// ============================================================================
// 01_basic_api.cpp — the complete FastAlloc C++ API tour, real-world patterns
// ----------------------------------------------------------------------------
// Build & run (from the FastAlloc repo root):
//   g++ -std=c++17 -O2 -Iinclude ../FastAlloc-RunKit/examples/01_basic_api.cpp \
//       build/libfast_alloc.a -pthread -o /tmp/ex01 && /tmp/ex01
//
// With leak/corruption checking (development builds):
//   g++ -std=c++17 -O1 -g -DFASTALLOC_DEBUG -Iinclude examples/01_basic_api.cpp \
//       build-dbg/libfast_alloc.a -pthread -o /tmp/ex01d && /tmp/ex01d
// ============================================================================
#include "fast_alloc.h"

#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Pattern 1: RAII wrapper — the way you normally use a C-style allocator in
// modern C++. Never leaks, exception-safe, zero overhead vs manual new/delete.
// ---------------------------------------------------------------------------
template <class T>
struct FastDelete {
    void operator()(T* p) const noexcept { FastAlloc::fast_free(p); }
};
template <class T>
using fast_unique_ptr = std::unique_ptr<T, FastDelete<T>>;

template <class T, class... Args>
fast_unique_ptr<T> make_fast(Args&&... args) {
    void* mem = FastAlloc::fast_malloc(sizeof(T));
    if (!mem) throw std::bad_alloc();                 // OOM: nullptr, allocator stays usable
    return fast_unique_ptr<T>(::new (mem) T(std::forward<Args>(args)...));
}

// Raw byte buffer with size hint (fast_free_sized skips a dependent load)
struct FastBuffer {
    void*  data = nullptr;
    size_t size = 0;
    explicit FastBuffer(size_t n) : data(FastAlloc::fast_malloc(n)), size(n) {
        if (!data) throw std::bad_alloc();
    }
    ~FastBuffer() { FastAlloc::fast_free_sized(data, size); }   // sized free = fastest path
    FastBuffer(const FastBuffer&) = delete;
    FastBuffer& operator=(const FastBuffer&) = delete;
    FastBuffer(FastBuffer&& o) noexcept : data(o.data), size(o.size) { o.data = nullptr; o.size = 0; }
    FastBuffer& operator=(FastBuffer&& o) noexcept {
        if (this != &o) { FastAlloc::fast_free_sized(data, size); data = o.data; size = o.size;
                          o.data = nullptr; o.size = 0; }
        return *this;
    }
};

static void print_stats(const char* tag) {
    FastAlloc::FastAllocStats s = FastAlloc::fast_alloc_stats();
    std::printf("  [%s] live: %zu blocks / %zu bytes   peak: %zu bytes   os_live: %zu MB\n",
                tag, s.current_live_blocks, s.current_live_bytes,
                s.peak_live_bytes, s.os_bytes_live / (1024 * 1024));
}

int main() {
    std::puts("== 1. malloc / free / calloc / realloc =========================");

    // Basic allocation. EVERY FastAlloc pointer is >= 16-byte aligned.
    void* p = FastAlloc::fast_malloc(128);
    std::memset(p, 0xAB, 128);
    FastAlloc::fast_free(p);

    // calloc = zero-initialized (verified, not assumed)
    unsigned* arr = (unsigned*)FastAlloc::fast_calloc(1000, sizeof(unsigned));
    bool all_zero = true;
    for (int i = 0; i < 1000; ++i) all_zero = all_zero && arr[i] == 0;
    std::printf("  calloc(1000 x 4B): all zero = %s\n", all_zero ? "YES" : "NO");

    // realloc grows in place when possible (large blocks use mremap on Linux)
    double* grown = (double*)FastAlloc::fast_realloc(arr, 4096 * sizeof(double));
    grown[4095] = 3.14159;                              // write to the tail — must be valid
    std::printf("  realloc to 32KB, tail write ok: %.5f\n", grown[4095]);

    // Documented zero-size semantics (glibc-compatible):
    void* z1 = FastAlloc::fast_malloc(0);               // UNIQUE non-null, free it
    std::printf("  malloc(0) -> unique non-null: %s\n", z1 ? "YES" : "NO");
    FastAlloc::fast_free(z1);
    std::printf("  realloc(p,0) -> %s (frees, returns nullptr per C11)\n",
                FastAlloc::fast_realloc(grown, 0) == nullptr ? "nullptr" : "BUG");
    FastAlloc::fast_free(nullptr);                      // documented no-op

    std::puts("== 2. Aligned allocation (SSE/AVX buffers) =====================");
    // Power of two, 16 <= alignment <= 4096. SIMD code wants 32/64-byte alignment.
    float* simd = (float*)FastAlloc::fast_aligned_alloc(64, 4096 * sizeof(float));
    std::printf("  64B-aligned AVX buffer: %%64 == %zu\n", (size_t)simd % 64);
    // realloc preserves the requested alignment
    float* simd2 = (float*)FastAlloc::fast_realloc(simd, 8192 * sizeof(float));
    std::printf("  after realloc still 64B-aligned: %%64 == %zu\n", (size_t)simd2 % 64);
    FastAlloc::fast_free(simd2);

    std::puts("== 3. RAII + placement new (production style) ==================");
    {
        auto obj = make_fast<std::string>(32, 'x');
        FastBuffer buf(8192);                           // 8KB = FastAlloc's slab sweet spot
        std::printf("  RAII string: %.6s...  RAII buffer: %zu bytes\n",
                    obj->c_str(), buf.size);
        print_stats("live");
    }                                                   // everything auto-freed here
    print_stats("freed");

    std::puts("== 4. OOM behaviour — check the return, keep running ===========");
    // FastAlloc returns nullptr on exhaustion; previously-allocated memory
    // stays valid and the allocator REMAINS USABLE (CI-verified). Handle it:
    void* huge = FastAlloc::fast_malloc(static_cast<size_t>(1) << 48);   // will fail
    std::printf("  absurd request -> %s (clean nullptr, no abort)\n", huge ? "BUG" : "nullptr");
    void* small_after_oom = FastAlloc::fast_malloc(64);                  // still works
    std::printf("  allocator still usable after OOM: %s\n", small_after_oom ? "YES" : "NO");
    FastAlloc::fast_free(small_after_oom);

    std::puts("== 5. Memory return to the OS ==================================");
    {
        std::vector<FastBuffer> hold;
        hold.reserve(64);
        for (int i = 0; i < 64; ++i) hold.emplace_back(64 * 1024);       // 4 MB live
        print_stats("4MB live");
    }
    FastAlloc::fast_alloc_purge();          // drop ALL cached page spans to the OS
    print_stats("after purge");

    std::puts("== 6. Shutdown hygiene (dev builds) ============================");
    // Under FASTALLOC_DEBUG this prints an exact leak report (file-free but
    // exact: count + sizes). In release it prints a "build without debug" notice.
    FastAlloc::fast_alloc_dump_leaks();

    std::puts("\nAll basic-API checks passed.");
    return 0;
}
