// ============================================================================
// 02_new_delete_override.cpp — route your ENTIRE C++ app through FastAlloc
// ----------------------------------------------------------------------------
// This is the "zero code changes" adoption path: every `new`, `delete`,
// `std::vector`, `std::string`, `std::make_shared` ... in your program
// (including third-party libs compiled into your binary) allocates via
// FastAlloc.
//
// REQUIREMENT: FastAlloc must be BUILT with -DFASTALLOC_OVERRIDE_NEW=ON
// (that's what scripts/01_build.sh does into build-override/). The library
// then DEFINES the six global operator new/delete overloads, forwarding
// sized deletes to fast_free_sized() (one dependent load fewer on free).
//
// Build & run (from the FastAlloc repo root, after 01_build.sh):
//   g++ -std=c++17 -O2 -DFAST_ALLOC_OVERRIDE_NEW -Iinclude \
//       ../FastAlloc-RunKit/examples/02_new_delete_override.cpp \
//       build-override/libfast_alloc.a -pthread -o /tmp/ex02 && /tmp/ex02
//
// Then verify *where* memory went:
//   FASTALLOC_LOG_LEVEL=3 /tmp/ex02          (info logging, needs FASTALLOC_DEBUG)
// ============================================================================
#ifdef FAST_ALLOC_OVERRIDE_NEW
#  include "fast_alloc.h"     // pulls in the operator new/delete declarations
#endif

#include <cstdio>
#include <deque>
#include <map>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

// A deliberately allocation-heavy workload: no FastAlloc call anywhere.
// Every byte below now comes from FastAlloc's TLS cache.
static int64_t simulate_request_pipeline(int requests) {
    int64_t checksum = 0;
    std::unordered_map<std::string, std::vector<double>> session_cache;
    session_cache.reserve(requests / 10 + 1);

    for (int i = 0; i < requests; ++i) {
        // std::string allocations (small blocks -> TLS fast path)
        std::string key = "session-" + std::to_string(i % 997);
        // vector growth (realloc-style churn)
        std::vector<double> samples;
        samples.reserve(8);
        for (int j = 0; j < 16; ++j) samples.push_back(j * 1.5 + i);
        // node-based containers (mixed sizes)
        std::map<int, std::string> tags{{i, key}, {i + 1, "secondary"}};
        // shared_ptr control blocks + payload
        auto ctx = std::make_shared<std::pair<std::string, int>>(key, i);
        // deque splicing (fragmentation pressure)
        std::deque<int> dq(samples.begin(), samples.begin() + 4);

        checksum += (int64_t)ctx->first.size() + tags.begin()->first +
                    (int64_t)samples.back() + dq.front();
        if (i % 10 == 0) session_cache[key] = samples;   // keep some alive
    }
    for (auto& kv : session_cache) checksum += (int64_t)kv.second.size();
    return checksum;
}

int main() {
    std::puts("== Global new/delete override demo =============================");
#ifdef FAST_ALLOC_OVERRIDE_NEW
    std::puts("  FAST_ALLOC_OVERRIDE_NEW defined - global operators routed");
#else
    std::puts("  (compiled WITHOUT the macro: this run uses plain system heap.)");
    std::puts("   rebuild with -DFAST_ALLOC_OVERRIDE_NEW and link");
    std::puts("   build-override/libfast_alloc.a to actually route new/delete");
#endif

    int64_t sum = simulate_request_pipeline(20000);

    // The allocator's own statistics now describe your WHOLE program.
    FastAlloc::FastAllocStats s = FastAlloc::fast_alloc_stats();
    std::printf("  workload checksum        : %lld\n", (long long)sum);
    std::printf("  small allocs via FastAlloc: %zu\n", s.small_allocs);
    std::printf("  large allocs              : %zu\n", s.large_allocs);
    std::printf("  current live              : %zu blocks / %zu bytes\n",
                s.current_live_blocks, s.current_live_bytes);
    std::printf("  peak live bytes           : %zu (%.1f MB)\n",
                s.peak_live_bytes, s.peak_live_bytes / 1048576.0);
    std::printf("  TLS cache misses          : %zu (low = caches are working)\n",
                s.tls_cache_misses);

    // Optional: at shutdown, hand every cached page back to the OS.
    FastAlloc::fast_alloc_purge();
    std::puts("  purge() done - cached page spans returned to the OS.");
    return 0;
}
