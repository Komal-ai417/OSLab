// ============================================================================
// 04_multithreaded_server.cpp — FastAlloc in a REAL app: a threaded TCP server
// ----------------------------------------------------------------------------
// A realistic "HTTP-ish" request/response server showing every FastAlloc
// pattern a production service needs:
//
//   * worker THREAD POOL  -> each worker gets its own FastAlloc TLS cache
//   * per-request DYNAMICALLY GROWN buffers  -> fast_malloc + fast_realloc
//   * FIXED 64B-aligned SIMD buffers for parsing -> fast_aligned_alloc
//   * cross-thread alloc/free (request built by worker A, freed by worker B)
//   * an allocation watchdog thread using fast_alloc_stats()
//   * graceful shutdown: drain -> leak dump (debug builds) -> purge
//
// Build & run (from the FastAlloc repo root, after scripts/01_build.sh):
//   g++ -std=c++17 -O2 -Iinclude ../FastAlloc-RunKit/examples/04_multithreaded_server.cpp \
//       build/libfast_alloc.a -pthread -o /tmp/ex04
//   /tmp/ex04                       # terminal 1  (server on 127.0.0.1:8080)
//   for i in $(seq 1 200); do
//       printf 'GET /item/%d HTTP/1.1\r\n\r\n' $i | timeout 2 nc 127.0.0.1 8080 | head -1
//   done                            # terminal 2  (hammer it)
//
// Stress it with real concurrency:
//   (for i in $(seq 1 1000); do
//        printf 'POST /data/%d\r\n' $i | nc -q1 127.0.0.1 8080 > /dev/null &
//    done; wait)
// ============================================================================
#include "fast_alloc.h"

#include <atomic>
#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <netinet/in.h>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
namespace cfg {
    constexpr int      kPort        = 8080;
    constexpr int      kWorkers     = 4;      // each gets its own TLS cache
    constexpr size_t   kInitBuf     = 1024;   // request buffer start size
    constexpr size_t   kMaxRequest  = 1 << 20;
}

// ---------------------------------------------------------------------------
// Pattern: a fast_malloc-backed auto-growing I/O buffer.
// Identical role to std::vector<char>, but explicit: you SEE the allocator
// calls a real server makes, and free uses the sized fast path.
// ---------------------------------------------------------------------------
class RequestBuffer {
public:
    ~RequestBuffer() { FastAlloc::fast_free_sized(data_, cap_); }
    char*       data()       { return static_cast<char*>(data_); }
    size_t      size() const { return len_; }
    // Read more bytes, growing via fast_realloc (large blocks use mremap on
    // Linux — often NO copy at all).
    ssize_t read_more(int fd) {
        if (len_ + 4096 > cap_) {
            size_t new_cap = cap_ * 2;
            void* p = FastAlloc::fast_realloc(data_, new_cap);
            if (!p) return -1;                       // OOM: FastAlloc returns nullptr
            data_ = p; cap_ = new_cap;
        }
        ssize_t n = ::recv(fd, static_cast<char*>(data_) + len_, 4096, 0);
        if (n > 0) len_ += static_cast<size_t>(n);
        return n;
    }
    void reset() { len_ = 0; }
private:
    void*  data_ = FastAlloc::fast_malloc(cfg::kInitBuf);
    size_t cap_  = cfg::kInitBuf;
    size_t len_  = 0;
};

// ---------------------------------------------------------------------------
// Pattern: response objects live on FastAlloc. Worker B may free what worker
// A allocated — FastAlloc's lock-free MPSC pending queues handle exactly this.
// ---------------------------------------------------------------------------
struct Response {
    void*   body = nullptr;
    size_t  len  = 0;
    ~Response() { FastAlloc::fast_free(body); }        // cross-thread-safe free
};

static void build_response(Response* r, const char* status,
                           const std::string& body) {
    std::string full = std::string(status) + "\r\nContent-Length: "
                     + std::to_string(body.size()) + "\r\n\r\n" + body;
    r->body = FastAlloc::fast_malloc(full.size());
    r->len  = full.size();
    if (r->body) std::memcpy(r->body, full.data(), full.size());  // OOM check first
}

// ---------------------------------------------------------------------------
// Pattern: 64-byte aligned scratch buffer for SIMD parsing (AVX-512 friendly)
// ---------------------------------------------------------------------------
struct AlignedScratch {
    float* p = static_cast<float*>(FastAlloc::fast_aligned_alloc(64, 4096));
    ~AlignedScratch() { FastAlloc::fast_free(p); }
};

// ---------------------------------------------------------------------------
// Thread pool with a socket queue
// ---------------------------------------------------------------------------
class Server {
public:
    explicit Server(int port, int workers)
        : port_(port), workers_(workers), scratch_(new AlignedScratch[workers]) {
        for (int i = 0; i < workers; ++i)
            pool_.emplace_back([this, i] { worker_loop(i); });
    }

    bool start() {
        listen_fd_ = ::socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) return false;
        int yes = 1;
        ::setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(static_cast<uint16_t>(port_));
        if (::bind(listen_fd_, (sockaddr*)&addr, sizeof(addr)) < 0 ||
            ::listen(listen_fd_, 128) < 0) return false;
        accepter_ = std::thread([this] { accept_loop(); });
        std::printf("  listening on 127.0.0.1:%d  (%d worker threads)\n", port_, workers_);
        return true;
    }

    void stop() {
        running_ = false;
        if (listen_fd_ >= 0) { ::shutdown(listen_fd_, SHUT_RDWR); ::close(listen_fd_); }
        if (accepter_.joinable()) accepter_.join();
        cv_.notify_all();
        for (auto& t : pool_) if (t.joinable()) t.join();

        // ---- shutdown hygiene: prove no leaks, return memory to the OS ----
        FastAlloc::FastAllocStats s = FastAlloc::fast_alloc_stats();
        std::printf("\n  [shutdown] served %llu requests, %llu errors\n",
                    (unsigned long long)served_, (unsigned long long)errors_);
        std::printf("  [shutdown] FastAlloc live: %zu blocks / %zu bytes "
                    "(should equal 0 leaks of ours; the gtest test heap may differ)\n",
                    s.current_live_blocks, s.current_live_bytes);
        FastAlloc::fast_alloc_dump_leaks();   // exact leak report in DEBUG builds
        FastAlloc::fast_alloc_purge();        // hand every cached page back to OS
        delete[] scratch_;
    }

private:
    void accept_loop() {
        while (running_) {
            int cfd = ::accept(listen_fd_, nullptr, nullptr);
            if (cfd < 0) { if (!running_) break; continue; }
            { std::lock_guard<std::mutex> g(mq_); queue_.push_back(cfd); }
            cv_.notify_one();
        }
    }

    void worker_loop(int id) {
        (void)id;  // this thread's FastAlloc TLS cache is created lazily on
                   // its first fast_malloc — that's the wait-free fast path.
        RequestBuffer buf;                       // per-thread reusable buffer
        while (running_) {
            int cfd;
            {
                std::unique_lock<std::mutex> lk(mq_);
                cv_.wait_for(lk, std::chrono::milliseconds(100),
                             [&] { return !queue_.empty() || !running_; });
                if (!running_ && queue_.empty()) return;
                if (queue_.empty()) continue;
                cfd = queue_.front(); queue_.pop_front();
            }
            handle_connection(cfd, buf);
        }
    }

    void handle_connection(int cfd, RequestBuffer& buf) {
        buf.reset();
        // Read until end of headers (or cap)
        while (true) {
            ssize_t n = buf.read_more(cfd);
            if (n <= 0) { ::close(cfd); ++errors_; return; }
            if (std::search(buf.data(), buf.data() + buf.size(),
                             "\r\n\r\n", "\r\n\r\n" + 4) != buf.data() + buf.size() ||
                buf.size() >= cfg::kMaxRequest) break;
        }

        // Fake "parsing" that touches the aligned SIMD scratch
        volatile float sink = scratch_[0].p[0];

        // Build + send the response (FastAlloc'd body, freed by destructor
        // possibly on a DIFFERENT worker than the one that allocated it)
        Response resp;
        std::string path = "unknown";
        char* sp = static_cast<char*>(std::memchr(buf.data(), ' ', buf.size()));
        if (sp) {
            char* sp2 = static_cast<char*>(std::memchr(sp + 1, ' ', buf.size() - ((sp + 1) - static_cast<char*>(buf.data()))));
            if (sp2) path.assign(sp + 1, sp2);
        }
        std::string body = "hello from FastAlloc! you asked for: " + path +
                           " (sink=" + std::to_string((int)sink) + ")";
        build_response(&resp, "HTTP/1.1 200 OK", body);
        if (resp.body) {
            size_t off = 0;
            while (off < resp.len) {
                ssize_t n = ::send(cfd, static_cast<char*>(resp.body) + off,
                                   resp.len - off, MSG_NOSIGNAL);
                if (n <= 0) { ++errors_; break; }
                off += static_cast<size_t>(n);
            }
            ++served_;
        } else ++errors_;
        ::close(cfd);
    }

    int port_, workers_, listen_fd_ = -1;
    std::atomic<bool> running_{true};
    std::atomic<uint64_t> served_{0}, errors_{0};
    std::thread accepter_;
    std::vector<std::thread> pool_;
    std::mutex mq_;
    std::condition_variable cv_;
    std::deque<int> queue_;
    AlignedScratch* scratch_;
};

// ---------------------------------------------------------------------------
// Pattern: allocation WATCHDOG thread — a real ops tool. If live bytes creep
// up while traffic is flat, you have a leak: log it, page someone.
// ---------------------------------------------------------------------------
static void watchdog(std::atomic<bool>& run) {
    size_t last_live = 0;
    while (run) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        FastAlloc::FastAllocStats s = FastAlloc::fast_alloc_stats();
        if (s.current_live_bytes > last_live * 2 + (1 << 20)) {
            std::printf("  [watchdog] live bytes grew %.1f MB -> %.1f MB — investigate\n",
                        last_live / 1048576.0, s.current_live_bytes / 1048576.0);
        }
        last_live = s.current_live_bytes;
    }
}

int main() {
    std::puts("== FastAlloc in a real multi-threaded TCP server ==============");
    std::puts("  (try: printf 'GET /demo HTTP/1.1\\r\\n\\r\\n' | nc 127.0.0.1 8080)");
    Server server(cfg::kPort, cfg::kWorkers);
    if (!server.start()) { std::perror("bind/listen"); return 1; }

    std::atomic<bool> wd_run{true};
    std::thread wd(watchdog, std::ref(wd_run));

    std::printf("  running for 30 seconds (Ctrl-C or wait)...\n");
    std::this_thread::sleep_for(std::chrono::seconds(30));

    wd_run = false; wd.join();
    server.stop();
    std::puts("  done — stats above prove the shutdown is leak-free & purged.");
    return 0;
}
