// fast_alloc_c.cpp — implementation of the extern "C" shim (compile as C++)
#include "fast_alloc_c.h"
#include "fast_alloc.h"

extern "C" {

void* fa_malloc(size_t size)                { return FastAlloc::fast_malloc(size); }
void* fa_calloc(size_t num, size_t size)    { return FastAlloc::fast_calloc(num, size); }
void* fa_realloc(void* ptr, size_t n)       { return FastAlloc::fast_realloc(ptr, n); }
void  fa_free(void* ptr)                    { FastAlloc::fast_free(ptr); }
void  fa_free_sized(void* ptr, size_t size) { FastAlloc::fast_free_sized(ptr, size); }
void* fa_aligned_alloc(size_t a, size_t s)  { return FastAlloc::fast_aligned_alloc(a, s); }
void  fa_purge(void)                        { FastAlloc::fast_alloc_purge(); }

size_t fa_live_bytes(void)  { return FastAlloc::fast_alloc_stats().current_live_bytes; }
size_t fa_live_blocks(void) { return FastAlloc::fast_alloc_stats().current_live_blocks; }

}  // extern "C"
