// ============================================================================
// 03_stl_allocator.cpp — demo: hot containers on FastAlloc, cold ones on malloc
// ----------------------------------------------------------------------------
// Build & run (from the FastAlloc repo root):
//   g++ -std=c++17 -O2 -Iinclude -I../FastAlloc-RunKit/examples \
//       ../FastAlloc-RunKit/examples/03_stl_allocator.cpp \
//       build/libfast_alloc.a -pthread -o /tmp/ex03 && /tmp/ex03
// ============================================================================
#include "fast_stl_allocator.h"

#include <cstdio>
#include <chrono>
#include <map>
#include <string>
#include <vector>   // plain std containers for the cold path comparison

// Hot path: per-message bookkeeping in a trading-tick style loop.
// These containers allocate/free thousands of small blocks per second —
// exactly the workload FastAlloc's TLS cache is built for (sweet spot:
// blocks <= 8 KB).
struct Tick {
    fast_string<std::char_traits<char>> symbol;
    fast_vector<double> prices;
    int64_t ns() const { return 0; }
};

int main() {
    std::puts("== STL adapter demo: mixed hot/cold allocation strategy ========");

    // --- HOT: node + buffer churn on FastAlloc ---------------------------
    fast_umap<int, fast_vector<double>> order_book;
    order_book.reserve(1024);

    auto t0 = std::chrono::steady_clock::now();
    int64_t checksum = 0;
    for (int i = 0; i < 200000; ++i) {
        fast_vector<double>& levels = order_book[i % 512];
        if (levels.empty()) levels.reserve(16);
        levels.push_back(i * 0.25);
        if (levels.size() > 32) levels.clear();           // churn: alloc/free storm
        Tick t{("SYM-" + std::to_string(i % 64)).c_str(), fast_vector<double>{1.0, 2.0, 3.0}};
        checksum += (int64_t)t.prices[2] + levels.size();
    }
    auto t1 = std::chrono::steady_clock::now();

    // --- COLD: same-shaped work on the system heap for comparison --------
    std::unordered_map<int, std::vector<double>> cold_book;
    int64_t cold_sum = 0;
    for (int i = 0; i < 200000; ++i) {
        std::vector<double>& levels = cold_book[i % 512];
        levels.push_back(i * 0.25);
        if (levels.size() > 32) levels.clear();
        std::string s = "SYM-" + std::to_string(i % 64);
        cold_sum += (int64_t)s.size() + levels.size();
    }
    auto t2 = std::chrono::steady_clock::now();

    auto ms = [](auto a, auto b) {
        return std::chrono::duration_cast<std::chrono::milliseconds>(b - a).count();
    };
    std::printf("  FastAlloc-backed hot loop : %lld ms  (checksum %lld)\n",
                (long long)ms(t0, t1), (long long)checksum);
    std::printf("  system-heap cold loop     : %lld ms  (checksum %lld)\n",
                (long long)ms(t1, t2), (long long)cold_sum);

    // --- What the allocator saw ------------------------------------------
    FastAlloc::FastAllocStats s = FastAlloc::fast_alloc_stats();
    std::printf("  FastAlloc small allocs    : %zu\n", s.small_allocs);
    std::printf("  FastAlloc large allocs    : %zu\n", s.large_allocs);
    std::printf("  TLS cache misses          : %zu (should be tiny vs allocs)\n",
                s.tls_cache_misses);
    std::printf("  live now                  : %zu blocks / %zu bytes\n",
                s.current_live_blocks, s.current_live_bytes);

    order_book.clear();
    FastAlloc::fast_alloc_purge();
    std::puts("  cleared + purged.");
    return 0;
}
