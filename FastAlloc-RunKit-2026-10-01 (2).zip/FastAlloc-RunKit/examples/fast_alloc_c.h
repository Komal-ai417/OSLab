/* ===========================================================================
 * fast_alloc_c.h — use FastAlloc from PURE C (or Python/Rust via FFI)
 * ---------------------------------------------------------------------------
 * FastAlloc's native API is C++ (namespaced). Real-world C codebases —
 * kernels, embedded firmware, legacy engines, Lua/CPython extension modules —
 * need plain C symbols. This tiny extern "C" shim does exactly that.
 *
 * Compile the .cpp once into your project (needs a C++ compiler; the resulting
 * symbols are plain C and link into C binaries).
 * =========================================================================== */
#ifndef FAST_ALLOC_C_H
#define FAST_ALLOC_C_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void*  fa_malloc(size_t size);
void*  fa_calloc(size_t num, size_t size);
void*  fa_realloc(void* ptr, size_t new_size);
void   fa_free(void* ptr);
/* size-hinted free — skips one dependent load inside FastAlloc */
void   fa_free_sized(void* ptr, size_t size);
/* power-of-two alignment, 16 <= align <= 4096 */
void*  fa_aligned_alloc(size_t alignment, size_t size);
/* drop every cached page span back to the OS */
void   fa_purge(void);
/* O(1) stats snapshot — useful for exposing allocator metrics to ops */
size_t fa_live_bytes(void);
size_t fa_live_blocks(void);

#ifdef __cplusplus
}  /* extern "C" */
#endif

#endif /* FAST_ALLOC_C_H */
