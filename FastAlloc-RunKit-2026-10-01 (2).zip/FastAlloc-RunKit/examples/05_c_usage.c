/* ===========================================================================
 * 05_c_usage.c — real-world pure-C usage: a packet-processing ring buffer
 * ---------------------------------------------------------------------------
 * A classic embedded/networking pattern: a fixed pool of dynamically sized
 * message slots, zero-copy handoff, sized frees on the hot path. Written in
 * 100% C, proving FastAlloc slots into non-C++ codebases via the shim.
 *
 * Build & run (from the FastAlloc repo root, after scripts/01_build.sh):
 *   g++ -std=c++17 -O2 -c -Iinclude ../FastAlloc-RunKit/examples/fast_alloc_c.cpp \
 *       -o /tmp/fa_c.o
 *   gcc -std=c11 -O2 -I../FastAlloc-RunKit/examples \
 *       ../FastAlloc-RunKit/examples/05_c_usage.c /tmp/fa_c.o \
 *       build/libfast_alloc.a -lstdc++ -pthread -o /tmp/ex05 && /tmp/ex05
 *   (NOTE the -lstdc++: a C program linking C++ objects needs the C++ runtime)
 * =========================================================================== */
#include "fast_alloc_c.h"
#include <stdio.h>
#include <string.h>

#define SLOTS 128

typedef struct {
    unsigned char* buf;
    size_t         len;
} packet_t;

/* Producer/consumer ring over FastAlloc slots. In real firmware the producer
 * is a DMA/IRQ handler filling buffers; here we synthesize payloads. */
static packet_t ring[SLOTS];
static unsigned head = 0, tail = 0, dropped = 0;

static int ring_push(const unsigned char* src, size_t len) {
    unsigned next = (head + 1) % SLOTS;
    if (next == tail) { dropped++; return -1; }              /* full */
    unsigned char* p = (unsigned char*)fa_malloc(len);
    if (!p) { dropped++; return -1; }                        /* OOM: clean nullptr */
    memcpy(p, src, len);
    ring[head].buf = p; ring[head].len = len;
    head = next;
    return 0;
}

static int ring_pop(unsigned char* out, size_t cap, size_t* out_len) {
    if (tail == head) return -1;                             /* empty */
    packet_t* pkt = &ring[tail];
    size_t n = pkt->len < cap ? pkt->len : cap;
    memcpy(out, pkt->buf, n);
    *out_len = pkt->len;
    fa_free_sized(pkt->buf, pkt->len);                       /* hot-path sized free */
    tail = (tail + 1) % SLOTS;
    return 0;
}

int main(void) {
    puts("== Pure-C usage: packet ring on FastAlloc ======================");

    /* --- hot loop: variable-size packets, 64..1500 bytes (slab sweet spot) */
    unsigned char payload[1500];
    unsigned long checksum = 0;
    for (int round = 0; round < 1000; ++round) {
        for (int i = 0; i < SLOTS / 2; ++i) {
            size_t len = 64 + ((unsigned)i * 37 + round * 13) % 1437;
            memset(payload, (unsigned char)(i + round), len);
            payload[0] = (unsigned char)(len & 0xFF);        /* length header */
            payload[1] = (unsigned char)((len >> 8) & 0xFF);
            ring_push(payload, len);
        }
        unsigned char out[1500];
        size_t olen;
        while (ring_pop(out, sizeof out, &olen) == 0) {
            /* verify the length header survived the round trip */
            unsigned declared = out[0] | ((unsigned)out[1] << 8);
            if (declared + 64 <= 1500) checksum += declared + olen;
        }
    }
    printf("  1000 rounds x %d slots, checksum=%lu, dropped=%u\n",
           SLOTS / 2, checksum, dropped);

    /* --- aligned DMA-style scratch ------------------------------------ */
    void* dma = fa_aligned_alloc(4096, 65536);   /* page-aligned 64KB block */
    printf("  4096B-aligned DMA buffer: %%4096 == %zu\n", (size_t)dma % 4096);
    fa_free(dma);

    /* --- ops metrics straight from the allocator ------------------------ */
    printf("  live now: %zu bytes in %zu blocks (both should be small)\n",
           fa_live_bytes(), fa_live_blocks());

    fa_purge();
    puts("  purged — every cached page span returned to the OS.");
    return 0;
}
