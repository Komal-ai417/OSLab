// ============================================================================
// fast_stl_allocator.h — use FastAlloc for selected hot STL containers
// ----------------------------------------------------------------------------
// The surgical alternative to the global new/delete override: keep system
// malloc for cold code, route ONLY your hot containers through FastAlloc.
//
//   #include "fast_stl_allocator.h"
//   std::vector<int, FastAllocator<int>> hot;        // per-element storage
//   std::map<K, V, std::less<K>, FastAllocator<std::pair<const K, V>>> m;
//
// Drop the header next to your sources; it only needs fast_alloc.h + the
// FastAlloc static library on the link line.
// ============================================================================
#pragma once
#include "fast_alloc.h"
#include <cstddef>
#include <new>
#include <type_traits>
#include <utility>

template <class T>
struct FastAllocator {
    using value_type = T;

    FastAllocator() noexcept = default;
    template <class U>
    FastAllocator(const FastAllocator<U>&) noexcept {}

    // -- allocate n objects of T ------------------------------------------
    T* allocate(std::size_t n) {
        if (n == 0) return nullptr;
        if (n > static_cast<std::size_t>(-1) / sizeof(T))   // overflow guard
            throw std::bad_alloc();
        void* p = FastAlloc::fast_malloc(n * sizeof(T));
        if (!p) throw std::bad_alloc();                     // FastAlloc OOM contract
        return static_cast<T*>(p);
    }

    // -- sized free: FastAlloc skips a dependent load when told the size ----
    void deallocate(T* p, std::size_t n) noexcept {
        FastAlloc::fast_free_sized(p, n * sizeof(T));
    }

    // -- rebinding for node-based containers (map, list, set) ---------------
    template <class U>
    struct rebind { using other = FastAllocator<U>; };

    // -- STL requirement boilerplate ----------------------------------------
    using size_type       = std::size_t;
    using difference_type = std::ptrdiff_t;
    using pointer         = T*;
    using const_pointer   = const T*;
    using reference       = T&;
    using const_reference = const T&;
    T* address(T& x) const noexcept { return &x; }
    const T* address(const T& x) const noexcept { return &x; }
    size_type max_size() const noexcept { return static_cast<size_type>(-1) / sizeof(T); }
    template <class U, class... Args>
    void construct(U* p, Args&&... args) { ::new ((void*)p) U(std::forward<Args>(args)...); }
    template <class U>
    void destroy(U* p) noexcept { p->~U(); }
};

template <class T, class U>
bool operator==(const FastAllocator<T>&, const FastAllocator<U>&) noexcept { return true; }
template <class T, class U>
bool operator!=(const FastAllocator<T>&, const FastAllocator<U>&) noexcept { return false; }

// ---------------------------------------------------------------------------
// Convenience aliases for the common containers
// ---------------------------------------------------------------------------
#include <deque>
#include <list>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

template <class T>            using fast_vector  = std::vector<T,  FastAllocator<T>>;
template <class T>            using fast_deque   = std::deque<T,   FastAllocator<T>>;
template <class T>            using fast_list    = std::list<T,    FastAllocator<T>>;
template <class K, class V>   using fast_map     = std::map<K, V, std::less<K>,
                                                           FastAllocator<std::pair<const K, V>>>;
template <class K, class V>   using fast_umap    = std::unordered_map<K, V, std::hash<K>, std::equal_to<K>,
                                                           FastAllocator<std::pair<const K, V>>>;
template <class C>            using fast_string  = std::basic_string<char, C, FastAllocator<char>>;
