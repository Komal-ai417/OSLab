#!/usr/bin/env bash
# ============================================================================
# 04_benchmarks.sh — run every benchmark that ships with FastAlloc
# ----------------------------------------------------------------------------
# Usage:   bash 04_benchmarks.sh [path/to/FastAlloc] [--quick]
#
#   1. fast_alloc_bench           30 configs  BM_MallocFree_{Std,FastAlloc}
#                                             x {8,64,512,4096,8192}B x {1,4,8}T
#   2. fast_alloc_bench_extended  62 configs  MallocOnly/FreeOnly/RandomSize/
#                                             ScopedAlloc/LargeAlloc/Realloc/
#                                             Calloc/HeavyContention
#   3. fast_alloc_bench_memory    side-by-side time + PEAK RSS vs std::malloc
#   4. bench_suite                11 Larsson/mimalloc-bench style workloads
#                                             (FastAlloc in-process)
#
# Pass --quick for a fast smoke run (~1 min) instead of the full matrix.
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"
[[ "${2:-}" == "--quick" ]] && QUICK=1 || QUICK=0

hdr() { echo -e "\n\033[1;35m================ $* ================\033[0m"; }
need() { [[ -x "$REPO/build/$1" ]] || { echo "missing $REPO/build/$1 - run 01_build.sh"; exit 1; }; }

GB_MIN=--benchmark_min_time=3000x     # 3000 iterations per bench (CI default)
[[ $QUICK -eq 1 ]] && GB_MIN=--benchmark_min_time=300x

# ---- 1. Core micro suite: std::malloc vs FastAlloc, same process ----------
need fast_alloc_bench
hdr "fast_alloc_bench — malloc/free pairs (std vs FastAlloc)"
"$REPO/build/fast_alloc_bench" $GB_MIN --benchmark_report_aggregates_only=true

# ---- 2. Extended suite ------------------------------------------------------
need fast_alloc_bench_extended
hdr "fast_alloc_bench_extended — MallocOnly/FreeOnly/Random/Realloc/Calloc/Contention"
"$REPO/build/fast_alloc_bench_extended" $GB_MIN --benchmark_report_aggregates_only=true

# ---- 3. Memory stress: time + peak RSS --------------------------------------
need fast_alloc_bench_memory
hdr "fast_alloc_bench_memory — time & peak-RSS vs std::malloc"
for T in 1 4; do
    "$REPO/build/fast_alloc_bench_memory" --threads "$T" --allocs 20000 --size 4096
done

# ---- 4. Cross-allocator workloads (FastAlloc side; 05_cross_allocator.sh
#         adds glibc/jemalloc/mimalloc via LD_PRELOAD) ------------------------
need bench_suite
hdr "bench_suite — FastAlloc on every workload"
WLS="tiny small-mixed random-1-4096 ramp churn cache-thrash cross-thread thread-churn large realloc-grow overhead"
[[ $QUICK -eq 1 ]] && WLS="tiny churn large"
for w in $WLS; do
    "$REPO/build/bench_suite" --alloc fast --label FastAlloc --workload "$w" \
        --threads 4 --reps 3 --json "$REPO/bench_fast.jsonl" | tail -2
done

echo -e "\n\033[1;32mDone. Cross-allocator verdict: bash 05_cross_allocator.sh\033[0m"
