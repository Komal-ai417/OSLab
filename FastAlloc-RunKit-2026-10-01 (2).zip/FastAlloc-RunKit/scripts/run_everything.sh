#!/usr/bin/env bash
# ============================================================================
# run_everything.sh — ONE command: the full FastAlloc verification battery
# ----------------------------------------------------------------------------
# Usage:   bash run_everything.sh [path/to/FastAlloc]
#
# Runs, in order:
#   0. prerequisite check
#   1. build every configuration   (release, debug-instrumented, asan, tsan,
#                                    lsan, new/delete-override)
#   2. correctness suites          (75 release + 86 debug gtest cases)
#   3. sanitizer matrix            (ASan+UBSan / TSan / LSan)
#   4. every benchmark binary
#   5. cross-allocator comparison  (glibc / jemalloc if present)
#   6. memory footprint proof
#
# Total wall time on a 2-core VM: ~25-40 min (first run downloads GTest/GBench).
# Skip stages with:  SKIP=benchmarks,cross,mem bash run_everything.sh
# ============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"

skip() { [[ ",${SKIP:-}," == *",$1,"* ]]; }

echo "#######################################################################"
echo "#  FastAlloc FULL verification battery"
echo "#  repo: $REPO"
echo "#######################################################################"

skip check     || bash "$HERE/00_prereqs.sh"
skip build     || bash "$HERE/01_build.sh" "$REPO"
skip tests     || bash "$HERE/02_test_correctness.sh" "$REPO"
skip sanitizers || bash "$HERE/03_sanitizers.sh" "$REPO"
skip benchmarks || bash "$HERE/04_benchmarks.sh" "$REPO"
skip cross     || bash "$HERE/05_cross_allocator.sh" "$REPO" || echo "(cross-allocator skipped/failed - optional)"
skip mem       || bash "$HERE/06_memory_footprint.sh" "$REPO" || echo "(memory footprint skipped - optional)"

echo "#######################################################################"
echo "#  DONE — everything above this line ran to completion."
echo "#  Green = the allocator is correct, race-free, leak-free on this box."
echo "#######################################################################"
