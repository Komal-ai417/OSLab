#!/usr/bin/env bash
# ============================================================================
# 02_test_correctness.sh — run the FULL correctness suite in every mode
# ----------------------------------------------------------------------------
# Usage:   bash 02_test_correctness.sh [path/to/FastAlloc]
#
# What runs:
#   1. Release build        : 75 gtest cases  (functional + concurrency + OOM)
#   2. FASTALLOC_DEBUG build: 86 gtest cases  (+ death tests: canaries,
#                             red zones, use-after-free poison, double free,
#                             corrupt headers, leak dump)
#   3. Manual binary run so you SEE the gtest summary line per config.
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"

hdr() { echo -e "\n\033[1;35m================ $* ================\033[0m"; }

run_one() {  # run_one <dir> <label> [note printed when there is no test binary]
    local dir="$1" label="$2" note="${3:-}"
    hdr "$label  ($dir)"
    if [[ ! -x "$REPO/$dir/fast_alloc_tests" ]]; then
        if [[ -n "$note" ]]; then
            echo "no test binary here - $note"
        else
            echo "binary missing - run 01_build.sh first; skipping"
        fi
        return 0
    fi
    "$REPO/$dir/fast_alloc_tests" 2>&1 | tail -5
}

# --- 1. ctest in Release ----------------------------------------------------
hdr "ctest — Release"
ctest --test-dir "$REPO/build" --output-on-failure -V 2>&1 | tail -6

# --- 2. Raw binary summaries (visible pass counts) ---------------------------
run_one build        "Release tests"
run_one build-dbg    "Debug instrumentation tests (canaries/poison/death tests)"
# build-override deliberately has NO test binary: 01_build.sh builds only the
# override library (libfast_alloc.a) there -- gtest exercises the normal
# paths. The override path is proven by the examples instead (RUNBOOK §7.2):
#   cd ../FastAlloc-RunKit/examples && make FASTALLOC="$REPO" ex02_override && ./ex02_override
#   -> expect exit 0 and 'current live: 0' after the frees (proves patch OVR-1 + STAT-1).
run_one build-override "Global new/delete override build" \
    "BY DESIGN (01_build.sh builds only the override library); verify this path with: make -C ../FastAlloc-RunKit/examples FASTALLOC=$REPO ex02_override && ./../FastAlloc-RunKit/examples/ex02_override"

echo -e "\n\033[1;32mExpected results:\033[0m"
if [[ -f "$REPO/tests/audit/CMakeLists.txt" ]]; then
    echo "  Release : 75/75 validate + 49/49 audit (both suites run by ctest)"
    echo "  Debug   : 86 validate tests (85 pass + 1 SKIPPED by design); audit suite"
    echo "            intentionally NOT registered under FASTALLOC_DEBUG (heavy tiers"
    echo "            are release-semantics calibrated; run its binary directly if"
    echo "            you insist: 46 pass + 3 skip)"
else
    echo "  Release : 75/75 passed"
    echo "  Debug   : 86 tests, 85 passed + 1 SKIPPED by design (needs corrupt-header injection)"
fi
echo "  Override: no test binary by design - prove it with the examples:"
echo "            make -C ../FastAlloc-RunKit/examples FASTALLOC=$REPO ex02_override && ./../FastAlloc-RunKit/examples/ex02_override"
echo "            (expect exit 0 + 'current live: 0'; needs the RunKit patch applied - RUNBOOK §7.2/§9)"
echo "Next: bash 03_sanitizers.sh"
