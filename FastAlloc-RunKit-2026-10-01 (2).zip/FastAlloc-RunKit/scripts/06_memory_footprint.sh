#!/usr/bin/env bash
# ============================================================================
# 06_memory_footprint.sh — prove the memory-return claim on YOUR machine
# ----------------------------------------------------------------------------
# Usage:   bash 06_memory_footprint.sh [path/to/FastAlloc]
#
# Demonstrates:
#   1. Peak RSS + retention of 1M live objects, per allocator
#   2. fast_alloc_purge() returning EVERYTHING to the OS
#   3. fast_alloc_stats() + fast_alloc_dump_leaks() as an in-app watchdog
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"
BENCH="$REPO/build/bench_suite"
[[ -x "$BENCH" ]] || { echo "missing $BENCH - run 01_build.sh"; exit 1; }

hdr() { echo -e "\n\033[1;35m================ $* ================\033[0m"; }

JEM=""
for so in /usr/lib/x86_64-linux-gnu/libjemalloc.so.2 /lib/x86_64-linux-gnu/libjemalloc.so.2; do
    [[ -z "$JEM" && -f "$so" ]] && JEM="$so"
done

hdr "Memory retention: 1M live 512B objects, then free-all, then purge"
echo "(retained_after_free / retained_after_purge columns, MB — lower is better)"
echo

for t in 1 4; do
    echo "--- threads=$t ---"
    for alloc in fast std; do
        if [[ $alloc == fast ]]; then
            "$BENCH" --alloc fast --label FastAlloc --workload ramp --threads "$t" --reps 1 --json "$REPO/mem_fast.jsonl" >/dev/null
        else
            "$BENCH" --alloc std --label glibc --workload ramp --threads "$t" --reps 1 --json "$REPO/mem_glibc.jsonl" >/dev/null
            [[ -n "$JEM" ]] && LD_PRELOAD="$JEM" "$BENCH" --alloc std --label jemalloc --workload ramp --threads "$t" --reps 1 --json "$REPO/mem_jem.jsonl" >/dev/null
        fi
    done
    python3 - "$REPO/mem_fast.jsonl" "$REPO/mem_glibc.jsonl" "$REPO/mem_jem.jsonl" <<'EOF'
import json, sys
rows = []
for f in sys.argv[1:]:
    try:
        with open(f) as fh:
            for line in fh:
                d = json.loads(line)
                r = d["reps"][0]
                rows.append((d["label"], r["rss_peak_mb"], r.get("retained_after_free_mb", -1), r.get("retained_after_purge_mb", -1)))
    except FileNotFoundError:
        pass
print(f"  {'allocator':<12}{'peak RSS MB':>14}{'after free MB':>16}{'after purge MB':>18}")
for label, peak, after_free, after_purge in rows:
    print(f"  {label:<12}{peak:>14.1f}{after_free:>16.1f}{after_purge:>18.1f}")
EOF
done

hdr "Side-by-side stress (time + peak RSS), std::malloc vs FastAlloc"
"$REPO/build/fast_alloc_bench_memory" --threads 4 --allocs 100000 --size 512

echo -e "\n\033[1;32mClaim to verify (from docs/performance_report.md, 2026-09-10):\033[0m"
echo "  after freeing 1M objects + purge: FastAlloc ~16 MB retained"
echo "  vs glibc 46.7 MB / jemalloc 171.8 MB / mimalloc 552.2 MB."
echo "Your numbers WILL differ by machine/kernel — the RATIO is the point."
