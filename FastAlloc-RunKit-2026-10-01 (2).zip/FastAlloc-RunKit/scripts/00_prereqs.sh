#!/usr/bin/env bash
# ============================================================================
# 00_prereqs.sh — verify/install everything needed to build & test FastAlloc
# ----------------------------------------------------------------------------
# Usage:  bash 00_prereqs.sh
#
# Needs:  a C++17 compiler (g++ >= 9 or clang++ >= 10), CMake >= 3.15,
#         Python 3, and internet access ONCE (CMake FetchContent downloads
#         Google Test v1.14.0 + Google Benchmark v1.9.4 on first configure).
# ============================================================================
set -euo pipefail

green() { printf '\033[0;32m%s\033[0m\n' "$*"; }
red()   { printf '\033[0;31m%s\033[0m\n' "$*"; }
ok()    { green "  [OK] $*"; }
miss()  { red "  [MISSING] $*"; }

echo "==================== FastAlloc prerequisites check ===================="

fail=0

# --- C++ compiler ----------------------------------------------------------
if command -v g++ >/dev/null 2>&1; then
    ok "g++  : $(g++ --version | head -1)"
elif command -v clang++ >/dev/null 2>&1; then
    ok "clang++ : $(clang++ --version | head -1)"
else
    miss "no C++ compiler"; fail=1
fi

# --- CMake -----------------------------------------------------------------
if command -v cmake >/dev/null 2>&1; then
    ok "cmake : $(cmake --version | head -1)"
else
    miss "cmake (pip3 install cmake  OR  sudo apt install cmake)"; fail=1
fi

# --- Ninja (optional but faster) --------------------------------------------
if command -v ninja >/dev/null 2>&1; then
    ok "ninja : $(ninja --version)  (optional, faster builds)"
else
    echo "  [info] ninja not found - scripts fall back to make"
fi

# --- Python 3 (bench_compare.py / analyze.py) -------------------------------
if command -v python3 >/dev/null 2>&1; then
    ok "python3 : $(python3 --version)"
else
    miss "python3 (needed only for benchmark verdict tooling)"; fail=1
fi

# --- Threads / OS -----------------------------------------------------------
if [[ "$(uname -s)" != "Linux" && "$(uname -s)" != "Darwin" ]]; then
    echo "  [warn] $(uname -s) detected - Linux is the tested platform (Windows via MSVC also CI-tested)"
fi
ok "cores : $(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo '?')"

# --- Optional: comparison allocators ----------------------------------------
for so in /usr/lib/x86_64-linux-gnu/libjemalloc.so.2 /lib/x86_64-linux-gnu/libjemalloc.so.2; do
    [[ -f "$so" ]] && ok "jemalloc found: $so (cross-allocator benchmark)" && break
done
[[ -f /usr/lib/x86_64-linux-gnu/libmimalloc.so.2 ]] && ok "mimalloc found (cross-allocator benchmark)"

echo "======================================================================="
if [[ $fail -eq 1 ]]; then
    red "Some REQUIRED tools are missing. Install them, e.g.:"
    echo "  Debian/Ubuntu : sudo apt install -y build-essential cmake python3 libjemalloc2"
    echo "  any pip env   : pip3 install cmake ninja"
    exit 1
fi
green "All required prerequisites are satisfied. Next: bash 01_build.sh"
