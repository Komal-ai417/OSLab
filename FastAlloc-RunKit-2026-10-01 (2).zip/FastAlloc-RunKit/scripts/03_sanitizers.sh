#!/usr/bin/env bash
# ============================================================================
# 03_sanitizers.sh — run the test suite under the FULL sanitizer matrix
# ----------------------------------------------------------------------------
# Usage:   bash 03_sanitizers.sh [path/to/FastAlloc]
#
#   build-asan : AddressSanitizer + UndefinedBehaviorSanitizer
#                -> heap overflow / UAF / double-free / UB traps
#   build-tsan : ThreadSanitizer  -> data races in the lock-free paths
#   build-lsan : LeakSanitizer    -> leaks across the whole test suite
#
# Any sanitizer finding = non-zero exit + diagnostic dump. All green = clean.
#
# TSan + modern kernels (rev 3): libtsan runtimes shipped with GCC<=13 /
# clang<=17 reject the high-entropy address layouts produced by kernels with
# vm.mmap_rnd_bits > 28 and die BEFORE main() with
#   "FATAL: ThreadSanitizer: unexpected memory mapping 0x...-0x..."
# That is a toolchain/kernel incompatibility, NOT a FastAlloc defect (the same
# binaries run clean natively and under ASan/UBSan on the same machine, and
# TSan is clean with GCC>=14 / clang>=18 runtimes). Which processes lose the
# ASLR lottery differs on every boot, so a suite that passed yesterday can
# FATAL today. This script therefore runs every TSan binary with ASLR disabled
# for that process only (`setarch <arch> -R`, personality ADDR_NO_RANDOMIZE,
# inherited by child processes, no root required, harmless for modern
# runtimes). System-wide alternative where /proc/sys is WRITABLE:
#   sysctl -w vm.mmap_rnd_bits=28
# (NOT available inside containers — Colab, Docker etc. mount /proc/sys
# read-only; there the setarch route is the only option).
#
# rev 4: runs now STREAM per-test progress live — the gtest [ RUN ] / [ OK ]
# lines and any sanitizer finding print as they happen, and each run reports
# its elapsed time. (rev 3 buffered output quietly, so a multi-minute TSan
# audit leg on a small VM looked exactly like a hang — field report from a
# 2-core box.) TSan legs print a heads-up about the slow heavy cases.
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"

hdr() { echo -e "\n\033[1;35m================ $* ================\033[0m"; }

# Command prefix that disables ASLR for one process tree (see header comment).
TSAN_PREFIX=()
if command -v setarch >/dev/null 2>&1; then
    TSAN_PREFIX=(setarch "$(uname -m)" -R)
    echo -e "\033[1;33mnote:\033[0m TSan binaries run under 'setarch $(uname -m) -R' (per-process ASLR"
    echo "      off) — shields old libtsan runtimes from high-ASLR kernels (RUNBOOK §10)."
else
    echo -e "\033[1;33mwarning:\033[0m 'setarch' not found. If the TSan leg dies with"
    echo "         'unexpected memory mapping', run: sudo sysctl -w vm.mmap_rnd_bits=28"
    echo "         (bare metal / full VMs only — containers have read-only /proc/sys)"
    echo "         or install util-linux — see RUNBOOK §10."
fi

# Live view: GNU grep streams line-buffered; BusyBox grep (no --line-buffered)
# falls back to quiet buffering with the full log still kept on failure.
SAN_VIEW_RE='^\[ +(RUN|OK|FAILED|PASSED|SKIPPED)|^\[=|FATAL|ERROR:|runtime error:|SUMMARY: (Address|Thread|Leak)Sanitizer'
LIVE_GREP=0
echo x | grep --line-buffered -q x >/dev/null 2>&1 && LIVE_GREP=1

san_exec() {  # san_exec <logfile> <cmd...> — run cmd, tee to log, live-filter
    local log="$1"; shift
    local rc=0
    if [[ $LIVE_GREP -eq 1 ]]; then
        "$@" 2>&1 | tee "$log" \
            | { grep --line-buffered -E "$SAN_VIEW_RE" || :; } || rc=$?
    else
        "$@" 2>&1 | tee "$log" || rc=$?
        tail -4 "$log"
    fi
    return $rc
}

san_run() {  # san_run <build-dir> <binary-relpath>
    local dir="$1" rel="$2"
    if [[ ! -x "$REPO/$dir/$rel" ]]; then
        echo "binary missing ($dir/$rel) - run 01_build.sh first"; exit 1
    fi
    # Per-process ASLR off for TSan legs only (see header comment).
    local -a pre=()
    if [[ "$dir" == build-tsan && ${#TSAN_PREFIX[@]} -gt 0 ]]; then
        pre=("${TSAN_PREFIX[@]}")
    fi
    local log rc=0 t0=$SECONDS
    log=$(mktemp /tmp/fastalloc-san.XXXXXX.log)
    # allocator_may_return_null=1: sanitizer allocator in libc-compatible
    # mode (the differential tests probe libc's overflow-fails-cleanly
    # contract; without this flag ASan/TSan/LSan abort the process instead
    # of returning nullptr). Mirrors the audit-evidence methodology and the
    # compiled-in defaults from tests/sanitizer_defaults.cpp.
    # Output streams LIVE (per-test [ RUN ]/[ OK ] + findings) while the full
    # log is kept for the failure path — a multi-minute TSan leg must never
    # look like a hang (rev 4).
    san_exec "$log" env \
        ASAN_OPTIONS=detect_leaks=1:abort_on_error=1:allocator_may_return_null=1 \
        UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1 \
        TSAN_OPTIONS=halt_on_error=1:allocator_may_return_null=1 \
        ${pre[@]+"${pre[@]}"} "$REPO/$dir/$rel" || rc=$?
    if [[ $rc -ne 0 ]]; then
        tail -25 "$log"
        echo
        echo -e "\033[1;31mFAILED (exit $rc) - $dir/$rel; full output kept at: $log\033[0m"
        if grep -q "unexpected memory mapping" "$log"; then
            cat <<EOF

That FATAL is the known libtsan-vs-high-ASLR-kernel issue (kernels with
vm.mmap_rnd_bits > 28 + GCC<=13 / clang<=17 runtimes) — NOT a FastAlloc
defect. Remedies, pick one:
  1. let this script wrap the run in 'setarch $(uname -m) -R' (it does so
     automatically when the 'util-linux' package is installed), or
  2. run it by hand:  setarch $(uname -m) -R $REPO/$dir/$rel
  3. system-wide, as root: sysctl -w vm.mmap_rnd_bits=28 — ONLY works where
     /proc/sys is writable (bare metal / full VMs). In containers (Colab,
     Docker...) it is read-only ("setting key ...: Read-only file system")
     and CANNOT be changed from inside — use 1 or 2 there.
Durable fix: a GCC>=14 or clang>=18 toolchain (new libtsan tolerates the
layouts). Details: RUNBOOK §10.
EOF
        fi
        exit 1
    fi
    echo -e "\033[1;32m--> $dir/$rel green in $((SECONDS - t0)) s\033[0m"
    rm -f "$log"
}

run_san() {  # run_san <dir> <label>
    local dir="$1" label="$2"
    hdr "$label"
    if [[ "$dir" == build-tsan ]]; then
        echo "(heads-up: TSan runs 10-20x slower than native. On small VMs the heavy"
        echo " concurrency cases (audit suite, e.g. ThreadCountSweep1to128) can take"
        echo " minutes each. The [ RUN ] / [ OK ] lines below stream LIVE — a long"
        echo " silence while one heavy case runs is normal; 'top' shows the CPU"
        echo " working if you want proof.)"
    fi
    san_run "$dir" fast_alloc_tests
    # Audit trees (2026-10-01 deliverable): run the audit suite under the
    # same sanitizer environment -- these builds are release semantics, so
    # the audit binary is fully in-scope here (49 more cases).
    if [[ -x "$REPO/$dir/tests/audit/fast_alloc_audit_tests" ]]; then
        echo "--- audit suite (49 cases) ---"
        san_run "$dir" tests/audit/fast_alloc_audit_tests
    fi
}

run_san build-asan "AddressSanitizer + UBSan (memory errors + undefined behaviour)"
run_san build-tsan "ThreadSanitizer   (data races)"
run_san build-lsan "LeakSanitizer     (memory leaks)"

echo -e "\n\033[1;32mExpected: every suite green in every sanitizer build (75 cases, or 75+49 on audit trees), zero findings.\033[0m"
echo "Next: bash 04_benchmarks.sh"
