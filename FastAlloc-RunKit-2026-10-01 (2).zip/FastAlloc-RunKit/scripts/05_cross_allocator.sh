#!/usr/bin/env bash
# ============================================================================
# 05_cross_allocator.sh — FastAlloc vs glibc / jemalloc / mimalloc, honestly
# ----------------------------------------------------------------------------
# Usage:   bash 05_cross_allocator.sh [path/to/FastAlloc] [--quick]
#
# Methodology (what makes this comparison trustworthy):
#   * ONE allocator per process (no cross-contamination of caches/RSS)
#   * glibc baseline      : plain run
#   * jemalloc/mimalloc   : same binary, LD_PRELOAD=<lib>
#   * every cell: warmup + 3 reps (median taken by analyzer)
#   * every freed block is checksum-verified
#   * results land in one JSONL -> analyze.py renders win/loss tables
# ----------------------------------------------------------------------------
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"
shift 2>/dev/null || true
[[ "${1:-}" == "--quick" ]] && WLS="tiny churn large" || WLS="tiny small-mixed random-1-4096 ramp churn cache-thrash cross-thread thread-churn large realloc-grow overhead"

BENCH="$REPO/build/bench_suite"
[[ -x "$BENCH" ]] || { echo "missing $BENCH - run 01_build.sh"; exit 1; }

JEM="${JEMALLOC_SO:-}"
MI="${MIMALLOC_SO:-}"
for so in /usr/lib/x86_64-linux-gnu/libjemalloc.so.2 /lib/x86_64-linux-gnu/libjemalloc.so.2; do
    [[ -z "$JEM" && -f "$so" ]] && JEM="$so"
done
for so in /usr/lib/x86_64-linux-gnu/libmimalloc.so.2 /usr/local/lib/libmimalloc.so.2; do
    [[ -z "$MI" && -f "$so" ]] && MI="$so"
done

OUT="$REPO/cross_allocator_results.jsonl"
rm -f "$OUT"
THREADS="${THREADS:-1 2 4}"

run_cell() {  # run_cell <env-prefix> <alloc> <label> <workload> <threads>
    local envp="$1" alloc="$2" label="$3" w="$4" t="$5"
    printf '%-26s %-14s T=%-2s : ' "$w" "$label" "$t"
    # shellcheck disable=SC2086
    env $envp "$BENCH" --alloc "$alloc" --label "$label" --workload "$w" \
        --threads "$t" --reps 3 --json "$OUT" 2>/dev/null | grep -E "median" | tail -1 || echo "(failed)"
}

for w in $WLS; do
    for t in $THREADS; do
        run_cell ""                        std  glibc     "$w" "$t"
        run_cell ""                        fast FastAlloc "$w" "$t"
        [[ -n "$JEM" ]] && run_cell "LD_PRELOAD=$JEM" std  jemalloc  "$w" "$t"
        [[ -n "$MI" ]] && run_cell "LD_PRELOAD=$MI" std  mimalloc  "$w" "$t"
    done
done

echo -e "\n\033[1;32mResults: $OUT\033[0m  — rendering win/loss tables:"
python3 "$REPO/benchmarks/benchsuite/analyze.py" "$OUT" | tee "$REPO/cross_allocator_report.md"

echo -e "\nONE-SHOT ALTERNATIVE (drives everything incl. gbench + memory bench):"
echo "  python3 $REPO/benchmarks/benchsuite/bench_compare.py --quick          # smoke"
echo "  python3 $REPO/benchmarks/benchsuite/bench_compare.py --reps 5 --threads 1,2,4"
