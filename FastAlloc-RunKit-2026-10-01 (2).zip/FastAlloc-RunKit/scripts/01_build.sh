#!/usr/bin/env bash
# ============================================================================
# 01_build.sh — build EVERY useful configuration of FastAlloc
# ----------------------------------------------------------------------------
# Usage:   bash 01_build.sh [path/to/FastAlloc]     (default: ./FastAlloc or \$PWD)
#
# Creates (inside the repo):
#   build/        Release      -O3 + LTO             -> tests + all benchmarks
#   build-dbg/    +FASTALLOC_DEBUG  canaries/red-zones/poison/registry/leak-dump
#   build-asan/   AddressSanitizer + UBSan
#   build-tsan/   ThreadSanitizer
#   build-lsan/   LeakSanitizer
#   build-override/ +FASTALLOC_OVERRIDE_NEW  (global new/delete routed to FastAlloc)
#
# First configure downloads Google Test v1.14.0 + Google Benchmark v1.9.4
# via FetchContent (needs internet once).
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"
[[ -f "$REPO/CMakeLists.txt" ]] || { echo "error: $REPO is not the FastAlloc repo (no CMakeLists.txt)"; exit 1; }

GEN=()
command -v ninja >/dev/null 2>&1 && GEN=(-G Ninja -DCMAKE_MAKE_PROGRAM="$(command -v ninja)")
JOBS=$(( $(nproc 2>/dev/null || echo 4) ))

cfg() {  # cfg <dir> <extra cmake args...>
    local dir="$1"; shift
    echo -e "\n\033[1;36m==> Configuring $REPO/$dir $*\033[0m"
    cmake -S "$REPO" -B "$REPO/$dir" -DCMAKE_BUILD_TYPE=Release "${GEN[@]}" "$@"
}

bld() {  # bld <dir> [target...]
    local dir="$1"; shift
    echo -e "\n\033[1;36m==> Building $dir (target: ${*:-all})\033[0m"
    cmake --build "$REPO/$dir" -j"$JOBS" "$@"
}

# Test targets: trees carrying the audit suite (tests/audit/, i.e. the
# 2026-10-01 audit deliverable) have a SECOND gtest binary -- build BOTH
# wherever tests are built, or ctest will report fast_alloc_audit_tests as
# "Not Run" (the entry is registered whenever FASTALLOC_BUILD_TESTS=ON).
# Pristine upstream + RunKit patch trees fall back to the single binary.
TEST_TARGETS=(fast_alloc_tests)
if [[ -f "$REPO/tests/audit/CMakeLists.txt" ]]; then
    TEST_TARGETS+=(fast_alloc_audit_tests)
fi

# 1) Release — tests + every benchmark binary
cfg build
bld build

# 2) Debug instrumentation — canaries, red zones, freed-block poisoning,
#    exact allocation registry, double-free/invalid-free detection, leak dump
#    (audit trees: the audit binary is BUILT here but intentionally NOT
#    registered in ctest under FASTALLOC_DEBUG — its heavy tiers are
#    release-semantics calibrated; `ctest --test-dir build-dbg` runs the
#    validate suite only, by design)
cfg build-dbg -DFASTALLOC_DEBUG=ON
bld build-dbg --target "${TEST_TARGETS[@]}"

# 3) Sanitizer matrix (release semantics: both suites registered in ctest)
cfg build-asan -DFASTALLOC_SANITIZE=address,undefined
bld build-asan --target "${TEST_TARGETS[@]}"

cfg build-tsan -DFASTALLOC_SANITIZE=thread
bld build-tsan --target "${TEST_TARGETS[@]}"

cfg build-lsan -DFASTALLOC_SANITIZE=leak
bld build-lsan --target "${TEST_TARGETS[@]}"

# 4) Global new/delete override build (for the "route my whole app" pattern)
cfg build-override -DFASTALLOC_OVERRIDE_NEW=ON
bld build-override --target fast_alloc

echo -e "\n\033[1;32mAll builds finished. Artifacts:\033[0m"
ls -1 "$REPO"/build*/fast_alloc_tests "$REPO"/build*/tests/audit/fast_alloc_audit_tests \
      "$REPO"/build/bench_suite \
      "$REPO"/build/fast_alloc_bench* "$REPO"/build/libfast_alloc.a 2>/dev/null
echo -e "\nNext: bash 02_test_correctness.sh"
