# FastAlloc RunKit

**Everything you need to run, test, verify and USE [FastAlloc](https://github.com/Komal-ai417/FastAlloc)
on your own machine — plus 5 real-world usage examples and 2 bug fixes with patches.**

> **2026-10-01 rev 2 — audit-tree compatibility.** The build/test scripts are now
> tree-aware and work against BOTH targets:
> (a) pristine upstream `c10af3b` + this kit's patch (original mode, 75/86 cases), and
> (b) the 2026-10-01 audit deliverable tree, which adds a second gtest binary
> (`fast_alloc_audit_tests`, 49 cases) — `01_build.sh` now builds it in every
> test configuration so `ctest` never reports it "Not Run", and `03_sanitizers.sh`
> runs it under the full sanitizer matrix. On audit trees, `ctest --test-dir build-dbg`
> runs the validate suite only (the audit suite is deliberately not registered under
> `FASTALLOC_DEBUG`; run its binary directly if you want it there: 46 pass + 3 skip).

> **2026-10-01 rev 3 — TSan hardened after a second field report.** On kernels with
> `vm.mmap_rnd_bits > 28` (Ubuntu 24.04-era defaults), the libtsan runtime shipped
> with GCC<=13 / clang<=17 can die before `main()` with
> `FATAL: ThreadSanitizer: unexpected memory mapping` — a toolchain issue, not a
> FastAlloc defect, and randomly per-process (one binary passes, the next FATALs).
> `03_sanitizers.sh` now runs every TSan binary with per-process ASLR disabled
> (`setarch -R`, no root needed) and, if it still trips, prints the exact remedy
> (RUNBOOK §10). `02_test_correctness.sh` also now states explicitly that the
> override build has NO test binary by design — verify that path with
> `make ex02_override` instead.

Every command and every example in this kit was executed and verified end-to-end
on Linux (g++ 14.2, CMake 4.4): 75/75 release tests, 86-case debug suite,
ASan+UBSan / TSan / LSan all clean, all 4 benchmark binaries, cross-allocator
matrix vs glibc/jemalloc, and 500/500 concurrent requests through the example
TCP server.

```
FastAlloc-RunKit/
├── README.md                  <- you are here
├── RUNBOOK.md                 <- EVERY command, organized by task (start here)
├── patches/
│   └── 0001-fix-override-new-bootstrap-and-stats.patch
│                              <- 2 real bugs found by this audit:
│                                 OVR-1: global new/delete override crashed on
│                                 first allocation (recursive magic-static init)
│                                 STAT-1: release stats missed sized frees
├── scripts/                   <- one command per task (bash <script>)
│   ├── 00_prereqs.sh          verify toolchain
│   ├── 01_build.sh            build all 6 configurations
│   ├── 02_test_correctness.sh 75 + 86 test suites
│   ├── 03_sanitizers.sh       ASan+UBSan / TSan / LSan
│   ├── 04_benchmarks.sh       all 4 benchmark binaries
│   ├── 05_cross_allocator.sh  vs glibc / jemalloc / mimalloc + win/loss tables
│   ├── 06_memory_footprint.sh RSS retention proof
│   └── run_everything.sh      the full battery in one command
└── examples/                  <- real-world usage code (all compile & run)
    ├── 01_basic_api.cpp       the complete C++ API tour
    ├── 02_new_delete_override.cpp   route your WHOLE app through FastAlloc
    ├── 03_stl_allocator.cpp + fast_stl_allocator.h
    │                          std::vector / std::map / std::string on FastAlloc
    ├── 04_multithreaded_server.cpp
    │                          real threaded TCP server (pool, buffers, watchdog)
    ├── 05_c_usage.c + fast_alloc_c.{h,cpp}
    │                          pure C / FFI via extern "C" shim
    ├── CMakeLists.txt         3 ways to integrate FastAlloc into your project
    └── Makefile               build all 5 examples in one make
```

## Quick start (3 commands)

```bash
git clone https://github.com/Komal-ai417/FastAlloc.git
cd FastAlloc && git apply ../FastAlloc-RunKit/patches/0001-fix-override-new-bootstrap-and-stats.patch
bash ../FastAlloc-RunKit/scripts/run_everything.sh     # full battery, ~25-40 min
```

Impatient? Read `RUNBOOK.md` — it has every individual command with expected
output, so you can run exactly the piece you care about.

## The two bugs this kit found (and fixes)

1. **OVR-1 (critical)**: building with `-DFASTALLOC_OVERRIDE_NEW=ON` — the
   README's advertised "route all new/delete through FastAlloc" feature —
   aborted with `__gnu_cxx::recursive_init_error` on the program's FIRST
   allocation. Three internal singletons bootstrapped via `new`, which under
   the override re-entered the allocator before it existed. Fixed with
   placement-new into static storage (3 files, ~20 lines).
2. **STAT-1 (diagnostics)**: `fast_free_sized()` never updated the free
   counters, so `fast_alloc_stats()` in release builds showed fake
   ever-growing "live" counts for apps using sized deletes (including the
   override path). Memory was always freed correctly — only the stats lied.
   Fixed; A/B benchmarked as performance-neutral.

Both fixes pass the full regression: Release 75/75, Debug 85+1-skip-by-design,
ASan+UBSan 75/75, TSan 75/75 (zero races), LSan 75/75 (zero leaks).

## What FastAlloc is good at (measured by this kit + repo's own honest report)

- small-block pair workloads at every thread count (1.24–2.98x vs glibc)
- best p50/p99 tail latency of glibc / jemalloc / mimalloc / FastAlloc
- returning memory to the OS: ~2.9x/10.7x/34.5x less retained RSS than
  glibc/jemalloc/mimalloc after freeing 1M objects and purging
- NOT fastest for: realloc-heavy code, ramp vs mimalloc, bulk free storms —
  run §4.4 of the RUNBOOK and see the verdict on YOUR hardware
