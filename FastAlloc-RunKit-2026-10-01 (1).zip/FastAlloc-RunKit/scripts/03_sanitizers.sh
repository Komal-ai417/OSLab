#!/usr/bin/env bash
# ============================================================================
# 03_sanitizers.sh — run the test suite under the FULL sanitizer matrix
# ----------------------------------------------------------------------------
# Usage:   bash 03_sanitizers.sh [path/to/FastAlloc]
#
#   build-asan : AddressSanitizer + UndefinedBehaviorSanitizer
#                -> heap overflow / UAF / double-free / UB traps
#   build-tsan : ThreadSanitizer  -> data races in the lock-free paths
#   build-lsan : LeakSanitizer    -> leaks across the whole test suite
#
# Any sanitizer finding = non-zero exit + diagnostic dump. All green = clean.
#
# TSan + modern kernels (rev 3): libtsan runtimes shipped with GCC<=13 /
# clang<=17 reject the high-entropy address layouts produced by kernels with
# vm.mmap_rnd_bits > 28 and die BEFORE main() with
#   "FATAL: ThreadSanitizer: unexpected memory mapping 0x...-0x..."
# That is a toolchain/kernel incompatibility, NOT a FastAlloc defect (the same
# binaries run clean natively and under ASan/UBSan on the same machine, and
# TSan is clean with GCC>=14 / clang>=18 runtimes). Which processes lose the
# ASLR lottery differs on every boot, so a suite that passed yesterday can
# FATAL today. This script therefore runs every TSan binary with ASLR disabled
# for that process only (`setarch <arch> -R`, personality ADDR_NO_RANDOMIZE,
# inherited by child processes, no root required, harmless for modern
# runtimes). System-wide alternative: `sysctl -w vm.mmap_rnd_bits=28`.
# ============================================================================
set -euo pipefail

REPO="${1:-${FASTALLOC_DIR:-$(ls -d ./FastAlloc 2>/dev/null || echo .)}}"

hdr() { echo -e "\n\033[1;35m================ $* ================\033[0m"; }

# Command prefix that disables ASLR for one process tree (see header comment).
TSAN_PREFIX=()
if command -v setarch >/dev/null 2>&1; then
    TSAN_PREFIX=(setarch "$(uname -m)" -R)
    echo -e "\033[1;33mnote:\033[0m TSan binaries run under 'setarch $(uname -m) -R' (per-process ASLR"
    echo "      off) — shields old libtsan runtimes from high-ASLR kernels (RUNBOOK §10)."
else
    echo -e "\033[1;33mwarning:\033[0m 'setarch' not found. If the TSan leg dies with"
    echo "         'unexpected memory mapping', run: sudo sysctl -w vm.mmap_rnd_bits=28"
    echo "         (or install util-linux) — see RUNBOOK §10."
fi

san_run() {  # san_run <build-dir> <binary-relpath>
    local dir="$1" rel="$2"
    if [[ ! -x "$REPO/$dir/$rel" ]]; then
        echo "binary missing ($dir/$rel) - run 01_build.sh first"; exit 1
    fi
    # Per-process ASLR off for TSan legs only (see header comment).
    local -a pre=()
    if [[ "$dir" == build-tsan && ${#TSAN_PREFIX[@]} -gt 0 ]]; then
        pre=("${TSAN_PREFIX[@]}")
    fi
    local log rc=0
    log=$(mktemp /tmp/fastalloc-san.XXXXXX.log)
    # allocator_may_return_null=1: sanitizer allocator in libc-compatible
    # mode (the differential tests probe libc's overflow-fails-cleanly
    # contract; without this flag ASan/TSan/LSan abort the process instead
    # of returning nullptr). Mirrors the audit-evidence methodology and the
    # compiled-in defaults from tests/sanitizer_defaults.cpp.
    ASAN_OPTIONS=detect_leaks=1:abort_on_error=1:allocator_may_return_null=1 \
    UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1 \
    TSAN_OPTIONS=halt_on_error=1:allocator_may_return_null=1 \
        ${pre[@]+"${pre[@]}"} "$REPO/$dir/$rel" >"$log" 2>&1 || rc=$?
    if [[ $rc -ne 0 ]]; then
        tail -6 "$log"
        echo
        echo -e "\033[1;31mFAILED (exit $rc) - $dir/$rel; full output kept at: $log\033[0m"
        if grep -q "unexpected memory mapping" "$log"; then
            cat <<EOF

That FATAL is the known libtsan-vs-high-ASLR-kernel issue (kernels with
vm.mmap_rnd_bits > 28 + GCC<=13 / clang<=17 runtimes) — NOT a FastAlloc
defect. Remedies, pick one:
  1. install 'util-linux' so this script can wrap the run in
     'setarch $(uname -m) -R' (it should have done so automatically), or
  2. system-wide, as root:  sysctl -w vm.mmap_rnd_bits=28
     (persist: echo vm.mmap_rnd_bits=28 > /etc/sysctl.d/99-tsan.conf), or
  3. run it by hand:  setarch $(uname -m) -R $REPO/$dir/$rel
Durable fix: a GCC>=14 or clang>=18 toolchain (new libtsan tolerates the
layouts). Details: RUNBOOK §10.
EOF
        fi
        exit 1
    fi
    tail -4 "$log"
    rm -f "$log"
}

run_san() {  # run_san <dir> <label>
    local dir="$1" label="$2"
    hdr "$label"
    san_run "$dir" fast_alloc_tests
    # Audit trees (2026-10-01 deliverable): run the audit suite under the
    # same sanitizer environment -- these builds are release semantics, so
    # the audit binary is fully in-scope here (49 more cases).
    if [[ -x "$REPO/$dir/tests/audit/fast_alloc_audit_tests" ]]; then
        echo "--- audit suite (49 cases) ---"
        san_run "$dir" tests/audit/fast_alloc_audit_tests
    fi
}

run_san build-asan "AddressSanitizer + UBSan (memory errors + undefined behaviour)"
run_san build-tsan "ThreadSanitizer   (data races)"
run_san build-lsan "LeakSanitizer     (memory leaks)"

echo -e "\n\033[1;32mExpected: every suite green in every sanitizer build (75 cases, or 75+49 on audit trees), zero findings.\033[0m"
echo "Next: bash 04_benchmarks.sh"
