# FastAlloc RUNBOOK — every command to build, test, verify and benchmark

Every command below was **executed and verified** on Linux (g++ 14.2, CMake 4.4, 2-core VM).
Copy-paste ready. `$REPO` = your FastAlloc checkout.

> **FIRST — apply the audit patch.** This kit found and fixed 2 real bugs (details in
> §9). Without the patch, the `FASTALLOC_OVERRIDE_NEW` feature (§7.2) **aborts on the
> first allocation**, and release-mode stats lie when you use sized frees.
>
> ```bash
> cd FastAlloc
> git apply /path/to/FastAlloc-RunKit/patches/0001-fix-override-new-bootstrap-and-stats.patch
> ```

---

## 0. One-time setup

```bash
git clone https://github.com/Komal-ai417/FastAlloc.git
cd FastAlloc
git apply ../FastAlloc-RunKit/patches/0001-fix-override-new-bootstrap-and-stats.patch

# prerequisites: C++17 compiler, CMake >= 3.15, python3
sudo apt install -y build-essential cmake python3 libjemalloc2   # Debian/Ubuntu
# (or: pip3 install cmake ninja)

bash ../FastAlloc-RunKit/scripts/00_prereqs.sh                  # verify everything
```

First `cmake` configure downloads Google Test v1.14.0 + Google Benchmark v1.9.4
via FetchContent — needs internet **once**.

---

## 1. Build — every configuration

```bash
REPO=$PWD   # run from the FastAlloc repo root

# 1a. Release (tests + all 4 benchmark binaries)  -> build/
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)

# 1b. Debug instrumentation (canaries, red zones, freed-block poison,
#     exact allocation registry, double-free/invalid-free detection, leak dump)
#     -> build-dbg/
#     (audit trees: build BOTH test binaries; ctest in build-dbg intentionally
#      registers only the validate suite under FASTALLOC_DEBUG)
cmake -B build-dbg -DFASTALLOC_DEBUG=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-dbg -j$(nproc) --target fast_alloc_tests fast_alloc_audit_tests

# 1c. Global new/delete override build  -> build-override/   (PATCH REQUIRED)
cmake -B build-override -DFASTALLOC_OVERRIDE_NEW=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-override -j$(nproc) --target fast_alloc

# 1d. Sanitizer builds (see §3)
#     (audit trees: both binaries -- release semantics, both suites in ctest)
cmake -B build-asan -DFASTALLOC_SANITIZE=address,undefined -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake -B build-tsan -DFASTALLOC_SANITIZE=thread           -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake -B build-lsan -DFASTALLOC_SANITIZE=leak             -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build-asan -j$(nproc) --target fast_alloc_tests fast_alloc_audit_tests
cmake --build build-tsan -j$(nproc) --target fast_alloc_tests fast_alloc_audit_tests
cmake --build build-lsan -j$(nproc) --target fast_alloc_tests fast_alloc_audit_tests
```

Or all of the above in one command:

```bash
bash ../FastAlloc-RunKit/scripts/01_build.sh          # builds ALL six configs
```

**Artifacts produced**

| Path | What it is |
|---|---|
| `build/libfast_alloc.a` | the library (Release, LTO) |
| `build/fast_alloc_tests` | 75-case gtest binary |
| `build-dbg/fast_alloc_tests` | 86-case gtest binary (instrumented) |
| `build/fast_alloc_bench` | Google-Benchmark micro suite (30 configs) |
| `build/fast_alloc_bench_extended` | extended suite (62 configs) |
| `build/fast_alloc_bench_memory` | time + peak-RSS stress vs std::malloc |
| `build/bench_suite` | 11-workload cross-allocator suite |
| `build-override/libfast_alloc.a` | library with global new/delete override |

**CMake knobs**: `FASTALLOC_BUILD_TESTS`, `FASTALLOC_BUILD_BENCHMARKS`,
`FASTALLOC_DEBUG`, `FASTALLOC_OVERRIDE_NEW`,
`FASTALLOC_SANITIZE=address|thread|leak|undefined|address,undefined`.

---

## 2. Correctness tests

```bash
# via ctest (any config)
ctest --test-dir build --output-on-failure -V
ctest --test-dir build-dbg --output-on-failure -V

# or run the binary directly to see per-test output
./build/fast_alloc_tests
./build/fast_alloc_tests --gtest_list_tests                  # list all 75
./build/fast_alloc_tests --gtest_filter='ApiTest.*'          # one suite
./build/fast_alloc_tests --gtest_filter='*MallocZero*'       # one test
./build/fast_alloc_tests --gtest_repeat=10                   # hunt flakes
./build-dbg/fast_alloc_tests                                 # 86, incl. death tests
```

**Verified expected output** (this kit's run, g++ 14.2):

```
Release : [  PASSED  ] 75 tests.                     # 5.4 s
Debug   : 86 tests: 85 passed, 1 SKIPPED by design    # 6.5 s
          (ApiTest.FreeWithCorruptLargeHeaderIsDroppedNotCached —
           needs a corrupted-header injection environment)
```

Or: `bash ../FastAlloc-RunKit/scripts/02_test_correctness.sh`

What the suite covers (9 suites): API semantics incl. zero-size/OOM contracts,
size-class boundaries, large/mremap blocks, alignment, MPSC concurrency,
thread-exit flush, OOM-injection via test seam, debug-aids (canaries/poison/
double-free/leak dump), and 8-thread stress churn.

---

## 3. Sanitizers — memory safety, races, leaks

```bash
# Address + Undefined (heap overflow / UAF / UB) — ~45 s
./build-asan/fast_alloc_tests

# Threads (data races in the lock-free paths) — ~67 s
./build-tsan/fast_alloc_tests

# Leaks
./build-lsan/fast_alloc_tests

# harder settings for any of them:
ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 ./build-asan/fast_alloc_tests
UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=1 ./build-asan/fast_alloc_tests
TSAN_OPTIONS=halt_on_error=1 ./build-tsan/fast_alloc_tests
```

**Verified**: 75/75 passed under ASan+UBSan, TSan (zero races), LSan (zero leaks).

Or: `bash ../FastAlloc-RunKit/scripts/03_sanitizers.sh`

> **TSan on modern kernels**: kernels with `vm.mmap_rnd_bits > 28` (Ubuntu
> 24.04-era defaults) make the libtsan runtime from GCC<=13 / clang<=17 die
> BEFORE `main()` with `FATAL: ThreadSanitizer: unexpected memory mapping` —
> a toolchain issue, not a FastAlloc defect (and per-process random: a run
> that survived yesterday can FATAL today). `03_sanitizers.sh` handles it
> automatically by wrapping every TSan binary in `setarch $(uname -m) -R`
> (per-process ASLR off, no root). Manual equivalents in §10.

Sanitize YOUR OWN program (not just the test suite):

```bash
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -Iinclude my_app.cpp \
    build/libfast_alloc.a -pthread -o my_app_asan && ./my_app_asan
```

---

## 4. Benchmarks — every binary

### 4.1 Google-Benchmark micro suites (in-process, std vs FastAlloc)

```bash
./build/fast_alloc_bench --benchmark_list_tests          # see all 30
./build/fast_alloc_bench --benchmark_min_time=3000x      # CI default: 3000 iters
./build/fast_alloc_bench --benchmark_filter='BM_MallocFree_FastAlloc/64/threads:1'
./build/fast_alloc_bench --benchmark_report_aggregates_only=true

./build/fast_alloc_bench_extended --benchmark_min_time=3000x
# MallocOnly / FreeOnly / RandomSize / ScopedAlloc / LargeAlloc / Realloc /
# Calloc / HeavyContention — 62 configs
./build/fast_alloc_bench_extended --benchmark_filter='Realloc' --benchmark_min_time=3000x
```

### 4.2 Memory stress — time + peak RSS, side by side

```bash
./build/fast_alloc_bench_memory --threads 4 --allocs 20000 --size 4096
# knobs: --threads N --allocs N --size BYTES
```

### 4.3 Cross-allocator workloads (one allocator per process)

```bash
./build/bench_suite --help            # all flags
WLS="tiny small-mixed random-1-4096 ramp churn cache-thrash cross-thread thread-churn large realloc-grow overhead"

# FastAlloc
./build/bench_suite --alloc fast --label FastAlloc --workload churn --threads 4 \
    --reps 5 --json results.jsonl

# glibc baseline (plain run)
./build/bench_suite --alloc std --label glibc --workload churn --threads 4 \
    --reps 5 --json results.jsonl

# jemalloc / mimalloc via LD_PRELOAD (same binary!)
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libjemalloc.so.2 \
    ./build/bench_suite --alloc std --label jemalloc --workload churn \
    --threads 4 --reps 5 --json results.jsonl

# render the win/loss tables
python3 benchmarks/benchsuite/analyze.py results.jsonl
```

Or the driver that runs the whole matrix: `bash ../FastAlloc-RunKit/scripts/05_cross_allocator.sh`

### 4.4 ONE command — everything + verdict report

```bash
# full: micro suites + cross-allocator matrix + memory bench + win/loss verdict
python3 benchmarks/benchsuite/bench_compare.py --reps 5 --threads 1,2,4

# quick smoke preset (~2 min)
python3 benchmarks/benchsuite/bench_compare.py --quick

# chunk long sessions
python3 benchmarks/benchsuite/bench_compare.py --workloads churn,tiny --suite-skip-run
# writes bench_report.md + bench_report_data.json + raw JSONL
```

**Reading the numbers honestly** (re-measured on this kit's 2-vCPU VM,
median of 3, one allocator per process): FastAlloc beat glibc on churn T=2
(120.5 vs 162.2 ns/op), jemalloc won that cell (96.0). Full win/loss tables
depend on machine — that's why §4.4 exists. The repo's own honest numbers
(docs/performance_report.md): wins 20/33 cells vs glibc, best-in-class p50/p99
latency and RSS retention; loses on realloc-heavy and ramp vs mimalloc.

Or: `bash ../FastAlloc-RunKit/scripts/04_benchmarks.sh [--quick]`

---

## 5. Memory-footprint verification (the headline claim)

Claim: after freeing 1M objects + `fast_alloc_purge()`, FastAlloc retains
~16 MB vs glibc 46.7 / jemalloc 171.8 / mimalloc 552.2 MB.

```bash
./build/bench_suite --alloc fast --label FastAlloc --workload ramp --threads 1 --reps 1 --json mem.jsonl
./build/bench_suite --alloc std  --label glibc     --workload ramp --threads 1 --reps 1 --json mem.jsonl
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libjemalloc.so.2 \
  ./build/bench_suite --alloc std --label jemalloc --workload ramp --threads 1 --reps 1 --json mem.jsonl
python3 - <<'EOF'
import json
for line in open("mem.jsonl"):
    d = json.loads(line); r = d["reps"][0]
    print(f'{d["label"]:<10} peak {r["rss_peak_mb"]:>7.1f} MB  '
          f'after-free {r.get("retained_after_free_mb",-1):>7.1f} MB  '
          f'after-purge {r.get("retained_after_purge_mb",-1):>7.1f} MB')
EOF

./build/fast_alloc_bench_memory --threads 4 --allocs 100000 --size 512
```

Or: `bash ../FastAlloc-RunKit/scripts/06_memory_footprint.sh`

Your absolute numbers WILL differ (kernel, CPU, pages) — compare the RATIO.

---

## 6. Debug instrumentation (FASTALLOC_DEBUG builds)

```bash
# run the instrumented suite - death tests prove the guards fire:
./build-dbg/fast_alloc_tests --gtest_filter='*Canary*:*Poison*:*DoubleFree*:*Leak*'

# runtime log level (needs FASTALLOC_DEBUG or FASTALLOC_LOGGING):
FASTALLOC_LOG_LEVEL=5 ./build-dbg/fast_alloc_tests --gtest_filter='ApiTest.Basic' 2>&1 | head -40
```

What the instrumentation gives you in YOUR app (build app against build-dbg):

- front canaries + rear red zones -> heap under/overflow caught at free
- freed blocks poisoned (0xDD)     -> use-after-free WRITE caught at free
- exact allocation registry        -> double-free / invalid-free detection
- `FastAlloc::fast_alloc_dump_leaks()` -> exact leak report at shutdown
- `FastAlloc::fast_alloc_stats()`  -> EXACT live counts (release: approximate)

```bash
g++ -std=c++17 -O1 -g -DFASTALLOC_DEBUG -Iinclude my_app.cpp \
    build-dbg/libfast_alloc.a -pthread -o my_app_dbg && ./my_app_dbg
```

---

## 7. Real-world usage — the 5 examples (all verified working)

```bash
cd ../FastAlloc-RunKit/examples
make FASTALLOC=$REPO all          # builds all 5 against your repo

./ex01_basic_api                  # full C++ API tour + stats + purge + OOM
./ex02_override                   # whole app routed via global new/delete
./ex03_stl                        # std::vector/map/string on FastAlloc
./ex04_server                     # REAL threaded TCP server (port 8080, 30 s)
./ex05_c                          # pure-C packet ring via extern "C" shim
```

### 7.1 Direct API (see `01_basic_api.cpp`)
```cpp
#include "fast_alloc.h"
void* p = FastAlloc::fast_malloc(128);          // >= 16-byte aligned, always
FastAlloc::fast_free_sized(p, 128);             // sized free = fastest path
void* z = FastAlloc::fast_calloc(10, 4);        // zeroed, verified
void* a = FastAlloc::fast_aligned_alloc(64, n); // SIMD buffers, 16..4096
void* g = FastAlloc::fast_realloc(a, 2*n);      // mremap for large blocks
FastAlloc::fast_alloc_purge();                  // return ALL cached pages to OS
```

### 7.2 Whole-app drop-in (see `02_new_delete_override.cpp`) — PATCH REQUIRED
```bash
# link your app against the OVERRIDE build and define the macro:
g++ -std=c++17 -O2 -DFAST_ALLOC_OVERRIDE_NEW -Iinclude my_app.cpp \
    build-override/libfast_alloc.a -pthread -o my_app
```
Every `new`/`delete`/`std::vector`/`std::string`/`make_shared` now allocates
via FastAlloc. **Without the RunKit patch this path aborts on first allocation
(audit finding OVR-1, §9).**

### 7.3 Surgical: hot containers only (see `03_stl_allocator.cpp` + `fast_stl_allocator.h`)
```cpp
#include "fast_stl_allocator.h"
fast_vector<int> v;               // std::vector on FastAlloc
fast_umap<K,V> m;                 // std::unordered_map on FastAlloc
fast_string<std::char_traits<char>> s;
```

### 7.4 Real server (see `04_multithreaded_server.cpp`)
Thread pool + per-request fast_realloc-grown buffers + 64B-aligned SIMD
scratch + cross-thread frees + stats watchdog + clean shutdown (leak dump +
purge). Verified: 500/500 concurrent requests served, 0 errors.

### 7.5 Pure C / FFI (see `fast_alloc_c.h`, `05_c_usage.c`)
```bash
g++ -std=c++17 -O2 -c -Iinclude fast_alloc_c.cpp -o fa_c.o
gcc -std=c11 my_c_app.c fa_c.o $REPO/build/libfast_alloc.a -lstdc++ -pthread -o app
# NOTE the -lstdc++: C program + C++ objects needs the C++ runtime
```

### 7.6 Integrate into YOUR CMake project (see `examples/CMakeLists.txt`)
Three recipes: `add_subdirectory` / `FetchContent` / prebuilt `.a` — plus the
override variant. Read the file, pick one, delete the rest.

---

## 8. One-command everything

```bash
bash ../FastAlloc-RunKit/scripts/run_everything.sh          # full battery, ~25-40 min
SKIP=benchmarks,cross,mem bash ../FastAlloc-RunKit/scripts/run_everything.sh
bash ../FastAlloc-RunKit/scripts/run_everything.sh --quick  # via 04/05 --quick passthrough
```

Runs: prereq check -> 6 builds -> 75+86 correctness -> ASan/UBSan/TSan/LSan ->
all benchmarks -> cross-allocator matrix -> memory footprint.

---

## 9. Audit findings fixed by the included patch

### OVR-1 (critical, runtime crash) — override build cannot bootstrap
`FASTALLOC_OVERRIDE_NEW=ON` aborts on the FIRST allocation with
`__gnu_cxx::recursive_init_error`. Three singletons bootstrap via `new`
(GlobalHeap `src/global_heap.cpp`, CachePool `src/tls_cache.cpp`, SpanPool
`src/os_memory.cpp`); under the override that `new` forwards to
`fast_malloc`, which needs the very singleton being constructed -> re-entrant
magic-static init -> terminate. **The feature advertised in the README was
unusable at runtime.** Fix: placement-new into static storage (zero
allocation at bootstrap). Repro before fix:

```bash
printf '#include "fast_alloc.h"\nint main(){FastAlloc::fast_free(FastAlloc::fast_malloc(8));}' > t.cpp
g++ -std=c++17 -Iinclude t.cpp build-override/libfast_alloc.a -pthread -o t && ./t   # aborts
```

### STAT-1 (diagnostics) — release stats miss sized frees
`fast_free_sized()` (release fast path) never called `CountSmallFree()`, so
`fast_alloc_stats()` reported monotonically growing `current_live_blocks` when
apps use sized deletes (exactly what `FASTALLOC_OVERRIDE_NEW` does). Memory
was freed correctly (exact DEBUG registry: 0 live; LSan clean) — only the
counters lied. Fix: count it like `fast_free()` does. A/B benchmark:
performance-neutral (161.1 vs 159.6 ns/op churn T=2 — within noise).

**After the patch, full regression is green in all five configurations**
(Release 75/75, Debug 85+1-by-design, ASan+UBSan 75/75, TSan 75/75, LSan 75/75).

---

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `cmake` not found | `pip3 install cmake ninja` or `sudo apt install cmake` |
| FetchContent download fails | proxy/firewall; needs internet ONCE for GTest+GBench |
| `recursive_init_error` abort with override | patch not applied — see §9 / top of file |
| TSan `FATAL: unexpected memory mapping` | kernel ASLR entropy (`vm.mmap_rnd_bits` > 28) vs old libtsan (GCC<=13 / clang<=17). **03_sanitizers.sh wraps TSan runs in `setarch -R` automatically.** Manually: `setarch $(uname -m) -R ./build-tsan/fast_alloc_tests`, or system-wide `sudo sysctl -w vm.mmap_rnd_bits=28` (persist in `/etc/sysctl.d/99-tsan.conf`). Durable: GCC>=14 / clang>=18 runtime |
| 1 debug test SKIPPED | by design (needs corrupted-header injection env) |
| C link errors (`__cxa_guard_*`) | add `-lstdc++` when linking C against the C++ lib |
| `-march=native` on old CPU | remove from CMakeLists or set `-DCMAKE_CXX_FLAGS=-O3` |
| bench numbers vary a lot | pin frequency, disable SMT noise, raise `--reps`, use `--benchmark_min_time=5000x` |
