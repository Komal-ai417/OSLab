user/ljtest.o: user/ljtest.c user/ulib.h user/../kernel/stat.h \
 user/../kernel/fcntl.h user/../kernel/pstat.h
