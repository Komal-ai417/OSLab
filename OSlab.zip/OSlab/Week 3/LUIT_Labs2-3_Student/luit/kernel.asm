
kernel.elf:     file format elf64-littleriscv


Disassembly of section .text:

0000000080200000 <_entry>:
# L1/L2 - first instructions. OpenSBI enters here in S-mode.
# a0 = hartid, a1 = physical address of the FDT blob. Both must survive to start().
.section .text.entry
.globl _entry
_entry:
        la      t0, boot_stacks
    80200000:	0000c297          	auipc	t0,0xc
    80200004:	00028293          	mv	t0,t0
        li      t1, 16384
    80200008:	6311                	lui	t1,0x4
        addi    t2, a0, 1
    8020000a:	00150393          	addi	t2,a0,1
        mul     t1, t1, t2
    8020000e:	02730333          	mul	t1,t1,t2
        add     sp, t0, t1      # sp = boot_stacks + (hartid+1)*16384
    80200012:	00628133          	add	sp,t0,t1
        mv      tp, a0          # tp = hartid, for mycpu()
    80200016:	822a                	mv	tp,a0
        call    start
    80200018:	00000097          	auipc	ra,0x0
    8020001c:	00e080e7          	jalr	14(ra) # 80200026 <start>

0000000080200020 <spin>:
spin:   wfi
    80200020:	10500073          	wfi
        j       spin
    80200024:	bff5                	j	80200020 <spin>

0000000080200026 <start>:
    printf("hart %d: online\n", hal_hart_id());
    scheduler();            /* never returns */
}

void start(uint64 hartid, uint64 fdt_pa)
{
    80200026:	7139                	addi	sp,sp,-64
    80200028:	fc06                	sd	ra,56(sp)
    8020002a:	f822                	sd	s0,48(sp)
    8020002c:	0080                	addi	s0,sp,64
    /* Lab 12: elect the boot hart at runtime. The boot hart is whichever one
     * the firmware entered first (hart 0 on qemu virt, hart 1 on sifive_u where
     * hart 0 is a low-power monitor). The first arrival wins the CAS. */
    if (boot_hart == -1 &&
    8020002e:	0000b717          	auipc	a4,0xb
    80200032:	fd272703          	lw	a4,-46(a4) # 8020b000 <boot_hart>
    80200036:	57fd                	li	a5,-1
    80200038:	04f70963          	beq	a4,a5,8020008a <start+0x64>
    8020003c:	f04a                	sd	s2,32(sp)
    8020003e:	f426                	sd	s1,40(sp)
    80200040:	ec4e                	sd	s3,24(sp)
    80200042:	e852                	sd	s4,16(sp)
    80200044:	e456                	sd	s5,8(sp)
        }

        scheduler();
    } else {
        /* --- secondary harts --- */
        while (started == 0)
    80200046:	0015a717          	auipc	a4,0x15a
    8020004a:	fba70713          	addi	a4,a4,-70 # 8035a000 <started>
    8020004e:	431c                	lw	a5,0(a4)
    80200050:	2781                	sext.w	a5,a5
    80200052:	dff5                	beqz	a5,8020004e <start+0x28>
            ;
        __sync_synchronize();
    80200054:	0ff0000f          	fence
    kvminithart();          /* same kernel page table */
    80200058:	00003097          	auipc	ra,0x3
    8020005c:	146080e7          	jalr	326(ra) # 8020319e <kvminithart>
    trapinit_hart();        /* own stvec, own timer, own PLIC context */
    80200060:	00003097          	auipc	ra,0x3
    80200064:	830080e7          	jalr	-2000(ra) # 80202890 <trapinit_hart>
    printf("hart %d: online\n", hal_hart_id());
    80200068:	00008097          	auipc	ra,0x8
    8020006c:	0e8080e7          	jalr	232(ra) # 80208150 <hal_hart_id>
    80200070:	85aa                	mv	a1,a0
    80200072:	00009517          	auipc	a0,0x9
    80200076:	11650513          	addi	a0,a0,278 # 80209188 <etext+0x188>
    8020007a:	00000097          	auipc	ra,0x0
    8020007e:	32a080e7          	jalr	810(ra) # 802003a4 <printf>
    scheduler();            /* never returns */
    80200082:	00002097          	auipc	ra,0x2
    80200086:	e4e080e7          	jalr	-434(ra) # 80201ed0 <scheduler>
    8020008a:	f04a                	sd	s2,32(sp)
    8020008c:	892a                	mv	s2,a0
        __sync_bool_compare_and_swap(&boot_hart, -1, (int)hartid)) {
    8020008e:	0000b717          	auipc	a4,0xb
    80200092:	f7270713          	addi	a4,a4,-142 # 8020b000 <boot_hart>
    80200096:	56fd                	li	a3,-1
    80200098:	0f50000f          	fence	iorw,ow
    8020009c:	140727af          	lr.w.aq	a5,(a4)
    802000a0:	00d79563          	bne	a5,a3,802000aa <start+0x84>
    802000a4:	1ca7262f          	sc.w.aq	a2,a0,(a4)
    802000a8:	fa75                	bnez	a2,8020009c <start+0x76>
    802000aa:	2785                	addiw	a5,a5,1
    if (boot_hart == -1 &&
    802000ac:	fbc9                	bnez	a5,8020003e <start+0x18>
    802000ae:	f426                	sd	s1,40(sp)
    802000b0:	ec4e                	sd	s3,24(sp)
    802000b2:	e852                	sd	s4,16(sp)
        fdt_init(fdt_pa);
    802000b4:	852e                	mv	a0,a1
    802000b6:	00001097          	auipc	ra,0x1
    802000ba:	860080e7          	jalr	-1952(ra) # 80200916 <fdt_init>
        printf("\n");
    802000be:	00009517          	auipc	a0,0x9
    802000c2:	f4250513          	addi	a0,a0,-190 # 80209000 <etext>
    802000c6:	00000097          	auipc	ra,0x0
    802000ca:	2de080e7          	jalr	734(ra) # 802003a4 <printf>
        printf("=========================================\n");
    802000ce:	00009517          	auipc	a0,0x9
    802000d2:	f3a50513          	addi	a0,a0,-198 # 80209008 <etext+0x8>
    802000d6:	00000097          	auipc	ra,0x0
    802000da:	2ce080e7          	jalr	718(ra) # 802003a4 <printf>
        printf("  BrahmaputraOS / kernel Luit\n");
    802000de:	00009517          	auipc	a0,0x9
    802000e2:	f5a50513          	addi	a0,a0,-166 # 80209038 <etext+0x38>
    802000e6:	00000097          	auipc	ra,0x0
    802000ea:	2be080e7          	jalr	702(ra) # 802003a4 <printf>
        printf("  IIT Guwahati - CS3106L\n");
    802000ee:	00009517          	auipc	a0,0x9
    802000f2:	f6a50513          	addi	a0,a0,-150 # 80209058 <etext+0x58>
    802000f6:	00000097          	auipc	ra,0x0
    802000fa:	2ae080e7          	jalr	686(ra) # 802003a4 <printf>
        printf("=========================================\n");
    802000fe:	00009517          	auipc	a0,0x9
    80200102:	f0a50513          	addi	a0,a0,-246 # 80209008 <etext+0x8>
    80200106:	00000097          	auipc	ra,0x0
    8020010a:	29e080e7          	jalr	670(ra) # 802003a4 <printf>
        printf("fdt   : blob at %p (%d bytes)\n", fdt.blob, fdt.blob_size);
    8020010e:	0002c497          	auipc	s1,0x2c
    80200112:	f0a48493          	addi	s1,s1,-246 # 8022c018 <fdt>
    80200116:	6490                	ld	a2,8(s1)
    80200118:	608c                	ld	a1,0(s1)
    8020011a:	00009517          	auipc	a0,0x9
    8020011e:	f5e50513          	addi	a0,a0,-162 # 80209078 <etext+0x78>
    80200122:	00000097          	auipc	ra,0x0
    80200126:	282080e7          	jalr	642(ra) # 802003a4 <printf>
        printf("uart  : %p  (discovered, not hardcoded)\n", fdt.uart_base);
    8020012a:	688c                	ld	a1,16(s1)
    8020012c:	00009517          	auipc	a0,0x9
    80200130:	f6c50513          	addi	a0,a0,-148 # 80209098 <etext+0x98>
    80200134:	00000097          	auipc	ra,0x0
    80200138:	270080e7          	jalr	624(ra) # 802003a4 <printf>
        printf("plic  : %p\n", fdt.plic_base);
    8020013c:	6c8c                	ld	a1,24(s1)
    8020013e:	00009517          	auipc	a0,0x9
    80200142:	f8a50513          	addi	a0,a0,-118 # 802090c8 <etext+0xc8>
    80200146:	00000097          	auipc	ra,0x0
    8020014a:	25e080e7          	jalr	606(ra) # 802003a4 <printf>
        printf("memory: %p + %d MiB\n", fdt.mem_base, fdt.mem_size >> 20);
    8020014e:	6cd0                	ld	a2,152(s1)
    80200150:	8251                	srli	a2,a2,0x14
    80200152:	68cc                	ld	a1,144(s1)
    80200154:	00009517          	auipc	a0,0x9
    80200158:	f8450513          	addi	a0,a0,-124 # 802090d8 <etext+0xd8>
    8020015c:	00000097          	auipc	ra,0x0
    80200160:	248080e7          	jalr	584(ra) # 802003a4 <printf>
        printf("harts : %d\n", fdt.ncpu);
    80200164:	0a04a583          	lw	a1,160(s1)
    80200168:	00009517          	auipc	a0,0x9
    8020016c:	f8850513          	addi	a0,a0,-120 # 802090f0 <etext+0xf0>
    80200170:	00000097          	auipc	ra,0x0
    80200174:	234080e7          	jalr	564(ra) # 802003a4 <printf>
        hal_console_init(fdt.uart_base);
    80200178:	6888                	ld	a0,16(s1)
    8020017a:	00008097          	auipc	ra,0x8
    8020017e:	084080e7          	jalr	132(ra) # 802081fe <hal_console_init>
        hal_intc_init(fdt.plic_base);
    80200182:	6c88                	ld	a0,24(s1)
    80200184:	00008097          	auipc	ra,0x8
    80200188:	ed6080e7          	jalr	-298(ra) # 8020805a <hal_intc_init>
        console_ready = 1;
    8020018c:	0015a997          	auipc	s3,0x15a
    80200190:	e7898993          	addi	s3,s3,-392 # 8035a004 <console_ready>
    80200194:	4a05                	li	s4,1
    80200196:	0149a023          	sw	s4,0(s3)
        palloc_init();
    8020019a:	00001097          	auipc	ra,0x1
    8020019e:	e2a080e7          	jalr	-470(ra) # 80200fc4 <palloc_init>
        printfinit();       /* locked printf, now that we have locks + memory */
    802001a2:	00000097          	auipc	ra,0x0
    802001a6:	442080e7          	jalr	1090(ra) # 802005e4 <printfinit>
        procinit();
    802001aa:	00001097          	auipc	ra,0x1
    802001ae:	7ee080e7          	jalr	2030(ra) # 80201998 <procinit>
        trace_init();      /* Lab 2 */
    802001b2:	00005097          	auipc	ra,0x5
    802001b6:	e6a080e7          	jalr	-406(ra) # 8020501c <trace_init>
        futex_init();      /* Lab 6 */
    802001ba:	00005097          	auipc	ra,0x5
    802001be:	0ea080e7          	jalr	234(ra) # 802052a4 <futex_init>
        kvminit();
    802001c2:	00003097          	auipc	ra,0x3
    802001c6:	eca080e7          	jalr	-310(ra) # 8020308c <kvminit>
        kvminithart();      /* paging ON for this hart */
    802001ca:	00003097          	auipc	ra,0x3
    802001ce:	fd4080e7          	jalr	-44(ra) # 8020319e <kvminithart>
        console_ready = 0;                    /* SBI console while we re-point */
    802001d2:	0009a023          	sw	zero,0(s3)
        hal_console_init(mmio_alias(fdt.uart_base));
    802001d6:	6888                	ld	a0,16(s1)
    802001d8:	00003097          	auipc	ra,0x3
    802001dc:	ce4080e7          	jalr	-796(ra) # 80202ebc <mmio_alias>
    802001e0:	00008097          	auipc	ra,0x8
    802001e4:	01e080e7          	jalr	30(ra) # 802081fe <hal_console_init>
        console_ready = 1;
    802001e8:	0149a023          	sw	s4,0(s3)
        hal_intc_init(mmio_alias(fdt.plic_base));
    802001ec:	6c88                	ld	a0,24(s1)
    802001ee:	00003097          	auipc	ra,0x3
    802001f2:	cce080e7          	jalr	-818(ra) # 80202ebc <mmio_alias>
    802001f6:	00008097          	auipc	ra,0x8
    802001fa:	e64080e7          	jalr	-412(ra) # 8020805a <hal_intc_init>
        consoleinit();      /* console device (major CONSOLE)         */
    802001fe:	00006097          	auipc	ra,0x6
    80200202:	01e080e7          	jalr	30(ra) # 8020621c <consoleinit>
        binit();            /* buffer cache                           */
    80200206:	00006097          	auipc	ra,0x6
    8020020a:	5be080e7          	jalr	1470(ra) # 802067c4 <binit>
        iinit();            /* inode cache                            */
    8020020e:	00007097          	auipc	ra,0x7
    80200212:	c24080e7          	jalr	-988(ra) # 80206e32 <iinit>
        fileinit();         /* system-wide open-file table            */
    80200216:	00007097          	auipc	ra,0x7
    8020021a:	746080e7          	jalr	1862(ra) # 8020795c <fileinit>
        if (hal_block_init() < 0)
    8020021e:	00008097          	auipc	ra,0x8
    80200222:	0fe080e7          	jalr	254(ra) # 8020831c <hal_block_init>
    80200226:	06054463          	bltz	a0,8020028e <start+0x268>
    8020022a:	e456                	sd	s5,8(sp)
        trapinit_hart();    /* traps, timer, PLIC (incl. the disk irq) */
    8020022c:	00002097          	auipc	ra,0x2
    80200230:	664080e7          	jalr	1636(ra) # 80202890 <trapinit_hart>
        userinit();         /* the first user process                 */
    80200234:	00001097          	auipc	ra,0x1
    80200238:	7fc080e7          	jalr	2044(ra) # 80201a30 <userinit>
        printf("hart %d: online (boot)\n", (int)hartid);
    8020023c:	0009059b          	sext.w	a1,s2
    80200240:	00009517          	auipc	a0,0x9
    80200244:	f0850513          	addi	a0,a0,-248 # 80209148 <etext+0x148>
    80200248:	00000097          	auipc	ra,0x0
    8020024c:	15c080e7          	jalr	348(ra) # 802003a4 <printf>
        __sync_synchronize();
    80200250:	0ff0000f          	fence
        started = 1;
    80200254:	4785                	li	a5,1
    80200256:	0015a717          	auipc	a4,0x15a
    8020025a:	daf72523          	sw	a5,-598(a4) # 8035a000 <started>
        for (int i = 0; i < fdt.ncpu; i++) {
    8020025e:	0002c797          	auipc	a5,0x2c
    80200262:	e5a7a783          	lw	a5,-422(a5) # 8022c0b8 <fdt+0xa0>
    80200266:	06f05c63          	blez	a5,802002de <start+0x2b8>
    8020026a:	4481                	li	s1,0
            if (i == boot_hart) continue;        /* skip ourselves */
    8020026c:	0000b997          	auipc	s3,0xb
    80200270:	d9498993          	addi	s3,s3,-620 # 8020b000 <boot_hart>
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    80200274:	00000a17          	auipc	s4,0x0
    80200278:	d8ca0a13          	addi	s4,s4,-628 # 80200000 <_entry>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    8020027c:	00009a97          	auipc	s5,0x9
    80200280:	ee4a8a93          	addi	s5,s5,-284 # 80209160 <etext+0x160>
        for (int i = 0; i < fdt.ncpu; i++) {
    80200284:	0002c917          	auipc	s2,0x2c
    80200288:	d9490913          	addi	s2,s2,-620 # 8022c018 <fdt>
    8020028c:	a00d                	j	802002ae <start+0x288>
    8020028e:	e456                	sd	s5,8(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
    80200290:	00009517          	auipc	a0,0x9
    80200294:	e7050513          	addi	a0,a0,-400 # 80209100 <etext+0x100>
    80200298:	00000097          	auipc	ra,0x0
    8020029c:	37e080e7          	jalr	894(ra) # 80200616 <panic>
        for (int i = 0; i < fdt.ncpu; i++) {
    802002a0:	0485                	addi	s1,s1,1
    802002a2:	0a092703          	lw	a4,160(s2)
    802002a6:	0004879b          	sext.w	a5,s1
    802002aa:	02e7da63          	bge	a5,a4,802002de <start+0x2b8>
            if (i == boot_hart) continue;        /* skip ourselves */
    802002ae:	0009a783          	lw	a5,0(s3)
    802002b2:	2781                	sext.w	a5,a5
    802002b4:	0004871b          	sext.w	a4,s1
    802002b8:	fee784e3          	beq	a5,a4,802002a0 <start+0x27a>
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    802002bc:	4601                	li	a2,0
    802002be:	85d2                	mv	a1,s4
    802002c0:	8526                	mv	a0,s1
    802002c2:	00000097          	auipc	ra,0x0
    802002c6:	574080e7          	jalr	1396(ra) # 80200836 <sbi_hart_start>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    802002ca:	d979                	beqz	a0,802002a0 <start+0x27a>
    802002cc:	862a                	mv	a2,a0
    802002ce:	0004859b          	sext.w	a1,s1
    802002d2:	8556                	mv	a0,s5
    802002d4:	00000097          	auipc	ra,0x0
    802002d8:	0d0080e7          	jalr	208(ra) # 802003a4 <printf>
    802002dc:	b7d1                	j	802002a0 <start+0x27a>
        scheduler();
    802002de:	00002097          	auipc	ra,0x2
    802002e2:	bf2080e7          	jalr	-1038(ra) # 80201ed0 <scheduler>

00000000802002e6 <putc>:

/* Before the UART driver exists (i.e. before the device tree has told us where
 * the UART is), fall back to OpenSBI's console. This is why a panic inside
 * fdt_init() is still visible - a silent early panic is a nightmare to debug. */
int console_ready = 0;
static void putc(char c) { if (console_ready) hal_console_putc(c); else sbi_putchar(c); }
    802002e6:	1141                	addi	sp,sp,-16
    802002e8:	e406                	sd	ra,8(sp)
    802002ea:	e022                	sd	s0,0(sp)
    802002ec:	0800                	addi	s0,sp,16
    802002ee:	0015a797          	auipc	a5,0x15a
    802002f2:	d167a783          	lw	a5,-746(a5) # 8035a004 <console_ready>
    802002f6:	cb89                	beqz	a5,80200308 <putc+0x22>
    802002f8:	00008097          	auipc	ra,0x8
    802002fc:	f40080e7          	jalr	-192(ra) # 80208238 <hal_console_putc>
    80200300:	60a2                	ld	ra,8(sp)
    80200302:	6402                	ld	s0,0(sp)
    80200304:	0141                	addi	sp,sp,16
    80200306:	8082                	ret
    80200308:	00000097          	auipc	ra,0x0
    8020030c:	4dc080e7          	jalr	1244(ra) # 802007e4 <sbi_putchar>
    80200310:	bfc5                	j	80200300 <putc+0x1a>

0000000080200312 <printint>:

static void printint(long long xx, int base, int sign)
{
    80200312:	7139                	addi	sp,sp,-64
    80200314:	fc06                	sd	ra,56(sp)
    80200316:	f822                	sd	s0,48(sp)
    80200318:	0080                	addi	s0,sp,64
    char buf[24];
    int i = 0;
    unsigned long long x;

    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    8020031a:	c219                	beqz	a2,80200320 <printint+0xe>
    8020031c:	08054163          	bltz	a0,8020039e <printint+0x8c>
    80200320:	4601                	li	a2,0
    80200322:	fc840693          	addi	a3,s0,-56
    80200326:	4781                	li	a5,0
    do { buf[i++] = digits[x % base]; } while ((x /= base) != 0);
    80200328:	0000a817          	auipc	a6,0xa
    8020032c:	c9080813          	addi	a6,a6,-880 # 80209fb8 <digits>
    80200330:	88be                	mv	a7,a5
    80200332:	2785                	addiw	a5,a5,1
    80200334:	02b57733          	remu	a4,a0,a1
    80200338:	9742                	add	a4,a4,a6
    8020033a:	00074703          	lbu	a4,0(a4)
    8020033e:	00e68023          	sb	a4,0(a3)
    80200342:	872a                	mv	a4,a0
    80200344:	02b55533          	divu	a0,a0,a1
    80200348:	0685                	addi	a3,a3,1
    8020034a:	feb773e3          	bgeu	a4,a1,80200330 <printint+0x1e>
    if (sign) buf[i++] = '-';
    8020034e:	ca09                	beqz	a2,80200360 <printint+0x4e>
    80200350:	1781                	addi	a5,a5,-32
    80200352:	97a2                	add	a5,a5,s0
    80200354:	02d00713          	li	a4,45
    80200358:	fee78423          	sb	a4,-24(a5)
    8020035c:	0028879b          	addiw	a5,a7,2
    while (--i >= 0) putc(buf[i]);
    80200360:	02f05b63          	blez	a5,80200396 <printint+0x84>
    80200364:	f426                	sd	s1,40(sp)
    80200366:	f04a                	sd	s2,32(sp)
    80200368:	fc840713          	addi	a4,s0,-56
    8020036c:	00f704b3          	add	s1,a4,a5
    80200370:	fff70913          	addi	s2,a4,-1
    80200374:	993e                	add	s2,s2,a5
    80200376:	37fd                	addiw	a5,a5,-1
    80200378:	1782                	slli	a5,a5,0x20
    8020037a:	9381                	srli	a5,a5,0x20
    8020037c:	40f90933          	sub	s2,s2,a5
    80200380:	fff4c503          	lbu	a0,-1(s1)
    80200384:	00000097          	auipc	ra,0x0
    80200388:	f62080e7          	jalr	-158(ra) # 802002e6 <putc>
    8020038c:	14fd                	addi	s1,s1,-1
    8020038e:	ff2499e3          	bne	s1,s2,80200380 <printint+0x6e>
    80200392:	74a2                	ld	s1,40(sp)
    80200394:	7902                	ld	s2,32(sp)
}
    80200396:	70e2                	ld	ra,56(sp)
    80200398:	7442                	ld	s0,48(sp)
    8020039a:	6121                	addi	sp,sp,64
    8020039c:	8082                	ret
    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    8020039e:	40a00533          	neg	a0,a0
    802003a2:	b741                	j	80200322 <printint+0x10>

00000000802003a4 <printf>:
    for (int i = 0; i < 16; i++, x <<= 4)
        putc(digits[x >> 60]);
}

void printf(const char *fmt, ...)
{
    802003a4:	7171                	addi	sp,sp,-176
    802003a6:	f486                	sd	ra,104(sp)
    802003a8:	f0a2                	sd	s0,96(sp)
    802003aa:	e0d2                	sd	s4,64(sp)
    802003ac:	f062                	sd	s8,32(sp)
    802003ae:	1880                	addi	s0,sp,112
    802003b0:	8a2a                	mv	s4,a0
    802003b2:	e40c                	sd	a1,8(s0)
    802003b4:	e810                	sd	a2,16(s0)
    802003b6:	ec14                	sd	a3,24(s0)
    802003b8:	f018                	sd	a4,32(s0)
    802003ba:	f41c                	sd	a5,40(s0)
    802003bc:	03043823          	sd	a6,48(s0)
    802003c0:	03143c23          	sd	a7,56(s0)
    va_list ap;
    int locking = pr_locking;
    802003c4:	0015ac17          	auipc	s8,0x15a
    802003c8:	c44c2c03          	lw	s8,-956(s8) # 8035a008 <pr_locking>
    if (locking) acquire(&pr_lock);
    802003cc:	020c1863          	bnez	s8,802003fc <printf+0x58>

    va_start(ap, fmt);
    802003d0:	00840793          	addi	a5,s0,8
    802003d4:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003d8:	00054503          	lbu	a0,0(a0)
    802003dc:	1e050063          	beqz	a0,802005bc <printf+0x218>
    802003e0:	eca6                	sd	s1,88(sp)
    802003e2:	e8ca                	sd	s2,80(sp)
    802003e4:	fc56                	sd	s5,56(sp)
    802003e6:	f85a                	sd	s6,48(sp)
    802003e8:	f45e                	sd	s7,40(sp)
    802003ea:	4481                	li	s1,0
        char c = fmt[i];
        if (c != '%') { putc(c); continue; }
    802003ec:	02500a93          	li	s5,37
        c = fmt[++i];
        if (!c) break;
        switch (c) {
    802003f0:	4b55                	li	s6,21
    802003f2:	0000ab97          	auipc	s7,0xa
    802003f6:	b6eb8b93          	addi	s7,s7,-1170 # 80209f60 <etext+0xf60>
    802003fa:	a825                	j	80200432 <printf+0x8e>
    if (locking) acquire(&pr_lock);
    802003fc:	0002c517          	auipc	a0,0x2c
    80200400:	c0450513          	addi	a0,a0,-1020 # 8022c000 <pr_lock>
    80200404:	00001097          	auipc	ra,0x1
    80200408:	084080e7          	jalr	132(ra) # 80201488 <acquire>
    va_start(ap, fmt);
    8020040c:	00840793          	addi	a5,s0,8
    80200410:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    80200414:	000a4503          	lbu	a0,0(s4)
    80200418:	f561                	bnez	a0,802003e0 <printf+0x3c>
    8020041a:	aa65                	j	802005d2 <printf+0x22e>
        if (c != '%') { putc(c); continue; }
    8020041c:	00000097          	auipc	ra,0x0
    80200420:	eca080e7          	jalr	-310(ra) # 802002e6 <putc>
    for (int i = 0; fmt[i]; i++) {
    80200424:	2485                	addiw	s1,s1,1
    80200426:	009a07b3          	add	a5,s4,s1
    8020042a:	0007c503          	lbu	a0,0(a5)
    8020042e:	18050063          	beqz	a0,802005ae <printf+0x20a>
        if (c != '%') { putc(c); continue; }
    80200432:	ff5515e3          	bne	a0,s5,8020041c <printf+0x78>
        c = fmt[++i];
    80200436:	2485                	addiw	s1,s1,1
    80200438:	009a07b3          	add	a5,s4,s1
    8020043c:	0007c903          	lbu	s2,0(a5)
        if (!c) break;
    80200440:	16090763          	beqz	s2,802005ae <printf+0x20a>
        switch (c) {
    80200444:	15590263          	beq	s2,s5,80200588 <printf+0x1e4>
    80200448:	f9d9079b          	addiw	a5,s2,-99
    8020044c:	0ff7f793          	zext.b	a5,a5
    80200450:	14fb6363          	bltu	s6,a5,80200596 <printf+0x1f2>
    80200454:	f9d9079b          	addiw	a5,s2,-99
    80200458:	0ff7f713          	zext.b	a4,a5
    8020045c:	12eb6d63          	bltu	s6,a4,80200596 <printf+0x1f2>
    80200460:	00271793          	slli	a5,a4,0x2
    80200464:	97de                	add	a5,a5,s7
    80200466:	439c                	lw	a5,0(a5)
    80200468:	97de                	add	a5,a5,s7
    8020046a:	8782                	jr	a5
        case 'd': printint(va_arg(ap, int), 10, 1); break;
    8020046c:	f9843783          	ld	a5,-104(s0)
    80200470:	00878713          	addi	a4,a5,8
    80200474:	f8e43c23          	sd	a4,-104(s0)
    80200478:	4605                	li	a2,1
    8020047a:	45a9                	li	a1,10
    8020047c:	4388                	lw	a0,0(a5)
    8020047e:	00000097          	auipc	ra,0x0
    80200482:	e94080e7          	jalr	-364(ra) # 80200312 <printint>
    80200486:	bf79                	j	80200424 <printf+0x80>
        case 'l': printint(va_arg(ap, uint64), 10, 0); break;
    80200488:	f9843783          	ld	a5,-104(s0)
    8020048c:	00878713          	addi	a4,a5,8
    80200490:	f8e43c23          	sd	a4,-104(s0)
    80200494:	4601                	li	a2,0
    80200496:	45a9                	li	a1,10
    80200498:	6388                	ld	a0,0(a5)
    8020049a:	00000097          	auipc	ra,0x0
    8020049e:	e78080e7          	jalr	-392(ra) # 80200312 <printint>
    802004a2:	b749                	j	80200424 <printf+0x80>
        case 'u': printint(va_arg(ap, uint64), 10, 0); break;
    802004a4:	f9843783          	ld	a5,-104(s0)
    802004a8:	00878713          	addi	a4,a5,8
    802004ac:	f8e43c23          	sd	a4,-104(s0)
    802004b0:	4601                	li	a2,0
    802004b2:	45a9                	li	a1,10
    802004b4:	6388                	ld	a0,0(a5)
    802004b6:	00000097          	auipc	ra,0x0
    802004ba:	e5c080e7          	jalr	-420(ra) # 80200312 <printint>
    802004be:	b79d                	j	80200424 <printf+0x80>
        case 'x': printint(va_arg(ap, uint64), 16, 0); break;
    802004c0:	f9843783          	ld	a5,-104(s0)
    802004c4:	00878713          	addi	a4,a5,8
    802004c8:	f8e43c23          	sd	a4,-104(s0)
    802004cc:	4601                	li	a2,0
    802004ce:	45c1                	li	a1,16
    802004d0:	6388                	ld	a0,0(a5)
    802004d2:	00000097          	auipc	ra,0x0
    802004d6:	e40080e7          	jalr	-448(ra) # 80200312 <printint>
    802004da:	b7a9                	j	80200424 <printf+0x80>
    802004dc:	e4ce                	sd	s3,72(sp)
    802004de:	ec66                	sd	s9,24(sp)
        case 'p': printptr(va_arg(ap, uint64)); break;
    802004e0:	f9843783          	ld	a5,-104(s0)
    802004e4:	00878713          	addi	a4,a5,8
    802004e8:	f8e43c23          	sd	a4,-104(s0)
    802004ec:	0007b983          	ld	s3,0(a5)
    putc('0'); putc('x');
    802004f0:	03000513          	li	a0,48
    802004f4:	00000097          	auipc	ra,0x0
    802004f8:	df2080e7          	jalr	-526(ra) # 802002e6 <putc>
    802004fc:	07800513          	li	a0,120
    80200500:	00000097          	auipc	ra,0x0
    80200504:	de6080e7          	jalr	-538(ra) # 802002e6 <putc>
    80200508:	4941                	li	s2,16
        putc(digits[x >> 60]);
    8020050a:	0000ac97          	auipc	s9,0xa
    8020050e:	aaec8c93          	addi	s9,s9,-1362 # 80209fb8 <digits>
    80200512:	03c9d793          	srli	a5,s3,0x3c
    80200516:	97e6                	add	a5,a5,s9
    80200518:	0007c503          	lbu	a0,0(a5)
    8020051c:	00000097          	auipc	ra,0x0
    80200520:	dca080e7          	jalr	-566(ra) # 802002e6 <putc>
    for (int i = 0; i < 16; i++, x <<= 4)
    80200524:	0992                	slli	s3,s3,0x4
    80200526:	397d                	addiw	s2,s2,-1
    80200528:	fe0915e3          	bnez	s2,80200512 <printf+0x16e>
    8020052c:	69a6                	ld	s3,72(sp)
    8020052e:	6ce2                	ld	s9,24(sp)
    80200530:	bdd5                	j	80200424 <printf+0x80>
        case 'c': putc((char)va_arg(ap, int)); break;
    80200532:	f9843783          	ld	a5,-104(s0)
    80200536:	00878713          	addi	a4,a5,8
    8020053a:	f8e43c23          	sd	a4,-104(s0)
    8020053e:	0007c503          	lbu	a0,0(a5)
    80200542:	00000097          	auipc	ra,0x0
    80200546:	da4080e7          	jalr	-604(ra) # 802002e6 <putc>
    8020054a:	bde9                	j	80200424 <printf+0x80>
        case 's': {
            const char *s = va_arg(ap, const char *);
    8020054c:	f9843783          	ld	a5,-104(s0)
    80200550:	00878713          	addi	a4,a5,8
    80200554:	f8e43c23          	sd	a4,-104(s0)
    80200558:	0007b903          	ld	s2,0(a5)
            if (!s) s = "(null)";
    8020055c:	00090f63          	beqz	s2,8020057a <printf+0x1d6>
            while (*s) putc(*s++);
    80200560:	00094503          	lbu	a0,0(s2)
    80200564:	ec0500e3          	beqz	a0,80200424 <printf+0x80>
    80200568:	0905                	addi	s2,s2,1
    8020056a:	00000097          	auipc	ra,0x0
    8020056e:	d7c080e7          	jalr	-644(ra) # 802002e6 <putc>
    80200572:	00094503          	lbu	a0,0(s2)
    80200576:	f96d                	bnez	a0,80200568 <printf+0x1c4>
    80200578:	b575                	j	80200424 <printf+0x80>
            if (!s) s = "(null)";
    8020057a:	00009917          	auipc	s2,0x9
    8020057e:	c2690913          	addi	s2,s2,-986 # 802091a0 <etext+0x1a0>
            while (*s) putc(*s++);
    80200582:	02800513          	li	a0,40
    80200586:	b7cd                	j	80200568 <printf+0x1c4>
            break;
        }
        case '%': putc('%'); break;
    80200588:	02500513          	li	a0,37
    8020058c:	00000097          	auipc	ra,0x0
    80200590:	d5a080e7          	jalr	-678(ra) # 802002e6 <putc>
    80200594:	bd41                	j	80200424 <printf+0x80>
        default:  putc('%'); putc(c); break;
    80200596:	02500513          	li	a0,37
    8020059a:	00000097          	auipc	ra,0x0
    8020059e:	d4c080e7          	jalr	-692(ra) # 802002e6 <putc>
    802005a2:	854a                	mv	a0,s2
    802005a4:	00000097          	auipc	ra,0x0
    802005a8:	d42080e7          	jalr	-702(ra) # 802002e6 <putc>
    802005ac:	bda5                	j	80200424 <printf+0x80>
        }
    }
    va_end(ap);
    if (locking) release(&pr_lock);
    802005ae:	000c1d63          	bnez	s8,802005c8 <printf+0x224>
    802005b2:	64e6                	ld	s1,88(sp)
    802005b4:	6946                	ld	s2,80(sp)
    802005b6:	7ae2                	ld	s5,56(sp)
    802005b8:	7b42                	ld	s6,48(sp)
    802005ba:	7ba2                	ld	s7,40(sp)
}
    802005bc:	70a6                	ld	ra,104(sp)
    802005be:	7406                	ld	s0,96(sp)
    802005c0:	6a06                	ld	s4,64(sp)
    802005c2:	7c02                	ld	s8,32(sp)
    802005c4:	614d                	addi	sp,sp,176
    802005c6:	8082                	ret
    802005c8:	64e6                	ld	s1,88(sp)
    802005ca:	6946                	ld	s2,80(sp)
    802005cc:	7ae2                	ld	s5,56(sp)
    802005ce:	7b42                	ld	s6,48(sp)
    802005d0:	7ba2                	ld	s7,40(sp)
    if (locking) release(&pr_lock);
    802005d2:	0002c517          	auipc	a0,0x2c
    802005d6:	a2e50513          	addi	a0,a0,-1490 # 8022c000 <pr_lock>
    802005da:	00001097          	auipc	ra,0x1
    802005de:	f62080e7          	jalr	-158(ra) # 8020153c <release>
}
    802005e2:	bfe9                	j	802005bc <printf+0x218>

00000000802005e4 <printfinit>:

void printfinit(void) { initlock(&pr_lock, "pr"); pr_locking = 1; }
    802005e4:	1141                	addi	sp,sp,-16
    802005e6:	e406                	sd	ra,8(sp)
    802005e8:	e022                	sd	s0,0(sp)
    802005ea:	0800                	addi	s0,sp,16
    802005ec:	00009597          	auipc	a1,0x9
    802005f0:	bbc58593          	addi	a1,a1,-1092 # 802091a8 <etext+0x1a8>
    802005f4:	0002c517          	auipc	a0,0x2c
    802005f8:	a0c50513          	addi	a0,a0,-1524 # 8022c000 <pr_lock>
    802005fc:	00001097          	auipc	ra,0x1
    80200600:	e10080e7          	jalr	-496(ra) # 8020140c <initlock>
    80200604:	4785                	li	a5,1
    80200606:	0015a717          	auipc	a4,0x15a
    8020060a:	a0f72123          	sw	a5,-1534(a4) # 8035a008 <pr_locking>
    8020060e:	60a2                	ld	ra,8(sp)
    80200610:	6402                	ld	s0,0(sp)
    80200612:	0141                	addi	sp,sp,16
    80200614:	8082                	ret

0000000080200616 <panic>:

void panic(const char *s)
{
    80200616:	1101                	addi	sp,sp,-32
    80200618:	ec06                	sd	ra,24(sp)
    8020061a:	e822                	sd	s0,16(sp)
    8020061c:	e426                	sd	s1,8(sp)
    8020061e:	1000                	addi	s0,sp,32
    80200620:	84aa                	mv	s1,a0
    pr_locking = 0;                       /* never deadlock inside a panic */
    80200622:	0015a797          	auipc	a5,0x15a
    80200626:	9e07a323          	sw	zero,-1562(a5) # 8035a008 <pr_locking>
    printf("\n=== KERNEL PANIC (hart %d) ===\n", hal_hart_id());
    8020062a:	00008097          	auipc	ra,0x8
    8020062e:	b26080e7          	jalr	-1242(ra) # 80208150 <hal_hart_id>
    80200632:	85aa                	mv	a1,a0
    80200634:	00009517          	auipc	a0,0x9
    80200638:	b7c50513          	addi	a0,a0,-1156 # 802091b0 <etext+0x1b0>
    8020063c:	00000097          	auipc	ra,0x0
    80200640:	d68080e7          	jalr	-664(ra) # 802003a4 <printf>
    printf("  %s\n", s);
    80200644:	85a6                	mv	a1,s1
    80200646:	00009517          	auipc	a0,0x9
    8020064a:	b9250513          	addi	a0,a0,-1134 # 802091d8 <etext+0x1d8>
    8020064e:	00000097          	auipc	ra,0x0
    80200652:	d56080e7          	jalr	-682(ra) # 802003a4 <printf>
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80200656:	141025f3          	csrr	a1,sepc
    printf("  sepc   = %p\n", r_sepc());
    8020065a:	00009517          	auipc	a0,0x9
    8020065e:	b8650513          	addi	a0,a0,-1146 # 802091e0 <etext+0x1e0>
    80200662:	00000097          	auipc	ra,0x0
    80200666:	d42080e7          	jalr	-702(ra) # 802003a4 <printf>
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    8020066a:	142025f3          	csrr	a1,scause
    printf("  scause = %p\n", r_scause());
    8020066e:	00009517          	auipc	a0,0x9
    80200672:	b8250513          	addi	a0,a0,-1150 # 802091f0 <etext+0x1f0>
    80200676:	00000097          	auipc	ra,0x0
    8020067a:	d2e080e7          	jalr	-722(ra) # 802003a4 <printf>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    8020067e:	143025f3          	csrr	a1,stval
    printf("  stval  = %p\n", r_stval());
    80200682:	00009517          	auipc	a0,0x9
    80200686:	b7e50513          	addi	a0,a0,-1154 # 80209200 <etext+0x200>
    8020068a:	00000097          	auipc	ra,0x0
    8020068e:	d1a080e7          	jalr	-742(ra) # 802003a4 <printf>
static inline void   w_sscratch(uint64 x){ asm volatile("csrw sscratch, %0"::"r"(x)); }
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    80200692:	180025f3          	csrr	a1,satp
    printf("  satp   = %p\n", r_satp());
    80200696:	00009517          	auipc	a0,0x9
    8020069a:	b7a50513          	addi	a0,a0,-1158 # 80209210 <etext+0x210>
    8020069e:	00000097          	auipc	ra,0x0
    802006a2:	d06080e7          	jalr	-762(ra) # 802003a4 <printf>
    printf("=============================\n");
    802006a6:	00009517          	auipc	a0,0x9
    802006aa:	b7a50513          	addi	a0,a0,-1158 # 80209220 <etext+0x220>
    802006ae:	00000097          	auipc	ra,0x0
    802006b2:	cf6080e7          	jalr	-778(ra) # 802003a4 <printf>
    for (;;) asm volatile("wfi");
    802006b6:	10500073          	wfi
    802006ba:	bff5                	j	802006b6 <panic+0xa0>

00000000802006bc <memset>:
#include "types.h"
#include "defs.h"
void *memset(void *dst, int c, usize n){ char *d=dst; while(n--) *d++=(char)c; return dst; }
    802006bc:	1141                	addi	sp,sp,-16
    802006be:	e422                	sd	s0,8(sp)
    802006c0:	0800                	addi	s0,sp,16
    802006c2:	ca01                	beqz	a2,802006d2 <memset+0x16>
    802006c4:	962a                	add	a2,a2,a0
    802006c6:	87aa                	mv	a5,a0
    802006c8:	0785                	addi	a5,a5,1
    802006ca:	feb78fa3          	sb	a1,-1(a5)
    802006ce:	fef61de3          	bne	a2,a5,802006c8 <memset+0xc>
    802006d2:	6422                	ld	s0,8(sp)
    802006d4:	0141                	addi	sp,sp,16
    802006d6:	8082                	ret

00000000802006d8 <memmove>:
void *memmove(void *dst, const void *src, usize n){
    802006d8:	1141                	addi	sp,sp,-16
    802006da:	e422                	sd	s0,8(sp)
    802006dc:	0800                	addi	s0,sp,16
    char *d=dst; const char *s=src;
    if (d < s) { while(n--) *d++ = *s++; }
    802006de:	02b57063          	bgeu	a0,a1,802006fe <memmove+0x26>
    802006e2:	ca19                	beqz	a2,802006f8 <memmove+0x20>
    802006e4:	962a                	add	a2,a2,a0
    char *d=dst; const char *s=src;
    802006e6:	87aa                	mv	a5,a0
    if (d < s) { while(n--) *d++ = *s++; }
    802006e8:	0585                	addi	a1,a1,1
    802006ea:	0785                	addi	a5,a5,1
    802006ec:	fff5c703          	lbu	a4,-1(a1)
    802006f0:	fee78fa3          	sb	a4,-1(a5)
    802006f4:	fef61ae3          	bne	a2,a5,802006e8 <memmove+0x10>
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    return dst;
}
    802006f8:	6422                	ld	s0,8(sp)
    802006fa:	0141                	addi	sp,sp,16
    802006fc:	8082                	ret
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    802006fe:	00c507b3          	add	a5,a0,a2
    80200702:	95b2                	add	a1,a1,a2
    80200704:	da75                	beqz	a2,802006f8 <memmove+0x20>
    80200706:	15fd                	addi	a1,a1,-1
    80200708:	17fd                	addi	a5,a5,-1
    8020070a:	0005c703          	lbu	a4,0(a1)
    8020070e:	00e78023          	sb	a4,0(a5)
    80200712:	fef51ae3          	bne	a0,a5,80200706 <memmove+0x2e>
    80200716:	b7cd                	j	802006f8 <memmove+0x20>

0000000080200718 <memcmp>:
int memcmp(const void *a, const void *b, usize n){
    80200718:	1141                	addi	sp,sp,-16
    8020071a:	e422                	sd	s0,8(sp)
    8020071c:	0800                	addi	s0,sp,16
    const uint8 *x=a,*y=b;
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    8020071e:	c21d                	beqz	a2,80200744 <memcmp+0x2c>
    80200720:	962a                	add	a2,a2,a0
    80200722:	00054783          	lbu	a5,0(a0)
    80200726:	0005c703          	lbu	a4,0(a1)
    8020072a:	00e79863          	bne	a5,a4,8020073a <memcmp+0x22>
    8020072e:	0505                	addi	a0,a0,1
    80200730:	0585                	addi	a1,a1,1
    80200732:	fea618e3          	bne	a2,a0,80200722 <memcmp+0xa>
    return 0;
    80200736:	4501                	li	a0,0
    80200738:	a019                	j	8020073e <memcmp+0x26>
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    8020073a:	40e7853b          	subw	a0,a5,a4
}
    8020073e:	6422                	ld	s0,8(sp)
    80200740:	0141                	addi	sp,sp,16
    80200742:	8082                	ret
    return 0;
    80200744:	4501                	li	a0,0
    80200746:	bfe5                	j	8020073e <memcmp+0x26>

0000000080200748 <strncmp>:
int strncmp(const char *a, const char *b, usize n){
    80200748:	1141                	addi	sp,sp,-16
    8020074a:	e422                	sd	s0,8(sp)
    8020074c:	0800                	addi	s0,sp,16
    while(n > 0 && *a && *a == *b){ a++; b++; n--; }
    8020074e:	ce11                	beqz	a2,8020076a <strncmp+0x22>
    80200750:	00054783          	lbu	a5,0(a0)
    80200754:	cf89                	beqz	a5,8020076e <strncmp+0x26>
    80200756:	0005c703          	lbu	a4,0(a1)
    8020075a:	00f71a63          	bne	a4,a5,8020076e <strncmp+0x26>
    8020075e:	0505                	addi	a0,a0,1
    80200760:	0585                	addi	a1,a1,1
    80200762:	167d                	addi	a2,a2,-1
    80200764:	f675                	bnez	a2,80200750 <strncmp+0x8>
    if(n == 0) return 0;
    80200766:	4501                	li	a0,0
    80200768:	a801                	j	80200778 <strncmp+0x30>
    8020076a:	4501                	li	a0,0
    8020076c:	a031                	j	80200778 <strncmp+0x30>
    return (uint8)*a - (uint8)*b;
    8020076e:	00054503          	lbu	a0,0(a0)
    80200772:	0005c783          	lbu	a5,0(a1)
    80200776:	9d1d                	subw	a0,a0,a5
}
    80200778:	6422                	ld	s0,8(sp)
    8020077a:	0141                	addi	sp,sp,16
    8020077c:	8082                	ret

000000008020077e <strncpy>:
char *strncpy(char *d, const char *s, int n){
    8020077e:	1141                	addi	sp,sp,-16
    80200780:	e422                	sd	s0,8(sp)
    80200782:	0800                	addi	s0,sp,16
    char *r=d;
    while(n-- > 0 && (*d++ = *s++) != 0) ;
    80200784:	87aa                	mv	a5,a0
    80200786:	86b2                	mv	a3,a2
    80200788:	367d                	addiw	a2,a2,-1
    8020078a:	02d05563          	blez	a3,802007b4 <strncpy+0x36>
    8020078e:	0785                	addi	a5,a5,1
    80200790:	0005c703          	lbu	a4,0(a1)
    80200794:	fee78fa3          	sb	a4,-1(a5)
    80200798:	0585                	addi	a1,a1,1
    8020079a:	f775                	bnez	a4,80200786 <strncpy+0x8>
    while(n-- > 0) *d++ = 0;
    8020079c:	873e                	mv	a4,a5
    8020079e:	9fb5                	addw	a5,a5,a3
    802007a0:	37fd                	addiw	a5,a5,-1
    802007a2:	00c05963          	blez	a2,802007b4 <strncpy+0x36>
    802007a6:	0705                	addi	a4,a4,1
    802007a8:	fe070fa3          	sb	zero,-1(a4)
    802007ac:	40e786bb          	subw	a3,a5,a4
    802007b0:	fed04be3          	bgtz	a3,802007a6 <strncpy+0x28>
    return r;
}
    802007b4:	6422                	ld	s0,8(sp)
    802007b6:	0141                	addi	sp,sp,16
    802007b8:	8082                	ret

00000000802007ba <strlen>:
int strlen(const char *s){ int n=0; while(s[n]) n++; return n; }
    802007ba:	1141                	addi	sp,sp,-16
    802007bc:	e422                	sd	s0,8(sp)
    802007be:	0800                	addi	s0,sp,16
    802007c0:	00054783          	lbu	a5,0(a0)
    802007c4:	cf91                	beqz	a5,802007e0 <strlen+0x26>
    802007c6:	0505                	addi	a0,a0,1
    802007c8:	87aa                	mv	a5,a0
    802007ca:	86be                	mv	a3,a5
    802007cc:	0785                	addi	a5,a5,1
    802007ce:	fff7c703          	lbu	a4,-1(a5)
    802007d2:	ff65                	bnez	a4,802007ca <strlen+0x10>
    802007d4:	40a6853b          	subw	a0,a3,a0
    802007d8:	2505                	addiw	a0,a0,1
    802007da:	6422                	ld	s0,8(sp)
    802007dc:	0141                	addi	sp,sp,16
    802007de:	8082                	ret
    802007e0:	4501                	li	a0,0
    802007e2:	bfe5                	j	802007da <strlen+0x20>

00000000802007e4 <sbi_putchar>:
 * NOTE: the LEGACY console extension (EID 0x01) is deprecated and is disabled
 * in recent OpenSBI. Use DBCN (Debug Console, EID 0x4442434E) and fall back to
 * legacy only if DBCN is unavailable. Students hit this: an early sbi_putchar
 * that silently does nothing makes a boot panic invisible. */
void sbi_putchar(int c)
{
    802007e4:	1141                	addi	sp,sp,-16
    802007e6:	e422                	sd	s0,8(sp)
    802007e8:	0800                	addi	s0,sp,16
    802007ea:	87aa                	mv	a5,a0
    unsigned char ch = (unsigned char)c;
    /* DBCN console_write_byte = EID 0x4442434E, FID 2 */
    struct sbiret r = sbi_call(0x4442434E, 2, ch, 0, 0);
    802007ec:	0ff57513          	zext.b	a0,a0
    register long r_a1 asm("a1") = a1;
    802007f0:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    802007f2:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    802007f4:	4809                	li	a6,2
    register long r_a7 asm("a7") = eid;
    802007f6:	444248b7          	lui	a7,0x44424
    802007fa:	34e88893          	addi	a7,a7,846 # 4442434e <_entry-0x3bddbcb2>
    asm volatile ("ecall"
    802007fe:	00000073          	ecall
    if (r.error != 0)
    80200802:	e501                	bnez	a0,8020080a <sbi_putchar+0x26>
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
}
    80200804:	6422                	ld	s0,8(sp)
    80200806:	0141                	addi	sp,sp,16
    80200808:	8082                	ret
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
    8020080a:	853e                	mv	a0,a5
    register long r_a1 asm("a1") = a1;
    8020080c:	4581                	li	a1,0
    register long r_a6 asm("a6") = fid;
    8020080e:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    80200810:	4885                	li	a7,1
    asm volatile ("ecall"
    80200812:	00000073          	ecall
}
    80200816:	b7fd                	j	80200804 <sbi_putchar+0x20>

0000000080200818 <sbi_set_timer>:

/* TIME extension: set the next timer interrupt (absolute time). */
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    80200818:	1141                	addi	sp,sp,-16
    8020081a:	e422                	sd	s0,8(sp)
    8020081c:	0800                	addi	s0,sp,16
    register long r_a1 asm("a1") = a1;
    8020081e:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    80200820:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    80200822:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    80200824:	544958b7          	lui	a7,0x54495
    80200828:	d4588893          	addi	a7,a7,-699 # 54494d45 <_entry-0x2bd6b2bb>
    asm volatile ("ecall"
    8020082c:	00000073          	ecall
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    80200830:	6422                	ld	s0,8(sp)
    80200832:	0141                	addi	sp,sp,16
    80200834:	8082                	ret

0000000080200836 <sbi_hart_start>:

/* HSM extension: start a secondary hart at `addr` (L9, SMP). */
long sbi_hart_start(uint64 hartid, uint64 addr, uint64 opaque)
{
    80200836:	1141                	addi	sp,sp,-16
    80200838:	e422                	sd	s0,8(sp)
    8020083a:	0800                	addi	s0,sp,16
    register long r_a6 asm("a6") = fid;
    8020083c:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    8020083e:	004858b7          	lui	a7,0x485
    80200842:	34d88893          	addi	a7,a7,845 # 48534d <_entry-0x7fd7acb3>
    asm volatile ("ecall"
    80200846:	00000073          	ecall
    return sbi_call(0x48534D, 0, hartid, addr, opaque).error;
}
    8020084a:	6422                	ld	s0,8(sp)
    8020084c:	0141                	addi	sp,sp,16
    8020084e:	8082                	ret

0000000080200850 <be32>:
    uint32 off_mem_rsvmap, version, last_comp_version;
    uint32 boot_cpuid_phys, size_dt_strings, size_dt_struct;
};

/* The FDT is big-endian; RISC-V is little-endian. Swap on every read. */
static uint32 be32(uint32 x) {
    80200850:	1141                	addi	sp,sp,-16
    80200852:	e422                	sd	s0,8(sp)
    80200854:	0800                	addi	s0,sp,16
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    80200856:	0185179b          	slliw	a5,a0,0x18
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    8020085a:	0185571b          	srliw	a4,a0,0x18
    8020085e:	8fd9                	or	a5,a5,a4
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    80200860:	0085171b          	slliw	a4,a0,0x8
    80200864:	00ff06b7          	lui	a3,0xff0
    80200868:	8f75                	and	a4,a4,a3
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    8020086a:	8fd9                	or	a5,a5,a4
    8020086c:	0085551b          	srliw	a0,a0,0x8
    80200870:	6741                	lui	a4,0x10
    80200872:	f0070713          	addi	a4,a4,-256 # ff00 <_entry-0x801f0100>
    80200876:	8d79                	and	a0,a0,a4
    80200878:	8d5d                	or	a0,a0,a5
}
    8020087a:	2501                	sext.w	a0,a0
    8020087c:	6422                	ld	s0,8(sp)
    8020087e:	0141                	addi	sp,sp,16
    80200880:	8082                	ret

0000000080200882 <streq>:
#define MAXDEPTH 16

struct fdt_info fdt;                 /* what we discovered about this board */
static const char *strings;          /* strings block base */

static int streq(const char *a, const char *b) {
    80200882:	1141                	addi	sp,sp,-16
    80200884:	e422                	sd	s0,8(sp)
    80200886:	0800                	addi	s0,sp,16
    while (*a && *a == *b) { a++; b++; }
    80200888:	00054783          	lbu	a5,0(a0)
    8020088c:	cb91                	beqz	a5,802008a0 <streq+0x1e>
    8020088e:	0005c703          	lbu	a4,0(a1)
    80200892:	00f71763          	bne	a4,a5,802008a0 <streq+0x1e>
    80200896:	0505                	addi	a0,a0,1
    80200898:	0585                	addi	a1,a1,1
    8020089a:	00054783          	lbu	a5,0(a0)
    8020089e:	fbe5                	bnez	a5,8020088e <streq+0xc>
    return *a == *b;
    802008a0:	0005c503          	lbu	a0,0(a1)
    802008a4:	8d1d                	sub	a0,a0,a5
}
    802008a6:	00153513          	seqz	a0,a0
    802008aa:	6422                	ld	s0,8(sp)
    802008ac:	0141                	addi	sp,sp,16
    802008ae:	8082                	ret

00000000802008b0 <strlist_has>:
/* does `list` (a NUL-separated string list of length len) contain `want`? */
static int strlist_has(const char *list, int len, const char *want) {
    int i = 0;
    while (i < len) {
    802008b0:	04b05f63          	blez	a1,8020090e <strlist_has+0x5e>
static int strlist_has(const char *list, int len, const char *want) {
    802008b4:	7139                	addi	sp,sp,-64
    802008b6:	fc06                	sd	ra,56(sp)
    802008b8:	f822                	sd	s0,48(sp)
    802008ba:	f426                	sd	s1,40(sp)
    802008bc:	f04a                	sd	s2,32(sp)
    802008be:	ec4e                	sd	s3,24(sp)
    802008c0:	e852                	sd	s4,16(sp)
    802008c2:	e456                	sd	s5,8(sp)
    802008c4:	0080                	addi	s0,sp,64
    802008c6:	8a2a                	mv	s4,a0
    802008c8:	89ae                	mv	s3,a1
    802008ca:	8ab2                	mv	s5,a2
    int i = 0;
    802008cc:	4481                	li	s1,0
    802008ce:	a021                	j	802008d6 <strlist_has+0x26>
        if (streq(&list[i], want)) return 1;
        while (i < len && list[i]) i++;
        i++;
    802008d0:	2485                	addiw	s1,s1,1
    while (i < len) {
    802008d2:	0334d563          	bge	s1,s3,802008fc <strlist_has+0x4c>
        if (streq(&list[i], want)) return 1;
    802008d6:	009a0933          	add	s2,s4,s1
    802008da:	85d6                	mv	a1,s5
    802008dc:	854a                	mv	a0,s2
    802008de:	00000097          	auipc	ra,0x0
    802008e2:	fa4080e7          	jalr	-92(ra) # 80200882 <streq>
    802008e6:	e515                	bnez	a0,80200912 <strlist_has+0x62>
        while (i < len && list[i]) i++;
    802008e8:	ff34d4e3          	bge	s1,s3,802008d0 <strlist_has+0x20>
    802008ec:	87ca                	mv	a5,s2
    802008ee:	0007c703          	lbu	a4,0(a5)
    802008f2:	df79                	beqz	a4,802008d0 <strlist_has+0x20>
    802008f4:	2485                	addiw	s1,s1,1
    802008f6:	0785                	addi	a5,a5,1
    802008f8:	fe999be3          	bne	s3,s1,802008ee <strlist_has+0x3e>
    }
    return 0;
}
    802008fc:	70e2                	ld	ra,56(sp)
    802008fe:	7442                	ld	s0,48(sp)
    80200900:	74a2                	ld	s1,40(sp)
    80200902:	7902                	ld	s2,32(sp)
    80200904:	69e2                	ld	s3,24(sp)
    80200906:	6a42                	ld	s4,16(sp)
    80200908:	6aa2                	ld	s5,8(sp)
    8020090a:	6121                	addi	sp,sp,64
    8020090c:	8082                	ret
    return 0;
    8020090e:	4501                	li	a0,0
}
    80200910:	8082                	ret
        if (streq(&list[i], want)) return 1;
    80200912:	4505                	li	a0,1
    80200914:	b7e5                	j	802008fc <strlist_has+0x4c>

0000000080200916 <fdt_init>:
 *
 * Also: a node's `reg` is decoded with its PARENT's #address-cells/#size-cells,
 * not its own. We keep a small stack of them.
 */
void fdt_init(uint64 fdt_pa)
{
    80200916:	712d                	addi	sp,sp,-288
    80200918:	ee06                	sd	ra,280(sp)
    8020091a:	ea22                	sd	s0,272(sp)
    8020091c:	fdce                	sd	s3,248(sp)
    8020091e:	1200                	addi	s0,sp,288
    80200920:	89aa                	mv	s3,a0
    struct fdt_header *h = (struct fdt_header *)fdt_pa;

    if (be32(h->magic) != FDT_MAGIC)
    80200922:	4108                	lw	a0,0(a0)
    80200924:	00000097          	auipc	ra,0x0
    80200928:	f2c080e7          	jalr	-212(ra) # 80200850 <be32>
    8020092c:	2501                	sext.w	a0,a0
    8020092e:	d00e07b7          	lui	a5,0xd00e0
    80200932:	eed78793          	addi	a5,a5,-275 # ffffffffd00dfeed <uart+0xffffffff4fd85ebd>
    80200936:	0cf51263          	bne	a0,a5,802009fa <fdt_init+0xe4>
    8020093a:	e626                	sd	s1,264(sp)
    8020093c:	e24a                	sd	s2,256(sp)
    8020093e:	f9d2                	sd	s4,240(sp)
    80200940:	f5d6                	sd	s5,232(sp)
    80200942:	f1da                	sd	s6,224(sp)
    80200944:	edde                	sd	s7,216(sp)
    80200946:	e9e2                	sd	s8,208(sp)
    80200948:	e1ea                	sd	s10,192(sp)
        panic("fdt: bad magic - is a1 really the device tree?");

    strings = (const char *)(fdt_pa + be32(h->off_dt_strings));
    8020094a:	00c9a503          	lw	a0,12(s3)
    8020094e:	00000097          	auipc	ra,0x0
    80200952:	f02080e7          	jalr	-254(ra) # 80200850 <be32>
    80200956:	02051b13          	slli	s6,a0,0x20
    8020095a:	020b5b13          	srli	s6,s6,0x20
    8020095e:	9b4e                	add	s6,s6,s3
    const uint32 *p = (const uint32 *)(fdt_pa + be32(h->off_dt_struct));
    80200960:	0089a503          	lw	a0,8(s3)
    80200964:	00000097          	auipc	ra,0x0
    80200968:	eec080e7          	jalr	-276(ra) # 80200850 <be32>
    8020096c:	02051493          	slli	s1,a0,0x20
    80200970:	9081                	srli	s1,s1,0x20
    80200972:	94ce                	add	s1,s1,s3

    fdt.blob = fdt_pa;
    80200974:	0002b917          	auipc	s2,0x2b
    80200978:	6a490913          	addi	s2,s2,1700 # 8022c018 <fdt>
    8020097c:	01393023          	sd	s3,0(s2)
    fdt.blob_size = be32(h->totalsize);
    80200980:	0049a503          	lw	a0,4(s3)
    80200984:	00000097          	auipc	ra,0x0
    80200988:	ecc080e7          	jalr	-308(ra) # 80200850 <be32>
    8020098c:	1502                	slli	a0,a0,0x20
    8020098e:	9101                	srli	a0,a0,0x20
    80200990:	00a93423          	sd	a0,8(s2)
    fdt.ncpu = 0;
    80200994:	0a092023          	sw	zero,160(s2)
    fdt.uart_base = 0; fdt.plic_base = 0; fdt.uart_irq = 0;
    80200998:	00093823          	sd	zero,16(s2)
    8020099c:	00093c23          	sd	zero,24(s2)
    802009a0:	02092023          	sw	zero,32(s2)
    fdt.nvirtio = 0;
    802009a4:	08092423          	sw	zero,136(s2)
    fdt.mem_base = 0;  fdt.mem_size = 0;
    802009a8:	08093823          	sd	zero,144(s2)
    802009ac:	08093c23          	sd	zero,152(s2)

    /* #address-cells / #size-cells, one slot per depth. Defaults per spec. */
    int ac[MAXDEPTH], sc[MAXDEPTH];
    ac[0] = 2; sc[0] = 2;
    802009b0:	4789                	li	a5,2
    802009b2:	f4f42823          	sw	a5,-176(s0)
    802009b6:	f0f42823          	sw	a5,-240(s0)

    /* properties buffered for the node we are currently inside */
    int    kind = PEND_NONE;
    int    have_reg = 0;
    uint64 reg_base = 0, reg_size = 0;
    int    have_irq = 0, irq = 0;
    802009ba:	ee043423          	sd	zero,-280(s0)
    802009be:	ee043823          	sd	zero,-272(s0)
    uint64 reg_base = 0, reg_size = 0;
    802009c2:	f0043023          	sd	zero,-256(s0)
    802009c6:	f0043423          	sd	zero,-248(s0)
    int    have_reg = 0;
    802009ca:	4d01                	li	s10,0
    int    kind = PEND_NONE;
    802009cc:	4c01                	li	s8,0
    int cpus_depth = -1;
    802009ce:	5bfd                	li	s7,-1
    int depth = 0;
    802009d0:	4981                	li	s3,0
    802009d2:	4aa5                	li	s5,9
    802009d4:	00009917          	auipc	s2,0x9
    802009d8:	5f890913          	addi	s2,s2,1528 # 80209fcc <digits+0x14>

    for (;;) {
        uint32 tok = be32(*p++);
    802009dc:	00448a13          	addi	s4,s1,4
    802009e0:	4088                	lw	a0,0(s1)
    802009e2:	00000097          	auipc	ra,0x0
    802009e6:	e6e080e7          	jalr	-402(ra) # 80200850 <be32>
    802009ea:	2501                	sext.w	a0,a0

        if (tok == FDT_END) break;
    802009ec:	50aaef63          	bltu	s5,a0,80200f0a <fdt_init+0x5f4>
    802009f0:	050a                	slli	a0,a0,0x2
    802009f2:	954a                	add	a0,a0,s2
    802009f4:	411c                	lw	a5,0(a0)
    802009f6:	97ca                	add	a5,a5,s2
    802009f8:	8782                	jr	a5
    802009fa:	e626                	sd	s1,264(sp)
    802009fc:	e24a                	sd	s2,256(sp)
    802009fe:	f9d2                	sd	s4,240(sp)
    80200a00:	f5d6                	sd	s5,232(sp)
    80200a02:	f1da                	sd	s6,224(sp)
    80200a04:	edde                	sd	s7,216(sp)
    80200a06:	e9e2                	sd	s8,208(sp)
    80200a08:	e5e6                	sd	s9,200(sp)
    80200a0a:	e1ea                	sd	s10,192(sp)
    80200a0c:	fd6e                	sd	s11,184(sp)
        panic("fdt: bad magic - is a1 really the device tree?");
    80200a0e:	00009517          	auipc	a0,0x9
    80200a12:	83a50513          	addi	a0,a0,-1990 # 80209248 <etext+0x248>
    80200a16:	00000097          	auipc	ra,0x0
    80200a1a:	c00080e7          	jalr	-1024(ra) # 80200616 <panic>
        uint32 tok = be32(*p++);
    80200a1e:	84d2                	mv	s1,s4
    80200a20:	bf75                	j	802009dc <fdt_init+0xc6>
        if (tok == FDT_BEGIN_NODE) {
            const char *name = (const char *)p;
            int len = 0; while (name[len]) len++;
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */

            depth++;
    80200a22:	89e2                	mv	s3,s8
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
            sc[depth] = sc[depth - 1];

            /* start a fresh property buffer for this node */
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
            have_irq = 0; irq = 0;
    80200a24:	ee043423          	sd	zero,-280(s0)
    80200a28:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200a2c:	f0043023          	sd	zero,-256(s0)
    80200a30:	f0043423          	sd	zero,-248(s0)
    80200a34:	4d01                	li	s10,0
    80200a36:	4c01                	li	s8,0
    80200a38:	b755                	j	802009dc <fdt_init+0xc6>
        if (tok == FDT_PROP) {
            uint32 len     = be32(*p++);
            uint32 nameoff = be32(*p++);
            const char *pname = &strings[nameoff];
            const uint32 *val = p;
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a3a:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
                else if (strlist_has(c, len, "riscv,plic0") ||
                         strlist_has(c, len, "sifive,plic-1.0.0"))
                    kind = PEND_PLIC;
                else if (strlist_has(c, len, "virtio,mmio"))
                    kind = PEND_VIRTIO;
    80200a3e:	4c0d                	li	s8,3
    80200a40:	6cae                	ld	s9,200(sp)
    80200a42:	7dea                	ld	s11,184(sp)
    80200a44:	bf61                	j	802009dc <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a46:	ef843483          	ld	s1,-264(s0)
            } else if (streq(pname, "device_type")) {
                if (strlist_has((const char *)val, len, "memory"))
                    kind = PEND_MEM;
    80200a4a:	4c11                	li	s8,4
    80200a4c:	6cae                	ld	s9,200(sp)
    80200a4e:	7dea                	ld	s11,184(sp)
    80200a50:	b771                	j	802009dc <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a52:	ef843483          	ld	s1,-264(s0)
    80200a56:	6cae                	ld	s9,200(sp)
    80200a58:	7dea                	ld	s11,184(sp)
    80200a5a:	b749                	j	802009dc <fdt_init+0xc6>
    80200a5c:	ef843483          	ld	s1,-264(s0)
    80200a60:	6cae                	ld	s9,200(sp)
    80200a62:	7dea                	ld	s11,184(sp)
    80200a64:	bfa5                	j	802009dc <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200a66:	0044c783          	lbu	a5,4(s1)
    80200a6a:	c7d9                	beqz	a5,80200af8 <fdt_init+0x1e2>
    80200a6c:	0495                	addi	s1,s1,5
    80200a6e:	87a6                	mv	a5,s1
    80200a70:	86be                	mv	a3,a5
    80200a72:	0785                	addi	a5,a5,1
    80200a74:	fff7c703          	lbu	a4,-1(a5)
    80200a78:	ff65                	bnez	a4,80200a70 <fdt_init+0x15a>
    80200a7a:	9e85                	subw	a3,a3,s1
    80200a7c:	2685                	addiw	a3,a3,1 # ff0001 <_entry-0x7f20ffff>
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */
    80200a7e:	2691                	addiw	a3,a3,4
    80200a80:	41f6d49b          	sraiw	s1,a3,0x1f
    80200a84:	01e4d49b          	srliw	s1,s1,0x1e
    80200a88:	9cb5                	addw	s1,s1,a3
    80200a8a:	4024d49b          	sraiw	s1,s1,0x2
    80200a8e:	048a                	slli	s1,s1,0x2
    80200a90:	94d2                	add	s1,s1,s4
            depth++;
    80200a92:	00198c1b          	addiw	s8,s3,1
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200a96:	47bd                	li	a5,15
    80200a98:	0787c263          	blt	a5,s8,80200afc <fdt_init+0x1e6>
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
    80200a9c:	00299713          	slli	a4,s3,0x2
    80200aa0:	f9070793          	addi	a5,a4,-112
    80200aa4:	00878733          	add	a4,a5,s0
    80200aa8:	fc072683          	lw	a3,-64(a4)
    80200aac:	002c1793          	slli	a5,s8,0x2
    80200ab0:	f9078793          	addi	a5,a5,-112
    80200ab4:	97a2                	add	a5,a5,s0
    80200ab6:	fcd7a023          	sw	a3,-64(a5)
            sc[depth] = sc[depth - 1];
    80200aba:	f8072703          	lw	a4,-128(a4)
    80200abe:	f8e7a023          	sw	a4,-128(a5)
            if (streq(name, "cpus")) cpus_depth = depth;
    80200ac2:	00008597          	auipc	a1,0x8
    80200ac6:	7ce58593          	addi	a1,a1,1998 # 80209290 <etext+0x290>
    80200aca:	8552                	mv	a0,s4
    80200acc:	00000097          	auipc	ra,0x0
    80200ad0:	db6080e7          	jalr	-586(ra) # 80200882 <streq>
    80200ad4:	c111                	beqz	a0,80200ad8 <fdt_init+0x1c2>
    80200ad6:	8be2                	mv	s7,s8
            if (cpus_depth > 0 && depth == cpus_depth + 1 && startswith(name, "cpu@"))
    80200ad8:	f57055e3          	blez	s7,80200a22 <fdt_init+0x10c>
    80200adc:	03798a63          	beq	s3,s7,80200b10 <fdt_init+0x1fa>
            depth++;
    80200ae0:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200ae2:	ee043423          	sd	zero,-280(s0)
    80200ae6:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200aea:	f0043023          	sd	zero,-256(s0)
    80200aee:	f0043423          	sd	zero,-248(s0)
    80200af2:	4d01                	li	s10,0
    80200af4:	4c01                	li	s8,0
    80200af6:	b5dd                	j	802009dc <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200af8:	4681                	li	a3,0
    80200afa:	b751                	j	80200a7e <fdt_init+0x168>
    80200afc:	e5e6                	sd	s9,200(sp)
    80200afe:	fd6e                	sd	s11,184(sp)
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200b00:	00008517          	auipc	a0,0x8
    80200b04:	77850513          	addi	a0,a0,1912 # 80209278 <etext+0x278>
    80200b08:	00000097          	auipc	ra,0x0
    80200b0c:	b0e080e7          	jalr	-1266(ra) # 80200616 <panic>
    80200b10:	00008797          	auipc	a5,0x8
    80200b14:	73078793          	addi	a5,a5,1840 # 80209240 <etext+0x240>
    while (*pre) { if (*s++ != *pre++) return 0; }
    80200b18:	0007c703          	lbu	a4,0(a5)
    80200b1c:	46070f63          	beqz	a4,80200f9a <fdt_init+0x684>
    80200b20:	0a05                	addi	s4,s4,1
    80200b22:	0785                	addi	a5,a5,1
    80200b24:	fffa4683          	lbu	a3,-1(s4)
    80200b28:	fee688e3          	beq	a3,a4,80200b18 <fdt_init+0x202>
            depth++;
    80200b2c:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200b2e:	ee043423          	sd	zero,-280(s0)
    80200b32:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200b36:	f0043023          	sd	zero,-256(s0)
    80200b3a:	f0043423          	sd	zero,-248(s0)
    80200b3e:	4d01                	li	s10,0
    80200b40:	4c01                	li	s8,0
    80200b42:	bd69                	j	802009dc <fdt_init+0xc6>
            if (have_reg && kind != PEND_NONE) {
    80200b44:	040d0863          	beqz	s10,80200b94 <fdt_init+0x27e>
    80200b48:	040c0663          	beqz	s8,80200b94 <fdt_init+0x27e>
                switch (kind) {
    80200b4c:	478d                	li	a5,3
    80200b4e:	06fc0f63          	beq	s8,a5,80200bcc <fdt_init+0x2b6>
    80200b52:	0387c463          	blt	a5,s8,80200b7a <fdt_init+0x264>
    80200b56:	4785                	li	a5,1
    80200b58:	04fc0563          	beq	s8,a5,80200ba2 <fdt_init+0x28c>
    80200b5c:	4789                	li	a5,2
    80200b5e:	02fc1b63          	bne	s8,a5,80200b94 <fdt_init+0x27e>
                case PEND_PLIC:   if (!fdt.plic_base) fdt.plic_base = reg_base; break;
    80200b62:	0002b797          	auipc	a5,0x2b
    80200b66:	4ce7b783          	ld	a5,1230(a5) # 8022c030 <fdt+0x18>
    80200b6a:	e78d                	bnez	a5,80200b94 <fdt_init+0x27e>
    80200b6c:	f0843703          	ld	a4,-248(s0)
    80200b70:	0002b797          	auipc	a5,0x2b
    80200b74:	4ce7b023          	sd	a4,1216(a5) # 8022c030 <fdt+0x18>
    80200b78:	a831                	j	80200b94 <fdt_init+0x27e>
                switch (kind) {
    80200b7a:	4791                	li	a5,4
    80200b7c:	00fc1c63          	bne	s8,a5,80200b94 <fdt_init+0x27e>
                case PEND_MEM:    fdt.mem_base = reg_base; fdt.mem_size = reg_size; break;
    80200b80:	0002b797          	auipc	a5,0x2b
    80200b84:	49878793          	addi	a5,a5,1176 # 8022c018 <fdt>
    80200b88:	f0843703          	ld	a4,-248(s0)
    80200b8c:	ebd8                	sd	a4,144(a5)
    80200b8e:	f0043703          	ld	a4,-256(s0)
    80200b92:	efd8                	sd	a4,152(a5)
            if (depth == cpus_depth) cpus_depth = -1;
    80200b94:	09798163          	beq	s3,s7,80200c16 <fdt_init+0x300>
            depth--;
    80200b98:	39fd                	addiw	s3,s3,-1
        uint32 tok = be32(*p++);
    80200b9a:	84d2                	mv	s1,s4
            kind = PEND_NONE; have_reg = 0;
    80200b9c:	4d01                	li	s10,0
    80200b9e:	4c01                	li	s8,0
            continue;
    80200ba0:	bd35                	j	802009dc <fdt_init+0xc6>
                    if (!fdt.uart_base) {
    80200ba2:	0002b797          	auipc	a5,0x2b
    80200ba6:	4867b783          	ld	a5,1158(a5) # 8022c028 <fdt+0x10>
    80200baa:	f7ed                	bnez	a5,80200b94 <fdt_init+0x27e>
                        fdt.uart_base = reg_base;
    80200bac:	f0843703          	ld	a4,-248(s0)
    80200bb0:	0002b797          	auipc	a5,0x2b
    80200bb4:	46e7bc23          	sd	a4,1144(a5) # 8022c028 <fdt+0x10>
                        if (have_irq) fdt.uart_irq = irq;
    80200bb8:	ef043783          	ld	a5,-272(s0)
    80200bbc:	dfe1                	beqz	a5,80200b94 <fdt_init+0x27e>
    80200bbe:	ee843703          	ld	a4,-280(s0)
    80200bc2:	0002b797          	auipc	a5,0x2b
    80200bc6:	46e7ab23          	sw	a4,1142(a5) # 8022c038 <fdt+0x20>
    80200bca:	b7e9                	j	80200b94 <fdt_init+0x27e>
                    if (fdt.nvirtio < FDT_MAX_VIRTIO) {
    80200bcc:	0002b797          	auipc	a5,0x2b
    80200bd0:	4d47a783          	lw	a5,1236(a5) # 8022c0a0 <fdt+0x88>
    80200bd4:	471d                	li	a4,7
    80200bd6:	faf74fe3          	blt	a4,a5,80200b94 <fdt_init+0x27e>
                        fdt.virtio_base[fdt.nvirtio] = reg_base;
    80200bda:	00478693          	addi	a3,a5,4
    80200bde:	068e                	slli	a3,a3,0x3
    80200be0:	0002b717          	auipc	a4,0x2b
    80200be4:	43870713          	addi	a4,a4,1080 # 8022c018 <fdt>
    80200be8:	9736                	add	a4,a4,a3
    80200bea:	f0843683          	ld	a3,-248(s0)
    80200bee:	e714                	sd	a3,8(a4)
                        fdt.virtio_irq[fdt.nvirtio]  = have_irq ? irq : 0;
    80200bf0:	ef043703          	ld	a4,-272(s0)
    80200bf4:	863a                	mv	a2,a4
    80200bf6:	c319                	beqz	a4,80200bfc <fdt_init+0x2e6>
    80200bf8:	ee843603          	ld	a2,-280(s0)
    80200bfc:	0002b697          	auipc	a3,0x2b
    80200c00:	41c68693          	addi	a3,a3,1052 # 8022c018 <fdt>
    80200c04:	01878713          	addi	a4,a5,24
    80200c08:	070a                	slli	a4,a4,0x2
    80200c0a:	9736                	add	a4,a4,a3
    80200c0c:	c710                	sw	a2,8(a4)
                        fdt.nvirtio++;
    80200c0e:	2785                	addiw	a5,a5,1
    80200c10:	08f6a423          	sw	a5,136(a3)
    80200c14:	b741                	j	80200b94 <fdt_init+0x27e>
            if (depth == cpus_depth) cpus_depth = -1;
    80200c16:	5bfd                	li	s7,-1
    80200c18:	b741                	j	80200b98 <fdt_init+0x282>
    80200c1a:	e5e6                	sd	s9,200(sp)
    80200c1c:	fd6e                	sd	s11,184(sp)
            uint32 len     = be32(*p++);
    80200c1e:	40c8                	lw	a0,4(s1)
    80200c20:	00000097          	auipc	ra,0x0
    80200c24:	c30080e7          	jalr	-976(ra) # 80200850 <be32>
    80200c28:	00050c9b          	sext.w	s9,a0
            uint32 nameoff = be32(*p++);
    80200c2c:	00c48d93          	addi	s11,s1,12
    80200c30:	4488                	lw	a0,8(s1)
    80200c32:	00000097          	auipc	ra,0x0
    80200c36:	c1e080e7          	jalr	-994(ra) # 80200850 <be32>
            const char *pname = &strings[nameoff];
    80200c3a:	02051a13          	slli	s4,a0,0x20
    80200c3e:	020a5a13          	srli	s4,s4,0x20
    80200c42:	9a5a                	add	s4,s4,s6
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c44:	003c879b          	addiw	a5,s9,3
    80200c48:	0027d79b          	srliw	a5,a5,0x2
    80200c4c:	078a                	slli	a5,a5,0x2
    80200c4e:	97ee                	add	a5,a5,s11
    80200c50:	eef43c23          	sd	a5,-264(s0)
            if (streq(pname, "#address-cells")) {
    80200c54:	00008597          	auipc	a1,0x8
    80200c58:	64458593          	addi	a1,a1,1604 # 80209298 <etext+0x298>
    80200c5c:	8552                	mv	a0,s4
    80200c5e:	00000097          	auipc	ra,0x0
    80200c62:	c24080e7          	jalr	-988(ra) # 80200882 <streq>
    80200c66:	c11d                	beqz	a0,80200c8c <fdt_init+0x376>
                ac[depth] = be32(val[0]);
    80200c68:	44c8                	lw	a0,12(s1)
    80200c6a:	00000097          	auipc	ra,0x0
    80200c6e:	be6080e7          	jalr	-1050(ra) # 80200850 <be32>
    80200c72:	00299793          	slli	a5,s3,0x2
    80200c76:	f9078713          	addi	a4,a5,-112
    80200c7a:	008707b3          	add	a5,a4,s0
    80200c7e:	fca7a023          	sw	a0,-64(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c82:	ef843483          	ld	s1,-264(s0)
    80200c86:	6cae                	ld	s9,200(sp)
    80200c88:	7dea                	ld	s11,184(sp)
    80200c8a:	bb89                	j	802009dc <fdt_init+0xc6>
            } else if (streq(pname, "#size-cells")) {
    80200c8c:	00008597          	auipc	a1,0x8
    80200c90:	61c58593          	addi	a1,a1,1564 # 802092a8 <etext+0x2a8>
    80200c94:	8552                	mv	a0,s4
    80200c96:	00000097          	auipc	ra,0x0
    80200c9a:	bec080e7          	jalr	-1044(ra) # 80200882 <streq>
    80200c9e:	c115                	beqz	a0,80200cc2 <fdt_init+0x3ac>
                sc[depth] = be32(val[0]);
    80200ca0:	44c8                	lw	a0,12(s1)
    80200ca2:	00000097          	auipc	ra,0x0
    80200ca6:	bae080e7          	jalr	-1106(ra) # 80200850 <be32>
    80200caa:	00299793          	slli	a5,s3,0x2
    80200cae:	f9078793          	addi	a5,a5,-112
    80200cb2:	97a2                	add	a5,a5,s0
    80200cb4:	f8a7a023          	sw	a0,-128(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cb8:	ef843483          	ld	s1,-264(s0)
    80200cbc:	6cae                	ld	s9,200(sp)
    80200cbe:	7dea                	ld	s11,184(sp)
    80200cc0:	bb31                	j	802009dc <fdt_init+0xc6>
            } else if (streq(pname, "compatible")) {
    80200cc2:	00008597          	auipc	a1,0x8
    80200cc6:	5f658593          	addi	a1,a1,1526 # 802092b8 <etext+0x2b8>
    80200cca:	8552                	mv	a0,s4
    80200ccc:	00000097          	auipc	ra,0x0
    80200cd0:	bb6080e7          	jalr	-1098(ra) # 80200882 <streq>
    80200cd4:	c961                	beqz	a0,80200da4 <fdt_init+0x48e>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550") ||
    80200cd6:	2c81                	sext.w	s9,s9
    80200cd8:	00008617          	auipc	a2,0x8
    80200cdc:	5f060613          	addi	a2,a2,1520 # 802092c8 <etext+0x2c8>
    80200ce0:	85e6                	mv	a1,s9
    80200ce2:	856e                	mv	a0,s11
    80200ce4:	00000097          	auipc	ra,0x0
    80200ce8:	bcc080e7          	jalr	-1076(ra) # 802008b0 <strlist_has>
    80200cec:	c519                	beqz	a0,80200cfa <fdt_init+0x3e4>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cee:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cf2:	4c05                	li	s8,1
    80200cf4:	6cae                	ld	s9,200(sp)
    80200cf6:	7dea                	ld	s11,184(sp)
    80200cf8:	b1d5                	j	802009dc <fdt_init+0xc6>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550") ||
    80200cfa:	00008617          	auipc	a2,0x8
    80200cfe:	5de60613          	addi	a2,a2,1502 # 802092d8 <etext+0x2d8>
    80200d02:	85e6                	mv	a1,s9
    80200d04:	856e                	mv	a0,s11
    80200d06:	00000097          	auipc	ra,0x0
    80200d0a:	baa080e7          	jalr	-1110(ra) # 802008b0 <strlist_has>
    80200d0e:	c519                	beqz	a0,80200d1c <fdt_init+0x406>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d10:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200d14:	4c05                	li	s8,1
    80200d16:	6cae                	ld	s9,200(sp)
    80200d18:	7dea                	ld	s11,184(sp)
    80200d1a:	b1c9                	j	802009dc <fdt_init+0xc6>
                    strlist_has(c, len, "sifive,uart0"))   /* Lab 12: sifive_u board */
    80200d1c:	00008617          	auipc	a2,0x8
    80200d20:	5c460613          	addi	a2,a2,1476 # 802092e0 <etext+0x2e0>
    80200d24:	85e6                	mv	a1,s9
    80200d26:	856e                	mv	a0,s11
    80200d28:	00000097          	auipc	ra,0x0
    80200d2c:	b88080e7          	jalr	-1144(ra) # 802008b0 <strlist_has>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550") ||
    80200d30:	c519                	beqz	a0,80200d3e <fdt_init+0x428>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d32:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200d36:	4c05                	li	s8,1
    80200d38:	6cae                	ld	s9,200(sp)
    80200d3a:	7dea                	ld	s11,184(sp)
    80200d3c:	b145                	j	802009dc <fdt_init+0xc6>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200d3e:	00008617          	auipc	a2,0x8
    80200d42:	5b260613          	addi	a2,a2,1458 # 802092f0 <etext+0x2f0>
    80200d46:	85e6                	mv	a1,s9
    80200d48:	856e                	mv	a0,s11
    80200d4a:	00000097          	auipc	ra,0x0
    80200d4e:	b66080e7          	jalr	-1178(ra) # 802008b0 <strlist_has>
    80200d52:	c519                	beqz	a0,80200d60 <fdt_init+0x44a>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d54:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d58:	4c09                	li	s8,2
    80200d5a:	6cae                	ld	s9,200(sp)
    80200d5c:	7dea                	ld	s11,184(sp)
    80200d5e:	b9bd                	j	802009dc <fdt_init+0xc6>
                         strlist_has(c, len, "sifive,plic-1.0.0"))
    80200d60:	00008617          	auipc	a2,0x8
    80200d64:	5a060613          	addi	a2,a2,1440 # 80209300 <etext+0x300>
    80200d68:	85e6                	mv	a1,s9
    80200d6a:	856e                	mv	a0,s11
    80200d6c:	00000097          	auipc	ra,0x0
    80200d70:	b44080e7          	jalr	-1212(ra) # 802008b0 <strlist_has>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200d74:	c519                	beqz	a0,80200d82 <fdt_init+0x46c>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d76:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d7a:	4c09                	li	s8,2
    80200d7c:	6cae                	ld	s9,200(sp)
    80200d7e:	7dea                	ld	s11,184(sp)
    80200d80:	b9b1                	j	802009dc <fdt_init+0xc6>
                else if (strlist_has(c, len, "virtio,mmio"))
    80200d82:	00008617          	auipc	a2,0x8
    80200d86:	59660613          	addi	a2,a2,1430 # 80209318 <etext+0x318>
    80200d8a:	85e6                	mv	a1,s9
    80200d8c:	856e                	mv	a0,s11
    80200d8e:	00000097          	auipc	ra,0x0
    80200d92:	b22080e7          	jalr	-1246(ra) # 802008b0 <strlist_has>
    80200d96:	ca0512e3          	bnez	a0,80200a3a <fdt_init+0x124>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d9a:	ef843483          	ld	s1,-264(s0)
    80200d9e:	6cae                	ld	s9,200(sp)
    80200da0:	7dea                	ld	s11,184(sp)
    80200da2:	b92d                	j	802009dc <fdt_init+0xc6>
            } else if (streq(pname, "device_type")) {
    80200da4:	00008597          	auipc	a1,0x8
    80200da8:	58458593          	addi	a1,a1,1412 # 80209328 <etext+0x328>
    80200dac:	8552                	mv	a0,s4
    80200dae:	00000097          	auipc	ra,0x0
    80200db2:	ad4080e7          	jalr	-1324(ra) # 80200882 <streq>
    80200db6:	c115                	beqz	a0,80200dda <fdt_init+0x4c4>
                if (strlist_has((const char *)val, len, "memory"))
    80200db8:	00008617          	auipc	a2,0x8
    80200dbc:	58060613          	addi	a2,a2,1408 # 80209338 <etext+0x338>
    80200dc0:	85e6                	mv	a1,s9
    80200dc2:	856e                	mv	a0,s11
    80200dc4:	00000097          	auipc	ra,0x0
    80200dc8:	aec080e7          	jalr	-1300(ra) # 802008b0 <strlist_has>
    80200dcc:	c6051de3          	bnez	a0,80200a46 <fdt_init+0x130>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200dd0:	ef843483          	ld	s1,-264(s0)
    80200dd4:	6cae                	ld	s9,200(sp)
    80200dd6:	7dea                	ld	s11,184(sp)
    80200dd8:	b111                	j	802009dc <fdt_init+0xc6>
            } else if (streq(pname, "interrupts")) {
    80200dda:	00008597          	auipc	a1,0x8
    80200dde:	56658593          	addi	a1,a1,1382 # 80209340 <etext+0x340>
    80200de2:	8552                	mv	a0,s4
    80200de4:	00000097          	auipc	ra,0x0
    80200de8:	a9e080e7          	jalr	-1378(ra) # 80200882 <streq>
    80200dec:	c50d                	beqz	a0,80200e16 <fdt_init+0x500>
                /* First cell = PLIC source number (qemu virt uses plain
                 * one-cell specifiers for uart and virtio). */
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200dee:	478d                	li	a5,3
    80200df0:	c797f1e3          	bgeu	a5,s9,80200a52 <fdt_init+0x13c>
    80200df4:	44c8                	lw	a0,12(s1)
    80200df6:	00000097          	auipc	ra,0x0
    80200dfa:	a5a080e7          	jalr	-1446(ra) # 80200850 <be32>
    80200dfe:	0005079b          	sext.w	a5,a0
    80200e02:	eef43423          	sd	a5,-280(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e06:	ef843483          	ld	s1,-264(s0)
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200e0a:	4785                	li	a5,1
    80200e0c:	eef43823          	sd	a5,-272(s0)
    80200e10:	6cae                	ld	s9,200(sp)
    80200e12:	7dea                	ld	s11,184(sp)
    80200e14:	b6e1                	j	802009dc <fdt_init+0xc6>
            } else if (streq(pname, "reg")) {
    80200e16:	00008597          	auipc	a1,0x8
    80200e1a:	53a58593          	addi	a1,a1,1338 # 80209350 <etext+0x350>
    80200e1e:	8552                	mv	a0,s4
    80200e20:	00000097          	auipc	ra,0x0
    80200e24:	a62080e7          	jalr	-1438(ra) # 80200882 <streq>
    80200e28:	c2050ae3          	beqz	a0,80200a5c <fdt_init+0x146>
                /* Decode with the PARENT's cell counts. */
                int pac = ac[depth - 1];
    80200e2c:	fff9879b          	addiw	a5,s3,-1
    80200e30:	078a                	slli	a5,a5,0x2
    80200e32:	f9078793          	addi	a5,a5,-112
    80200e36:	97a2                	add	a5,a5,s0
    80200e38:	fc07aa03          	lw	s4,-64(a5)
                int psc = sc[depth - 1];
    80200e3c:	f807ad03          	lw	s10,-128(a5)
                if (pac == 2)      reg_base = be64(val);
    80200e40:	4789                	li	a5,2
    80200e42:	02fa0563          	beq	s4,a5,80200e6c <fdt_init+0x556>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e46:	4785                	li	a5,1
                else               reg_base = 0;
    80200e48:	f0043423          	sd	zero,-248(s0)
                else if (pac == 1) reg_base = be32(val[0]);
    80200e4c:	04fa0563          	beq	s4,a5,80200e96 <fdt_init+0x580>

                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e50:	4789                	li	a5,2
    80200e52:	04fd0d63          	beq	s10,a5,80200eac <fdt_init+0x596>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200e56:	4785                	li	a5,1
    80200e58:	08fd0763          	beq	s10,a5,80200ee6 <fdt_init+0x5d0>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e5c:	ef843483          	ld	s1,-264(s0)
                else               reg_size = 0;
    80200e60:	f0043023          	sd	zero,-256(s0)
                have_reg = 1;
    80200e64:	4d05                	li	s10,1
    80200e66:	6cae                	ld	s9,200(sp)
    80200e68:	7dea                	ld	s11,184(sp)
    80200e6a:	be8d                	j	802009dc <fdt_init+0xc6>
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e6c:	44c8                	lw	a0,12(s1)
    80200e6e:	00000097          	auipc	ra,0x0
    80200e72:	9e2080e7          	jalr	-1566(ra) # 80200850 <be32>
    80200e76:	00050c9b          	sext.w	s9,a0
    80200e7a:	4888                	lw	a0,16(s1)
    80200e7c:	00000097          	auipc	ra,0x0
    80200e80:	9d4080e7          	jalr	-1580(ra) # 80200850 <be32>
    80200e84:	1c82                	slli	s9,s9,0x20
    80200e86:	02051793          	slli	a5,a0,0x20
    80200e8a:	9381                	srli	a5,a5,0x20
    80200e8c:	00fce7b3          	or	a5,s9,a5
    80200e90:	f0f43423          	sd	a5,-248(s0)
    80200e94:	bf75                	j	80200e50 <fdt_init+0x53a>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e96:	44c8                	lw	a0,12(s1)
    80200e98:	00000097          	auipc	ra,0x0
    80200e9c:	9b8080e7          	jalr	-1608(ra) # 80200850 <be32>
    80200ea0:	02051793          	slli	a5,a0,0x20
    80200ea4:	9381                	srli	a5,a5,0x20
    80200ea6:	f0f43423          	sd	a5,-248(s0)
    80200eaa:	b75d                	j	80200e50 <fdt_init+0x53a>
                if (psc == 2)      reg_size = be64(&val[pac]);
    80200eac:	002a1493          	slli	s1,s4,0x2
    80200eb0:	94ee                	add	s1,s1,s11
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200eb2:	4088                	lw	a0,0(s1)
    80200eb4:	00000097          	auipc	ra,0x0
    80200eb8:	99c080e7          	jalr	-1636(ra) # 80200850 <be32>
    80200ebc:	00050a1b          	sext.w	s4,a0
    80200ec0:	40c8                	lw	a0,4(s1)
    80200ec2:	00000097          	auipc	ra,0x0
    80200ec6:	98e080e7          	jalr	-1650(ra) # 80200850 <be32>
    80200eca:	1a02                	slli	s4,s4,0x20
    80200ecc:	02051793          	slli	a5,a0,0x20
    80200ed0:	9381                	srli	a5,a5,0x20
    80200ed2:	00fa67b3          	or	a5,s4,a5
    80200ed6:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200eda:	ef843483          	ld	s1,-264(s0)
                have_reg = 1;
    80200ede:	4d05                	li	s10,1
    80200ee0:	6cae                	ld	s9,200(sp)
    80200ee2:	7dea                	ld	s11,184(sp)
    80200ee4:	bce5                	j	802009dc <fdt_init+0xc6>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200ee6:	0a0a                	slli	s4,s4,0x2
    80200ee8:	9dd2                	add	s11,s11,s4
    80200eea:	000da503          	lw	a0,0(s11)
    80200eee:	00000097          	auipc	ra,0x0
    80200ef2:	962080e7          	jalr	-1694(ra) # 80200850 <be32>
    80200ef6:	02051793          	slli	a5,a0,0x20
    80200efa:	9381                	srli	a5,a5,0x20
    80200efc:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200f00:	ef843483          	ld	s1,-264(s0)
    80200f04:	6cae                	ld	s9,200(sp)
    80200f06:	7dea                	ld	s11,184(sp)
    80200f08:	bcd1                	j	802009dc <fdt_init+0xc6>
    80200f0a:	e5e6                	sd	s9,200(sp)
    80200f0c:	fd6e                	sd	s11,184(sp)
            }
            continue;
        }
        panic("fdt: unknown token in structure block");
    80200f0e:	00008517          	auipc	a0,0x8
    80200f12:	44a50513          	addi	a0,a0,1098 # 80209358 <etext+0x358>
    80200f16:	fffff097          	auipc	ra,0xfffff
    80200f1a:	700080e7          	jalr	1792(ra) # 80200616 <panic>
    }

    if (fdt.ncpu == 0) fdt.ncpu = 1;
    80200f1e:	0002b797          	auipc	a5,0x2b
    80200f22:	19a7a783          	lw	a5,410(a5) # 8022c0b8 <fdt+0xa0>
    80200f26:	ef8d                	bnez	a5,80200f60 <fdt_init+0x64a>
    80200f28:	4785                	li	a5,1
    80200f2a:	0002b717          	auipc	a4,0x2b
    80200f2e:	18f72723          	sw	a5,398(a4) # 8022c0b8 <fdt+0xa0>
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200f32:	0002b797          	auipc	a5,0x2b
    80200f36:	0f67b783          	ld	a5,246(a5) # 8022c028 <fdt+0x10>
    80200f3a:	cf85                	beqz	a5,80200f72 <fdt_init+0x65c>
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f3c:	0002b797          	auipc	a5,0x2b
    80200f40:	1747b783          	ld	a5,372(a5) # 8022c0b0 <fdt+0x98>
    80200f44:	c3a9                	beqz	a5,80200f86 <fdt_init+0x670>
    80200f46:	64b2                	ld	s1,264(sp)
    80200f48:	6912                	ld	s2,256(sp)
    80200f4a:	7a4e                	ld	s4,240(sp)
    80200f4c:	7aae                	ld	s5,232(sp)
    80200f4e:	7b0e                	ld	s6,224(sp)
    80200f50:	6bee                	ld	s7,216(sp)
    80200f52:	6c4e                	ld	s8,208(sp)
    80200f54:	6d0e                	ld	s10,192(sp)
}
    80200f56:	60f2                	ld	ra,280(sp)
    80200f58:	6452                	ld	s0,272(sp)
    80200f5a:	79ee                	ld	s3,248(sp)
    80200f5c:	6115                	addi	sp,sp,288
    80200f5e:	8082                	ret
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    80200f60:	4721                	li	a4,8
    80200f62:	fcf758e3          	bge	a4,a5,80200f32 <fdt_init+0x61c>
    80200f66:	47a1                	li	a5,8
    80200f68:	0002b717          	auipc	a4,0x2b
    80200f6c:	14f72823          	sw	a5,336(a4) # 8022c0b8 <fdt+0xa0>
    80200f70:	b7c9                	j	80200f32 <fdt_init+0x61c>
    80200f72:	e5e6                	sd	s9,200(sp)
    80200f74:	fd6e                	sd	s11,184(sp)
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200f76:	00008517          	auipc	a0,0x8
    80200f7a:	40a50513          	addi	a0,a0,1034 # 80209380 <etext+0x380>
    80200f7e:	fffff097          	auipc	ra,0xfffff
    80200f82:	698080e7          	jalr	1688(ra) # 80200616 <panic>
    80200f86:	e5e6                	sd	s9,200(sp)
    80200f88:	fd6e                	sd	s11,184(sp)
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f8a:	00008517          	auipc	a0,0x8
    80200f8e:	41e50513          	addi	a0,a0,1054 # 802093a8 <etext+0x3a8>
    80200f92:	fffff097          	auipc	ra,0xfffff
    80200f96:	684080e7          	jalr	1668(ra) # 80200616 <panic>
                fdt.ncpu++;
    80200f9a:	0002b717          	auipc	a4,0x2b
    80200f9e:	07e70713          	addi	a4,a4,126 # 8022c018 <fdt>
    80200fa2:	0a072783          	lw	a5,160(a4)
    80200fa6:	2785                	addiw	a5,a5,1
    80200fa8:	0af72023          	sw	a5,160(a4)
            depth++;
    80200fac:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200fae:	ee043423          	sd	zero,-280(s0)
    80200fb2:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200fb6:	f0043023          	sd	zero,-256(s0)
    80200fba:	f0043423          	sd	zero,-248(s0)
    80200fbe:	4d01                	li	s10,0
    80200fc0:	4c01                	li	s8,0
    80200fc2:	bc29                	j	802009dc <fdt_init+0xc6>

0000000080200fc4 <palloc_init>:
} kmem;

#define PA2IDX(pa) (((uint64)(pa) - kmem.base) >> PGSHIFT)

void palloc_init(void)
{
    80200fc4:	715d                	addi	sp,sp,-80
    80200fc6:	e486                	sd	ra,72(sp)
    80200fc8:	e0a2                	sd	s0,64(sp)
    80200fca:	fc26                	sd	s1,56(sp)
    80200fcc:	f84a                	sd	s2,48(sp)
    80200fce:	f44e                	sd	s3,40(sp)
    80200fd0:	f052                	sd	s4,32(sp)
    80200fd2:	ec56                	sd	s5,24(sp)
    80200fd4:	e85a                	sd	s6,16(sp)
    80200fd6:	e45e                	sd	s7,8(sp)
    80200fd8:	e062                	sd	s8,0(sp)
    80200fda:	0880                	addi	s0,sp,80
    initlock(&kmem.lock, "kmem");
    80200fdc:	0002bb97          	auipc	s7,0x2b
    80200fe0:	0e4b8b93          	addi	s7,s7,228 # 8022c0c0 <kmem>
    80200fe4:	00008597          	auipc	a1,0x8
    80200fe8:	3dc58593          	addi	a1,a1,988 # 802093c0 <etext+0x3c0>
    80200fec:	855e                	mv	a0,s7
    80200fee:	00000097          	auipc	ra,0x0
    80200ff2:	41e080e7          	jalr	1054(ra) # 8020140c <initlock>

    uint64 mem_start = fdt.mem_base;
    80200ff6:	0002b717          	auipc	a4,0x2b
    80200ffa:	02270713          	addi	a4,a4,34 # 8022c018 <fdt>
    80200ffe:	09073a83          	ld	s5,144(a4)
    uint64 mem_end   = fdt.mem_base + fdt.mem_size;
    80201002:	09873a03          	ld	s4,152(a4)
    80201006:	9a56                	add	s4,s4,s5
     * TOP of RAM (on qemu virt, ~0x87e00000). If you "reserve" it by pushing
     * free_start past it, you throw away almost all your memory and end up with
     * a kernel that has 1 MiB and cannot say why. Do NOT skip PAST the blob -
     * skip OVER its pages, and keep everything else.
     */
    uint64 free_start = PGROUNDUP((uint64)kernel_end);
    80201008:	6c05                	lui	s8,0x1
    8020100a:	fffc0693          	addi	a3,s8,-1 # fff <_entry-0x801ff001>
    8020100e:	77fd                	lui	a5,0xfffff
    80201010:	0015a617          	auipc	a2,0x15a
    80201014:	fef60613          	addi	a2,a2,-17 # 8035afff <uart+0xfcf>
    80201018:	00f674b3          	and	s1,a2,a5
    uint64 fdt_lo = PGROUNDDOWN(fdt.blob);
    8020101c:	00073903          	ld	s2,0(a4)
    80201020:	00f979b3          	and	s3,s2,a5
    uint64 fdt_hi = PGROUNDUP(fdt.blob + fdt.blob_size);
    80201024:	6718                	ld	a4,8(a4)
    80201026:	993a                	add	s2,s2,a4
    80201028:	9936                	add	s2,s2,a3
    8020102a:	00f97933          	and	s2,s2,a5

    uint64 npages = (mem_end - free_start) >> PGSHIFT;
    8020102e:	409a0b33          	sub	s6,s4,s1
    80201032:	00cb5b13          	srli	s6,s6,0xc

    /* One refcount byte per page (L11, copy-on-write). Carve it out of the
     * front of free memory - which is below the FDT, so this is safe. */
    uint64 refbytes = PGROUNDUP(npages);
    80201036:	9b36                	add	s6,s6,a3
    80201038:	00fb7b33          	and	s6,s6,a5
    kmem.refcnt = (uint8 *)free_start;
    8020103c:	029bbc23          	sd	s1,56(s7)
    memset(kmem.refcnt, 0, refbytes);
    80201040:	865a                	mv	a2,s6
    80201042:	4581                	li	a1,0
    80201044:	8526                	mv	a0,s1
    80201046:	fffff097          	auipc	ra,0xfffff
    8020104a:	676080e7          	jalr	1654(ra) # 802006bc <memset>
    free_start += refbytes;
    8020104e:	01648633          	add	a2,s1,s6

    kmem.base = free_start;
    80201052:	02cbb023          	sd	a2,32(s7)
    kmem.top  = mem_end;
    80201056:	034bb423          	sd	s4,40(s7)
    kmem.freelist = 0;
    8020105a:	000bbc23          	sd	zero,24(s7)
    kmem.nfree = 0;
    8020105e:	020ba823          	sw	zero,48(s7)

    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201062:	9c32                	add	s8,s8,a2
    80201064:	058a6063          	bltu	s4,s8,802010a4 <palloc_init+0xe0>
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
            continue;                       /* never hand this page out    */
        struct run *r = (struct run *)p;
        kmem.refcnt[PA2IDX(p)] = 0;
    80201068:	87de                	mv	a5,s7
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    8020106a:	6505                	lui	a0,0x1
    8020106c:	6589                	lui	a1,0x2
    8020106e:	a035                	j	8020109a <palloc_init+0xd6>
        kmem.refcnt[PA2IDX(p)] = 0;
    80201070:	7398                	ld	a4,32(a5)
    80201072:	40e60733          	sub	a4,a2,a4
    80201076:	8331                	srli	a4,a4,0xc
    80201078:	7f94                	ld	a3,56(a5)
    8020107a:	9736                	add	a4,a4,a3
    8020107c:	00070023          	sb	zero,0(a4)
        r->next = kmem.freelist;
    80201080:	6f98                	ld	a4,24(a5)
    80201082:	e218                	sd	a4,0(a2)
        kmem.freelist = r;
    80201084:	ef90                	sd	a2,24(a5)
        kmem.nfree++;
    80201086:	5b98                	lw	a4,48(a5)
    80201088:	2705                	addiw	a4,a4,1
    8020108a:	db98                	sw	a4,48(a5)
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    8020108c:	00a606b3          	add	a3,a2,a0
    80201090:	962e                	add	a2,a2,a1
    80201092:	7798                	ld	a4,40(a5)
    80201094:	00c76863          	bltu	a4,a2,802010a4 <palloc_init+0xe0>
    80201098:	8636                	mv	a2,a3
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
    8020109a:	fd366be3          	bltu	a2,s3,80201070 <palloc_init+0xac>
    8020109e:	fd2679e3          	bgeu	a2,s2,80201070 <palloc_init+0xac>
    802010a2:	b7ed                	j	8020108c <palloc_init+0xc8>
    }
    kmem.total_pages = kmem.nfree;   /* Lab 8: fixed total for conservation */
    802010a4:	0002b797          	auipc	a5,0x2b
    802010a8:	01c78793          	addi	a5,a5,28 # 8022c0c0 <kmem>
    802010ac:	5b94                	lw	a3,48(a5)
    802010ae:	10d7b023          	sd	a3,256(a5)
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
           mem_start, mem_end, kmem.nfree, (kmem.nfree * PGSIZE) >> 20);
    802010b2:	00c6971b          	slliw	a4,a3,0xc
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    802010b6:	4147571b          	sraiw	a4,a4,0x14
    802010ba:	8652                	mv	a2,s4
    802010bc:	85d6                	mv	a1,s5
    802010be:	00008517          	auipc	a0,0x8
    802010c2:	30a50513          	addi	a0,a0,778 # 802093c8 <etext+0x3c8>
    802010c6:	fffff097          	auipc	ra,0xfffff
    802010ca:	2de080e7          	jalr	734(ra) # 802003a4 <printf>
}
    802010ce:	60a6                	ld	ra,72(sp)
    802010d0:	6406                	ld	s0,64(sp)
    802010d2:	74e2                	ld	s1,56(sp)
    802010d4:	7942                	ld	s2,48(sp)
    802010d6:	79a2                	ld	s3,40(sp)
    802010d8:	7a02                	ld	s4,32(sp)
    802010da:	6ae2                	ld	s5,24(sp)
    802010dc:	6b42                	ld	s6,16(sp)
    802010de:	6ba2                	ld	s7,8(sp)
    802010e0:	6c02                	ld	s8,0(sp)
    802010e2:	6161                	addi	sp,sp,80
    802010e4:	8082                	ret

00000000802010e6 <palloc>:

void *palloc(void)
{
    802010e6:	1101                	addi	sp,sp,-32
    802010e8:	ec06                	sd	ra,24(sp)
    802010ea:	e822                	sd	s0,16(sp)
    802010ec:	e426                	sd	s1,8(sp)
    802010ee:	e04a                	sd	s2,0(sp)
    802010f0:	1000                	addi	s0,sp,32
    int h = hal_hart_id();
    802010f2:	00007097          	auipc	ra,0x7
    802010f6:	05e080e7          	jalr	94(ra) # 80208150 <hal_hart_id>
    802010fa:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    802010fc:	0002b917          	auipc	s2,0x2b
    80201100:	fc490913          	addi	s2,s2,-60 # 8022c0c0 <kmem>
    80201104:	854a                	mv	a0,s2
    80201106:	00000097          	auipc	ra,0x0
    8020110a:	382080e7          	jalr	898(ra) # 80201488 <acquire>
    kmem.acquires[h]++;
    8020110e:	00848793          	addi	a5,s1,8
    80201112:	078e                	slli	a5,a5,0x3
    80201114:	97ca                	add	a5,a5,s2
    80201116:	6398                	ld	a4,0(a5)
    80201118:	0705                	addi	a4,a4,1
    8020111a:	e398                	sd	a4,0(a5)
    kmem.allocs[h]++;
    8020111c:	04c1                	addi	s1,s1,16
    8020111e:	048e                	slli	s1,s1,0x3
    80201120:	94ca                	add	s1,s1,s2
    80201122:	609c                	ld	a5,0(s1)
    80201124:	0785                	addi	a5,a5,1
    80201126:	e09c                	sd	a5,0(s1)
    struct run *r = kmem.freelist;
    80201128:	01893483          	ld	s1,24(s2)
    if (r) {
    8020112c:	c4b9                	beqz	s1,8020117a <palloc+0x94>
        kmem.freelist = r->next;
    8020112e:	609c                	ld	a5,0(s1)
    80201130:	854a                	mv	a0,s2
    80201132:	00f93c23          	sd	a5,24(s2)
        kmem.nfree--;
    80201136:	03092783          	lw	a5,48(s2)
    8020113a:	37fd                	addiw	a5,a5,-1
    8020113c:	02f92823          	sw	a5,48(s2)
        kmem.refcnt[PA2IDX(r)] = 1;
    80201140:	02093783          	ld	a5,32(s2)
    80201144:	40f487b3          	sub	a5,s1,a5
    80201148:	83b1                	srli	a5,a5,0xc
    8020114a:	03893703          	ld	a4,56(s2)
    8020114e:	97ba                	add	a5,a5,a4
    80201150:	4705                	li	a4,1
    80201152:	00e78023          	sb	a4,0(a5)
    }
    release(&kmem.lock);
    80201156:	00000097          	auipc	ra,0x0
    8020115a:	3e6080e7          	jalr	998(ra) # 8020153c <release>

    if (r)
        memset((void *)r, 5, PGSIZE);   /* poison: catch use-before-init */
    8020115e:	6605                	lui	a2,0x1
    80201160:	4595                	li	a1,5
    80201162:	8526                	mv	a0,s1
    80201164:	fffff097          	auipc	ra,0xfffff
    80201168:	558080e7          	jalr	1368(ra) # 802006bc <memset>
    return (void *)r;
}
    8020116c:	8526                	mv	a0,s1
    8020116e:	60e2                	ld	ra,24(sp)
    80201170:	6442                	ld	s0,16(sp)
    80201172:	64a2                	ld	s1,8(sp)
    80201174:	6902                	ld	s2,0(sp)
    80201176:	6105                	addi	sp,sp,32
    80201178:	8082                	ret
    release(&kmem.lock);
    8020117a:	0002b517          	auipc	a0,0x2b
    8020117e:	f4650513          	addi	a0,a0,-186 # 8022c0c0 <kmem>
    80201182:	00000097          	auipc	ra,0x0
    80201186:	3ba080e7          	jalr	954(ra) # 8020153c <release>
    if (r)
    8020118a:	b7cd                	j	8020116c <palloc+0x86>

000000008020118c <palloc_ref_inc>:

void palloc_ref_inc(void *pa)
{
    8020118c:	1101                	addi	sp,sp,-32
    8020118e:	ec06                	sd	ra,24(sp)
    80201190:	e822                	sd	s0,16(sp)
    80201192:	e426                	sd	s1,8(sp)
    80201194:	e04a                	sd	s2,0(sp)
    80201196:	1000                	addi	s0,sp,32
    80201198:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    8020119a:	0002b917          	auipc	s2,0x2b
    8020119e:	f2690913          	addi	s2,s2,-218 # 8022c0c0 <kmem>
    802011a2:	854a                	mv	a0,s2
    802011a4:	00000097          	auipc	ra,0x0
    802011a8:	2e4080e7          	jalr	740(ra) # 80201488 <acquire>
    kmem.refcnt[PA2IDX(pa)]++;
    802011ac:	02093783          	ld	a5,32(s2)
    802011b0:	8c9d                	sub	s1,s1,a5
    802011b2:	80b1                	srli	s1,s1,0xc
    802011b4:	03893783          	ld	a5,56(s2)
    802011b8:	97a6                	add	a5,a5,s1
    802011ba:	0007c703          	lbu	a4,0(a5)
    802011be:	2705                	addiw	a4,a4,1
    802011c0:	00e78023          	sb	a4,0(a5)
    release(&kmem.lock);
    802011c4:	854a                	mv	a0,s2
    802011c6:	00000097          	auipc	ra,0x0
    802011ca:	376080e7          	jalr	886(ra) # 8020153c <release>
}
    802011ce:	60e2                	ld	ra,24(sp)
    802011d0:	6442                	ld	s0,16(sp)
    802011d2:	64a2                	ld	s1,8(sp)
    802011d4:	6902                	ld	s2,0(sp)
    802011d6:	6105                	addi	sp,sp,32
    802011d8:	8082                	ret

00000000802011da <palloc_ref_get>:

int palloc_ref_get(void *pa)
{
    802011da:	1101                	addi	sp,sp,-32
    802011dc:	ec06                	sd	ra,24(sp)
    802011de:	e822                	sd	s0,16(sp)
    802011e0:	e426                	sd	s1,8(sp)
    802011e2:	e04a                	sd	s2,0(sp)
    802011e4:	1000                	addi	s0,sp,32
    802011e6:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    802011e8:	0002b917          	auipc	s2,0x2b
    802011ec:	ed890913          	addi	s2,s2,-296 # 8022c0c0 <kmem>
    802011f0:	854a                	mv	a0,s2
    802011f2:	00000097          	auipc	ra,0x0
    802011f6:	296080e7          	jalr	662(ra) # 80201488 <acquire>
    int n = kmem.refcnt[PA2IDX(pa)];
    802011fa:	02093783          	ld	a5,32(s2)
    802011fe:	8c9d                	sub	s1,s1,a5
    80201200:	80b1                	srli	s1,s1,0xc
    80201202:	03893783          	ld	a5,56(s2)
    80201206:	97a6                	add	a5,a5,s1
    80201208:	0007c483          	lbu	s1,0(a5)
    release(&kmem.lock);
    8020120c:	854a                	mv	a0,s2
    8020120e:	00000097          	auipc	ra,0x0
    80201212:	32e080e7          	jalr	814(ra) # 8020153c <release>
    return n;
}
    80201216:	8526                	mv	a0,s1
    80201218:	60e2                	ld	ra,24(sp)
    8020121a:	6442                	ld	s0,16(sp)
    8020121c:	64a2                	ld	s1,8(sp)
    8020121e:	6902                	ld	s2,0(sp)
    80201220:	6105                	addi	sp,sp,32
    80201222:	8082                	ret

0000000080201224 <pfree>:

void pfree(void *pa)
{
    80201224:	7179                	addi	sp,sp,-48
    80201226:	f406                	sd	ra,40(sp)
    80201228:	f022                	sd	s0,32(sp)
    8020122a:	ec26                	sd	s1,24(sp)
    8020122c:	e84a                	sd	s2,16(sp)
    8020122e:	e44e                	sd	s3,8(sp)
    80201230:	1800                	addi	s0,sp,48
    if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < kmem.base || (uint64)pa >= kmem.top)
    80201232:	03451713          	slli	a4,a0,0x34
    80201236:	eb45                	bnez	a4,802012e6 <pfree+0xc2>
    80201238:	892a                	mv	s2,a0
    8020123a:	0002b717          	auipc	a4,0x2b
    8020123e:	ea673703          	ld	a4,-346(a4) # 8022c0e0 <kmem+0x20>
    80201242:	0ae56263          	bltu	a0,a4,802012e6 <pfree+0xc2>
    80201246:	0002b717          	auipc	a4,0x2b
    8020124a:	ea273703          	ld	a4,-350(a4) # 8022c0e8 <kmem+0x28>
    8020124e:	08e57c63          	bgeu	a0,a4,802012e6 <pfree+0xc2>
        panic("pfree: bad pointer");

    int h = hal_hart_id();
    80201252:	00007097          	auipc	ra,0x7
    80201256:	efe080e7          	jalr	-258(ra) # 80208150 <hal_hart_id>
    8020125a:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    8020125c:	0002b997          	auipc	s3,0x2b
    80201260:	e6498993          	addi	s3,s3,-412 # 8022c0c0 <kmem>
    80201264:	854e                	mv	a0,s3
    80201266:	00000097          	auipc	ra,0x0
    8020126a:	222080e7          	jalr	546(ra) # 80201488 <acquire>
    kmem.acquires[h]++;
    8020126e:	00848793          	addi	a5,s1,8
    80201272:	078e                	slli	a5,a5,0x3
    80201274:	97ce                	add	a5,a5,s3
    80201276:	6398                	ld	a4,0(a5)
    80201278:	0705                	addi	a4,a4,1
    8020127a:	e398                	sd	a4,0(a5)
    kmem.frees[h]++;
    8020127c:	04e1                	addi	s1,s1,24
    8020127e:	048e                	slli	s1,s1,0x3
    80201280:	94ce                	add	s1,s1,s3
    80201282:	609c                	ld	a5,0(s1)
    80201284:	0785                	addi	a5,a5,1
    80201286:	e09c                	sd	a5,0(s1)
    uint64 i = PA2IDX(pa);
    80201288:	0209b783          	ld	a5,32(s3)
    8020128c:	40f907b3          	sub	a5,s2,a5
    80201290:	83b1                	srli	a5,a5,0xc
    if (kmem.refcnt[i] < 1)
    80201292:	0389b703          	ld	a4,56(s3)
    80201296:	973e                	add	a4,a4,a5
    80201298:	00074783          	lbu	a5,0(a4)
    8020129c:	cfa9                	beqz	a5,802012f6 <pfree+0xd2>
        panic("pfree: double free / refcount underflow");

    if (--kmem.refcnt[i] > 0) {          /* still shared (COW) - not really free */
    8020129e:	37fd                	addiw	a5,a5,-1
    802012a0:	0ff7f793          	zext.b	a5,a5
    802012a4:	00f70023          	sb	a5,0(a4)
    802012a8:	efb9                	bnez	a5,80201306 <pfree+0xe2>
        release(&kmem.lock);
        return;
    }
    memset(pa, 1, PGSIZE);               /* poison: catch use-after-free */
    802012aa:	6605                	lui	a2,0x1
    802012ac:	4585                	li	a1,1
    802012ae:	854a                	mv	a0,s2
    802012b0:	fffff097          	auipc	ra,0xfffff
    802012b4:	40c080e7          	jalr	1036(ra) # 802006bc <memset>
    struct run *r = (struct run *)pa;
    r->next = kmem.freelist;
    802012b8:	0002b517          	auipc	a0,0x2b
    802012bc:	e0850513          	addi	a0,a0,-504 # 8022c0c0 <kmem>
    802012c0:	6d1c                	ld	a5,24(a0)
    802012c2:	00f93023          	sd	a5,0(s2)
    kmem.freelist = r;
    802012c6:	01253c23          	sd	s2,24(a0)
    kmem.nfree++;
    802012ca:	591c                	lw	a5,48(a0)
    802012cc:	2785                	addiw	a5,a5,1
    802012ce:	d91c                	sw	a5,48(a0)
    release(&kmem.lock);
    802012d0:	00000097          	auipc	ra,0x0
    802012d4:	26c080e7          	jalr	620(ra) # 8020153c <release>
}
    802012d8:	70a2                	ld	ra,40(sp)
    802012da:	7402                	ld	s0,32(sp)
    802012dc:	64e2                	ld	s1,24(sp)
    802012de:	6942                	ld	s2,16(sp)
    802012e0:	69a2                	ld	s3,8(sp)
    802012e2:	6145                	addi	sp,sp,48
    802012e4:	8082                	ret
        panic("pfree: bad pointer");
    802012e6:	00008517          	auipc	a0,0x8
    802012ea:	11a50513          	addi	a0,a0,282 # 80209400 <etext+0x400>
    802012ee:	fffff097          	auipc	ra,0xfffff
    802012f2:	328080e7          	jalr	808(ra) # 80200616 <panic>
        panic("pfree: double free / refcount underflow");
    802012f6:	00008517          	auipc	a0,0x8
    802012fa:	12250513          	addi	a0,a0,290 # 80209418 <etext+0x418>
    802012fe:	fffff097          	auipc	ra,0xfffff
    80201302:	318080e7          	jalr	792(ra) # 80200616 <panic>
        release(&kmem.lock);
    80201306:	0002b517          	auipc	a0,0x2b
    8020130a:	dba50513          	addi	a0,a0,-582 # 8022c0c0 <kmem>
    8020130e:	00000097          	auipc	ra,0x0
    80201312:	22e080e7          	jalr	558(ra) # 8020153c <release>
        return;
    80201316:	b7c9                	j	802012d8 <pfree+0xb4>

0000000080201318 <palloc_free_count>:

int palloc_free_count(void)
{
    80201318:	1101                	addi	sp,sp,-32
    8020131a:	ec06                	sd	ra,24(sp)
    8020131c:	e822                	sd	s0,16(sp)
    8020131e:	e426                	sd	s1,8(sp)
    80201320:	e04a                	sd	s2,0(sp)
    80201322:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    80201324:	0002b497          	auipc	s1,0x2b
    80201328:	d9c48493          	addi	s1,s1,-612 # 8022c0c0 <kmem>
    8020132c:	8526                	mv	a0,s1
    8020132e:	00000097          	auipc	ra,0x0
    80201332:	15a080e7          	jalr	346(ra) # 80201488 <acquire>
    int n = kmem.nfree;
    80201336:	0304a903          	lw	s2,48(s1)
    release(&kmem.lock);
    8020133a:	8526                	mv	a0,s1
    8020133c:	00000097          	auipc	ra,0x0
    80201340:	200080e7          	jalr	512(ra) # 8020153c <release>
    return n;
}
    80201344:	854a                	mv	a0,s2
    80201346:	60e2                	ld	ra,24(sp)
    80201348:	6442                	ld	s0,16(sp)
    8020134a:	64a2                	ld	s1,8(sp)
    8020134c:	6902                	ld	s2,0(sp)
    8020134e:	6105                	addi	sp,sp,32
    80201350:	8082                	ret

0000000080201352 <alloc_stats>:
    uint64 frees[NCPU];
    int    nfree;
    int    total;
};
int alloc_stats(struct allocstat *out)
{
    80201352:	1101                	addi	sp,sp,-32
    80201354:	ec06                	sd	ra,24(sp)
    80201356:	e822                	sd	s0,16(sp)
    80201358:	e426                	sd	s1,8(sp)
    8020135a:	e04a                	sd	s2,0(sp)
    8020135c:	1000                	addi	s0,sp,32
    8020135e:	892a                	mv	s2,a0
    acquire(&kmem.lock);
    80201360:	0002b497          	auipc	s1,0x2b
    80201364:	d6048493          	addi	s1,s1,-672 # 8022c0c0 <kmem>
    80201368:	8526                	mv	a0,s1
    8020136a:	00000097          	auipc	ra,0x0
    8020136e:	11e080e7          	jalr	286(ra) # 80201488 <acquire>
    for (int i = 0; i < NCPU; i++) {
    80201372:	87a6                	mv	a5,s1
    80201374:	874a                	mv	a4,s2
    80201376:	0002b617          	auipc	a2,0x2b
    8020137a:	d8a60613          	addi	a2,a2,-630 # 8022c100 <kmem+0x40>
        out->acquires[i] = kmem.acquires[i];
    8020137e:	63b4                	ld	a3,64(a5)
    80201380:	e314                	sd	a3,0(a4)
        out->allocs[i]   = kmem.allocs[i];
    80201382:	63d4                	ld	a3,128(a5)
    80201384:	e334                	sd	a3,64(a4)
        out->frees[i]    = kmem.frees[i];
    80201386:	63f4                	ld	a3,192(a5)
    80201388:	e354                	sd	a3,128(a4)
    for (int i = 0; i < NCPU; i++) {
    8020138a:	07a1                	addi	a5,a5,8
    8020138c:	0721                	addi	a4,a4,8
    8020138e:	fec798e3          	bne	a5,a2,8020137e <alloc_stats+0x2c>
    }
    out->nfree = kmem.nfree;
    80201392:	0002b517          	auipc	a0,0x2b
    80201396:	d2e50513          	addi	a0,a0,-722 # 8022c0c0 <kmem>
    8020139a:	591c                	lw	a5,48(a0)
    8020139c:	0cf92023          	sw	a5,192(s2)
    out->total = (int)kmem.total_pages;
    802013a0:	10053783          	ld	a5,256(a0)
    802013a4:	0cf92223          	sw	a5,196(s2)
    release(&kmem.lock);
    802013a8:	00000097          	auipc	ra,0x0
    802013ac:	194080e7          	jalr	404(ra) # 8020153c <release>
    return 0;
}
    802013b0:	4501                	li	a0,0
    802013b2:	60e2                	ld	ra,24(sp)
    802013b4:	6442                	ld	s0,16(sp)
    802013b6:	64a2                	ld	s1,8(sp)
    802013b8:	6902                	ld	s2,0(sp)
    802013ba:	6105                	addi	sp,sp,32
    802013bc:	8082                	ret

00000000802013be <alloc_audit>:

/* Lab 8: conservation invariant - count free-list length and compare against
 * nfree; they must agree, and free must never exceed total. Returns 0 if the
 * allocator is internally consistent, else a violation code. */
int alloc_audit(void)
{
    802013be:	7179                	addi	sp,sp,-48
    802013c0:	f406                	sd	ra,40(sp)
    802013c2:	f022                	sd	s0,32(sp)
    802013c4:	ec26                	sd	s1,24(sp)
    802013c6:	e84a                	sd	s2,16(sp)
    802013c8:	e44e                	sd	s3,8(sp)
    802013ca:	1800                	addi	s0,sp,48
    /* Conservation invariant: the number of free pages must always lie within
     * [0, total_pages]. This is the load-bearing safety property — a negative or
     * over-count means a double-free or a lost page. (A full free-list structural
     * walk is left as student work in Lab 8; it must handle the allocator's
     * page-poisoning correctly, which is part of the exercise.) */
    acquire(&kmem.lock);
    802013cc:	0002b497          	auipc	s1,0x2b
    802013d0:	cf448493          	addi	s1,s1,-780 # 8022c0c0 <kmem>
    802013d4:	8526                	mv	a0,s1
    802013d6:	00000097          	auipc	ra,0x0
    802013da:	0b2080e7          	jalr	178(ra) # 80201488 <acquire>
    int nfree = kmem.nfree;
    802013de:	0304a903          	lw	s2,48(s1)
    uint64 total = kmem.total_pages;
    802013e2:	1004b983          	ld	s3,256(s1)
    release(&kmem.lock);
    802013e6:	8526                	mv	a0,s1
    802013e8:	00000097          	auipc	ra,0x0
    802013ec:	154080e7          	jalr	340(ra) # 8020153c <release>
    if (nfree < 0) return 1;                      /* lost/double-freed pages */
    802013f0:	4505                	li	a0,1
    802013f2:	00094663          	bltz	s2,802013fe <alloc_audit+0x40>
    if ((uint64)nfree > total) return 2;          /* impossible over-count */
    802013f6:	0129b933          	sltu	s2,s3,s2
    802013fa:	00191513          	slli	a0,s2,0x1
    return 0;
}
    802013fe:	70a2                	ld	ra,40(sp)
    80201400:	7402                	ld	s0,32(sp)
    80201402:	64e2                	ld	s1,24(sp)
    80201404:	6942                	ld	s2,16(sp)
    80201406:	69a2                	ld	s3,8(sp)
    80201408:	6145                	addi	sp,sp,48
    8020140a:	8082                	ret

000000008020140c <initlock>:
#include "types.h"
#include "defs.h"
#include "hal.h"

void initlock(struct spinlock *lk, const char *name)
{
    8020140c:	1141                	addi	sp,sp,-16
    8020140e:	e422                	sd	s0,8(sp)
    80201410:	0800                	addi	s0,sp,16
    lk->name = name; lk->locked = 0; lk->cpu = -1;
    80201412:	e50c                	sd	a1,8(a0)
    80201414:	00052023          	sw	zero,0(a0)
    80201418:	57fd                	li	a5,-1
    8020141a:	c91c                	sw	a5,16(a0)
}
    8020141c:	6422                	ld	s0,8(sp)
    8020141e:	0141                	addi	sp,sp,16
    80201420:	8082                	ret

0000000080201422 <holding>:
    pop_off();
}

int holding(struct spinlock *lk)
{
    return lk->locked && lk->cpu == hal_hart_id();
    80201422:	411c                	lw	a5,0(a0)
    80201424:	e399                	bnez	a5,8020142a <holding+0x8>
    80201426:	4501                	li	a0,0
}
    80201428:	8082                	ret
{
    8020142a:	1101                	addi	sp,sp,-32
    8020142c:	ec06                	sd	ra,24(sp)
    8020142e:	e822                	sd	s0,16(sp)
    80201430:	e426                	sd	s1,8(sp)
    80201432:	1000                	addi	s0,sp,32
    return lk->locked && lk->cpu == hal_hart_id();
    80201434:	4904                	lw	s1,16(a0)
    80201436:	00007097          	auipc	ra,0x7
    8020143a:	d1a080e7          	jalr	-742(ra) # 80208150 <hal_hart_id>
    8020143e:	40a48533          	sub	a0,s1,a0
    80201442:	00153513          	seqz	a0,a0
}
    80201446:	60e2                	ld	ra,24(sp)
    80201448:	6442                	ld	s0,16(sp)
    8020144a:	64a2                	ld	s1,8(sp)
    8020144c:	6105                	addi	sp,sp,32
    8020144e:	8082                	ret

0000000080201450 <push_off>:

void push_off(void)
{
    80201450:	1101                	addi	sp,sp,-32
    80201452:	ec06                	sd	ra,24(sp)
    80201454:	e822                	sd	s0,16(sp)
    80201456:	e426                	sd	s1,8(sp)
    80201458:	1000                	addi	s0,sp,32
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020145a:	100024f3          	csrr	s1,sstatus
    8020145e:	100027f3          	csrr	a5,sstatus
#define SIE_SSIE (1L << 1)
#define SIE_STIE (1L << 5)       /* timer  */
#define SIE_SEIE (1L << 9)       /* external */

static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    80201462:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201464:	10079073          	csrw	sstatus,a5
    int old = intr_get();
    intr_off();
    struct cpu *c = mycpu();
    80201468:	00000097          	auipc	ra,0x0
    8020146c:	464080e7          	jalr	1124(ra) # 802018cc <mycpu>
    if (c->noff == 0) c->intena = old;   /* remember the ORIGINAL state */
    80201470:	5d3c                	lw	a5,120(a0)
    80201472:	e781                	bnez	a5,8020147a <push_off+0x2a>
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201474:	8085                	srli	s1,s1,0x1
    80201476:	8885                	andi	s1,s1,1
    80201478:	dd64                	sw	s1,124(a0)
    c->noff++;
    8020147a:	2785                	addiw	a5,a5,1
    8020147c:	dd3c                	sw	a5,120(a0)
}
    8020147e:	60e2                	ld	ra,24(sp)
    80201480:	6442                	ld	s0,16(sp)
    80201482:	64a2                	ld	s1,8(sp)
    80201484:	6105                	addi	sp,sp,32
    80201486:	8082                	ret

0000000080201488 <acquire>:
{
    80201488:	1101                	addi	sp,sp,-32
    8020148a:	ec06                	sd	ra,24(sp)
    8020148c:	e822                	sd	s0,16(sp)
    8020148e:	e426                	sd	s1,8(sp)
    80201490:	1000                	addi	s0,sp,32
    80201492:	84aa                	mv	s1,a0
    push_off();
    80201494:	00000097          	auipc	ra,0x0
    80201498:	fbc080e7          	jalr	-68(ra) # 80201450 <push_off>
    if (holding(lk)) panic("acquire: already holding this lock");
    8020149c:	8526                	mv	a0,s1
    8020149e:	00000097          	auipc	ra,0x0
    802014a2:	f84080e7          	jalr	-124(ra) # 80201422 <holding>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    802014a6:	4705                	li	a4,1
    if (holding(lk)) panic("acquire: already holding this lock");
    802014a8:	e115                	bnez	a0,802014cc <acquire+0x44>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    802014aa:	87ba                	mv	a5,a4
    802014ac:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    802014b0:	2781                	sext.w	a5,a5
    802014b2:	ffe5                	bnez	a5,802014aa <acquire+0x22>
    __sync_synchronize();          /* fence: nothing below moves above this */
    802014b4:	0ff0000f          	fence
    lk->cpu = hal_hart_id();
    802014b8:	00007097          	auipc	ra,0x7
    802014bc:	c98080e7          	jalr	-872(ra) # 80208150 <hal_hart_id>
    802014c0:	c888                	sw	a0,16(s1)
}
    802014c2:	60e2                	ld	ra,24(sp)
    802014c4:	6442                	ld	s0,16(sp)
    802014c6:	64a2                	ld	s1,8(sp)
    802014c8:	6105                	addi	sp,sp,32
    802014ca:	8082                	ret
    if (holding(lk)) panic("acquire: already holding this lock");
    802014cc:	00008517          	auipc	a0,0x8
    802014d0:	f7450513          	addi	a0,a0,-140 # 80209440 <etext+0x440>
    802014d4:	fffff097          	auipc	ra,0xfffff
    802014d8:	142080e7          	jalr	322(ra) # 80200616 <panic>

00000000802014dc <pop_off>:

void pop_off(void)
{
    802014dc:	1141                	addi	sp,sp,-16
    802014de:	e406                	sd	ra,8(sp)
    802014e0:	e022                	sd	s0,0(sp)
    802014e2:	0800                	addi	s0,sp,16
    struct cpu *c = mycpu();
    802014e4:	00000097          	auipc	ra,0x0
    802014e8:	3e8080e7          	jalr	1000(ra) # 802018cc <mycpu>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802014ec:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    802014f0:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("pop_off: interrupts already on");
    802014f2:	e78d                	bnez	a5,8020151c <pop_off+0x40>
    if (c->noff < 1) panic("pop_off: unbalanced");
    802014f4:	5d3c                	lw	a5,120(a0)
    802014f6:	02f05b63          	blez	a5,8020152c <pop_off+0x50>
    c->noff--;
    802014fa:	37fd                	addiw	a5,a5,-1
    802014fc:	0007871b          	sext.w	a4,a5
    80201500:	dd3c                	sw	a5,120(a0)
    if (c->noff == 0 && c->intena) intr_on();
    80201502:	eb09                	bnez	a4,80201514 <pop_off+0x38>
    80201504:	5d7c                	lw	a5,124(a0)
    80201506:	c799                	beqz	a5,80201514 <pop_off+0x38>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201508:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    8020150c:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201510:	10079073          	csrw	sstatus,a5
}
    80201514:	60a2                	ld	ra,8(sp)
    80201516:	6402                	ld	s0,0(sp)
    80201518:	0141                	addi	sp,sp,16
    8020151a:	8082                	ret
    if (intr_get()) panic("pop_off: interrupts already on");
    8020151c:	00008517          	auipc	a0,0x8
    80201520:	f4c50513          	addi	a0,a0,-180 # 80209468 <etext+0x468>
    80201524:	fffff097          	auipc	ra,0xfffff
    80201528:	0f2080e7          	jalr	242(ra) # 80200616 <panic>
    if (c->noff < 1) panic("pop_off: unbalanced");
    8020152c:	00008517          	auipc	a0,0x8
    80201530:	f5c50513          	addi	a0,a0,-164 # 80209488 <etext+0x488>
    80201534:	fffff097          	auipc	ra,0xfffff
    80201538:	0e2080e7          	jalr	226(ra) # 80200616 <panic>

000000008020153c <release>:
{
    8020153c:	1101                	addi	sp,sp,-32
    8020153e:	ec06                	sd	ra,24(sp)
    80201540:	e822                	sd	s0,16(sp)
    80201542:	e426                	sd	s1,8(sp)
    80201544:	1000                	addi	s0,sp,32
    80201546:	84aa                	mv	s1,a0
    if (!holding(lk)) panic("release: not holding this lock");
    80201548:	00000097          	auipc	ra,0x0
    8020154c:	eda080e7          	jalr	-294(ra) # 80201422 <holding>
    80201550:	c115                	beqz	a0,80201574 <release+0x38>
    lk->cpu = -1;
    80201552:	57fd                	li	a5,-1
    80201554:	c89c                	sw	a5,16(s1)
    __sync_synchronize();          /* fence: nothing above moves below this */
    80201556:	0ff0000f          	fence
    __sync_lock_release(&lk->locked);
    8020155a:	0f50000f          	fence	iorw,ow
    8020155e:	0804a02f          	amoswap.w	zero,zero,(s1)
    pop_off();
    80201562:	00000097          	auipc	ra,0x0
    80201566:	f7a080e7          	jalr	-134(ra) # 802014dc <pop_off>
}
    8020156a:	60e2                	ld	ra,24(sp)
    8020156c:	6442                	ld	s0,16(sp)
    8020156e:	64a2                	ld	s1,8(sp)
    80201570:	6105                	addi	sp,sp,32
    80201572:	8082                	ret
    if (!holding(lk)) panic("release: not holding this lock");
    80201574:	00008517          	auipc	a0,0x8
    80201578:	f2c50513          	addi	a0,a0,-212 # 802094a0 <etext+0x4a0>
    8020157c:	fffff097          	auipc	ra,0xfffff
    80201580:	09a080e7          	jalr	154(ra) # 80200616 <panic>

0000000080201584 <initsleeplock>:
 */
#include "types.h"
#include "defs.h"

void initsleeplock(struct sleeplock *lk, const char *name)
{
    80201584:	1101                	addi	sp,sp,-32
    80201586:	ec06                	sd	ra,24(sp)
    80201588:	e822                	sd	s0,16(sp)
    8020158a:	e426                	sd	s1,8(sp)
    8020158c:	e04a                	sd	s2,0(sp)
    8020158e:	1000                	addi	s0,sp,32
    80201590:	84aa                	mv	s1,a0
    80201592:	892e                	mv	s2,a1
    initlock(&lk->lk, "sleep lock");
    80201594:	00008597          	auipc	a1,0x8
    80201598:	f2c58593          	addi	a1,a1,-212 # 802094c0 <etext+0x4c0>
    8020159c:	0521                	addi	a0,a0,8
    8020159e:	00000097          	auipc	ra,0x0
    802015a2:	e6e080e7          	jalr	-402(ra) # 8020140c <initlock>
    lk->name = name;
    802015a6:	0324b023          	sd	s2,32(s1)
    lk->locked = 0;
    802015aa:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    802015ae:	0204a423          	sw	zero,40(s1)
}
    802015b2:	60e2                	ld	ra,24(sp)
    802015b4:	6442                	ld	s0,16(sp)
    802015b6:	64a2                	ld	s1,8(sp)
    802015b8:	6902                	ld	s2,0(sp)
    802015ba:	6105                	addi	sp,sp,32
    802015bc:	8082                	ret

00000000802015be <acquiresleep>:

void acquiresleep(struct sleeplock *lk)
{
    802015be:	1101                	addi	sp,sp,-32
    802015c0:	ec06                	sd	ra,24(sp)
    802015c2:	e822                	sd	s0,16(sp)
    802015c4:	e426                	sd	s1,8(sp)
    802015c6:	e04a                	sd	s2,0(sp)
    802015c8:	1000                	addi	s0,sp,32
    802015ca:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    802015cc:	00850913          	addi	s2,a0,8
    802015d0:	854a                	mv	a0,s2
    802015d2:	00000097          	auipc	ra,0x0
    802015d6:	eb6080e7          	jalr	-330(ra) # 80201488 <acquire>
    while (lk->locked)
    802015da:	409c                	lw	a5,0(s1)
    802015dc:	cb89                	beqz	a5,802015ee <acquiresleep+0x30>
        sleep(lk, &lk->lk);       /* releases lk->lk while asleep */
    802015de:	85ca                	mv	a1,s2
    802015e0:	8526                	mv	a0,s1
    802015e2:	00001097          	auipc	ra,0x1
    802015e6:	b04080e7          	jalr	-1276(ra) # 802020e6 <sleep>
    while (lk->locked)
    802015ea:	409c                	lw	a5,0(s1)
    802015ec:	fbed                	bnez	a5,802015de <acquiresleep+0x20>
    lk->locked = 1;
    802015ee:	4785                	li	a5,1
    802015f0:	c09c                	sw	a5,0(s1)
    lk->pid = myproc()->pid;
    802015f2:	00000097          	auipc	ra,0x0
    802015f6:	2fe080e7          	jalr	766(ra) # 802018f0 <myproc>
    802015fa:	591c                	lw	a5,48(a0)
    802015fc:	d49c                	sw	a5,40(s1)
    release(&lk->lk);
    802015fe:	854a                	mv	a0,s2
    80201600:	00000097          	auipc	ra,0x0
    80201604:	f3c080e7          	jalr	-196(ra) # 8020153c <release>
}
    80201608:	60e2                	ld	ra,24(sp)
    8020160a:	6442                	ld	s0,16(sp)
    8020160c:	64a2                	ld	s1,8(sp)
    8020160e:	6902                	ld	s2,0(sp)
    80201610:	6105                	addi	sp,sp,32
    80201612:	8082                	ret

0000000080201614 <releasesleep>:

void releasesleep(struct sleeplock *lk)
{
    80201614:	1101                	addi	sp,sp,-32
    80201616:	ec06                	sd	ra,24(sp)
    80201618:	e822                	sd	s0,16(sp)
    8020161a:	e426                	sd	s1,8(sp)
    8020161c:	e04a                	sd	s2,0(sp)
    8020161e:	1000                	addi	s0,sp,32
    80201620:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201622:	00850913          	addi	s2,a0,8
    80201626:	854a                	mv	a0,s2
    80201628:	00000097          	auipc	ra,0x0
    8020162c:	e60080e7          	jalr	-416(ra) # 80201488 <acquire>
    lk->locked = 0;
    80201630:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    80201634:	0204a423          	sw	zero,40(s1)
    wakeup(lk);
    80201638:	8526                	mv	a0,s1
    8020163a:	00001097          	auipc	ra,0x1
    8020163e:	c32080e7          	jalr	-974(ra) # 8020226c <wakeup>
    release(&lk->lk);
    80201642:	854a                	mv	a0,s2
    80201644:	00000097          	auipc	ra,0x0
    80201648:	ef8080e7          	jalr	-264(ra) # 8020153c <release>
}
    8020164c:	60e2                	ld	ra,24(sp)
    8020164e:	6442                	ld	s0,16(sp)
    80201650:	64a2                	ld	s1,8(sp)
    80201652:	6902                	ld	s2,0(sp)
    80201654:	6105                	addi	sp,sp,32
    80201656:	8082                	ret

0000000080201658 <holdingsleep>:

int holdingsleep(struct sleeplock *lk)
{
    80201658:	7179                	addi	sp,sp,-48
    8020165a:	f406                	sd	ra,40(sp)
    8020165c:	f022                	sd	s0,32(sp)
    8020165e:	ec26                	sd	s1,24(sp)
    80201660:	e84a                	sd	s2,16(sp)
    80201662:	1800                	addi	s0,sp,48
    80201664:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201666:	00850913          	addi	s2,a0,8
    8020166a:	854a                	mv	a0,s2
    8020166c:	00000097          	auipc	ra,0x0
    80201670:	e1c080e7          	jalr	-484(ra) # 80201488 <acquire>
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201674:	409c                	lw	a5,0(s1)
    80201676:	ef91                	bnez	a5,80201692 <holdingsleep+0x3a>
    80201678:	4481                	li	s1,0
    release(&lk->lk);
    8020167a:	854a                	mv	a0,s2
    8020167c:	00000097          	auipc	ra,0x0
    80201680:	ec0080e7          	jalr	-320(ra) # 8020153c <release>
    return r;
}
    80201684:	8526                	mv	a0,s1
    80201686:	70a2                	ld	ra,40(sp)
    80201688:	7402                	ld	s0,32(sp)
    8020168a:	64e2                	ld	s1,24(sp)
    8020168c:	6942                	ld	s2,16(sp)
    8020168e:	6145                	addi	sp,sp,48
    80201690:	8082                	ret
    80201692:	e44e                	sd	s3,8(sp)
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201694:	0284a983          	lw	s3,40(s1)
    80201698:	00000097          	auipc	ra,0x0
    8020169c:	258080e7          	jalr	600(ra) # 802018f0 <myproc>
    802016a0:	5904                	lw	s1,48(a0)
    802016a2:	413484b3          	sub	s1,s1,s3
    802016a6:	0014b493          	seqz	s1,s1
    802016aa:	69a2                	ld	s3,8(sp)
    802016ac:	b7f9                	j	8020167a <holdingsleep+0x22>

00000000802016ae <freeproc>:
        p->kstack = 0;
    }
}

static void freeproc(struct proc *p)
{
    802016ae:	1101                	addi	sp,sp,-32
    802016b0:	ec06                	sd	ra,24(sp)
    802016b2:	e822                	sd	s0,16(sp)
    802016b4:	e426                	sd	s1,8(sp)
    802016b6:	1000                	addi	s0,sp,32
    802016b8:	84aa                	mv	s1,a0
    if (!p->is_thread) usysinfo_free(p);
    802016ba:	18c52783          	lw	a5,396(a0)
    802016be:	c7a5                	beqz	a5,80201726 <freeproc+0x78>
    if (p->alarm_saved) { pfree((void *)p->alarm_saved); p->alarm_saved = 0; }
    802016c0:	1b84b503          	ld	a0,440(s1)
    802016c4:	c519                	beqz	a0,802016d2 <freeproc+0x24>
    802016c6:	00000097          	auipc	ra,0x0
    802016ca:	b5e080e7          	jalr	-1186(ra) # 80201224 <pfree>
    802016ce:	1a04bc23          	sd	zero,440(s1)
    if (p->tf) pfree((void *)p->tf);
    802016d2:	6ca8                	ld	a0,88(s1)
    802016d4:	c509                	beqz	a0,802016de <freeproc+0x30>
    802016d6:	00000097          	auipc	ra,0x0
    802016da:	b4e080e7          	jalr	-1202(ra) # 80201224 <pfree>
    p->tf = 0;
    802016de:	0404bc23          	sd	zero,88(s1)
    if (p->pagetable && !p->is_thread) uvmfree(p->pagetable, p->sz);
    802016e2:	68a8                	ld	a0,80(s1)
    802016e4:	c501                	beqz	a0,802016ec <freeproc+0x3e>
    802016e6:	18c4a783          	lw	a5,396(s1)
    802016ea:	c3b9                	beqz	a5,80201730 <freeproc+0x82>
    p->pagetable = 0;
    802016ec:	0404b823          	sd	zero,80(s1)
    p->is_thread = 0; p->tgid = 0;
    802016f0:	1804a623          	sw	zero,396(s1)
    802016f4:	1804a823          	sw	zero,400(s1)
    p->kstack = 0;              /* statically allocated - nothing to free */
    802016f8:	0404b023          	sd	zero,64(s1)
    p->sz = 0; p->pid = 0; p->parent = 0;
    802016fc:	0404b423          	sd	zero,72(s1)
    80201700:	0204a823          	sw	zero,48(s1)
    80201704:	0204bc23          	sd	zero,56(s1)
    p->name[0] = 0; p->chan = 0; p->killed = 0; p->xstate = 0;
    80201708:	14048c23          	sb	zero,344(s1)
    8020170c:	0204b023          	sd	zero,32(s1)
    80201710:	0204a423          	sw	zero,40(s1)
    80201714:	0204a623          	sw	zero,44(s1)
    p->state = UNUSED;
    80201718:	0004ac23          	sw	zero,24(s1)
}
    8020171c:	60e2                	ld	ra,24(sp)
    8020171e:	6442                	ld	s0,16(sp)
    80201720:	64a2                	ld	s1,8(sp)
    80201722:	6105                	addi	sp,sp,32
    80201724:	8082                	ret
    if (!p->is_thread) usysinfo_free(p);
    80201726:	00004097          	auipc	ra,0x4
    8020172a:	9fc080e7          	jalr	-1540(ra) # 80205122 <usysinfo_free>
    8020172e:	bf49                	j	802016c0 <freeproc+0x12>
    if (p->pagetable && !p->is_thread) uvmfree(p->pagetable, p->sz);
    80201730:	64ac                	ld	a1,72(s1)
    80201732:	00002097          	auipc	ra,0x2
    80201736:	b54080e7          	jalr	-1196(ra) # 80203286 <uvmfree>
    8020173a:	bf4d                	j	802016ec <freeproc+0x3e>

000000008020173c <allocproc>:
    }
    usertrapret();
}

static struct proc *allocproc(void)
{
    8020173c:	7179                	addi	sp,sp,-48
    8020173e:	f406                	sd	ra,40(sp)
    80201740:	f022                	sd	s0,32(sp)
    80201742:	ec26                	sd	s1,24(sp)
    80201744:	e84a                	sd	s2,16(sp)
    80201746:	1800                	addi	s0,sp,48
    struct proc *p;
    for (p = proc; p < &proc[NPROC]; p++) {
    80201748:	0012d497          	auipc	s1,0x12d
    8020174c:	8b848493          	addi	s1,s1,-1864 # 8032e000 <proc>
    80201750:	00134917          	auipc	s2,0x134
    80201754:	8b090913          	addi	s2,s2,-1872 # 80335000 <tickslock>
        acquire(&p->lock);
    80201758:	8526                	mv	a0,s1
    8020175a:	00000097          	auipc	ra,0x0
    8020175e:	d2e080e7          	jalr	-722(ra) # 80201488 <acquire>
        if (p->state == UNUSED) goto found;
    80201762:	4c9c                	lw	a5,24(s1)
    80201764:	cf81                	beqz	a5,8020177c <allocproc+0x40>
        release(&p->lock);
    80201766:	8526                	mv	a0,s1
    80201768:	00000097          	auipc	ra,0x0
    8020176c:	dd4080e7          	jalr	-556(ra) # 8020153c <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80201770:	1c048493          	addi	s1,s1,448
    80201774:	ff2492e3          	bne	s1,s2,80201758 <allocproc+0x1c>
    }
    return 0;
    80201778:	4481                	li	s1,0
    8020177a:	a8dd                	j	80201870 <allocproc+0x134>
    8020177c:	e44e                	sd	s3,8(sp)
    acquire(&pid_lock);
    8020177e:	0002c997          	auipc	s3,0x2c
    80201782:	88298993          	addi	s3,s3,-1918 # 8022d000 <pid_lock>
    80201786:	854e                	mv	a0,s3
    80201788:	00000097          	auipc	ra,0x0
    8020178c:	d00080e7          	jalr	-768(ra) # 80201488 <acquire>
    int pid = nextpid++;
    80201790:	0000a797          	auipc	a5,0xa
    80201794:	87878793          	addi	a5,a5,-1928 # 8020b008 <nextpid>
    80201798:	0007a903          	lw	s2,0(a5)
    8020179c:	0019071b          	addiw	a4,s2,1
    802017a0:	c398                	sw	a4,0(a5)
    release(&pid_lock);
    802017a2:	854e                	mv	a0,s3
    802017a4:	00000097          	auipc	ra,0x0
    802017a8:	d98080e7          	jalr	-616(ra) # 8020153c <release>

found:
    p->pid    = allocpid();
    802017ac:	0324a823          	sw	s2,48(s1)
    p->state  = USED;
    802017b0:	4785                	li	a5,1
    802017b2:	cc9c                	sw	a5,24(s1)
    p->killed = 0;
    802017b4:	0204a423          	sw	zero,40(s1)
    p->xstate = 0;
    802017b8:	0204a623          	sw	zero,44(s1)
    p->chan   = 0;
    802017bc:	0204b023          	sd	zero,32(s1)

    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    802017c0:	00000097          	auipc	ra,0x0
    802017c4:	926080e7          	jalr	-1754(ra) # 802010e6 <palloc>
    802017c8:	892a                	mv	s2,a0
    802017ca:	eca8                	sd	a0,88(s1)
    802017cc:	c94d                	beqz	a0,8020187e <allocproc+0x142>

    /* Contiguous, statically reserved. See the note at the top of this file. */
    p->kstack = (uint64)kstacks[p - proc];
    802017ce:	0012d797          	auipc	a5,0x12d
    802017d2:	83278793          	addi	a5,a5,-1998 # 8032e000 <proc>
    802017d6:	40f487b3          	sub	a5,s1,a5
    802017da:	4067d713          	srai	a4,a5,0x6
    802017de:	06db77b7          	lui	a5,0x6db7
    802017e2:	db778793          	addi	a5,a5,-585 # 6db6db7 <_entry-0x79449249>
    802017e6:	07b2                	slli	a5,a5,0xc
    802017e8:	db778793          	addi	a5,a5,-585
    802017ec:	07b2                	slli	a5,a5,0xc
    802017ee:	db778793          	addi	a5,a5,-585
    802017f2:	07b2                	slli	a5,a5,0xc
    802017f4:	db778793          	addi	a5,a5,-585
    802017f8:	02f707b3          	mul	a5,a4,a5
    802017fc:	07ba                	slli	a5,a5,0xe
    802017fe:	0002d717          	auipc	a4,0x2d
    80201802:	80270713          	addi	a4,a4,-2046 # 8022e000 <kstacks>
    80201806:	97ba                	add	a5,a5,a4
    80201808:	e0bc                	sd	a5,64(s1)

    p->pagetable = uvmcreate();
    8020180a:	00002097          	auipc	ra,0x2
    8020180e:	9bc080e7          	jalr	-1604(ra) # 802031c6 <uvmcreate>
    80201812:	892a                	mv	s2,a0
    80201814:	e8a8                	sd	a0,80(s1)
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    80201816:	c149                	beqz	a0,80201898 <allocproc+0x15c>
    p->syscall_count = 0; p->ctxsw_count = 0; p->state_gen = 0;
    80201818:	1604bc23          	sd	zero,376(s1)
    8020181c:	1804b023          	sd	zero,384(s1)
    80201820:	1804a423          	sw	zero,392(s1)
    p->alarm_interval = 0; p->alarm_handler = 0; p->alarm_altstack = 0;
    80201824:	1804bc23          	sd	zero,408(s1)
    80201828:	1a04b023          	sd	zero,416(s1)
    8020182c:	1a04b423          	sd	zero,424(s1)
    p->alarm_ticks = 0; p->in_handler = 0; p->alarm_saved = 0;
    80201830:	1a04a823          	sw	zero,432(s1)
    80201834:	1a04aa23          	sw	zero,436(s1)
    80201838:	1a04bc23          	sd	zero,440(s1)
    if (usysinfo_setup(p) < 0) { freeproc(p); release(&p->lock); return 0; }
    8020183c:	8526                	mv	a0,s1
    8020183e:	00004097          	auipc	ra,0x4
    80201842:	87a080e7          	jalr	-1926(ra) # 802050b8 <usysinfo_setup>
    80201846:	06054663          	bltz	a0,802018b2 <allocproc+0x176>

    memset(&p->context, 0, sizeof(p->context));
    8020184a:	07000613          	li	a2,112
    8020184e:	4581                	li	a1,0
    80201850:	06048513          	addi	a0,s1,96
    80201854:	fffff097          	auipc	ra,0xfffff
    80201858:	e68080e7          	jalr	-408(ra) # 802006bc <memset>
    p->context.ra = (uint64)forkret;
    8020185c:	00000797          	auipc	a5,0x0
    80201860:	0d078793          	addi	a5,a5,208 # 8020192c <forkret>
    80201864:	f0bc                	sd	a5,96(s1)
    p->context.sp = p->kstack + KSTACK_SIZE;
    80201866:	60bc                	ld	a5,64(s1)
    80201868:	6711                	lui	a4,0x4
    8020186a:	97ba                	add	a5,a5,a4
    8020186c:	f4bc                	sd	a5,104(s1)
    8020186e:	69a2                	ld	s3,8(sp)
    return p;
}
    80201870:	8526                	mv	a0,s1
    80201872:	70a2                	ld	ra,40(sp)
    80201874:	7402                	ld	s0,32(sp)
    80201876:	64e2                	ld	s1,24(sp)
    80201878:	6942                	ld	s2,16(sp)
    8020187a:	6145                	addi	sp,sp,48
    8020187c:	8082                	ret
    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    8020187e:	8526                	mv	a0,s1
    80201880:	00000097          	auipc	ra,0x0
    80201884:	e2e080e7          	jalr	-466(ra) # 802016ae <freeproc>
    80201888:	8526                	mv	a0,s1
    8020188a:	00000097          	auipc	ra,0x0
    8020188e:	cb2080e7          	jalr	-846(ra) # 8020153c <release>
    80201892:	84ca                	mv	s1,s2
    80201894:	69a2                	ld	s3,8(sp)
    80201896:	bfe9                	j	80201870 <allocproc+0x134>
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    80201898:	8526                	mv	a0,s1
    8020189a:	00000097          	auipc	ra,0x0
    8020189e:	e14080e7          	jalr	-492(ra) # 802016ae <freeproc>
    802018a2:	8526                	mv	a0,s1
    802018a4:	00000097          	auipc	ra,0x0
    802018a8:	c98080e7          	jalr	-872(ra) # 8020153c <release>
    802018ac:	84ca                	mv	s1,s2
    802018ae:	69a2                	ld	s3,8(sp)
    802018b0:	b7c1                	j	80201870 <allocproc+0x134>
    if (usysinfo_setup(p) < 0) { freeproc(p); release(&p->lock); return 0; }
    802018b2:	8526                	mv	a0,s1
    802018b4:	00000097          	auipc	ra,0x0
    802018b8:	dfa080e7          	jalr	-518(ra) # 802016ae <freeproc>
    802018bc:	8526                	mv	a0,s1
    802018be:	00000097          	auipc	ra,0x0
    802018c2:	c7e080e7          	jalr	-898(ra) # 8020153c <release>
    802018c6:	4481                	li	s1,0
    802018c8:	69a2                	ld	s3,8(sp)
    802018ca:	b75d                	j	80201870 <allocproc+0x134>

00000000802018cc <mycpu>:
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    802018cc:	1141                	addi	sp,sp,-16
    802018ce:	e406                	sd	ra,8(sp)
    802018d0:	e022                	sd	s0,0(sp)
    802018d2:	0800                	addi	s0,sp,16
    802018d4:	00007097          	auipc	ra,0x7
    802018d8:	87c080e7          	jalr	-1924(ra) # 80208150 <hal_hart_id>
    802018dc:	051e                	slli	a0,a0,0x7
    802018de:	0002b797          	auipc	a5,0x2b
    802018e2:	73a78793          	addi	a5,a5,1850 # 8022d018 <cpus>
    802018e6:	953e                	add	a0,a0,a5
    802018e8:	60a2                	ld	ra,8(sp)
    802018ea:	6402                	ld	s0,0(sp)
    802018ec:	0141                	addi	sp,sp,16
    802018ee:	8082                	ret

00000000802018f0 <myproc>:
{
    802018f0:	1101                	addi	sp,sp,-32
    802018f2:	ec06                	sd	ra,24(sp)
    802018f4:	e822                	sd	s0,16(sp)
    802018f6:	e426                	sd	s1,8(sp)
    802018f8:	1000                	addi	s0,sp,32
    push_off();
    802018fa:	00000097          	auipc	ra,0x0
    802018fe:	b56080e7          	jalr	-1194(ra) # 80201450 <push_off>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201902:	00007097          	auipc	ra,0x7
    80201906:	84e080e7          	jalr	-1970(ra) # 80208150 <hal_hart_id>
    struct proc *p = mycpu()->proc;
    8020190a:	051e                	slli	a0,a0,0x7
    8020190c:	0002b797          	auipc	a5,0x2b
    80201910:	6f478793          	addi	a5,a5,1780 # 8022d000 <pid_lock>
    80201914:	97aa                	add	a5,a5,a0
    80201916:	6f84                	ld	s1,24(a5)
    pop_off();
    80201918:	00000097          	auipc	ra,0x0
    8020191c:	bc4080e7          	jalr	-1084(ra) # 802014dc <pop_off>
}
    80201920:	8526                	mv	a0,s1
    80201922:	60e2                	ld	ra,24(sp)
    80201924:	6442                	ld	s0,16(sp)
    80201926:	64a2                	ld	s1,8(sp)
    80201928:	6105                	addi	sp,sp,32
    8020192a:	8082                	ret

000000008020192c <forkret>:
{
    8020192c:	1101                	addi	sp,sp,-32
    8020192e:	ec06                	sd	ra,24(sp)
    80201930:	e822                	sd	s0,16(sp)
    80201932:	1000                	addi	s0,sp,32
    release(&myproc()->lock);
    80201934:	00000097          	auipc	ra,0x0
    80201938:	fbc080e7          	jalr	-68(ra) # 802018f0 <myproc>
    8020193c:	00000097          	auipc	ra,0x0
    80201940:	c00080e7          	jalr	-1024(ra) # 8020153c <release>
    if (first) {
    80201944:	00009797          	auipc	a5,0x9
    80201948:	6c07a783          	lw	a5,1728(a5) # 8020b004 <first.1>
    8020194c:	eb89                	bnez	a5,8020195e <forkret+0x32>
    usertrapret();
    8020194e:	00001097          	auipc	ra,0x1
    80201952:	0b8080e7          	jalr	184(ra) # 80202a06 <usertrapret>
}
    80201956:	60e2                	ld	ra,24(sp)
    80201958:	6442                	ld	s0,16(sp)
    8020195a:	6105                	addi	sp,sp,32
    8020195c:	8082                	ret
    8020195e:	e426                	sd	s1,8(sp)
        first = 0;
    80201960:	00009797          	auipc	a5,0x9
    80201964:	6a07a223          	sw	zero,1700(a5) # 8020b004 <first.1>
        fsinit(ROOTDEV);
    80201968:	4501                	li	a0,0
    8020196a:	00005097          	auipc	ra,0x5
    8020196e:	410080e7          	jalr	1040(ra) # 80206d7a <fsinit>
        myproc()->cwd = namei("/");
    80201972:	00000097          	auipc	ra,0x0
    80201976:	f7e080e7          	jalr	-130(ra) # 802018f0 <myproc>
    8020197a:	84aa                	mv	s1,a0
    8020197c:	00008517          	auipc	a0,0x8
    80201980:	b5450513          	addi	a0,a0,-1196 # 802094d0 <etext+0x4d0>
    80201984:	00006097          	auipc	ra,0x6
    80201988:	f9e080e7          	jalr	-98(ra) # 80207922 <namei>
    8020198c:	14a4b823          	sd	a0,336(s1)
        __sync_synchronize();
    80201990:	0ff0000f          	fence
    80201994:	64a2                	ld	s1,8(sp)
    80201996:	bf65                	j	8020194e <forkret+0x22>

0000000080201998 <procinit>:
{
    80201998:	7179                	addi	sp,sp,-48
    8020199a:	f406                	sd	ra,40(sp)
    8020199c:	f022                	sd	s0,32(sp)
    8020199e:	ec26                	sd	s1,24(sp)
    802019a0:	e84a                	sd	s2,16(sp)
    802019a2:	e44e                	sd	s3,8(sp)
    802019a4:	1800                	addi	s0,sp,48
    initlock(&pid_lock,  "nextpid");
    802019a6:	00008597          	auipc	a1,0x8
    802019aa:	b3258593          	addi	a1,a1,-1230 # 802094d8 <etext+0x4d8>
    802019ae:	0002b517          	auipc	a0,0x2b
    802019b2:	65250513          	addi	a0,a0,1618 # 8022d000 <pid_lock>
    802019b6:	00000097          	auipc	ra,0x0
    802019ba:	a56080e7          	jalr	-1450(ra) # 8020140c <initlock>
    initlock(&wait_lock, "wait_lock");
    802019be:	00008597          	auipc	a1,0x8
    802019c2:	b2258593          	addi	a1,a1,-1246 # 802094e0 <etext+0x4e0>
    802019c6:	0002c517          	auipc	a0,0x2c
    802019ca:	a5250513          	addi	a0,a0,-1454 # 8022d418 <wait_lock>
    802019ce:	00000097          	auipc	ra,0x0
    802019d2:	a3e080e7          	jalr	-1474(ra) # 8020140c <initlock>
    initlock(&tickslock, "time");
    802019d6:	00008597          	auipc	a1,0x8
    802019da:	b1a58593          	addi	a1,a1,-1254 # 802094f0 <etext+0x4f0>
    802019de:	00133517          	auipc	a0,0x133
    802019e2:	62250513          	addi	a0,a0,1570 # 80335000 <tickslock>
    802019e6:	00000097          	auipc	ra,0x0
    802019ea:	a26080e7          	jalr	-1498(ra) # 8020140c <initlock>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802019ee:	0012c497          	auipc	s1,0x12c
    802019f2:	61248493          	addi	s1,s1,1554 # 8032e000 <proc>
        initlock(&p->lock, "proc");
    802019f6:	00008997          	auipc	s3,0x8
    802019fa:	b0298993          	addi	s3,s3,-1278 # 802094f8 <etext+0x4f8>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802019fe:	00133917          	auipc	s2,0x133
    80201a02:	60290913          	addi	s2,s2,1538 # 80335000 <tickslock>
        initlock(&p->lock, "proc");
    80201a06:	85ce                	mv	a1,s3
    80201a08:	8526                	mv	a0,s1
    80201a0a:	00000097          	auipc	ra,0x0
    80201a0e:	a02080e7          	jalr	-1534(ra) # 8020140c <initlock>
        p->state  = UNUSED;
    80201a12:	0004ac23          	sw	zero,24(s1)
        p->kstack = 0;
    80201a16:	0404b023          	sd	zero,64(s1)
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201a1a:	1c048493          	addi	s1,s1,448
    80201a1e:	ff2494e3          	bne	s1,s2,80201a06 <procinit+0x6e>
}
    80201a22:	70a2                	ld	ra,40(sp)
    80201a24:	7402                	ld	s0,32(sp)
    80201a26:	64e2                	ld	s1,24(sp)
    80201a28:	6942                	ld	s2,16(sp)
    80201a2a:	69a2                	ld	s3,8(sp)
    80201a2c:	6145                	addi	sp,sp,48
    80201a2e:	8082                	ret

0000000080201a30 <userinit>:

/* --- the very first user process, built by hand --- */
extern char _binary_user_initcode_start[], _binary_user_initcode_end[];

void userinit(void)
{
    80201a30:	7179                	addi	sp,sp,-48
    80201a32:	f406                	sd	ra,40(sp)
    80201a34:	f022                	sd	s0,32(sp)
    80201a36:	ec26                	sd	s1,24(sp)
    80201a38:	e84a                	sd	s2,16(sp)
    80201a3a:	e44e                	sd	s3,8(sp)
    80201a3c:	1800                	addi	s0,sp,48
    struct proc *p = allocproc();
    80201a3e:	00000097          	auipc	ra,0x0
    80201a42:	cfe080e7          	jalr	-770(ra) # 8020173c <allocproc>
    if (!p) panic("userinit: allocproc failed");
    80201a46:	c569                	beqz	a0,80201b10 <userinit+0xe0>
    80201a48:	84aa                	mv	s1,a0
    initproc = p;
    80201a4a:	00158797          	auipc	a5,0x158
    80201a4e:	5ca7b323          	sd	a0,1478(a5) # 8035a010 <initproc>

    uint64 sz = (uint64)(_binary_user_initcode_end - _binary_user_initcode_start);
    80201a52:	00009997          	auipc	s3,0x9
    80201a56:	93698993          	addi	s3,s3,-1738 # 8020a388 <_binary_user_initcode_end>
    80201a5a:	00009797          	auipc	a5,0x9
    80201a5e:	8f678793          	addi	a5,a5,-1802 # 8020a350 <_binary_user_initcode_start>
    80201a62:	40f989b3          	sub	s3,s3,a5
    if (sz > PGSIZE) panic("userinit: initcode too big");
    80201a66:	6785                	lui	a5,0x1
    80201a68:	0b37ec63          	bltu	a5,s3,80201b20 <userinit+0xf0>

    char *mem = palloc();
    80201a6c:	fffff097          	auipc	ra,0xfffff
    80201a70:	67a080e7          	jalr	1658(ra) # 802010e6 <palloc>
    80201a74:	892a                	mv	s2,a0
    memset(mem, 0, PGSIZE);
    80201a76:	6605                	lui	a2,0x1
    80201a78:	4581                	li	a1,0
    80201a7a:	fffff097          	auipc	ra,0xfffff
    80201a7e:	c42080e7          	jalr	-958(ra) # 802006bc <memset>
    memmove(mem, _binary_user_initcode_start, sz);
    80201a82:	864e                	mv	a2,s3
    80201a84:	00009597          	auipc	a1,0x9
    80201a88:	8cc58593          	addi	a1,a1,-1844 # 8020a350 <_binary_user_initcode_start>
    80201a8c:	854a                	mv	a0,s2
    80201a8e:	fffff097          	auipc	ra,0xfffff
    80201a92:	c4a080e7          	jalr	-950(ra) # 802006d8 <memmove>
    mappages(p->pagetable, 0, PGSIZE, (uint64)mem, PTE_R | PTE_W | PTE_X | PTE_U);
    80201a96:	4779                	li	a4,30
    80201a98:	86ca                	mv	a3,s2
    80201a9a:	6605                	lui	a2,0x1
    80201a9c:	4581                	li	a1,0
    80201a9e:	68a8                	ld	a0,80(s1)
    80201aa0:	00001097          	auipc	ra,0x1
    80201aa4:	514080e7          	jalr	1300(ra) # 80202fb4 <mappages>

    char *stack = palloc();
    80201aa8:	fffff097          	auipc	ra,0xfffff
    80201aac:	63e080e7          	jalr	1598(ra) # 802010e6 <palloc>
    80201ab0:	892a                	mv	s2,a0
    memset(stack, 0, PGSIZE);
    80201ab2:	6605                	lui	a2,0x1
    80201ab4:	4581                	li	a1,0
    80201ab6:	fffff097          	auipc	ra,0xfffff
    80201aba:	c06080e7          	jalr	-1018(ra) # 802006bc <memset>
    mappages(p->pagetable, PGSIZE, PGSIZE, (uint64)stack, PTE_R | PTE_W | PTE_U);
    80201abe:	4759                	li	a4,22
    80201ac0:	86ca                	mv	a3,s2
    80201ac2:	6605                	lui	a2,0x1
    80201ac4:	6585                	lui	a1,0x1
    80201ac6:	68a8                	ld	a0,80(s1)
    80201ac8:	00001097          	auipc	ra,0x1
    80201acc:	4ec080e7          	jalr	1260(ra) # 80202fb4 <mappages>

    p->sz       = 2 * PGSIZE;
    80201ad0:	6789                	lui	a5,0x2
    80201ad2:	e4bc                	sd	a5,72(s1)
    p->tf->epc  = 0;                    /* start at the first byte of initcode */
    80201ad4:	6cb8                	ld	a4,88(s1)
    80201ad6:	00073c23          	sd	zero,24(a4) # 4018 <_entry-0x801fbfe8>
    p->tf->sp   = 2 * PGSIZE;           /* stack grows down from the top       */
    80201ada:	6cb8                	ld	a4,88(s1)
    80201adc:	fb1c                	sd	a5,48(a4)
    strncpy(p->name, "initcode", sizeof(p->name));
    80201ade:	4641                	li	a2,16
    80201ae0:	00008597          	auipc	a1,0x8
    80201ae4:	a6058593          	addi	a1,a1,-1440 # 80209540 <etext+0x540>
    80201ae8:	15848513          	addi	a0,s1,344
    80201aec:	fffff097          	auipc	ra,0xfffff
    80201af0:	c92080e7          	jalr	-878(ra) # 8020077e <strncpy>
    /* p->cwd is set by forkret once the filesystem is initialized. */
    p->state    = RUNNABLE;
    80201af4:	478d                	li	a5,3
    80201af6:	cc9c                	sw	a5,24(s1)
    release(&p->lock);
    80201af8:	8526                	mv	a0,s1
    80201afa:	00000097          	auipc	ra,0x0
    80201afe:	a42080e7          	jalr	-1470(ra) # 8020153c <release>
}
    80201b02:	70a2                	ld	ra,40(sp)
    80201b04:	7402                	ld	s0,32(sp)
    80201b06:	64e2                	ld	s1,24(sp)
    80201b08:	6942                	ld	s2,16(sp)
    80201b0a:	69a2                	ld	s3,8(sp)
    80201b0c:	6145                	addi	sp,sp,48
    80201b0e:	8082                	ret
    if (!p) panic("userinit: allocproc failed");
    80201b10:	00008517          	auipc	a0,0x8
    80201b14:	9f050513          	addi	a0,a0,-1552 # 80209500 <etext+0x500>
    80201b18:	fffff097          	auipc	ra,0xfffff
    80201b1c:	afe080e7          	jalr	-1282(ra) # 80200616 <panic>
    if (sz > PGSIZE) panic("userinit: initcode too big");
    80201b20:	00008517          	auipc	a0,0x8
    80201b24:	a0050513          	addi	a0,a0,-1536 # 80209520 <etext+0x520>
    80201b28:	fffff097          	auipc	ra,0xfffff
    80201b2c:	aee080e7          	jalr	-1298(ra) # 80200616 <panic>

0000000080201b30 <growproc>:

int growproc(int n)
{
    80201b30:	7139                	addi	sp,sp,-64
    80201b32:	fc06                	sd	ra,56(sp)
    80201b34:	f822                	sd	s0,48(sp)
    80201b36:	ec4e                	sd	s3,24(sp)
    80201b38:	e852                	sd	s4,16(sp)
    80201b3a:	e456                	sd	s5,8(sp)
    80201b3c:	0080                	addi	s0,sp,64
    80201b3e:	8a2a                	mv	s4,a0
    struct proc *p = myproc();
    80201b40:	00000097          	auipc	ra,0x0
    80201b44:	db0080e7          	jalr	-592(ra) # 802018f0 <myproc>
    80201b48:	89aa                	mv	s3,a0
    uint64 sz = p->sz;
    80201b4a:	04853a83          	ld	s5,72(a0)

    if (n > 0) {
    80201b4e:	07405863          	blez	s4,80201bbe <growproc+0x8e>
    80201b52:	f04a                	sd	s2,32(sp)
    80201b54:	e05a                	sd	s6,0(sp)
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    80201b56:	6905                	lui	s2,0x1
    80201b58:	197d                	addi	s2,s2,-1 # fff <_entry-0x801ff001>
    80201b5a:	9956                	add	s2,s2,s5
    80201b5c:	77fd                	lui	a5,0xfffff
    80201b5e:	00f97933          	and	s2,s2,a5
    80201b62:	015a0b33          	add	s6,s4,s5
    80201b66:	0b697263          	bgeu	s2,s6,80201c0a <growproc+0xda>
    80201b6a:	f426                	sd	s1,40(sp)
            char *mem = palloc();
    80201b6c:	fffff097          	auipc	ra,0xfffff
    80201b70:	57a080e7          	jalr	1402(ra) # 802010e6 <palloc>
    80201b74:	84aa                	mv	s1,a0
            if (!mem) return -1;
    80201b76:	cd49                	beqz	a0,80201c10 <growproc+0xe0>
            memset(mem, 0, PGSIZE);
    80201b78:	6605                	lui	a2,0x1
    80201b7a:	4581                	li	a1,0
    80201b7c:	fffff097          	auipc	ra,0xfffff
    80201b80:	b40080e7          	jalr	-1216(ra) # 802006bc <memset>
            if (mappages(p->pagetable, a, PGSIZE, (uint64)mem,
    80201b84:	4759                	li	a4,22
    80201b86:	86a6                	mv	a3,s1
    80201b88:	6605                	lui	a2,0x1
    80201b8a:	85ca                	mv	a1,s2
    80201b8c:	0509b503          	ld	a0,80(s3)
    80201b90:	00001097          	auipc	ra,0x1
    80201b94:	424080e7          	jalr	1060(ra) # 80202fb4 <mappages>
    80201b98:	e909                	bnez	a0,80201baa <growproc+0x7a>
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    80201b9a:	6785                	lui	a5,0x1
    80201b9c:	993e                	add	s2,s2,a5
    80201b9e:	fd6967e3          	bltu	s2,s6,80201b6c <growproc+0x3c>
    80201ba2:	74a2                	ld	s1,40(sp)
    80201ba4:	7902                	ld	s2,32(sp)
    80201ba6:	6b02                	ld	s6,0(sp)
    80201ba8:	a829                	j	80201bc2 <growproc+0x92>
                         PTE_R | PTE_W | PTE_U) != 0) {
                pfree(mem);
    80201baa:	8526                	mv	a0,s1
    80201bac:	fffff097          	auipc	ra,0xfffff
    80201bb0:	678080e7          	jalr	1656(ra) # 80201224 <pfree>
                return -1;
    80201bb4:	557d                	li	a0,-1
    80201bb6:	74a2                	ld	s1,40(sp)
    80201bb8:	7902                	ld	s2,32(sp)
    80201bba:	6b02                	ld	s6,0(sp)
    80201bbc:	a039                	j	80201bca <growproc+0x9a>
            }
        }
    } else if (n < 0) {
    80201bbe:	000a4d63          	bltz	s4,80201bd8 <growproc+0xa8>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
        sz = newsz;
        p->sz = sz;
        return 0;
    }
    p->sz = sz + n;
    80201bc2:	9a56                	add	s4,s4,s5
    80201bc4:	0549b423          	sd	s4,72(s3)
    return 0;
    80201bc8:	4501                	li	a0,0
}
    80201bca:	70e2                	ld	ra,56(sp)
    80201bcc:	7442                	ld	s0,48(sp)
    80201bce:	69e2                	ld	s3,24(sp)
    80201bd0:	6a42                	ld	s4,16(sp)
    80201bd2:	6aa2                	ld	s5,8(sp)
    80201bd4:	6121                	addi	sp,sp,64
    80201bd6:	8082                	ret
        uint64 newsz = sz + n;
    80201bd8:	9a56                	add	s4,s4,s5
        if (PGROUNDUP(newsz) < PGROUNDUP(sz))
    80201bda:	6785                	lui	a5,0x1
    80201bdc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80201bde:	00fa05b3          	add	a1,s4,a5
    80201be2:	777d                	lui	a4,0xfffff
    80201be4:	8df9                	and	a1,a1,a4
    80201be6:	97d6                	add	a5,a5,s5
    80201be8:	8ff9                	and	a5,a5,a4
    80201bea:	00f5e663          	bltu	a1,a5,80201bf6 <growproc+0xc6>
        p->sz = sz;
    80201bee:	0549b423          	sd	s4,72(s3)
        return 0;
    80201bf2:	4501                	li	a0,0
    80201bf4:	bfd9                	j	80201bca <growproc+0x9a>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
    80201bf6:	8f8d                	sub	a5,a5,a1
            uvmunmap(p->pagetable, PGROUNDUP(newsz),
    80201bf8:	4685                	li	a3,1
    80201bfa:	00c7d613          	srli	a2,a5,0xc
    80201bfe:	6928                	ld	a0,80(a0)
    80201c00:	00001097          	auipc	ra,0x1
    80201c04:	612080e7          	jalr	1554(ra) # 80203212 <uvmunmap>
    80201c08:	b7dd                	j	80201bee <growproc+0xbe>
    80201c0a:	7902                	ld	s2,32(sp)
    80201c0c:	6b02                	ld	s6,0(sp)
    80201c0e:	bf55                	j	80201bc2 <growproc+0x92>
            if (!mem) return -1;
    80201c10:	557d                	li	a0,-1
    80201c12:	74a2                	ld	s1,40(sp)
    80201c14:	7902                	ld	s2,32(sp)
    80201c16:	6b02                	ld	s6,0(sp)
    80201c18:	bf4d                	j	80201bca <growproc+0x9a>

0000000080201c1a <fork>:

int fork(void)
{
    80201c1a:	7139                	addi	sp,sp,-64
    80201c1c:	fc06                	sd	ra,56(sp)
    80201c1e:	f822                	sd	s0,48(sp)
    80201c20:	f04a                	sd	s2,32(sp)
    80201c22:	e456                	sd	s5,8(sp)
    80201c24:	0080                	addi	s0,sp,64
    struct proc *parent = myproc();
    80201c26:	00000097          	auipc	ra,0x0
    80201c2a:	cca080e7          	jalr	-822(ra) # 802018f0 <myproc>
    80201c2e:	8aaa                	mv	s5,a0
    struct proc *np = allocproc();
    80201c30:	00000097          	auipc	ra,0x0
    80201c34:	b0c080e7          	jalr	-1268(ra) # 8020173c <allocproc>
    if (!np) return -1;
    80201c38:	12050663          	beqz	a0,80201d64 <fork+0x14a>
    80201c3c:	ec4e                	sd	s3,24(sp)
    80201c3e:	89aa                	mv	s3,a0

    /* EAGER COPY: every user page is duplicated, right now. Simple, correct,
     * and O(memory) even for fork+exec - which is why Lab 5 replaces this
     * with copy-on-write. Do not bring COW forward; the graders diff it. */
    if (uvmcopy(parent->pagetable, np->pagetable, parent->sz) < 0) {
    80201c40:	048ab603          	ld	a2,72(s5)
    80201c44:	692c                	ld	a1,80(a0)
    80201c46:	050ab503          	ld	a0,80(s5)
    80201c4a:	00001097          	auipc	ra,0x1
    80201c4e:	678080e7          	jalr	1656(ra) # 802032c2 <uvmcopy>
    80201c52:	04054a63          	bltz	a0,80201ca6 <fork+0x8c>
    80201c56:	f426                	sd	s1,40(sp)
    80201c58:	e852                	sd	s4,16(sp)
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = parent->sz;
    80201c5a:	048ab783          	ld	a5,72(s5)
    80201c5e:	04f9b423          	sd	a5,72(s3)
    *(np->tf) = *(parent->tf);
    80201c62:	058ab683          	ld	a3,88(s5)
    80201c66:	87b6                	mv	a5,a3
    80201c68:	0589b703          	ld	a4,88(s3)
    80201c6c:	12068693          	addi	a3,a3,288
    80201c70:	0007b803          	ld	a6,0(a5)
    80201c74:	6788                	ld	a0,8(a5)
    80201c76:	6b8c                	ld	a1,16(a5)
    80201c78:	6f90                	ld	a2,24(a5)
    80201c7a:	01073023          	sd	a6,0(a4) # fffffffffffff000 <uart+0xffffffff7fca4fd0>
    80201c7e:	e708                	sd	a0,8(a4)
    80201c80:	eb0c                	sd	a1,16(a4)
    80201c82:	ef10                	sd	a2,24(a4)
    80201c84:	02078793          	addi	a5,a5,32
    80201c88:	02070713          	addi	a4,a4,32
    80201c8c:	fed792e3          	bne	a5,a3,80201c70 <fork+0x56>
    np->tf->a0 = 0;                 /* the child sees fork() return 0 */
    80201c90:	0589b783          	ld	a5,88(s3)
    80201c94:	0607b823          	sd	zero,112(a5)

    /* The child INHERITS the parent's open files and cwd - this is what makes
     * `cmd > file` work: the shell redirects, then forks, and the child keeps
     * the redirected descriptor. Same struct file, same offset. */
    for (int i = 0; i < NOFILE; i++)
    80201c98:	0d0a8493          	addi	s1,s5,208
    80201c9c:	0d098913          	addi	s2,s3,208
    80201ca0:	150a8a13          	addi	s4,s5,336
    80201ca4:	a015                	j	80201cc8 <fork+0xae>
        freeproc(np);
    80201ca6:	854e                	mv	a0,s3
    80201ca8:	00000097          	auipc	ra,0x0
    80201cac:	a06080e7          	jalr	-1530(ra) # 802016ae <freeproc>
        release(&np->lock);
    80201cb0:	854e                	mv	a0,s3
    80201cb2:	00000097          	auipc	ra,0x0
    80201cb6:	88a080e7          	jalr	-1910(ra) # 8020153c <release>
        return -1;
    80201cba:	597d                	li	s2,-1
    80201cbc:	69e2                	ld	s3,24(sp)
    80201cbe:	a861                	j	80201d56 <fork+0x13c>
    for (int i = 0; i < NOFILE; i++)
    80201cc0:	04a1                	addi	s1,s1,8
    80201cc2:	0921                	addi	s2,s2,8
    80201cc4:	01448b63          	beq	s1,s4,80201cda <fork+0xc0>
        if (parent->ofile[i])
    80201cc8:	6088                	ld	a0,0(s1)
    80201cca:	d97d                	beqz	a0,80201cc0 <fork+0xa6>
            np->ofile[i] = filedup(parent->ofile[i]);
    80201ccc:	00006097          	auipc	ra,0x6
    80201cd0:	d22080e7          	jalr	-734(ra) # 802079ee <filedup>
    80201cd4:	00a93023          	sd	a0,0(s2)
    80201cd8:	b7e5                	j	80201cc0 <fork+0xa6>
    np->cwd = idup(parent->cwd);
    80201cda:	150ab503          	ld	a0,336(s5)
    80201cde:	00005097          	auipc	ra,0x5
    80201ce2:	372080e7          	jalr	882(ra) # 80207050 <idup>
    80201ce6:	14a9b823          	sd	a0,336(s3)

    strncpy(np->name, parent->name, sizeof(np->name));
    80201cea:	4641                	li	a2,16
    80201cec:	158a8593          	addi	a1,s5,344
    80201cf0:	15898513          	addi	a0,s3,344
    80201cf4:	fffff097          	auipc	ra,0xfffff
    80201cf8:	a8a080e7          	jalr	-1398(ra) # 8020077e <strncpy>
    trace_fork(parent, np);   /* Lab 2 */
    80201cfc:	85ce                	mv	a1,s3
    80201cfe:	8556                	mv	a0,s5
    80201d00:	00003097          	auipc	ra,0x3
    80201d04:	3ac080e7          	jalr	940(ra) # 802050ac <trace_fork>
    int pid = np->pid;
    80201d08:	0309a903          	lw	s2,48(s3)
    release(&np->lock);
    80201d0c:	854e                	mv	a0,s3
    80201d0e:	00000097          	auipc	ra,0x0
    80201d12:	82e080e7          	jalr	-2002(ra) # 8020153c <release>

    acquire(&wait_lock);
    80201d16:	0002b497          	auipc	s1,0x2b
    80201d1a:	70248493          	addi	s1,s1,1794 # 8022d418 <wait_lock>
    80201d1e:	8526                	mv	a0,s1
    80201d20:	fffff097          	auipc	ra,0xfffff
    80201d24:	768080e7          	jalr	1896(ra) # 80201488 <acquire>
    np->parent = parent;
    80201d28:	0359bc23          	sd	s5,56(s3)
    release(&wait_lock);
    80201d2c:	8526                	mv	a0,s1
    80201d2e:	00000097          	auipc	ra,0x0
    80201d32:	80e080e7          	jalr	-2034(ra) # 8020153c <release>

    acquire(&np->lock);
    80201d36:	854e                	mv	a0,s3
    80201d38:	fffff097          	auipc	ra,0xfffff
    80201d3c:	750080e7          	jalr	1872(ra) # 80201488 <acquire>
    np->state = RUNNABLE;
    80201d40:	478d                	li	a5,3
    80201d42:	00f9ac23          	sw	a5,24(s3)
    release(&np->lock);
    80201d46:	854e                	mv	a0,s3
    80201d48:	fffff097          	auipc	ra,0xfffff
    80201d4c:	7f4080e7          	jalr	2036(ra) # 8020153c <release>
    return pid;
    80201d50:	74a2                	ld	s1,40(sp)
    80201d52:	69e2                	ld	s3,24(sp)
    80201d54:	6a42                	ld	s4,16(sp)
}
    80201d56:	854a                	mv	a0,s2
    80201d58:	70e2                	ld	ra,56(sp)
    80201d5a:	7442                	ld	s0,48(sp)
    80201d5c:	7902                	ld	s2,32(sp)
    80201d5e:	6aa2                	ld	s5,8(sp)
    80201d60:	6121                	addi	sp,sp,64
    80201d62:	8082                	ret
    if (!np) return -1;
    80201d64:	597d                	li	s2,-1
    80201d66:	bfc5                	j	80201d56 <fork+0x13c>

0000000080201d68 <clone>:
/* Lab 6: clone - a thread sharing the caller's address space. Unlike fork it
 * does not copy memory; it uses the parent's page table, its own user stack,
 * and starts at fn(arg). The LAST task using a shared page table frees it; a
 * per-proc is_thread flag tells freeproc not to free a shared page table. */
int clone(uint64 fn, uint64 arg, uint64 stack)
{
    80201d68:	7139                	addi	sp,sp,-64
    80201d6a:	fc06                	sd	ra,56(sp)
    80201d6c:	f822                	sd	s0,48(sp)
    80201d6e:	f426                	sd	s1,40(sp)
    80201d70:	f04a                	sd	s2,32(sp)
    80201d72:	e852                	sd	s4,16(sp)
    80201d74:	e456                	sd	s5,8(sp)
    80201d76:	0080                	addi	s0,sp,64
    80201d78:	8a2a                	mv	s4,a0
    80201d7a:	84ae                	mv	s1,a1
    80201d7c:	8932                	mv	s2,a2
    struct proc *parent = myproc();
    80201d7e:	00000097          	auipc	ra,0x0
    80201d82:	b72080e7          	jalr	-1166(ra) # 802018f0 <myproc>
    80201d86:	8aaa                	mv	s5,a0
    struct proc *np = allocproc();
    80201d88:	00000097          	auipc	ra,0x0
    80201d8c:	9b4080e7          	jalr	-1612(ra) # 8020173c <allocproc>
    if (!np) return -1;
    80201d90:	12050e63          	beqz	a0,80201ecc <clone+0x164>
    80201d94:	ec4e                	sd	s3,24(sp)
    80201d96:	89aa                	mv	s3,a0

    /* allocproc built a fresh page table + info page for np; discard them and
     * share the parent's address space instead. */
    usysinfo_free(np);
    80201d98:	00003097          	auipc	ra,0x3
    80201d9c:	38a080e7          	jalr	906(ra) # 80205122 <usysinfo_free>
    uvmfree(np->pagetable, 0);          /* np->sz==0: frees only pt pages */
    80201da0:	4581                	li	a1,0
    80201da2:	0509b503          	ld	a0,80(s3)
    80201da6:	00001097          	auipc	ra,0x1
    80201daa:	4e0080e7          	jalr	1248(ra) # 80203286 <uvmfree>
    np->pagetable = parent->pagetable;  /* SHARE */
    80201dae:	050ab783          	ld	a5,80(s5)
    80201db2:	04f9b823          	sd	a5,80(s3)
    np->sz = parent->sz;
    80201db6:	048ab783          	ld	a5,72(s5)
    80201dba:	04f9b423          	sd	a5,72(s3)
    np->is_thread = 1;
    80201dbe:	4785                	li	a5,1
    80201dc0:	18f9a623          	sw	a5,396(s3)
    np->tgid = parent->tgid ? parent->tgid : parent->pid;
    80201dc4:	190aa783          	lw	a5,400(s5)
    80201dc8:	e399                	bnez	a5,80201dce <clone+0x66>
    80201dca:	030aa783          	lw	a5,48(s5)
    80201dce:	18f9a823          	sw	a5,400(s3)
    np->usysinfo = 0;                   /* threads share AS; no own info page */
    80201dd2:	1609b823          	sd	zero,368(s3)

    *(np->tf) = *(parent->tf);
    80201dd6:	058ab683          	ld	a3,88(s5)
    80201dda:	87b6                	mv	a5,a3
    80201ddc:	0589b703          	ld	a4,88(s3)
    80201de0:	12068693          	addi	a3,a3,288
    80201de4:	638c                	ld	a1,0(a5)
    80201de6:	6790                	ld	a2,8(a5)
    80201de8:	0107b883          	ld	a7,16(a5)
    80201dec:	0187b803          	ld	a6,24(a5)
    80201df0:	e30c                	sd	a1,0(a4)
    80201df2:	e710                	sd	a2,8(a4)
    80201df4:	01173823          	sd	a7,16(a4)
    80201df8:	01073c23          	sd	a6,24(a4)
    80201dfc:	02078793          	addi	a5,a5,32
    80201e00:	02070713          	addi	a4,a4,32
    80201e04:	fed790e3          	bne	a5,a3,80201de4 <clone+0x7c>
    np->tf->epc = fn;                   /* entry point */
    80201e08:	0589b783          	ld	a5,88(s3)
    80201e0c:	0147bc23          	sd	s4,24(a5)
    np->tf->sp  = stack;                /* caller-provided stack */
    80201e10:	0589b783          	ld	a5,88(s3)
    80201e14:	0327b823          	sd	s2,48(a5)
    np->tf->a0  = arg;
    80201e18:	0589b783          	ld	a5,88(s3)
    80201e1c:	fba4                	sd	s1,112(a5)
    np->tf->ra  = 0;                    /* must call exit, not return */
    80201e1e:	0589b783          	ld	a5,88(s3)
    80201e22:	0207b423          	sd	zero,40(a5)

    for (int i = 0; i < NOFILE; i++)
    80201e26:	0d0a8493          	addi	s1,s5,208
    80201e2a:	0d098913          	addi	s2,s3,208
    80201e2e:	150a8a13          	addi	s4,s5,336
    80201e32:	a029                	j	80201e3c <clone+0xd4>
    80201e34:	04a1                	addi	s1,s1,8
    80201e36:	0921                	addi	s2,s2,8
    80201e38:	01448b63          	beq	s1,s4,80201e4e <clone+0xe6>
        if (parent->ofile[i])
    80201e3c:	6088                	ld	a0,0(s1)
    80201e3e:	d97d                	beqz	a0,80201e34 <clone+0xcc>
            np->ofile[i] = filedup(parent->ofile[i]);
    80201e40:	00006097          	auipc	ra,0x6
    80201e44:	bae080e7          	jalr	-1106(ra) # 802079ee <filedup>
    80201e48:	00a93023          	sd	a0,0(s2)
    80201e4c:	b7e5                	j	80201e34 <clone+0xcc>
    np->cwd = idup(parent->cwd);
    80201e4e:	150ab503          	ld	a0,336(s5)
    80201e52:	00005097          	auipc	ra,0x5
    80201e56:	1fe080e7          	jalr	510(ra) # 80207050 <idup>
    80201e5a:	14a9b823          	sd	a0,336(s3)
    strncpy(np->name, parent->name, sizeof(np->name));
    80201e5e:	4641                	li	a2,16
    80201e60:	158a8593          	addi	a1,s5,344
    80201e64:	15898513          	addi	a0,s3,344
    80201e68:	fffff097          	auipc	ra,0xfffff
    80201e6c:	916080e7          	jalr	-1770(ra) # 8020077e <strncpy>

    int tid = np->pid;
    80201e70:	0309a903          	lw	s2,48(s3)
    release(&np->lock);
    80201e74:	854e                	mv	a0,s3
    80201e76:	fffff097          	auipc	ra,0xfffff
    80201e7a:	6c6080e7          	jalr	1734(ra) # 8020153c <release>

    acquire(&wait_lock);
    80201e7e:	0002b497          	auipc	s1,0x2b
    80201e82:	59a48493          	addi	s1,s1,1434 # 8022d418 <wait_lock>
    80201e86:	8526                	mv	a0,s1
    80201e88:	fffff097          	auipc	ra,0xfffff
    80201e8c:	600080e7          	jalr	1536(ra) # 80201488 <acquire>
    np->parent = parent;
    80201e90:	0359bc23          	sd	s5,56(s3)
    release(&wait_lock);
    80201e94:	8526                	mv	a0,s1
    80201e96:	fffff097          	auipc	ra,0xfffff
    80201e9a:	6a6080e7          	jalr	1702(ra) # 8020153c <release>

    acquire(&np->lock);
    80201e9e:	854e                	mv	a0,s3
    80201ea0:	fffff097          	auipc	ra,0xfffff
    80201ea4:	5e8080e7          	jalr	1512(ra) # 80201488 <acquire>
    np->state = RUNNABLE;
    80201ea8:	478d                	li	a5,3
    80201eaa:	00f9ac23          	sw	a5,24(s3)
    release(&np->lock);
    80201eae:	854e                	mv	a0,s3
    80201eb0:	fffff097          	auipc	ra,0xfffff
    80201eb4:	68c080e7          	jalr	1676(ra) # 8020153c <release>
    return tid;
    80201eb8:	69e2                	ld	s3,24(sp)
}
    80201eba:	854a                	mv	a0,s2
    80201ebc:	70e2                	ld	ra,56(sp)
    80201ebe:	7442                	ld	s0,48(sp)
    80201ec0:	74a2                	ld	s1,40(sp)
    80201ec2:	7902                	ld	s2,32(sp)
    80201ec4:	6a42                	ld	s4,16(sp)
    80201ec6:	6aa2                	ld	s5,8(sp)
    80201ec8:	6121                	addi	sp,sp,64
    80201eca:	8082                	ret
    if (!np) return -1;
    80201ecc:	597d                	li	s2,-1
    80201ece:	b7f5                	j	80201eba <clone+0x152>

0000000080201ed0 <scheduler>:
    }
}

/* --- the scheduler: one instance per hart (L9) --- */
void scheduler(void)
{
    80201ed0:	715d                	addi	sp,sp,-80
    80201ed2:	e486                	sd	ra,72(sp)
    80201ed4:	e0a2                	sd	s0,64(sp)
    80201ed6:	fc26                	sd	s1,56(sp)
    80201ed8:	f84a                	sd	s2,48(sp)
    80201eda:	f44e                	sd	s3,40(sp)
    80201edc:	f052                	sd	s4,32(sp)
    80201ede:	ec56                	sd	s5,24(sp)
    80201ee0:	e85a                	sd	s6,16(sp)
    80201ee2:	e45e                	sd	s7,8(sp)
    80201ee4:	0880                	addi	s0,sp,80
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201ee6:	00006097          	auipc	ra,0x6
    80201eea:	26a080e7          	jalr	618(ra) # 80208150 <hal_hart_id>
    struct cpu *c = mycpu();
    c->proc = 0;
    80201eee:	00751b13          	slli	s6,a0,0x7
    80201ef2:	0002b717          	auipc	a4,0x2b
    80201ef6:	10e70713          	addi	a4,a4,270 # 8022d000 <pid_lock>
    80201efa:	975a                	add	a4,a4,s6
    80201efc:	00073c23          	sd	zero,24(a4)
                usysinfo_update(p);       /* Lab 3 */
                c->proc  = p;
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
                sfence_vma();

                swtch(&c->context, &p->context);
    80201f00:	0002b717          	auipc	a4,0x2b
    80201f04:	12070713          	addi	a4,a4,288 # 8022d020 <cpus+0x8>
    80201f08:	9b3a                	add	s6,s6,a4
                c->proc  = p;
    80201f0a:	00751793          	slli	a5,a0,0x7
    80201f0e:	0002ba97          	auipc	s5,0x2b
    80201f12:	0f2a8a93          	addi	s5,s5,242 # 8022d000 <pid_lock>
    80201f16:	9abe                	add	s5,s5,a5
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201f18:	5a7d                	li	s4,-1
    80201f1a:	1a7e                	slli	s4,s4,0x3f

                w_satp(MAKE_SATP(kernel_pagetable));
    80201f1c:	00158b97          	auipc	s7,0x158
    80201f20:	104b8b93          	addi	s7,s7,260 # 8035a020 <kernel_pagetable>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201f24:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80201f28:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201f2c:	10079073          	csrw	sstatus,a5
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f30:	0012c497          	auipc	s1,0x12c
    80201f34:	0d048493          	addi	s1,s1,208 # 8032e000 <proc>
            if (p->state == RUNNABLE) {
    80201f38:	498d                	li	s3,3
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f3a:	00133917          	auipc	s2,0x133
    80201f3e:	0c690913          	addi	s2,s2,198 # 80335000 <tickslock>
    80201f42:	a811                	j	80201f56 <scheduler+0x86>
                sfence_vma();
                c->proc = 0;
            }
            release(&p->lock);
    80201f44:	8526                	mv	a0,s1
    80201f46:	fffff097          	auipc	ra,0xfffff
    80201f4a:	5f6080e7          	jalr	1526(ra) # 8020153c <release>
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f4e:	1c048493          	addi	s1,s1,448
    80201f52:	fd2489e3          	beq	s1,s2,80201f24 <scheduler+0x54>
            acquire(&p->lock);
    80201f56:	8526                	mv	a0,s1
    80201f58:	fffff097          	auipc	ra,0xfffff
    80201f5c:	530080e7          	jalr	1328(ra) # 80201488 <acquire>
            if (p->state == RUNNABLE) {
    80201f60:	4c9c                	lw	a5,24(s1)
    80201f62:	ff3791e3          	bne	a5,s3,80201f44 <scheduler+0x74>
                p->state = RUNNING;
    80201f66:	4791                	li	a5,4
    80201f68:	cc9c                	sw	a5,24(s1)
                p->ctxsw_count++; p->state_gen++;
    80201f6a:	1804b783          	ld	a5,384(s1)
    80201f6e:	0785                	addi	a5,a5,1
    80201f70:	18f4b023          	sd	a5,384(s1)
    80201f74:	1884a783          	lw	a5,392(s1)
    80201f78:	2785                	addiw	a5,a5,1
    80201f7a:	18f4a423          	sw	a5,392(s1)
                usysinfo_update(p);       /* Lab 3 */
    80201f7e:	8526                	mv	a0,s1
    80201f80:	00003097          	auipc	ra,0x3
    80201f84:	20e080e7          	jalr	526(ra) # 8020518e <usysinfo_update>
                c->proc  = p;
    80201f88:	009abc23          	sd	s1,24(s5)
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201f8c:	68bc                	ld	a5,80(s1)
    80201f8e:	83b1                	srli	a5,a5,0xc
    80201f90:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201f94:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201f98:	12000073          	sfence.vma
                swtch(&c->context, &p->context);
    80201f9c:	06048593          	addi	a1,s1,96
    80201fa0:	855a                	mv	a0,s6
    80201fa2:	00000097          	auipc	ra,0x0
    80201fa6:	6f8080e7          	jalr	1784(ra) # 8020269a <swtch>
                w_satp(MAKE_SATP(kernel_pagetable));
    80201faa:	000bb783          	ld	a5,0(s7)
    80201fae:	83b1                	srli	a5,a5,0xc
    80201fb0:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201fb4:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201fb8:	12000073          	sfence.vma
                c->proc = 0;
    80201fbc:	000abc23          	sd	zero,24(s5)
    80201fc0:	b751                	j	80201f44 <scheduler+0x74>

0000000080201fc2 <sched>:
    }
}

/* Switch to the scheduler. Must hold p->lock and have changed p->state. */
void sched(void)
{
    80201fc2:	7179                	addi	sp,sp,-48
    80201fc4:	f406                	sd	ra,40(sp)
    80201fc6:	f022                	sd	s0,32(sp)
    80201fc8:	ec26                	sd	s1,24(sp)
    80201fca:	e84a                	sd	s2,16(sp)
    80201fcc:	e44e                	sd	s3,8(sp)
    80201fce:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    80201fd0:	00000097          	auipc	ra,0x0
    80201fd4:	920080e7          	jalr	-1760(ra) # 802018f0 <myproc>
    80201fd8:	84aa                	mv	s1,a0
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201fda:	fffff097          	auipc	ra,0xfffff
    80201fde:	448080e7          	jalr	1096(ra) # 80201422 <holding>
    80201fe2:	c541                	beqz	a0,8020206a <sched+0xa8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201fe4:	00006097          	auipc	ra,0x6
    80201fe8:	16c080e7          	jalr	364(ra) # 80208150 <hal_hart_id>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201fec:	051e                	slli	a0,a0,0x7
    80201fee:	0002b797          	auipc	a5,0x2b
    80201ff2:	01278793          	addi	a5,a5,18 # 8022d000 <pid_lock>
    80201ff6:	97aa                	add	a5,a5,a0
    80201ff8:	0907a703          	lw	a4,144(a5)
    80201ffc:	4785                	li	a5,1
    80201ffe:	06f71e63          	bne	a4,a5,8020207a <sched+0xb8>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80202002:	4c98                	lw	a4,24(s1)
    80202004:	4791                	li	a5,4
    80202006:	08f70263          	beq	a4,a5,8020208a <sched+0xc8>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020200a:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    8020200e:	8b89                	andi	a5,a5,2
    if (intr_get())           panic("sched: interrupts are on");
    80202010:	e7c9                	bnez	a5,8020209a <sched+0xd8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80202012:	00006097          	auipc	ra,0x6
    80202016:	13e080e7          	jalr	318(ra) # 80208150 <hal_hart_id>

    int intena = mycpu()->intena;
    8020201a:	0002b917          	auipc	s2,0x2b
    8020201e:	fe690913          	addi	s2,s2,-26 # 8022d000 <pid_lock>
    80202022:	00751793          	slli	a5,a0,0x7
    80202026:	97ca                	add	a5,a5,s2
    80202028:	0947a983          	lw	s3,148(a5)
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    8020202c:	00006097          	auipc	ra,0x6
    80202030:	124080e7          	jalr	292(ra) # 80208150 <hal_hart_id>
    swtch(&p->context, &mycpu()->context);
    80202034:	051e                	slli	a0,a0,0x7
    80202036:	0002b597          	auipc	a1,0x2b
    8020203a:	fea58593          	addi	a1,a1,-22 # 8022d020 <cpus+0x8>
    8020203e:	95aa                	add	a1,a1,a0
    80202040:	06048513          	addi	a0,s1,96
    80202044:	00000097          	auipc	ra,0x0
    80202048:	656080e7          	jalr	1622(ra) # 8020269a <swtch>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    8020204c:	00006097          	auipc	ra,0x6
    80202050:	104080e7          	jalr	260(ra) # 80208150 <hal_hart_id>
    mycpu()->intena = intena;
    80202054:	051e                	slli	a0,a0,0x7
    80202056:	992a                	add	s2,s2,a0
    80202058:	09392a23          	sw	s3,148(s2)
}
    8020205c:	70a2                	ld	ra,40(sp)
    8020205e:	7402                	ld	s0,32(sp)
    80202060:	64e2                	ld	s1,24(sp)
    80202062:	6942                	ld	s2,16(sp)
    80202064:	69a2                	ld	s3,8(sp)
    80202066:	6145                	addi	sp,sp,48
    80202068:	8082                	ret
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    8020206a:	00007517          	auipc	a0,0x7
    8020206e:	4e650513          	addi	a0,a0,1254 # 80209550 <etext+0x550>
    80202072:	ffffe097          	auipc	ra,0xffffe
    80202076:	5a4080e7          	jalr	1444(ra) # 80200616 <panic>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    8020207a:	00007517          	auipc	a0,0x7
    8020207e:	4f650513          	addi	a0,a0,1270 # 80209570 <etext+0x570>
    80202082:	ffffe097          	auipc	ra,0xffffe
    80202086:	594080e7          	jalr	1428(ra) # 80200616 <panic>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    8020208a:	00007517          	auipc	a0,0x7
    8020208e:	50650513          	addi	a0,a0,1286 # 80209590 <etext+0x590>
    80202092:	ffffe097          	auipc	ra,0xffffe
    80202096:	584080e7          	jalr	1412(ra) # 80200616 <panic>
    if (intr_get())           panic("sched: interrupts are on");
    8020209a:	00007517          	auipc	a0,0x7
    8020209e:	51650513          	addi	a0,a0,1302 # 802095b0 <etext+0x5b0>
    802020a2:	ffffe097          	auipc	ra,0xffffe
    802020a6:	574080e7          	jalr	1396(ra) # 80200616 <panic>

00000000802020aa <yield>:

void yield(void)
{
    802020aa:	1101                	addi	sp,sp,-32
    802020ac:	ec06                	sd	ra,24(sp)
    802020ae:	e822                	sd	s0,16(sp)
    802020b0:	e426                	sd	s1,8(sp)
    802020b2:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    802020b4:	00000097          	auipc	ra,0x0
    802020b8:	83c080e7          	jalr	-1988(ra) # 802018f0 <myproc>
    802020bc:	84aa                	mv	s1,a0
    acquire(&p->lock);
    802020be:	fffff097          	auipc	ra,0xfffff
    802020c2:	3ca080e7          	jalr	970(ra) # 80201488 <acquire>
    p->state = RUNNABLE;
    802020c6:	478d                	li	a5,3
    802020c8:	cc9c                	sw	a5,24(s1)
    sched();
    802020ca:	00000097          	auipc	ra,0x0
    802020ce:	ef8080e7          	jalr	-264(ra) # 80201fc2 <sched>
    release(&p->lock);
    802020d2:	8526                	mv	a0,s1
    802020d4:	fffff097          	auipc	ra,0xfffff
    802020d8:	468080e7          	jalr	1128(ra) # 8020153c <release>
}
    802020dc:	60e2                	ld	ra,24(sp)
    802020de:	6442                	ld	s0,16(sp)
    802020e0:	64a2                	ld	s1,8(sp)
    802020e2:	6105                	addi	sp,sp,32
    802020e4:	8082                	ret

00000000802020e6 <sleep>:

void sleep(void *chan, struct spinlock *lk)
{
    802020e6:	7179                	addi	sp,sp,-48
    802020e8:	f406                	sd	ra,40(sp)
    802020ea:	f022                	sd	s0,32(sp)
    802020ec:	ec26                	sd	s1,24(sp)
    802020ee:	e84a                	sd	s2,16(sp)
    802020f0:	e44e                	sd	s3,8(sp)
    802020f2:	1800                	addi	s0,sp,48
    802020f4:	89aa                	mv	s3,a0
    802020f6:	892e                	mv	s2,a1
    struct proc *p = myproc();
    802020f8:	fffff097          	auipc	ra,0xfffff
    802020fc:	7f8080e7          	jalr	2040(ra) # 802018f0 <myproc>
    80202100:	84aa                	mv	s1,a0

    /* Acquire p->lock BEFORE releasing lk. If we did it the other way round, a
     * wakeup could slip in between and be lost - the classic missed-wakeup race. */
    acquire(&p->lock);
    80202102:	fffff097          	auipc	ra,0xfffff
    80202106:	386080e7          	jalr	902(ra) # 80201488 <acquire>
    release(lk);
    8020210a:	854a                	mv	a0,s2
    8020210c:	fffff097          	auipc	ra,0xfffff
    80202110:	430080e7          	jalr	1072(ra) # 8020153c <release>

    p->chan  = chan;
    80202114:	0334b023          	sd	s3,32(s1)
    p->state = SLEEPING;
    80202118:	4789                	li	a5,2
    8020211a:	cc9c                	sw	a5,24(s1)
    sched();
    8020211c:	00000097          	auipc	ra,0x0
    80202120:	ea6080e7          	jalr	-346(ra) # 80201fc2 <sched>

    p->chan = 0;
    80202124:	0204b023          	sd	zero,32(s1)
    release(&p->lock);
    80202128:	8526                	mv	a0,s1
    8020212a:	fffff097          	auipc	ra,0xfffff
    8020212e:	412080e7          	jalr	1042(ra) # 8020153c <release>
    acquire(lk);
    80202132:	854a                	mv	a0,s2
    80202134:	fffff097          	auipc	ra,0xfffff
    80202138:	354080e7          	jalr	852(ra) # 80201488 <acquire>
}
    8020213c:	70a2                	ld	ra,40(sp)
    8020213e:	7402                	ld	s0,32(sp)
    80202140:	64e2                	ld	s1,24(sp)
    80202142:	6942                	ld	s2,16(sp)
    80202144:	69a2                	ld	s3,8(sp)
    80202146:	6145                	addi	sp,sp,48
    80202148:	8082                	ret

000000008020214a <wait>:
{
    8020214a:	715d                	addi	sp,sp,-80
    8020214c:	e486                	sd	ra,72(sp)
    8020214e:	e0a2                	sd	s0,64(sp)
    80202150:	fc26                	sd	s1,56(sp)
    80202152:	f84a                	sd	s2,48(sp)
    80202154:	f44e                	sd	s3,40(sp)
    80202156:	f052                	sd	s4,32(sp)
    80202158:	ec56                	sd	s5,24(sp)
    8020215a:	e85a                	sd	s6,16(sp)
    8020215c:	e45e                	sd	s7,8(sp)
    8020215e:	0880                	addi	s0,sp,80
    80202160:	8b2a                	mv	s6,a0
    struct proc *p = myproc();
    80202162:	fffff097          	auipc	ra,0xfffff
    80202166:	78e080e7          	jalr	1934(ra) # 802018f0 <myproc>
    8020216a:	892a                	mv	s2,a0
    acquire(&wait_lock);
    8020216c:	0002b517          	auipc	a0,0x2b
    80202170:	2ac50513          	addi	a0,a0,684 # 8022d418 <wait_lock>
    80202174:	fffff097          	auipc	ra,0xfffff
    80202178:	314080e7          	jalr	788(ra) # 80201488 <acquire>
        int havekids = 0;
    8020217c:	4b81                	li	s7,0
            if (pp->state == ZOMBIE) {
    8020217e:	4a15                	li	s4,5
            havekids = 1;
    80202180:	4a85                	li	s5,1
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202182:	00133997          	auipc	s3,0x133
    80202186:	e7e98993          	addi	s3,s3,-386 # 80335000 <tickslock>
    8020218a:	0012c497          	auipc	s1,0x12c
    8020218e:	e7648493          	addi	s1,s1,-394 # 8032e000 <proc>
        int havekids = 0;
    80202192:	875e                	mv	a4,s7
    80202194:	a051                	j	80202218 <wait+0xce>
                int pid = pp->pid;
    80202196:	0304a983          	lw	s3,48(s1)
                if (addr && copyout(p->pagetable, addr,
    8020219a:	000b0e63          	beqz	s6,802021b6 <wait+0x6c>
    8020219e:	4691                	li	a3,4
    802021a0:	02c48613          	addi	a2,s1,44
    802021a4:	85da                	mv	a1,s6
    802021a6:	05093503          	ld	a0,80(s2)
    802021aa:	00001097          	auipc	ra,0x1
    802021ae:	2b0080e7          	jalr	688(ra) # 8020345a <copyout>
    802021b2:	04054063          	bltz	a0,802021f2 <wait+0xa8>
                freeproc(pp);
    802021b6:	8526                	mv	a0,s1
    802021b8:	fffff097          	auipc	ra,0xfffff
    802021bc:	4f6080e7          	jalr	1270(ra) # 802016ae <freeproc>
                release(&pp->lock);
    802021c0:	8526                	mv	a0,s1
    802021c2:	fffff097          	auipc	ra,0xfffff
    802021c6:	37a080e7          	jalr	890(ra) # 8020153c <release>
                release(&wait_lock);
    802021ca:	0002b517          	auipc	a0,0x2b
    802021ce:	24e50513          	addi	a0,a0,590 # 8022d418 <wait_lock>
    802021d2:	fffff097          	auipc	ra,0xfffff
    802021d6:	36a080e7          	jalr	874(ra) # 8020153c <release>
}
    802021da:	854e                	mv	a0,s3
    802021dc:	60a6                	ld	ra,72(sp)
    802021de:	6406                	ld	s0,64(sp)
    802021e0:	74e2                	ld	s1,56(sp)
    802021e2:	7942                	ld	s2,48(sp)
    802021e4:	79a2                	ld	s3,40(sp)
    802021e6:	7a02                	ld	s4,32(sp)
    802021e8:	6ae2                	ld	s5,24(sp)
    802021ea:	6b42                	ld	s6,16(sp)
    802021ec:	6ba2                	ld	s7,8(sp)
    802021ee:	6161                	addi	sp,sp,80
    802021f0:	8082                	ret
                    release(&pp->lock);
    802021f2:	8526                	mv	a0,s1
    802021f4:	fffff097          	auipc	ra,0xfffff
    802021f8:	348080e7          	jalr	840(ra) # 8020153c <release>
                    release(&wait_lock);
    802021fc:	0002b517          	auipc	a0,0x2b
    80202200:	21c50513          	addi	a0,a0,540 # 8022d418 <wait_lock>
    80202204:	fffff097          	auipc	ra,0xfffff
    80202208:	338080e7          	jalr	824(ra) # 8020153c <release>
                    return -1;
    8020220c:	59fd                	li	s3,-1
    8020220e:	b7f1                	j	802021da <wait+0x90>
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202210:	1c048493          	addi	s1,s1,448
    80202214:	03348463          	beq	s1,s3,8020223c <wait+0xf2>
            if (pp->parent != p) continue;
    80202218:	7c9c                	ld	a5,56(s1)
    8020221a:	ff279be3          	bne	a5,s2,80202210 <wait+0xc6>
            acquire(&pp->lock);
    8020221e:	8526                	mv	a0,s1
    80202220:	fffff097          	auipc	ra,0xfffff
    80202224:	268080e7          	jalr	616(ra) # 80201488 <acquire>
            if (pp->state == ZOMBIE) {
    80202228:	4c9c                	lw	a5,24(s1)
    8020222a:	f74786e3          	beq	a5,s4,80202196 <wait+0x4c>
            release(&pp->lock);
    8020222e:	8526                	mv	a0,s1
    80202230:	fffff097          	auipc	ra,0xfffff
    80202234:	30c080e7          	jalr	780(ra) # 8020153c <release>
            havekids = 1;
    80202238:	8756                	mv	a4,s5
    8020223a:	bfd9                	j	80202210 <wait+0xc6>
        if (!havekids || p->killed) {
    8020223c:	cf11                	beqz	a4,80202258 <wait+0x10e>
    8020223e:	02892783          	lw	a5,40(s2)
    80202242:	eb99                	bnez	a5,80202258 <wait+0x10e>
        sleep(p, &wait_lock);
    80202244:	0002b597          	auipc	a1,0x2b
    80202248:	1d458593          	addi	a1,a1,468 # 8022d418 <wait_lock>
    8020224c:	854a                	mv	a0,s2
    8020224e:	00000097          	auipc	ra,0x0
    80202252:	e98080e7          	jalr	-360(ra) # 802020e6 <sleep>
    for (;;) {
    80202256:	bf15                	j	8020218a <wait+0x40>
            release(&wait_lock);
    80202258:	0002b517          	auipc	a0,0x2b
    8020225c:	1c050513          	addi	a0,a0,448 # 8022d418 <wait_lock>
    80202260:	fffff097          	auipc	ra,0xfffff
    80202264:	2dc080e7          	jalr	732(ra) # 8020153c <release>
            return -1;
    80202268:	59fd                	li	s3,-1
    8020226a:	bf85                	j	802021da <wait+0x90>

000000008020226c <wakeup>:

void wakeup(void *chan)
{
    8020226c:	7139                	addi	sp,sp,-64
    8020226e:	fc06                	sd	ra,56(sp)
    80202270:	f822                	sd	s0,48(sp)
    80202272:	f426                	sd	s1,40(sp)
    80202274:	f04a                	sd	s2,32(sp)
    80202276:	ec4e                	sd	s3,24(sp)
    80202278:	e852                	sd	s4,16(sp)
    8020227a:	e456                	sd	s5,8(sp)
    8020227c:	0080                	addi	s0,sp,64
    8020227e:	8a2a                	mv	s4,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202280:	0012c497          	auipc	s1,0x12c
    80202284:	d8048493          	addi	s1,s1,-640 # 8032e000 <proc>
        if (p != myproc()) {
            acquire(&p->lock);
            if (p->state == SLEEPING && p->chan == chan)
    80202288:	4989                	li	s3,2
                p->state = RUNNABLE;
    8020228a:	4a8d                	li	s5,3
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020228c:	00133917          	auipc	s2,0x133
    80202290:	d7490913          	addi	s2,s2,-652 # 80335000 <tickslock>
    80202294:	a811                	j	802022a8 <wakeup+0x3c>
            release(&p->lock);
    80202296:	8526                	mv	a0,s1
    80202298:	fffff097          	auipc	ra,0xfffff
    8020229c:	2a4080e7          	jalr	676(ra) # 8020153c <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802022a0:	1c048493          	addi	s1,s1,448
    802022a4:	03248663          	beq	s1,s2,802022d0 <wakeup+0x64>
        if (p != myproc()) {
    802022a8:	fffff097          	auipc	ra,0xfffff
    802022ac:	648080e7          	jalr	1608(ra) # 802018f0 <myproc>
    802022b0:	fea488e3          	beq	s1,a0,802022a0 <wakeup+0x34>
            acquire(&p->lock);
    802022b4:	8526                	mv	a0,s1
    802022b6:	fffff097          	auipc	ra,0xfffff
    802022ba:	1d2080e7          	jalr	466(ra) # 80201488 <acquire>
            if (p->state == SLEEPING && p->chan == chan)
    802022be:	4c9c                	lw	a5,24(s1)
    802022c0:	fd379be3          	bne	a5,s3,80202296 <wakeup+0x2a>
    802022c4:	709c                	ld	a5,32(s1)
    802022c6:	fd4798e3          	bne	a5,s4,80202296 <wakeup+0x2a>
                p->state = RUNNABLE;
    802022ca:	0154ac23          	sw	s5,24(s1)
    802022ce:	b7e1                	j	80202296 <wakeup+0x2a>
        }
    }
}
    802022d0:	70e2                	ld	ra,56(sp)
    802022d2:	7442                	ld	s0,48(sp)
    802022d4:	74a2                	ld	s1,40(sp)
    802022d6:	7902                	ld	s2,32(sp)
    802022d8:	69e2                	ld	s3,24(sp)
    802022da:	6a42                	ld	s4,16(sp)
    802022dc:	6aa2                	ld	s5,8(sp)
    802022de:	6121                	addi	sp,sp,64
    802022e0:	8082                	ret

00000000802022e2 <exit>:
{
    802022e2:	7139                	addi	sp,sp,-64
    802022e4:	fc06                	sd	ra,56(sp)
    802022e6:	f822                	sd	s0,48(sp)
    802022e8:	f426                	sd	s1,40(sp)
    802022ea:	f04a                	sd	s2,32(sp)
    802022ec:	ec4e                	sd	s3,24(sp)
    802022ee:	e456                	sd	s5,8(sp)
    802022f0:	0080                	addi	s0,sp,64
    802022f2:	8aaa                	mv	s5,a0
    struct proc *p = myproc();
    802022f4:	fffff097          	auipc	ra,0xfffff
    802022f8:	5fc080e7          	jalr	1532(ra) # 802018f0 <myproc>
    802022fc:	892a                	mv	s2,a0
    if (p == initproc) panic("init exiting");
    802022fe:	00158797          	auipc	a5,0x158
    80202302:	d127b783          	ld	a5,-750(a5) # 8035a010 <initproc>
    80202306:	0d050493          	addi	s1,a0,208
    8020230a:	15050993          	addi	s3,a0,336
    8020230e:	00a78463          	beq	a5,a0,80202316 <exit+0x34>
    80202312:	e852                	sd	s4,16(sp)
    80202314:	a01d                	j	8020233a <exit+0x58>
    80202316:	e852                	sd	s4,16(sp)
    80202318:	00007517          	auipc	a0,0x7
    8020231c:	2b850513          	addi	a0,a0,696 # 802095d0 <etext+0x5d0>
    80202320:	ffffe097          	auipc	ra,0xffffe
    80202324:	2f6080e7          	jalr	758(ra) # 80200616 <panic>
            fileclose(p->ofile[fd]);
    80202328:	00005097          	auipc	ra,0x5
    8020232c:	718080e7          	jalr	1816(ra) # 80207a40 <fileclose>
            p->ofile[fd] = 0;
    80202330:	0004b023          	sd	zero,0(s1)
    for (int fd = 0; fd < NOFILE; fd++) {
    80202334:	04a1                	addi	s1,s1,8
    80202336:	01348563          	beq	s1,s3,80202340 <exit+0x5e>
        if (p->ofile[fd]) {
    8020233a:	6088                	ld	a0,0(s1)
    8020233c:	f575                	bnez	a0,80202328 <exit+0x46>
    8020233e:	bfdd                	j	80202334 <exit+0x52>
    iput(p->cwd);
    80202340:	15093503          	ld	a0,336(s2)
    80202344:	00005097          	auipc	ra,0x5
    80202348:	f08080e7          	jalr	-248(ra) # 8020724c <iput>
    p->cwd = 0;
    8020234c:	14093823          	sd	zero,336(s2)
    mmap_cleanup(p);          /* Lab 10: unmap + flush shared dirty pages */
    80202350:	854a                	mv	a0,s2
    80202352:	00003097          	auipc	ra,0x3
    80202356:	51e080e7          	jalr	1310(ra) # 80205870 <mmap_cleanup>
    acquire(&wait_lock);
    8020235a:	0002b517          	auipc	a0,0x2b
    8020235e:	0be50513          	addi	a0,a0,190 # 8022d418 <wait_lock>
    80202362:	fffff097          	auipc	ra,0xfffff
    80202366:	126080e7          	jalr	294(ra) # 80201488 <acquire>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    8020236a:	0012c497          	auipc	s1,0x12c
    8020236e:	c9648493          	addi	s1,s1,-874 # 8032e000 <proc>
            pp->parent = initproc;
    80202372:	00158a17          	auipc	s4,0x158
    80202376:	c9ea0a13          	addi	s4,s4,-866 # 8035a010 <initproc>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    8020237a:	00133997          	auipc	s3,0x133
    8020237e:	c8698993          	addi	s3,s3,-890 # 80335000 <tickslock>
    80202382:	a821                	j	8020239a <exit+0xb8>
            pp->parent = initproc;
    80202384:	000a3503          	ld	a0,0(s4)
    80202388:	fc88                	sd	a0,56(s1)
            wakeup(initproc);
    8020238a:	00000097          	auipc	ra,0x0
    8020238e:	ee2080e7          	jalr	-286(ra) # 8020226c <wakeup>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202392:	1c048493          	addi	s1,s1,448
    80202396:	01348663          	beq	s1,s3,802023a2 <exit+0xc0>
        if (pp->parent == p) {
    8020239a:	7c9c                	ld	a5,56(s1)
    8020239c:	fef91be3          	bne	s2,a5,80202392 <exit+0xb0>
    802023a0:	b7d5                	j	80202384 <exit+0xa2>
    wakeup(p->parent);
    802023a2:	03893503          	ld	a0,56(s2)
    802023a6:	00000097          	auipc	ra,0x0
    802023aa:	ec6080e7          	jalr	-314(ra) # 8020226c <wakeup>
    acquire(&p->lock);
    802023ae:	854a                	mv	a0,s2
    802023b0:	fffff097          	auipc	ra,0xfffff
    802023b4:	0d8080e7          	jalr	216(ra) # 80201488 <acquire>
    p->xstate = status;
    802023b8:	03592623          	sw	s5,44(s2)
    p->state  = ZOMBIE;
    802023bc:	4795                	li	a5,5
    802023be:	00f92c23          	sw	a5,24(s2)
    release(&wait_lock);
    802023c2:	0002b517          	auipc	a0,0x2b
    802023c6:	05650513          	addi	a0,a0,86 # 8022d418 <wait_lock>
    802023ca:	fffff097          	auipc	ra,0xfffff
    802023ce:	172080e7          	jalr	370(ra) # 8020153c <release>
    sched();                        /* never returns */
    802023d2:	00000097          	auipc	ra,0x0
    802023d6:	bf0080e7          	jalr	-1040(ra) # 80201fc2 <sched>
    panic("zombie exit");
    802023da:	00007517          	auipc	a0,0x7
    802023de:	20650513          	addi	a0,a0,518 # 802095e0 <etext+0x5e0>
    802023e2:	ffffe097          	auipc	ra,0xffffe
    802023e6:	234080e7          	jalr	564(ra) # 80200616 <panic>

00000000802023ea <kill>:

int kill(int pid)
{
    802023ea:	7179                	addi	sp,sp,-48
    802023ec:	f406                	sd	ra,40(sp)
    802023ee:	f022                	sd	s0,32(sp)
    802023f0:	ec26                	sd	s1,24(sp)
    802023f2:	e84a                	sd	s2,16(sp)
    802023f4:	e44e                	sd	s3,8(sp)
    802023f6:	1800                	addi	s0,sp,48
    802023f8:	892a                	mv	s2,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802023fa:	0012c497          	auipc	s1,0x12c
    802023fe:	c0648493          	addi	s1,s1,-1018 # 8032e000 <proc>
    80202402:	00133997          	auipc	s3,0x133
    80202406:	bfe98993          	addi	s3,s3,-1026 # 80335000 <tickslock>
        acquire(&p->lock);
    8020240a:	8526                	mv	a0,s1
    8020240c:	fffff097          	auipc	ra,0xfffff
    80202410:	07c080e7          	jalr	124(ra) # 80201488 <acquire>
        if (p->pid == pid) {
    80202414:	589c                	lw	a5,48(s1)
    80202416:	01278d63          	beq	a5,s2,80202430 <kill+0x46>
            p->killed = 1;
            if (p->state == SLEEPING) p->state = RUNNABLE;
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    8020241a:	8526                	mv	a0,s1
    8020241c:	fffff097          	auipc	ra,0xfffff
    80202420:	120080e7          	jalr	288(ra) # 8020153c <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202424:	1c048493          	addi	s1,s1,448
    80202428:	ff3491e3          	bne	s1,s3,8020240a <kill+0x20>
    }
    return -1;
    8020242c:	557d                	li	a0,-1
    8020242e:	a829                	j	80202448 <kill+0x5e>
            p->killed = 1;
    80202430:	4785                	li	a5,1
    80202432:	d49c                	sw	a5,40(s1)
            if (p->state == SLEEPING) p->state = RUNNABLE;
    80202434:	4c98                	lw	a4,24(s1)
    80202436:	4789                	li	a5,2
    80202438:	00f70f63          	beq	a4,a5,80202456 <kill+0x6c>
            release(&p->lock);
    8020243c:	8526                	mv	a0,s1
    8020243e:	fffff097          	auipc	ra,0xfffff
    80202442:	0fe080e7          	jalr	254(ra) # 8020153c <release>
            return 0;
    80202446:	4501                	li	a0,0
}
    80202448:	70a2                	ld	ra,40(sp)
    8020244a:	7402                	ld	s0,32(sp)
    8020244c:	64e2                	ld	s1,24(sp)
    8020244e:	6942                	ld	s2,16(sp)
    80202450:	69a2                	ld	s3,8(sp)
    80202452:	6145                	addi	sp,sp,48
    80202454:	8082                	ret
            if (p->state == SLEEPING) p->state = RUNNABLE;
    80202456:	478d                	li	a5,3
    80202458:	cc9c                	sw	a5,24(s1)
    8020245a:	b7cd                	j	8020243c <kill+0x52>

000000008020245c <fdstat_lookup>:
 * procstat() syscall and the `ps` utility. Reads are racy-by-design (a
 * snapshot, not a transaction) but each slot is read under its own lock. */

/* Lab 1: read one fd's metadata from a target process, under its lock. */
int fdstat_lookup(int pid, int fd, struct fdinfo *fi)
{
    8020245c:	7139                	addi	sp,sp,-64
    8020245e:	fc06                	sd	ra,56(sp)
    80202460:	f822                	sd	s0,48(sp)
    80202462:	f426                	sd	s1,40(sp)
    80202464:	f04a                	sd	s2,32(sp)
    80202466:	ec4e                	sd	s3,24(sp)
    80202468:	e852                	sd	s4,16(sp)
    8020246a:	e456                	sd	s5,8(sp)
    8020246c:	0080                	addi	s0,sp,64
    8020246e:	89aa                	mv	s3,a0
    80202470:	8a2e                	mv	s4,a1
    80202472:	8ab2                	mv	s5,a2
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202474:	0012c497          	auipc	s1,0x12c
    80202478:	b8c48493          	addi	s1,s1,-1140 # 8032e000 <proc>
    8020247c:	00133917          	auipc	s2,0x133
    80202480:	b8490913          	addi	s2,s2,-1148 # 80335000 <tickslock>
    80202484:	a03d                	j	802024b2 <fdstat_lookup+0x56>
        acquire(&p->lock);
        if (p->state != UNUSED && p->pid == pid) {
            struct file *f = p->ofile[fd];
            if (f == 0) { release(&p->lock); return -1; }
    80202486:	8526                	mv	a0,s1
    80202488:	fffff097          	auipc	ra,0xfffff
    8020248c:	0b4080e7          	jalr	180(ra) # 8020153c <release>
    80202490:	557d                	li	a0,-1
    80202492:	a041                	j	80202512 <fdstat_lookup+0xb6>
            fi->type     = f->type;
            fi->readable = f->readable;
            fi->writable = f->writable;
            fi->off      = (f->type == FD_INODE) ? f->off : 0;
    80202494:	5398                	lw	a4,32(a5)
    80202496:	a8b1                	j	802024f2 <fdstat_lookup+0x96>
            fi->inum     = (f->type == FD_INODE || f->type == FD_DEVICE) && f->ip
    80202498:	6f9c                	ld	a5,24(a5)
    8020249a:	c7a5                	beqz	a5,80202502 <fdstat_lookup+0xa6>
                           ? f->ip->inum : 0;
    8020249c:	43d4                	lw	a3,4(a5)
    8020249e:	a095                	j	80202502 <fdstat_lookup+0xa6>
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    802024a0:	8526                	mv	a0,s1
    802024a2:	fffff097          	auipc	ra,0xfffff
    802024a6:	09a080e7          	jalr	154(ra) # 8020153c <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802024aa:	1c048493          	addi	s1,s1,448
    802024ae:	07248b63          	beq	s1,s2,80202524 <fdstat_lookup+0xc8>
        acquire(&p->lock);
    802024b2:	8526                	mv	a0,s1
    802024b4:	fffff097          	auipc	ra,0xfffff
    802024b8:	fd4080e7          	jalr	-44(ra) # 80201488 <acquire>
        if (p->state != UNUSED && p->pid == pid) {
    802024bc:	4c9c                	lw	a5,24(s1)
    802024be:	d3ed                	beqz	a5,802024a0 <fdstat_lookup+0x44>
    802024c0:	589c                	lw	a5,48(s1)
    802024c2:	fd379fe3          	bne	a5,s3,802024a0 <fdstat_lookup+0x44>
            struct file *f = p->ofile[fd];
    802024c6:	01aa0793          	addi	a5,s4,26
    802024ca:	078e                	slli	a5,a5,0x3
    802024cc:	97a6                	add	a5,a5,s1
    802024ce:	639c                	ld	a5,0(a5)
            if (f == 0) { release(&p->lock); return -1; }
    802024d0:	dbdd                	beqz	a5,80202486 <fdstat_lookup+0x2a>
            fi->type     = f->type;
    802024d2:	4398                	lw	a4,0(a5)
    802024d4:	00eaa023          	sw	a4,0(s5)
            fi->readable = f->readable;
    802024d8:	0087c703          	lbu	a4,8(a5)
    802024dc:	00eaa623          	sw	a4,12(s5)
            fi->writable = f->writable;
    802024e0:	0097c703          	lbu	a4,9(a5)
    802024e4:	00eaa823          	sw	a4,16(s5)
            fi->off      = (f->type == FD_INODE) ? f->off : 0;
    802024e8:	4390                	lw	a2,0(a5)
    802024ea:	4689                	li	a3,2
    802024ec:	4701                	li	a4,0
    802024ee:	fad603e3          	beq	a2,a3,80202494 <fdstat_lookup+0x38>
    802024f2:	00eaa423          	sw	a4,8(s5)
            fi->inum     = (f->type == FD_INODE || f->type == FD_DEVICE) && f->ip
    802024f6:	4398                	lw	a4,0(a5)
                           ? f->ip->inum : 0;
    802024f8:	3779                	addiw	a4,a4,-2
    802024fa:	4605                	li	a2,1
    802024fc:	4681                	li	a3,0
    802024fe:	f8e67de3          	bgeu	a2,a4,80202498 <fdstat_lookup+0x3c>
            fi->inum     = (f->type == FD_INODE || f->type == FD_DEVICE) && f->ip
    80202502:	00daa223          	sw	a3,4(s5)
            release(&p->lock);
    80202506:	8526                	mv	a0,s1
    80202508:	fffff097          	auipc	ra,0xfffff
    8020250c:	034080e7          	jalr	52(ra) # 8020153c <release>
            return 0;
    80202510:	4501                	li	a0,0
    }
    return -1;
}
    80202512:	70e2                	ld	ra,56(sp)
    80202514:	7442                	ld	s0,48(sp)
    80202516:	74a2                	ld	s1,40(sp)
    80202518:	7902                	ld	s2,32(sp)
    8020251a:	69e2                	ld	s3,24(sp)
    8020251c:	6a42                	ld	s4,16(sp)
    8020251e:	6aa2                	ld	s5,8(sp)
    80202520:	6121                	addi	sp,sp,64
    80202522:	8082                	ret
    return -1;
    80202524:	557d                	li	a0,-1
    80202526:	b7f5                	j	80202512 <fdstat_lookup+0xb6>

0000000080202528 <procstat>:

int procstat(uint64 uaddr, int max)
{
    80202528:	7159                	addi	sp,sp,-112
    8020252a:	f486                	sd	ra,104(sp)
    8020252c:	f0a2                	sd	s0,96(sp)
    8020252e:	e8ca                	sd	s2,80(sp)
    80202530:	1880                	addi	s0,sp,112
    struct pstat ps;
    int n = 0;
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    80202532:	0cb05463          	blez	a1,802025fa <procstat+0xd2>
    80202536:	eca6                	sd	s1,88(sp)
    80202538:	e4ce                	sd	s3,72(sp)
    8020253a:	e0d2                	sd	s4,64(sp)
    8020253c:	fc56                	sd	s5,56(sp)
    8020253e:	f85a                	sd	s6,48(sp)
    80202540:	f45e                	sd	s7,40(sp)
    80202542:	8a2a                	mv	s4,a0
    80202544:	89ae                	mv	s3,a1
    80202546:	0012c497          	auipc	s1,0x12c
    8020254a:	aba48493          	addi	s1,s1,-1350 # 8032e000 <proc>
    int n = 0;
    8020254e:	4901                	li	s2,0
        acquire(&p->lock);
        if (p->state == UNUSED) { release(&p->lock); continue; }
        ps.pid   = p->pid;
        ps.ppid  = p->parent ? p->parent->pid : 0;
    80202550:	4b01                	li	s6,0
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    80202552:	00133a97          	auipc	s5,0x133
    80202556:	aaea8a93          	addi	s5,s5,-1362 # 80335000 <tickslock>
    8020255a:	a0ad                	j	802025c4 <procstat+0x9c>
        if (p->state == UNUSED) { release(&p->lock); continue; }
    8020255c:	8526                	mv	a0,s1
    8020255e:	fffff097          	auipc	ra,0xfffff
    80202562:	fde080e7          	jalr	-34(ra) # 8020153c <release>
    80202566:	a889                	j	802025b8 <procstat+0x90>
        ps.ppid  = p->parent ? p->parent->pid : 0;
    80202568:	5a98                	lw	a4,48(a3)
    8020256a:	f8e42a23          	sw	a4,-108(s0)
        ps.state = p->state;
    8020256e:	f8f42c23          	sw	a5,-104(s0)
        memmove(ps.name, p->name, sizeof(ps.name));
    80202572:	4641                	li	a2,16
    80202574:	158b8593          	addi	a1,s7,344
    80202578:	f9c40513          	addi	a0,s0,-100
    8020257c:	ffffe097          	auipc	ra,0xffffe
    80202580:	15c080e7          	jalr	348(ra) # 802006d8 <memmove>
        release(&p->lock);
    80202584:	8526                	mv	a0,s1
    80202586:	fffff097          	auipc	ra,0xfffff
    8020258a:	fb6080e7          	jalr	-74(ra) # 8020153c <release>
        if (copyout(myproc()->pagetable, uaddr + n * sizeof(ps),
    8020258e:	fffff097          	auipc	ra,0xfffff
    80202592:	362080e7          	jalr	866(ra) # 802018f0 <myproc>
    80202596:	00391593          	slli	a1,s2,0x3
    8020259a:	412585b3          	sub	a1,a1,s2
    8020259e:	058a                	slli	a1,a1,0x2
    802025a0:	46f1                	li	a3,28
    802025a2:	f9040613          	addi	a2,s0,-112
    802025a6:	95d2                	add	a1,a1,s4
    802025a8:	6928                	ld	a0,80(a0)
    802025aa:	00001097          	auipc	ra,0x1
    802025ae:	eb0080e7          	jalr	-336(ra) # 8020345a <copyout>
    802025b2:	04054663          	bltz	a0,802025fe <procstat+0xd6>
                    (char *)&ps, sizeof(ps)) < 0)
            return -1;
        n++;
    802025b6:	2905                	addiw	s2,s2,1
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802025b8:	1c048493          	addi	s1,s1,448
    802025bc:	05548963          	beq	s1,s5,8020260e <procstat+0xe6>
    802025c0:	03395163          	bge	s2,s3,802025e2 <procstat+0xba>
        acquire(&p->lock);
    802025c4:	8ba6                	mv	s7,s1
    802025c6:	8526                	mv	a0,s1
    802025c8:	fffff097          	auipc	ra,0xfffff
    802025cc:	ec0080e7          	jalr	-320(ra) # 80201488 <acquire>
        if (p->state == UNUSED) { release(&p->lock); continue; }
    802025d0:	4c9c                	lw	a5,24(s1)
    802025d2:	d7c9                	beqz	a5,8020255c <procstat+0x34>
        ps.pid   = p->pid;
    802025d4:	5898                	lw	a4,48(s1)
    802025d6:	f8e42823          	sw	a4,-112(s0)
        ps.ppid  = p->parent ? p->parent->pid : 0;
    802025da:	7c94                	ld	a3,56(s1)
    802025dc:	875a                	mv	a4,s6
    802025de:	f6c9                	bnez	a3,80202568 <procstat+0x40>
    802025e0:	b769                	j	8020256a <procstat+0x42>
    802025e2:	64e6                	ld	s1,88(sp)
    802025e4:	69a6                	ld	s3,72(sp)
    802025e6:	6a06                	ld	s4,64(sp)
    802025e8:	7ae2                	ld	s5,56(sp)
    802025ea:	7b42                	ld	s6,48(sp)
    802025ec:	7ba2                	ld	s7,40(sp)
    }
    return n;
}
    802025ee:	854a                	mv	a0,s2
    802025f0:	70a6                	ld	ra,104(sp)
    802025f2:	7406                	ld	s0,96(sp)
    802025f4:	6946                	ld	s2,80(sp)
    802025f6:	6165                	addi	sp,sp,112
    802025f8:	8082                	ret
    return n;
    802025fa:	4901                	li	s2,0
    802025fc:	bfcd                	j	802025ee <procstat+0xc6>
            return -1;
    802025fe:	597d                	li	s2,-1
    80202600:	64e6                	ld	s1,88(sp)
    80202602:	69a6                	ld	s3,72(sp)
    80202604:	6a06                	ld	s4,64(sp)
    80202606:	7ae2                	ld	s5,56(sp)
    80202608:	7b42                	ld	s6,48(sp)
    8020260a:	7ba2                	ld	s7,40(sp)
    8020260c:	b7cd                	j	802025ee <procstat+0xc6>
    8020260e:	64e6                	ld	s1,88(sp)
    80202610:	69a6                	ld	s3,72(sp)
    80202612:	6a06                	ld	s4,64(sp)
    80202614:	7ae2                	ld	s5,56(sp)
    80202616:	7b42                	ld	s6,48(sp)
    80202618:	7ba2                	ld	s7,40(sp)
    8020261a:	bfd1                	j	802025ee <procstat+0xc6>

000000008020261c <procdump>:

void procdump(void)
{
    8020261c:	7179                	addi	sp,sp,-48
    8020261e:	f406                	sd	ra,40(sp)
    80202620:	f022                	sd	s0,32(sp)
    80202622:	ec26                	sd	s1,24(sp)
    80202624:	e84a                	sd	s2,16(sp)
    80202626:	e44e                	sd	s3,8(sp)
    80202628:	e052                	sd	s4,0(sp)
    8020262a:	1800                	addi	s0,sp,48
    static const char *st[] = {
        [UNUSED]"unused", [USED]"used", [SLEEPING]"sleep",
        [RUNNABLE]"runble", [RUNNING]"run", [ZOMBIE]"zombie"
    };
    printf("\n--- process table ---\n");
    8020262c:	00007517          	auipc	a0,0x7
    80202630:	fc450513          	addi	a0,a0,-60 # 802095f0 <etext+0x5f0>
    80202634:	ffffe097          	auipc	ra,0xffffe
    80202638:	d70080e7          	jalr	-656(ra) # 802003a4 <printf>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020263c:	0012c497          	auipc	s1,0x12c
    80202640:	b1c48493          	addi	s1,s1,-1252 # 8032e158 <proc+0x158>
    80202644:	00133917          	auipc	s2,0x133
    80202648:	b1490913          	addi	s2,s2,-1260 # 80335158 <rings+0x140>
        if (p->state == UNUSED) continue;
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    8020264c:	00008a17          	auipc	s4,0x8
    80202650:	9aca0a13          	addi	s4,s4,-1620 # 80209ff8 <st.0>
    80202654:	00007997          	auipc	s3,0x7
    80202658:	fb498993          	addi	s3,s3,-76 # 80209608 <etext+0x608>
    8020265c:	a029                	j	80202666 <procdump+0x4a>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020265e:	1c048493          	addi	s1,s1,448
    80202662:	03248463          	beq	s1,s2,8020268a <procdump+0x6e>
        if (p->state == UNUSED) continue;
    80202666:	ec04a783          	lw	a5,-320(s1)
    8020266a:	dbf5                	beqz	a5,8020265e <procdump+0x42>
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    8020266c:	02079713          	slli	a4,a5,0x20
    80202670:	01d75793          	srli	a5,a4,0x1d
    80202674:	97d2                	add	a5,a5,s4
    80202676:	86a6                	mv	a3,s1
    80202678:	6390                	ld	a2,0(a5)
    8020267a:	ed84a583          	lw	a1,-296(s1)
    8020267e:	854e                	mv	a0,s3
    80202680:	ffffe097          	auipc	ra,0xffffe
    80202684:	d24080e7          	jalr	-732(ra) # 802003a4 <printf>
    80202688:	bfd9                	j	8020265e <procdump+0x42>
    }
}
    8020268a:	70a2                	ld	ra,40(sp)
    8020268c:	7402                	ld	s0,32(sp)
    8020268e:	64e2                	ld	s1,24(sp)
    80202690:	6942                	ld	s2,16(sp)
    80202692:	69a2                	ld	s3,8(sp)
    80202694:	6a02                	ld	s4,0(sp)
    80202696:	6145                	addi	sp,sp,48
    80202698:	8082                	ret

000000008020269a <swtch>:
# L7 - context switch. Only the CALLEE-SAVED registers need saving: the C
# calling convention says the caller already spilled anything else it cared about.
# Nine loads, nine stores, one ret - and a process wakes up years later, unaware.
        .globl swtch
swtch:
        sd ra,  0(a0)
    8020269a:	00153023          	sd	ra,0(a0)
        sd sp,  8(a0)
    8020269e:	00253423          	sd	sp,8(a0)
        sd s0,  16(a0)
    802026a2:	e900                	sd	s0,16(a0)
        sd s1,  24(a0)
    802026a4:	ed04                	sd	s1,24(a0)
        sd s2,  32(a0)
    802026a6:	03253023          	sd	s2,32(a0)
        sd s3,  40(a0)
    802026aa:	03353423          	sd	s3,40(a0)
        sd s4,  48(a0)
    802026ae:	03453823          	sd	s4,48(a0)
        sd s5,  56(a0)
    802026b2:	03553c23          	sd	s5,56(a0)
        sd s6,  64(a0)
    802026b6:	05653023          	sd	s6,64(a0)
        sd s7,  72(a0)
    802026ba:	05753423          	sd	s7,72(a0)
        sd s8,  80(a0)
    802026be:	05853823          	sd	s8,80(a0)
        sd s9,  88(a0)
    802026c2:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    802026c6:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    802026ca:	07b53423          	sd	s11,104(a0)

        ld ra,  0(a1)
    802026ce:	0005b083          	ld	ra,0(a1)
        ld sp,  8(a1)
    802026d2:	0085b103          	ld	sp,8(a1)
        ld s0,  16(a1)
    802026d6:	6980                	ld	s0,16(a1)
        ld s1,  24(a1)
    802026d8:	6d84                	ld	s1,24(a1)
        ld s2,  32(a1)
    802026da:	0205b903          	ld	s2,32(a1)
        ld s3,  40(a1)
    802026de:	0285b983          	ld	s3,40(a1)
        ld s4,  48(a1)
    802026e2:	0305ba03          	ld	s4,48(a1)
        ld s5,  56(a1)
    802026e6:	0385ba83          	ld	s5,56(a1)
        ld s6,  64(a1)
    802026ea:	0405bb03          	ld	s6,64(a1)
        ld s7,  72(a1)
    802026ee:	0485bb83          	ld	s7,72(a1)
        ld s8,  80(a1)
    802026f2:	0505bc03          	ld	s8,80(a1)
        ld s9,  88(a1)
    802026f6:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    802026fa:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    802026fe:	0685bd83          	ld	s11,104(a1)
        ret
    80202702:	8082                	ret

0000000080202704 <cause_str>:
    }
    return 0;
}

static const char *cause_str(uint64 c)
{
    80202704:	1141                	addi	sp,sp,-16
    80202706:	e422                	sd	s0,8(sp)
    80202708:	0800                	addi	s0,sp,16
    switch (c) {
    8020270a:	47bd                	li	a5,15
    8020270c:	06a7ea63          	bltu	a5,a0,80202780 <cause_str+0x7c>
    80202710:	050a                	slli	a0,a0,0x2
    80202712:	00008717          	auipc	a4,0x8
    80202716:	91670713          	addi	a4,a4,-1770 # 8020a028 <st.0+0x30>
    8020271a:	953a                	add	a0,a0,a4
    8020271c:	411c                	lw	a5,0(a0)
    8020271e:	97ba                	add	a5,a5,a4
    80202720:	8782                	jr	a5
    case 0:  return "instruction address misaligned";
    80202722:	00007517          	auipc	a0,0x7
    80202726:	f2650513          	addi	a0,a0,-218 # 80209648 <etext+0x648>
    8020272a:	a029                	j	80202734 <cause_str+0x30>
    case 1:  return "instruction access fault";
    case 2:  return "illegal instruction";
    8020272c:	00007517          	auipc	a0,0x7
    80202730:	f5c50513          	addi	a0,a0,-164 # 80209688 <etext+0x688>
    case 12: return "instruction page fault";
    case 13: return "load page fault";
    case 15: return "store page fault";
    default: return "unknown";
    }
}
    80202734:	6422                	ld	s0,8(sp)
    80202736:	0141                	addi	sp,sp,16
    80202738:	8082                	ret
    case 3:  return "breakpoint";
    8020273a:	00007517          	auipc	a0,0x7
    8020273e:	f6650513          	addi	a0,a0,-154 # 802096a0 <etext+0x6a0>
    80202742:	bfcd                	j	80202734 <cause_str+0x30>
    case 5:  return "load access fault";
    80202744:	00007517          	auipc	a0,0x7
    80202748:	f6c50513          	addi	a0,a0,-148 # 802096b0 <etext+0x6b0>
    8020274c:	b7e5                	j	80202734 <cause_str+0x30>
    case 7:  return "store access fault";
    8020274e:	00007517          	auipc	a0,0x7
    80202752:	f7a50513          	addi	a0,a0,-134 # 802096c8 <etext+0x6c8>
    80202756:	bff9                	j	80202734 <cause_str+0x30>
    case 8:  return "ecall from user";
    80202758:	00007517          	auipc	a0,0x7
    8020275c:	f8850513          	addi	a0,a0,-120 # 802096e0 <etext+0x6e0>
    80202760:	bfd1                	j	80202734 <cause_str+0x30>
    case 12: return "instruction page fault";
    80202762:	00007517          	auipc	a0,0x7
    80202766:	f8e50513          	addi	a0,a0,-114 # 802096f0 <etext+0x6f0>
    8020276a:	b7e9                	j	80202734 <cause_str+0x30>
    case 13: return "load page fault";
    8020276c:	00007517          	auipc	a0,0x7
    80202770:	f9c50513          	addi	a0,a0,-100 # 80209708 <etext+0x708>
    80202774:	b7c1                	j	80202734 <cause_str+0x30>
    case 15: return "store page fault";
    80202776:	00007517          	auipc	a0,0x7
    8020277a:	fa250513          	addi	a0,a0,-94 # 80209718 <etext+0x718>
    8020277e:	bf5d                	j	80202734 <cause_str+0x30>
    default: return "unknown";
    80202780:	00007517          	auipc	a0,0x7
    80202784:	fb050513          	addi	a0,a0,-80 # 80209730 <etext+0x730>
    80202788:	b775                	j	80202734 <cause_str+0x30>
    switch (c) {
    8020278a:	00007517          	auipc	a0,0x7
    8020278e:	ede50513          	addi	a0,a0,-290 # 80209668 <etext+0x668>
    80202792:	b74d                	j	80202734 <cause_str+0x30>

0000000080202794 <devintr>:
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80202794:	142027f3          	csrr	a5,scause
    if (!(scause & 0x8000000000000000UL)) return 0;   /* top bit = interrupt */
    80202798:	4501                	li	a0,0
    8020279a:	0e07da63          	bgez	a5,8020288e <devintr+0xfa>
{
    8020279e:	1101                	addi	sp,sp,-32
    802027a0:	ec06                	sd	ra,24(sp)
    802027a2:	e822                	sd	s0,16(sp)
    802027a4:	1000                	addi	s0,sp,32
    uint64 code = scause & 0xff;
    802027a6:	0ff7f793          	zext.b	a5,a5
    if (code == 9) {                     /* supervisor external -> PLIC */
    802027aa:	4725                	li	a4,9
    802027ac:	00e78a63          	beq	a5,a4,802027c0 <devintr+0x2c>
    if (code == 5) {
    802027b0:	4715                	li	a4,5
    return 0;
    802027b2:	4501                	li	a0,0
    if (code == 5) {
    802027b4:	08e78263          	beq	a5,a4,80202838 <devintr+0xa4>
}
    802027b8:	60e2                	ld	ra,24(sp)
    802027ba:	6442                	ld	s0,16(sp)
    802027bc:	6105                	addi	sp,sp,32
    802027be:	8082                	ret
    802027c0:	e426                	sd	s1,8(sp)
        int irq = hal_intc_claim();
    802027c2:	00006097          	auipc	ra,0x6
    802027c6:	936080e7          	jalr	-1738(ra) # 802080f8 <hal_intc_claim>
    802027ca:	84aa                	mv	s1,a0
        if (irq == fdt.uart_irq) {
    802027cc:	0002a797          	auipc	a5,0x2a
    802027d0:	86c7a783          	lw	a5,-1940(a5) # 8022c038 <fdt+0x20>
    802027d4:	00a78663          	beq	a5,a0,802027e0 <devintr+0x4c>
        return 1;
    802027d8:	4505                	li	a0,1
        } else if (irq && irq == hal_block_irq()) {
    802027da:	e09d                	bnez	s1,80202800 <devintr+0x6c>
    802027dc:	64a2                	ld	s1,8(sp)
    802027de:	bfe9                	j	802027b8 <devintr+0x24>
            int c = hal_console_getc();
    802027e0:	00006097          	auipc	ra,0x6
    802027e4:	a7c080e7          	jalr	-1412(ra) # 8020825c <hal_console_getc>
            if (c != -1) consoleintr(c);
    802027e8:	57fd                	li	a5,-1
    802027ea:	00f51663          	bne	a0,a5,802027f6 <devintr+0x62>
        return 1;
    802027ee:	4505                	li	a0,1
        if (irq) hal_intc_complete(irq);
    802027f0:	e49d                	bnez	s1,8020281e <devintr+0x8a>
    802027f2:	64a2                	ld	s1,8(sp)
    802027f4:	b7d1                	j	802027b8 <devintr+0x24>
            if (c != -1) consoleintr(c);
    802027f6:	00004097          	auipc	ra,0x4
    802027fa:	a6a080e7          	jalr	-1430(ra) # 80206260 <consoleintr>
    802027fe:	bfc5                	j	802027ee <devintr+0x5a>
        } else if (irq && irq == hal_block_irq()) {
    80202800:	00006097          	auipc	ra,0x6
    80202804:	afc080e7          	jalr	-1284(ra) # 802082fc <hal_block_irq>
    80202808:	02950363          	beq	a0,s1,8020282e <devintr+0x9a>
            printf("devintr: unexpected PLIC irq %d\n", irq);
    8020280c:	85a6                	mv	a1,s1
    8020280e:	00007517          	auipc	a0,0x7
    80202812:	f2a50513          	addi	a0,a0,-214 # 80209738 <etext+0x738>
    80202816:	ffffe097          	auipc	ra,0xffffe
    8020281a:	b8e080e7          	jalr	-1138(ra) # 802003a4 <printf>
        if (irq) hal_intc_complete(irq);
    8020281e:	8526                	mv	a0,s1
    80202820:	00006097          	auipc	ra,0x6
    80202824:	904080e7          	jalr	-1788(ra) # 80208124 <hal_intc_complete>
        return 1;
    80202828:	4505                	li	a0,1
    8020282a:	64a2                	ld	s1,8(sp)
    8020282c:	b771                	j	802027b8 <devintr+0x24>
            hal_block_intr();
    8020282e:	00006097          	auipc	ra,0x6
    80202832:	f80080e7          	jalr	-128(ra) # 802087ae <hal_block_intr>
    80202836:	b7e5                	j	8020281e <devintr+0x8a>
        if (hal_hart_id() == 0) {        /* only hart 0 keeps the clock */
    80202838:	00006097          	auipc	ra,0x6
    8020283c:	918080e7          	jalr	-1768(ra) # 80208150 <hal_hart_id>
    80202840:	c919                	beqz	a0,80202856 <devintr+0xc2>
        hal_timer_next(1000000);
    80202842:	000f4537          	lui	a0,0xf4
    80202846:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    8020284a:	00006097          	auipc	ra,0x6
    8020284e:	976080e7          	jalr	-1674(ra) # 802081c0 <hal_timer_next>
        return 2;
    80202852:	4509                	li	a0,2
    80202854:	b795                	j	802027b8 <devintr+0x24>
    80202856:	e426                	sd	s1,8(sp)
            acquire(&tickslock);
    80202858:	00132497          	auipc	s1,0x132
    8020285c:	7a848493          	addi	s1,s1,1960 # 80335000 <tickslock>
    80202860:	8526                	mv	a0,s1
    80202862:	fffff097          	auipc	ra,0xfffff
    80202866:	c26080e7          	jalr	-986(ra) # 80201488 <acquire>
            ticks++;
    8020286a:	00157517          	auipc	a0,0x157
    8020286e:	7ae50513          	addi	a0,a0,1966 # 8035a018 <ticks>
    80202872:	611c                	ld	a5,0(a0)
    80202874:	0785                	addi	a5,a5,1
    80202876:	e11c                	sd	a5,0(a0)
            wakeup(&ticks);
    80202878:	00000097          	auipc	ra,0x0
    8020287c:	9f4080e7          	jalr	-1548(ra) # 8020226c <wakeup>
            release(&tickslock);
    80202880:	8526                	mv	a0,s1
    80202882:	fffff097          	auipc	ra,0xfffff
    80202886:	cba080e7          	jalr	-838(ra) # 8020153c <release>
    8020288a:	64a2                	ld	s1,8(sp)
    8020288c:	bf5d                	j	80202842 <devintr+0xae>
}
    8020288e:	8082                	ret

0000000080202890 <trapinit_hart>:
{
    80202890:	1101                	addi	sp,sp,-32
    80202892:	ec06                	sd	ra,24(sp)
    80202894:	e822                	sd	s0,16(sp)
    80202896:	e426                	sd	s1,8(sp)
    80202898:	1000                	addi	s0,sp,32
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    8020289a:	00000797          	auipc	a5,0x0
    8020289e:	36678793          	addi	a5,a5,870 # 80202c00 <kernelvec>
    802028a2:	10579073          	csrw	stvec,a5
    hal_intc_enable(fdt.uart_irq);              /* priority 1; 0 = never fires */
    802028a6:	00029497          	auipc	s1,0x29
    802028aa:	77248493          	addi	s1,s1,1906 # 8022c018 <fdt>
    802028ae:	5088                	lw	a0,32(s1)
    802028b0:	00005097          	auipc	ra,0x5
    802028b4:	7be080e7          	jalr	1982(ra) # 8020806e <hal_intc_enable>
    hal_intc_hart_init(hal_hart_id());
    802028b8:	00006097          	auipc	ra,0x6
    802028bc:	898080e7          	jalr	-1896(ra) # 80208150 <hal_hart_id>
    802028c0:	00005097          	auipc	ra,0x5
    802028c4:	7ce080e7          	jalr	1998(ra) # 8020808e <hal_intc_hart_init>
    hal_intc_enable_hart(hal_hart_id(), fdt.uart_irq);
    802028c8:	00006097          	auipc	ra,0x6
    802028cc:	888080e7          	jalr	-1912(ra) # 80208150 <hal_hart_id>
    802028d0:	508c                	lw	a1,32(s1)
    802028d2:	00005097          	auipc	ra,0x5
    802028d6:	7e2080e7          	jalr	2018(ra) # 802080b4 <hal_intc_enable_hart>
    if (hal_block_irq()) {
    802028da:	00006097          	auipc	ra,0x6
    802028de:	a22080e7          	jalr	-1502(ra) # 802082fc <hal_block_irq>
    802028e2:	e915                	bnez	a0,80202916 <trapinit_hart+0x86>
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
    802028e4:	104027f3          	csrr	a5,sie
    w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    802028e8:	2227e793          	ori	a5,a5,546
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
    802028ec:	10479073          	csrw	sie,a5
    hal_timer_next(1000000);
    802028f0:	000f4537          	lui	a0,0xf4
    802028f4:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    802028f8:	00006097          	auipc	ra,0x6
    802028fc:	8c8080e7          	jalr	-1848(ra) # 802081c0 <hal_timer_next>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202900:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202904:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202908:	10079073          	csrw	sstatus,a5
}
    8020290c:	60e2                	ld	ra,24(sp)
    8020290e:	6442                	ld	s0,16(sp)
    80202910:	64a2                	ld	s1,8(sp)
    80202912:	6105                	addi	sp,sp,32
    80202914:	8082                	ret
        hal_intc_enable(hal_block_irq());
    80202916:	00006097          	auipc	ra,0x6
    8020291a:	9e6080e7          	jalr	-1562(ra) # 802082fc <hal_block_irq>
    8020291e:	00005097          	auipc	ra,0x5
    80202922:	750080e7          	jalr	1872(ra) # 8020806e <hal_intc_enable>
        hal_intc_enable_hart(hal_hart_id(), hal_block_irq());
    80202926:	00006097          	auipc	ra,0x6
    8020292a:	82a080e7          	jalr	-2006(ra) # 80208150 <hal_hart_id>
    8020292e:	84aa                	mv	s1,a0
    80202930:	00006097          	auipc	ra,0x6
    80202934:	9cc080e7          	jalr	-1588(ra) # 802082fc <hal_block_irq>
    80202938:	85aa                	mv	a1,a0
    8020293a:	8526                	mv	a0,s1
    8020293c:	00005097          	auipc	ra,0x5
    80202940:	778080e7          	jalr	1912(ra) # 802080b4 <hal_intc_enable_hart>
    80202944:	b745                	j	802028e4 <trapinit_hart+0x54>

0000000080202946 <kerneltrap>:

/* Trap while already in the kernel. */
void kerneltrap(void)
{
    80202946:	7179                	addi	sp,sp,-48
    80202948:	f406                	sd	ra,40(sp)
    8020294a:	f022                	sd	s0,32(sp)
    8020294c:	ec26                	sd	s1,24(sp)
    8020294e:	e84a                	sd	s2,16(sp)
    80202950:	e44e                	sd	s3,8(sp)
    80202952:	1800                	addi	s0,sp,48
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80202954:	14102973          	csrr	s2,sepc
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202958:	100024f3          	csrr	s1,sstatus
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    8020295c:	142029f3          	csrr	s3,scause
    uint64 sepc     = r_sepc();
    uint64 sstatus  = r_sstatus();
    uint64 scause   = r_scause();

    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    80202960:	1004f793          	andi	a5,s1,256
    80202964:	cb85                	beqz	a5,80202994 <kerneltrap+0x4e>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202966:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    8020296a:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    8020296c:	ef85                	bnez	a5,802029a4 <kerneltrap+0x5e>

    int which = devintr();
    8020296e:	00000097          	auipc	ra,0x0
    80202972:	e26080e7          	jalr	-474(ra) # 80202794 <devintr>
    if (which == 0) {
    80202976:	cd1d                	beqz	a0,802029b4 <kerneltrap+0x6e>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
        panic("kernel exception");
    }
    /* Timer: give up the CPU, but only if we are running a process. */
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    80202978:	4789                	li	a5,2
    8020297a:	06f50463          	beq	a0,a5,802029e2 <kerneltrap+0x9c>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    8020297e:	14191073          	csrw	sepc,s2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202982:	10049073          	csrw	sstatus,s1
        yield();

    /* yield() may have run other code; restore what sret needs. */
    w_sepc(sepc);
    w_sstatus(sstatus);
}
    80202986:	70a2                	ld	ra,40(sp)
    80202988:	7402                	ld	s0,32(sp)
    8020298a:	64e2                	ld	s1,24(sp)
    8020298c:	6942                	ld	s2,16(sp)
    8020298e:	69a2                	ld	s3,8(sp)
    80202990:	6145                	addi	sp,sp,48
    80202992:	8082                	ret
    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    80202994:	00007517          	auipc	a0,0x7
    80202998:	dcc50513          	addi	a0,a0,-564 # 80209760 <etext+0x760>
    8020299c:	ffffe097          	auipc	ra,0xffffe
    802029a0:	c7a080e7          	jalr	-902(ra) # 80200616 <panic>
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    802029a4:	00007517          	auipc	a0,0x7
    802029a8:	ddc50513          	addi	a0,a0,-548 # 80209780 <etext+0x780>
    802029ac:	ffffe097          	auipc	ra,0xffffe
    802029b0:	c6a080e7          	jalr	-918(ra) # 80200616 <panic>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
    802029b4:	0ff9f513          	zext.b	a0,s3
    802029b8:	00000097          	auipc	ra,0x0
    802029bc:	d4c080e7          	jalr	-692(ra) # 80202704 <cause_str>
    802029c0:	85aa                	mv	a1,a0
    802029c2:	00007517          	auipc	a0,0x7
    802029c6:	de650513          	addi	a0,a0,-538 # 802097a8 <etext+0x7a8>
    802029ca:	ffffe097          	auipc	ra,0xffffe
    802029ce:	9da080e7          	jalr	-1574(ra) # 802003a4 <printf>
        panic("kernel exception");
    802029d2:	00007517          	auipc	a0,0x7
    802029d6:	dee50513          	addi	a0,a0,-530 # 802097c0 <etext+0x7c0>
    802029da:	ffffe097          	auipc	ra,0xffffe
    802029de:	c3c080e7          	jalr	-964(ra) # 80200616 <panic>
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    802029e2:	fffff097          	auipc	ra,0xfffff
    802029e6:	f0e080e7          	jalr	-242(ra) # 802018f0 <myproc>
    802029ea:	d951                	beqz	a0,8020297e <kerneltrap+0x38>
    802029ec:	fffff097          	auipc	ra,0xfffff
    802029f0:	f04080e7          	jalr	-252(ra) # 802018f0 <myproc>
    802029f4:	4d18                	lw	a4,24(a0)
    802029f6:	4791                	li	a5,4
    802029f8:	f8f713e3          	bne	a4,a5,8020297e <kerneltrap+0x38>
        yield();
    802029fc:	fffff097          	auipc	ra,0xfffff
    80202a00:	6ae080e7          	jalr	1710(ra) # 802020aa <yield>
    80202a04:	bfad                	j	8020297e <kerneltrap+0x38>

0000000080202a06 <usertrapret>:
    if (p->killed) exit(-1);
    usertrapret();
}

void usertrapret(void)
{
    80202a06:	1141                	addi	sp,sp,-16
    80202a08:	e406                	sd	ra,8(sp)
    80202a0a:	e022                	sd	s0,0(sp)
    80202a0c:	0800                	addi	s0,sp,16
    struct proc *p = myproc();
    80202a0e:	fffff097          	auipc	ra,0xfffff
    80202a12:	ee2080e7          	jalr	-286(ra) # 802018f0 <myproc>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202a16:	100027f3          	csrr	a5,sstatus
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    80202a1a:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202a1c:	10079073          	csrw	sstatus,a5
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    80202a20:	00000797          	auipc	a5,0x0
    80202a24:	24078793          	addi	a5,a5,576 # 80202c60 <uservec>
    80202a28:	10579073          	csrw	stvec,a5

    intr_off();                       /* no interrupts between stvec and sret */
    w_stvec((uint64)uservec);

    p->tf->kernel_satp   = r_satp();
    80202a2c:	6d3c                	ld	a5,88(a0)
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    80202a2e:	18002773          	csrr	a4,satp
    80202a32:	e398                	sd	a4,0(a5)
    p->tf->kernel_sp     = p->kstack + 4 * PGSIZE;   /* top of the kernel stack */
    80202a34:	6d38                	ld	a4,88(a0)
    80202a36:	613c                	ld	a5,64(a0)
    80202a38:	6691                	lui	a3,0x4
    80202a3a:	97b6                	add	a5,a5,a3
    80202a3c:	e71c                	sd	a5,8(a4)
    p->tf->kernel_trap   = (uint64)usertrap;
    80202a3e:	6d3c                	ld	a5,88(a0)
    80202a40:	00000717          	auipc	a4,0x0
    80202a44:	03870713          	addi	a4,a4,56 # 80202a78 <usertrap>
    80202a48:	eb98                	sd	a4,16(a5)
    p->tf->kernel_hartid = r_tp();
    80202a4a:	6d3c                	ld	a5,88(a0)
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    80202a4c:	8712                	mv	a4,tp
    80202a4e:	f398                	sd	a4,32(a5)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202a50:	100027f3          	csrr	a5,sstatus

    uint64 x = r_sstatus();
    x &= ~SSTATUS_SPP;                /* SPP=0 -> sret drops us to U-mode */
    80202a54:	eff7f793          	andi	a5,a5,-257
    x |= SSTATUS_SPIE;                /* re-enable interrupts in user mode */
    80202a58:	0207e793          	ori	a5,a5,32
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202a5c:	10079073          	csrw	sstatus,a5
    w_sstatus(x);
    w_sepc(p->tf->epc);
    80202a60:	6d28                	ld	a0,88(a0)
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    80202a62:	6d1c                	ld	a5,24(a0)
    80202a64:	14179073          	csrw	sepc,a5

    userret(p->tf);
    80202a68:	00000097          	auipc	ra,0x0
    80202a6c:	284080e7          	jalr	644(ra) # 80202cec <userret>
}
    80202a70:	60a2                	ld	ra,8(sp)
    80202a72:	6402                	ld	s0,0(sp)
    80202a74:	0141                	addi	sp,sp,16
    80202a76:	8082                	ret

0000000080202a78 <usertrap>:
{
    80202a78:	7179                	addi	sp,sp,-48
    80202a7a:	f406                	sd	ra,40(sp)
    80202a7c:	f022                	sd	s0,32(sp)
    80202a7e:	1800                	addi	s0,sp,48
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202a80:	100027f3          	csrr	a5,sstatus
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    80202a84:	1007f793          	andi	a5,a5,256
    80202a88:	eba9                	bnez	a5,80202ada <usertrap+0x62>
    80202a8a:	ec26                	sd	s1,24(sp)
    80202a8c:	e84a                	sd	s2,16(sp)
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    80202a8e:	00000797          	auipc	a5,0x0
    80202a92:	17278793          	addi	a5,a5,370 # 80202c00 <kernelvec>
    80202a96:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    80202a9a:	fffff097          	auipc	ra,0xfffff
    80202a9e:	e56080e7          	jalr	-426(ra) # 802018f0 <myproc>
    80202aa2:	84aa                	mv	s1,a0
    p->tf->epc = r_sepc();
    80202aa4:	6d3c                	ld	a5,88(a0)
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80202aa6:	14102773          	csrr	a4,sepc
    80202aaa:	ef98                	sd	a4,24(a5)
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80202aac:	14202973          	csrr	s2,scause
    if (scause == 8) {               /* ecall: a system call */
    80202ab0:	47a1                	li	a5,8
    80202ab2:	04f90063          	beq	s2,a5,80202af2 <usertrap+0x7a>
    80202ab6:	e44e                	sd	s3,8(sp)
    } else if (scause == 15 || scause == 13) {   /* store / load page fault */
    80202ab8:	47bd                	li	a5,15
    80202aba:	06f90f63          	beq	s2,a5,80202b38 <usertrap+0xc0>
    80202abe:	47b5                	li	a5,13
    80202ac0:	0cf91363          	bne	s2,a5,80202b86 <usertrap+0x10e>
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80202ac4:	143029f3          	csrr	s3,stval
        } else if (mmap_fault(p, va) == 0) {
    80202ac8:	85ce                	mv	a1,s3
    80202aca:	8526                	mv	a0,s1
    80202acc:	00003097          	auipc	ra,0x3
    80202ad0:	b0e080e7          	jalr	-1266(ra) # 802055da <mmap_fault>
    80202ad4:	ed2d                	bnez	a0,80202b4e <usertrap+0xd6>
    80202ad6:	69a2                	ld	s3,8(sp)
    80202ad8:	a82d                	j	80202b12 <usertrap+0x9a>
    80202ada:	ec26                	sd	s1,24(sp)
    80202adc:	e84a                	sd	s2,16(sp)
    80202ade:	e44e                	sd	s3,8(sp)
    80202ae0:	e052                	sd	s4,0(sp)
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    80202ae2:	00007517          	auipc	a0,0x7
    80202ae6:	cf650513          	addi	a0,a0,-778 # 802097d8 <etext+0x7d8>
    80202aea:	ffffe097          	auipc	ra,0xffffe
    80202aee:	b2c080e7          	jalr	-1236(ra) # 80200616 <panic>
        if (p->killed) exit(-1);
    80202af2:	551c                	lw	a5,40(a0)
    80202af4:	eb9d                	bnez	a5,80202b2a <usertrap+0xb2>
        p->tf->epc += 4;             /* return AFTER the ecall, not onto it */
    80202af6:	6d38                	ld	a4,88(a0)
    80202af8:	6f1c                	ld	a5,24(a4)
    80202afa:	0791                	addi	a5,a5,4
    80202afc:	ef1c                	sd	a5,24(a4)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202afe:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202b02:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202b06:	10079073          	csrw	sstatus,a5
        syscall();
    80202b0a:	00001097          	auipc	ra,0x1
    80202b0e:	77e080e7          	jalr	1918(ra) # 80204288 <syscall>
    if (p->killed) exit(-1);
    80202b12:	549c                	lw	a5,40(s1)
    80202b14:	efe1                	bnez	a5,80202bec <usertrap+0x174>
    usertrapret();
    80202b16:	00000097          	auipc	ra,0x0
    80202b1a:	ef0080e7          	jalr	-272(ra) # 80202a06 <usertrapret>
    80202b1e:	64e2                	ld	s1,24(sp)
    80202b20:	6942                	ld	s2,16(sp)
}
    80202b22:	70a2                	ld	ra,40(sp)
    80202b24:	7402                	ld	s0,32(sp)
    80202b26:	6145                	addi	sp,sp,48
    80202b28:	8082                	ret
    80202b2a:	e44e                	sd	s3,8(sp)
    80202b2c:	e052                	sd	s4,0(sp)
        if (p->killed) exit(-1);
    80202b2e:	557d                	li	a0,-1
    80202b30:	fffff097          	auipc	ra,0xfffff
    80202b34:	7b2080e7          	jalr	1970(ra) # 802022e2 <exit>
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80202b38:	143029f3          	csrr	s3,stval
        if (scause == 15 && cowfault(p->pagetable, va) == 0) {
    80202b3c:	85ce                	mv	a1,s3
    80202b3e:	6928                	ld	a0,80(a0)
    80202b40:	00001097          	auipc	ra,0x1
    80202b44:	83e080e7          	jalr	-1986(ra) # 8020337e <cowfault>
    80202b48:	f141                	bnez	a0,80202ac8 <usertrap+0x50>
    80202b4a:	69a2                	ld	s3,8(sp)
    80202b4c:	b7d9                	j	80202b12 <usertrap+0x9a>
    80202b4e:	e052                	sd	s4,0(sp)
            printf("usertrap: pid %d %s at va %p (sepc %p) - killing\n",
    80202b50:	0304aa03          	lw	s4,48(s1)
    80202b54:	854a                	mv	a0,s2
    80202b56:	00000097          	auipc	ra,0x0
    80202b5a:	bae080e7          	jalr	-1106(ra) # 80202704 <cause_str>
    80202b5e:	862a                	mv	a2,a0
    80202b60:	6cbc                	ld	a5,88(s1)
    80202b62:	6f98                	ld	a4,24(a5)
    80202b64:	86ce                	mv	a3,s3
    80202b66:	85d2                	mv	a1,s4
    80202b68:	00007517          	auipc	a0,0x7
    80202b6c:	c9050513          	addi	a0,a0,-880 # 802097f8 <etext+0x7f8>
    80202b70:	ffffe097          	auipc	ra,0xffffe
    80202b74:	834080e7          	jalr	-1996(ra) # 802003a4 <printf>
            p->killed = 1;
    80202b78:	4785                	li	a5,1
    80202b7a:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    80202b7c:	557d                	li	a0,-1
    80202b7e:	fffff097          	auipc	ra,0xfffff
    80202b82:	764080e7          	jalr	1892(ra) # 802022e2 <exit>
        int which = devintr();
    80202b86:	00000097          	auipc	ra,0x0
    80202b8a:	c0e080e7          	jalr	-1010(ra) # 80202794 <devintr>
        if (which == 0) {
    80202b8e:	c911                	beqz	a0,80202ba2 <usertrap+0x12a>
        if (which == 2 && p->state == RUNNING) {
    80202b90:	4789                	li	a5,2
    80202b92:	04f51b63          	bne	a0,a5,80202be8 <usertrap+0x170>
    80202b96:	4c98                	lw	a4,24(s1)
    80202b98:	4791                	li	a5,4
    80202b9a:	02f70d63          	beq	a4,a5,80202bd4 <usertrap+0x15c>
    80202b9e:	69a2                	ld	s3,8(sp)
    80202ba0:	bf8d                	j	80202b12 <usertrap+0x9a>
            printf("usertrap: pid %d unexpected %s (scause %p, stval %p) - killing\n",
    80202ba2:	0304a983          	lw	s3,48(s1)
    80202ba6:	0ff97513          	zext.b	a0,s2
    80202baa:	00000097          	auipc	ra,0x0
    80202bae:	b5a080e7          	jalr	-1190(ra) # 80202704 <cause_str>
    80202bb2:	862a                	mv	a2,a0
    80202bb4:	14302773          	csrr	a4,stval
    80202bb8:	86ca                	mv	a3,s2
    80202bba:	85ce                	mv	a1,s3
    80202bbc:	00007517          	auipc	a0,0x7
    80202bc0:	c7450513          	addi	a0,a0,-908 # 80209830 <etext+0x830>
    80202bc4:	ffffd097          	auipc	ra,0xffffd
    80202bc8:	7e0080e7          	jalr	2016(ra) # 802003a4 <printf>
            p->killed = 1;
    80202bcc:	4785                	li	a5,1
    80202bce:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    80202bd0:	e052                	sd	s4,0(sp)
    80202bd2:	b76d                	j	80202b7c <usertrap+0x104>
            alarm_tick();               /* Lab 4: maybe deliver a timer event */
    80202bd4:	00003097          	auipc	ra,0x3
    80202bd8:	820080e7          	jalr	-2016(ra) # 802053f4 <alarm_tick>
            yield();
    80202bdc:	fffff097          	auipc	ra,0xfffff
    80202be0:	4ce080e7          	jalr	1230(ra) # 802020aa <yield>
    80202be4:	69a2                	ld	s3,8(sp)
    80202be6:	b735                	j	80202b12 <usertrap+0x9a>
    80202be8:	69a2                	ld	s3,8(sp)
    80202bea:	b725                	j	80202b12 <usertrap+0x9a>
    80202bec:	e44e                	sd	s3,8(sp)
    80202bee:	e052                	sd	s4,0(sp)
    80202bf0:	b771                	j	80202b7c <usertrap+0x104>
	...

0000000080202c00 <kernelvec>:
        .globl kernelvec
        .align 4
kernelvec:
        # We were already in the kernel: our sp is a valid kernel stack.
        # Save every caller-saved register - kerneltrap() is C and may clobber them.
        addi    sp, sp, -256
    80202c00:	7111                	addi	sp,sp,-256
        sd      ra, 0(sp)
    80202c02:	e006                	sd	ra,0(sp)
        sd      sp, 8(sp)
    80202c04:	e40a                	sd	sp,8(sp)
        sd      gp, 16(sp)
    80202c06:	e80e                	sd	gp,16(sp)
        sd      tp, 24(sp)
    80202c08:	ec12                	sd	tp,24(sp)
        sd      t0, 32(sp)
    80202c0a:	f016                	sd	t0,32(sp)
        sd      t1, 40(sp)
    80202c0c:	f41a                	sd	t1,40(sp)
        sd      t2, 48(sp)
    80202c0e:	f81e                	sd	t2,48(sp)
        sd      a0, 72(sp)
    80202c10:	e4aa                	sd	a0,72(sp)
        sd      a1, 80(sp)
    80202c12:	e8ae                	sd	a1,80(sp)
        sd      a2, 88(sp)
    80202c14:	ecb2                	sd	a2,88(sp)
        sd      a3, 96(sp)
    80202c16:	f0b6                	sd	a3,96(sp)
        sd      a4, 104(sp)
    80202c18:	f4ba                	sd	a4,104(sp)
        sd      a5, 112(sp)
    80202c1a:	f8be                	sd	a5,112(sp)
        sd      a6, 120(sp)
    80202c1c:	fcc2                	sd	a6,120(sp)
        sd      a7, 128(sp)
    80202c1e:	e146                	sd	a7,128(sp)
        sd      t3, 216(sp)
    80202c20:	edf2                	sd	t3,216(sp)
        sd      t4, 224(sp)
    80202c22:	f1f6                	sd	t4,224(sp)
        sd      t5, 232(sp)
    80202c24:	f5fa                	sd	t5,232(sp)
        sd      t6, 240(sp)
    80202c26:	f9fe                	sd	t6,240(sp)

        call    kerneltrap
    80202c28:	00000097          	auipc	ra,0x0
    80202c2c:	d1e080e7          	jalr	-738(ra) # 80202946 <kerneltrap>

        ld      ra, 0(sp)
    80202c30:	6082                	ld	ra,0(sp)
        ld      gp, 16(sp)
    80202c32:	61c2                	ld	gp,16(sp)
        # NOT tp - kerneltrap may have moved us to another hart's scheduler.
        ld      t0, 32(sp)
    80202c34:	7282                	ld	t0,32(sp)
        ld      t1, 40(sp)
    80202c36:	7322                	ld	t1,40(sp)
        ld      t2, 48(sp)
    80202c38:	73c2                	ld	t2,48(sp)
        ld      a0, 72(sp)
    80202c3a:	6526                	ld	a0,72(sp)
        ld      a1, 80(sp)
    80202c3c:	65c6                	ld	a1,80(sp)
        ld      a2, 88(sp)
    80202c3e:	6666                	ld	a2,88(sp)
        ld      a3, 96(sp)
    80202c40:	7686                	ld	a3,96(sp)
        ld      a4, 104(sp)
    80202c42:	7726                	ld	a4,104(sp)
        ld      a5, 112(sp)
    80202c44:	77c6                	ld	a5,112(sp)
        ld      a6, 120(sp)
    80202c46:	7866                	ld	a6,120(sp)
        ld      a7, 128(sp)
    80202c48:	688a                	ld	a7,128(sp)
        ld      t3, 216(sp)
    80202c4a:	6e6e                	ld	t3,216(sp)
        ld      t4, 224(sp)
    80202c4c:	7e8e                	ld	t4,224(sp)
        ld      t5, 232(sp)
    80202c4e:	7f2e                	ld	t5,232(sp)
        ld      t6, 240(sp)
    80202c50:	7fce                	ld	t6,240(sp)
        addi    sp, sp, 256
    80202c52:	6111                	addi	sp,sp,256
        # sepc/sstatus were saved+restored by kerneltrap() in C.
        sret
    80202c54:	10200073          	sret
    80202c58:	00000013          	nop
    80202c5c:	00000013          	nop

0000000080202c60 <uservec>:
        .globl uservec
        .globl userret
        .globl usertrap
        .align 4
uservec:
        csrrw   a0, sscratch, a0        # a0 = &tf ; sscratch = user's a0
    80202c60:	14051573          	csrrw	a0,sscratch,a0

        sd ra,  40(a0)
    80202c64:	02153423          	sd	ra,40(a0)
        sd sp,  48(a0)
    80202c68:	02253823          	sd	sp,48(a0)
        sd gp,  56(a0)
    80202c6c:	02353c23          	sd	gp,56(a0)
        sd tp,  64(a0)
    80202c70:	04453023          	sd	tp,64(a0)
        sd t0,  72(a0)
    80202c74:	04553423          	sd	t0,72(a0)
        sd t1,  80(a0)
    80202c78:	04653823          	sd	t1,80(a0)
        sd t2,  88(a0)
    80202c7c:	04753c23          	sd	t2,88(a0)
        sd s0,  96(a0)
    80202c80:	f120                	sd	s0,96(a0)
        sd s1,  104(a0)
    80202c82:	f524                	sd	s1,104(a0)
        sd a1,  120(a0)
    80202c84:	fd2c                	sd	a1,120(a0)
        sd a2,  128(a0)
    80202c86:	e150                	sd	a2,128(a0)
        sd a3,  136(a0)
    80202c88:	e554                	sd	a3,136(a0)
        sd a4,  144(a0)
    80202c8a:	e958                	sd	a4,144(a0)
        sd a5,  152(a0)
    80202c8c:	ed5c                	sd	a5,152(a0)
        sd a6,  160(a0)
    80202c8e:	0b053023          	sd	a6,160(a0)
        sd a7,  168(a0)
    80202c92:	0b153423          	sd	a7,168(a0)
        sd s2,  176(a0)
    80202c96:	0b253823          	sd	s2,176(a0)
        sd s3,  184(a0)
    80202c9a:	0b353c23          	sd	s3,184(a0)
        sd s4,  192(a0)
    80202c9e:	0d453023          	sd	s4,192(a0)
        sd s5,  200(a0)
    80202ca2:	0d553423          	sd	s5,200(a0)
        sd s6,  208(a0)
    80202ca6:	0d653823          	sd	s6,208(a0)
        sd s7,  216(a0)
    80202caa:	0d753c23          	sd	s7,216(a0)
        sd s8,  224(a0)
    80202cae:	0f853023          	sd	s8,224(a0)
        sd s9,  232(a0)
    80202cb2:	0f953423          	sd	s9,232(a0)
        sd s10, 240(a0)
    80202cb6:	0fa53823          	sd	s10,240(a0)
        sd s11, 248(a0)
    80202cba:	0fb53c23          	sd	s11,248(a0)
        sd t3,  256(a0)
    80202cbe:	11c53023          	sd	t3,256(a0)
        sd t4,  264(a0)
    80202cc2:	11d53423          	sd	t4,264(a0)
        sd t5,  272(a0)
    80202cc6:	11e53823          	sd	t5,272(a0)
        sd t6,  280(a0)
    80202cca:	11f53c23          	sd	t6,280(a0)

        csrr    t0, sscratch            # t0 = user's original a0
    80202cce:	140022f3          	csrr	t0,sscratch
        sd      t0, 112(a0)             # tf->a0
    80202cd2:	06553823          	sd	t0,112(a0)

        csrr    t1, sepc
    80202cd6:	14102373          	csrr	t1,sepc
        sd      t1, 24(a0)              # tf->epc = where user was
    80202cda:	00653c23          	sd	t1,24(a0)

        ld      tp, 32(a0)              # restore our hartid into tp
    80202cde:	02053203          	ld	tp,32(a0)
        ld      sp, 8(a0)               # switch to the kernel stack
    80202ce2:	00853103          	ld	sp,8(a0)
        ld      t1, 16(a0)              # tf->kernel_trap = &usertrap
    80202ce6:	01053303          	ld	t1,16(a0)
        jr      t1
    80202cea:	8302                	jr	t1

0000000080202cec <userret>:

# void userret(struct trapframe *tf)  -- a0 = tf
userret:
        csrw    sscratch, a0            # so the next uservec can find it
    80202cec:	14051073          	csrw	sscratch,a0

        ld t0,  24(a0)
    80202cf0:	01853283          	ld	t0,24(a0)
        csrw    sepc, t0                # return to where the user left off
    80202cf4:	14129073          	csrw	sepc,t0

        ld ra,  40(a0)
    80202cf8:	02853083          	ld	ra,40(a0)
        ld sp,  48(a0)
    80202cfc:	03053103          	ld	sp,48(a0)
        ld gp,  56(a0)
    80202d00:	03853183          	ld	gp,56(a0)
        ld tp,  64(a0)
    80202d04:	04053203          	ld	tp,64(a0)
        ld t0,  72(a0)
    80202d08:	04853283          	ld	t0,72(a0)
        ld t1,  80(a0)
    80202d0c:	05053303          	ld	t1,80(a0)
        ld t2,  88(a0)
    80202d10:	05853383          	ld	t2,88(a0)
        ld s0,  96(a0)
    80202d14:	7120                	ld	s0,96(a0)
        ld s1,  104(a0)
    80202d16:	7524                	ld	s1,104(a0)
        ld a1,  120(a0)
    80202d18:	7d2c                	ld	a1,120(a0)
        ld a2,  128(a0)
    80202d1a:	6150                	ld	a2,128(a0)
        ld a3,  136(a0)
    80202d1c:	6554                	ld	a3,136(a0)
        ld a4,  144(a0)
    80202d1e:	6958                	ld	a4,144(a0)
        ld a5,  152(a0)
    80202d20:	6d5c                	ld	a5,152(a0)
        ld a6,  160(a0)
    80202d22:	0a053803          	ld	a6,160(a0)
        ld a7,  168(a0)
    80202d26:	0a853883          	ld	a7,168(a0)
        ld s2,  176(a0)
    80202d2a:	0b053903          	ld	s2,176(a0)
        ld s3,  184(a0)
    80202d2e:	0b853983          	ld	s3,184(a0)
        ld s4,  192(a0)
    80202d32:	0c053a03          	ld	s4,192(a0)
        ld s5,  200(a0)
    80202d36:	0c853a83          	ld	s5,200(a0)
        ld s6,  208(a0)
    80202d3a:	0d053b03          	ld	s6,208(a0)
        ld s7,  216(a0)
    80202d3e:	0d853b83          	ld	s7,216(a0)
        ld s8,  224(a0)
    80202d42:	0e053c03          	ld	s8,224(a0)
        ld s9,  232(a0)
    80202d46:	0e853c83          	ld	s9,232(a0)
        ld s10, 240(a0)
    80202d4a:	0f053d03          	ld	s10,240(a0)
        ld s11, 248(a0)
    80202d4e:	0f853d83          	ld	s11,248(a0)
        ld t3,  256(a0)
    80202d52:	10053e03          	ld	t3,256(a0)
        ld t4,  264(a0)
    80202d56:	10853e83          	ld	t4,264(a0)
        ld t5,  272(a0)
    80202d5a:	11053f03          	ld	t5,272(a0)
        ld t6,  280(a0)
    80202d5e:	11853f83          	ld	t6,280(a0)

        ld a0,  112(a0)                 # finally, the user's a0 (syscall retval)
    80202d62:	7928                	ld	a0,112(a0)
        sret
    80202d64:	10200073          	sret
    80202d68:	00000013          	nop
    80202d6c:	00000013          	nop

0000000080202d70 <freewalk_user>:
}

/* Free ONLY the user half of the tree (indices 0..1). Kernel entries are
 * borrowed, not owned - freeing them would take down every other process. */
static void freewalk_user(pagetable_t pt, int level)
{
    80202d70:	7139                	addi	sp,sp,-64
    80202d72:	fc06                	sd	ra,56(sp)
    80202d74:	f822                	sd	s0,48(sp)
    80202d76:	f426                	sd	s1,40(sp)
    80202d78:	f04a                	sd	s2,32(sp)
    80202d7a:	ec4e                	sd	s3,24(sp)
    80202d7c:	e852                	sd	s4,16(sp)
    80202d7e:	e456                	sd	s5,8(sp)
    80202d80:	0080                	addi	s0,sp,64
    80202d82:	89aa                	mv	s3,a0
    80202d84:	8a2e                	mv	s4,a1
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    80202d86:	4789                	li	a5,2
    80202d88:	20000913          	li	s2,512
    80202d8c:	02f58c63          	beq	a1,a5,80202dc4 <freewalk_user+0x54>
    for (int i = 0; i < limit; i++) {
    80202d90:	84ce                	mv	s1,s3
    80202d92:	090e                	slli	s2,s2,0x3
    80202d94:	994e                	add	s2,s2,s3
        pte_t pte = pt[i];
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80202d96:	4a85                	li	s5,1
        pte_t pte = pt[i];
    80202d98:	609c                	ld	a5,0(s1)
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80202d9a:	00f7f713          	andi	a4,a5,15
    80202d9e:	03570563          	beq	a4,s5,80202dc8 <freewalk_user+0x58>
    for (int i = 0; i < limit; i++) {
    80202da2:	04a1                	addi	s1,s1,8
    80202da4:	ff249ae3          	bne	s1,s2,80202d98 <freewalk_user+0x28>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
            pt[i] = 0;
        }
    }
    pfree((void *)pt);
    80202da8:	854e                	mv	a0,s3
    80202daa:	ffffe097          	auipc	ra,0xffffe
    80202dae:	47a080e7          	jalr	1146(ra) # 80201224 <pfree>
}
    80202db2:	70e2                	ld	ra,56(sp)
    80202db4:	7442                	ld	s0,48(sp)
    80202db6:	74a2                	ld	s1,40(sp)
    80202db8:	7902                	ld	s2,32(sp)
    80202dba:	69e2                	ld	s3,24(sp)
    80202dbc:	6a42                	ld	s4,16(sp)
    80202dbe:	6aa2                	ld	s5,8(sp)
    80202dc0:	6121                	addi	sp,sp,64
    80202dc2:	8082                	ret
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    80202dc4:	892e                	mv	s2,a1
    80202dc6:	b7e9                	j	80202d90 <freewalk_user+0x20>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
    80202dc8:	83a9                	srli	a5,a5,0xa
    80202dca:	fffa059b          	addiw	a1,s4,-1
    80202dce:	00c79513          	slli	a0,a5,0xc
    80202dd2:	00000097          	auipc	ra,0x0
    80202dd6:	f9e080e7          	jalr	-98(ra) # 80202d70 <freewalk_user>
            pt[i] = 0;
    80202dda:	0004b023          	sd	zero,0(s1)
    80202dde:	b7d1                	j	80202da2 <freewalk_user+0x32>

0000000080202de0 <vmprint_lvl>:
    return got_null ? 0 : -1;
}

/* Debug aid you will use all semester, and in Viva #2. */
static void vmprint_lvl(pagetable_t pt, int level)
{
    80202de0:	711d                	addi	sp,sp,-96
    80202de2:	ec86                	sd	ra,88(sp)
    80202de4:	e8a2                	sd	s0,80(sp)
    80202de6:	e4a6                	sd	s1,72(sp)
    80202de8:	e0ca                	sd	s2,64(sp)
    80202dea:	fc4e                	sd	s3,56(sp)
    80202dec:	f852                	sd	s4,48(sp)
    80202dee:	f456                	sd	s5,40(sp)
    80202df0:	f05a                	sd	s6,32(sp)
    80202df2:	ec5e                	sd	s7,24(sp)
    80202df4:	e862                	sd	s8,16(sp)
    80202df6:	e466                	sd	s9,8(sp)
    80202df8:	e06a                	sd	s10,0(sp)
    80202dfa:	1080                	addi	s0,sp,96
    80202dfc:	892e                	mv	s2,a1
    for (int i = 0; i < 512; i++) {
    80202dfe:	8b2a                	mv	s6,a0
    80202e00:	4a01                	li	s4,0
        pte_t pte = pt[i];
        if (!(pte & PTE_V)) continue;
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202e02:	4b89                	li	s7,2
        for (int d = 2; d >= level; d--) printf(" ..");
    80202e04:	00007a97          	auipc	s5,0x7
    80202e08:	a6ca8a93          	addi	s5,s5,-1428 # 80209870 <etext+0x870>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202e0c:	00007c97          	auipc	s9,0x7
    80202e10:	a6cc8c93          	addi	s9,s9,-1428 # 80209878 <etext+0x878>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202e14:	4d05                	li	s10,1
    for (int i = 0; i < 512; i++) {
    80202e16:	20000c13          	li	s8,512
    80202e1a:	a089                	j	80202e5c <vmprint_lvl+0x7c>
        for (int d = 2; d >= level; d--) printf(" ..");
    80202e1c:	84de                	mv	s1,s7
    80202e1e:	052bca63          	blt	s7,s2,80202e72 <vmprint_lvl+0x92>
    80202e22:	8556                	mv	a0,s5
    80202e24:	ffffd097          	auipc	ra,0xffffd
    80202e28:	580080e7          	jalr	1408(ra) # 802003a4 <printf>
    80202e2c:	34fd                	addiw	s1,s1,-1
    80202e2e:	ff24dae3          	bge	s1,s2,80202e22 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202e32:	00a9d493          	srli	s1,s3,0xa
    80202e36:	04b2                	slli	s1,s1,0xc
    80202e38:	86a6                	mv	a3,s1
    80202e3a:	864e                	mv	a2,s3
    80202e3c:	85d2                	mv	a1,s4
    80202e3e:	8566                	mv	a0,s9
    80202e40:	ffffd097          	auipc	ra,0xffffd
    80202e44:	564080e7          	jalr	1380(ra) # 802003a4 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202e48:	00e9f993          	andi	s3,s3,14
    80202e4c:	00099463          	bnez	s3,80202e54 <vmprint_lvl+0x74>
    80202e50:	05204063          	bgtz	s2,80202e90 <vmprint_lvl+0xb0>
    for (int i = 0; i < 512; i++) {
    80202e54:	2a05                	addiw	s4,s4,1
    80202e56:	0b21                	addi	s6,s6,8
    80202e58:	058a0463          	beq	s4,s8,80202ea0 <vmprint_lvl+0xc0>
        pte_t pte = pt[i];
    80202e5c:	000b3983          	ld	s3,0(s6)
        if (!(pte & PTE_V)) continue;
    80202e60:	0019f793          	andi	a5,s3,1
    80202e64:	dbe5                	beqz	a5,80202e54 <vmprint_lvl+0x74>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202e66:	fb791be3          	bne	s2,s7,80202e1c <vmprint_lvl+0x3c>
    80202e6a:	ff4d45e3          	blt	s10,s4,80202e54 <vmprint_lvl+0x74>
    80202e6e:	84ca                	mv	s1,s2
    80202e70:	bf4d                	j	80202e22 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202e72:	00a9d493          	srli	s1,s3,0xa
    80202e76:	04b2                	slli	s1,s1,0xc
    80202e78:	86a6                	mv	a3,s1
    80202e7a:	864e                	mv	a2,s3
    80202e7c:	85d2                	mv	a1,s4
    80202e7e:	8566                	mv	a0,s9
    80202e80:	ffffd097          	auipc	ra,0xffffd
    80202e84:	524080e7          	jalr	1316(ra) # 802003a4 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202e88:	00e9f993          	andi	s3,s3,14
    80202e8c:	fc0994e3          	bnez	s3,80202e54 <vmprint_lvl+0x74>
            vmprint_lvl((pagetable_t)PTE2PA(pte), level - 1);
    80202e90:	fff9059b          	addiw	a1,s2,-1
    80202e94:	8526                	mv	a0,s1
    80202e96:	00000097          	auipc	ra,0x0
    80202e9a:	f4a080e7          	jalr	-182(ra) # 80202de0 <vmprint_lvl>
    80202e9e:	bf5d                	j	80202e54 <vmprint_lvl+0x74>
    }
}
    80202ea0:	60e6                	ld	ra,88(sp)
    80202ea2:	6446                	ld	s0,80(sp)
    80202ea4:	64a6                	ld	s1,72(sp)
    80202ea6:	6906                	ld	s2,64(sp)
    80202ea8:	79e2                	ld	s3,56(sp)
    80202eaa:	7a42                	ld	s4,48(sp)
    80202eac:	7aa2                	ld	s5,40(sp)
    80202eae:	7b02                	ld	s6,32(sp)
    80202eb0:	6be2                	ld	s7,24(sp)
    80202eb2:	6c42                	ld	s8,16(sp)
    80202eb4:	6ca2                	ld	s9,8(sp)
    80202eb6:	6d02                	ld	s10,0(sp)
    80202eb8:	6125                	addi	sp,sp,96
    80202eba:	8082                	ret

0000000080202ebc <mmio_alias>:
uint64 mmio_alias(uint64 pa) { return MMIO_VA(pa); }
    80202ebc:	1141                	addi	sp,sp,-16
    80202ebe:	e422                	sd	s0,8(sp)
    80202ec0:	0800                	addi	s0,sp,16
    80202ec2:	4785                	li	a5,1
    80202ec4:	1782                	slli	a5,a5,0x20
    80202ec6:	953e                	add	a0,a0,a5
    80202ec8:	6422                	ld	s0,8(sp)
    80202eca:	0141                	addi	sp,sp,16
    80202ecc:	8082                	ret

0000000080202ece <walk>:
{
    80202ece:	7139                	addi	sp,sp,-64
    80202ed0:	fc06                	sd	ra,56(sp)
    80202ed2:	f822                	sd	s0,48(sp)
    80202ed4:	f426                	sd	s1,40(sp)
    80202ed6:	f04a                	sd	s2,32(sp)
    80202ed8:	ec4e                	sd	s3,24(sp)
    80202eda:	e852                	sd	s4,16(sp)
    80202edc:	e456                	sd	s5,8(sp)
    80202ede:	e05a                	sd	s6,0(sp)
    80202ee0:	0080                	addi	s0,sp,64
    80202ee2:	84aa                	mv	s1,a0
    80202ee4:	89ae                	mv	s3,a1
    80202ee6:	8ab2                	mv	s5,a2
    if (va >= MAXVA) panic("walk: va out of range");
    80202ee8:	57fd                	li	a5,-1
    80202eea:	83e9                	srli	a5,a5,0x1a
    80202eec:	4a79                	li	s4,30
    for (int level = 2; level > 0; level--) {
    80202eee:	4b31                	li	s6,12
    if (va >= MAXVA) panic("walk: va out of range");
    80202ef0:	04b7f263          	bgeu	a5,a1,80202f34 <walk+0x66>
    80202ef4:	00007517          	auipc	a0,0x7
    80202ef8:	99c50513          	addi	a0,a0,-1636 # 80209890 <etext+0x890>
    80202efc:	ffffd097          	auipc	ra,0xffffd
    80202f00:	71a080e7          	jalr	1818(ra) # 80200616 <panic>
            if (!alloc) return 0;
    80202f04:	060a8663          	beqz	s5,80202f70 <walk+0xa2>
            pt = (pagetable_t)palloc();
    80202f08:	ffffe097          	auipc	ra,0xffffe
    80202f0c:	1de080e7          	jalr	478(ra) # 802010e6 <palloc>
    80202f10:	84aa                	mv	s1,a0
            if (!pt) return 0;
    80202f12:	c529                	beqz	a0,80202f5c <walk+0x8e>
            memset(pt, 0, PGSIZE);
    80202f14:	6605                	lui	a2,0x1
    80202f16:	4581                	li	a1,0
    80202f18:	ffffd097          	auipc	ra,0xffffd
    80202f1c:	7a4080e7          	jalr	1956(ra) # 802006bc <memset>
            *pte = PA2PTE(pt) | PTE_V;
    80202f20:	00c4d793          	srli	a5,s1,0xc
    80202f24:	07aa                	slli	a5,a5,0xa
    80202f26:	0017e793          	ori	a5,a5,1
    80202f2a:	00f93023          	sd	a5,0(s2)
    for (int level = 2; level > 0; level--) {
    80202f2e:	3a5d                	addiw	s4,s4,-9
    80202f30:	036a0063          	beq	s4,s6,80202f50 <walk+0x82>
        pte_t *pte = &pt[PX(level, va)];
    80202f34:	0149d933          	srl	s2,s3,s4
    80202f38:	1ff97913          	andi	s2,s2,511
    80202f3c:	090e                	slli	s2,s2,0x3
    80202f3e:	9926                	add	s2,s2,s1
        if (*pte & PTE_V) {
    80202f40:	00093483          	ld	s1,0(s2)
    80202f44:	0014f793          	andi	a5,s1,1
    80202f48:	dfd5                	beqz	a5,80202f04 <walk+0x36>
            pt = (pagetable_t)PTE2PA(*pte);
    80202f4a:	80a9                	srli	s1,s1,0xa
    80202f4c:	04b2                	slli	s1,s1,0xc
    80202f4e:	b7c5                	j	80202f2e <walk+0x60>
    return &pt[PX(0, va)];
    80202f50:	00c9d513          	srli	a0,s3,0xc
    80202f54:	1ff57513          	andi	a0,a0,511
    80202f58:	050e                	slli	a0,a0,0x3
    80202f5a:	9526                	add	a0,a0,s1
}
    80202f5c:	70e2                	ld	ra,56(sp)
    80202f5e:	7442                	ld	s0,48(sp)
    80202f60:	74a2                	ld	s1,40(sp)
    80202f62:	7902                	ld	s2,32(sp)
    80202f64:	69e2                	ld	s3,24(sp)
    80202f66:	6a42                	ld	s4,16(sp)
    80202f68:	6aa2                	ld	s5,8(sp)
    80202f6a:	6b02                	ld	s6,0(sp)
    80202f6c:	6121                	addi	sp,sp,64
    80202f6e:	8082                	ret
            if (!alloc) return 0;
    80202f70:	4501                	li	a0,0
    80202f72:	b7ed                	j	80202f5c <walk+0x8e>

0000000080202f74 <walkaddr>:
    if (va >= MAXVA) return 0;
    80202f74:	57fd                	li	a5,-1
    80202f76:	83e9                	srli	a5,a5,0x1a
    80202f78:	00b7f463          	bgeu	a5,a1,80202f80 <walkaddr+0xc>
    80202f7c:	4501                	li	a0,0
}
    80202f7e:	8082                	ret
{
    80202f80:	1141                	addi	sp,sp,-16
    80202f82:	e406                	sd	ra,8(sp)
    80202f84:	e022                	sd	s0,0(sp)
    80202f86:	0800                	addi	s0,sp,16
    pte_t *pte = walk(pt, va, 0);
    80202f88:	4601                	li	a2,0
    80202f8a:	00000097          	auipc	ra,0x0
    80202f8e:	f44080e7          	jalr	-188(ra) # 80202ece <walk>
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202f92:	cd19                	beqz	a0,80202fb0 <walkaddr+0x3c>
    80202f94:	611c                	ld	a5,0(a0)
    80202f96:	0117f693          	andi	a3,a5,17
    80202f9a:	4745                	li	a4,17
    80202f9c:	4501                	li	a0,0
    80202f9e:	00e69563          	bne	a3,a4,80202fa8 <walkaddr+0x34>
    return PTE2PA(*pte);
    80202fa2:	83a9                	srli	a5,a5,0xa
    80202fa4:	00c79513          	slli	a0,a5,0xc
}
    80202fa8:	60a2                	ld	ra,8(sp)
    80202faa:	6402                	ld	s0,0(sp)
    80202fac:	0141                	addi	sp,sp,16
    80202fae:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202fb0:	4501                	li	a0,0
    80202fb2:	bfdd                	j	80202fa8 <walkaddr+0x34>

0000000080202fb4 <mappages>:
{
    80202fb4:	715d                	addi	sp,sp,-80
    80202fb6:	e486                	sd	ra,72(sp)
    80202fb8:	e0a2                	sd	s0,64(sp)
    80202fba:	fc26                	sd	s1,56(sp)
    80202fbc:	f84a                	sd	s2,48(sp)
    80202fbe:	f44e                	sd	s3,40(sp)
    80202fc0:	f052                	sd	s4,32(sp)
    80202fc2:	ec56                	sd	s5,24(sp)
    80202fc4:	e85a                	sd	s6,16(sp)
    80202fc6:	e45e                	sd	s7,8(sp)
    80202fc8:	0880                	addi	s0,sp,80
    if (size == 0) panic("mappages: zero size");
    80202fca:	c639                	beqz	a2,80203018 <mappages+0x64>
    80202fcc:	8aaa                	mv	s5,a0
    80202fce:	8b3a                	mv	s6,a4
    uint64 a    = PGROUNDDOWN(va);
    80202fd0:	777d                	lui	a4,0xfffff
    80202fd2:	00e5f7b3          	and	a5,a1,a4
    uint64 last = PGROUNDDOWN(va + size - 1);
    80202fd6:	fff58993          	addi	s3,a1,-1
    80202fda:	99b2                	add	s3,s3,a2
    80202fdc:	00e9f9b3          	and	s3,s3,a4
    uint64 a    = PGROUNDDOWN(va);
    80202fe0:	893e                	mv	s2,a5
    80202fe2:	40f68a33          	sub	s4,a3,a5
        a  += PGSIZE;
    80202fe6:	6b85                	lui	s7,0x1
    80202fe8:	014904b3          	add	s1,s2,s4
        pte_t *pte = walk(pt, a, 1);
    80202fec:	4605                	li	a2,1
    80202fee:	85ca                	mv	a1,s2
    80202ff0:	8556                	mv	a0,s5
    80202ff2:	00000097          	auipc	ra,0x0
    80202ff6:	edc080e7          	jalr	-292(ra) # 80202ece <walk>
        if (!pte) return -1;
    80202ffa:	cd1d                	beqz	a0,80203038 <mappages+0x84>
        if (*pte & PTE_V) panic("mappages: remap");
    80202ffc:	611c                	ld	a5,0(a0)
    80202ffe:	8b85                	andi	a5,a5,1
    80203000:	e785                	bnez	a5,80203028 <mappages+0x74>
        *pte = PA2PTE(pa) | perm | PTE_V;
    80203002:	80b1                	srli	s1,s1,0xc
    80203004:	04aa                	slli	s1,s1,0xa
    80203006:	0164e4b3          	or	s1,s1,s6
    8020300a:	0014e493          	ori	s1,s1,1
    8020300e:	e104                	sd	s1,0(a0)
        if (a == last) break;
    80203010:	05390063          	beq	s2,s3,80203050 <mappages+0x9c>
        a  += PGSIZE;
    80203014:	995e                	add	s2,s2,s7
    for (;;) {
    80203016:	bfc9                	j	80202fe8 <mappages+0x34>
    if (size == 0) panic("mappages: zero size");
    80203018:	00007517          	auipc	a0,0x7
    8020301c:	89050513          	addi	a0,a0,-1904 # 802098a8 <etext+0x8a8>
    80203020:	ffffd097          	auipc	ra,0xffffd
    80203024:	5f6080e7          	jalr	1526(ra) # 80200616 <panic>
        if (*pte & PTE_V) panic("mappages: remap");
    80203028:	00007517          	auipc	a0,0x7
    8020302c:	89850513          	addi	a0,a0,-1896 # 802098c0 <etext+0x8c0>
    80203030:	ffffd097          	auipc	ra,0xffffd
    80203034:	5e6080e7          	jalr	1510(ra) # 80200616 <panic>
        if (!pte) return -1;
    80203038:	557d                	li	a0,-1
}
    8020303a:	60a6                	ld	ra,72(sp)
    8020303c:	6406                	ld	s0,64(sp)
    8020303e:	74e2                	ld	s1,56(sp)
    80203040:	7942                	ld	s2,48(sp)
    80203042:	79a2                	ld	s3,40(sp)
    80203044:	7a02                	ld	s4,32(sp)
    80203046:	6ae2                	ld	s5,24(sp)
    80203048:	6b42                	ld	s6,16(sp)
    8020304a:	6ba2                	ld	s7,8(sp)
    8020304c:	6161                	addi	sp,sp,80
    8020304e:	8082                	ret
    return 0;
    80203050:	4501                	li	a0,0
    80203052:	b7e5                	j	8020303a <mappages+0x86>

0000000080203054 <kvmmap>:
{
    80203054:	1141                	addi	sp,sp,-16
    80203056:	e406                	sd	ra,8(sp)
    80203058:	e022                	sd	s0,0(sp)
    8020305a:	0800                	addi	s0,sp,16
    8020305c:	8736                	mv	a4,a3
    if (mappages(kernel_pagetable, va, sz, pa, perm) != 0)
    8020305e:	86ae                	mv	a3,a1
    80203060:	85aa                	mv	a1,a0
    80203062:	00157517          	auipc	a0,0x157
    80203066:	fbe53503          	ld	a0,-66(a0) # 8035a020 <kernel_pagetable>
    8020306a:	00000097          	auipc	ra,0x0
    8020306e:	f4a080e7          	jalr	-182(ra) # 80202fb4 <mappages>
    80203072:	e509                	bnez	a0,8020307c <kvmmap+0x28>
}
    80203074:	60a2                	ld	ra,8(sp)
    80203076:	6402                	ld	s0,0(sp)
    80203078:	0141                	addi	sp,sp,16
    8020307a:	8082                	ret
        panic("kvmmap");
    8020307c:	00007517          	auipc	a0,0x7
    80203080:	85450513          	addi	a0,a0,-1964 # 802098d0 <etext+0x8d0>
    80203084:	ffffd097          	auipc	ra,0xffffd
    80203088:	592080e7          	jalr	1426(ra) # 80200616 <panic>

000000008020308c <kvminit>:
{
    8020308c:	7179                	addi	sp,sp,-48
    8020308e:	f406                	sd	ra,40(sp)
    80203090:	f022                	sd	s0,32(sp)
    80203092:	ec26                	sd	s1,24(sp)
    80203094:	e84a                	sd	s2,16(sp)
    80203096:	1800                	addi	s0,sp,48
    kernel_pagetable = (pagetable_t)palloc();
    80203098:	ffffe097          	auipc	ra,0xffffe
    8020309c:	04e080e7          	jalr	78(ra) # 802010e6 <palloc>
    802030a0:	00157717          	auipc	a4,0x157
    802030a4:	f8a73023          	sd	a0,-128(a4) # 8035a020 <kernel_pagetable>
    memset(kernel_pagetable, 0, PGSIZE);
    802030a8:	6605                	lui	a2,0x1
    802030aa:	4581                	li	a1,0
    802030ac:	ffffd097          	auipc	ra,0xffffd
    802030b0:	610080e7          	jalr	1552(ra) # 802006bc <memset>
    kvmmap(MMIO_VA(fdt.uart_base), fdt.uart_base, PGSIZE, PTE_R | PTE_W);
    802030b4:	00029497          	auipc	s1,0x29
    802030b8:	f6448493          	addi	s1,s1,-156 # 8022c018 <fdt>
    802030bc:	688c                	ld	a1,16(s1)
    802030be:	4505                	li	a0,1
    802030c0:	1502                	slli	a0,a0,0x20
    802030c2:	4699                	li	a3,6
    802030c4:	6605                	lui	a2,0x1
    802030c6:	952e                	add	a0,a0,a1
    802030c8:	00000097          	auipc	ra,0x0
    802030cc:	f8c080e7          	jalr	-116(ra) # 80203054 <kvmmap>
    if (fdt.plic_base)
    802030d0:	6c8c                	ld	a1,24(s1)
    802030d2:	e1d5                	bnez	a1,80203176 <kvminit+0xea>
    for (int i = 0; i < fdt.nvirtio; i++)
    802030d4:	00029797          	auipc	a5,0x29
    802030d8:	fcc7a783          	lw	a5,-52(a5) # 8022c0a0 <fdt+0x88>
    802030dc:	02f05e63          	blez	a5,80203118 <kvminit+0x8c>
    802030e0:	e44e                	sd	s3,8(sp)
    802030e2:	e052                	sd	s4,0(sp)
    802030e4:	00029917          	auipc	s2,0x29
    802030e8:	f3490913          	addi	s2,s2,-204 # 8022c018 <fdt>
    802030ec:	4481                	li	s1,0
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    802030ee:	4985                	li	s3,1
    802030f0:	1982                	slli	s3,s3,0x20
    for (int i = 0; i < fdt.nvirtio; i++)
    802030f2:	8a4a                	mv	s4,s2
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    802030f4:	02893583          	ld	a1,40(s2)
    802030f8:	4699                	li	a3,6
    802030fa:	6605                	lui	a2,0x1
    802030fc:	01358533          	add	a0,a1,s3
    80203100:	00000097          	auipc	ra,0x0
    80203104:	f54080e7          	jalr	-172(ra) # 80203054 <kvmmap>
    for (int i = 0; i < fdt.nvirtio; i++)
    80203108:	2485                	addiw	s1,s1,1
    8020310a:	0921                	addi	s2,s2,8
    8020310c:	088a2783          	lw	a5,136(s4)
    80203110:	fef4c2e3          	blt	s1,a5,802030f4 <kvminit+0x68>
    80203114:	69a2                	ld	s3,8(sp)
    80203116:	6a02                	ld	s4,0(sp)
    kvmmap(ktext, ktext, (uint64)etext - ktext, PTE_R | PTE_X);
    80203118:	00006497          	auipc	s1,0x6
    8020311c:	ee848493          	addi	s1,s1,-280 # 80209000 <etext>
    80203120:	bff00613          	li	a2,-1025
    80203124:	0656                	slli	a2,a2,0x15
    80203126:	46a9                	li	a3,10
    80203128:	9626                	add	a2,a2,s1
    8020312a:	40100593          	li	a1,1025
    8020312e:	05d6                	slli	a1,a1,0x15
    80203130:	852e                	mv	a0,a1
    80203132:	00000097          	auipc	ra,0x0
    80203136:	f22080e7          	jalr	-222(ra) # 80203054 <kvmmap>
    uint64 mem_end = fdt.mem_base + fdt.mem_size;
    8020313a:	00029917          	auipc	s2,0x29
    8020313e:	ede90913          	addi	s2,s2,-290 # 8022c018 <fdt>
    80203142:	09093603          	ld	a2,144(s2)
    80203146:	09893783          	ld	a5,152(s2)
    8020314a:	963e                	add	a2,a2,a5
    kvmmap((uint64)etext, (uint64)etext, mem_end - (uint64)etext, PTE_R | PTE_W);
    8020314c:	4699                	li	a3,6
    8020314e:	8e05                	sub	a2,a2,s1
    80203150:	85a6                	mv	a1,s1
    80203152:	8526                	mv	a0,s1
    80203154:	00000097          	auipc	ra,0x0
    80203158:	f00080e7          	jalr	-256(ra) # 80203054 <kvmmap>
    if (fdt.mem_base < ktext)
    8020315c:	09093503          	ld	a0,144(s2)
    80203160:	40100793          	li	a5,1025
    80203164:	07d6                	slli	a5,a5,0x15
    80203166:	02f56363          	bltu	a0,a5,8020318c <kvminit+0x100>
}
    8020316a:	70a2                	ld	ra,40(sp)
    8020316c:	7402                	ld	s0,32(sp)
    8020316e:	64e2                	ld	s1,24(sp)
    80203170:	6942                	ld	s2,16(sp)
    80203172:	6145                	addi	sp,sp,48
    80203174:	8082                	ret
        kvmmap(MMIO_VA(fdt.plic_base), fdt.plic_base, 0x400000, PTE_R | PTE_W);
    80203176:	4505                	li	a0,1
    80203178:	1502                	slli	a0,a0,0x20
    8020317a:	4699                	li	a3,6
    8020317c:	00400637          	lui	a2,0x400
    80203180:	952e                	add	a0,a0,a1
    80203182:	00000097          	auipc	ra,0x0
    80203186:	ed2080e7          	jalr	-302(ra) # 80203054 <kvmmap>
    8020318a:	b7a9                	j	802030d4 <kvminit+0x48>
        kvmmap(fdt.mem_base, fdt.mem_base, ktext - fdt.mem_base, PTE_R | PTE_W);
    8020318c:	4699                	li	a3,6
    8020318e:	40a78633          	sub	a2,a5,a0
    80203192:	85aa                	mv	a1,a0
    80203194:	00000097          	auipc	ra,0x0
    80203198:	ec0080e7          	jalr	-320(ra) # 80203054 <kvmmap>
}
    8020319c:	b7f9                	j	8020316a <kvminit+0xde>

000000008020319e <kvminithart>:
{
    8020319e:	1141                	addi	sp,sp,-16
    802031a0:	e422                	sd	s0,8(sp)
    802031a2:	0800                	addi	s0,sp,16
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    802031a4:	12000073          	sfence.vma
    w_satp(MAKE_SATP(kernel_pagetable));
    802031a8:	00157797          	auipc	a5,0x157
    802031ac:	e787b783          	ld	a5,-392(a5) # 8035a020 <kernel_pagetable>
    802031b0:	83b1                	srli	a5,a5,0xc
    802031b2:	577d                	li	a4,-1
    802031b4:	177e                	slli	a4,a4,0x3f
    802031b6:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    802031b8:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    802031bc:	12000073          	sfence.vma
}
    802031c0:	6422                	ld	s0,8(sp)
    802031c2:	0141                	addi	sp,sp,16
    802031c4:	8082                	ret

00000000802031c6 <uvmcreate>:
{
    802031c6:	1101                	addi	sp,sp,-32
    802031c8:	ec06                	sd	ra,24(sp)
    802031ca:	e822                	sd	s0,16(sp)
    802031cc:	e426                	sd	s1,8(sp)
    802031ce:	1000                	addi	s0,sp,32
    pagetable_t pt = (pagetable_t)palloc();
    802031d0:	ffffe097          	auipc	ra,0xffffe
    802031d4:	f16080e7          	jalr	-234(ra) # 802010e6 <palloc>
    802031d8:	84aa                	mv	s1,a0
    if (!pt) return 0;
    802031da:	c515                	beqz	a0,80203206 <uvmcreate+0x40>
    memset(pt, 0, PGSIZE);
    802031dc:	6605                	lui	a2,0x1
    802031de:	4581                	li	a1,0
    802031e0:	ffffd097          	auipc	ra,0xffffd
    802031e4:	4dc080e7          	jalr	1244(ra) # 802006bc <memset>
    802031e8:	47c1                	li	a5,16
        pt[i] = kernel_pagetable[i];
    802031ea:	00157597          	auipc	a1,0x157
    802031ee:	e3658593          	addi	a1,a1,-458 # 8035a020 <kernel_pagetable>
    for (int i = KERN_IDX_LO; i < 512; i++)
    802031f2:	6605                	lui	a2,0x1
        pt[i] = kernel_pagetable[i];
    802031f4:	6198                	ld	a4,0(a1)
    802031f6:	973e                	add	a4,a4,a5
    802031f8:	6314                	ld	a3,0(a4)
    802031fa:	00f48733          	add	a4,s1,a5
    802031fe:	e314                	sd	a3,0(a4)
    for (int i = KERN_IDX_LO; i < 512; i++)
    80203200:	07a1                	addi	a5,a5,8
    80203202:	fec799e3          	bne	a5,a2,802031f4 <uvmcreate+0x2e>
}
    80203206:	8526                	mv	a0,s1
    80203208:	60e2                	ld	ra,24(sp)
    8020320a:	6442                	ld	s0,16(sp)
    8020320c:	64a2                	ld	s1,8(sp)
    8020320e:	6105                	addi	sp,sp,32
    80203210:	8082                	ret

0000000080203212 <uvmunmap>:
{
    80203212:	7139                	addi	sp,sp,-64
    80203214:	fc06                	sd	ra,56(sp)
    80203216:	f822                	sd	s0,48(sp)
    80203218:	ec4e                	sd	s3,24(sp)
    8020321a:	0080                	addi	s0,sp,64
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8020321c:	0632                	slli	a2,a2,0xc
    8020321e:	00b609b3          	add	s3,a2,a1
    80203222:	0535fd63          	bgeu	a1,s3,8020327c <uvmunmap+0x6a>
    80203226:	f426                	sd	s1,40(sp)
    80203228:	f04a                	sd	s2,32(sp)
    8020322a:	e852                	sd	s4,16(sp)
    8020322c:	e456                	sd	s5,8(sp)
    8020322e:	e05a                	sd	s6,0(sp)
    80203230:	8a2a                	mv	s4,a0
    80203232:	892e                	mv	s2,a1
    80203234:	8ab6                	mv	s5,a3
    80203236:	6b05                	lui	s6,0x1
    80203238:	a031                	j	80203244 <uvmunmap+0x32>
        *pte = 0;
    8020323a:	0004b023          	sd	zero,0(s1)
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8020323e:	995a                	add	s2,s2,s6
    80203240:	03397963          	bgeu	s2,s3,80203272 <uvmunmap+0x60>
        pte_t *pte = walk(pt, a, 0);
    80203244:	4601                	li	a2,0
    80203246:	85ca                	mv	a1,s2
    80203248:	8552                	mv	a0,s4
    8020324a:	00000097          	auipc	ra,0x0
    8020324e:	c84080e7          	jalr	-892(ra) # 80202ece <walk>
    80203252:	84aa                	mv	s1,a0
        if (!pte || !(*pte & PTE_V)) continue;     /* lazily-allocated: fine */
    80203254:	d56d                	beqz	a0,8020323e <uvmunmap+0x2c>
    80203256:	611c                	ld	a5,0(a0)
    80203258:	0017f713          	andi	a4,a5,1
    8020325c:	d36d                	beqz	a4,8020323e <uvmunmap+0x2c>
        if (do_free) pfree((void *)PTE2PA(*pte));
    8020325e:	fc0a8ee3          	beqz	s5,8020323a <uvmunmap+0x28>
    80203262:	83a9                	srli	a5,a5,0xa
    80203264:	00c79513          	slli	a0,a5,0xc
    80203268:	ffffe097          	auipc	ra,0xffffe
    8020326c:	fbc080e7          	jalr	-68(ra) # 80201224 <pfree>
    80203270:	b7e9                	j	8020323a <uvmunmap+0x28>
    80203272:	74a2                	ld	s1,40(sp)
    80203274:	7902                	ld	s2,32(sp)
    80203276:	6a42                	ld	s4,16(sp)
    80203278:	6aa2                	ld	s5,8(sp)
    8020327a:	6b02                	ld	s6,0(sp)
}
    8020327c:	70e2                	ld	ra,56(sp)
    8020327e:	7442                	ld	s0,48(sp)
    80203280:	69e2                	ld	s3,24(sp)
    80203282:	6121                	addi	sp,sp,64
    80203284:	8082                	ret

0000000080203286 <uvmfree>:
{
    80203286:	1101                	addi	sp,sp,-32
    80203288:	ec06                	sd	ra,24(sp)
    8020328a:	e822                	sd	s0,16(sp)
    8020328c:	e426                	sd	s1,8(sp)
    8020328e:	1000                	addi	s0,sp,32
    80203290:	84aa                	mv	s1,a0
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80203292:	ed81                	bnez	a1,802032aa <uvmfree+0x24>
    freewalk_user(pt, 2);
    80203294:	4589                	li	a1,2
    80203296:	8526                	mv	a0,s1
    80203298:	00000097          	auipc	ra,0x0
    8020329c:	ad8080e7          	jalr	-1320(ra) # 80202d70 <freewalk_user>
}
    802032a0:	60e2                	ld	ra,24(sp)
    802032a2:	6442                	ld	s0,16(sp)
    802032a4:	64a2                	ld	s1,8(sp)
    802032a6:	6105                	addi	sp,sp,32
    802032a8:	8082                	ret
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    802032aa:	6785                	lui	a5,0x1
    802032ac:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    802032ae:	95be                	add	a1,a1,a5
    802032b0:	4685                	li	a3,1
    802032b2:	00c5d613          	srli	a2,a1,0xc
    802032b6:	4581                	li	a1,0
    802032b8:	00000097          	auipc	ra,0x0
    802032bc:	f5a080e7          	jalr	-166(ra) # 80203212 <uvmunmap>
    802032c0:	bfd1                	j	80203294 <uvmfree+0xe>

00000000802032c2 <uvmcopy>:
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    802032c2:	ca55                	beqz	a2,80203376 <uvmcopy+0xb4>
{
    802032c4:	7139                	addi	sp,sp,-64
    802032c6:	fc06                	sd	ra,56(sp)
    802032c8:	f822                	sd	s0,48(sp)
    802032ca:	f426                	sd	s1,40(sp)
    802032cc:	f04a                	sd	s2,32(sp)
    802032ce:	ec4e                	sd	s3,24(sp)
    802032d0:	e852                	sd	s4,16(sp)
    802032d2:	e456                	sd	s5,8(sp)
    802032d4:	e05a                	sd	s6,0(sp)
    802032d6:	0080                	addi	s0,sp,64
    802032d8:	8a2a                	mv	s4,a0
    802032da:	8aae                	mv	s5,a1
    802032dc:	89b2                	mv	s3,a2
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    802032de:	4481                	li	s1,0
            *pte = PA2PTE(pa) | flags;
    802032e0:	7b7d                	lui	s6,0xfffff
    802032e2:	002b5b13          	srli	s6,s6,0x2
    802032e6:	a81d                	j	8020331c <uvmcopy+0x5a>
            flags = (flags & ~PTE_W) | PTE_COW;
    802032e8:	2fb7f713          	andi	a4,a5,763
    802032ec:	10076713          	ori	a4,a4,256
            *pte = PA2PTE(pa) | flags;
    802032f0:	0167f7b3          	and	a5,a5,s6
    802032f4:	8fd9                	or	a5,a5,a4
    802032f6:	e11c                	sd	a5,0(a0)
        if (mappages(new, i, PGSIZE, pa, flags) != 0) {
    802032f8:	86ca                	mv	a3,s2
    802032fa:	6605                	lui	a2,0x1
    802032fc:	85a6                	mv	a1,s1
    802032fe:	8556                	mv	a0,s5
    80203300:	00000097          	auipc	ra,0x0
    80203304:	cb4080e7          	jalr	-844(ra) # 80202fb4 <mappages>
    80203308:	ed1d                	bnez	a0,80203346 <uvmcopy+0x84>
        palloc_ref_inc((void *)pa);
    8020330a:	854a                	mv	a0,s2
    8020330c:	ffffe097          	auipc	ra,0xffffe
    80203310:	e80080e7          	jalr	-384(ra) # 8020118c <palloc_ref_inc>
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80203314:	6785                	lui	a5,0x1
    80203316:	94be                	add	s1,s1,a5
    80203318:	0534f263          	bgeu	s1,s3,8020335c <uvmcopy+0x9a>
        pte_t *pte = walk(old, i, 0);
    8020331c:	4601                	li	a2,0
    8020331e:	85a6                	mv	a1,s1
    80203320:	8552                	mv	a0,s4
    80203322:	00000097          	auipc	ra,0x0
    80203326:	bac080e7          	jalr	-1108(ra) # 80202ece <walk>
        if (!pte || !(*pte & PTE_V)) continue;
    8020332a:	d56d                	beqz	a0,80203314 <uvmcopy+0x52>
    8020332c:	611c                	ld	a5,0(a0)
    8020332e:	0017f713          	andi	a4,a5,1
    80203332:	d36d                	beqz	a4,80203314 <uvmcopy+0x52>
        uint64 pa = PTE2PA(*pte);
    80203334:	00a7d913          	srli	s2,a5,0xa
    80203338:	0932                	slli	s2,s2,0xc
        if (flags & PTE_W) {
    8020333a:	0047f713          	andi	a4,a5,4
    8020333e:	f74d                	bnez	a4,802032e8 <uvmcopy+0x26>
        uint64 flags = PTE_FLAGS(*pte);
    80203340:	3ff7f713          	andi	a4,a5,1023
    80203344:	bf55                	j	802032f8 <uvmcopy+0x36>
            uvmunmap(new, 0, i / PGSIZE, 1);
    80203346:	4685                	li	a3,1
    80203348:	00c4d613          	srli	a2,s1,0xc
    8020334c:	4581                	li	a1,0
    8020334e:	8556                	mv	a0,s5
    80203350:	00000097          	auipc	ra,0x0
    80203354:	ec2080e7          	jalr	-318(ra) # 80203212 <uvmunmap>
            return -1;
    80203358:	557d                	li	a0,-1
    8020335a:	a021                	j	80203362 <uvmcopy+0xa0>
    8020335c:	12000073          	sfence.vma
    return 0;
    80203360:	4501                	li	a0,0
}
    80203362:	70e2                	ld	ra,56(sp)
    80203364:	7442                	ld	s0,48(sp)
    80203366:	74a2                	ld	s1,40(sp)
    80203368:	7902                	ld	s2,32(sp)
    8020336a:	69e2                	ld	s3,24(sp)
    8020336c:	6a42                	ld	s4,16(sp)
    8020336e:	6aa2                	ld	s5,8(sp)
    80203370:	6b02                	ld	s6,0(sp)
    80203372:	6121                	addi	sp,sp,64
    80203374:	8082                	ret
    80203376:	12000073          	sfence.vma
    return 0;
    8020337a:	4501                	li	a0,0
}
    8020337c:	8082                	ret

000000008020337e <cowfault>:
    if (va >= USER_TOP) return -1;
    8020337e:	800007b7          	lui	a5,0x80000
    80203382:	fff7c793          	not	a5,a5
    80203386:	0ab7eb63          	bltu	a5,a1,8020343c <cowfault+0xbe>
{
    8020338a:	7179                	addi	sp,sp,-48
    8020338c:	f406                	sd	ra,40(sp)
    8020338e:	f022                	sd	s0,32(sp)
    80203390:	e84a                	sd	s2,16(sp)
    80203392:	1800                	addi	s0,sp,48
    pte_t *pte = walk(pt, PGROUNDDOWN(va), 0);
    80203394:	4601                	li	a2,0
    80203396:	77fd                	lui	a5,0xfffff
    80203398:	8dfd                	and	a1,a1,a5
    8020339a:	00000097          	auipc	ra,0x0
    8020339e:	b34080e7          	jalr	-1228(ra) # 80202ece <walk>
    802033a2:	892a                	mv	s2,a0
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    802033a4:	cd51                	beqz	a0,80203440 <cowfault+0xc2>
    802033a6:	ec26                	sd	s1,24(sp)
    802033a8:	6104                	ld	s1,0(a0)
    802033aa:	0114f713          	andi	a4,s1,17
    802033ae:	47c5                	li	a5,17
    802033b0:	08f71a63          	bne	a4,a5,80203444 <cowfault+0xc6>
    if (!(*pte & PTE_COW)) return -1;
    802033b4:	1004f793          	andi	a5,s1,256
    802033b8:	cbc9                	beqz	a5,8020344a <cowfault+0xcc>
    802033ba:	e44e                	sd	s3,8(sp)
    802033bc:	e052                	sd	s4,0(sp)
    uint64 flags = (PTE_FLAGS(*pte) & ~PTE_COW) | PTE_W;
    802033be:	2fb4fa13          	andi	s4,s1,763
    802033c2:	004a6a13          	ori	s4,s4,4
    uint64 pa = PTE2PA(*pte);
    802033c6:	00a4d993          	srli	s3,s1,0xa
    802033ca:	09b2                	slli	s3,s3,0xc
    if (palloc_ref_get((void *)pa) == 1) {
    802033cc:	854e                	mv	a0,s3
    802033ce:	ffffe097          	auipc	ra,0xffffe
    802033d2:	e0c080e7          	jalr	-500(ra) # 802011da <palloc_ref_get>
    802033d6:	4785                	li	a5,1
    802033d8:	04f50463          	beq	a0,a5,80203420 <cowfault+0xa2>
    char *mem = palloc();
    802033dc:	ffffe097          	auipc	ra,0xffffe
    802033e0:	d0a080e7          	jalr	-758(ra) # 802010e6 <palloc>
    802033e4:	84aa                	mv	s1,a0
    if (!mem) return -1;
    802033e6:	c52d                	beqz	a0,80203450 <cowfault+0xd2>
    memmove(mem, (void *)pa, PGSIZE);
    802033e8:	6605                	lui	a2,0x1
    802033ea:	85ce                	mv	a1,s3
    802033ec:	ffffd097          	auipc	ra,0xffffd
    802033f0:	2ec080e7          	jalr	748(ra) # 802006d8 <memmove>
    *pte = PA2PTE((uint64)mem) | flags;
    802033f4:	80b1                	srli	s1,s1,0xc
    802033f6:	04aa                	slli	s1,s1,0xa
    802033f8:	0144e4b3          	or	s1,s1,s4
    802033fc:	00993023          	sd	s1,0(s2)
    80203400:	12000073          	sfence.vma
    pfree((void *)pa);
    80203404:	854e                	mv	a0,s3
    80203406:	ffffe097          	auipc	ra,0xffffe
    8020340a:	e1e080e7          	jalr	-482(ra) # 80201224 <pfree>
    return 0;
    8020340e:	4501                	li	a0,0
    80203410:	64e2                	ld	s1,24(sp)
    80203412:	69a2                	ld	s3,8(sp)
    80203414:	6a02                	ld	s4,0(sp)
}
    80203416:	70a2                	ld	ra,40(sp)
    80203418:	7402                	ld	s0,32(sp)
    8020341a:	6942                	ld	s2,16(sp)
    8020341c:	6145                	addi	sp,sp,48
    8020341e:	8082                	ret
        *pte = PA2PTE(pa) | flags;
    80203420:	77fd                	lui	a5,0xfffff
    80203422:	8389                	srli	a5,a5,0x2
    80203424:	8cfd                	and	s1,s1,a5
    80203426:	0144e4b3          	or	s1,s1,s4
    8020342a:	00993023          	sd	s1,0(s2)
    8020342e:	12000073          	sfence.vma
        return 0;
    80203432:	4501                	li	a0,0
    80203434:	64e2                	ld	s1,24(sp)
    80203436:	69a2                	ld	s3,8(sp)
    80203438:	6a02                	ld	s4,0(sp)
    8020343a:	bff1                	j	80203416 <cowfault+0x98>
    if (va >= USER_TOP) return -1;
    8020343c:	557d                	li	a0,-1
}
    8020343e:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203440:	557d                	li	a0,-1
    80203442:	bfd1                	j	80203416 <cowfault+0x98>
    80203444:	557d                	li	a0,-1
    80203446:	64e2                	ld	s1,24(sp)
    80203448:	b7f9                	j	80203416 <cowfault+0x98>
    if (!(*pte & PTE_COW)) return -1;
    8020344a:	557d                	li	a0,-1
    8020344c:	64e2                	ld	s1,24(sp)
    8020344e:	b7e1                	j	80203416 <cowfault+0x98>
    if (!mem) return -1;
    80203450:	557d                	li	a0,-1
    80203452:	64e2                	ld	s1,24(sp)
    80203454:	69a2                	ld	s3,8(sp)
    80203456:	6a02                	ld	s4,0(sp)
    80203458:	bf7d                	j	80203416 <cowfault+0x98>

000000008020345a <copyout>:
    while (len > 0) {
    8020345a:	c6e1                	beqz	a3,80203522 <copyout+0xc8>
{
    8020345c:	711d                	addi	sp,sp,-96
    8020345e:	ec86                	sd	ra,88(sp)
    80203460:	e8a2                	sd	s0,80(sp)
    80203462:	e4a6                	sd	s1,72(sp)
    80203464:	e0ca                	sd	s2,64(sp)
    80203466:	fc4e                	sd	s3,56(sp)
    80203468:	f852                	sd	s4,48(sp)
    8020346a:	f456                	sd	s5,40(sp)
    8020346c:	1080                	addi	s0,sp,96
    8020346e:	8aaa                	mv	s5,a0
    80203470:	89ae                	mv	s3,a1
    80203472:	8a32                	mv	s4,a2
    80203474:	8936                	mv	s2,a3
        uint64 va0 = PGROUNDDOWN(dstva);
    80203476:	74fd                	lui	s1,0xfffff
    80203478:	8ced                	and	s1,s1,a1
        if (va0 >= USER_TOP) return -1;
    8020347a:	800007b7          	lui	a5,0x80000
    8020347e:	fff7c793          	not	a5,a5
    80203482:	0a97e263          	bltu	a5,s1,80203526 <copyout+0xcc>
    80203486:	f05a                	sd	s6,32(sp)
    80203488:	ec5e                	sd	s7,24(sp)
    8020348a:	e862                	sd	s8,16(sp)
    8020348c:	e466                	sd	s9,8(sp)
    8020348e:	e06a                	sd	s10,0(sp)
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203490:	4bc5                	li	s7,17
    80203492:	6c05                	lui	s8,0x1
        if (va0 >= USER_TOP) return -1;
    80203494:	8b3e                	mv	s6,a5
    80203496:	a035                	j	802034c2 <copyout+0x68>
        uint64 pa0 = PTE2PA(*pte);
    80203498:	611c                	ld	a5,0(a0)
    8020349a:	83a9                	srli	a5,a5,0xa
    8020349c:	07b2                	slli	a5,a5,0xc
        memmove((void *)(pa0 + (dstva - va0)), src, n);
    8020349e:	40998533          	sub	a0,s3,s1
    802034a2:	8666                	mv	a2,s9
    802034a4:	85d2                	mv	a1,s4
    802034a6:	953e                	add	a0,a0,a5
    802034a8:	ffffd097          	auipc	ra,0xffffd
    802034ac:	230080e7          	jalr	560(ra) # 802006d8 <memmove>
        len -= n; src += n; dstva = va0 + PGSIZE;
    802034b0:	41990933          	sub	s2,s2,s9
    802034b4:	9a66                	add	s4,s4,s9
    while (len > 0) {
    802034b6:	04090f63          	beqz	s2,80203514 <copyout+0xba>
        if (va0 >= USER_TOP) return -1;
    802034ba:	07ab6863          	bltu	s6,s10,8020352a <copyout+0xd0>
    802034be:	84ea                	mv	s1,s10
    802034c0:	89ea                	mv	s3,s10
        pte_t *pte = walk(pt, va0, 0);
    802034c2:	4601                	li	a2,0
    802034c4:	85a6                	mv	a1,s1
    802034c6:	8556                	mv	a0,s5
    802034c8:	00000097          	auipc	ra,0x0
    802034cc:	a06080e7          	jalr	-1530(ra) # 80202ece <walk>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    802034d0:	c525                	beqz	a0,80203538 <copyout+0xde>
    802034d2:	611c                	ld	a5,0(a0)
    802034d4:	0117f713          	andi	a4,a5,17
    802034d8:	07771f63          	bne	a4,s7,80203556 <copyout+0xfc>
        if (!(*pte & PTE_W)) {
    802034dc:	0047f713          	andi	a4,a5,4
    802034e0:	e315                	bnez	a4,80203504 <copyout+0xaa>
            if ((*pte & PTE_COW) && cowfault(pt, va0) == 0)
    802034e2:	1007f793          	andi	a5,a5,256
    802034e6:	cfbd                	beqz	a5,80203564 <copyout+0x10a>
    802034e8:	85a6                	mv	a1,s1
    802034ea:	8556                	mv	a0,s5
    802034ec:	00000097          	auipc	ra,0x0
    802034f0:	e92080e7          	jalr	-366(ra) # 8020337e <cowfault>
    802034f4:	ed3d                	bnez	a0,80203572 <copyout+0x118>
                pte = walk(pt, va0, 0);
    802034f6:	4601                	li	a2,0
    802034f8:	85a6                	mv	a1,s1
    802034fa:	8556                	mv	a0,s5
    802034fc:	00000097          	auipc	ra,0x0
    80203500:	9d2080e7          	jalr	-1582(ra) # 80202ece <walk>
        uint64 n = PGSIZE - (dstva - va0);
    80203504:	01848d33          	add	s10,s1,s8
    80203508:	413d0cb3          	sub	s9,s10,s3
        if (n > len) n = len;
    8020350c:	f99976e3          	bgeu	s2,s9,80203498 <copyout+0x3e>
    80203510:	8cca                	mv	s9,s2
    80203512:	b759                	j	80203498 <copyout+0x3e>
    return 0;
    80203514:	4501                	li	a0,0
    80203516:	7b02                	ld	s6,32(sp)
    80203518:	6be2                	ld	s7,24(sp)
    8020351a:	6c42                	ld	s8,16(sp)
    8020351c:	6ca2                	ld	s9,8(sp)
    8020351e:	6d02                	ld	s10,0(sp)
    80203520:	a015                	j	80203544 <copyout+0xea>
    80203522:	4501                	li	a0,0
}
    80203524:	8082                	ret
        if (va0 >= USER_TOP) return -1;
    80203526:	557d                	li	a0,-1
    80203528:	a831                	j	80203544 <copyout+0xea>
    8020352a:	557d                	li	a0,-1
    8020352c:	7b02                	ld	s6,32(sp)
    8020352e:	6be2                	ld	s7,24(sp)
    80203530:	6c42                	ld	s8,16(sp)
    80203532:	6ca2                	ld	s9,8(sp)
    80203534:	6d02                	ld	s10,0(sp)
    80203536:	a039                	j	80203544 <copyout+0xea>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203538:	557d                	li	a0,-1
    8020353a:	7b02                	ld	s6,32(sp)
    8020353c:	6be2                	ld	s7,24(sp)
    8020353e:	6c42                	ld	s8,16(sp)
    80203540:	6ca2                	ld	s9,8(sp)
    80203542:	6d02                	ld	s10,0(sp)
}
    80203544:	60e6                	ld	ra,88(sp)
    80203546:	6446                	ld	s0,80(sp)
    80203548:	64a6                	ld	s1,72(sp)
    8020354a:	6906                	ld	s2,64(sp)
    8020354c:	79e2                	ld	s3,56(sp)
    8020354e:	7a42                	ld	s4,48(sp)
    80203550:	7aa2                	ld	s5,40(sp)
    80203552:	6125                	addi	sp,sp,96
    80203554:	8082                	ret
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203556:	557d                	li	a0,-1
    80203558:	7b02                	ld	s6,32(sp)
    8020355a:	6be2                	ld	s7,24(sp)
    8020355c:	6c42                	ld	s8,16(sp)
    8020355e:	6ca2                	ld	s9,8(sp)
    80203560:	6d02                	ld	s10,0(sp)
    80203562:	b7cd                	j	80203544 <copyout+0xea>
            else return -1;
    80203564:	557d                	li	a0,-1
    80203566:	7b02                	ld	s6,32(sp)
    80203568:	6be2                	ld	s7,24(sp)
    8020356a:	6c42                	ld	s8,16(sp)
    8020356c:	6ca2                	ld	s9,8(sp)
    8020356e:	6d02                	ld	s10,0(sp)
    80203570:	bfd1                	j	80203544 <copyout+0xea>
    80203572:	557d                	li	a0,-1
    80203574:	7b02                	ld	s6,32(sp)
    80203576:	6be2                	ld	s7,24(sp)
    80203578:	6c42                	ld	s8,16(sp)
    8020357a:	6ca2                	ld	s9,8(sp)
    8020357c:	6d02                	ld	s10,0(sp)
    8020357e:	b7d9                	j	80203544 <copyout+0xea>

0000000080203580 <copyin>:
    while (len > 0) {
    80203580:	c6bd                	beqz	a3,802035ee <copyin+0x6e>
{
    80203582:	715d                	addi	sp,sp,-80
    80203584:	e486                	sd	ra,72(sp)
    80203586:	e0a2                	sd	s0,64(sp)
    80203588:	fc26                	sd	s1,56(sp)
    8020358a:	f84a                	sd	s2,48(sp)
    8020358c:	f44e                	sd	s3,40(sp)
    8020358e:	f052                	sd	s4,32(sp)
    80203590:	ec56                	sd	s5,24(sp)
    80203592:	e85a                	sd	s6,16(sp)
    80203594:	e45e                	sd	s7,8(sp)
    80203596:	e062                	sd	s8,0(sp)
    80203598:	0880                	addi	s0,sp,80
    8020359a:	8b2a                	mv	s6,a0
    8020359c:	8a2e                	mv	s4,a1
    8020359e:	8c32                	mv	s8,a2
    802035a0:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    802035a2:	7bfd                	lui	s7,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    802035a4:	6a85                	lui	s5,0x1
    802035a6:	a015                	j	802035ca <copyin+0x4a>
        memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    802035a8:	018505b3          	add	a1,a0,s8
    802035ac:	8626                	mv	a2,s1
    802035ae:	412585b3          	sub	a1,a1,s2
    802035b2:	8552                	mv	a0,s4
    802035b4:	ffffd097          	auipc	ra,0xffffd
    802035b8:	124080e7          	jalr	292(ra) # 802006d8 <memmove>
        len -= n; dst += n; srcva = va0 + PGSIZE;
    802035bc:	409989b3          	sub	s3,s3,s1
    802035c0:	9a26                	add	s4,s4,s1
    802035c2:	01590c33          	add	s8,s2,s5
    while (len > 0) {
    802035c6:	02098263          	beqz	s3,802035ea <copyin+0x6a>
        uint64 va0 = PGROUNDDOWN(srcva);
    802035ca:	017c7933          	and	s2,s8,s7
        uint64 pa0 = walkaddr(pt, va0);
    802035ce:	85ca                	mv	a1,s2
    802035d0:	855a                	mv	a0,s6
    802035d2:	00000097          	auipc	ra,0x0
    802035d6:	9a2080e7          	jalr	-1630(ra) # 80202f74 <walkaddr>
        if (pa0 == 0) return -1;
    802035da:	cd01                	beqz	a0,802035f2 <copyin+0x72>
        uint64 n = PGSIZE - (srcva - va0);
    802035dc:	418904b3          	sub	s1,s2,s8
    802035e0:	94d6                	add	s1,s1,s5
        if (n > len) n = len;
    802035e2:	fc99f3e3          	bgeu	s3,s1,802035a8 <copyin+0x28>
    802035e6:	84ce                	mv	s1,s3
    802035e8:	b7c1                	j	802035a8 <copyin+0x28>
    return 0;
    802035ea:	4501                	li	a0,0
    802035ec:	a021                	j	802035f4 <copyin+0x74>
    802035ee:	4501                	li	a0,0
}
    802035f0:	8082                	ret
        if (pa0 == 0) return -1;
    802035f2:	557d                	li	a0,-1
}
    802035f4:	60a6                	ld	ra,72(sp)
    802035f6:	6406                	ld	s0,64(sp)
    802035f8:	74e2                	ld	s1,56(sp)
    802035fa:	7942                	ld	s2,48(sp)
    802035fc:	79a2                	ld	s3,40(sp)
    802035fe:	7a02                	ld	s4,32(sp)
    80203600:	6ae2                	ld	s5,24(sp)
    80203602:	6b42                	ld	s6,16(sp)
    80203604:	6ba2                	ld	s7,8(sp)
    80203606:	6c02                	ld	s8,0(sp)
    80203608:	6161                	addi	sp,sp,80
    8020360a:	8082                	ret

000000008020360c <copyinstr>:
    while (got_null == 0 && max > 0) {
    8020360c:	c6cd                	beqz	a3,802036b6 <copyinstr+0xaa>
{
    8020360e:	715d                	addi	sp,sp,-80
    80203610:	e486                	sd	ra,72(sp)
    80203612:	e0a2                	sd	s0,64(sp)
    80203614:	fc26                	sd	s1,56(sp)
    80203616:	f84a                	sd	s2,48(sp)
    80203618:	f44e                	sd	s3,40(sp)
    8020361a:	f052                	sd	s4,32(sp)
    8020361c:	ec56                	sd	s5,24(sp)
    8020361e:	e85a                	sd	s6,16(sp)
    80203620:	e45e                	sd	s7,8(sp)
    80203622:	0880                	addi	s0,sp,80
    80203624:	8a2a                	mv	s4,a0
    80203626:	8b2e                	mv	s6,a1
    80203628:	8bb2                	mv	s7,a2
    8020362a:	8936                	mv	s2,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    8020362c:	7afd                	lui	s5,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    8020362e:	6985                	lui	s3,0x1
    80203630:	a811                	j	80203644 <copyinstr+0x38>
    80203632:	01258733          	add	a4,a1,s2
            dst++; p++; n--; max--;
    80203636:	40f70933          	sub	s2,a4,a5
        srcva = va0 + PGSIZE;
    8020363a:	01348bb3          	add	s7,s1,s3
    while (got_null == 0 && max > 0) {
    8020363e:	06e78463          	beq	a5,a4,802036a6 <copyinstr+0x9a>
{
    80203642:	8b3e                	mv	s6,a5
        uint64 va0 = PGROUNDDOWN(srcva);
    80203644:	015bf4b3          	and	s1,s7,s5
        uint64 pa0 = walkaddr(pt, va0);
    80203648:	85a6                	mv	a1,s1
    8020364a:	8552                	mv	a0,s4
    8020364c:	00000097          	auipc	ra,0x0
    80203650:	928080e7          	jalr	-1752(ra) # 80202f74 <walkaddr>
        if (pa0 == 0) return -1;
    80203654:	c939                	beqz	a0,802036aa <copyinstr+0x9e>
        uint64 n = PGSIZE - (srcva - va0);
    80203656:	417486b3          	sub	a3,s1,s7
    8020365a:	96ce                	add	a3,a3,s3
        if (n > max) n = max;
    8020365c:	00d97363          	bgeu	s2,a3,80203662 <copyinstr+0x56>
    80203660:	86ca                	mv	a3,s2
        char *p = (char *)(pa0 + (srcva - va0));
    80203662:	955e                	add	a0,a0,s7
    80203664:	8d05                	sub	a0,a0,s1
        while (n > 0) {
    80203666:	c6a1                	beqz	a3,802036ae <copyinstr+0xa2>
    80203668:	87da                	mv	a5,s6
    8020366a:	85da                	mv	a1,s6
            *dst = *p;
    8020366c:	41650633          	sub	a2,a0,s6
        while (n > 0) {
    80203670:	96da                	add	a3,a3,s6
            *dst = *p;
    80203672:	00c78733          	add	a4,a5,a2
    80203676:	00074703          	lbu	a4,0(a4)
    8020367a:	00e78023          	sb	a4,0(a5) # ffffffff80000000 <uart+0xfffffffeffca5fd0>
            if (*p == '\0') { got_null = 1; break; }
    8020367e:	c709                	beqz	a4,80203688 <copyinstr+0x7c>
            dst++; p++; n--; max--;
    80203680:	0785                	addi	a5,a5,1
        while (n > 0) {
    80203682:	fef698e3          	bne	a3,a5,80203672 <copyinstr+0x66>
    80203686:	b775                	j	80203632 <copyinstr+0x26>
    80203688:	4785                	li	a5,1
    return got_null ? 0 : -1;
    8020368a:	37fd                	addiw	a5,a5,-1
    8020368c:	0007851b          	sext.w	a0,a5
}
    80203690:	60a6                	ld	ra,72(sp)
    80203692:	6406                	ld	s0,64(sp)
    80203694:	74e2                	ld	s1,56(sp)
    80203696:	7942                	ld	s2,48(sp)
    80203698:	79a2                	ld	s3,40(sp)
    8020369a:	7a02                	ld	s4,32(sp)
    8020369c:	6ae2                	ld	s5,24(sp)
    8020369e:	6b42                	ld	s6,16(sp)
    802036a0:	6ba2                	ld	s7,8(sp)
    802036a2:	6161                	addi	sp,sp,80
    802036a4:	8082                	ret
    802036a6:	4781                	li	a5,0
    802036a8:	b7cd                	j	8020368a <copyinstr+0x7e>
        if (pa0 == 0) return -1;
    802036aa:	557d                	li	a0,-1
    802036ac:	b7d5                	j	80203690 <copyinstr+0x84>
        srcva = va0 + PGSIZE;
    802036ae:	6b85                	lui	s7,0x1
    802036b0:	9ba6                	add	s7,s7,s1
    802036b2:	87da                	mv	a5,s6
    802036b4:	b779                	j	80203642 <copyinstr+0x36>
    int got_null = 0;
    802036b6:	4781                	li	a5,0
    return got_null ? 0 : -1;
    802036b8:	37fd                	addiw	a5,a5,-1
    802036ba:	0007851b          	sext.w	a0,a5
}
    802036be:	8082                	ret

00000000802036c0 <vmprint>:
void vmprint(pagetable_t pt)
{
    802036c0:	1101                	addi	sp,sp,-32
    802036c2:	ec06                	sd	ra,24(sp)
    802036c4:	e822                	sd	s0,16(sp)
    802036c6:	e426                	sd	s1,8(sp)
    802036c8:	1000                	addi	s0,sp,32
    802036ca:	84aa                	mv	s1,a0
    printf("page table %p (user half)\n", pt);
    802036cc:	85aa                	mv	a1,a0
    802036ce:	00006517          	auipc	a0,0x6
    802036d2:	20a50513          	addi	a0,a0,522 # 802098d8 <etext+0x8d8>
    802036d6:	ffffd097          	auipc	ra,0xffffd
    802036da:	cce080e7          	jalr	-818(ra) # 802003a4 <printf>
    vmprint_lvl(pt, 2);
    802036de:	4589                	li	a1,2
    802036e0:	8526                	mv	a0,s1
    802036e2:	fffff097          	auipc	ra,0xfffff
    802036e6:	6fe080e7          	jalr	1790(ra) # 80202de0 <vmprint_lvl>
}
    802036ea:	60e2                	ld	ra,24(sp)
    802036ec:	6442                	ld	s0,16(sp)
    802036ee:	64a2                	ld	s1,8(sp)
    802036f0:	6105                	addi	sp,sp,32
    802036f2:	8082                	ret

00000000802036f4 <sys_getpid>:
    int n; argint(0, &n);
    exit(n);
    return 0;
}

uint64 sys_getpid(void) { return myproc()->pid; }
    802036f4:	1141                	addi	sp,sp,-16
    802036f6:	e406                	sd	ra,8(sp)
    802036f8:	e022                	sd	s0,0(sp)
    802036fa:	0800                	addi	s0,sp,16
    802036fc:	ffffe097          	auipc	ra,0xffffe
    80203700:	1f4080e7          	jalr	500(ra) # 802018f0 <myproc>
    80203704:	5908                	lw	a0,48(a0)
    80203706:	60a2                	ld	ra,8(sp)
    80203708:	6402                	ld	s0,0(sp)
    8020370a:	0141                	addi	sp,sp,16
    8020370c:	8082                	ret

000000008020370e <sys_gettid>:
    argaddr(0, &fn);
    argaddr(1, &arg);
    argaddr(2, &stack);
    return clone(fn, arg, stack);
}
uint64 sys_gettid(void) { return myproc()->pid; }
    8020370e:	1141                	addi	sp,sp,-16
    80203710:	e406                	sd	ra,8(sp)
    80203712:	e022                	sd	s0,0(sp)
    80203714:	0800                	addi	s0,sp,16
    80203716:	ffffe097          	auipc	ra,0xffffe
    8020371a:	1da080e7          	jalr	474(ra) # 802018f0 <myproc>
    8020371e:	5908                	lw	a0,48(a0)
    80203720:	60a2                	ld	ra,8(sp)
    80203722:	6402                	ld	s0,0(sp)
    80203724:	0141                	addi	sp,sp,16
    80203726:	8082                	ret

0000000080203728 <sys_sigreturn>:
    p->alarm_handler = handler;
    p->alarm_ticks = 0;
    return 0;
}
uint64 sys_sigreturn(void)
{
    80203728:	1141                	addi	sp,sp,-16
    8020372a:	e406                	sd	ra,8(sp)
    8020372c:	e022                	sd	s0,0(sp)
    8020372e:	0800                	addi	s0,sp,16
    struct proc *p = myproc();
    80203730:	ffffe097          	auipc	ra,0xffffe
    80203734:	1c0080e7          	jalr	448(ra) # 802018f0 <myproc>
    if (p->alarm_saved == 0 || !p->in_handler) return -1;
    80203738:	1b853603          	ld	a2,440(a0)
    8020373c:	c621                	beqz	a2,80203784 <sys_sigreturn+0x5c>
    8020373e:	872a                	mv	a4,a0
    80203740:	1b452783          	lw	a5,436(a0)
    80203744:	557d                	li	a0,-1
    80203746:	cb9d                	beqz	a5,8020377c <sys_sigreturn+0x54>
    *(p->tf) = *(p->alarm_saved);           /* full restore */
    80203748:	87b2                	mv	a5,a2
    8020374a:	6f34                	ld	a3,88(a4)
    8020374c:	12060613          	addi	a2,a2,288 # 1120 <_entry-0x801feee0>
    80203750:	0007b883          	ld	a7,0(a5)
    80203754:	0087b803          	ld	a6,8(a5)
    80203758:	6b88                	ld	a0,16(a5)
    8020375a:	6f8c                	ld	a1,24(a5)
    8020375c:	0116b023          	sd	a7,0(a3) # 4000 <_entry-0x801fc000>
    80203760:	0106b423          	sd	a6,8(a3)
    80203764:	ea88                	sd	a0,16(a3)
    80203766:	ee8c                	sd	a1,24(a3)
    80203768:	02078793          	addi	a5,a5,32
    8020376c:	02068693          	addi	a3,a3,32
    80203770:	fec790e3          	bne	a5,a2,80203750 <sys_sigreturn+0x28>
    p->in_handler = 0;
    80203774:	1a072a23          	sw	zero,436(a4)
    return p->tf->a0;                        /* preserve a0 */
    80203778:	6f3c                	ld	a5,88(a4)
    8020377a:	7ba8                	ld	a0,112(a5)
}
    8020377c:	60a2                	ld	ra,8(sp)
    8020377e:	6402                	ld	s0,0(sp)
    80203780:	0141                	addi	sp,sp,16
    80203782:	8082                	ret
    if (p->alarm_saved == 0 || !p->in_handler) return -1;
    80203784:	557d                	li	a0,-1
    80203786:	bfdd                	j	8020377c <sys_sigreturn+0x54>

0000000080203788 <argraw>:
{
    80203788:	1101                	addi	sp,sp,-32
    8020378a:	ec06                	sd	ra,24(sp)
    8020378c:	e822                	sd	s0,16(sp)
    8020378e:	e426                	sd	s1,8(sp)
    80203790:	1000                	addi	s0,sp,32
    80203792:	84aa                	mv	s1,a0
    struct trapframe *tf = myproc()->tf;
    80203794:	ffffe097          	auipc	ra,0xffffe
    80203798:	15c080e7          	jalr	348(ra) # 802018f0 <myproc>
    8020379c:	6d34                	ld	a3,88(a0)
    switch (n) {
    8020379e:	4795                	li	a5,5
    802037a0:	0297eb63          	bltu	a5,s1,802037d6 <argraw+0x4e>
    802037a4:	048a                	slli	s1,s1,0x2
    802037a6:	00007717          	auipc	a4,0x7
    802037aa:	8c270713          	addi	a4,a4,-1854 # 8020a068 <st.0+0x70>
    802037ae:	94ba                	add	s1,s1,a4
    802037b0:	409c                	lw	a5,0(s1)
    802037b2:	97ba                	add	a5,a5,a4
    802037b4:	8782                	jr	a5
    case 0: return tf->a0;
    802037b6:	7aa8                	ld	a0,112(a3)
}
    802037b8:	60e2                	ld	ra,24(sp)
    802037ba:	6442                	ld	s0,16(sp)
    802037bc:	64a2                	ld	s1,8(sp)
    802037be:	6105                	addi	sp,sp,32
    802037c0:	8082                	ret
    case 1: return tf->a1;
    802037c2:	7ea8                	ld	a0,120(a3)
    802037c4:	bfd5                	j	802037b8 <argraw+0x30>
    case 2: return tf->a2;
    802037c6:	62c8                	ld	a0,128(a3)
    802037c8:	bfc5                	j	802037b8 <argraw+0x30>
    case 3: return tf->a3;
    802037ca:	66c8                	ld	a0,136(a3)
    802037cc:	b7f5                	j	802037b8 <argraw+0x30>
    case 4: return tf->a4;
    802037ce:	6ac8                	ld	a0,144(a3)
    802037d0:	b7e5                	j	802037b8 <argraw+0x30>
    case 5: return tf->a5;
    802037d2:	6ec8                	ld	a0,152(a3)
    802037d4:	b7d5                	j	802037b8 <argraw+0x30>
    panic("argraw: bad arg index");
    802037d6:	00006517          	auipc	a0,0x6
    802037da:	12250513          	addi	a0,a0,290 # 802098f8 <etext+0x8f8>
    802037de:	ffffd097          	auipc	ra,0xffffd
    802037e2:	e38080e7          	jalr	-456(ra) # 80200616 <panic>

00000000802037e6 <sys_fork>:
uint64 sys_fork(void)   { return fork(); }
    802037e6:	1141                	addi	sp,sp,-16
    802037e8:	e406                	sd	ra,8(sp)
    802037ea:	e022                	sd	s0,0(sp)
    802037ec:	0800                	addi	s0,sp,16
    802037ee:	ffffe097          	auipc	ra,0xffffe
    802037f2:	42c080e7          	jalr	1068(ra) # 80201c1a <fork>
    802037f6:	60a2                	ld	ra,8(sp)
    802037f8:	6402                	ld	s0,0(sp)
    802037fa:	0141                	addi	sp,sp,16
    802037fc:	8082                	ret

00000000802037fe <sys_uptime>:
{
    802037fe:	1101                	addi	sp,sp,-32
    80203800:	ec06                	sd	ra,24(sp)
    80203802:	e822                	sd	s0,16(sp)
    80203804:	e426                	sd	s1,8(sp)
    80203806:	1000                	addi	s0,sp,32
    acquire(&tickslock);
    80203808:	00131517          	auipc	a0,0x131
    8020380c:	7f850513          	addi	a0,a0,2040 # 80335000 <tickslock>
    80203810:	ffffe097          	auipc	ra,0xffffe
    80203814:	c78080e7          	jalr	-904(ra) # 80201488 <acquire>
    uint64 t = ticks;
    80203818:	00157497          	auipc	s1,0x157
    8020381c:	8004b483          	ld	s1,-2048(s1) # 8035a018 <ticks>
    release(&tickslock);
    80203820:	00131517          	auipc	a0,0x131
    80203824:	7e050513          	addi	a0,a0,2016 # 80335000 <tickslock>
    80203828:	ffffe097          	auipc	ra,0xffffe
    8020382c:	d14080e7          	jalr	-748(ra) # 8020153c <release>
}
    80203830:	8526                	mv	a0,s1
    80203832:	60e2                	ld	ra,24(sp)
    80203834:	6442                	ld	s0,16(sp)
    80203836:	64a2                	ld	s1,8(sp)
    80203838:	6105                	addi	sp,sp,32
    8020383a:	8082                	ret

000000008020383c <sys_freepages>:
uint64 sys_freepages(void) { return palloc_free_count(); }
    8020383c:	1141                	addi	sp,sp,-16
    8020383e:	e406                	sd	ra,8(sp)
    80203840:	e022                	sd	s0,0(sp)
    80203842:	0800                	addi	s0,sp,16
    80203844:	ffffe097          	auipc	ra,0xffffe
    80203848:	ad4080e7          	jalr	-1324(ra) # 80201318 <palloc_free_count>
    8020384c:	60a2                	ld	ra,8(sp)
    8020384e:	6402                	ld	s0,0(sp)
    80203850:	0141                	addi	sp,sp,16
    80203852:	8082                	ret

0000000080203854 <sys_pgaudit>:
uint64 sys_pgaudit(void){ struct proc *p=myproc(); return pgaudit(p->pagetable,p->sz); }
    80203854:	1141                	addi	sp,sp,-16
    80203856:	e406                	sd	ra,8(sp)
    80203858:	e022                	sd	s0,0(sp)
    8020385a:	0800                	addi	s0,sp,16
    8020385c:	ffffe097          	auipc	ra,0xffffe
    80203860:	094080e7          	jalr	148(ra) # 802018f0 <myproc>
    80203864:	652c                	ld	a1,72(a0)
    80203866:	6928                	ld	a0,80(a0)
    80203868:	00002097          	auipc	ra,0x2
    8020386c:	99a080e7          	jalr	-1638(ra) # 80205202 <pgaudit>
    80203870:	60a2                	ld	ra,8(sp)
    80203872:	6402                	ld	s0,0(sp)
    80203874:	0141                	addi	sp,sp,16
    80203876:	8082                	ret

0000000080203878 <sys_alloc_audit>:
    struct allocstat st;
    alloc_stats(&st);
    if (copyout(myproc()->pagetable, out, (char *)&st, sizeof(st)) < 0) return -1;
    return 0;
}
uint64 sys_alloc_audit(void) { return alloc_audit(); }
    80203878:	1141                	addi	sp,sp,-16
    8020387a:	e406                	sd	ra,8(sp)
    8020387c:	e022                	sd	s0,0(sp)
    8020387e:	0800                	addi	s0,sp,16
    80203880:	ffffe097          	auipc	ra,0xffffe
    80203884:	b3e080e7          	jalr	-1218(ra) # 802013be <alloc_audit>
    80203888:	60a2                	ld	ra,8(sp)
    8020388a:	6402                	ld	s0,0(sp)
    8020388c:	0141                	addi	sp,sp,16
    8020388e:	8082                	ret

0000000080203890 <sys_logverify>:
    return b0;
}

/* Verify the home blocks hold the recovered pattern (called after reboot). */
uint64 sys_logverify(void)
{
    80203890:	7139                	addi	sp,sp,-64
    80203892:	fc06                	sd	ra,56(sp)
    80203894:	f822                	sd	s0,48(sp)
    80203896:	f426                	sd	s1,40(sp)
    80203898:	f04a                	sd	s2,32(sp)
    8020389a:	ec4e                	sd	s3,24(sp)
    8020389c:	e852                	sd	s4,16(sp)
    8020389e:	e456                	sd	s5,8(sp)
    802038a0:	0080                	addi	s0,sp,64
    int b0 = sb.datastart + sb.ndata - 8;
    802038a2:	00150797          	auipc	a5,0x150
    802038a6:	3c678793          	addi	a5,a5,966 # 80353c68 <sb>
    802038aa:	5398                	lw	a4,32(a5)
    802038ac:	0107aa03          	lw	s4,16(a5)
    802038b0:	00ea0a3b          	addw	s4,s4,a4
    802038b4:	3a61                	addiw	s4,s4,-8
    802038b6:	0c000493          	li	s1,192
    int ok = 1;
    802038ba:	4905                	li	s2,1
    for (int i = 0; i < 3; i++) {
        struct buf *bp = bread(1, b0 + i);
        for (int j = 0; j < BSIZE; j++)
            if (bp->data[j] != (uint8)(0xC0 + i)) ok = 0;
    802038bc:	4981                	li	s3,0
    for (int i = 0; i < 3; i++) {
    802038be:	0c300a93          	li	s5,195
    802038c2:	a025                	j	802038ea <sys_logverify+0x5a>
        for (int j = 0; j < BSIZE; j++)
    802038c4:	0785                	addi	a5,a5,1
    802038c6:	00d78863          	beq	a5,a3,802038d6 <sys_logverify+0x46>
            if (bp->data[j] != (uint8)(0xC0 + i)) ok = 0;
    802038ca:	0007c703          	lbu	a4,0(a5)
    802038ce:	fe970be3          	beq	a4,s1,802038c4 <sys_logverify+0x34>
    802038d2:	894e                	mv	s2,s3
    802038d4:	bfc5                	j	802038c4 <sys_logverify+0x34>
        brelse(bp);
    802038d6:	00003097          	auipc	ra,0x3
    802038da:	0ac080e7          	jalr	172(ra) # 80206982 <brelse>
    for (int i = 0; i < 3; i++) {
    802038de:	2a05                	addiw	s4,s4,1
    802038e0:	2485                	addiw	s1,s1,1
    802038e2:	0ff4f493          	zext.b	s1,s1
    802038e6:	01548d63          	beq	s1,s5,80203900 <sys_logverify+0x70>
        struct buf *bp = bread(1, b0 + i);
    802038ea:	85d2                	mv	a1,s4
    802038ec:	4505                	li	a0,1
    802038ee:	00003097          	auipc	ra,0x3
    802038f2:	f64080e7          	jalr	-156(ra) # 80206852 <bread>
        for (int j = 0; j < BSIZE; j++)
    802038f6:	05850793          	addi	a5,a0,88
    802038fa:	45850693          	addi	a3,a0,1112
    802038fe:	b7f1                	j	802038ca <sys_logverify+0x3a>
    }
    return ok ? 0 : -1;
}
    80203900:	fff90513          	addi	a0,s2,-1
    80203904:	70e2                	ld	ra,56(sp)
    80203906:	7442                	ld	s0,48(sp)
    80203908:	74a2                	ld	s1,40(sp)
    8020390a:	7902                	ld	s2,32(sp)
    8020390c:	69e2                	ld	s3,24(sp)
    8020390e:	6a42                	ld	s4,16(sp)
    80203910:	6aa2                	ld	s5,8(sp)
    80203912:	6121                	addi	sp,sp,64
    80203914:	8082                	ret

0000000080203916 <sys_logtest>:
{
    80203916:	7139                	addi	sp,sp,-64
    80203918:	fc06                	sd	ra,56(sp)
    8020391a:	f822                	sd	s0,48(sp)
    8020391c:	f426                	sd	s1,40(sp)
    8020391e:	f04a                	sd	s2,32(sp)
    80203920:	ec4e                	sd	s3,24(sp)
    80203922:	e852                	sd	s4,16(sp)
    80203924:	e456                	sd	s5,8(sp)
    80203926:	0080                	addi	s0,sp,64
    int b0 = sb.datastart + sb.ndata - 8;
    80203928:	00150797          	auipc	a5,0x150
    8020392c:	34078793          	addi	a5,a5,832 # 80353c68 <sb>
    80203930:	5398                	lw	a4,32(a5)
    80203932:	0107a983          	lw	s3,16(a5)
    80203936:	00e989bb          	addw	s3,s3,a4
    8020393a:	39e1                	addiw	s3,s3,-8 # ff8 <_entry-0x801ff008>
    begin_op();
    8020393c:	00002097          	auipc	ra,0x2
    80203940:	2b8080e7          	jalr	696(ra) # 80205bf4 <begin_op>
    80203944:	8a4e                	mv	s4,s3
    80203946:	0a000493          	li	s1,160
    for (int i = 0; i < 3; i++) {
    8020394a:	0a300a93          	li	s5,163
        struct buf *bp = bread(1, b0 + i);
    8020394e:	85d2                	mv	a1,s4
    80203950:	4505                	li	a0,1
    80203952:	00003097          	auipc	ra,0x3
    80203956:	f00080e7          	jalr	-256(ra) # 80206852 <bread>
    8020395a:	892a                	mv	s2,a0
        for (int j = 0; j < BSIZE; j++) bp->data[j] = (uint8)(0xA0 + i);
    8020395c:	05850793          	addi	a5,a0,88
    80203960:	45850713          	addi	a4,a0,1112
    80203964:	00978023          	sb	s1,0(a5)
    80203968:	0785                	addi	a5,a5,1
    8020396a:	fee79de3          	bne	a5,a4,80203964 <sys_logtest+0x4e>
        log_write(bp);
    8020396e:	854a                	mv	a0,s2
    80203970:	00002097          	auipc	ra,0x2
    80203974:	3ac080e7          	jalr	940(ra) # 80205d1c <log_write>
        brelse(bp);
    80203978:	854a                	mv	a0,s2
    8020397a:	00003097          	auipc	ra,0x3
    8020397e:	008080e7          	jalr	8(ra) # 80206982 <brelse>
    for (int i = 0; i < 3; i++) {
    80203982:	2a05                	addiw	s4,s4,1
    80203984:	2485                	addiw	s1,s1,1
    80203986:	0ff4f493          	zext.b	s1,s1
    8020398a:	fd5492e3          	bne	s1,s5,8020394e <sys_logtest+0x38>
    end_op();                      /* commits + installs */
    8020398e:	00002097          	auipc	ra,0x2
    80203992:	2ca080e7          	jalr	714(ra) # 80205c58 <end_op>
    80203996:	0a000493          	li	s1,160
    int ok = 1;
    8020399a:	4905                	li	s2,1
            if (bp->data[j] != (uint8)(0xA0 + i)) ok = 0;
    8020399c:	4a01                	li	s4,0
    for (int i = 0; i < 3; i++) {
    8020399e:	0a300a93          	li	s5,163
    802039a2:	a025                	j	802039ca <sys_logtest+0xb4>
        for (int j = 0; j < BSIZE; j++)
    802039a4:	0785                	addi	a5,a5,1
    802039a6:	00d78863          	beq	a5,a3,802039b6 <sys_logtest+0xa0>
            if (bp->data[j] != (uint8)(0xA0 + i)) ok = 0;
    802039aa:	0007c703          	lbu	a4,0(a5)
    802039ae:	fe970be3          	beq	a4,s1,802039a4 <sys_logtest+0x8e>
    802039b2:	8952                	mv	s2,s4
    802039b4:	bfc5                	j	802039a4 <sys_logtest+0x8e>
        brelse(bp);
    802039b6:	00003097          	auipc	ra,0x3
    802039ba:	fcc080e7          	jalr	-52(ra) # 80206982 <brelse>
    for (int i = 0; i < 3; i++) {
    802039be:	2985                	addiw	s3,s3,1
    802039c0:	2485                	addiw	s1,s1,1
    802039c2:	0ff4f493          	zext.b	s1,s1
    802039c6:	01548d63          	beq	s1,s5,802039e0 <sys_logtest+0xca>
        struct buf *bp = bread(1, b0 + i);
    802039ca:	85ce                	mv	a1,s3
    802039cc:	4505                	li	a0,1
    802039ce:	00003097          	auipc	ra,0x3
    802039d2:	e84080e7          	jalr	-380(ra) # 80206852 <bread>
        for (int j = 0; j < BSIZE; j++)
    802039d6:	05850793          	addi	a5,a0,88
    802039da:	45850693          	addi	a3,a0,1112
    802039de:	b7f1                	j	802039aa <sys_logtest+0x94>
}
    802039e0:	fff90513          	addi	a0,s2,-1
    802039e4:	70e2                	ld	ra,56(sp)
    802039e6:	7442                	ld	s0,48(sp)
    802039e8:	74a2                	ld	s1,40(sp)
    802039ea:	7902                	ld	s2,32(sp)
    802039ec:	69e2                	ld	s3,24(sp)
    802039ee:	6a42                	ld	s4,16(sp)
    802039f0:	6aa2                	ld	s5,8(sp)
    802039f2:	6121                	addi	sp,sp,64
    802039f4:	8082                	ret

00000000802039f6 <sys_logcrash>:
{
    802039f6:	7139                	addi	sp,sp,-64
    802039f8:	fc06                	sd	ra,56(sp)
    802039fa:	f822                	sd	s0,48(sp)
    802039fc:	f426                	sd	s1,40(sp)
    802039fe:	f04a                	sd	s2,32(sp)
    80203a00:	ec4e                	sd	s3,24(sp)
    80203a02:	e852                	sd	s4,16(sp)
    80203a04:	e456                	sd	s5,8(sp)
    80203a06:	0080                	addi	s0,sp,64
    int b0 = sb.datastart + sb.ndata - 8;
    80203a08:	00150797          	auipc	a5,0x150
    80203a0c:	26078793          	addi	a5,a5,608 # 80353c68 <sb>
    80203a10:	5398                	lw	a4,32(a5)
    80203a12:	0107aa83          	lw	s5,16(a5)
    80203a16:	00ea8abb          	addw	s5,s5,a4
    80203a1a:	ff8a8a1b          	addiw	s4,s5,-8 # ffffffffffffeff8 <uart+0xffffffff7fca4fc8>
    80203a1e:	000a099b          	sext.w	s3,s4
    80203a22:	8a4e                	mv	s4,s3
    for (int i = 0; i < 3; i++) {
    80203a24:	3aed                	addiw	s5,s5,-5
    int b0 = sb.datastart + sb.ndata - 8;
    80203a26:	894e                	mv	s2,s3
        struct buf *bp = bread(1, b0 + i);
    80203a28:	85ca                	mv	a1,s2
    80203a2a:	4505                	li	a0,1
    80203a2c:	00003097          	auipc	ra,0x3
    80203a30:	e26080e7          	jalr	-474(ra) # 80206852 <bread>
    80203a34:	84aa                	mv	s1,a0
        memset(bp->data, 0, BSIZE);
    80203a36:	40000613          	li	a2,1024
    80203a3a:	4581                	li	a1,0
    80203a3c:	05850513          	addi	a0,a0,88
    80203a40:	ffffd097          	auipc	ra,0xffffd
    80203a44:	c7c080e7          	jalr	-900(ra) # 802006bc <memset>
        bwrite(bp);
    80203a48:	8526                	mv	a0,s1
    80203a4a:	00003097          	auipc	ra,0x3
    80203a4e:	efa080e7          	jalr	-262(ra) # 80206944 <bwrite>
        brelse(bp);
    80203a52:	8526                	mv	a0,s1
    80203a54:	00003097          	auipc	ra,0x3
    80203a58:	f2e080e7          	jalr	-210(ra) # 80206982 <brelse>
    for (int i = 0; i < 3; i++) {
    80203a5c:	2905                	addiw	s2,s2,1
    80203a5e:	fd5915e3          	bne	s2,s5,80203a28 <sys_logcrash+0x32>
    begin_op();
    80203a62:	00002097          	auipc	ra,0x2
    80203a66:	192080e7          	jalr	402(ra) # 80205bf4 <begin_op>
    80203a6a:	0c000493          	li	s1,192
    for (int i = 0; i < 3; i++) {
    80203a6e:	0c300a93          	li	s5,195
        struct buf *bp = bread(1, b0 + i);
    80203a72:	85ce                	mv	a1,s3
    80203a74:	4505                	li	a0,1
    80203a76:	00003097          	auipc	ra,0x3
    80203a7a:	ddc080e7          	jalr	-548(ra) # 80206852 <bread>
    80203a7e:	892a                	mv	s2,a0
        for (int j = 0; j < BSIZE; j++) bp->data[j] = (uint8)(0xC0 + i);
    80203a80:	05850793          	addi	a5,a0,88
    80203a84:	45850713          	addi	a4,a0,1112
    80203a88:	00978023          	sb	s1,0(a5)
    80203a8c:	0785                	addi	a5,a5,1
    80203a8e:	fee79de3          	bne	a5,a4,80203a88 <sys_logcrash+0x92>
        log_write(bp);
    80203a92:	854a                	mv	a0,s2
    80203a94:	00002097          	auipc	ra,0x2
    80203a98:	288080e7          	jalr	648(ra) # 80205d1c <log_write>
        brelse(bp);
    80203a9c:	854a                	mv	a0,s2
    80203a9e:	00003097          	auipc	ra,0x3
    80203aa2:	ee4080e7          	jalr	-284(ra) # 80206982 <brelse>
    for (int i = 0; i < 3; i++) {
    80203aa6:	2985                	addiw	s3,s3,1
    80203aa8:	2485                	addiw	s1,s1,1
    80203aaa:	0ff4f493          	zext.b	s1,s1
    80203aae:	fd5492e3          	bne	s1,s5,80203a72 <sys_logcrash+0x7c>
    log_commit_only();          /* write log + header, then STOP (no install) */
    80203ab2:	00002097          	auipc	ra,0x2
    80203ab6:	24a080e7          	jalr	586(ra) # 80205cfc <log_commit_only>
}
    80203aba:	8552                	mv	a0,s4
    80203abc:	70e2                	ld	ra,56(sp)
    80203abe:	7442                	ld	s0,48(sp)
    80203ac0:	74a2                	ld	s1,40(sp)
    80203ac2:	7902                	ld	s2,32(sp)
    80203ac4:	69e2                	ld	s3,24(sp)
    80203ac6:	6a42                	ld	s4,16(sp)
    80203ac8:	6aa2                	ld	s5,8(sp)
    80203aca:	6121                	addi	sp,sp,64
    80203acc:	8082                	ret

0000000080203ace <sys_fsck>:

/* Lab 9: filesystem consistency check. */
uint64 sys_fsck(void) { return fsck(1); }
    80203ace:	1141                	addi	sp,sp,-16
    80203ad0:	e406                	sd	ra,8(sp)
    80203ad2:	e022                	sd	s0,0(sp)
    80203ad4:	0800                	addi	s0,sp,16
    80203ad6:	4505                	li	a0,1
    80203ad8:	00002097          	auipc	ra,0x2
    80203adc:	338080e7          	jalr	824(ra) # 80205e10 <fsck>
    80203ae0:	60a2                	ld	ra,8(sp)
    80203ae2:	6402                	ld	s0,0(sp)
    80203ae4:	0141                	addi	sp,sp,16
    80203ae6:	8082                	ret

0000000080203ae8 <argint>:
int argint(int n, int *ip)     { *ip = (int)argraw(n); return 0; }
    80203ae8:	1101                	addi	sp,sp,-32
    80203aea:	ec06                	sd	ra,24(sp)
    80203aec:	e822                	sd	s0,16(sp)
    80203aee:	e426                	sd	s1,8(sp)
    80203af0:	1000                	addi	s0,sp,32
    80203af2:	84ae                	mv	s1,a1
    80203af4:	00000097          	auipc	ra,0x0
    80203af8:	c94080e7          	jalr	-876(ra) # 80203788 <argraw>
    80203afc:	c088                	sw	a0,0(s1)
    80203afe:	4501                	li	a0,0
    80203b00:	60e2                	ld	ra,24(sp)
    80203b02:	6442                	ld	s0,16(sp)
    80203b04:	64a2                	ld	s1,8(sp)
    80203b06:	6105                	addi	sp,sp,32
    80203b08:	8082                	ret

0000000080203b0a <sys_exit>:
{
    80203b0a:	1101                	addi	sp,sp,-32
    80203b0c:	ec06                	sd	ra,24(sp)
    80203b0e:	e822                	sd	s0,16(sp)
    80203b10:	1000                	addi	s0,sp,32
    int n; argint(0, &n);
    80203b12:	fec40593          	addi	a1,s0,-20
    80203b16:	4501                	li	a0,0
    80203b18:	00000097          	auipc	ra,0x0
    80203b1c:	fd0080e7          	jalr	-48(ra) # 80203ae8 <argint>
    exit(n);
    80203b20:	fec42503          	lw	a0,-20(s0)
    80203b24:	ffffe097          	auipc	ra,0xffffe
    80203b28:	7be080e7          	jalr	1982(ra) # 802022e2 <exit>

0000000080203b2c <sys_sbrk>:
{
    80203b2c:	7179                	addi	sp,sp,-48
    80203b2e:	f406                	sd	ra,40(sp)
    80203b30:	f022                	sd	s0,32(sp)
    80203b32:	ec26                	sd	s1,24(sp)
    80203b34:	1800                	addi	s0,sp,48
    int n; argint(0, &n);
    80203b36:	fdc40593          	addi	a1,s0,-36
    80203b3a:	4501                	li	a0,0
    80203b3c:	00000097          	auipc	ra,0x0
    80203b40:	fac080e7          	jalr	-84(ra) # 80203ae8 <argint>
    uint64 addr = myproc()->sz;
    80203b44:	ffffe097          	auipc	ra,0xffffe
    80203b48:	dac080e7          	jalr	-596(ra) # 802018f0 <myproc>
    80203b4c:	6524                	ld	s1,72(a0)
    if (growproc(n) < 0) return -1;
    80203b4e:	fdc42503          	lw	a0,-36(s0)
    80203b52:	ffffe097          	auipc	ra,0xffffe
    80203b56:	fde080e7          	jalr	-34(ra) # 80201b30 <growproc>
    80203b5a:	00054863          	bltz	a0,80203b6a <sys_sbrk+0x3e>
}
    80203b5e:	8526                	mv	a0,s1
    80203b60:	70a2                	ld	ra,40(sp)
    80203b62:	7402                	ld	s0,32(sp)
    80203b64:	64e2                	ld	s1,24(sp)
    80203b66:	6145                	addi	sp,sp,48
    80203b68:	8082                	ret
    if (growproc(n) < 0) return -1;
    80203b6a:	54fd                	li	s1,-1
    80203b6c:	bfcd                	j	80203b5e <sys_sbrk+0x32>

0000000080203b6e <sys_sleep>:
{
    80203b6e:	7139                	addi	sp,sp,-64
    80203b70:	fc06                	sd	ra,56(sp)
    80203b72:	f822                	sd	s0,48(sp)
    80203b74:	f04a                	sd	s2,32(sp)
    80203b76:	ec4e                	sd	s3,24(sp)
    80203b78:	0080                	addi	s0,sp,64
    int n; argint(0, &n);
    80203b7a:	fcc40593          	addi	a1,s0,-52
    80203b7e:	4501                	li	a0,0
    80203b80:	00000097          	auipc	ra,0x0
    80203b84:	f68080e7          	jalr	-152(ra) # 80203ae8 <argint>
    acquire(&tickslock);
    80203b88:	00131517          	auipc	a0,0x131
    80203b8c:	47850513          	addi	a0,a0,1144 # 80335000 <tickslock>
    80203b90:	ffffe097          	auipc	ra,0xffffe
    80203b94:	8f8080e7          	jalr	-1800(ra) # 80201488 <acquire>
    uint64 t0 = ticks;
    80203b98:	00156997          	auipc	s3,0x156
    80203b9c:	4809b983          	ld	s3,1152(s3) # 8035a018 <ticks>
    while (ticks - t0 < (uint64)n) {
    80203ba0:	fcc42903          	lw	s2,-52(s0)
    80203ba4:	02090f63          	beqz	s2,80203be2 <sys_sleep+0x74>
    80203ba8:	f426                	sd	s1,40(sp)
    80203baa:	e852                	sd	s4,16(sp)
        sleep(&ticks, &tickslock);
    80203bac:	00131a17          	auipc	s4,0x131
    80203bb0:	454a0a13          	addi	s4,s4,1108 # 80335000 <tickslock>
    80203bb4:	00156497          	auipc	s1,0x156
    80203bb8:	46448493          	addi	s1,s1,1124 # 8035a018 <ticks>
        if (myproc()->killed) { release(&tickslock); return -1; }
    80203bbc:	ffffe097          	auipc	ra,0xffffe
    80203bc0:	d34080e7          	jalr	-716(ra) # 802018f0 <myproc>
    80203bc4:	551c                	lw	a5,40(a0)
    80203bc6:	ef8d                	bnez	a5,80203c00 <sys_sleep+0x92>
        sleep(&ticks, &tickslock);
    80203bc8:	85d2                	mv	a1,s4
    80203bca:	8526                	mv	a0,s1
    80203bcc:	ffffe097          	auipc	ra,0xffffe
    80203bd0:	51a080e7          	jalr	1306(ra) # 802020e6 <sleep>
    while (ticks - t0 < (uint64)n) {
    80203bd4:	609c                	ld	a5,0(s1)
    80203bd6:	413787b3          	sub	a5,a5,s3
    80203bda:	ff27e1e3          	bltu	a5,s2,80203bbc <sys_sleep+0x4e>
    80203bde:	74a2                	ld	s1,40(sp)
    80203be0:	6a42                	ld	s4,16(sp)
    release(&tickslock);
    80203be2:	00131517          	auipc	a0,0x131
    80203be6:	41e50513          	addi	a0,a0,1054 # 80335000 <tickslock>
    80203bea:	ffffe097          	auipc	ra,0xffffe
    80203bee:	952080e7          	jalr	-1710(ra) # 8020153c <release>
    return 0;
    80203bf2:	4501                	li	a0,0
}
    80203bf4:	70e2                	ld	ra,56(sp)
    80203bf6:	7442                	ld	s0,48(sp)
    80203bf8:	7902                	ld	s2,32(sp)
    80203bfa:	69e2                	ld	s3,24(sp)
    80203bfc:	6121                	addi	sp,sp,64
    80203bfe:	8082                	ret
        if (myproc()->killed) { release(&tickslock); return -1; }
    80203c00:	00131517          	auipc	a0,0x131
    80203c04:	40050513          	addi	a0,a0,1024 # 80335000 <tickslock>
    80203c08:	ffffe097          	auipc	ra,0xffffe
    80203c0c:	934080e7          	jalr	-1740(ra) # 8020153c <release>
    80203c10:	557d                	li	a0,-1
    80203c12:	74a2                	ld	s1,40(sp)
    80203c14:	6a42                	ld	s4,16(sp)
    80203c16:	bff9                	j	80203bf4 <sys_sleep+0x86>

0000000080203c18 <sys_kill>:
{
    80203c18:	1101                	addi	sp,sp,-32
    80203c1a:	ec06                	sd	ra,24(sp)
    80203c1c:	e822                	sd	s0,16(sp)
    80203c1e:	1000                	addi	s0,sp,32
    int pid; argint(0, &pid);
    80203c20:	fec40593          	addi	a1,s0,-20
    80203c24:	4501                	li	a0,0
    80203c26:	00000097          	auipc	ra,0x0
    80203c2a:	ec2080e7          	jalr	-318(ra) # 80203ae8 <argint>
    return kill(pid);
    80203c2e:	fec42503          	lw	a0,-20(s0)
    80203c32:	ffffe097          	auipc	ra,0xffffe
    80203c36:	7b8080e7          	jalr	1976(ra) # 802023ea <kill>
}
    80203c3a:	60e2                	ld	ra,24(sp)
    80203c3c:	6442                	ld	s0,16(sp)
    80203c3e:	6105                	addi	sp,sp,32
    80203c40:	8082                	ret

0000000080203c42 <argaddr>:
int argaddr(int n, uint64 *ap) { *ap = argraw(n); return 0; }
    80203c42:	1101                	addi	sp,sp,-32
    80203c44:	ec06                	sd	ra,24(sp)
    80203c46:	e822                	sd	s0,16(sp)
    80203c48:	e426                	sd	s1,8(sp)
    80203c4a:	1000                	addi	s0,sp,32
    80203c4c:	84ae                	mv	s1,a1
    80203c4e:	00000097          	auipc	ra,0x0
    80203c52:	b3a080e7          	jalr	-1222(ra) # 80203788 <argraw>
    80203c56:	e088                	sd	a0,0(s1)
    80203c58:	4501                	li	a0,0
    80203c5a:	60e2                	ld	ra,24(sp)
    80203c5c:	6442                	ld	s0,16(sp)
    80203c5e:	64a2                	ld	s1,8(sp)
    80203c60:	6105                	addi	sp,sp,32
    80203c62:	8082                	ret

0000000080203c64 <sys_wait>:
{
    80203c64:	1101                	addi	sp,sp,-32
    80203c66:	ec06                	sd	ra,24(sp)
    80203c68:	e822                	sd	s0,16(sp)
    80203c6a:	1000                	addi	s0,sp,32
    uint64 p; argaddr(0, &p);
    80203c6c:	fe840593          	addi	a1,s0,-24
    80203c70:	4501                	li	a0,0
    80203c72:	00000097          	auipc	ra,0x0
    80203c76:	fd0080e7          	jalr	-48(ra) # 80203c42 <argaddr>
    return wait(p);
    80203c7a:	fe843503          	ld	a0,-24(s0)
    80203c7e:	ffffe097          	auipc	ra,0xffffe
    80203c82:	4cc080e7          	jalr	1228(ra) # 8020214a <wait>
}
    80203c86:	60e2                	ld	ra,24(sp)
    80203c88:	6442                	ld	s0,16(sp)
    80203c8a:	6105                	addi	sp,sp,32
    80203c8c:	8082                	ret

0000000080203c8e <sys_procstat>:
{
    80203c8e:	1101                	addi	sp,sp,-32
    80203c90:	ec06                	sd	ra,24(sp)
    80203c92:	e822                	sd	s0,16(sp)
    80203c94:	1000                	addi	s0,sp,32
    argaddr(0, &uaddr);
    80203c96:	fe840593          	addi	a1,s0,-24
    80203c9a:	4501                	li	a0,0
    80203c9c:	00000097          	auipc	ra,0x0
    80203ca0:	fa6080e7          	jalr	-90(ra) # 80203c42 <argaddr>
    argint(1, &max);
    80203ca4:	fe440593          	addi	a1,s0,-28
    80203ca8:	4505                	li	a0,1
    80203caa:	00000097          	auipc	ra,0x0
    80203cae:	e3e080e7          	jalr	-450(ra) # 80203ae8 <argint>
    if (max <= 0) return -1;
    80203cb2:	fe442783          	lw	a5,-28(s0)
    80203cb6:	02f05663          	blez	a5,80203ce2 <sys_procstat+0x54>
    if (max > NPROC) max = NPROC;
    80203cba:	04000713          	li	a4,64
    80203cbe:	00f75663          	bge	a4,a5,80203cca <sys_procstat+0x3c>
    80203cc2:	04000793          	li	a5,64
    80203cc6:	fef42223          	sw	a5,-28(s0)
    return procstat(uaddr, max);
    80203cca:	fe442583          	lw	a1,-28(s0)
    80203cce:	fe843503          	ld	a0,-24(s0)
    80203cd2:	fffff097          	auipc	ra,0xfffff
    80203cd6:	856080e7          	jalr	-1962(ra) # 80202528 <procstat>
}
    80203cda:	60e2                	ld	ra,24(sp)
    80203cdc:	6442                	ld	s0,16(sp)
    80203cde:	6105                	addi	sp,sp,32
    80203ce0:	8082                	ret
    if (max <= 0) return -1;
    80203ce2:	557d                	li	a0,-1
    80203ce4:	bfdd                	j	80203cda <sys_procstat+0x4c>

0000000080203ce6 <sys_tracectl>:
uint64 sys_tracectl(void) { int a; uint64 f; argint(0,&a); argaddr(1,&f); return trace_ctl(a,f); }
    80203ce6:	1101                	addi	sp,sp,-32
    80203ce8:	ec06                	sd	ra,24(sp)
    80203cea:	e822                	sd	s0,16(sp)
    80203cec:	1000                	addi	s0,sp,32
    80203cee:	fec40593          	addi	a1,s0,-20
    80203cf2:	4501                	li	a0,0
    80203cf4:	00000097          	auipc	ra,0x0
    80203cf8:	df4080e7          	jalr	-524(ra) # 80203ae8 <argint>
    80203cfc:	fe040593          	addi	a1,s0,-32
    80203d00:	4505                	li	a0,1
    80203d02:	00000097          	auipc	ra,0x0
    80203d06:	f40080e7          	jalr	-192(ra) # 80203c42 <argaddr>
    80203d0a:	fe043583          	ld	a1,-32(s0)
    80203d0e:	fec42503          	lw	a0,-20(s0)
    80203d12:	00001097          	auipc	ra,0x1
    80203d16:	37e080e7          	jalr	894(ra) # 80205090 <trace_ctl>
    80203d1a:	60e2                	ld	ra,24(sp)
    80203d1c:	6442                	ld	s0,16(sp)
    80203d1e:	6105                	addi	sp,sp,32
    80203d20:	8082                	ret

0000000080203d22 <sys_traceread>:
uint64 sys_traceread(void){ uint64 b; int m; argaddr(0,&b); argint(1,&m); return trace_read(b,m); }
    80203d22:	1101                	addi	sp,sp,-32
    80203d24:	ec06                	sd	ra,24(sp)
    80203d26:	e822                	sd	s0,16(sp)
    80203d28:	1000                	addi	s0,sp,32
    80203d2a:	fe840593          	addi	a1,s0,-24
    80203d2e:	4501                	li	a0,0
    80203d30:	00000097          	auipc	ra,0x0
    80203d34:	f12080e7          	jalr	-238(ra) # 80203c42 <argaddr>
    80203d38:	fe440593          	addi	a1,s0,-28
    80203d3c:	4505                	li	a0,1
    80203d3e:	00000097          	auipc	ra,0x0
    80203d42:	daa080e7          	jalr	-598(ra) # 80203ae8 <argint>
    80203d46:	fe442583          	lw	a1,-28(s0)
    80203d4a:	fe843503          	ld	a0,-24(s0)
    80203d4e:	00001097          	auipc	ra,0x1
    80203d52:	350080e7          	jalr	848(ra) # 8020509e <trace_read>
    80203d56:	60e2                	ld	ra,24(sp)
    80203d58:	6442                	ld	s0,16(sp)
    80203d5a:	6105                	addi	sp,sp,32
    80203d5c:	8082                	ret

0000000080203d5e <sys_pgrefstat>:
{
    80203d5e:	7139                	addi	sp,sp,-64
    80203d60:	fc06                	sd	ra,56(sp)
    80203d62:	f822                	sd	s0,48(sp)
    80203d64:	f426                	sd	s1,40(sp)
    80203d66:	0080                	addi	s0,sp,64
    argaddr(0, &va);
    80203d68:	fd840593          	addi	a1,s0,-40
    80203d6c:	4501                	li	a0,0
    80203d6e:	00000097          	auipc	ra,0x0
    80203d72:	ed4080e7          	jalr	-300(ra) # 80203c42 <argaddr>
    argaddr(1, &out);
    80203d76:	fd040593          	addi	a1,s0,-48
    80203d7a:	4505                	li	a0,1
    80203d7c:	00000097          	auipc	ra,0x0
    80203d80:	ec6080e7          	jalr	-314(ra) # 80203c42 <argaddr>
    struct proc *p = myproc();
    80203d84:	ffffe097          	auipc	ra,0xffffe
    80203d88:	b6c080e7          	jalr	-1172(ra) # 802018f0 <myproc>
    80203d8c:	84aa                	mv	s1,a0
    if (pgrefstat(p->pagetable, va, &r) < 0)
    80203d8e:	fc040613          	addi	a2,s0,-64
    80203d92:	fd843583          	ld	a1,-40(s0)
    80203d96:	6928                	ld	a0,80(a0)
    80203d98:	00001097          	auipc	ra,0x1
    80203d9c:	402080e7          	jalr	1026(ra) # 8020519a <pgrefstat>
    80203da0:	87aa                	mv	a5,a0
        return -1;
    80203da2:	557d                	li	a0,-1
    if (pgrefstat(p->pagetable, va, &r) < 0)
    80203da4:	0007cd63          	bltz	a5,80203dbe <sys_pgrefstat+0x60>
    if (copyout(p->pagetable, out, (char *)&r, sizeof(r)) < 0)
    80203da8:	46b1                	li	a3,12
    80203daa:	fc040613          	addi	a2,s0,-64
    80203dae:	fd043583          	ld	a1,-48(s0)
    80203db2:	68a8                	ld	a0,80(s1)
    80203db4:	fffff097          	auipc	ra,0xfffff
    80203db8:	6a6080e7          	jalr	1702(ra) # 8020345a <copyout>
    80203dbc:	957d                	srai	a0,a0,0x3f
}
    80203dbe:	70e2                	ld	ra,56(sp)
    80203dc0:	7442                	ld	s0,48(sp)
    80203dc2:	74a2                	ld	s1,40(sp)
    80203dc4:	6121                	addi	sp,sp,64
    80203dc6:	8082                	ret

0000000080203dc8 <sys_clone>:
{
    80203dc8:	7179                	addi	sp,sp,-48
    80203dca:	f406                	sd	ra,40(sp)
    80203dcc:	f022                	sd	s0,32(sp)
    80203dce:	1800                	addi	s0,sp,48
    argaddr(0, &fn);
    80203dd0:	fe840593          	addi	a1,s0,-24
    80203dd4:	4501                	li	a0,0
    80203dd6:	00000097          	auipc	ra,0x0
    80203dda:	e6c080e7          	jalr	-404(ra) # 80203c42 <argaddr>
    argaddr(1, &arg);
    80203dde:	fe040593          	addi	a1,s0,-32
    80203de2:	4505                	li	a0,1
    80203de4:	00000097          	auipc	ra,0x0
    80203de8:	e5e080e7          	jalr	-418(ra) # 80203c42 <argaddr>
    argaddr(2, &stack);
    80203dec:	fd840593          	addi	a1,s0,-40
    80203df0:	4509                	li	a0,2
    80203df2:	00000097          	auipc	ra,0x0
    80203df6:	e50080e7          	jalr	-432(ra) # 80203c42 <argaddr>
    return clone(fn, arg, stack);
    80203dfa:	fd843603          	ld	a2,-40(s0)
    80203dfe:	fe043583          	ld	a1,-32(s0)
    80203e02:	fe843503          	ld	a0,-24(s0)
    80203e06:	ffffe097          	auipc	ra,0xffffe
    80203e0a:	f62080e7          	jalr	-158(ra) # 80201d68 <clone>
}
    80203e0e:	70a2                	ld	ra,40(sp)
    80203e10:	7402                	ld	s0,32(sp)
    80203e12:	6145                	addi	sp,sp,48
    80203e14:	8082                	ret

0000000080203e16 <sys_futex>:
{
    80203e16:	7179                	addi	sp,sp,-48
    80203e18:	f406                	sd	ra,40(sp)
    80203e1a:	f022                	sd	s0,32(sp)
    80203e1c:	1800                	addi	s0,sp,48
    argaddr(0, &uaddr);
    80203e1e:	fe840593          	addi	a1,s0,-24
    80203e22:	4501                	li	a0,0
    80203e24:	00000097          	auipc	ra,0x0
    80203e28:	e1e080e7          	jalr	-482(ra) # 80203c42 <argaddr>
    argint(1, &op);
    80203e2c:	fdc40593          	addi	a1,s0,-36
    80203e30:	4505                	li	a0,1
    80203e32:	00000097          	auipc	ra,0x0
    80203e36:	cb6080e7          	jalr	-842(ra) # 80203ae8 <argint>
    argaddr(2, &val);
    80203e3a:	fe040593          	addi	a1,s0,-32
    80203e3e:	4509                	li	a0,2
    80203e40:	00000097          	auipc	ra,0x0
    80203e44:	e02080e7          	jalr	-510(ra) # 80203c42 <argaddr>
    argint(3, &n);
    80203e48:	fd840593          	addi	a1,s0,-40
    80203e4c:	450d                	li	a0,3
    80203e4e:	00000097          	auipc	ra,0x0
    80203e52:	c9a080e7          	jalr	-870(ra) # 80203ae8 <argint>
    if (op == FUTEX_WAIT) return futex_wait(uaddr, val);
    80203e56:	fdc42783          	lw	a5,-36(s0)
    80203e5a:	cb89                	beqz	a5,80203e6c <sys_futex+0x56>
    if (op == FUTEX_WAKE) return futex_wake(uaddr, n);
    80203e5c:	4705                	li	a4,1
    return -1;
    80203e5e:	557d                	li	a0,-1
    if (op == FUTEX_WAKE) return futex_wake(uaddr, n);
    80203e60:	00e78f63          	beq	a5,a4,80203e7e <sys_futex+0x68>
}
    80203e64:	70a2                	ld	ra,40(sp)
    80203e66:	7402                	ld	s0,32(sp)
    80203e68:	6145                	addi	sp,sp,48
    80203e6a:	8082                	ret
    if (op == FUTEX_WAIT) return futex_wait(uaddr, val);
    80203e6c:	fe043583          	ld	a1,-32(s0)
    80203e70:	fe843503          	ld	a0,-24(s0)
    80203e74:	00001097          	auipc	ra,0x1
    80203e78:	476080e7          	jalr	1142(ra) # 802052ea <futex_wait>
    80203e7c:	b7e5                	j	80203e64 <sys_futex+0x4e>
    if (op == FUTEX_WAKE) return futex_wake(uaddr, n);
    80203e7e:	fd842583          	lw	a1,-40(s0)
    80203e82:	fe843503          	ld	a0,-24(s0)
    80203e86:	00001097          	auipc	ra,0x1
    80203e8a:	512080e7          	jalr	1298(ra) # 80205398 <futex_wake>
    80203e8e:	bfd9                	j	80203e64 <sys_futex+0x4e>

0000000080203e90 <sys_sigalarm>:
{
    80203e90:	1101                	addi	sp,sp,-32
    80203e92:	ec06                	sd	ra,24(sp)
    80203e94:	e822                	sd	s0,16(sp)
    80203e96:	1000                	addi	s0,sp,32
    argint(0, &interval);
    80203e98:	fec40593          	addi	a1,s0,-20
    80203e9c:	4501                	li	a0,0
    80203e9e:	00000097          	auipc	ra,0x0
    80203ea2:	c4a080e7          	jalr	-950(ra) # 80203ae8 <argint>
    argaddr(1, &handler);
    80203ea6:	fe040593          	addi	a1,s0,-32
    80203eaa:	4505                	li	a0,1
    80203eac:	00000097          	auipc	ra,0x0
    80203eb0:	d96080e7          	jalr	-618(ra) # 80203c42 <argaddr>
    struct proc *p = myproc();
    80203eb4:	ffffe097          	auipc	ra,0xffffe
    80203eb8:	a3c080e7          	jalr	-1476(ra) # 802018f0 <myproc>
    p->alarm_interval = interval;
    80203ebc:	fec42783          	lw	a5,-20(s0)
    80203ec0:	18f53c23          	sd	a5,408(a0)
    p->alarm_handler = handler;
    80203ec4:	fe043783          	ld	a5,-32(s0)
    80203ec8:	1af53023          	sd	a5,416(a0)
    p->alarm_ticks = 0;
    80203ecc:	1a052823          	sw	zero,432(a0)
}
    80203ed0:	4501                	li	a0,0
    80203ed2:	60e2                	ld	ra,24(sp)
    80203ed4:	6442                	ld	s0,16(sp)
    80203ed6:	6105                	addi	sp,sp,32
    80203ed8:	8082                	ret

0000000080203eda <sys_event_stack>:
{
    80203eda:	7179                	addi	sp,sp,-48
    80203edc:	f406                	sd	ra,40(sp)
    80203ede:	f022                	sd	s0,32(sp)
    80203ee0:	ec26                	sd	s1,24(sp)
    80203ee2:	e84a                	sd	s2,16(sp)
    80203ee4:	1800                	addi	s0,sp,48
    argaddr(0, &sp);
    80203ee6:	fd840593          	addi	a1,s0,-40
    80203eea:	4501                	li	a0,0
    80203eec:	00000097          	auipc	ra,0x0
    80203ef0:	d56080e7          	jalr	-682(ra) # 80203c42 <argaddr>
    argint(1, &size);
    80203ef4:	fd440593          	addi	a1,s0,-44
    80203ef8:	4505                	li	a0,1
    80203efa:	00000097          	auipc	ra,0x0
    80203efe:	bee080e7          	jalr	-1042(ra) # 80203ae8 <argint>
    struct proc *p = myproc();
    80203f02:	ffffe097          	auipc	ra,0xffffe
    80203f06:	9ee080e7          	jalr	-1554(ra) # 802018f0 <myproc>
    80203f0a:	84aa                	mv	s1,a0
    if (sp && walkaddr(p->pagetable, PGROUNDDOWN(sp)) == 0) return -1;
    80203f0c:	fd843903          	ld	s2,-40(s0)
    80203f10:	00091b63          	bnez	s2,80203f26 <sys_event_stack+0x4c>
    p->alarm_altstack = sp ? (sp + size) : 0;   /* top of the alt stack */
    80203f14:	1b24b423          	sd	s2,424(s1)
    return 0;
    80203f18:	4501                	li	a0,0
}
    80203f1a:	70a2                	ld	ra,40(sp)
    80203f1c:	7402                	ld	s0,32(sp)
    80203f1e:	64e2                	ld	s1,24(sp)
    80203f20:	6942                	ld	s2,16(sp)
    80203f22:	6145                	addi	sp,sp,48
    80203f24:	8082                	ret
    if (sp && walkaddr(p->pagetable, PGROUNDDOWN(sp)) == 0) return -1;
    80203f26:	75fd                	lui	a1,0xfffff
    80203f28:	00b975b3          	and	a1,s2,a1
    80203f2c:	6928                	ld	a0,80(a0)
    80203f2e:	fffff097          	auipc	ra,0xfffff
    80203f32:	046080e7          	jalr	70(ra) # 80202f74 <walkaddr>
    80203f36:	87aa                	mv	a5,a0
    80203f38:	557d                	li	a0,-1
    80203f3a:	d3e5                	beqz	a5,80203f1a <sys_event_stack+0x40>
    p->alarm_altstack = sp ? (sp + size) : 0;   /* top of the alt stack */
    80203f3c:	fd442783          	lw	a5,-44(s0)
    80203f40:	993e                	add	s2,s2,a5
    80203f42:	bfc9                	j	80203f14 <sys_event_stack+0x3a>

0000000080203f44 <sys_alloc_stats>:
{
    80203f44:	7115                	addi	sp,sp,-224
    80203f46:	ed86                	sd	ra,216(sp)
    80203f48:	e9a2                	sd	s0,208(sp)
    80203f4a:	1180                	addi	s0,sp,224
    argaddr(0, &out);
    80203f4c:	fe840593          	addi	a1,s0,-24
    80203f50:	4501                	li	a0,0
    80203f52:	00000097          	auipc	ra,0x0
    80203f56:	cf0080e7          	jalr	-784(ra) # 80203c42 <argaddr>
    alloc_stats(&st);
    80203f5a:	f2040513          	addi	a0,s0,-224
    80203f5e:	ffffd097          	auipc	ra,0xffffd
    80203f62:	3f4080e7          	jalr	1012(ra) # 80201352 <alloc_stats>
    if (copyout(myproc()->pagetable, out, (char *)&st, sizeof(st)) < 0) return -1;
    80203f66:	ffffe097          	auipc	ra,0xffffe
    80203f6a:	98a080e7          	jalr	-1654(ra) # 802018f0 <myproc>
    80203f6e:	0c800693          	li	a3,200
    80203f72:	f2040613          	addi	a2,s0,-224
    80203f76:	fe843583          	ld	a1,-24(s0)
    80203f7a:	6928                	ld	a0,80(a0)
    80203f7c:	fffff097          	auipc	ra,0xfffff
    80203f80:	4de080e7          	jalr	1246(ra) # 8020345a <copyout>
}
    80203f84:	957d                	srai	a0,a0,0x3f
    80203f86:	60ee                	ld	ra,216(sp)
    80203f88:	644e                	ld	s0,208(sp)
    80203f8a:	612d                	addi	sp,sp,224
    80203f8c:	8082                	ret

0000000080203f8e <sys_mmap>:
{
    80203f8e:	7139                	addi	sp,sp,-64
    80203f90:	fc06                	sd	ra,56(sp)
    80203f92:	f822                	sd	s0,48(sp)
    80203f94:	0080                	addi	s0,sp,64
    argaddr(0, &addr);
    80203f96:	fe840593          	addi	a1,s0,-24
    80203f9a:	4501                	li	a0,0
    80203f9c:	00000097          	auipc	ra,0x0
    80203fa0:	ca6080e7          	jalr	-858(ra) # 80203c42 <argaddr>
    argaddr(1, &len);
    80203fa4:	fe040593          	addi	a1,s0,-32
    80203fa8:	4505                	li	a0,1
    80203faa:	00000097          	auipc	ra,0x0
    80203fae:	c98080e7          	jalr	-872(ra) # 80203c42 <argaddr>
    argint(2, &prot);
    80203fb2:	fd440593          	addi	a1,s0,-44
    80203fb6:	4509                	li	a0,2
    80203fb8:	00000097          	auipc	ra,0x0
    80203fbc:	b30080e7          	jalr	-1232(ra) # 80203ae8 <argint>
    argint(3, &flags);
    80203fc0:	fd040593          	addi	a1,s0,-48
    80203fc4:	450d                	li	a0,3
    80203fc6:	00000097          	auipc	ra,0x0
    80203fca:	b22080e7          	jalr	-1246(ra) # 80203ae8 <argint>
    argint(4, &fd);
    80203fce:	fcc40593          	addi	a1,s0,-52
    80203fd2:	4511                	li	a0,4
    80203fd4:	00000097          	auipc	ra,0x0
    80203fd8:	b14080e7          	jalr	-1260(ra) # 80203ae8 <argint>
    argaddr(5, &off);
    80203fdc:	fd840593          	addi	a1,s0,-40
    80203fe0:	4515                	li	a0,5
    80203fe2:	00000097          	auipc	ra,0x0
    80203fe6:	c60080e7          	jalr	-928(ra) # 80203c42 <argaddr>
    return mmap(addr, len, prot, flags, fd, off);
    80203fea:	fd843783          	ld	a5,-40(s0)
    80203fee:	fcc42703          	lw	a4,-52(s0)
    80203ff2:	fd042683          	lw	a3,-48(s0)
    80203ff6:	fd442603          	lw	a2,-44(s0)
    80203ffa:	fe043583          	ld	a1,-32(s0)
    80203ffe:	fe843503          	ld	a0,-24(s0)
    80204002:	00001097          	auipc	ra,0x1
    80204006:	4c2080e7          	jalr	1218(ra) # 802054c4 <mmap>
}
    8020400a:	70e2                	ld	ra,56(sp)
    8020400c:	7442                	ld	s0,48(sp)
    8020400e:	6121                	addi	sp,sp,64
    80204010:	8082                	ret

0000000080204012 <sys_munmap>:
{
    80204012:	1101                	addi	sp,sp,-32
    80204014:	ec06                	sd	ra,24(sp)
    80204016:	e822                	sd	s0,16(sp)
    80204018:	1000                	addi	s0,sp,32
    argaddr(0, &addr);
    8020401a:	fe840593          	addi	a1,s0,-24
    8020401e:	4501                	li	a0,0
    80204020:	00000097          	auipc	ra,0x0
    80204024:	c22080e7          	jalr	-990(ra) # 80203c42 <argaddr>
    argaddr(1, &len);
    80204028:	fe040593          	addi	a1,s0,-32
    8020402c:	4505                	li	a0,1
    8020402e:	00000097          	auipc	ra,0x0
    80204032:	c14080e7          	jalr	-1004(ra) # 80203c42 <argaddr>
    return munmap(addr, len);
    80204036:	fe043583          	ld	a1,-32(s0)
    8020403a:	fe843503          	ld	a0,-24(s0)
    8020403e:	00001097          	auipc	ra,0x1
    80204042:	6b0080e7          	jalr	1712(ra) # 802056ee <munmap>
}
    80204046:	60e2                	ld	ra,24(sp)
    80204048:	6442                	ld	s0,16(sp)
    8020404a:	6105                	addi	sp,sp,32
    8020404c:	8082                	ret

000000008020404e <sys_fdstat>:

#include "syscalltab.h"     /* GENERATED: syscalls[] and syscall_names[] */

/* Lab 1: fdstat - report metadata for one fd of a target process. */
uint64 sys_fdstat(void)
{
    8020404e:	7139                	addi	sp,sp,-64
    80204050:	fc06                	sd	ra,56(sp)
    80204052:	f822                	sd	s0,48(sp)
    80204054:	0080                	addi	s0,sp,64
    int pid, fd;
    uint64 out;
    argint(0, &pid);
    80204056:	fec40593          	addi	a1,s0,-20
    8020405a:	4501                	li	a0,0
    8020405c:	00000097          	auipc	ra,0x0
    80204060:	a8c080e7          	jalr	-1396(ra) # 80203ae8 <argint>
    argint(1, &fd);
    80204064:	fe840593          	addi	a1,s0,-24
    80204068:	4505                	li	a0,1
    8020406a:	00000097          	auipc	ra,0x0
    8020406e:	a7e080e7          	jalr	-1410(ra) # 80203ae8 <argint>
    argaddr(2, &out);
    80204072:	fe040593          	addi	a1,s0,-32
    80204076:	4509                	li	a0,2
    80204078:	00000097          	auipc	ra,0x0
    8020407c:	bca080e7          	jalr	-1078(ra) # 80203c42 <argaddr>
    if (fd < 0 || fd >= NOFILE) return -1;
    80204080:	fe842583          	lw	a1,-24(s0)
    80204084:	0005871b          	sext.w	a4,a1
    80204088:	47bd                	li	a5,15
    8020408a:	557d                	li	a0,-1
    8020408c:	02e7ed63          	bltu	a5,a4,802040c6 <sys_fdstat+0x78>
    struct fdinfo fi;
    int found = fdstat_lookup(pid, fd, &fi);
    80204090:	fc840613          	addi	a2,s0,-56
    80204094:	fec42503          	lw	a0,-20(s0)
    80204098:	ffffe097          	auipc	ra,0xffffe
    8020409c:	3c4080e7          	jalr	964(ra) # 8020245c <fdstat_lookup>
    802040a0:	87aa                	mv	a5,a0
    if (found < 0) return -1;
    802040a2:	557d                	li	a0,-1
    802040a4:	0207c163          	bltz	a5,802040c6 <sys_fdstat+0x78>
    if (copyout(myproc()->pagetable, out, (char *)&fi, sizeof(fi)) < 0) return -1;
    802040a8:	ffffe097          	auipc	ra,0xffffe
    802040ac:	848080e7          	jalr	-1976(ra) # 802018f0 <myproc>
    802040b0:	46d1                	li	a3,20
    802040b2:	fc840613          	addi	a2,s0,-56
    802040b6:	fe043583          	ld	a1,-32(s0)
    802040ba:	6928                	ld	a0,80(a0)
    802040bc:	fffff097          	auipc	ra,0xfffff
    802040c0:	39e080e7          	jalr	926(ra) # 8020345a <copyout>
    802040c4:	957d                	srai	a0,a0,0x3f
    return 0;
}
    802040c6:	70e2                	ld	ra,56(sp)
    802040c8:	7442                	ld	s0,48(sp)
    802040ca:	6121                	addi	sp,sp,64
    802040cc:	8082                	ret

00000000802040ce <sys_abimeta>:

/* Lab 1: abimeta - copy out (num,name) rows from the generated syscall table. */
struct abinfo { int num; char name[16]; };
uint64 sys_abimeta(void)
{
    802040ce:	7119                	addi	sp,sp,-128
    802040d0:	fc86                	sd	ra,120(sp)
    802040d2:	f8a2                	sd	s0,112(sp)
    802040d4:	e0da                	sd	s6,64(sp)
    802040d6:	0100                	addi	s0,sp,128
    uint64 buf;
    int max;
    argaddr(0, &buf);
    802040d8:	f9840593          	addi	a1,s0,-104
    802040dc:	4501                	li	a0,0
    802040de:	00000097          	auipc	ra,0x0
    802040e2:	b64080e7          	jalr	-1180(ra) # 80203c42 <argaddr>
    argint(1, &max);
    802040e6:	f9440593          	addi	a1,s0,-108
    802040ea:	4505                	li	a0,1
    802040ec:	00000097          	auipc	ra,0x0
    802040f0:	9fc080e7          	jalr	-1540(ra) # 80203ae8 <argint>
    if (max <= 0) return -1;
    802040f4:	f9442b03          	lw	s6,-108(s0)
    802040f8:	11605463          	blez	s6,80204200 <sys_abimeta+0x132>
    802040fc:	f4a6                	sd	s1,104(sp)
    802040fe:	f0ca                	sd	s2,96(sp)
    80204100:	ecce                	sd	s3,88(sp)
    80204102:	e8d2                	sd	s4,80(sp)
    80204104:	e4d6                	sd	s5,72(sp)
    80204106:	fc5e                	sd	s7,56(sp)
    80204108:	f862                	sd	s8,48(sp)
    8020410a:	f466                	sd	s9,40(sp)
    8020410c:	f06a                	sd	s10,32(sp)
    8020410e:	00006a17          	auipc	s4,0x6
    80204112:	f7aa0a13          	addi	s4,s4,-134 # 8020a088 <syscalls+0x8>
    80204116:	00006a97          	auipc	s5,0x6
    8020411a:	0daa8a93          	addi	s5,s5,218 # 8020a1f0 <syscall_names+0x8>
    int n = 0;
    int nsys = sizeof(syscalls)/sizeof(syscalls[0]);
    for (int i = 1; i < nsys && n < max; i++) {
    8020411e:	4905                	li	s2,1
    int n = 0;
    80204120:	4981                	li	s3,0
    [42] "logcrash",
    [43] "logverify",
    [44] "fsck",
};
/* silence -Wunused for the names table until Lab 3 uses it */
static inline const char *syscall_name(int n){ return (n > 0 && n < (int)(sizeof(syscall_names)/sizeof(char*)) && syscall_names[n]) ? syscall_names[n] : "?"; }
    80204122:	02b00c13          	li	s8,43
        if (!syscalls[i]) continue;
        struct abinfo a;
        a.num = i;
        const char *nm = syscall_name(i);
        int j = 0;
        for (; nm[j] && j < 15; j++) a.name[j] = nm[j];
    80204126:	44c1                	li	s1,16
    80204128:	00005d17          	auipc	s10,0x5
    8020412c:	7e8d0d13          	addi	s10,s10,2024 # 80209910 <etext+0x910>
    80204130:	03f00c93          	li	s9,63
    for (int i = 1; i < nsys && n < max; i++) {
    80204134:	02d00b93          	li	s7,45
    80204138:	a0b5                	j	802041a4 <sys_abimeta+0xd6>
    8020413a:	866a                	mv	a2,s10
        for (; nm[j] && j < 15; j++) a.name[j] = nm[j];
    8020413c:	8766                	mv	a4,s9
    8020413e:	4785                	li	a5,1
    80204140:	f8040693          	addi	a3,s0,-128
    80204144:	96be                	add	a3,a3,a5
    80204146:	00e681a3          	sb	a4,3(a3)
    8020414a:	0007869b          	sext.w	a3,a5
    8020414e:	00f60733          	add	a4,a2,a5
    80204152:	00074703          	lbu	a4,0(a4)
    80204156:	c701                	beqz	a4,8020415e <sys_abimeta+0x90>
    80204158:	0785                	addi	a5,a5,1
    8020415a:	fe9793e3          	bne	a5,s1,80204140 <sys_abimeta+0x72>
        a.name[j] = 0;
    8020415e:	fa068793          	addi	a5,a3,-96
    80204162:	008786b3          	add	a3,a5,s0
    80204166:	fe068223          	sb	zero,-28(a3)
        if (copyout(myproc()->pagetable, buf + n * sizeof(a), (char *)&a, sizeof(a)) < 0)
    8020416a:	ffffd097          	auipc	ra,0xffffd
    8020416e:	786080e7          	jalr	1926(ra) # 802018f0 <myproc>
    80204172:	00299793          	slli	a5,s3,0x2
    80204176:	97ce                	add	a5,a5,s3
    80204178:	078a                	slli	a5,a5,0x2
    8020417a:	46d1                	li	a3,20
    8020417c:	f8040613          	addi	a2,s0,-128
    80204180:	f9843583          	ld	a1,-104(s0)
    80204184:	95be                	add	a1,a1,a5
    80204186:	6928                	ld	a0,80(a0)
    80204188:	fffff097          	auipc	ra,0xfffff
    8020418c:	2d2080e7          	jalr	722(ra) # 8020345a <copyout>
    80204190:	02054e63          	bltz	a0,802041cc <sys_abimeta+0xfe>
            return -1;
        n++;
    80204194:	2985                	addiw	s3,s3,1
    for (int i = 1; i < nsys && n < max; i++) {
    80204196:	2905                	addiw	s2,s2,1
    80204198:	05790563          	beq	s2,s7,802041e2 <sys_abimeta+0x114>
    8020419c:	0a21                	addi	s4,s4,8
    8020419e:	0aa1                	addi	s5,s5,8
    802041a0:	0569d163          	bge	s3,s6,802041e2 <sys_abimeta+0x114>
        if (!syscalls[i]) continue;
    802041a4:	000a3783          	ld	a5,0(s4)
    802041a8:	d7fd                	beqz	a5,80204196 <sys_abimeta+0xc8>
        a.num = i;
    802041aa:	f9242023          	sw	s2,-128(s0)
    802041ae:	fff9079b          	addiw	a5,s2,-1
    802041b2:	f8fc64e3          	bltu	s8,a5,8020413a <sys_abimeta+0x6c>
    802041b6:	000ab603          	ld	a2,0(s5)
    802041ba:	c611                	beqz	a2,802041c6 <sys_abimeta+0xf8>
        for (; nm[j] && j < 15; j++) a.name[j] = nm[j];
    802041bc:	00064703          	lbu	a4,0(a2)
    802041c0:	ff3d                	bnez	a4,8020413e <sys_abimeta+0x70>
        int j = 0;
    802041c2:	4681                	li	a3,0
    802041c4:	bf69                	j	8020415e <sys_abimeta+0x90>
    802041c6:	866a                	mv	a2,s10
        for (; nm[j] && j < 15; j++) a.name[j] = nm[j];
    802041c8:	8766                	mv	a4,s9
    802041ca:	bf95                	j	8020413e <sys_abimeta+0x70>
            return -1;
    802041cc:	557d                	li	a0,-1
    802041ce:	74a6                	ld	s1,104(sp)
    802041d0:	7906                	ld	s2,96(sp)
    802041d2:	69e6                	ld	s3,88(sp)
    802041d4:	6a46                	ld	s4,80(sp)
    802041d6:	6aa6                	ld	s5,72(sp)
    802041d8:	7be2                	ld	s7,56(sp)
    802041da:	7c42                	ld	s8,48(sp)
    802041dc:	7ca2                	ld	s9,40(sp)
    802041de:	7d02                	ld	s10,32(sp)
    802041e0:	a819                	j	802041f6 <sys_abimeta+0x128>
    }
    return n;
    802041e2:	854e                	mv	a0,s3
    802041e4:	74a6                	ld	s1,104(sp)
    802041e6:	7906                	ld	s2,96(sp)
    802041e8:	69e6                	ld	s3,88(sp)
    802041ea:	6a46                	ld	s4,80(sp)
    802041ec:	6aa6                	ld	s5,72(sp)
    802041ee:	7be2                	ld	s7,56(sp)
    802041f0:	7c42                	ld	s8,48(sp)
    802041f2:	7ca2                	ld	s9,40(sp)
    802041f4:	7d02                	ld	s10,32(sp)
}
    802041f6:	70e6                	ld	ra,120(sp)
    802041f8:	7446                	ld	s0,112(sp)
    802041fa:	6b06                	ld	s6,64(sp)
    802041fc:	6109                	addi	sp,sp,128
    802041fe:	8082                	ret
    if (max <= 0) return -1;
    80204200:	557d                	li	a0,-1
    80204202:	bfd5                	j	802041f6 <sys_abimeta+0x128>

0000000080204204 <fetchstr>:
{
    80204204:	7179                	addi	sp,sp,-48
    80204206:	f406                	sd	ra,40(sp)
    80204208:	f022                	sd	s0,32(sp)
    8020420a:	ec26                	sd	s1,24(sp)
    8020420c:	e84a                	sd	s2,16(sp)
    8020420e:	e44e                	sd	s3,8(sp)
    80204210:	1800                	addi	s0,sp,48
    80204212:	892a                	mv	s2,a0
    80204214:	84ae                	mv	s1,a1
    80204216:	89b2                	mv	s3,a2
    struct proc *p = myproc();
    80204218:	ffffd097          	auipc	ra,0xffffd
    8020421c:	6d8080e7          	jalr	1752(ra) # 802018f0 <myproc>
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    80204220:	86ce                	mv	a3,s3
    80204222:	864a                	mv	a2,s2
    80204224:	85a6                	mv	a1,s1
    80204226:	6928                	ld	a0,80(a0)
    80204228:	fffff097          	auipc	ra,0xfffff
    8020422c:	3e4080e7          	jalr	996(ra) # 8020360c <copyinstr>
    80204230:	00054e63          	bltz	a0,8020424c <fetchstr+0x48>
    return strlen(buf);
    80204234:	8526                	mv	a0,s1
    80204236:	ffffc097          	auipc	ra,0xffffc
    8020423a:	584080e7          	jalr	1412(ra) # 802007ba <strlen>
}
    8020423e:	70a2                	ld	ra,40(sp)
    80204240:	7402                	ld	s0,32(sp)
    80204242:	64e2                	ld	s1,24(sp)
    80204244:	6942                	ld	s2,16(sp)
    80204246:	69a2                	ld	s3,8(sp)
    80204248:	6145                	addi	sp,sp,48
    8020424a:	8082                	ret
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    8020424c:	557d                	li	a0,-1
    8020424e:	bfc5                	j	8020423e <fetchstr+0x3a>

0000000080204250 <argstr>:
{
    80204250:	7179                	addi	sp,sp,-48
    80204252:	f406                	sd	ra,40(sp)
    80204254:	f022                	sd	s0,32(sp)
    80204256:	ec26                	sd	s1,24(sp)
    80204258:	e84a                	sd	s2,16(sp)
    8020425a:	1800                	addi	s0,sp,48
    8020425c:	84ae                	mv	s1,a1
    8020425e:	8932                	mv	s2,a2
    argaddr(n, &addr);
    80204260:	fd840593          	addi	a1,s0,-40
    80204264:	00000097          	auipc	ra,0x0
    80204268:	9de080e7          	jalr	-1570(ra) # 80203c42 <argaddr>
    return fetchstr(addr, buf, max);
    8020426c:	864a                	mv	a2,s2
    8020426e:	85a6                	mv	a1,s1
    80204270:	fd843503          	ld	a0,-40(s0)
    80204274:	00000097          	auipc	ra,0x0
    80204278:	f90080e7          	jalr	-112(ra) # 80204204 <fetchstr>
}
    8020427c:	70a2                	ld	ra,40(sp)
    8020427e:	7402                	ld	s0,32(sp)
    80204280:	64e2                	ld	s1,24(sp)
    80204282:	6942                	ld	s2,16(sp)
    80204284:	6145                	addi	sp,sp,48
    80204286:	8082                	ret

0000000080204288 <syscall>:

void syscall(void)
{
    80204288:	7179                	addi	sp,sp,-48
    8020428a:	f406                	sd	ra,40(sp)
    8020428c:	f022                	sd	s0,32(sp)
    8020428e:	ec26                	sd	s1,24(sp)
    80204290:	e84a                	sd	s2,16(sp)
    80204292:	e44e                	sd	s3,8(sp)
    80204294:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    80204296:	ffffd097          	auipc	ra,0xffffd
    8020429a:	65a080e7          	jalr	1626(ra) # 802018f0 <myproc>
    8020429e:	84aa                	mv	s1,a0
    uint64 num = p->tf->a7;
    802042a0:	05853983          	ld	s3,88(a0)
    802042a4:	0a89b903          	ld	s2,168(s3)

    /* Validate the number BEFORE indexing the table. A bad syscall number is a
     * hostile input, not a bug - return an error and stay alive.
     * Lab 2 (trace) hooks in HERE: this is the one point every call crosses. */
    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    802042a8:	fff90713          	addi	a4,s2,-1
    802042ac:	02b00793          	li	a5,43
    802042b0:	04e7e663          	bltu	a5,a4,802042fc <syscall+0x74>
    802042b4:	00391713          	slli	a4,s2,0x3
    802042b8:	00006797          	auipc	a5,0x6
    802042bc:	dc878793          	addi	a5,a5,-568 # 8020a080 <syscalls>
    802042c0:	97ba                	add	a5,a5,a4
    802042c2:	639c                	ld	a5,0(a5)
    802042c4:	cf85                	beqz	a5,802042fc <syscall+0x74>
    802042c6:	e052                	sd	s4,0(sp)
        uint64 a0 = p->tf->a0;
    802042c8:	0709ba03          	ld	s4,112(s3)
        p->tf->a0 = syscalls[num]();
    802042cc:	9782                	jalr	a5
    802042ce:	06a9b823          	sd	a0,112(s3)
        trace_record((int)num, (long)p->tf->a0, a0);   /* Lab 2 */
    802042d2:	6cbc                	ld	a5,88(s1)
    802042d4:	8652                	mv	a2,s4
    802042d6:	7bac                	ld	a1,112(a5)
    802042d8:	0009051b          	sext.w	a0,s2
    802042dc:	00001097          	auipc	ra,0x1
    802042e0:	da8080e7          	jalr	-600(ra) # 80205084 <trace_record>
        p->syscall_count++; usysinfo_update(p);         /* Lab 3 */
    802042e4:	1784b783          	ld	a5,376(s1)
    802042e8:	0785                	addi	a5,a5,1
    802042ea:	16f4bc23          	sd	a5,376(s1)
    802042ee:	8526                	mv	a0,s1
    802042f0:	00001097          	auipc	ra,0x1
    802042f4:	e9e080e7          	jalr	-354(ra) # 8020518e <usysinfo_update>
    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    802042f8:	6a02                	ld	s4,0(sp)
    802042fa:	a005                	j	8020431a <syscall+0x92>
    } else {
        printf("pid %d (%s): unknown syscall %d\n", p->pid, p->name, num);
    802042fc:	86ca                	mv	a3,s2
    802042fe:	15848613          	addi	a2,s1,344
    80204302:	588c                	lw	a1,48(s1)
    80204304:	00005517          	auipc	a0,0x5
    80204308:	61450513          	addi	a0,a0,1556 # 80209918 <etext+0x918>
    8020430c:	ffffc097          	auipc	ra,0xffffc
    80204310:	098080e7          	jalr	152(ra) # 802003a4 <printf>
        p->tf->a0 = -1;
    80204314:	6cbc                	ld	a5,88(s1)
    80204316:	577d                	li	a4,-1
    80204318:	fbb8                	sd	a4,112(a5)
    }
    (void)syscall_name;      /* used by Lab 2; referenced here to stay warning-clean */
}
    8020431a:	70a2                	ld	ra,40(sp)
    8020431c:	7402                	ld	s0,32(sp)
    8020431e:	64e2                	ld	s1,24(sp)
    80204320:	6942                	ld	s2,16(sp)
    80204322:	69a2                	ld	s3,8(sp)
    80204324:	6145                	addi	sp,sp,48
    80204326:	8082                	ret

0000000080204328 <argfd>:
#include "defs.h"
#include "fcntl.h"

/* Fetch the n'th arg as a file descriptor; return the struct file too. */
static int argfd(int n, int *pfd, struct file **pf)
{
    80204328:	7179                	addi	sp,sp,-48
    8020432a:	f406                	sd	ra,40(sp)
    8020432c:	f022                	sd	s0,32(sp)
    8020432e:	ec26                	sd	s1,24(sp)
    80204330:	e84a                	sd	s2,16(sp)
    80204332:	1800                	addi	s0,sp,48
    80204334:	892e                	mv	s2,a1
    80204336:	84b2                	mv	s1,a2
    int fd;
    argint(n, &fd);
    80204338:	fdc40593          	addi	a1,s0,-36
    8020433c:	fffff097          	auipc	ra,0xfffff
    80204340:	7ac080e7          	jalr	1964(ra) # 80203ae8 <argint>
    if (fd < 0 || fd >= NOFILE) return -1;
    80204344:	fdc42703          	lw	a4,-36(s0)
    80204348:	47bd                	li	a5,15
    8020434a:	02e7eb63          	bltu	a5,a4,80204380 <argfd+0x58>
    struct file *f = myproc()->ofile[fd];
    8020434e:	ffffd097          	auipc	ra,0xffffd
    80204352:	5a2080e7          	jalr	1442(ra) # 802018f0 <myproc>
    80204356:	fdc42703          	lw	a4,-36(s0)
    8020435a:	01a70793          	addi	a5,a4,26
    8020435e:	078e                	slli	a5,a5,0x3
    80204360:	953e                	add	a0,a0,a5
    80204362:	611c                	ld	a5,0(a0)
    if (f == 0) return -1;
    80204364:	c385                	beqz	a5,80204384 <argfd+0x5c>
    if (pfd) *pfd = fd;
    80204366:	00090463          	beqz	s2,8020436e <argfd+0x46>
    8020436a:	00e92023          	sw	a4,0(s2)
    if (pf)  *pf  = f;
    return 0;
    8020436e:	4501                	li	a0,0
    if (pf)  *pf  = f;
    80204370:	c091                	beqz	s1,80204374 <argfd+0x4c>
    80204372:	e09c                	sd	a5,0(s1)
}
    80204374:	70a2                	ld	ra,40(sp)
    80204376:	7402                	ld	s0,32(sp)
    80204378:	64e2                	ld	s1,24(sp)
    8020437a:	6942                	ld	s2,16(sp)
    8020437c:	6145                	addi	sp,sp,48
    8020437e:	8082                	ret
    if (fd < 0 || fd >= NOFILE) return -1;
    80204380:	557d                	li	a0,-1
    80204382:	bfcd                	j	80204374 <argfd+0x4c>
    if (f == 0) return -1;
    80204384:	557d                	li	a0,-1
    80204386:	b7fd                	j	80204374 <argfd+0x4c>

0000000080204388 <fdalloc>:

/* Install f in the first free slot of the fd table. */
static int fdalloc(struct file *f)
{
    80204388:	1101                	addi	sp,sp,-32
    8020438a:	ec06                	sd	ra,24(sp)
    8020438c:	e822                	sd	s0,16(sp)
    8020438e:	e426                	sd	s1,8(sp)
    80204390:	1000                	addi	s0,sp,32
    80204392:	84aa                	mv	s1,a0
    struct proc *p = myproc();
    80204394:	ffffd097          	auipc	ra,0xffffd
    80204398:	55c080e7          	jalr	1372(ra) # 802018f0 <myproc>
    8020439c:	862a                	mv	a2,a0
    for (int fd = 0; fd < NOFILE; fd++) {
    8020439e:	0d050793          	addi	a5,a0,208
    802043a2:	4501                	li	a0,0
    802043a4:	46c1                	li	a3,16
        if (p->ofile[fd] == 0) {
    802043a6:	6398                	ld	a4,0(a5)
    802043a8:	cb19                	beqz	a4,802043be <fdalloc+0x36>
    for (int fd = 0; fd < NOFILE; fd++) {
    802043aa:	2505                	addiw	a0,a0,1
    802043ac:	07a1                	addi	a5,a5,8
    802043ae:	fed51ce3          	bne	a0,a3,802043a6 <fdalloc+0x1e>
            p->ofile[fd] = f;
            return fd;
        }
    }
    return -1;
    802043b2:	557d                	li	a0,-1
}
    802043b4:	60e2                	ld	ra,24(sp)
    802043b6:	6442                	ld	s0,16(sp)
    802043b8:	64a2                	ld	s1,8(sp)
    802043ba:	6105                	addi	sp,sp,32
    802043bc:	8082                	ret
            p->ofile[fd] = f;
    802043be:	01a50793          	addi	a5,a0,26
    802043c2:	078e                	slli	a5,a5,0x3
    802043c4:	963e                	add	a2,a2,a5
    802043c6:	e204                	sd	s1,0(a2)
            return fd;
    802043c8:	b7f5                	j	802043b4 <fdalloc+0x2c>

00000000802043ca <create>:
}

/* Create path as type. Returns LOCKED inode, or 0. Handles the T_DIR case
 * (".", "..", parent nlink) and open(O_CREATE) racing an existing file. */
static struct inode *create(char *path, uint16 type, uint16 major, uint16 minor)
{
    802043ca:	711d                	addi	sp,sp,-96
    802043cc:	ec86                	sd	ra,88(sp)
    802043ce:	e8a2                	sd	s0,80(sp)
    802043d0:	e4a6                	sd	s1,72(sp)
    802043d2:	e0ca                	sd	s2,64(sp)
    802043d4:	fc4e                	sd	s3,56(sp)
    802043d6:	f456                	sd	s5,40(sp)
    802043d8:	f05a                	sd	s6,32(sp)
    802043da:	1080                	addi	s0,sp,96
    802043dc:	8b2e                	mv	s6,a1
    802043de:	89b2                	mv	s3,a2
    802043e0:	8936                	mv	s2,a3
    char name[DIRSIZ];
    struct inode *dp = nameiparent(path, name);
    802043e2:	fa040593          	addi	a1,s0,-96
    802043e6:	00003097          	auipc	ra,0x3
    802043ea:	55a080e7          	jalr	1370(ra) # 80207940 <nameiparent>
    802043ee:	84aa                	mv	s1,a0
    if (dp == 0) return 0;
    802043f0:	16050263          	beqz	a0,80204554 <create+0x18a>
    ilock(dp);
    802043f4:	00003097          	auipc	ra,0x3
    802043f8:	c9a080e7          	jalr	-870(ra) # 8020708e <ilock>

    struct inode *ip = dirlookup(dp, name, 0);
    802043fc:	4601                	li	a2,0
    802043fe:	fa040593          	addi	a1,s0,-96
    80204402:	8526                	mv	a0,s1
    80204404:	00003097          	auipc	ra,0x3
    80204408:	254080e7          	jalr	596(ra) # 80207658 <dirlookup>
    8020440c:	8aaa                	mv	s5,a0
    if (ip != 0) {
    8020440e:	c929                	beqz	a0,80204460 <create+0x96>
        iunlockput(dp);
    80204410:	8526                	mv	a0,s1
    80204412:	00003097          	auipc	ra,0x3
    80204416:	f58080e7          	jalr	-168(ra) # 8020736a <iunlockput>
        ilock(ip);
    8020441a:	8556                	mv	a0,s5
    8020441c:	00003097          	auipc	ra,0x3
    80204420:	c72080e7          	jalr	-910(ra) # 8020708e <ilock>
        if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEV))
    80204424:	000b059b          	sext.w	a1,s6
    80204428:	4789                	li	a5,2
    8020442a:	02f59463          	bne	a1,a5,80204452 <create+0x88>
    8020442e:	044ad783          	lhu	a5,68(s5)
    80204432:	37f9                	addiw	a5,a5,-2
    80204434:	17c2                	slli	a5,a5,0x30
    80204436:	93c1                	srli	a5,a5,0x30
    80204438:	4705                	li	a4,1
    8020443a:	00f76c63          	bltu	a4,a5,80204452 <create+0x88>
    ip->nlink = 0;
    iupdate(ip);
    iunlockput(ip);
    iunlockput(dp);
    return 0;
}
    8020443e:	8556                	mv	a0,s5
    80204440:	60e6                	ld	ra,88(sp)
    80204442:	6446                	ld	s0,80(sp)
    80204444:	64a6                	ld	s1,72(sp)
    80204446:	6906                	ld	s2,64(sp)
    80204448:	79e2                	ld	s3,56(sp)
    8020444a:	7aa2                	ld	s5,40(sp)
    8020444c:	7b02                	ld	s6,32(sp)
    8020444e:	6125                	addi	sp,sp,96
    80204450:	8082                	ret
        iunlockput(ip);
    80204452:	8556                	mv	a0,s5
    80204454:	00003097          	auipc	ra,0x3
    80204458:	f16080e7          	jalr	-234(ra) # 8020736a <iunlockput>
        return 0;
    8020445c:	4a81                	li	s5,0
    8020445e:	b7c5                	j	8020443e <create+0x74>
    80204460:	f852                	sd	s4,48(sp)
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    80204462:	85da                	mv	a1,s6
    80204464:	4088                	lw	a0,0(s1)
    80204466:	00003097          	auipc	ra,0x3
    8020446a:	a2c080e7          	jalr	-1492(ra) # 80206e92 <ialloc>
    8020446e:	8a2a                	mv	s4,a0
    80204470:	c921                	beqz	a0,802044c0 <create+0xf6>
    ilock(ip);
    80204472:	00003097          	auipc	ra,0x3
    80204476:	c1c080e7          	jalr	-996(ra) # 8020708e <ilock>
    ip->major = major;
    8020447a:	053a1323          	sh	s3,70(s4)
    ip->minor = minor;
    8020447e:	052a1423          	sh	s2,72(s4)
    ip->nlink = 1;
    80204482:	4905                	li	s2,1
    80204484:	052a1523          	sh	s2,74(s4)
    iupdate(ip);
    80204488:	8552                	mv	a0,s4
    8020448a:	00003097          	auipc	ra,0x3
    8020448e:	b38080e7          	jalr	-1224(ra) # 80206fc2 <iupdate>
    if (type == T_DIR) {
    80204492:	000b059b          	sext.w	a1,s6
    80204496:	03258d63          	beq	a1,s2,802044d0 <create+0x106>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    8020449a:	004a2603          	lw	a2,4(s4)
    8020449e:	fa040593          	addi	a1,s0,-96
    802044a2:	8526                	mv	a0,s1
    802044a4:	00003097          	auipc	ra,0x3
    802044a8:	3c4080e7          	jalr	964(ra) # 80207868 <dirlink>
    802044ac:	08054163          	bltz	a0,8020452e <create+0x164>
    iunlockput(dp);
    802044b0:	8526                	mv	a0,s1
    802044b2:	00003097          	auipc	ra,0x3
    802044b6:	eb8080e7          	jalr	-328(ra) # 8020736a <iunlockput>
    return ip;
    802044ba:	8ad2                	mv	s5,s4
    802044bc:	7a42                	ld	s4,48(sp)
    802044be:	b741                	j	8020443e <create+0x74>
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    802044c0:	8526                	mv	a0,s1
    802044c2:	00003097          	auipc	ra,0x3
    802044c6:	ea8080e7          	jalr	-344(ra) # 8020736a <iunlockput>
    802044ca:	8ad2                	mv	s5,s4
    802044cc:	7a42                	ld	s4,48(sp)
    802044ce:	bf85                	j	8020443e <create+0x74>
        if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    802044d0:	004a2603          	lw	a2,4(s4)
    802044d4:	00005597          	auipc	a1,0x5
    802044d8:	61c58593          	addi	a1,a1,1564 # 80209af0 <etext+0xaf0>
    802044dc:	8552                	mv	a0,s4
    802044de:	00003097          	auipc	ra,0x3
    802044e2:	38a080e7          	jalr	906(ra) # 80207868 <dirlink>
    802044e6:	04054463          	bltz	a0,8020452e <create+0x164>
    802044ea:	40d0                	lw	a2,4(s1)
    802044ec:	00005597          	auipc	a1,0x5
    802044f0:	60c58593          	addi	a1,a1,1548 # 80209af8 <etext+0xaf8>
    802044f4:	8552                	mv	a0,s4
    802044f6:	00003097          	auipc	ra,0x3
    802044fa:	372080e7          	jalr	882(ra) # 80207868 <dirlink>
    802044fe:	02054863          	bltz	a0,8020452e <create+0x164>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    80204502:	004a2603          	lw	a2,4(s4)
    80204506:	fa040593          	addi	a1,s0,-96
    8020450a:	8526                	mv	a0,s1
    8020450c:	00003097          	auipc	ra,0x3
    80204510:	35c080e7          	jalr	860(ra) # 80207868 <dirlink>
    80204514:	00054d63          	bltz	a0,8020452e <create+0x164>
        dp->nlink++;
    80204518:	04a4d783          	lhu	a5,74(s1)
    8020451c:	2785                	addiw	a5,a5,1
    8020451e:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80204522:	8526                	mv	a0,s1
    80204524:	00003097          	auipc	ra,0x3
    80204528:	a9e080e7          	jalr	-1378(ra) # 80206fc2 <iupdate>
    8020452c:	b751                	j	802044b0 <create+0xe6>
    ip->nlink = 0;
    8020452e:	040a1523          	sh	zero,74(s4)
    iupdate(ip);
    80204532:	8552                	mv	a0,s4
    80204534:	00003097          	auipc	ra,0x3
    80204538:	a8e080e7          	jalr	-1394(ra) # 80206fc2 <iupdate>
    iunlockput(ip);
    8020453c:	8552                	mv	a0,s4
    8020453e:	00003097          	auipc	ra,0x3
    80204542:	e2c080e7          	jalr	-468(ra) # 8020736a <iunlockput>
    iunlockput(dp);
    80204546:	8526                	mv	a0,s1
    80204548:	00003097          	auipc	ra,0x3
    8020454c:	e22080e7          	jalr	-478(ra) # 8020736a <iunlockput>
    return 0;
    80204550:	7a42                	ld	s4,48(sp)
    80204552:	b5f5                	j	8020443e <create+0x74>
    if (dp == 0) return 0;
    80204554:	8aaa                	mv	s5,a0
    80204556:	b5e5                	j	8020443e <create+0x74>

0000000080204558 <sys_dup>:
{
    80204558:	7179                	addi	sp,sp,-48
    8020455a:	f406                	sd	ra,40(sp)
    8020455c:	f022                	sd	s0,32(sp)
    8020455e:	1800                	addi	s0,sp,48
    if (argfd(0, 0, &f) < 0) return -1;
    80204560:	fd840613          	addi	a2,s0,-40
    80204564:	4581                	li	a1,0
    80204566:	4501                	li	a0,0
    80204568:	00000097          	auipc	ra,0x0
    8020456c:	dc0080e7          	jalr	-576(ra) # 80204328 <argfd>
    80204570:	57fd                	li	a5,-1
    80204572:	02054763          	bltz	a0,802045a0 <sys_dup+0x48>
    80204576:	ec26                	sd	s1,24(sp)
    80204578:	e84a                	sd	s2,16(sp)
    int fd = fdalloc(f);
    8020457a:	fd843903          	ld	s2,-40(s0)
    8020457e:	854a                	mv	a0,s2
    80204580:	00000097          	auipc	ra,0x0
    80204584:	e08080e7          	jalr	-504(ra) # 80204388 <fdalloc>
    80204588:	84aa                	mv	s1,a0
    if (fd < 0) return -1;
    8020458a:	57fd                	li	a5,-1
    8020458c:	00054f63          	bltz	a0,802045aa <sys_dup+0x52>
    filedup(f);
    80204590:	854a                	mv	a0,s2
    80204592:	00003097          	auipc	ra,0x3
    80204596:	45c080e7          	jalr	1116(ra) # 802079ee <filedup>
    return fd;
    8020459a:	87a6                	mv	a5,s1
    8020459c:	64e2                	ld	s1,24(sp)
    8020459e:	6942                	ld	s2,16(sp)
}
    802045a0:	853e                	mv	a0,a5
    802045a2:	70a2                	ld	ra,40(sp)
    802045a4:	7402                	ld	s0,32(sp)
    802045a6:	6145                	addi	sp,sp,48
    802045a8:	8082                	ret
    802045aa:	64e2                	ld	s1,24(sp)
    802045ac:	6942                	ld	s2,16(sp)
    802045ae:	bfcd                	j	802045a0 <sys_dup+0x48>

00000000802045b0 <sys_read>:
{
    802045b0:	7179                	addi	sp,sp,-48
    802045b2:	f406                	sd	ra,40(sp)
    802045b4:	f022                	sd	s0,32(sp)
    802045b6:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    802045b8:	fd840593          	addi	a1,s0,-40
    802045bc:	4505                	li	a0,1
    802045be:	fffff097          	auipc	ra,0xfffff
    802045c2:	684080e7          	jalr	1668(ra) # 80203c42 <argaddr>
    argint(2, &n);
    802045c6:	fe440593          	addi	a1,s0,-28
    802045ca:	4509                	li	a0,2
    802045cc:	fffff097          	auipc	ra,0xfffff
    802045d0:	51c080e7          	jalr	1308(ra) # 80203ae8 <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    802045d4:	fe840613          	addi	a2,s0,-24
    802045d8:	4581                	li	a1,0
    802045da:	4501                	li	a0,0
    802045dc:	00000097          	auipc	ra,0x0
    802045e0:	d4c080e7          	jalr	-692(ra) # 80204328 <argfd>
    802045e4:	02054363          	bltz	a0,8020460a <sys_read+0x5a>
    802045e8:	fe442603          	lw	a2,-28(s0)
    802045ec:	557d                	li	a0,-1
    802045ee:	00064a63          	bltz	a2,80204602 <sys_read+0x52>
    return fileread(f, p, n);
    802045f2:	fd843583          	ld	a1,-40(s0)
    802045f6:	fe843503          	ld	a0,-24(s0)
    802045fa:	00003097          	auipc	ra,0x3
    802045fe:	582080e7          	jalr	1410(ra) # 80207b7c <fileread>
}
    80204602:	70a2                	ld	ra,40(sp)
    80204604:	7402                	ld	s0,32(sp)
    80204606:	6145                	addi	sp,sp,48
    80204608:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    8020460a:	557d                	li	a0,-1
    8020460c:	bfdd                	j	80204602 <sys_read+0x52>

000000008020460e <sys_write>:
{
    8020460e:	7179                	addi	sp,sp,-48
    80204610:	f406                	sd	ra,40(sp)
    80204612:	f022                	sd	s0,32(sp)
    80204614:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    80204616:	fd840593          	addi	a1,s0,-40
    8020461a:	4505                	li	a0,1
    8020461c:	fffff097          	auipc	ra,0xfffff
    80204620:	626080e7          	jalr	1574(ra) # 80203c42 <argaddr>
    argint(2, &n);
    80204624:	fe440593          	addi	a1,s0,-28
    80204628:	4509                	li	a0,2
    8020462a:	fffff097          	auipc	ra,0xfffff
    8020462e:	4be080e7          	jalr	1214(ra) # 80203ae8 <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80204632:	fe840613          	addi	a2,s0,-24
    80204636:	4581                	li	a1,0
    80204638:	4501                	li	a0,0
    8020463a:	00000097          	auipc	ra,0x0
    8020463e:	cee080e7          	jalr	-786(ra) # 80204328 <argfd>
    80204642:	02054363          	bltz	a0,80204668 <sys_write+0x5a>
    80204646:	fe442603          	lw	a2,-28(s0)
    8020464a:	557d                	li	a0,-1
    8020464c:	00064a63          	bltz	a2,80204660 <sys_write+0x52>
    return filewrite(f, p, n);
    80204650:	fd843583          	ld	a1,-40(s0)
    80204654:	fe843503          	ld	a0,-24(s0)
    80204658:	00003097          	auipc	ra,0x3
    8020465c:	5f8080e7          	jalr	1528(ra) # 80207c50 <filewrite>
}
    80204660:	70a2                	ld	ra,40(sp)
    80204662:	7402                	ld	s0,32(sp)
    80204664:	6145                	addi	sp,sp,48
    80204666:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80204668:	557d                	li	a0,-1
    8020466a:	bfdd                	j	80204660 <sys_write+0x52>

000000008020466c <sys_close>:
{
    8020466c:	1101                	addi	sp,sp,-32
    8020466e:	ec06                	sd	ra,24(sp)
    80204670:	e822                	sd	s0,16(sp)
    80204672:	1000                	addi	s0,sp,32
    if (argfd(0, &fd, &f) < 0) return -1;
    80204674:	fe040613          	addi	a2,s0,-32
    80204678:	fec40593          	addi	a1,s0,-20
    8020467c:	4501                	li	a0,0
    8020467e:	00000097          	auipc	ra,0x0
    80204682:	caa080e7          	jalr	-854(ra) # 80204328 <argfd>
    80204686:	57fd                	li	a5,-1
    80204688:	02054463          	bltz	a0,802046b0 <sys_close+0x44>
    myproc()->ofile[fd] = 0;
    8020468c:	ffffd097          	auipc	ra,0xffffd
    80204690:	264080e7          	jalr	612(ra) # 802018f0 <myproc>
    80204694:	fec42783          	lw	a5,-20(s0)
    80204698:	07e9                	addi	a5,a5,26
    8020469a:	078e                	slli	a5,a5,0x3
    8020469c:	953e                	add	a0,a0,a5
    8020469e:	00053023          	sd	zero,0(a0)
    fileclose(f);
    802046a2:	fe043503          	ld	a0,-32(s0)
    802046a6:	00003097          	auipc	ra,0x3
    802046aa:	39a080e7          	jalr	922(ra) # 80207a40 <fileclose>
    return 0;
    802046ae:	4781                	li	a5,0
}
    802046b0:	853e                	mv	a0,a5
    802046b2:	60e2                	ld	ra,24(sp)
    802046b4:	6442                	ld	s0,16(sp)
    802046b6:	6105                	addi	sp,sp,32
    802046b8:	8082                	ret

00000000802046ba <sys_fstat>:
{
    802046ba:	1101                	addi	sp,sp,-32
    802046bc:	ec06                	sd	ra,24(sp)
    802046be:	e822                	sd	s0,16(sp)
    802046c0:	1000                	addi	s0,sp,32
    argaddr(1, &st);
    802046c2:	fe040593          	addi	a1,s0,-32
    802046c6:	4505                	li	a0,1
    802046c8:	fffff097          	auipc	ra,0xfffff
    802046cc:	57a080e7          	jalr	1402(ra) # 80203c42 <argaddr>
    if (argfd(0, 0, &f) < 0) return -1;
    802046d0:	fe840613          	addi	a2,s0,-24
    802046d4:	4581                	li	a1,0
    802046d6:	4501                	li	a0,0
    802046d8:	00000097          	auipc	ra,0x0
    802046dc:	c50080e7          	jalr	-944(ra) # 80204328 <argfd>
    802046e0:	87aa                	mv	a5,a0
    802046e2:	557d                	li	a0,-1
    802046e4:	0007ca63          	bltz	a5,802046f8 <sys_fstat+0x3e>
    return filestat(f, st);
    802046e8:	fe043583          	ld	a1,-32(s0)
    802046ec:	fe843503          	ld	a0,-24(s0)
    802046f0:	00003097          	auipc	ra,0x3
    802046f4:	422080e7          	jalr	1058(ra) # 80207b12 <filestat>
}
    802046f8:	60e2                	ld	ra,24(sp)
    802046fa:	6442                	ld	s0,16(sp)
    802046fc:	6105                	addi	sp,sp,32
    802046fe:	8082                	ret

0000000080204700 <sys_link>:
{
    80204700:	7129                	addi	sp,sp,-320
    80204702:	fe06                	sd	ra,312(sp)
    80204704:	fa22                	sd	s0,304(sp)
    80204706:	0280                	addi	s0,sp,320
    if (argstr(0, oldp, MAXPATH) < 0 || argstr(1, newp, MAXPATH) < 0) return -1;
    80204708:	08000613          	li	a2,128
    8020470c:	ec040593          	addi	a1,s0,-320
    80204710:	4501                	li	a0,0
    80204712:	00000097          	auipc	ra,0x0
    80204716:	b3e080e7          	jalr	-1218(ra) # 80204250 <argstr>
    8020471a:	57fd                	li	a5,-1
    8020471c:	0e054f63          	bltz	a0,8020481a <sys_link+0x11a>
    80204720:	08000613          	li	a2,128
    80204724:	f4040593          	addi	a1,s0,-192
    80204728:	4505                	li	a0,1
    8020472a:	00000097          	auipc	ra,0x0
    8020472e:	b26080e7          	jalr	-1242(ra) # 80204250 <argstr>
    80204732:	57fd                	li	a5,-1
    80204734:	0e054363          	bltz	a0,8020481a <sys_link+0x11a>
    80204738:	f626                	sd	s1,296(sp)
    struct inode *ip = namei(oldp);
    8020473a:	ec040513          	addi	a0,s0,-320
    8020473e:	00003097          	auipc	ra,0x3
    80204742:	1e4080e7          	jalr	484(ra) # 80207922 <namei>
    80204746:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80204748:	cd71                	beqz	a0,80204824 <sys_link+0x124>
    ilock(ip);
    8020474a:	00003097          	auipc	ra,0x3
    8020474e:	944080e7          	jalr	-1724(ra) # 8020708e <ilock>
    if (ip->type == T_DIR) {          /* hard links to dirs make cycles */
    80204752:	0444d703          	lhu	a4,68(s1)
    80204756:	4785                	li	a5,1
    80204758:	06f70d63          	beq	a4,a5,802047d2 <sys_link+0xd2>
    8020475c:	f24a                	sd	s2,288(sp)
    ip->nlink++;
    8020475e:	04a4d783          	lhu	a5,74(s1)
    80204762:	2785                	addiw	a5,a5,1
    80204764:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80204768:	8526                	mv	a0,s1
    8020476a:	00003097          	auipc	ra,0x3
    8020476e:	858080e7          	jalr	-1960(ra) # 80206fc2 <iupdate>
    iunlock(ip);
    80204772:	8526                	mv	a0,s1
    80204774:	00003097          	auipc	ra,0x3
    80204778:	9e0080e7          	jalr	-1568(ra) # 80207154 <iunlock>
    struct inode *dp = nameiparent(newp, name);
    8020477c:	fc040593          	addi	a1,s0,-64
    80204780:	f4040513          	addi	a0,s0,-192
    80204784:	00003097          	auipc	ra,0x3
    80204788:	1bc080e7          	jalr	444(ra) # 80207940 <nameiparent>
    8020478c:	892a                	mv	s2,a0
    if (dp == 0) goto bad;
    8020478e:	cd39                	beqz	a0,802047ec <sys_link+0xec>
    ilock(dp);
    80204790:	00003097          	auipc	ra,0x3
    80204794:	8fe080e7          	jalr	-1794(ra) # 8020708e <ilock>
    if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80204798:	00092703          	lw	a4,0(s2)
    8020479c:	409c                	lw	a5,0(s1)
    8020479e:	04f71263          	bne	a4,a5,802047e2 <sys_link+0xe2>
    802047a2:	40d0                	lw	a2,4(s1)
    802047a4:	fc040593          	addi	a1,s0,-64
    802047a8:	854a                	mv	a0,s2
    802047aa:	00003097          	auipc	ra,0x3
    802047ae:	0be080e7          	jalr	190(ra) # 80207868 <dirlink>
    802047b2:	02054863          	bltz	a0,802047e2 <sys_link+0xe2>
    iunlockput(dp);
    802047b6:	854a                	mv	a0,s2
    802047b8:	00003097          	auipc	ra,0x3
    802047bc:	bb2080e7          	jalr	-1102(ra) # 8020736a <iunlockput>
    iput(ip);
    802047c0:	8526                	mv	a0,s1
    802047c2:	00003097          	auipc	ra,0x3
    802047c6:	a8a080e7          	jalr	-1398(ra) # 8020724c <iput>
    return 0;
    802047ca:	4781                	li	a5,0
    802047cc:	74b2                	ld	s1,296(sp)
    802047ce:	7912                	ld	s2,288(sp)
    802047d0:	a0a9                	j	8020481a <sys_link+0x11a>
        iunlockput(ip);
    802047d2:	8526                	mv	a0,s1
    802047d4:	00003097          	auipc	ra,0x3
    802047d8:	b96080e7          	jalr	-1130(ra) # 8020736a <iunlockput>
        return -1;
    802047dc:	57fd                	li	a5,-1
    802047de:	74b2                	ld	s1,296(sp)
    802047e0:	a82d                	j	8020481a <sys_link+0x11a>
        iunlockput(dp);
    802047e2:	854a                	mv	a0,s2
    802047e4:	00003097          	auipc	ra,0x3
    802047e8:	b86080e7          	jalr	-1146(ra) # 8020736a <iunlockput>
    ilock(ip);
    802047ec:	8526                	mv	a0,s1
    802047ee:	00003097          	auipc	ra,0x3
    802047f2:	8a0080e7          	jalr	-1888(ra) # 8020708e <ilock>
    ip->nlink--;
    802047f6:	04a4d783          	lhu	a5,74(s1)
    802047fa:	37fd                	addiw	a5,a5,-1
    802047fc:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80204800:	8526                	mv	a0,s1
    80204802:	00002097          	auipc	ra,0x2
    80204806:	7c0080e7          	jalr	1984(ra) # 80206fc2 <iupdate>
    iunlockput(ip);
    8020480a:	8526                	mv	a0,s1
    8020480c:	00003097          	auipc	ra,0x3
    80204810:	b5e080e7          	jalr	-1186(ra) # 8020736a <iunlockput>
    return -1;
    80204814:	57fd                	li	a5,-1
    80204816:	74b2                	ld	s1,296(sp)
    80204818:	7912                	ld	s2,288(sp)
}
    8020481a:	853e                	mv	a0,a5
    8020481c:	70f2                	ld	ra,312(sp)
    8020481e:	7452                	ld	s0,304(sp)
    80204820:	6131                	addi	sp,sp,320
    80204822:	8082                	ret
    if (ip == 0) return -1;
    80204824:	57fd                	li	a5,-1
    80204826:	74b2                	ld	s1,296(sp)
    80204828:	bfcd                	j	8020481a <sys_link+0x11a>

000000008020482a <sys_rename>:
{
    8020482a:	7165                	addi	sp,sp,-400
    8020482c:	e706                	sd	ra,392(sp)
    8020482e:	e322                	sd	s0,384(sp)
    80204830:	0b00                	addi	s0,sp,400
    if (argstr(0, oldp, MAXPATH) < 0 || argstr(1, newp, MAXPATH) < 0)
    80204832:	08000613          	li	a2,128
    80204836:	f6040593          	addi	a1,s0,-160
    8020483a:	4501                	li	a0,0
    8020483c:	00000097          	auipc	ra,0x0
    80204840:	a14080e7          	jalr	-1516(ra) # 80204250 <argstr>
    80204844:	18054d63          	bltz	a0,802049de <sys_rename+0x1b4>
    80204848:	08000613          	li	a2,128
    8020484c:	ee040593          	addi	a1,s0,-288
    80204850:	4505                	li	a0,1
    80204852:	00000097          	auipc	ra,0x0
    80204856:	9fe080e7          	jalr	-1538(ra) # 80204250 <argstr>
    8020485a:	18054463          	bltz	a0,802049e2 <sys_rename+0x1b8>
    8020485e:	fea6                	sd	s1,376(sp)
    struct inode *ip = namei(oldp);
    80204860:	f6040513          	addi	a0,s0,-160
    80204864:	00003097          	auipc	ra,0x3
    80204868:	0be080e7          	jalr	190(ra) # 80207922 <namei>
    8020486c:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    8020486e:	16050c63          	beqz	a0,802049e6 <sys_rename+0x1bc>
    80204872:	faca                	sd	s2,368(sp)
    ilock(ip);
    80204874:	00003097          	auipc	ra,0x3
    80204878:	81a080e7          	jalr	-2022(ra) # 8020708e <ilock>
    ip->nlink++;                      /* the soon-to-exist new link */
    8020487c:	04a4d783          	lhu	a5,74(s1)
    80204880:	2785                	addiw	a5,a5,1
    80204882:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80204886:	8526                	mv	a0,s1
    80204888:	00002097          	auipc	ra,0x2
    8020488c:	73a080e7          	jalr	1850(ra) # 80206fc2 <iupdate>
    iunlock(ip);
    80204890:	8526                	mv	a0,s1
    80204892:	00003097          	auipc	ra,0x3
    80204896:	8c2080e7          	jalr	-1854(ra) # 80207154 <iunlock>
    struct inode *newdp = nameiparent(newp, newname);
    8020489a:	ec040593          	addi	a1,s0,-320
    8020489e:	ee040513          	addi	a0,s0,-288
    802048a2:	00003097          	auipc	ra,0x3
    802048a6:	09e080e7          	jalr	158(ra) # 80207940 <nameiparent>
    802048aa:	892a                	mv	s2,a0
    if (newdp == 0) goto undo;
    802048ac:	c165                	beqz	a0,8020498c <sys_rename+0x162>
    ilock(newdp);
    802048ae:	00002097          	auipc	ra,0x2
    802048b2:	7e0080e7          	jalr	2016(ra) # 8020708e <ilock>
    if (newdp->dev != ip->dev || dirlink(newdp, newname, ip->inum) < 0) {
    802048b6:	00092703          	lw	a4,0(s2)
    802048ba:	409c                	lw	a5,0(s1)
    802048bc:	0cf71363          	bne	a4,a5,80204982 <sys_rename+0x158>
    802048c0:	40d0                	lw	a2,4(s1)
    802048c2:	ec040593          	addi	a1,s0,-320
    802048c6:	854a                	mv	a0,s2
    802048c8:	00003097          	auipc	ra,0x3
    802048cc:	fa0080e7          	jalr	-96(ra) # 80207868 <dirlink>
    802048d0:	0a054963          	bltz	a0,80204982 <sys_rename+0x158>
    iunlockput(newdp);
    802048d4:	854a                	mv	a0,s2
    802048d6:	00003097          	auipc	ra,0x3
    802048da:	a94080e7          	jalr	-1388(ra) # 8020736a <iunlockput>
    struct inode *olddp = nameiparent(oldp, oldname);
    802048de:	ea040593          	addi	a1,s0,-352
    802048e2:	f6040513          	addi	a0,s0,-160
    802048e6:	00003097          	auipc	ra,0x3
    802048ea:	05a080e7          	jalr	90(ra) # 80207940 <nameiparent>
    802048ee:	892a                	mv	s2,a0
    if (olddp == 0) goto drop;
    802048f0:	cd51                	beqz	a0,8020498c <sys_rename+0x162>
    ilock(olddp);
    802048f2:	00002097          	auipc	ra,0x2
    802048f6:	79c080e7          	jalr	1948(ra) # 8020708e <ilock>
    struct inode *found = dirlookup(olddp, oldname, &off);
    802048fa:	e9c40613          	addi	a2,s0,-356
    802048fe:	ea040593          	addi	a1,s0,-352
    80204902:	854a                	mv	a0,s2
    80204904:	00003097          	auipc	ra,0x3
    80204908:	d54080e7          	jalr	-684(ra) # 80207658 <dirlookup>
    if (found == 0) { iunlockput(olddp); goto drop; }
    8020490c:	c95d                	beqz	a0,802049c2 <sys_rename+0x198>
    iput(found);
    8020490e:	00003097          	auipc	ra,0x3
    80204912:	93e080e7          	jalr	-1730(ra) # 8020724c <iput>
    memset(&de, 0, sizeof(de));
    80204916:	02000613          	li	a2,32
    8020491a:	4581                	li	a1,0
    8020491c:	e7840513          	addi	a0,s0,-392
    80204920:	ffffc097          	auipc	ra,0xffffc
    80204924:	d9c080e7          	jalr	-612(ra) # 802006bc <memset>
    if (writei(olddp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80204928:	02000713          	li	a4,32
    8020492c:	e9c42683          	lw	a3,-356(s0)
    80204930:	e7840613          	addi	a2,s0,-392
    80204934:	4581                	li	a1,0
    80204936:	854a                	mv	a0,s2
    80204938:	00003097          	auipc	ra,0x3
    8020493c:	bb8080e7          	jalr	-1096(ra) # 802074f0 <writei>
    80204940:	02000793          	li	a5,32
    80204944:	08f51563          	bne	a0,a5,802049ce <sys_rename+0x1a4>
    iunlockput(olddp);
    80204948:	854a                	mv	a0,s2
    8020494a:	00003097          	auipc	ra,0x3
    8020494e:	a20080e7          	jalr	-1504(ra) # 8020736a <iunlockput>
    ilock(ip);
    80204952:	8526                	mv	a0,s1
    80204954:	00002097          	auipc	ra,0x2
    80204958:	73a080e7          	jalr	1850(ra) # 8020708e <ilock>
    ip->nlink--;
    8020495c:	04a4d783          	lhu	a5,74(s1)
    80204960:	37fd                	addiw	a5,a5,-1
    80204962:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80204966:	8526                	mv	a0,s1
    80204968:	00002097          	auipc	ra,0x2
    8020496c:	65a080e7          	jalr	1626(ra) # 80206fc2 <iupdate>
    iunlockput(ip);
    80204970:	8526                	mv	a0,s1
    80204972:	00003097          	auipc	ra,0x3
    80204976:	9f8080e7          	jalr	-1544(ra) # 8020736a <iunlockput>
    return 0;
    8020497a:	4501                	li	a0,0
    8020497c:	74f6                	ld	s1,376(sp)
    8020497e:	7956                	ld	s2,368(sp)
    80204980:	a82d                	j	802049ba <sys_rename+0x190>
        iunlockput(newdp);
    80204982:	854a                	mv	a0,s2
    80204984:	00003097          	auipc	ra,0x3
    80204988:	9e6080e7          	jalr	-1562(ra) # 8020736a <iunlockput>
    ilock(ip);
    8020498c:	8526                	mv	a0,s1
    8020498e:	00002097          	auipc	ra,0x2
    80204992:	700080e7          	jalr	1792(ra) # 8020708e <ilock>
    ip->nlink--;
    80204996:	04a4d783          	lhu	a5,74(s1)
    8020499a:	37fd                	addiw	a5,a5,-1
    8020499c:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    802049a0:	8526                	mv	a0,s1
    802049a2:	00002097          	auipc	ra,0x2
    802049a6:	620080e7          	jalr	1568(ra) # 80206fc2 <iupdate>
    iunlockput(ip);
    802049aa:	8526                	mv	a0,s1
    802049ac:	00003097          	auipc	ra,0x3
    802049b0:	9be080e7          	jalr	-1602(ra) # 8020736a <iunlockput>
    return -1;
    802049b4:	557d                	li	a0,-1
    802049b6:	74f6                	ld	s1,376(sp)
    802049b8:	7956                	ld	s2,368(sp)
}
    802049ba:	60ba                	ld	ra,392(sp)
    802049bc:	641a                	ld	s0,384(sp)
    802049be:	6159                	addi	sp,sp,400
    802049c0:	8082                	ret
    if (found == 0) { iunlockput(olddp); goto drop; }
    802049c2:	854a                	mv	a0,s2
    802049c4:	00003097          	auipc	ra,0x3
    802049c8:	9a6080e7          	jalr	-1626(ra) # 8020736a <iunlockput>
    802049cc:	b7c1                	j	8020498c <sys_rename+0x162>
        panic("rename: writei");
    802049ce:	00005517          	auipc	a0,0x5
    802049d2:	13250513          	addi	a0,a0,306 # 80209b00 <etext+0xb00>
    802049d6:	ffffc097          	auipc	ra,0xffffc
    802049da:	c40080e7          	jalr	-960(ra) # 80200616 <panic>
        return -1;
    802049de:	557d                	li	a0,-1
    802049e0:	bfe9                	j	802049ba <sys_rename+0x190>
    802049e2:	557d                	li	a0,-1
    802049e4:	bfd9                	j	802049ba <sys_rename+0x190>
    if (ip == 0) return -1;
    802049e6:	557d                	li	a0,-1
    802049e8:	74f6                	ld	s1,376(sp)
    802049ea:	bfc1                	j	802049ba <sys_rename+0x190>

00000000802049ec <sys_unlink>:
{
    802049ec:	712d                	addi	sp,sp,-288
    802049ee:	ee06                	sd	ra,280(sp)
    802049f0:	ea22                	sd	s0,272(sp)
    802049f2:	1200                	addi	s0,sp,288
    if (argstr(0, path, MAXPATH) < 0) return -1;
    802049f4:	08000613          	li	a2,128
    802049f8:	f3040593          	addi	a1,s0,-208
    802049fc:	4501                	li	a0,0
    802049fe:	00000097          	auipc	ra,0x0
    80204a02:	852080e7          	jalr	-1966(ra) # 80204250 <argstr>
    80204a06:	18054d63          	bltz	a0,80204ba0 <sys_unlink+0x1b4>
    80204a0a:	e626                	sd	s1,264(sp)
    struct inode *dp = nameiparent(path, name);
    80204a0c:	fb040593          	addi	a1,s0,-80
    80204a10:	f3040513          	addi	a0,s0,-208
    80204a14:	00003097          	auipc	ra,0x3
    80204a18:	f2c080e7          	jalr	-212(ra) # 80207940 <nameiparent>
    80204a1c:	84aa                	mv	s1,a0
    if (dp == 0) return -1;
    80204a1e:	18050363          	beqz	a0,80204ba4 <sys_unlink+0x1b8>
    ilock(dp);
    80204a22:	00002097          	auipc	ra,0x2
    80204a26:	66c080e7          	jalr	1644(ra) # 8020708e <ilock>
    if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0) goto bad;
    80204a2a:	00005597          	auipc	a1,0x5
    80204a2e:	0c658593          	addi	a1,a1,198 # 80209af0 <etext+0xaf0>
    80204a32:	fb040513          	addi	a0,s0,-80
    80204a36:	00003097          	auipc	ra,0x3
    80204a3a:	c08080e7          	jalr	-1016(ra) # 8020763e <namecmp>
    80204a3e:	14050663          	beqz	a0,80204b8a <sys_unlink+0x19e>
    80204a42:	00005597          	auipc	a1,0x5
    80204a46:	0b658593          	addi	a1,a1,182 # 80209af8 <etext+0xaf8>
    80204a4a:	fb040513          	addi	a0,s0,-80
    80204a4e:	00003097          	auipc	ra,0x3
    80204a52:	bf0080e7          	jalr	-1040(ra) # 8020763e <namecmp>
    80204a56:	12050a63          	beqz	a0,80204b8a <sys_unlink+0x19e>
    80204a5a:	e24a                	sd	s2,256(sp)
    struct inode *ip = dirlookup(dp, name, &off);
    80204a5c:	f2c40613          	addi	a2,s0,-212
    80204a60:	fb040593          	addi	a1,s0,-80
    80204a64:	8526                	mv	a0,s1
    80204a66:	00003097          	auipc	ra,0x3
    80204a6a:	bf2080e7          	jalr	-1038(ra) # 80207658 <dirlookup>
    80204a6e:	892a                	mv	s2,a0
    if (ip == 0) goto bad;
    80204a70:	10050c63          	beqz	a0,80204b88 <sys_unlink+0x19c>
    ilock(ip);                        /* lock order: parent, then child */
    80204a74:	00002097          	auipc	ra,0x2
    80204a78:	61a080e7          	jalr	1562(ra) # 8020708e <ilock>
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80204a7c:	04a95783          	lhu	a5,74(s2)
    80204a80:	cfa5                	beqz	a5,80204af8 <sys_unlink+0x10c>
    if (ip->type == T_DIR && !isdirempty(ip)) {
    80204a82:	04495703          	lhu	a4,68(s2)
    80204a86:	4785                	li	a5,1
    80204a88:	08f70163          	beq	a4,a5,80204b0a <sys_unlink+0x11e>
    memset(&de, 0, sizeof(de));
    80204a8c:	02000613          	li	a2,32
    80204a90:	4581                	li	a1,0
    80204a92:	f0840513          	addi	a0,s0,-248
    80204a96:	ffffc097          	auipc	ra,0xffffc
    80204a9a:	c26080e7          	jalr	-986(ra) # 802006bc <memset>
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80204a9e:	02000713          	li	a4,32
    80204aa2:	f2c42683          	lw	a3,-212(s0)
    80204aa6:	f0840613          	addi	a2,s0,-248
    80204aaa:	4581                	li	a1,0
    80204aac:	8526                	mv	a0,s1
    80204aae:	00003097          	auipc	ra,0x3
    80204ab2:	a42080e7          	jalr	-1470(ra) # 802074f0 <writei>
    80204ab6:	02000793          	li	a5,32
    80204aba:	0af51363          	bne	a0,a5,80204b60 <sys_unlink+0x174>
    if (ip->type == T_DIR) {
    80204abe:	04495703          	lhu	a4,68(s2)
    80204ac2:	4785                	li	a5,1
    80204ac4:	0af70763          	beq	a4,a5,80204b72 <sys_unlink+0x186>
    iunlockput(dp);
    80204ac8:	8526                	mv	a0,s1
    80204aca:	00003097          	auipc	ra,0x3
    80204ace:	8a0080e7          	jalr	-1888(ra) # 8020736a <iunlockput>
    ip->nlink--;
    80204ad2:	04a95783          	lhu	a5,74(s2)
    80204ad6:	37fd                	addiw	a5,a5,-1
    80204ad8:	04f91523          	sh	a5,74(s2)
    iupdate(ip);
    80204adc:	854a                	mv	a0,s2
    80204ade:	00002097          	auipc	ra,0x2
    80204ae2:	4e4080e7          	jalr	1252(ra) # 80206fc2 <iupdate>
    iunlockput(ip);                   /* data freed in iput if last ref+link */
    80204ae6:	854a                	mv	a0,s2
    80204ae8:	00003097          	auipc	ra,0x3
    80204aec:	882080e7          	jalr	-1918(ra) # 8020736a <iunlockput>
    return 0;
    80204af0:	4501                	li	a0,0
    80204af2:	64b2                	ld	s1,264(sp)
    80204af4:	6912                	ld	s2,256(sp)
    80204af6:	a04d                	j	80204b98 <sys_unlink+0x1ac>
    80204af8:	fdce                	sd	s3,248(sp)
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80204afa:	00005517          	auipc	a0,0x5
    80204afe:	01650513          	addi	a0,a0,22 # 80209b10 <etext+0xb10>
    80204b02:	ffffc097          	auipc	ra,0xffffc
    80204b06:	b14080e7          	jalr	-1260(ra) # 80200616 <panic>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80204b0a:	04c92703          	lw	a4,76(s2)
    80204b0e:	04000793          	li	a5,64
    80204b12:	f6e7fde3          	bgeu	a5,a4,80204a8c <sys_unlink+0xa0>
    80204b16:	fdce                	sd	s3,248(sp)
    80204b18:	04000993          	li	s3,64
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80204b1c:	02000713          	li	a4,32
    80204b20:	86ce                	mv	a3,s3
    80204b22:	ee840613          	addi	a2,s0,-280
    80204b26:	4581                	li	a1,0
    80204b28:	854a                	mv	a0,s2
    80204b2a:	00003097          	auipc	ra,0x3
    80204b2e:	892080e7          	jalr	-1902(ra) # 802073bc <readi>
    80204b32:	02000793          	li	a5,32
    80204b36:	00f51d63          	bne	a0,a5,80204b50 <sys_unlink+0x164>
        if (de.inum != 0) return 0;
    80204b3a:	ee842783          	lw	a5,-280(s0)
    80204b3e:	e7b5                	bnez	a5,80204baa <sys_unlink+0x1be>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80204b40:	0209899b          	addiw	s3,s3,32
    80204b44:	04c92783          	lw	a5,76(s2)
    80204b48:	fcf9eae3          	bltu	s3,a5,80204b1c <sys_unlink+0x130>
    80204b4c:	79ee                	ld	s3,248(sp)
    80204b4e:	bf3d                	j	80204a8c <sys_unlink+0xa0>
            panic("isdirempty: short read");
    80204b50:	00005517          	auipc	a0,0x5
    80204b54:	fd850513          	addi	a0,a0,-40 # 80209b28 <etext+0xb28>
    80204b58:	ffffc097          	auipc	ra,0xffffc
    80204b5c:	abe080e7          	jalr	-1346(ra) # 80200616 <panic>
    80204b60:	fdce                	sd	s3,248(sp)
        panic("unlink: writei");
    80204b62:	00005517          	auipc	a0,0x5
    80204b66:	fde50513          	addi	a0,a0,-34 # 80209b40 <etext+0xb40>
    80204b6a:	ffffc097          	auipc	ra,0xffffc
    80204b6e:	aac080e7          	jalr	-1364(ra) # 80200616 <panic>
        dp->nlink--;                  /* the child's ".." no longer counts */
    80204b72:	04a4d783          	lhu	a5,74(s1)
    80204b76:	37fd                	addiw	a5,a5,-1
    80204b78:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80204b7c:	8526                	mv	a0,s1
    80204b7e:	00002097          	auipc	ra,0x2
    80204b82:	444080e7          	jalr	1092(ra) # 80206fc2 <iupdate>
    80204b86:	b789                	j	80204ac8 <sys_unlink+0xdc>
    80204b88:	6912                	ld	s2,256(sp)
    iunlockput(dp);
    80204b8a:	8526                	mv	a0,s1
    80204b8c:	00002097          	auipc	ra,0x2
    80204b90:	7de080e7          	jalr	2014(ra) # 8020736a <iunlockput>
    return -1;
    80204b94:	557d                	li	a0,-1
    80204b96:	64b2                	ld	s1,264(sp)
}
    80204b98:	60f2                	ld	ra,280(sp)
    80204b9a:	6452                	ld	s0,272(sp)
    80204b9c:	6115                	addi	sp,sp,288
    80204b9e:	8082                	ret
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204ba0:	557d                	li	a0,-1
    80204ba2:	bfdd                	j	80204b98 <sys_unlink+0x1ac>
    if (dp == 0) return -1;
    80204ba4:	557d                	li	a0,-1
    80204ba6:	64b2                	ld	s1,264(sp)
    80204ba8:	bfc5                	j	80204b98 <sys_unlink+0x1ac>
        iunlockput(ip);
    80204baa:	854a                	mv	a0,s2
    80204bac:	00002097          	auipc	ra,0x2
    80204bb0:	7be080e7          	jalr	1982(ra) # 8020736a <iunlockput>
        goto bad;
    80204bb4:	6912                	ld	s2,256(sp)
    80204bb6:	79ee                	ld	s3,248(sp)
    80204bb8:	bfc9                	j	80204b8a <sys_unlink+0x19e>

0000000080204bba <sys_open>:

uint64 sys_open(void)
{
    80204bba:	7131                	addi	sp,sp,-192
    80204bbc:	fd06                	sd	ra,184(sp)
    80204bbe:	f922                	sd	s0,176(sp)
    80204bc0:	0180                	addi	s0,sp,192
    char path[MAXPATH];
    int omode;
    argint(1, &omode);
    80204bc2:	f4c40593          	addi	a1,s0,-180
    80204bc6:	4505                	li	a0,1
    80204bc8:	fffff097          	auipc	ra,0xfffff
    80204bcc:	f20080e7          	jalr	-224(ra) # 80203ae8 <argint>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204bd0:	08000613          	li	a2,128
    80204bd4:	f5040593          	addi	a1,s0,-176
    80204bd8:	4501                	li	a0,0
    80204bda:	fffff097          	auipc	ra,0xfffff
    80204bde:	676080e7          	jalr	1654(ra) # 80204250 <argstr>
    80204be2:	12054b63          	bltz	a0,80204d18 <sys_open+0x15e>
    80204be6:	f526                	sd	s1,168(sp)

    struct inode *ip;
    if (omode & O_CREATE) {
    80204be8:	f4c42783          	lw	a5,-180(s0)
    80204bec:	2007f793          	andi	a5,a5,512
    80204bf0:	c7c5                	beqz	a5,80204c98 <sys_open+0xde>
        ip = create(path, T_FILE, 0, 0);
    80204bf2:	4681                	li	a3,0
    80204bf4:	4601                	li	a2,0
    80204bf6:	4589                	li	a1,2
    80204bf8:	f5040513          	addi	a0,s0,-176
    80204bfc:	fffff097          	auipc	ra,0xfffff
    80204c00:	7ce080e7          	jalr	1998(ra) # 802043ca <create>
    80204c04:	84aa                	mv	s1,a0
        if (ip == 0) return -1;
    80204c06:	10050b63          	beqz	a0,80204d1c <sys_open+0x162>
        if (ip->type == T_DIR && omode != O_RDONLY) {
            iunlockput(ip);
            return -1;
        }
    }
    if (ip->type == T_DEV && (ip->major < 0 || ip->major >= NDEV)) {
    80204c0a:	0444d703          	lhu	a4,68(s1)
    80204c0e:	478d                	li	a5,3
    80204c10:	00f71763          	bne	a4,a5,80204c1e <sys_open+0x64>
    80204c14:	0464d703          	lhu	a4,70(s1)
    80204c18:	47a5                	li	a5,9
    80204c1a:	0ae7eb63          	bltu	a5,a4,80204cd0 <sys_open+0x116>
    80204c1e:	f14a                	sd	s2,160(sp)
        iunlockput(ip);
        return -1;
    }

    struct file *f = filealloc();
    80204c20:	00003097          	auipc	ra,0x3
    80204c24:	d64080e7          	jalr	-668(ra) # 80207984 <filealloc>
    80204c28:	892a                	mv	s2,a0
    int fd;
    if (f == 0 || (fd = fdalloc(f)) < 0) {
    80204c2a:	c169                	beqz	a0,80204cec <sys_open+0x132>
    80204c2c:	ed4e                	sd	s3,152(sp)
    80204c2e:	fffff097          	auipc	ra,0xfffff
    80204c32:	75a080e7          	jalr	1882(ra) # 80204388 <fdalloc>
    80204c36:	89aa                	mv	s3,a0
    80204c38:	0a054463          	bltz	a0,80204ce0 <sys_open+0x126>
        if (f) fileclose(f);
        iunlockput(ip);
        return -1;
    }

    if (ip->type == T_DEV) {
    80204c3c:	0444d703          	lhu	a4,68(s1)
    80204c40:	478d                	li	a5,3
    80204c42:	0af70e63          	beq	a4,a5,80204cfe <sys_open+0x144>
        f->type  = FD_DEVICE;
        f->major = ip->major;
    } else {
        f->type = FD_INODE;
    80204c46:	4789                	li	a5,2
    80204c48:	00f92023          	sw	a5,0(s2)
        f->off  = 0;
    80204c4c:	02092023          	sw	zero,32(s2)
    }
    f->ip       = ip;
    80204c50:	00993c23          	sd	s1,24(s2)
    f->readable = !(omode & O_WRONLY);
    80204c54:	f4c42783          	lw	a5,-180(s0)
    80204c58:	0017c713          	xori	a4,a5,1
    80204c5c:	8b05                	andi	a4,a4,1
    80204c5e:	00e90423          	sb	a4,8(s2)
    f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80204c62:	0037f713          	andi	a4,a5,3
    80204c66:	00e03733          	snez	a4,a4
    80204c6a:	00e904a3          	sb	a4,9(s2)

    if ((omode & O_TRUNC) && ip->type == T_FILE)
    80204c6e:	4007f793          	andi	a5,a5,1024
    80204c72:	c791                	beqz	a5,80204c7e <sys_open+0xc4>
    80204c74:	0444d703          	lhu	a4,68(s1)
    80204c78:	4789                	li	a5,2
    80204c7a:	08f70963          	beq	a4,a5,80204d0c <sys_open+0x152>
        itrunc(ip);

    iunlock(ip);
    80204c7e:	8526                	mv	a0,s1
    80204c80:	00002097          	auipc	ra,0x2
    80204c84:	4d4080e7          	jalr	1236(ra) # 80207154 <iunlock>
    return fd;
    80204c88:	854e                	mv	a0,s3
    80204c8a:	74aa                	ld	s1,168(sp)
    80204c8c:	790a                	ld	s2,160(sp)
    80204c8e:	69ea                	ld	s3,152(sp)
}
    80204c90:	70ea                	ld	ra,184(sp)
    80204c92:	744a                	ld	s0,176(sp)
    80204c94:	6129                	addi	sp,sp,192
    80204c96:	8082                	ret
        if ((ip = namei(path)) == 0) return -1;
    80204c98:	f5040513          	addi	a0,s0,-176
    80204c9c:	00003097          	auipc	ra,0x3
    80204ca0:	c86080e7          	jalr	-890(ra) # 80207922 <namei>
    80204ca4:	84aa                	mv	s1,a0
    80204ca6:	cd35                	beqz	a0,80204d22 <sys_open+0x168>
        ilock(ip);
    80204ca8:	00002097          	auipc	ra,0x2
    80204cac:	3e6080e7          	jalr	998(ra) # 8020708e <ilock>
        if (ip->type == T_DIR && omode != O_RDONLY) {
    80204cb0:	0444d703          	lhu	a4,68(s1)
    80204cb4:	4785                	li	a5,1
    80204cb6:	f4f71ae3          	bne	a4,a5,80204c0a <sys_open+0x50>
    80204cba:	f4c42783          	lw	a5,-180(s0)
    80204cbe:	d3a5                	beqz	a5,80204c1e <sys_open+0x64>
            iunlockput(ip);
    80204cc0:	8526                	mv	a0,s1
    80204cc2:	00002097          	auipc	ra,0x2
    80204cc6:	6a8080e7          	jalr	1704(ra) # 8020736a <iunlockput>
            return -1;
    80204cca:	557d                	li	a0,-1
    80204ccc:	74aa                	ld	s1,168(sp)
    80204cce:	b7c9                	j	80204c90 <sys_open+0xd6>
        iunlockput(ip);
    80204cd0:	8526                	mv	a0,s1
    80204cd2:	00002097          	auipc	ra,0x2
    80204cd6:	698080e7          	jalr	1688(ra) # 8020736a <iunlockput>
        return -1;
    80204cda:	557d                	li	a0,-1
    80204cdc:	74aa                	ld	s1,168(sp)
    80204cde:	bf4d                	j	80204c90 <sys_open+0xd6>
        if (f) fileclose(f);
    80204ce0:	854a                	mv	a0,s2
    80204ce2:	00003097          	auipc	ra,0x3
    80204ce6:	d5e080e7          	jalr	-674(ra) # 80207a40 <fileclose>
    80204cea:	69ea                	ld	s3,152(sp)
        iunlockput(ip);
    80204cec:	8526                	mv	a0,s1
    80204cee:	00002097          	auipc	ra,0x2
    80204cf2:	67c080e7          	jalr	1660(ra) # 8020736a <iunlockput>
        return -1;
    80204cf6:	557d                	li	a0,-1
    80204cf8:	74aa                	ld	s1,168(sp)
    80204cfa:	790a                	ld	s2,160(sp)
    80204cfc:	bf51                	j	80204c90 <sys_open+0xd6>
        f->type  = FD_DEVICE;
    80204cfe:	00f92023          	sw	a5,0(s2)
        f->major = ip->major;
    80204d02:	0464d783          	lhu	a5,70(s1)
    80204d06:	02f91223          	sh	a5,36(s2)
    80204d0a:	b799                	j	80204c50 <sys_open+0x96>
        itrunc(ip);
    80204d0c:	8526                	mv	a0,s1
    80204d0e:	00002097          	auipc	ra,0x2
    80204d12:	492080e7          	jalr	1170(ra) # 802071a0 <itrunc>
    80204d16:	b7a5                	j	80204c7e <sys_open+0xc4>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204d18:	557d                	li	a0,-1
    80204d1a:	bf9d                	j	80204c90 <sys_open+0xd6>
        if (ip == 0) return -1;
    80204d1c:	557d                	li	a0,-1
    80204d1e:	74aa                	ld	s1,168(sp)
    80204d20:	bf85                	j	80204c90 <sys_open+0xd6>
        if ((ip = namei(path)) == 0) return -1;
    80204d22:	557d                	li	a0,-1
    80204d24:	74aa                	ld	s1,168(sp)
    80204d26:	b7ad                	j	80204c90 <sys_open+0xd6>

0000000080204d28 <sys_mkdir>:

uint64 sys_mkdir(void)
{
    80204d28:	7175                	addi	sp,sp,-144
    80204d2a:	e506                	sd	ra,136(sp)
    80204d2c:	e122                	sd	s0,128(sp)
    80204d2e:	0900                	addi	s0,sp,144
    char path[MAXPATH];
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204d30:	08000613          	li	a2,128
    80204d34:	f7040593          	addi	a1,s0,-144
    80204d38:	4501                	li	a0,0
    80204d3a:	fffff097          	auipc	ra,0xfffff
    80204d3e:	516080e7          	jalr	1302(ra) # 80204250 <argstr>
    80204d42:	57fd                	li	a5,-1
    80204d44:	02054163          	bltz	a0,80204d66 <sys_mkdir+0x3e>
    struct inode *ip = create(path, T_DIR, 0, 0);
    80204d48:	4681                	li	a3,0
    80204d4a:	4601                	li	a2,0
    80204d4c:	4585                	li	a1,1
    80204d4e:	f7040513          	addi	a0,s0,-144
    80204d52:	fffff097          	auipc	ra,0xfffff
    80204d56:	678080e7          	jalr	1656(ra) # 802043ca <create>
    if (ip == 0) return -1;
    80204d5a:	c919                	beqz	a0,80204d70 <sys_mkdir+0x48>
    iunlockput(ip);
    80204d5c:	00002097          	auipc	ra,0x2
    80204d60:	60e080e7          	jalr	1550(ra) # 8020736a <iunlockput>
    return 0;
    80204d64:	4781                	li	a5,0
}
    80204d66:	853e                	mv	a0,a5
    80204d68:	60aa                	ld	ra,136(sp)
    80204d6a:	640a                	ld	s0,128(sp)
    80204d6c:	6149                	addi	sp,sp,144
    80204d6e:	8082                	ret
    if (ip == 0) return -1;
    80204d70:	57fd                	li	a5,-1
    80204d72:	bfd5                	j	80204d66 <sys_mkdir+0x3e>

0000000080204d74 <sys_chdir>:

uint64 sys_chdir(void)
{
    80204d74:	7135                	addi	sp,sp,-160
    80204d76:	ed06                	sd	ra,152(sp)
    80204d78:	e922                	sd	s0,144(sp)
    80204d7a:	e14a                	sd	s2,128(sp)
    80204d7c:	1100                	addi	s0,sp,160
    char path[MAXPATH];
    struct proc *p = myproc();
    80204d7e:	ffffd097          	auipc	ra,0xffffd
    80204d82:	b72080e7          	jalr	-1166(ra) # 802018f0 <myproc>
    80204d86:	892a                	mv	s2,a0
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204d88:	08000613          	li	a2,128
    80204d8c:	f6040593          	addi	a1,s0,-160
    80204d90:	4501                	li	a0,0
    80204d92:	fffff097          	auipc	ra,0xfffff
    80204d96:	4be080e7          	jalr	1214(ra) # 80204250 <argstr>
    80204d9a:	57fd                	li	a5,-1
    80204d9c:	04054363          	bltz	a0,80204de2 <sys_chdir+0x6e>
    80204da0:	e526                	sd	s1,136(sp)
    struct inode *ip = namei(path);
    80204da2:	f6040513          	addi	a0,s0,-160
    80204da6:	00003097          	auipc	ra,0x3
    80204daa:	b7c080e7          	jalr	-1156(ra) # 80207922 <namei>
    80204dae:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80204db0:	c539                	beqz	a0,80204dfe <sys_chdir+0x8a>
    ilock(ip);
    80204db2:	00002097          	auipc	ra,0x2
    80204db6:	2dc080e7          	jalr	732(ra) # 8020708e <ilock>
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80204dba:	0444d703          	lhu	a4,68(s1)
    80204dbe:	4785                	li	a5,1
    80204dc0:	02f71763          	bne	a4,a5,80204dee <sys_chdir+0x7a>
    iunlock(ip);
    80204dc4:	8526                	mv	a0,s1
    80204dc6:	00002097          	auipc	ra,0x2
    80204dca:	38e080e7          	jalr	910(ra) # 80207154 <iunlock>
    iput(p->cwd);
    80204dce:	15093503          	ld	a0,336(s2)
    80204dd2:	00002097          	auipc	ra,0x2
    80204dd6:	47a080e7          	jalr	1146(ra) # 8020724c <iput>
    p->cwd = ip;
    80204dda:	14993823          	sd	s1,336(s2)
    return 0;
    80204dde:	4781                	li	a5,0
    80204de0:	64aa                	ld	s1,136(sp)
}
    80204de2:	853e                	mv	a0,a5
    80204de4:	60ea                	ld	ra,152(sp)
    80204de6:	644a                	ld	s0,144(sp)
    80204de8:	690a                	ld	s2,128(sp)
    80204dea:	610d                	addi	sp,sp,160
    80204dec:	8082                	ret
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80204dee:	8526                	mv	a0,s1
    80204df0:	00002097          	auipc	ra,0x2
    80204df4:	57a080e7          	jalr	1402(ra) # 8020736a <iunlockput>
    80204df8:	57fd                	li	a5,-1
    80204dfa:	64aa                	ld	s1,136(sp)
    80204dfc:	b7dd                	j	80204de2 <sys_chdir+0x6e>
    if (ip == 0) return -1;
    80204dfe:	57fd                	li	a5,-1
    80204e00:	64aa                	ld	s1,136(sp)
    80204e02:	b7c5                	j	80204de2 <sys_chdir+0x6e>

0000000080204e04 <sys_pipe>:

uint64 sys_pipe(void)
{
    80204e04:	7139                	addi	sp,sp,-64
    80204e06:	fc06                	sd	ra,56(sp)
    80204e08:	f822                	sd	s0,48(sp)
    80204e0a:	0080                	addi	s0,sp,64
    uint64 fdarray;                   /* user pointer to int[2] */
    argaddr(0, &fdarray);
    80204e0c:	fd840593          	addi	a1,s0,-40
    80204e10:	4501                	li	a0,0
    80204e12:	fffff097          	auipc	ra,0xfffff
    80204e16:	e30080e7          	jalr	-464(ra) # 80203c42 <argaddr>

    struct file *rf, *wf;
    if (pipealloc(&rf, &wf) < 0) return -1;
    80204e1a:	fc840593          	addi	a1,s0,-56
    80204e1e:	fd040513          	addi	a0,s0,-48
    80204e22:	00003097          	auipc	ra,0x3
    80204e26:	f0e080e7          	jalr	-242(ra) # 80207d30 <pipealloc>
    80204e2a:	57fd                	li	a5,-1
    80204e2c:	0a054463          	bltz	a0,80204ed4 <sys_pipe+0xd0>
    80204e30:	f426                	sd	s1,40(sp)

    struct proc *p = myproc();
    80204e32:	ffffd097          	auipc	ra,0xffffd
    80204e36:	abe080e7          	jalr	-1346(ra) # 802018f0 <myproc>
    80204e3a:	84aa                	mv	s1,a0
    int fd0 = -1, fd1 = -1;
    80204e3c:	57fd                	li	a5,-1
    80204e3e:	fcf42223          	sw	a5,-60(s0)
    80204e42:	fcf42023          	sw	a5,-64(s0)
    if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80204e46:	fd043503          	ld	a0,-48(s0)
    80204e4a:	fffff097          	auipc	ra,0xfffff
    80204e4e:	53e080e7          	jalr	1342(ra) # 80204388 <fdalloc>
    80204e52:	fca42223          	sw	a0,-60(s0)
    80204e56:	06054163          	bltz	a0,80204eb8 <sys_pipe+0xb4>
    80204e5a:	fc843503          	ld	a0,-56(s0)
    80204e5e:	fffff097          	auipc	ra,0xfffff
    80204e62:	52a080e7          	jalr	1322(ra) # 80204388 <fdalloc>
    80204e66:	fca42023          	sw	a0,-64(s0)
    80204e6a:	02054e63          	bltz	a0,80204ea6 <sys_pipe+0xa2>
        if (fd0 >= 0) p->ofile[fd0] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80204e6e:	4691                	li	a3,4
    80204e70:	fc440613          	addi	a2,s0,-60
    80204e74:	fd843583          	ld	a1,-40(s0)
    80204e78:	68a8                	ld	a0,80(s1)
    80204e7a:	ffffe097          	auipc	ra,0xffffe
    80204e7e:	5e0080e7          	jalr	1504(ra) # 8020345a <copyout>
    80204e82:	04054e63          	bltz	a0,80204ede <sys_pipe+0xda>
        copyout(p->pagetable, fdarray + sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0) {
    80204e86:	4691                	li	a3,4
    80204e88:	fc040613          	addi	a2,s0,-64
    80204e8c:	fd843583          	ld	a1,-40(s0)
    80204e90:	0591                	addi	a1,a1,4
    80204e92:	68a8                	ld	a0,80(s1)
    80204e94:	ffffe097          	auipc	ra,0xffffe
    80204e98:	5c6080e7          	jalr	1478(ra) # 8020345a <copyout>
        p->ofile[fd1] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    return 0;
    80204e9c:	4781                	li	a5,0
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80204e9e:	04054063          	bltz	a0,80204ede <sys_pipe+0xda>
    80204ea2:	74a2                	ld	s1,40(sp)
    80204ea4:	a805                	j	80204ed4 <sys_pipe+0xd0>
        if (fd0 >= 0) p->ofile[fd0] = 0;
    80204ea6:	fc442783          	lw	a5,-60(s0)
    80204eaa:	0007c763          	bltz	a5,80204eb8 <sys_pipe+0xb4>
    80204eae:	07e9                	addi	a5,a5,26
    80204eb0:	078e                	slli	a5,a5,0x3
    80204eb2:	97a6                	add	a5,a5,s1
    80204eb4:	0007b023          	sd	zero,0(a5)
        fileclose(rf);
    80204eb8:	fd043503          	ld	a0,-48(s0)
    80204ebc:	00003097          	auipc	ra,0x3
    80204ec0:	b84080e7          	jalr	-1148(ra) # 80207a40 <fileclose>
        fileclose(wf);
    80204ec4:	fc843503          	ld	a0,-56(s0)
    80204ec8:	00003097          	auipc	ra,0x3
    80204ecc:	b78080e7          	jalr	-1160(ra) # 80207a40 <fileclose>
        return -1;
    80204ed0:	57fd                	li	a5,-1
    80204ed2:	74a2                	ld	s1,40(sp)
}
    80204ed4:	853e                	mv	a0,a5
    80204ed6:	70e2                	ld	ra,56(sp)
    80204ed8:	7442                	ld	s0,48(sp)
    80204eda:	6121                	addi	sp,sp,64
    80204edc:	8082                	ret
        p->ofile[fd0] = 0;
    80204ede:	fc442783          	lw	a5,-60(s0)
    80204ee2:	07e9                	addi	a5,a5,26
    80204ee4:	078e                	slli	a5,a5,0x3
    80204ee6:	97a6                	add	a5,a5,s1
    80204ee8:	0007b023          	sd	zero,0(a5)
        p->ofile[fd1] = 0;
    80204eec:	fc042783          	lw	a5,-64(s0)
    80204ef0:	07e9                	addi	a5,a5,26
    80204ef2:	078e                	slli	a5,a5,0x3
    80204ef4:	94be                	add	s1,s1,a5
    80204ef6:	0004b023          	sd	zero,0(s1)
        fileclose(rf);
    80204efa:	fd043503          	ld	a0,-48(s0)
    80204efe:	00003097          	auipc	ra,0x3
    80204f02:	b42080e7          	jalr	-1214(ra) # 80207a40 <fileclose>
        fileclose(wf);
    80204f06:	fc843503          	ld	a0,-56(s0)
    80204f0a:	00003097          	auipc	ra,0x3
    80204f0e:	b36080e7          	jalr	-1226(ra) # 80207a40 <fileclose>
        return -1;
    80204f12:	57fd                	li	a5,-1
    80204f14:	74a2                	ld	s1,40(sp)
    80204f16:	bf7d                	j	80204ed4 <sys_pipe+0xd0>

0000000080204f18 <sys_exec>:

uint64 sys_exec(void)
{
    80204f18:	7129                	addi	sp,sp,-320
    80204f1a:	fe06                	sd	ra,312(sp)
    80204f1c:	fa22                	sd	s0,304(sp)
    80204f1e:	0280                	addi	s0,sp,320
    char path[MAXPATH];
    uint64 uargv, uarg;
    char *argv[MAXARG];

    if (argstr(0, path, MAXPATH) < 0) return -1;
    80204f20:	08000613          	li	a2,128
    80204f24:	f5040593          	addi	a1,s0,-176
    80204f28:	4501                	li	a0,0
    80204f2a:	fffff097          	auipc	ra,0xfffff
    80204f2e:	326080e7          	jalr	806(ra) # 80204250 <argstr>
    80204f32:	87aa                	mv	a5,a0
    80204f34:	557d                	li	a0,-1
    80204f36:	0a07c763          	bltz	a5,80204fe4 <sys_exec+0xcc>
    80204f3a:	f626                	sd	s1,296(sp)
    80204f3c:	f24a                	sd	s2,288(sp)
    80204f3e:	ee4e                	sd	s3,280(sp)
    80204f40:	ea52                	sd	s4,272(sp)
    argaddr(1, &uargv);
    80204f42:	f4840593          	addi	a1,s0,-184
    80204f46:	4505                	li	a0,1
    80204f48:	fffff097          	auipc	ra,0xfffff
    80204f4c:	cfa080e7          	jalr	-774(ra) # 80203c42 <argaddr>
    memset(argv, 0, sizeof(argv));
    80204f50:	08000613          	li	a2,128
    80204f54:	4581                	li	a1,0
    80204f56:	ec040513          	addi	a0,s0,-320
    80204f5a:	ffffb097          	auipc	ra,0xffffb
    80204f5e:	762080e7          	jalr	1890(ra) # 802006bc <memset>

    int ret = -1;
    for (int i = 0; ; i++) {
        if (i >= MAXARG) goto out;
    80204f62:	ec040493          	addi	s1,s0,-320
    memset(argv, 0, sizeof(argv));
    80204f66:	89a6                	mv	s3,s1
    80204f68:	4901                	li	s2,0
        if (i >= MAXARG) goto out;
    80204f6a:	4a41                	li	s4,16
        if (copyin(myproc()->pagetable, (char *)&uarg,
    80204f6c:	ffffd097          	auipc	ra,0xffffd
    80204f70:	984080e7          	jalr	-1660(ra) # 802018f0 <myproc>
    80204f74:	00391613          	slli	a2,s2,0x3
    80204f78:	46a1                	li	a3,8
    80204f7a:	f4843783          	ld	a5,-184(s0)
    80204f7e:	963e                	add	a2,a2,a5
    80204f80:	f4040593          	addi	a1,s0,-192
    80204f84:	6928                	ld	a0,80(a0)
    80204f86:	ffffe097          	auipc	ra,0xffffe
    80204f8a:	5fa080e7          	jalr	1530(ra) # 80203580 <copyin>
    80204f8e:	08054163          	bltz	a0,80205010 <sys_exec+0xf8>
                   uargv + sizeof(uint64) * i, sizeof(uint64)) < 0) goto out;
        if (uarg == 0) { argv[i] = 0; break; }
    80204f92:	f4043783          	ld	a5,-192(s0)
    80204f96:	cbb9                	beqz	a5,80204fec <sys_exec+0xd4>
        argv[i] = palloc();
    80204f98:	ffffc097          	auipc	ra,0xffffc
    80204f9c:	14e080e7          	jalr	334(ra) # 802010e6 <palloc>
    80204fa0:	85aa                	mv	a1,a0
    80204fa2:	00a9b023          	sd	a0,0(s3)
        if (!argv[i]) goto out;
    80204fa6:	c53d                	beqz	a0,80205014 <sys_exec+0xfc>
        if (fetchstr(uarg, argv[i], PGSIZE) < 0) goto out;
    80204fa8:	6605                	lui	a2,0x1
    80204faa:	f4043503          	ld	a0,-192(s0)
    80204fae:	fffff097          	auipc	ra,0xfffff
    80204fb2:	256080e7          	jalr	598(ra) # 80204204 <fetchstr>
    80204fb6:	06054163          	bltz	a0,80205018 <sys_exec+0x100>
        if (i >= MAXARG) goto out;
    80204fba:	0905                	addi	s2,s2,1
    80204fbc:	09a1                	addi	s3,s3,8
    80204fbe:	fb4917e3          	bne	s2,s4,80204f6c <sys_exec+0x54>
    int ret = -1;
    80204fc2:	59fd                	li	s3,-1
    }
    ret = exec(path, argv);
out:
    /* Free EVERY page we allocated, on every path - the original version of
     * this function leaked argv pages on a bad pointer. Found in the audit. */
    for (int i = 0; i < MAXARG && argv[i]; i++) pfree(argv[i]);
    80204fc4:	f4040913          	addi	s2,s0,-192
    80204fc8:	6088                	ld	a0,0(s1)
    80204fca:	c901                	beqz	a0,80204fda <sys_exec+0xc2>
    80204fcc:	ffffc097          	auipc	ra,0xffffc
    80204fd0:	258080e7          	jalr	600(ra) # 80201224 <pfree>
    80204fd4:	04a1                	addi	s1,s1,8
    80204fd6:	ff2499e3          	bne	s1,s2,80204fc8 <sys_exec+0xb0>
    return ret;
    80204fda:	854e                	mv	a0,s3
    80204fdc:	74b2                	ld	s1,296(sp)
    80204fde:	7912                	ld	s2,288(sp)
    80204fe0:	69f2                	ld	s3,280(sp)
    80204fe2:	6a52                	ld	s4,272(sp)
}
    80204fe4:	70f2                	ld	ra,312(sp)
    80204fe6:	7452                	ld	s0,304(sp)
    80204fe8:	6131                	addi	sp,sp,320
    80204fea:	8082                	ret
        if (uarg == 0) { argv[i] = 0; break; }
    80204fec:	0009079b          	sext.w	a5,s2
    80204ff0:	078e                	slli	a5,a5,0x3
    80204ff2:	fd078793          	addi	a5,a5,-48
    80204ff6:	97a2                	add	a5,a5,s0
    80204ff8:	ee07b823          	sd	zero,-272(a5)
    ret = exec(path, argv);
    80204ffc:	ec040593          	addi	a1,s0,-320
    80205000:	f5040513          	addi	a0,s0,-176
    80205004:	00001097          	auipc	ra,0x1
    80205008:	3b8080e7          	jalr	952(ra) # 802063bc <exec>
    8020500c:	89aa                	mv	s3,a0
    8020500e:	bf5d                	j	80204fc4 <sys_exec+0xac>
    int ret = -1;
    80205010:	59fd                	li	s3,-1
    80205012:	bf4d                	j	80204fc4 <sys_exec+0xac>
    80205014:	59fd                	li	s3,-1
    80205016:	b77d                	j	80204fc4 <sys_exec+0xac>
    80205018:	59fd                	li	s3,-1
    8020501a:	b76d                	j	80204fc4 <sys_exec+0xac>

000000008020501c <trace_init>:
};
static struct trace_ring rings[NCPU];

/* Called once at boot (kernel/main.c). Initialise every ring's lock and counters. */
void trace_init(void)
{
    8020501c:	7139                	addi	sp,sp,-64
    8020501e:	fc06                	sd	ra,56(sp)
    80205020:	f822                	sd	s0,48(sp)
    80205022:	f426                	sd	s1,40(sp)
    80205024:	f04a                	sd	s2,32(sp)
    80205026:	ec4e                	sd	s3,24(sp)
    80205028:	e852                	sd	s4,16(sp)
    8020502a:	e456                	sd	s5,8(sp)
    8020502c:	0080                	addi	s0,sp,64
    for (int i = 0; i < NCPU; i++) {
    8020502e:	00131497          	auipc	s1,0x131
    80205032:	40248493          	addi	s1,s1,1026 # 80336430 <rings+0x1418>
    80205036:	0013ba97          	auipc	s5,0x13b
    8020503a:	53aa8a93          	addi	s5,s5,1338 # 80340570 <vmas+0x1118>
        initlock(&rings[i].lock, "trace");
    8020503e:	79fd                	lui	s3,0xfffff
    80205040:	be898993          	addi	s3,s3,-1048 # ffffffffffffebe8 <uart+0xffffffff7fca4bb8>
    80205044:	00005a17          	auipc	s4,0x5
    80205048:	b0ca0a13          	addi	s4,s4,-1268 # 80209b50 <etext+0xb50>
    for (int i = 0; i < NCPU; i++) {
    8020504c:	6905                	lui	s2,0x1
    8020504e:	42890913          	addi	s2,s2,1064 # 1428 <_entry-0x801febd8>
        initlock(&rings[i].lock, "trace");
    80205052:	85d2                	mv	a1,s4
    80205054:	01348533          	add	a0,s1,s3
    80205058:	ffffc097          	auipc	ra,0xffffc
    8020505c:	3b4080e7          	jalr	948(ra) # 8020140c <initlock>
        rings[i].head = rings[i].count = rings[i].dropped = 0;
    80205060:	0004a423          	sw	zero,8(s1)
    80205064:	0004a223          	sw	zero,4(s1)
    80205068:	0004a023          	sw	zero,0(s1)
    for (int i = 0; i < NCPU; i++) {
    8020506c:	94ca                	add	s1,s1,s2
    8020506e:	ff5492e3          	bne	s1,s5,80205052 <trace_init+0x36>
    }
}
    80205072:	70e2                	ld	ra,56(sp)
    80205074:	7442                	ld	s0,48(sp)
    80205076:	74a2                	ld	s1,40(sp)
    80205078:	7902                	ld	s2,32(sp)
    8020507a:	69e2                	ld	s3,24(sp)
    8020507c:	6a42                	ld	s4,16(sp)
    8020507e:	6aa2                	ld	s5,8(sp)
    80205080:	6121                	addi	sp,sp,64
    80205082:	8082                	ret

0000000080205084 <trace_record>:
 *   3. Record into THIS hart's ring (use hal_hart_id()). If the ring is full,
 *      increment `dropped` instead of overwriting. Fill pid, hart, num, ret,
 *      arg0, and a timestamp from r_time().
 */
void trace_record(int num, long ret, uint64 arg0)
{
    80205084:	1141                	addi	sp,sp,-16
    80205086:	e422                	sd	s0,8(sp)
    80205088:	0800                	addi	s0,sp,16
    (void)num; (void)ret; (void)arg0;
    /* TODO: implement per-hart recording with overflow accounting. */
}
    8020508a:	6422                	ld	s0,8(sp)
    8020508c:	0141                	addi	sp,sp,16
    8020508e:	8082                	ret

0000000080205090 <trace_ctl>:

/* Backing the tracectl() syscall. action is TRACE_ENABLE or TRACE_DISABLE.
 * TODO: set or clear the current process's trace_filter accordingly. */
int trace_ctl(int action, uint64 filter)
{
    80205090:	1141                	addi	sp,sp,-16
    80205092:	e422                	sd	s0,8(sp)
    80205094:	0800                	addi	s0,sp,16
    (void)action; (void)filter;
    /* TODO: implement enable/disable of the per-process filter. */
    return -1;
}
    80205096:	557d                	li	a0,-1
    80205098:	6422                	ld	s0,8(sp)
    8020509a:	0141                	addi	sp,sp,16
    8020509c:	8082                	ret

000000008020509e <trace_read>:

/* Backing the traceread() syscall. Copy up to `max` events out to ubuf,
 * draining every hart's ring. TODO: drain each ring under its lock, copyout
 * each event, and surface the per-ring `dropped` count as an overflow record. */
int trace_read(uint64 ubuf, int max)
{
    8020509e:	1141                	addi	sp,sp,-16
    802050a0:	e422                	sd	s0,8(sp)
    802050a2:	0800                	addi	s0,sp,16
    (void)ubuf; (void)max;
    /* TODO: implement the cross-hart drain. */
    return 0;
}
    802050a4:	4501                	li	a0,0
    802050a6:	6422                	ld	s0,8(sp)
    802050a8:	0141                	addi	sp,sp,16
    802050aa:	8082                	ret

00000000802050ac <trace_fork>:

/* Called from fork(). TODO: make the child inherit the parent's trace_filter. */
void trace_fork(struct proc *parent, struct proc *child)
{
    802050ac:	1141                	addi	sp,sp,-16
    802050ae:	e422                	sd	s0,8(sp)
    802050b0:	0800                	addi	s0,sp,16
    (void)parent; (void)child;
    /* TODO: copy the filter so a traced process's children are traced too. */
}
    802050b2:	6422                	ld	s0,8(sp)
    802050b4:	0141                	addi	sp,sp,16
    802050b6:	8082                	ret

00000000802050b8 <usysinfo_setup>:
/* ---- The mapping infrastructure is provided (this is plumbing, not the lab's
 * core idea). Do not change the permissions: the page MUST stay read-only in
 * user space, or the whole safety argument collapses. ---- */

int usysinfo_setup(struct proc *p)
{
    802050b8:	1101                	addi	sp,sp,-32
    802050ba:	ec06                	sd	ra,24(sp)
    802050bc:	e822                	sd	s0,16(sp)
    802050be:	e04a                	sd	s2,0(sp)
    802050c0:	1000                	addi	s0,sp,32
    802050c2:	892a                	mv	s2,a0
    char *mem = palloc();
    802050c4:	ffffc097          	auipc	ra,0xffffc
    802050c8:	022080e7          	jalr	34(ra) # 802010e6 <palloc>
    if (mem == 0) return -1;
    802050cc:	c929                	beqz	a0,8020511e <usysinfo_setup+0x66>
    802050ce:	e426                	sd	s1,8(sp)
    802050d0:	84aa                	mv	s1,a0
    memset(mem, 0, PGSIZE);
    802050d2:	6605                	lui	a2,0x1
    802050d4:	4581                	li	a1,0
    802050d6:	ffffb097          	auipc	ra,0xffffb
    802050da:	5e6080e7          	jalr	1510(ra) # 802006bc <memset>
    struct usysinfo *u = (struct usysinfo *)mem;
    u->version = USYSINFO_VERSION; u->seq = 0;
    802050de:	4785                	li	a5,1
    802050e0:	c09c                	sw	a5,0(s1)
    802050e2:	0004a223          	sw	zero,4(s1)
    if (mappages(p->pagetable, USYSINFO_VA, PGSIZE, (uint64)mem, PTE_R | PTE_U) != 0) {
    802050e6:	4749                	li	a4,18
    802050e8:	86a6                	mv	a3,s1
    802050ea:	6605                	lui	a2,0x1
    802050ec:	7ffff5b7          	lui	a1,0x7ffff
    802050f0:	05093503          	ld	a0,80(s2)
    802050f4:	ffffe097          	auipc	ra,0xffffe
    802050f8:	ec0080e7          	jalr	-320(ra) # 80202fb4 <mappages>
    802050fc:	e909                	bnez	a0,8020510e <usysinfo_setup+0x56>
        pfree(mem); return -1;
    }
    p->usysinfo = u;
    802050fe:	16993823          	sd	s1,368(s2)
    return 0;
    80205102:	64a2                	ld	s1,8(sp)
}
    80205104:	60e2                	ld	ra,24(sp)
    80205106:	6442                	ld	s0,16(sp)
    80205108:	6902                	ld	s2,0(sp)
    8020510a:	6105                	addi	sp,sp,32
    8020510c:	8082                	ret
        pfree(mem); return -1;
    8020510e:	8526                	mv	a0,s1
    80205110:	ffffc097          	auipc	ra,0xffffc
    80205114:	114080e7          	jalr	276(ra) # 80201224 <pfree>
    80205118:	557d                	li	a0,-1
    8020511a:	64a2                	ld	s1,8(sp)
    8020511c:	b7e5                	j	80205104 <usysinfo_setup+0x4c>
    if (mem == 0) return -1;
    8020511e:	557d                	li	a0,-1
    80205120:	b7d5                	j	80205104 <usysinfo_setup+0x4c>

0000000080205122 <usysinfo_free>:

/* uvmfree only frees [0,sz); the info page is above sz, so free it explicitly
 * or one page leaks per process (caught by the baseline leak test). */
void usysinfo_free(struct proc *p)
{
    if (p->usysinfo) {
    80205122:	17053783          	ld	a5,368(a0)
    80205126:	cb85                	beqz	a5,80205156 <usysinfo_free+0x34>
{
    80205128:	1101                	addi	sp,sp,-32
    8020512a:	ec06                	sd	ra,24(sp)
    8020512c:	e822                	sd	s0,16(sp)
    8020512e:	e426                	sd	s1,8(sp)
    80205130:	1000                	addi	s0,sp,32
    80205132:	84aa                	mv	s1,a0
        if (p->pagetable) uvmunmap(p->pagetable, USYSINFO_VA, 1, 1);
    80205134:	6928                	ld	a0,80(a0)
    80205136:	c909                	beqz	a0,80205148 <usysinfo_free+0x26>
    80205138:	4685                	li	a3,1
    8020513a:	4605                	li	a2,1
    8020513c:	7ffff5b7          	lui	a1,0x7ffff
    80205140:	ffffe097          	auipc	ra,0xffffe
    80205144:	0d2080e7          	jalr	210(ra) # 80203212 <uvmunmap>
        p->usysinfo = 0;
    80205148:	1604b823          	sd	zero,368(s1)
    }
}
    8020514c:	60e2                	ld	ra,24(sp)
    8020514e:	6442                	ld	s0,16(sp)
    80205150:	64a2                	ld	s1,8(sp)
    80205152:	6105                	addi	sp,sp,32
    80205154:	8082                	ret
    80205156:	8082                	ret

0000000080205158 <usysinfo_remap>:

/* exec builds a fresh page table; re-map the existing info page into it. */
int usysinfo_remap(struct proc *p, pagetable_t newpt)
{
    if (p->usysinfo == 0) return 0;
    80205158:	17053683          	ld	a3,368(a0)
    8020515c:	c69d                	beqz	a3,8020518a <usysinfo_remap+0x32>
{
    8020515e:	1141                	addi	sp,sp,-16
    80205160:	e406                	sd	ra,8(sp)
    80205162:	e022                	sd	s0,0(sp)
    80205164:	0800                	addi	s0,sp,16
    80205166:	87ae                	mv	a5,a1
    if (mappages(newpt, USYSINFO_VA, PGSIZE, (uint64)p->usysinfo, PTE_R | PTE_U) != 0)
    80205168:	4749                	li	a4,18
    8020516a:	6605                	lui	a2,0x1
    8020516c:	7ffff5b7          	lui	a1,0x7ffff
    80205170:	853e                	mv	a0,a5
    80205172:	ffffe097          	auipc	ra,0xffffe
    80205176:	e42080e7          	jalr	-446(ra) # 80202fb4 <mappages>
    8020517a:	00a03533          	snez	a0,a0
    8020517e:	40a00533          	neg	a0,a0
        return -1;
    return 0;
}
    80205182:	60a2                	ld	ra,8(sp)
    80205184:	6402                	ld	s0,0(sp)
    80205186:	0141                	addi	sp,sp,16
    80205188:	8082                	ret
    if (p->usysinfo == 0) return 0;
    8020518a:	4501                	li	a0,0
}
    8020518c:	8082                	ret

000000008020518e <usysinfo_update>:
 * Getting the two barriers right is the whole point — without them the reader
 * can observe a half-written page. The torn-snapshot test (usitest, 20000 reads)
 * is what proves you got it right.
 */
void usysinfo_update(struct proc *p)
{
    8020518e:	1141                	addi	sp,sp,-16
    80205190:	e422                	sd	s0,8(sp)
    80205192:	0800                	addi	s0,sp,16
    struct usysinfo *u = p->usysinfo;
    if (u == 0) return;
    /* TODO: implement the seqlock writer (odd -> barrier -> fields -> barrier -> even). */
    (void)ticks;
}
    80205194:	6422                	ld	s0,8(sp)
    80205196:	0141                	addi	sp,sp,16
    80205198:	8082                	ret

000000008020519a <pgrefstat>:
#include "types.h"
#include "defs.h"
#include "param.h"
#include "riscv.h"
struct pgref { int refcount; int cow; int writable; };
int pgrefstat(pagetable_t pt, uint64 va, struct pgref *out) {
    8020519a:	1101                	addi	sp,sp,-32
    8020519c:	ec06                	sd	ra,24(sp)
    8020519e:	e822                	sd	s0,16(sp)
    802051a0:	e04a                	sd	s2,0(sp)
    802051a2:	1000                	addi	s0,sp,32
    802051a4:	8932                	mv	s2,a2
    pte_t *pte = walk(pt, PGROUNDDOWN(va), 0);
    802051a6:	4601                	li	a2,0
    802051a8:	77fd                	lui	a5,0xfffff
    802051aa:	8dfd                	and	a1,a1,a5
    802051ac:	ffffe097          	auipc	ra,0xffffe
    802051b0:	d22080e7          	jalr	-734(ra) # 80202ece <walk>
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    802051b4:	c131                	beqz	a0,802051f8 <pgrefstat+0x5e>
    802051b6:	e426                	sd	s1,8(sp)
    802051b8:	84aa                	mv	s1,a0
    802051ba:	6108                	ld	a0,0(a0)
    802051bc:	01157713          	andi	a4,a0,17
    802051c0:	47c5                	li	a5,17
    802051c2:	02f71d63          	bne	a4,a5,802051fc <pgrefstat+0x62>
    out->refcount = palloc_ref_get((void *)PTE2PA(*pte));
    802051c6:	8129                	srli	a0,a0,0xa
    802051c8:	0532                	slli	a0,a0,0xc
    802051ca:	ffffc097          	auipc	ra,0xffffc
    802051ce:	010080e7          	jalr	16(ra) # 802011da <palloc_ref_get>
    802051d2:	00a92023          	sw	a0,0(s2)
    out->cow = (*pte & PTE_COW) ? 1 : 0;
    802051d6:	609c                	ld	a5,0(s1)
    802051d8:	83a1                	srli	a5,a5,0x8
    802051da:	8b85                	andi	a5,a5,1
    802051dc:	00f92223          	sw	a5,4(s2)
    out->writable = (*pte & PTE_W) ? 1 : 0;
    802051e0:	609c                	ld	a5,0(s1)
    802051e2:	8389                	srli	a5,a5,0x2
    802051e4:	8b85                	andi	a5,a5,1
    802051e6:	00f92423          	sw	a5,8(s2)
    return 0;
    802051ea:	4501                	li	a0,0
    802051ec:	64a2                	ld	s1,8(sp)
}
    802051ee:	60e2                	ld	ra,24(sp)
    802051f0:	6442                	ld	s0,16(sp)
    802051f2:	6902                	ld	s2,0(sp)
    802051f4:	6105                	addi	sp,sp,32
    802051f6:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    802051f8:	557d                	li	a0,-1
    802051fa:	bfd5                	j	802051ee <pgrefstat+0x54>
    802051fc:	557d                	li	a0,-1
    802051fe:	64a2                	ld	s1,8(sp)
    80205200:	b7fd                	j	802051ee <pgrefstat+0x54>

0000000080205202 <pgaudit>:
int pgaudit(pagetable_t pt, uint64 sz) {
    for (uint64 a = 0; a < sz; a += PGSIZE) {
    80205202:	c9d9                	beqz	a1,80205298 <pgaudit+0x96>
int pgaudit(pagetable_t pt, uint64 sz) {
    80205204:	711d                	addi	sp,sp,-96
    80205206:	ec86                	sd	ra,88(sp)
    80205208:	e8a2                	sd	s0,80(sp)
    8020520a:	e4a6                	sd	s1,72(sp)
    8020520c:	e0ca                	sd	s2,64(sp)
    8020520e:	fc4e                	sd	s3,56(sp)
    80205210:	f852                	sd	s4,48(sp)
    80205212:	f456                	sd	s5,40(sp)
    80205214:	f05a                	sd	s6,32(sp)
    80205216:	ec5e                	sd	s7,24(sp)
    80205218:	e862                	sd	s8,16(sp)
    8020521a:	e466                	sd	s9,8(sp)
    8020521c:	1080                	addi	s0,sp,96
    8020521e:	8a2a                	mv	s4,a0
    80205220:	89ae                	mv	s3,a1
    for (uint64 a = 0; a < sz; a += PGSIZE) {
    80205222:	4901                	li	s2,0
        pte_t *pte = walk(pt, a, 0);
        if (!pte || !(*pte & PTE_V)) continue;
        if (!(*pte & PTE_U)) continue;
    80205224:	4b45                	li	s6,17
        uint64 pa = PTE2PA(*pte);
        int rc = palloc_ref_get((void *)pa);
        if (rc < 1) return 1;
        if ((*pte & PTE_COW) && (*pte & PTE_W)) return 2;
    80205226:	10400b93          	li	s7,260
        if (rc > 1 && (*pte & PTE_W) && !(*pte & PTE_COW)) return 3;
    8020522a:	4c05                	li	s8,1
    8020522c:	4c91                	li	s9,4
    for (uint64 a = 0; a < sz; a += PGSIZE) {
    8020522e:	6a85                	lui	s5,0x1
    80205230:	a021                	j	80205238 <pgaudit+0x36>
    80205232:	9956                	add	s2,s2,s5
    80205234:	05397463          	bgeu	s2,s3,8020527c <pgaudit+0x7a>
        pte_t *pte = walk(pt, a, 0);
    80205238:	4601                	li	a2,0
    8020523a:	85ca                	mv	a1,s2
    8020523c:	8552                	mv	a0,s4
    8020523e:	ffffe097          	auipc	ra,0xffffe
    80205242:	c90080e7          	jalr	-880(ra) # 80202ece <walk>
    80205246:	84aa                	mv	s1,a0
        if (!pte || !(*pte & PTE_V)) continue;
    80205248:	d56d                	beqz	a0,80205232 <pgaudit+0x30>
    8020524a:	611c                	ld	a5,0(a0)
        if (!(*pte & PTE_U)) continue;
    8020524c:	0117f713          	andi	a4,a5,17
    80205250:	ff6711e3          	bne	a4,s6,80205232 <pgaudit+0x30>
        uint64 pa = PTE2PA(*pte);
    80205254:	83a9                	srli	a5,a5,0xa
        int rc = palloc_ref_get((void *)pa);
    80205256:	00c79513          	slli	a0,a5,0xc
    8020525a:	ffffc097          	auipc	ra,0xffffc
    8020525e:	f80080e7          	jalr	-128(ra) # 802011da <palloc_ref_get>
        if (rc < 1) return 1;
    80205262:	02a05d63          	blez	a0,8020529c <pgaudit+0x9a>
        if ((*pte & PTE_COW) && (*pte & PTE_W)) return 2;
    80205266:	609c                	ld	a5,0(s1)
    80205268:	1047f793          	andi	a5,a5,260
    8020526c:	03778a63          	beq	a5,s7,802052a0 <pgaudit+0x9e>
        if (rc > 1 && (*pte & PTE_W) && !(*pte & PTE_COW)) return 3;
    80205270:	fcac51e3          	bge	s8,a0,80205232 <pgaudit+0x30>
    80205274:	fb979fe3          	bne	a5,s9,80205232 <pgaudit+0x30>
    80205278:	450d                	li	a0,3
    8020527a:	a011                	j	8020527e <pgaudit+0x7c>
    }
    return 0;
    8020527c:	4501                	li	a0,0
}
    8020527e:	60e6                	ld	ra,88(sp)
    80205280:	6446                	ld	s0,80(sp)
    80205282:	64a6                	ld	s1,72(sp)
    80205284:	6906                	ld	s2,64(sp)
    80205286:	79e2                	ld	s3,56(sp)
    80205288:	7a42                	ld	s4,48(sp)
    8020528a:	7aa2                	ld	s5,40(sp)
    8020528c:	7b02                	ld	s6,32(sp)
    8020528e:	6be2                	ld	s7,24(sp)
    80205290:	6c42                	ld	s8,16(sp)
    80205292:	6ca2                	ld	s9,8(sp)
    80205294:	6125                	addi	sp,sp,96
    80205296:	8082                	ret
    return 0;
    80205298:	4501                	li	a0,0
}
    8020529a:	8082                	ret
        if (rc < 1) return 1;
    8020529c:	4505                	li	a0,1
    8020529e:	b7c5                	j	8020527e <pgaudit+0x7c>
        if ((*pte & PTE_COW) && (*pte & PTE_W)) return 2;
    802052a0:	4509                	li	a0,2
    802052a2:	bff1                	j	8020527e <pgaudit+0x7c>

00000000802052a4 <futex_init>:

#define NBUCKET 32
static struct spinlock buckets[NBUCKET];

void futex_init(void)
{
    802052a4:	7179                	addi	sp,sp,-48
    802052a6:	f406                	sd	ra,40(sp)
    802052a8:	f022                	sd	s0,32(sp)
    802052aa:	ec26                	sd	s1,24(sp)
    802052ac:	e84a                	sd	s2,16(sp)
    802052ae:	e44e                	sd	s3,8(sp)
    802052b0:	1800                	addi	s0,sp,48
    for (int i = 0; i < NBUCKET; i++)
    802052b2:	0013a497          	auipc	s1,0x13a
    802052b6:	ea648493          	addi	s1,s1,-346 # 8033f158 <buckets>
    802052ba:	0013a997          	auipc	s3,0x13a
    802052be:	19e98993          	addi	s3,s3,414 # 8033f458 <vmas>
        initlock(&buckets[i], "futex");
    802052c2:	00004917          	auipc	s2,0x4
    802052c6:	77e90913          	addi	s2,s2,1918 # 80209a40 <etext+0xa40>
    802052ca:	85ca                	mv	a1,s2
    802052cc:	8526                	mv	a0,s1
    802052ce:	ffffc097          	auipc	ra,0xffffc
    802052d2:	13e080e7          	jalr	318(ra) # 8020140c <initlock>
    for (int i = 0; i < NBUCKET; i++)
    802052d6:	04e1                	addi	s1,s1,24
    802052d8:	ff3499e3          	bne	s1,s3,802052ca <futex_init+0x26>
}
    802052dc:	70a2                	ld	ra,40(sp)
    802052de:	7402                	ld	s0,32(sp)
    802052e0:	64e2                	ld	s1,24(sp)
    802052e2:	6942                	ld	s2,16(sp)
    802052e4:	69a2                	ld	s3,8(sp)
    802052e6:	6145                	addi	sp,sp,48
    802052e8:	8082                	ret

00000000802052ea <futex_wait>:
    return &buckets[(uaddr >> 3) % NBUCKET];
}

int futex_wait(uint64 uaddr, uint64 expected)
{
    if (uaddr & 7) return -1;                  /* must be 8-byte aligned */
    802052ea:	00757793          	andi	a5,a0,7
    802052ee:	e3dd                	bnez	a5,80205394 <futex_wait+0xaa>
{
    802052f0:	7139                	addi	sp,sp,-64
    802052f2:	fc06                	sd	ra,56(sp)
    802052f4:	f822                	sd	s0,48(sp)
    802052f6:	f426                	sd	s1,40(sp)
    802052f8:	f04a                	sd	s2,32(sp)
    802052fa:	ec4e                	sd	s3,24(sp)
    802052fc:	e852                	sd	s4,16(sp)
    802052fe:	0080                	addi	s0,sp,64
    80205300:	84aa                	mv	s1,a0
    80205302:	89ae                	mv	s3,a1
    struct proc *p = myproc();
    80205304:	ffffc097          	auipc	ra,0xffffc
    80205308:	5ec080e7          	jalr	1516(ra) # 802018f0 <myproc>
    8020530c:	8a2a                	mv	s4,a0
    return &buckets[(uaddr >> 3) % NBUCKET];
    8020530e:	0034d713          	srli	a4,s1,0x3
    80205312:	8b7d                	andi	a4,a4,31
    80205314:	00171793          	slli	a5,a4,0x1
    80205318:	97ba                	add	a5,a5,a4
    8020531a:	078e                	slli	a5,a5,0x3
    8020531c:	0013a917          	auipc	s2,0x13a
    80205320:	e3c90913          	addi	s2,s2,-452 # 8033f158 <buckets>
    80205324:	993e                	add	s2,s2,a5
    struct spinlock *b = bucket_for(uaddr);

    acquire(b);
    80205326:	854a                	mv	a0,s2
    80205328:	ffffc097          	auipc	ra,0xffffc
    8020532c:	160080e7          	jalr	352(ra) # 80201488 <acquire>
    uint64 val;
    if (copyin(p->pagetable, (char *)&val, uaddr, sizeof(val)) < 0) {
    80205330:	46a1                	li	a3,8
    80205332:	8626                	mv	a2,s1
    80205334:	fc840593          	addi	a1,s0,-56
    80205338:	050a3503          	ld	a0,80(s4)
    8020533c:	ffffe097          	auipc	ra,0xffffe
    80205340:	244080e7          	jalr	580(ra) # 80203580 <copyin>
    80205344:	02054463          	bltz	a0,8020536c <futex_wait+0x82>
        release(b); return -1;                 /* bad/unmapped address */
    }
    if (val != expected) { release(b); return 0; }   /* changed: don't sleep */
    80205348:	fc843783          	ld	a5,-56(s0)
    8020534c:	03378763          	beq	a5,s3,8020537a <futex_wait+0x90>
    80205350:	854a                	mv	a0,s2
    80205352:	ffffc097          	auipc	ra,0xffffc
    80205356:	1ea080e7          	jalr	490(ra) # 8020153c <release>
    8020535a:	4501                	li	a0,0
    /* sleep releases b and re-acquires p->lock atomically; a waker holding b
     * cannot have run its wakeup between our compare and here. */
    sleep((void *)uaddr, b);
    release(b);
    return 0;
}
    8020535c:	70e2                	ld	ra,56(sp)
    8020535e:	7442                	ld	s0,48(sp)
    80205360:	74a2                	ld	s1,40(sp)
    80205362:	7902                	ld	s2,32(sp)
    80205364:	69e2                	ld	s3,24(sp)
    80205366:	6a42                	ld	s4,16(sp)
    80205368:	6121                	addi	sp,sp,64
    8020536a:	8082                	ret
        release(b); return -1;                 /* bad/unmapped address */
    8020536c:	854a                	mv	a0,s2
    8020536e:	ffffc097          	auipc	ra,0xffffc
    80205372:	1ce080e7          	jalr	462(ra) # 8020153c <release>
    80205376:	557d                	li	a0,-1
    80205378:	b7d5                	j	8020535c <futex_wait+0x72>
    sleep((void *)uaddr, b);
    8020537a:	85ca                	mv	a1,s2
    8020537c:	8526                	mv	a0,s1
    8020537e:	ffffd097          	auipc	ra,0xffffd
    80205382:	d68080e7          	jalr	-664(ra) # 802020e6 <sleep>
    release(b);
    80205386:	854a                	mv	a0,s2
    80205388:	ffffc097          	auipc	ra,0xffffc
    8020538c:	1b4080e7          	jalr	436(ra) # 8020153c <release>
    return 0;
    80205390:	4501                	li	a0,0
    80205392:	b7e9                	j	8020535c <futex_wait+0x72>
    if (uaddr & 7) return -1;                  /* must be 8-byte aligned */
    80205394:	557d                	li	a0,-1
}
    80205396:	8082                	ret

0000000080205398 <futex_wake>:

int futex_wake(uint64 uaddr, int n)
{
    if (uaddr & 7) return -1;
    80205398:	00757793          	andi	a5,a0,7
    8020539c:	ebb1                	bnez	a5,802053f0 <futex_wake+0x58>
{
    8020539e:	1101                	addi	sp,sp,-32
    802053a0:	ec06                	sd	ra,24(sp)
    802053a2:	e822                	sd	s0,16(sp)
    802053a4:	e426                	sd	s1,8(sp)
    802053a6:	e04a                	sd	s2,0(sp)
    802053a8:	1000                	addi	s0,sp,32
    802053aa:	84aa                	mv	s1,a0
    return &buckets[(uaddr >> 3) % NBUCKET];
    802053ac:	00355713          	srli	a4,a0,0x3
    802053b0:	8b7d                	andi	a4,a4,31
    802053b2:	00171793          	slli	a5,a4,0x1
    802053b6:	97ba                	add	a5,a5,a4
    802053b8:	078e                	slli	a5,a5,0x3
    802053ba:	0013a917          	auipc	s2,0x13a
    802053be:	d9e90913          	addi	s2,s2,-610 # 8033f158 <buckets>
    802053c2:	993e                	add	s2,s2,a5
    struct spinlock *b = bucket_for(uaddr);
    acquire(b);
    802053c4:	854a                	mv	a0,s2
    802053c6:	ffffc097          	auipc	ra,0xffffc
    802053ca:	0c2080e7          	jalr	194(ra) # 80201488 <acquire>
    (void)n;                                   /* wakeup wakes all; re-check in user space */
    wakeup((void *)uaddr);
    802053ce:	8526                	mv	a0,s1
    802053d0:	ffffd097          	auipc	ra,0xffffd
    802053d4:	e9c080e7          	jalr	-356(ra) # 8020226c <wakeup>
    release(b);
    802053d8:	854a                	mv	a0,s2
    802053da:	ffffc097          	auipc	ra,0xffffc
    802053de:	162080e7          	jalr	354(ra) # 8020153c <release>
    return 0;
    802053e2:	4501                	li	a0,0
}
    802053e4:	60e2                	ld	ra,24(sp)
    802053e6:	6442                	ld	s0,16(sp)
    802053e8:	64a2                	ld	s1,8(sp)
    802053ea:	6902                	ld	s2,0(sp)
    802053ec:	6105                	addi	sp,sp,32
    802053ee:	8082                	ret
    if (uaddr & 7) return -1;
    802053f0:	557d                	li	a0,-1
}
    802053f2:	8082                	ret

00000000802053f4 <alarm_tick>:
#include "param.h"

/* Called from usertrap on a timer interrupt. Returns 1 if it set up a delivery
 * (so the caller should NOT also yield into the handler path incorrectly). */
int alarm_tick(void)
{
    802053f4:	1101                	addi	sp,sp,-32
    802053f6:	ec06                	sd	ra,24(sp)
    802053f8:	e822                	sd	s0,16(sp)
    802053fa:	e04a                	sd	s2,0(sp)
    802053fc:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    802053fe:	ffffc097          	auipc	ra,0xffffc
    80205402:	4f2080e7          	jalr	1266(ra) # 802018f0 <myproc>
    if (p->alarm_interval == 0) return 0;      /* disabled */
    80205406:	19853783          	ld	a5,408(a0)
    8020540a:	4901                	li	s2,0
    8020540c:	c3d5                	beqz	a5,802054b0 <alarm_tick+0xbc>
    8020540e:	e426                	sd	s1,8(sp)
    80205410:	84aa                	mv	s1,a0
    if (p->in_handler) return 0;               /* masked: don't nest */
    80205412:	1b452903          	lw	s2,436(a0)
    80205416:	08091b63          	bnez	s2,802054ac <alarm_tick+0xb8>

    if (++p->alarm_ticks < (int)p->alarm_interval) return 0;
    8020541a:	1b052703          	lw	a4,432(a0)
    8020541e:	2705                	addiw	a4,a4,1
    80205420:	0007069b          	sext.w	a3,a4
    80205424:	2781                	sext.w	a5,a5
    80205426:	00f6d663          	bge	a3,a5,80205432 <alarm_tick+0x3e>
    8020542a:	1ae52823          	sw	a4,432(a0)
    8020542e:	64a2                	ld	s1,8(sp)
    80205430:	a041                	j	802054b0 <alarm_tick+0xbc>
    p->alarm_ticks = 0;
    80205432:	1a052823          	sw	zero,432(a0)

    /* validate the handler address is a mapped user page */
    if (walkaddr(p->pagetable, PGROUNDDOWN(p->alarm_handler)) == 0)
    80205436:	1a053783          	ld	a5,416(a0)
    8020543a:	75fd                	lui	a1,0xfffff
    8020543c:	8dfd                	and	a1,a1,a5
    8020543e:	6928                	ld	a0,80(a0)
    80205440:	ffffe097          	auipc	ra,0xffffe
    80205444:	b34080e7          	jalr	-1228(ra) # 80202f74 <walkaddr>
    80205448:	c935                	beqz	a0,802054bc <alarm_tick+0xc8>
        return 0;                              /* bad handler: skip (don't kill) */

    /* save the full trapframe so sigreturn can restore it exactly */
    if (p->alarm_saved == 0) {
    8020544a:	1b84b783          	ld	a5,440(s1)
    8020544e:	c7b1                	beqz	a5,8020549a <alarm_tick+0xa6>
        p->alarm_saved = (struct trapframe *)palloc();
        if (p->alarm_saved == 0) return 0;
    }
    *(p->alarm_saved) = *(p->tf);
    80205450:	6cb4                	ld	a3,88(s1)
    80205452:	87b6                	mv	a5,a3
    80205454:	1b84b703          	ld	a4,440(s1)
    80205458:	12068693          	addi	a3,a3,288
    8020545c:	0007b803          	ld	a6,0(a5) # fffffffffffff000 <uart+0xffffffff7fca4fd0>
    80205460:	6788                	ld	a0,8(a5)
    80205462:	6b8c                	ld	a1,16(a5)
    80205464:	6f90                	ld	a2,24(a5)
    80205466:	01073023          	sd	a6,0(a4)
    8020546a:	e708                	sd	a0,8(a4)
    8020546c:	eb0c                	sd	a1,16(a4)
    8020546e:	ef10                	sd	a2,24(a4)
    80205470:	02078793          	addi	a5,a5,32
    80205474:	02070713          	addi	a4,a4,32
    80205478:	fed792e3          	bne	a5,a3,8020545c <alarm_tick+0x68>

    p->in_handler = 1;
    8020547c:	4785                	li	a5,1
    8020547e:	1af4aa23          	sw	a5,436(s1)
    p->tf->epc = p->alarm_handler;             /* jump to handler */
    80205482:	6cbc                	ld	a5,88(s1)
    80205484:	1a04b703          	ld	a4,416(s1)
    80205488:	ef98                	sd	a4,24(a5)
    if (p->alarm_altstack)
    8020548a:	1a84b783          	ld	a5,424(s1)
        p->tf->sp = p->alarm_altstack;         /* run on the alt stack */
    return 1;
    8020548e:	4905                	li	s2,1
    if (p->alarm_altstack)
    80205490:	cb85                	beqz	a5,802054c0 <alarm_tick+0xcc>
        p->tf->sp = p->alarm_altstack;         /* run on the alt stack */
    80205492:	6cb8                	ld	a4,88(s1)
    80205494:	fb1c                	sd	a5,48(a4)
    80205496:	64a2                	ld	s1,8(sp)
    80205498:	a821                	j	802054b0 <alarm_tick+0xbc>
        p->alarm_saved = (struct trapframe *)palloc();
    8020549a:	ffffc097          	auipc	ra,0xffffc
    8020549e:	c4c080e7          	jalr	-948(ra) # 802010e6 <palloc>
    802054a2:	1aa4bc23          	sd	a0,440(s1)
        if (p->alarm_saved == 0) return 0;
    802054a6:	f54d                	bnez	a0,80205450 <alarm_tick+0x5c>
    802054a8:	64a2                	ld	s1,8(sp)
    802054aa:	a019                	j	802054b0 <alarm_tick+0xbc>
    if (p->in_handler) return 0;               /* masked: don't nest */
    802054ac:	4901                	li	s2,0
    802054ae:	64a2                	ld	s1,8(sp)
}
    802054b0:	854a                	mv	a0,s2
    802054b2:	60e2                	ld	ra,24(sp)
    802054b4:	6442                	ld	s0,16(sp)
    802054b6:	6902                	ld	s2,0(sp)
    802054b8:	6105                	addi	sp,sp,32
    802054ba:	8082                	ret
    802054bc:	64a2                	ld	s1,8(sp)
    802054be:	bfcd                	j	802054b0 <alarm_tick+0xbc>
    802054c0:	64a2                	ld	s1,8(sp)
    802054c2:	b7fd                	j	802054b0 <alarm_tick+0xbc>

00000000802054c4 <mmap>:
{
    return vmas[p - proc];
}

uint64 mmap(uint64 addr, uint64 len, int prot, int flags, int fd, uint64 off)
{
    802054c4:	7139                	addi	sp,sp,-64
    802054c6:	fc06                	sd	ra,56(sp)
    802054c8:	f822                	sd	s0,48(sp)
    802054ca:	f426                	sd	s1,40(sp)
    802054cc:	f04a                	sd	s2,32(sp)
    802054ce:	ec4e                	sd	s3,24(sp)
    802054d0:	e852                	sd	s4,16(sp)
    802054d2:	e456                	sd	s5,8(sp)
    802054d4:	e05a                	sd	s6,0(sp)
    802054d6:	0080                	addi	s0,sp,64
    802054d8:	892e                	mv	s2,a1
    802054da:	8ab2                	mv	s5,a2
    802054dc:	8a36                	mv	s4,a3
    802054de:	84ba                	mv	s1,a4
    802054e0:	89be                	mv	s3,a5
    struct proc *p = myproc();
    802054e2:	ffffc097          	auipc	ra,0xffffc
    802054e6:	40e080e7          	jalr	1038(ra) # 802018f0 <myproc>
    if (len == 0) return -1;
    802054ea:	5b7d                	li	s6,-1
    802054ec:	0a090163          	beqz	s2,8020558e <mmap+0xca>
    if (fd < 0 || fd >= NOFILE || p->ofile[fd] == 0) return -1;
    802054f0:	0004879b          	sext.w	a5,s1
    802054f4:	473d                	li	a4,15
    802054f6:	08f76c63          	bltu	a4,a5,8020558e <mmap+0xca>
    802054fa:	04e9                	addi	s1,s1,26
    802054fc:	048e                	slli	s1,s1,0x3
    802054fe:	94aa                	add	s1,s1,a0
    80205500:	6090                	ld	a2,0(s1)
    80205502:	ca71                	beqz	a2,802055d6 <mmap+0x112>
    struct file *f = p->ofile[fd];
    if (f->type != FD_INODE) return -1;
    80205504:	4218                	lw	a4,0(a2)
    80205506:	4789                	li	a5,2
    80205508:	08f71363          	bne	a4,a5,8020558e <mmap+0xca>
    return vmas[p - proc];
    8020550c:	00129797          	auipc	a5,0x129
    80205510:	af478793          	addi	a5,a5,-1292 # 8032e000 <proc>
    80205514:	40f507b3          	sub	a5,a0,a5
    80205518:	8799                	srai	a5,a5,0x6
    8020551a:	06db7737          	lui	a4,0x6db7
    8020551e:	db770713          	addi	a4,a4,-585 # 6db6db7 <_entry-0x79449249>
    80205522:	0732                	slli	a4,a4,0xc
    80205524:	db770713          	addi	a4,a4,-585
    80205528:	0732                	slli	a4,a4,0xc
    8020552a:	db770713          	addi	a4,a4,-585
    8020552e:	0732                	slli	a4,a4,0xc
    80205530:	db770713          	addi	a4,a4,-585
    80205534:	02e787b3          	mul	a5,a5,a4
    80205538:	00179493          	slli	s1,a5,0x1
    8020553c:	94be                	add	s1,s1,a5
    8020553e:	04a2                	slli	s1,s1,0x8
    80205540:	0013a797          	auipc	a5,0x13a
    80205544:	f1878793          	addi	a5,a5,-232 # 8033f458 <vmas>
    80205548:	94be                	add	s1,s1,a5
    8020554a:	30048893          	addi	a7,s1,768
    8020554e:	8726                	mv	a4,s1

    struct vma *tab = table_for(p);
    /* find a free VMA slot and a free virtual range (simple bump within region) */
    uint64 va = MMAP_BASE;
    80205550:	40000b37          	lui	s6,0x40000
    for (int i = 0; i < NVMA; i++)
        if (tab[i].used && tab[i].start + tab[i].len > va)
            va = PGROUNDUP(tab[i].start + tab[i].len);
    80205554:	6685                	lui	a3,0x1
    80205556:	16fd                	addi	a3,a3,-1 # fff <_entry-0x801ff001>
    80205558:	75fd                	lui	a1,0xfffff
    8020555a:	a029                	j	80205564 <mmap+0xa0>
    for (int i = 0; i < NVMA; i++)
    8020555c:	03070713          	addi	a4,a4,48
    80205560:	03170063          	beq	a4,a7,80205580 <mmap+0xbc>
        if (tab[i].used && tab[i].start + tab[i].len > va)
    80205564:	00072803          	lw	a6,0(a4)
    80205568:	fe080ae3          	beqz	a6,8020555c <mmap+0x98>
    8020556c:	00873803          	ld	a6,8(a4)
    80205570:	6b1c                	ld	a5,16(a4)
    80205572:	983e                	add	a6,a6,a5
    80205574:	ff0b74e3          	bgeu	s6,a6,8020555c <mmap+0x98>
            va = PGROUNDUP(tab[i].start + tab[i].len);
    80205578:	9836                	add	a6,a6,a3
    8020557a:	00b87b33          	and	s6,a6,a1
    8020557e:	bff9                	j	8020555c <mmap+0x98>

    for (int i = 0; i < NVMA; i++) {
        if (!tab[i].used) {
    80205580:	409c                	lw	a5,0(s1)
    80205582:	c38d                	beqz	a5,802055a4 <mmap+0xe0>
    for (int i = 0; i < NVMA; i++) {
    80205584:	03048493          	addi	s1,s1,48
    80205588:	ff149ce3          	bne	s1,a7,80205580 <mmap+0xbc>
            tab[i].f = filedup(f);       /* hold the file open while mapped */
            tab[i].off = off;
            return va;
        }
    }
    return -1;                            /* no free VMA slot */
    8020558c:	5b7d                	li	s6,-1
}
    8020558e:	855a                	mv	a0,s6
    80205590:	70e2                	ld	ra,56(sp)
    80205592:	7442                	ld	s0,48(sp)
    80205594:	74a2                	ld	s1,40(sp)
    80205596:	7902                	ld	s2,32(sp)
    80205598:	69e2                	ld	s3,24(sp)
    8020559a:	6a42                	ld	s4,16(sp)
    8020559c:	6aa2                	ld	s5,8(sp)
    8020559e:	6b02                	ld	s6,0(sp)
    802055a0:	6121                	addi	sp,sp,64
    802055a2:	8082                	ret
            tab[i].used = 1;
    802055a4:	4785                	li	a5,1
    802055a6:	c09c                	sw	a5,0(s1)
            tab[i].start = va;
    802055a8:	0164b423          	sd	s6,8(s1)
            tab[i].len = PGROUNDUP(len);
    802055ac:	6785                	lui	a5,0x1
    802055ae:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    802055b0:	993e                	add	s2,s2,a5
    802055b2:	77fd                	lui	a5,0xfffff
    802055b4:	00f97933          	and	s2,s2,a5
    802055b8:	0124b823          	sd	s2,16(s1)
            tab[i].prot = prot;
    802055bc:	0154ac23          	sw	s5,24(s1)
            tab[i].flags = flags;
    802055c0:	0144ae23          	sw	s4,28(s1)
            tab[i].f = filedup(f);       /* hold the file open while mapped */
    802055c4:	8532                	mv	a0,a2
    802055c6:	00002097          	auipc	ra,0x2
    802055ca:	428080e7          	jalr	1064(ra) # 802079ee <filedup>
    802055ce:	f088                	sd	a0,32(s1)
            tab[i].off = off;
    802055d0:	0334b423          	sd	s3,40(s1)
            return va;
    802055d4:	bf6d                	j	8020558e <mmap+0xca>
    if (fd < 0 || fd >= NOFILE || p->ofile[fd] == 0) return -1;
    802055d6:	5b7d                	li	s6,-1
    802055d8:	bf5d                	j	8020558e <mmap+0xca>

00000000802055da <mmap_fault>:

/* Resolve a fault inside a mapped region: allocate a page, read the file bytes
 * into it, map it. Returns 0 if handled, -1 if the fault is not in any VMA. */
int mmap_fault(struct proc *p, uint64 va)
{
    802055da:	7139                	addi	sp,sp,-64
    802055dc:	fc06                	sd	ra,56(sp)
    802055de:	f822                	sd	s0,48(sp)
    802055e0:	f426                	sd	s1,40(sp)
    802055e2:	f04a                	sd	s2,32(sp)
    802055e4:	ec4e                	sd	s3,24(sp)
    802055e6:	0080                	addi	s0,sp,64
    802055e8:	89aa                	mv	s3,a0
    struct vma *tab = table_for(p);
    va = PGROUNDDOWN(va);
    802055ea:	77fd                	lui	a5,0xfffff
    802055ec:	00f5f933          	and	s2,a1,a5
    return vmas[p - proc];
    802055f0:	00129717          	auipc	a4,0x129
    802055f4:	a1070713          	addi	a4,a4,-1520 # 8032e000 <proc>
    802055f8:	40e50733          	sub	a4,a0,a4
    802055fc:	8719                	srai	a4,a4,0x6
    802055fe:	06db77b7          	lui	a5,0x6db7
    80205602:	db778793          	addi	a5,a5,-585 # 6db6db7 <_entry-0x79449249>
    80205606:	07b2                	slli	a5,a5,0xc
    80205608:	db778793          	addi	a5,a5,-585
    8020560c:	07b2                	slli	a5,a5,0xc
    8020560e:	db778793          	addi	a5,a5,-585
    80205612:	07b2                	slli	a5,a5,0xc
    80205614:	db778793          	addi	a5,a5,-585
    80205618:	02f70733          	mul	a4,a4,a5
    8020561c:	00171793          	slli	a5,a4,0x1
    80205620:	97ba                	add	a5,a5,a4
    80205622:	07a2                	slli	a5,a5,0x8
    80205624:	0013a717          	auipc	a4,0x13a
    80205628:	e3470713          	addi	a4,a4,-460 # 8033f458 <vmas>
    8020562c:	97ba                	add	a5,a5,a4
    8020562e:	30078693          	addi	a3,a5,768
    80205632:	a831                	j	8020564e <mmap_fault+0x74>
            readi(ip, 0, (uint64)mem, v->off + (va - v->start), PGSIZE);
            iunlock(ip);
            int perm = PTE_U | PTE_R;
            if (v->prot & PROT_WRITE) perm |= PTE_W;
            if (mappages(p->pagetable, va, PGSIZE, (uint64)mem, perm) != 0) {
                pfree(mem);
    80205634:	8552                	mv	a0,s4
    80205636:	ffffc097          	auipc	ra,0xffffc
    8020563a:	bee080e7          	jalr	-1042(ra) # 80201224 <pfree>
                return -1;
    8020563e:	557d                	li	a0,-1
    80205640:	6a42                	ld	s4,16(sp)
    80205642:	6aa2                	ld	s5,8(sp)
    80205644:	a859                	j	802056da <mmap_fault+0x100>
    for (int i = 0; i < NVMA; i++) {
    80205646:	03078793          	addi	a5,a5,48
    8020564a:	08d78763          	beq	a5,a3,802056d8 <mmap_fault+0xfe>
        struct vma *v = &tab[i];
    8020564e:	84be                	mv	s1,a5
        if (v->used && va >= v->start && va < v->start + v->len) {
    80205650:	4398                	lw	a4,0(a5)
    80205652:	db75                	beqz	a4,80205646 <mmap_fault+0x6c>
    80205654:	6798                	ld	a4,8(a5)
    80205656:	fee968e3          	bltu	s2,a4,80205646 <mmap_fault+0x6c>
    8020565a:	6b90                	ld	a2,16(a5)
    8020565c:	9732                	add	a4,a4,a2
    8020565e:	fee974e3          	bgeu	s2,a4,80205646 <mmap_fault+0x6c>
    80205662:	e852                	sd	s4,16(sp)
            char *mem = palloc();
    80205664:	ffffc097          	auipc	ra,0xffffc
    80205668:	a82080e7          	jalr	-1406(ra) # 802010e6 <palloc>
    8020566c:	8a2a                	mv	s4,a0
            if (!mem) return -1;
    8020566e:	cd2d                	beqz	a0,802056e8 <mmap_fault+0x10e>
    80205670:	e456                	sd	s5,8(sp)
            memset(mem, 0, PGSIZE);
    80205672:	6605                	lui	a2,0x1
    80205674:	4581                	li	a1,0
    80205676:	ffffb097          	auipc	ra,0xffffb
    8020567a:	046080e7          	jalr	70(ra) # 802006bc <memset>
            struct inode *ip = v->f->ip;
    8020567e:	709c                	ld	a5,32(s1)
    80205680:	0187ba83          	ld	s5,24(a5)
            ilock(ip);
    80205684:	8556                	mv	a0,s5
    80205686:	00002097          	auipc	ra,0x2
    8020568a:	a08080e7          	jalr	-1528(ra) # 8020708e <ilock>
            readi(ip, 0, (uint64)mem, v->off + (va - v->start), PGSIZE);
    8020568e:	749c                	ld	a5,40(s1)
    80205690:	012787bb          	addw	a5,a5,s2
    80205694:	6494                	ld	a3,8(s1)
    80205696:	6705                	lui	a4,0x1
    80205698:	40d786bb          	subw	a3,a5,a3
    8020569c:	8652                	mv	a2,s4
    8020569e:	4581                	li	a1,0
    802056a0:	8556                	mv	a0,s5
    802056a2:	00002097          	auipc	ra,0x2
    802056a6:	d1a080e7          	jalr	-742(ra) # 802073bc <readi>
            iunlock(ip);
    802056aa:	8556                	mv	a0,s5
    802056ac:	00002097          	auipc	ra,0x2
    802056b0:	aa8080e7          	jalr	-1368(ra) # 80207154 <iunlock>
            if (v->prot & PROT_WRITE) perm |= PTE_W;
    802056b4:	4c9c                	lw	a5,24(s1)
    802056b6:	8b89                	andi	a5,a5,2
    802056b8:	4759                	li	a4,22
    802056ba:	e391                	bnez	a5,802056be <mmap_fault+0xe4>
            int perm = PTE_U | PTE_R;
    802056bc:	4749                	li	a4,18
            if (mappages(p->pagetable, va, PGSIZE, (uint64)mem, perm) != 0) {
    802056be:	86d2                	mv	a3,s4
    802056c0:	6605                	lui	a2,0x1
    802056c2:	85ca                	mv	a1,s2
    802056c4:	0509b503          	ld	a0,80(s3)
    802056c8:	ffffe097          	auipc	ra,0xffffe
    802056cc:	8ec080e7          	jalr	-1812(ra) # 80202fb4 <mappages>
    802056d0:	f135                	bnez	a0,80205634 <mmap_fault+0x5a>
    802056d2:	6a42                	ld	s4,16(sp)
    802056d4:	6aa2                	ld	s5,8(sp)
    802056d6:	a011                	j	802056da <mmap_fault+0x100>
            }
            return 0;
        }
    }
    return -1;
    802056d8:	557d                	li	a0,-1
}
    802056da:	70e2                	ld	ra,56(sp)
    802056dc:	7442                	ld	s0,48(sp)
    802056de:	74a2                	ld	s1,40(sp)
    802056e0:	7902                	ld	s2,32(sp)
    802056e2:	69e2                	ld	s3,24(sp)
    802056e4:	6121                	addi	sp,sp,64
    802056e6:	8082                	ret
            if (!mem) return -1;
    802056e8:	557d                	li	a0,-1
    802056ea:	6a42                	ld	s4,16(sp)
    802056ec:	b7fd                	j	802056da <mmap_fault+0x100>

00000000802056ee <munmap>:

/* Write back a MAP_SHARED region's dirty pages and unmap it. */
int munmap(uint64 addr, uint64 len)
{
    802056ee:	715d                	addi	sp,sp,-80
    802056f0:	e486                	sd	ra,72(sp)
    802056f2:	e0a2                	sd	s0,64(sp)
    802056f4:	fc26                	sd	s1,56(sp)
    802056f6:	f84a                	sd	s2,48(sp)
    802056f8:	f052                	sd	s4,32(sp)
    802056fa:	ec56                	sd	s5,24(sp)
    802056fc:	0880                	addi	s0,sp,80
    802056fe:	892a                	mv	s2,a0
    80205700:	8aae                	mv	s5,a1
    struct proc *p = myproc();
    80205702:	ffffc097          	auipc	ra,0xffffc
    80205706:	1ee080e7          	jalr	494(ra) # 802018f0 <myproc>
    8020570a:	8a2a                	mv	s4,a0
    struct vma *tab = table_for(p);
    addr = PGROUNDDOWN(addr);
    8020570c:	77fd                	lui	a5,0xfffff
    8020570e:	00f97933          	and	s2,s2,a5
    return vmas[p - proc];
    80205712:	00129717          	auipc	a4,0x129
    80205716:	8ee70713          	addi	a4,a4,-1810 # 8032e000 <proc>
    8020571a:	40e50733          	sub	a4,a0,a4
    8020571e:	8719                	srai	a4,a4,0x6
    80205720:	06db77b7          	lui	a5,0x6db7
    80205724:	db778793          	addi	a5,a5,-585 # 6db6db7 <_entry-0x79449249>
    80205728:	07b2                	slli	a5,a5,0xc
    8020572a:	db778793          	addi	a5,a5,-585
    8020572e:	07b2                	slli	a5,a5,0xc
    80205730:	db778793          	addi	a5,a5,-585
    80205734:	07b2                	slli	a5,a5,0xc
    80205736:	db778793          	addi	a5,a5,-585
    8020573a:	02f70733          	mul	a4,a4,a5
    8020573e:	00171793          	slli	a5,a4,0x1
    80205742:	97ba                	add	a5,a5,a4
    80205744:	07a2                	slli	a5,a5,0x8
    80205746:	0013a717          	auipc	a4,0x13a
    8020574a:	d1270713          	addi	a4,a4,-750 # 8033f458 <vmas>
    8020574e:	97ba                	add	a5,a5,a4
    80205750:	30078693          	addi	a3,a5,768
    80205754:	a0f1                	j	80205820 <munmap+0x132>
                        struct inode *ip = v->f->ip;
                        ilock(ip);
                        writei(ip, 1, a, v->off + (a - v->start), PGSIZE);
                        iunlock(ip);
                    }
                    uvmunmap(p->pagetable, a, 1, 1);
    80205756:	4685                	li	a3,1
    80205758:	4605                	li	a2,1
    8020575a:	85ce                	mv	a1,s3
    8020575c:	050a3503          	ld	a0,80(s4)
    80205760:	ffffe097          	auipc	ra,0xffffe
    80205764:	ab2080e7          	jalr	-1358(ra) # 80203212 <uvmunmap>
            for (uint64 a = addr; a < end; a += PGSIZE) {
    80205768:	99de                	add	s3,s3,s7
    8020576a:	0759f063          	bgeu	s3,s5,802057ca <munmap+0xdc>
                pte_t *pte = walk(p->pagetable, a, 0);
    8020576e:	4601                	li	a2,0
    80205770:	85ce                	mv	a1,s3
    80205772:	050a3503          	ld	a0,80(s4)
    80205776:	ffffd097          	auipc	ra,0xffffd
    8020577a:	758080e7          	jalr	1880(ra) # 80202ece <walk>
                if (pte && (*pte & PTE_V)) {
    8020577e:	d56d                	beqz	a0,80205768 <munmap+0x7a>
    80205780:	611c                	ld	a5,0(a0)
    80205782:	8b85                	andi	a5,a5,1
    80205784:	d3f5                	beqz	a5,80205768 <munmap+0x7a>
                    if ((v->flags & MAP_SHARED) && (v->prot & PROT_WRITE)) {
    80205786:	6c9c                	ld	a5,24(s1)
    80205788:	0167f7b3          	and	a5,a5,s6
    8020578c:	fd6795e3          	bne	a5,s6,80205756 <munmap+0x68>
    80205790:	e062                	sd	s8,0(sp)
                        struct inode *ip = v->f->ip;
    80205792:	709c                	ld	a5,32(s1)
    80205794:	0187bc03          	ld	s8,24(a5)
                        ilock(ip);
    80205798:	8562                	mv	a0,s8
    8020579a:	00002097          	auipc	ra,0x2
    8020579e:	8f4080e7          	jalr	-1804(ra) # 8020708e <ilock>
                        writei(ip, 1, a, v->off + (a - v->start), PGSIZE);
    802057a2:	7494                	ld	a3,40(s1)
    802057a4:	649c                	ld	a5,8(s1)
    802057a6:	9e9d                	subw	a3,a3,a5
    802057a8:	6705                	lui	a4,0x1
    802057aa:	013686bb          	addw	a3,a3,s3
    802057ae:	864e                	mv	a2,s3
    802057b0:	4585                	li	a1,1
    802057b2:	8562                	mv	a0,s8
    802057b4:	00002097          	auipc	ra,0x2
    802057b8:	d3c080e7          	jalr	-708(ra) # 802074f0 <writei>
                        iunlock(ip);
    802057bc:	8562                	mv	a0,s8
    802057be:	00002097          	auipc	ra,0x2
    802057c2:	996080e7          	jalr	-1642(ra) # 80207154 <iunlock>
    802057c6:	6c02                	ld	s8,0(sp)
    802057c8:	b779                	j	80205756 <munmap+0x68>
    802057ca:	79a2                	ld	s3,40(sp)
    802057cc:	6b42                	ld	s6,16(sp)
    802057ce:	6ba2                	ld	s7,8(sp)
                }
            }
            /* if the whole VMA is gone, release it */
            if (addr == v->start && end == v->start + v->len) {
    802057d0:	649c                	ld	a5,8(s1)
    802057d2:	01278863          	beq	a5,s2,802057e2 <munmap+0xf4>
                fileclose(v->f);
                v->used = 0;
            } else if (addr == v->start) {
                v->start = end; v->off += (end - addr); v->len -= (end - addr);
            } else {
                v->len = addr - v->start;    /* trim the tail */
    802057d6:	40f90933          	sub	s2,s2,a5
    802057da:	0124b823          	sd	s2,16(s1)
            }
            return 0;
    802057de:	4501                	li	a0,0
    802057e0:	a041                	j	80205860 <munmap+0x172>
            if (addr == v->start && end == v->start + v->len) {
    802057e2:	6898                	ld	a4,16(s1)
    802057e4:	97ba                	add	a5,a5,a4
    802057e6:	02fa8063          	beq	s5,a5,80205806 <munmap+0x118>
                v->start = end; v->off += (end - addr); v->len -= (end - addr);
    802057ea:	0154b423          	sd	s5,8(s1)
    802057ee:	749c                	ld	a5,40(s1)
    802057f0:	412787b3          	sub	a5,a5,s2
    802057f4:	97d6                	add	a5,a5,s5
    802057f6:	f49c                	sd	a5,40(s1)
    802057f8:	012707b3          	add	a5,a4,s2
    802057fc:	415787b3          	sub	a5,a5,s5
    80205800:	e89c                	sd	a5,16(s1)
            return 0;
    80205802:	4501                	li	a0,0
    80205804:	a8b1                	j	80205860 <munmap+0x172>
                fileclose(v->f);
    80205806:	7088                	ld	a0,32(s1)
    80205808:	00002097          	auipc	ra,0x2
    8020580c:	238080e7          	jalr	568(ra) # 80207a40 <fileclose>
                v->used = 0;
    80205810:	0004a023          	sw	zero,0(s1)
            return 0;
    80205814:	4501                	li	a0,0
                v->used = 0;
    80205816:	a0a9                	j	80205860 <munmap+0x172>
    for (int i = 0; i < NVMA; i++) {
    80205818:	03078793          	addi	a5,a5,48
    8020581c:	04d78163          	beq	a5,a3,8020585e <munmap+0x170>
        struct vma *v = &tab[i];
    80205820:	84be                	mv	s1,a5
        if (v->used && addr >= v->start && addr < v->start + v->len) {
    80205822:	4398                	lw	a4,0(a5)
    80205824:	db75                	beqz	a4,80205818 <munmap+0x12a>
    80205826:	6798                	ld	a4,8(a5)
    80205828:	fee968e3          	bltu	s2,a4,80205818 <munmap+0x12a>
    8020582c:	6b90                	ld	a2,16(a5)
    8020582e:	9732                	add	a4,a4,a2
    80205830:	fee974e3          	bgeu	s2,a4,80205818 <munmap+0x12a>
            uint64 end = addr + PGROUNDUP(len);
    80205834:	6785                	lui	a5,0x1
    80205836:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80205838:	9abe                	add	s5,s5,a5
    8020583a:	77fd                	lui	a5,0xfffff
    8020583c:	00fafab3          	and	s5,s5,a5
    80205840:	9aca                	add	s5,s5,s2
            if (end > v->start + v->len) end = v->start + v->len;
    80205842:	01577363          	bgeu	a4,s5,80205848 <munmap+0x15a>
    80205846:	8aba                	mv	s5,a4
            for (uint64 a = addr; a < end; a += PGSIZE) {
    80205848:	f95974e3          	bgeu	s2,s5,802057d0 <munmap+0xe2>
    8020584c:	f44e                	sd	s3,40(sp)
    8020584e:	e85a                	sd	s6,16(sp)
    80205850:	e45e                	sd	s7,8(sp)
    80205852:	89ca                	mv	s3,s2
                    if ((v->flags & MAP_SHARED) && (v->prot & PROT_WRITE)) {
    80205854:	4b05                	li	s6,1
    80205856:	1b02                	slli	s6,s6,0x20
    80205858:	0b09                	addi	s6,s6,2 # 40000002 <_entry-0x401ffffe>
            for (uint64 a = addr; a < end; a += PGSIZE) {
    8020585a:	6b85                	lui	s7,0x1
    8020585c:	bf09                	j	8020576e <munmap+0x80>
        }
    }
    return -1;
    8020585e:	557d                	li	a0,-1
}
    80205860:	60a6                	ld	ra,72(sp)
    80205862:	6406                	ld	s0,64(sp)
    80205864:	74e2                	ld	s1,56(sp)
    80205866:	7942                	ld	s2,48(sp)
    80205868:	7a02                	ld	s4,32(sp)
    8020586a:	6ae2                	ld	s5,24(sp)
    8020586c:	6161                	addi	sp,sp,80
    8020586e:	8082                	ret

0000000080205870 <mmap_cleanup>:

/* Called at exit: unmap everything (write back shared dirty pages). */
void mmap_cleanup(struct proc *p)
{
    80205870:	715d                	addi	sp,sp,-80
    80205872:	e486                	sd	ra,72(sp)
    80205874:	e0a2                	sd	s0,64(sp)
    80205876:	fc26                	sd	s1,56(sp)
    80205878:	f84a                	sd	s2,48(sp)
    8020587a:	f44e                	sd	s3,40(sp)
    8020587c:	f052                	sd	s4,32(sp)
    8020587e:	ec56                	sd	s5,24(sp)
    80205880:	e85a                	sd	s6,16(sp)
    80205882:	e45e                	sd	s7,8(sp)
    80205884:	e062                	sd	s8,0(sp)
    80205886:	0880                	addi	s0,sp,80
    80205888:	8a2a                	mv	s4,a0
    return vmas[p - proc];
    8020588a:	00128797          	auipc	a5,0x128
    8020588e:	77678793          	addi	a5,a5,1910 # 8032e000 <proc>
    80205892:	40f507b3          	sub	a5,a0,a5
    80205896:	4067d713          	srai	a4,a5,0x6
    8020589a:	06db77b7          	lui	a5,0x6db7
    8020589e:	db778793          	addi	a5,a5,-585 # 6db6db7 <_entry-0x79449249>
    802058a2:	07b2                	slli	a5,a5,0xc
    802058a4:	db778793          	addi	a5,a5,-585
    802058a8:	07b2                	slli	a5,a5,0xc
    802058aa:	db778793          	addi	a5,a5,-585
    802058ae:	07b2                	slli	a5,a5,0xc
    802058b0:	db778793          	addi	a5,a5,-585
    802058b4:	02f707b3          	mul	a5,a4,a5
    802058b8:	00179993          	slli	s3,a5,0x1
    802058bc:	99be                	add	s3,s3,a5
    802058be:	09a2                	slli	s3,s3,0x8
    802058c0:	0013a797          	auipc	a5,0x13a
    802058c4:	b9878793          	addi	a5,a5,-1128 # 8033f458 <vmas>
    802058c8:	99be                	add	s3,s3,a5
    802058ca:	30098b93          	addi	s7,s3,768
        struct vma *v = &tab[i];
        if (v->used) {
            for (uint64 a = v->start; a < v->start + v->len; a += PGSIZE) {
                pte_t *pte = walk(p->pagetable, a, 0);
                if (pte && (*pte & PTE_V)) {
                    if ((v->flags & MAP_SHARED) && (v->prot & PROT_WRITE)) {
    802058ce:	4b05                	li	s6,1
    802058d0:	1b02                	slli	s6,s6,0x20
    802058d2:	0b09                	addi	s6,s6,2
            for (uint64 a = v->start; a < v->start + v->len; a += PGSIZE) {
    802058d4:	6a85                	lui	s5,0x1
    802058d6:	a869                	j	80205970 <mmap_cleanup+0x100>
                        struct inode *ip = v->f->ip;
                        ilock(ip);
                        writei(ip, 1, a, v->off + (a - v->start), PGSIZE);
                        iunlock(ip);
                    }
                    uvmunmap(p->pagetable, a, 1, 1);
    802058d8:	4685                	li	a3,1
    802058da:	4605                	li	a2,1
    802058dc:	85a6                	mv	a1,s1
    802058de:	050a3503          	ld	a0,80(s4)
    802058e2:	ffffe097          	auipc	ra,0xffffe
    802058e6:	930080e7          	jalr	-1744(ra) # 80203212 <uvmunmap>
            for (uint64 a = v->start; a < v->start + v->len; a += PGSIZE) {
    802058ea:	94d6                	add	s1,s1,s5
    802058ec:	00893783          	ld	a5,8(s2)
    802058f0:	01093703          	ld	a4,16(s2)
    802058f4:	97ba                	add	a5,a5,a4
    802058f6:	06f4f163          	bgeu	s1,a5,80205958 <mmap_cleanup+0xe8>
                pte_t *pte = walk(p->pagetable, a, 0);
    802058fa:	4601                	li	a2,0
    802058fc:	85a6                	mv	a1,s1
    802058fe:	050a3503          	ld	a0,80(s4)
    80205902:	ffffd097          	auipc	ra,0xffffd
    80205906:	5cc080e7          	jalr	1484(ra) # 80202ece <walk>
                if (pte && (*pte & PTE_V)) {
    8020590a:	d165                	beqz	a0,802058ea <mmap_cleanup+0x7a>
    8020590c:	611c                	ld	a5,0(a0)
    8020590e:	8b85                	andi	a5,a5,1
    80205910:	dfe9                	beqz	a5,802058ea <mmap_cleanup+0x7a>
                    if ((v->flags & MAP_SHARED) && (v->prot & PROT_WRITE)) {
    80205912:	01893783          	ld	a5,24(s2)
    80205916:	0167f7b3          	and	a5,a5,s6
    8020591a:	fb679fe3          	bne	a5,s6,802058d8 <mmap_cleanup+0x68>
                        struct inode *ip = v->f->ip;
    8020591e:	02093783          	ld	a5,32(s2)
    80205922:	0187bc03          	ld	s8,24(a5)
                        ilock(ip);
    80205926:	8562                	mv	a0,s8
    80205928:	00001097          	auipc	ra,0x1
    8020592c:	766080e7          	jalr	1894(ra) # 8020708e <ilock>
                        writei(ip, 1, a, v->off + (a - v->start), PGSIZE);
    80205930:	02893683          	ld	a3,40(s2)
    80205934:	00893783          	ld	a5,8(s2)
    80205938:	9e9d                	subw	a3,a3,a5
    8020593a:	8756                	mv	a4,s5
    8020593c:	9ea5                	addw	a3,a3,s1
    8020593e:	8626                	mv	a2,s1
    80205940:	4585                	li	a1,1
    80205942:	8562                	mv	a0,s8
    80205944:	00002097          	auipc	ra,0x2
    80205948:	bac080e7          	jalr	-1108(ra) # 802074f0 <writei>
                        iunlock(ip);
    8020594c:	8562                	mv	a0,s8
    8020594e:	00002097          	auipc	ra,0x2
    80205952:	806080e7          	jalr	-2042(ra) # 80207154 <iunlock>
    80205956:	b749                	j	802058d8 <mmap_cleanup+0x68>
                }
            }
            fileclose(v->f);
    80205958:	02093503          	ld	a0,32(s2)
    8020595c:	00002097          	auipc	ra,0x2
    80205960:	0e4080e7          	jalr	228(ra) # 80207a40 <fileclose>
            v->used = 0;
    80205964:	00092023          	sw	zero,0(s2)
    for (int i = 0; i < NVMA; i++) {
    80205968:	03098993          	addi	s3,s3,48
    8020596c:	01798e63          	beq	s3,s7,80205988 <mmap_cleanup+0x118>
        struct vma *v = &tab[i];
    80205970:	894e                	mv	s2,s3
        if (v->used) {
    80205972:	0009a783          	lw	a5,0(s3)
    80205976:	dbed                	beqz	a5,80205968 <mmap_cleanup+0xf8>
            for (uint64 a = v->start; a < v->start + v->len; a += PGSIZE) {
    80205978:	0089b483          	ld	s1,8(s3)
    8020597c:	0109b783          	ld	a5,16(s3)
    80205980:	97a6                	add	a5,a5,s1
    80205982:	f6f4ece3          	bltu	s1,a5,802058fa <mmap_cleanup+0x8a>
    80205986:	bfc9                	j	80205958 <mmap_cleanup+0xe8>
        }
    }
}
    80205988:	60a6                	ld	ra,72(sp)
    8020598a:	6406                	ld	s0,64(sp)
    8020598c:	74e2                	ld	s1,56(sp)
    8020598e:	7942                	ld	s2,48(sp)
    80205990:	79a2                	ld	s3,40(sp)
    80205992:	7a02                	ld	s4,32(sp)
    80205994:	6ae2                	ld	s5,24(sp)
    80205996:	6b42                	ld	s6,16(sp)
    80205998:	6ba2                	ld	s7,8(sp)
    8020599a:	6c02                	ld	s8,0(sp)
    8020599c:	6161                	addi	sp,sp,80
    8020599e:	8082                	ret

00000000802059a0 <install_trans>:
}

/* install: copy logged blocks from the log region to their home locations */
static void install_trans(void)
{
    for (int t = 0; t < log.lh.n; t++) {
    802059a0:	00146797          	auipc	a5,0x146
    802059a4:	ae07a783          	lw	a5,-1312(a5) # 8034b480 <log+0x28>
    802059a8:	08f05f63          	blez	a5,80205a46 <install_trans+0xa6>
{
    802059ac:	7139                	addi	sp,sp,-64
    802059ae:	fc06                	sd	ra,56(sp)
    802059b0:	f822                	sd	s0,48(sp)
    802059b2:	f426                	sd	s1,40(sp)
    802059b4:	f04a                	sd	s2,32(sp)
    802059b6:	ec4e                	sd	s3,24(sp)
    802059b8:	e852                	sd	s4,16(sp)
    802059ba:	e456                	sd	s5,8(sp)
    802059bc:	0080                	addi	s0,sp,64
    802059be:	00146a17          	auipc	s4,0x146
    802059c2:	ac6a0a13          	addi	s4,s4,-1338 # 8034b484 <log+0x2c>
    for (int t = 0; t < log.lh.n; t++) {
    802059c6:	4981                	li	s3,0
        struct buf *from = bread(1, log.start + 1 + t);      /* from log */
    802059c8:	00146a97          	auipc	s5,0x146
    802059cc:	a90a8a93          	addi	s5,s5,-1392 # 8034b458 <log>
    802059d0:	018aa583          	lw	a1,24(s5)
    802059d4:	2585                	addiw	a1,a1,1 # fffffffffffff001 <uart+0xffffffff7fca4fd1>
    802059d6:	013585bb          	addw	a1,a1,s3
    802059da:	4505                	li	a0,1
    802059dc:	00001097          	auipc	ra,0x1
    802059e0:	e76080e7          	jalr	-394(ra) # 80206852 <bread>
    802059e4:	892a                	mv	s2,a0
        struct buf *to   = bread(1, log.lh.block[t]);        /* home block */
    802059e6:	000a2583          	lw	a1,0(s4)
    802059ea:	4505                	li	a0,1
    802059ec:	00001097          	auipc	ra,0x1
    802059f0:	e66080e7          	jalr	-410(ra) # 80206852 <bread>
    802059f4:	84aa                	mv	s1,a0
        memmove(to->data, from->data, BSIZE);
    802059f6:	40000613          	li	a2,1024
    802059fa:	05890593          	addi	a1,s2,88
    802059fe:	05850513          	addi	a0,a0,88
    80205a02:	ffffb097          	auipc	ra,0xffffb
    80205a06:	cd6080e7          	jalr	-810(ra) # 802006d8 <memmove>
        bwrite(to);
    80205a0a:	8526                	mv	a0,s1
    80205a0c:	00001097          	auipc	ra,0x1
    80205a10:	f38080e7          	jalr	-200(ra) # 80206944 <bwrite>
        brelse(from);
    80205a14:	854a                	mv	a0,s2
    80205a16:	00001097          	auipc	ra,0x1
    80205a1a:	f6c080e7          	jalr	-148(ra) # 80206982 <brelse>
        brelse(to);
    80205a1e:	8526                	mv	a0,s1
    80205a20:	00001097          	auipc	ra,0x1
    80205a24:	f62080e7          	jalr	-158(ra) # 80206982 <brelse>
    for (int t = 0; t < log.lh.n; t++) {
    80205a28:	2985                	addiw	s3,s3,1
    80205a2a:	0a11                	addi	s4,s4,4
    80205a2c:	028aa783          	lw	a5,40(s5)
    80205a30:	faf9c0e3          	blt	s3,a5,802059d0 <install_trans+0x30>
    }
}
    80205a34:	70e2                	ld	ra,56(sp)
    80205a36:	7442                	ld	s0,48(sp)
    80205a38:	74a2                	ld	s1,40(sp)
    80205a3a:	7902                	ld	s2,32(sp)
    80205a3c:	69e2                	ld	s3,24(sp)
    80205a3e:	6a42                	ld	s4,16(sp)
    80205a40:	6aa2                	ld	s5,8(sp)
    80205a42:	6121                	addi	sp,sp,64
    80205a44:	8082                	ret
    80205a46:	8082                	ret

0000000080205a48 <write_head>:

/* the header lives in the first log block; its n field is the commit flag */
static void write_head(void)
{
    80205a48:	1101                	addi	sp,sp,-32
    80205a4a:	ec06                	sd	ra,24(sp)
    80205a4c:	e822                	sd	s0,16(sp)
    80205a4e:	e426                	sd	s1,8(sp)
    80205a50:	e04a                	sd	s2,0(sp)
    80205a52:	1000                	addi	s0,sp,32
    struct buf *b = bread(1, log.start);
    80205a54:	00146917          	auipc	s2,0x146
    80205a58:	a0490913          	addi	s2,s2,-1532 # 8034b458 <log>
    80205a5c:	01892583          	lw	a1,24(s2)
    80205a60:	4505                	li	a0,1
    80205a62:	00001097          	auipc	ra,0x1
    80205a66:	df0080e7          	jalr	-528(ra) # 80206852 <bread>
    80205a6a:	84aa                	mv	s1,a0
    struct logheader *hb = (struct logheader *)b->data;
    hb->n = log.lh.n;
    80205a6c:	02892603          	lw	a2,40(s2)
    80205a70:	cd30                	sw	a2,88(a0)
    for (int i = 0; i < log.lh.n; i++) hb->block[i] = log.lh.block[i];
    80205a72:	00c05f63          	blez	a2,80205a90 <write_head+0x48>
    80205a76:	00146717          	auipc	a4,0x146
    80205a7a:	a0e70713          	addi	a4,a4,-1522 # 8034b484 <log+0x2c>
    80205a7e:	87aa                	mv	a5,a0
    80205a80:	060a                	slli	a2,a2,0x2
    80205a82:	962a                	add	a2,a2,a0
    80205a84:	4314                	lw	a3,0(a4)
    80205a86:	cff4                	sw	a3,92(a5)
    80205a88:	0711                	addi	a4,a4,4
    80205a8a:	0791                	addi	a5,a5,4
    80205a8c:	fec79ce3          	bne	a5,a2,80205a84 <write_head+0x3c>
    bwrite(b);
    80205a90:	8526                	mv	a0,s1
    80205a92:	00001097          	auipc	ra,0x1
    80205a96:	eb2080e7          	jalr	-334(ra) # 80206944 <bwrite>
    brelse(b);
    80205a9a:	8526                	mv	a0,s1
    80205a9c:	00001097          	auipc	ra,0x1
    80205aa0:	ee6080e7          	jalr	-282(ra) # 80206982 <brelse>
}
    80205aa4:	60e2                	ld	ra,24(sp)
    80205aa6:	6442                	ld	s0,16(sp)
    80205aa8:	64a2                	ld	s1,8(sp)
    80205aaa:	6902                	ld	s2,0(sp)
    80205aac:	6105                	addi	sp,sp,32
    80205aae:	8082                	ret

0000000080205ab0 <write_log>:
    for (int t = 0; t < log.lh.n; t++) {
    80205ab0:	00146797          	auipc	a5,0x146
    80205ab4:	9d07a783          	lw	a5,-1584(a5) # 8034b480 <log+0x28>
    80205ab8:	08f05f63          	blez	a5,80205b56 <write_log+0xa6>
{
    80205abc:	7139                	addi	sp,sp,-64
    80205abe:	fc06                	sd	ra,56(sp)
    80205ac0:	f822                	sd	s0,48(sp)
    80205ac2:	f426                	sd	s1,40(sp)
    80205ac4:	f04a                	sd	s2,32(sp)
    80205ac6:	ec4e                	sd	s3,24(sp)
    80205ac8:	e852                	sd	s4,16(sp)
    80205aca:	e456                	sd	s5,8(sp)
    80205acc:	0080                	addi	s0,sp,64
    80205ace:	00146a17          	auipc	s4,0x146
    80205ad2:	9b6a0a13          	addi	s4,s4,-1610 # 8034b484 <log+0x2c>
    for (int t = 0; t < log.lh.n; t++) {
    80205ad6:	4981                	li	s3,0
        struct buf *to   = bread(1, log.start + 1 + t);      /* log slot */
    80205ad8:	00146a97          	auipc	s5,0x146
    80205adc:	980a8a93          	addi	s5,s5,-1664 # 8034b458 <log>
    80205ae0:	018aa583          	lw	a1,24(s5)
    80205ae4:	2585                	addiw	a1,a1,1
    80205ae6:	013585bb          	addw	a1,a1,s3
    80205aea:	4505                	li	a0,1
    80205aec:	00001097          	auipc	ra,0x1
    80205af0:	d66080e7          	jalr	-666(ra) # 80206852 <bread>
    80205af4:	84aa                	mv	s1,a0
        struct buf *from = bread(1, log.lh.block[t]);        /* cached block */
    80205af6:	000a2583          	lw	a1,0(s4)
    80205afa:	4505                	li	a0,1
    80205afc:	00001097          	auipc	ra,0x1
    80205b00:	d56080e7          	jalr	-682(ra) # 80206852 <bread>
    80205b04:	892a                	mv	s2,a0
        memmove(to->data, from->data, BSIZE);
    80205b06:	40000613          	li	a2,1024
    80205b0a:	05850593          	addi	a1,a0,88
    80205b0e:	05848513          	addi	a0,s1,88
    80205b12:	ffffb097          	auipc	ra,0xffffb
    80205b16:	bc6080e7          	jalr	-1082(ra) # 802006d8 <memmove>
        bwrite(to);
    80205b1a:	8526                	mv	a0,s1
    80205b1c:	00001097          	auipc	ra,0x1
    80205b20:	e28080e7          	jalr	-472(ra) # 80206944 <bwrite>
        brelse(from);
    80205b24:	854a                	mv	a0,s2
    80205b26:	00001097          	auipc	ra,0x1
    80205b2a:	e5c080e7          	jalr	-420(ra) # 80206982 <brelse>
        brelse(to);
    80205b2e:	8526                	mv	a0,s1
    80205b30:	00001097          	auipc	ra,0x1
    80205b34:	e52080e7          	jalr	-430(ra) # 80206982 <brelse>
    for (int t = 0; t < log.lh.n; t++) {
    80205b38:	2985                	addiw	s3,s3,1
    80205b3a:	0a11                	addi	s4,s4,4
    80205b3c:	028aa783          	lw	a5,40(s5)
    80205b40:	faf9c0e3          	blt	s3,a5,80205ae0 <write_log+0x30>
}
    80205b44:	70e2                	ld	ra,56(sp)
    80205b46:	7442                	ld	s0,48(sp)
    80205b48:	74a2                	ld	s1,40(sp)
    80205b4a:	7902                	ld	s2,32(sp)
    80205b4c:	69e2                	ld	s3,24(sp)
    80205b4e:	6a42                	ld	s4,16(sp)
    80205b50:	6aa2                	ld	s5,8(sp)
    80205b52:	6121                	addi	sp,sp,64
    80205b54:	8082                	ret
    80205b56:	8082                	ret

0000000080205b58 <log_init>:
{
    80205b58:	1101                	addi	sp,sp,-32
    80205b5a:	ec06                	sd	ra,24(sp)
    80205b5c:	e822                	sd	s0,16(sp)
    80205b5e:	e426                	sd	s1,8(sp)
    80205b60:	1000                	addi	s0,sp,32
    initlock(&log.lock, "log");
    80205b62:	00146497          	auipc	s1,0x146
    80205b66:	8f648493          	addi	s1,s1,-1802 # 8034b458 <log>
    80205b6a:	00004597          	auipc	a1,0x4
    80205b6e:	fee58593          	addi	a1,a1,-18 # 80209b58 <etext+0xb58>
    80205b72:	8526                	mv	a0,s1
    80205b74:	ffffc097          	auipc	ra,0xffffc
    80205b78:	898080e7          	jalr	-1896(ra) # 8020140c <initlock>
    log.start = sb.logstart;
    80205b7c:	0014e797          	auipc	a5,0x14e
    80205b80:	0ec78793          	addi	a5,a5,236 # 80353c68 <sb>
    80205b84:	578c                	lw	a1,40(a5)
    80205b86:	cc8c                	sw	a1,24(s1)
    log.size  = sb.nlog;
    80205b88:	53dc                	lw	a5,36(a5)
    80205b8a:	ccdc                	sw	a5,28(s1)
    log.lh.n  = 0;
    80205b8c:	0204a423          	sw	zero,40(s1)

static void read_head(void)
{
    struct buf *b = bread(1, log.start);
    80205b90:	4505                	li	a0,1
    80205b92:	00001097          	auipc	ra,0x1
    80205b96:	cc0080e7          	jalr	-832(ra) # 80206852 <bread>
    struct logheader *hb = (struct logheader *)b->data;
    log.lh.n = hb->n;
    80205b9a:	4d30                	lw	a2,88(a0)
    80205b9c:	d490                	sw	a2,40(s1)
    for (int i = 0; i < log.lh.n && i < 30; i++) log.lh.block[i] = hb->block[i];
    80205b9e:	02c05663          	blez	a2,80205bca <log_init+0x72>
    80205ba2:	367d                	addiw	a2,a2,-1 # fff <_entry-0x801ff001>
    80205ba4:	02061793          	slli	a5,a2,0x20
    80205ba8:	01e7d613          	srli	a2,a5,0x1e
    80205bac:	4781                	li	a5,0
    80205bae:	85a6                	mv	a1,s1
    80205bb0:	07800813          	li	a6,120
    80205bb4:	00f50733          	add	a4,a0,a5
    80205bb8:	4f74                	lw	a3,92(a4)
    80205bba:	00f58733          	add	a4,a1,a5
    80205bbe:	d754                	sw	a3,44(a4)
    80205bc0:	00c78563          	beq	a5,a2,80205bca <log_init+0x72>
    80205bc4:	0791                	addi	a5,a5,4
    80205bc6:	ff0797e3          	bne	a5,a6,80205bb4 <log_init+0x5c>
    brelse(b);
    80205bca:	00001097          	auipc	ra,0x1
    80205bce:	db8080e7          	jalr	-584(ra) # 80206982 <brelse>
    install_trans();             /* replay */
    80205bd2:	00000097          	auipc	ra,0x0
    80205bd6:	dce080e7          	jalr	-562(ra) # 802059a0 <install_trans>
    log.lh.n = 0;
    80205bda:	00146797          	auipc	a5,0x146
    80205bde:	8a07a323          	sw	zero,-1882(a5) # 8034b480 <log+0x28>
    write_head();                /* clear */
    80205be2:	00000097          	auipc	ra,0x0
    80205be6:	e66080e7          	jalr	-410(ra) # 80205a48 <write_head>
}
    80205bea:	60e2                	ld	ra,24(sp)
    80205bec:	6442                	ld	s0,16(sp)
    80205bee:	64a2                	ld	s1,8(sp)
    80205bf0:	6105                	addi	sp,sp,32
    80205bf2:	8082                	ret

0000000080205bf4 <begin_op>:
{
    80205bf4:	1101                	addi	sp,sp,-32
    80205bf6:	ec06                	sd	ra,24(sp)
    80205bf8:	e822                	sd	s0,16(sp)
    80205bfa:	e426                	sd	s1,8(sp)
    80205bfc:	1000                	addi	s0,sp,32
    acquire(&log.lock);
    80205bfe:	00146517          	auipc	a0,0x146
    80205c02:	85a50513          	addi	a0,a0,-1958 # 8034b458 <log>
    80205c06:	ffffc097          	auipc	ra,0xffffc
    80205c0a:	882080e7          	jalr	-1918(ra) # 80201488 <acquire>
    while (log.committing || log.lh.n + (log.outstanding + 1) * MAXOP > log.size - 1)
    80205c0e:	00146497          	auipc	s1,0x146
    80205c12:	84a48493          	addi	s1,s1,-1974 # 8034b458 <log>
    80205c16:	a039                	j	80205c24 <begin_op+0x30>
        sleep(&log, &log.lock);
    80205c18:	85a6                	mv	a1,s1
    80205c1a:	8526                	mv	a0,s1
    80205c1c:	ffffc097          	auipc	ra,0xffffc
    80205c20:	4ca080e7          	jalr	1226(ra) # 802020e6 <sleep>
    while (log.committing || log.lh.n + (log.outstanding + 1) * MAXOP > log.size - 1)
    80205c24:	50dc                	lw	a5,36(s1)
    80205c26:	fbed                	bnez	a5,80205c18 <begin_op+0x24>
    80205c28:	5098                	lw	a4,32(s1)
    80205c2a:	2705                	addiw	a4,a4,1
    80205c2c:	0047179b          	slliw	a5,a4,0x4
    80205c30:	9f99                	subw	a5,a5,a4
    80205c32:	5490                	lw	a2,40(s1)
    80205c34:	4cd4                	lw	a3,28(s1)
    80205c36:	9fb1                	addw	a5,a5,a2
    80205c38:	fed7d0e3          	bge	a5,a3,80205c18 <begin_op+0x24>
    log.outstanding++;
    80205c3c:	00146517          	auipc	a0,0x146
    80205c40:	81c50513          	addi	a0,a0,-2020 # 8034b458 <log>
    80205c44:	d118                	sw	a4,32(a0)
    release(&log.lock);
    80205c46:	ffffc097          	auipc	ra,0xffffc
    80205c4a:	8f6080e7          	jalr	-1802(ra) # 8020153c <release>
}
    80205c4e:	60e2                	ld	ra,24(sp)
    80205c50:	6442                	ld	s0,16(sp)
    80205c52:	64a2                	ld	s1,8(sp)
    80205c54:	6105                	addi	sp,sp,32
    80205c56:	8082                	ret

0000000080205c58 <end_op>:
{
    80205c58:	1101                	addi	sp,sp,-32
    80205c5a:	ec06                	sd	ra,24(sp)
    80205c5c:	e822                	sd	s0,16(sp)
    80205c5e:	e426                	sd	s1,8(sp)
    80205c60:	1000                	addi	s0,sp,32
    acquire(&log.lock);
    80205c62:	00145497          	auipc	s1,0x145
    80205c66:	7f648493          	addi	s1,s1,2038 # 8034b458 <log>
    80205c6a:	8526                	mv	a0,s1
    80205c6c:	ffffc097          	auipc	ra,0xffffc
    80205c70:	81c080e7          	jalr	-2020(ra) # 80201488 <acquire>
    log.outstanding--;
    80205c74:	509c                	lw	a5,32(s1)
    80205c76:	37fd                	addiw	a5,a5,-1
    80205c78:	0007871b          	sext.w	a4,a5
    80205c7c:	d09c                	sw	a5,32(s1)
    if (log.outstanding == 0) { do_commit = 1; log.committing = 1; }
    80205c7e:	e325                	bnez	a4,80205cde <end_op+0x86>
    80205c80:	4785                	li	a5,1
    80205c82:	d0dc                	sw	a5,36(s1)
    release(&log.lock);
    80205c84:	8526                	mv	a0,s1
    80205c86:	ffffc097          	auipc	ra,0xffffc
    80205c8a:	8b6080e7          	jalr	-1866(ra) # 8020153c <release>
        write_log();             /* 1. blocks -> log region */
    80205c8e:	00000097          	auipc	ra,0x0
    80205c92:	e22080e7          	jalr	-478(ra) # 80205ab0 <write_log>
        write_head();            /* 2. commit point: header on disk */
    80205c96:	00000097          	auipc	ra,0x0
    80205c9a:	db2080e7          	jalr	-590(ra) # 80205a48 <write_head>
        install_trans();         /* 3. log -> home */
    80205c9e:	00000097          	auipc	ra,0x0
    80205ca2:	d02080e7          	jalr	-766(ra) # 802059a0 <install_trans>
        log.lh.n = 0;
    80205ca6:	0204a423          	sw	zero,40(s1)
        write_head();            /* 4. clear */
    80205caa:	00000097          	auipc	ra,0x0
    80205cae:	d9e080e7          	jalr	-610(ra) # 80205a48 <write_head>
        acquire(&log.lock);
    80205cb2:	8526                	mv	a0,s1
    80205cb4:	ffffb097          	auipc	ra,0xffffb
    80205cb8:	7d4080e7          	jalr	2004(ra) # 80201488 <acquire>
        log.committing = 0;
    80205cbc:	0204a223          	sw	zero,36(s1)
        wakeup(&log);
    80205cc0:	8526                	mv	a0,s1
    80205cc2:	ffffc097          	auipc	ra,0xffffc
    80205cc6:	5aa080e7          	jalr	1450(ra) # 8020226c <wakeup>
        release(&log.lock);
    80205cca:	8526                	mv	a0,s1
    80205ccc:	ffffc097          	auipc	ra,0xffffc
    80205cd0:	870080e7          	jalr	-1936(ra) # 8020153c <release>
}
    80205cd4:	60e2                	ld	ra,24(sp)
    80205cd6:	6442                	ld	s0,16(sp)
    80205cd8:	64a2                	ld	s1,8(sp)
    80205cda:	6105                	addi	sp,sp,32
    80205cdc:	8082                	ret
    else wakeup(&log);
    80205cde:	00145497          	auipc	s1,0x145
    80205ce2:	77a48493          	addi	s1,s1,1914 # 8034b458 <log>
    80205ce6:	8526                	mv	a0,s1
    80205ce8:	ffffc097          	auipc	ra,0xffffc
    80205cec:	584080e7          	jalr	1412(ra) # 8020226c <wakeup>
    release(&log.lock);
    80205cf0:	8526                	mv	a0,s1
    80205cf2:	ffffc097          	auipc	ra,0xffffc
    80205cf6:	84a080e7          	jalr	-1974(ra) # 8020153c <release>
}
    80205cfa:	bfe9                	j	80205cd4 <end_op+0x7c>

0000000080205cfc <log_commit_only>:
{
    80205cfc:	1141                	addi	sp,sp,-16
    80205cfe:	e406                	sd	ra,8(sp)
    80205d00:	e022                	sd	s0,0(sp)
    80205d02:	0800                	addi	s0,sp,16
    write_log();
    80205d04:	00000097          	auipc	ra,0x0
    80205d08:	dac080e7          	jalr	-596(ra) # 80205ab0 <write_log>
    write_head();
    80205d0c:	00000097          	auipc	ra,0x0
    80205d10:	d3c080e7          	jalr	-708(ra) # 80205a48 <write_head>
}
    80205d14:	60a2                	ld	ra,8(sp)
    80205d16:	6402                	ld	s0,0(sp)
    80205d18:	0141                	addi	sp,sp,16
    80205d1a:	8082                	ret

0000000080205d1c <log_write>:
{
    80205d1c:	1101                	addi	sp,sp,-32
    80205d1e:	ec06                	sd	ra,24(sp)
    80205d20:	e822                	sd	s0,16(sp)
    80205d22:	e426                	sd	s1,8(sp)
    80205d24:	e04a                	sd	s2,0(sp)
    80205d26:	1000                	addi	s0,sp,32
    80205d28:	84aa                	mv	s1,a0
    acquire(&log.lock);
    80205d2a:	00145917          	auipc	s2,0x145
    80205d2e:	72e90913          	addi	s2,s2,1838 # 8034b458 <log>
    80205d32:	854a                	mv	a0,s2
    80205d34:	ffffb097          	auipc	ra,0xffffb
    80205d38:	754080e7          	jalr	1876(ra) # 80201488 <acquire>
    for (i = 0; i < log.lh.n; i++)
    80205d3c:	02892603          	lw	a2,40(s2)
    80205d40:	02c05f63          	blez	a2,80205d7e <log_write+0x62>
        if (log.lh.block[i] == (int)b->blockno) break;   /* absorb duplicate */
    80205d44:	44cc                	lw	a1,12(s1)
    80205d46:	00145717          	auipc	a4,0x145
    80205d4a:	73e70713          	addi	a4,a4,1854 # 8034b484 <log+0x2c>
    for (i = 0; i < log.lh.n; i++)
    80205d4e:	4781                	li	a5,0
        if (log.lh.block[i] == (int)b->blockno) break;   /* absorb duplicate */
    80205d50:	4314                	lw	a3,0(a4)
    80205d52:	02b68763          	beq	a3,a1,80205d80 <log_write+0x64>
    for (i = 0; i < log.lh.n; i++)
    80205d56:	2785                	addiw	a5,a5,1
    80205d58:	0711                	addi	a4,a4,4
    80205d5a:	fec79be3          	bne	a5,a2,80205d50 <log_write+0x34>
    log.lh.block[i] = b->blockno;
    80205d5e:	00860713          	addi	a4,a2,8
    80205d62:	070a                	slli	a4,a4,0x2
    80205d64:	00145797          	auipc	a5,0x145
    80205d68:	6f478793          	addi	a5,a5,1780 # 8034b458 <log>
    80205d6c:	97ba                	add	a5,a5,a4
    80205d6e:	44d8                	lw	a4,12(s1)
    80205d70:	c7d8                	sw	a4,12(a5)
    if (i == log.lh.n) log.lh.n++;
    80205d72:	2605                	addiw	a2,a2,1
    80205d74:	00145797          	auipc	a5,0x145
    80205d78:	70c7a623          	sw	a2,1804(a5) # 8034b480 <log+0x28>
    80205d7c:	a831                	j	80205d98 <log_write+0x7c>
    for (i = 0; i < log.lh.n; i++)
    80205d7e:	4781                	li	a5,0
    log.lh.block[i] = b->blockno;
    80205d80:	00878693          	addi	a3,a5,8
    80205d84:	068a                	slli	a3,a3,0x2
    80205d86:	00145717          	auipc	a4,0x145
    80205d8a:	6d270713          	addi	a4,a4,1746 # 8034b458 <log>
    80205d8e:	9736                	add	a4,a4,a3
    80205d90:	44d4                	lw	a3,12(s1)
    80205d92:	c754                	sw	a3,12(a4)
    if (i == log.lh.n) log.lh.n++;
    80205d94:	02f60363          	beq	a2,a5,80205dba <log_write+0x9e>
    b->refcnt++;                 /* pin in cache until installed */
    80205d98:	40bc                	lw	a5,64(s1)
    80205d9a:	2785                	addiw	a5,a5,1
    80205d9c:	c0bc                	sw	a5,64(s1)
    release(&log.lock);
    80205d9e:	00145517          	auipc	a0,0x145
    80205da2:	6ba50513          	addi	a0,a0,1722 # 8034b458 <log>
    80205da6:	ffffb097          	auipc	ra,0xffffb
    80205daa:	796080e7          	jalr	1942(ra) # 8020153c <release>
}
    80205dae:	60e2                	ld	ra,24(sp)
    80205db0:	6442                	ld	s0,16(sp)
    80205db2:	64a2                	ld	s1,8(sp)
    80205db4:	6902                	ld	s2,0(sp)
    80205db6:	6105                	addi	sp,sp,32
    80205db8:	8082                	ret
    80205dba:	863e                	mv	a2,a5
    80205dbc:	bf5d                	j	80205d72 <log_write+0x56>

0000000080205dbe <bmap_used>:

extern struct superblock sb;

/* is data block b marked used in the data bitmap? */
static int bmap_used(int dev, uint32 b)
{
    80205dbe:	1101                	addi	sp,sp,-32
    80205dc0:	ec06                	sd	ra,24(sp)
    80205dc2:	e822                	sd	s0,16(sp)
    80205dc4:	e426                	sd	s1,8(sp)
    80205dc6:	1000                	addi	s0,sp,32
    80205dc8:	84ae                	mv	s1,a1
    struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80205dca:	00d5d59b          	srliw	a1,a1,0xd
    80205dce:	0014e797          	auipc	a5,0x14e
    80205dd2:	eb27a783          	lw	a5,-334(a5) # 80353c80 <sb+0x18>
    80205dd6:	9dbd                	addw	a1,a1,a5
    80205dd8:	00001097          	auipc	ra,0x1
    80205ddc:	a7a080e7          	jalr	-1414(ra) # 80206852 <bread>
    uint32 bi = b % BPB;
    80205de0:	03349793          	slli	a5,s1,0x33
    int m = 1 << (bi % 8);
    int used = (bp->data[bi / 8] & m) != 0;
    80205de4:	93d9                	srli	a5,a5,0x36
    80205de6:	00f50733          	add	a4,a0,a5
    int m = 1 << (bi % 8);
    80205dea:	889d                	andi	s1,s1,7
    80205dec:	4785                	li	a5,1
    80205dee:	009797bb          	sllw	a5,a5,s1
    int used = (bp->data[bi / 8] & m) != 0;
    80205df2:	05874483          	lbu	s1,88(a4)
    80205df6:	8cfd                	and	s1,s1,a5
    80205df8:	009034b3          	snez	s1,s1
    brelse(bp);
    80205dfc:	00001097          	auipc	ra,0x1
    80205e00:	b86080e7          	jalr	-1146(ra) # 80206982 <brelse>
    return used;
}
    80205e04:	8526                	mv	a0,s1
    80205e06:	60e2                	ld	ra,24(sp)
    80205e08:	6442                	ld	s0,16(sp)
    80205e0a:	64a2                	ld	s1,8(sp)
    80205e0c:	6105                	addi	sp,sp,32
    80205e0e:	8082                	ret

0000000080205e10 <fsck>:
 * We use a scratch page as a bitmap over data blocks (ndata up to ~32k fits in
 * one 4KB page = 32768 bits). */
#define FSCK_MAXDATA (PGSIZE * 8)

int fsck(int dev)
{
    80205e10:	7131                	addi	sp,sp,-192
    80205e12:	fd06                	sd	ra,184(sp)
    80205e14:	f922                	sd	s0,176(sp)
    80205e16:	f8e2                	sd	s8,112(sp)
    80205e18:	0180                	addi	s0,sp,192
    if (sb.ndata > FSCK_MAXDATA) return -99;      /* fs too big for this checker */
    80205e1a:	0014e717          	auipc	a4,0x14e
    80205e1e:	e5e72703          	lw	a4,-418(a4) # 80353c78 <sb+0x10>
    80205e22:	67a1                	lui	a5,0x8
    80205e24:	1ae7ec63          	bltu	a5,a4,80205fdc <fsck+0x1cc>
    80205e28:	e952                	sd	s4,144(sp)
    80205e2a:	e556                	sd	s5,136(sp)
    80205e2c:	8aaa                	mv	s5,a0

    uint8 *seen = (uint8 *)palloc();
    80205e2e:	ffffb097          	auipc	ra,0xffffb
    80205e32:	2b8080e7          	jalr	696(ra) # 802010e6 <palloc>
    80205e36:	8a2a                	mv	s4,a0
    if (!seen) return -1;
    80205e38:	1a050563          	beqz	a0,80205fe2 <fsck+0x1d2>
    memset(seen, 0, PGSIZE);
    80205e3c:	6605                	lui	a2,0x1
    80205e3e:	4581                	li	a1,0
    80205e40:	ffffb097          	auipc	ra,0xffffb
    80205e44:	87c080e7          	jalr	-1924(ra) # 802006bc <memset>

    int violation = 0;

    /* walk every inode */
    for (uint32 inum = 1; inum < sb.ninodes && !violation; inum++) {
    80205e48:	0014e717          	auipc	a4,0x14e
    80205e4c:	e2c72703          	lw	a4,-468(a4) # 80353c74 <sb+0xc>
    80205e50:	4785                	li	a5,1
    80205e52:	16e7fa63          	bgeu	a5,a4,80205fc6 <fsck+0x1b6>
    80205e56:	f526                	sd	s1,168(sp)
    80205e58:	f14a                	sd	s2,160(sp)
    80205e5a:	ed4e                	sd	s3,152(sp)
    80205e5c:	e15a                	sd	s6,128(sp)
    80205e5e:	fcde                	sd	s7,120(sp)
    80205e60:	f4e6                	sd	s9,104(sp)
    80205e62:	f0ea                	sd	s10,96(sp)
    80205e64:	ecee                	sd	s11,88(sp)
    80205e66:	4985                	li	s3,1
        struct buf *ibp = bread(dev, IBBLOCK(inum, sb));
    80205e68:	000a8b9b          	sext.w	s7,s5
    80205e6c:	0014e917          	auipc	s2,0x14e
    80205e70:	dfc90913          	addi	s2,s2,-516 # 80353c68 <sb>
    80205e74:	f8c40493          	addi	s1,s0,-116
        int nlink = din->nlink;
        uint32 addrs[NDIRECT + 1];
        for (int k = 0; k < NDIRECT + 1; k++) addrs[k] = din->addrs[k];
        brelse(ibp);

        if (type != T_DIR && type != T_FILE && type != T_DEV)
    80205e78:	4c89                	li	s9,2
            uint32 b = addrs[k];
            if (b == 0) continue;
            if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
            uint32 di = b - sb.datastart;
            if (seen[di / 8] & (1 << (di % 8))) { violation = 4; break; }   /* double-alloc */
            seen[di / 8] |= (1 << (di % 8));
    80205e7a:	4b05                	li	s6,1
    80205e7c:	aa49                	j	8020600e <fsck+0x1fe>
        if (nlink < 1) { violation = 2; break; }
    80205e7e:	000d8563          	beqz	s11,80205e88 <fsck+0x78>
    80205e82:	030c0d13          	addi	s10,s8,48 # 1030 <_entry-0x801fefd0>
    80205e86:	a831                	j	80205ea2 <fsck+0x92>
    80205e88:	4c09                	li	s8,2
    80205e8a:	74aa                	ld	s1,168(sp)
    80205e8c:	790a                	ld	s2,160(sp)
    80205e8e:	69ea                	ld	s3,152(sp)
    80205e90:	6b0a                	ld	s6,128(sp)
    80205e92:	7be6                	ld	s7,120(sp)
    80205e94:	7ca6                	ld	s9,104(sp)
    80205e96:	7d06                	ld	s10,96(sp)
    80205e98:	6de6                	ld	s11,88(sp)
    80205e9a:	aa09                	j	80205fac <fsck+0x19c>
        for (int k = 0; k < NDIRECT && !violation; k++) {
    80205e9c:	0c11                	addi	s8,s8,4
    80205e9e:	1fac0063          	beq	s8,s10,8020607e <fsck+0x26e>
            uint32 b = addrs[k];
    80205ea2:	000c2583          	lw	a1,0(s8)
            if (b == 0) continue;
    80205ea6:	d9fd                	beqz	a1,80205e9c <fsck+0x8c>
            if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205ea8:	02092783          	lw	a5,32(s2)
    80205eac:	14f5e963          	bltu	a1,a5,80205ffe <fsck+0x1ee>
    80205eb0:	01092703          	lw	a4,16(s2)
    80205eb4:	9f3d                	addw	a4,a4,a5
    80205eb6:	1ce5f063          	bgeu	a1,a4,80206076 <fsck+0x266>
            uint32 di = b - sb.datastart;
    80205eba:	40f587bb          	subw	a5,a1,a5
            if (seen[di / 8] & (1 << (di % 8))) { violation = 4; break; }   /* double-alloc */
    80205ebe:	0037d71b          	srliw	a4,a5,0x3
    80205ec2:	9752                	add	a4,a4,s4
    80205ec4:	00074683          	lbu	a3,0(a4)
    80205ec8:	8b9d                	andi	a5,a5,7
    80205eca:	40f6d63b          	sraw	a2,a3,a5
    80205ece:	8a05                	andi	a2,a2,1
    80205ed0:	1a061563          	bnez	a2,8020607a <fsck+0x26a>
            seen[di / 8] |= (1 << (di % 8));
    80205ed4:	00fb17bb          	sllw	a5,s6,a5
    80205ed8:	8edd                	or	a3,a3,a5
    80205eda:	00d70023          	sb	a3,0(a4)
            if (!bmap_used(dev, b)) { violation = 5; break; }               /* referenced but free */
    80205ede:	8556                	mv	a0,s5
    80205ee0:	00000097          	auipc	ra,0x0
    80205ee4:	ede080e7          	jalr	-290(ra) # 80205dbe <bmap_used>
    80205ee8:	f955                	bnez	a0,80205e9c <fsck+0x8c>
    80205eea:	4c15                	li	s8,5
        }

        /* check the indirect block and its entries */
        if (!violation && addrs[NDIRECT]) {
    80205eec:	aa11                	j	80206000 <fsck+0x1f0>
            if (ib < sb.datastart || ib >= sb.datastart + sb.ndata) { violation = 3; }
            else {
                uint32 di = ib - sb.datastart;
                if (seen[di / 8] & (1 << (di % 8))) violation = 4;
                else {
                    seen[di / 8] |= (1 << (di % 8));
    80205eee:	4605                	li	a2,1
    80205ef0:	00f617bb          	sllw	a5,a2,a5
    80205ef4:	8edd                	or	a3,a3,a5
    80205ef6:	00d70023          	sb	a3,0(a4)
                    if (!bmap_used(dev, ib)) violation = 5;
    80205efa:	85ea                	mv	a1,s10
    80205efc:	8556                	mv	a0,s5
    80205efe:	00000097          	auipc	ra,0x0
    80205f02:	ec0080e7          	jalr	-320(ra) # 80205dbe <bmap_used>
    80205f06:	c175                	beqz	a0,80205fea <fsck+0x1da>
                    struct buf *bp = bread(dev, ib);
    80205f08:	85ea                	mv	a1,s10
    80205f0a:	855e                	mv	a0,s7
    80205f0c:	00001097          	auipc	ra,0x1
    80205f10:	946080e7          	jalr	-1722(ra) # 80206852 <bread>
    80205f14:	f4a43023          	sd	a0,-192(s0)
                    uint32 *entries = (uint32 *)bp->data;
                    for (int k = 0; k < (int)NINDIRECT && !violation; k++) {
    80205f18:	05850d13          	addi	s10,a0,88
    80205f1c:	45850793          	addi	a5,a0,1112
    80205f20:	f4f43423          	sd	a5,-184(s0)
                        uint32 b = entries[k];
                        if (b == 0) continue;
                        if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205f24:	0014ed97          	auipc	s11,0x14e
    80205f28:	d44d8d93          	addi	s11,s11,-700 # 80353c68 <sb>
    80205f2c:	a031                	j	80205f38 <fsck+0x128>
                    for (int k = 0; k < (int)NINDIRECT && !violation; k++) {
    80205f2e:	0d11                	addi	s10,s10,4
    80205f30:	f4843783          	ld	a5,-184(s0)
    80205f34:	04fd0963          	beq	s10,a5,80205f86 <fsck+0x176>
                        uint32 b = entries[k];
    80205f38:	000d2583          	lw	a1,0(s10)
                        if (b == 0) continue;
    80205f3c:	d9ed                	beqz	a1,80205f2e <fsck+0x11e>
                        if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205f3e:	020da783          	lw	a5,32(s11)
    80205f42:	04f5e163          	bltu	a1,a5,80205f84 <fsck+0x174>
    80205f46:	010da703          	lw	a4,16(s11)
    80205f4a:	9f3d                	addw	a4,a4,a5
    80205f4c:	04e5f463          	bgeu	a1,a4,80205f94 <fsck+0x184>
                        uint32 d2 = b - sb.datastart;
    80205f50:	40f587bb          	subw	a5,a1,a5
                        if (seen[d2 / 8] & (1 << (d2 % 8))) { violation = 4; break; }
    80205f54:	0037d71b          	srliw	a4,a5,0x3
    80205f58:	9752                	add	a4,a4,s4
    80205f5a:	00074683          	lbu	a3,0(a4)
    80205f5e:	8b9d                	andi	a5,a5,7
    80205f60:	40f6d63b          	sraw	a2,a3,a5
    80205f64:	8a05                	andi	a2,a2,1
    80205f66:	ea0d                	bnez	a2,80205f98 <fsck+0x188>
                        seen[d2 / 8] |= (1 << (d2 % 8));
    80205f68:	4605                	li	a2,1
    80205f6a:	00f617bb          	sllw	a5,a2,a5
    80205f6e:	8edd                	or	a3,a3,a5
    80205f70:	00d70023          	sb	a3,0(a4)
                        if (!bmap_used(dev, b)) { violation = 5; break; }
    80205f74:	8556                	mv	a0,s5
    80205f76:	00000097          	auipc	ra,0x0
    80205f7a:	e48080e7          	jalr	-440(ra) # 80205dbe <bmap_used>
    80205f7e:	f945                	bnez	a0,80205f2e <fsck+0x11e>
    80205f80:	4c15                	li	s8,5
    80205f82:	a011                	j	80205f86 <fsck+0x176>
                        if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205f84:	4c0d                	li	s8,3
                    }
                    brelse(bp);
    80205f86:	f4043503          	ld	a0,-192(s0)
    80205f8a:	00001097          	auipc	ra,0x1
    80205f8e:	9f8080e7          	jalr	-1544(ra) # 80206982 <brelse>
    80205f92:	a0bd                	j	80206000 <fsck+0x1f0>
                        if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205f94:	4c0d                	li	s8,3
    80205f96:	bfc5                	j	80205f86 <fsck+0x176>
                        if (seen[d2 / 8] & (1 << (d2 % 8))) { violation = 4; break; }
    80205f98:	4c11                	li	s8,4
    80205f9a:	b7f5                	j	80205f86 <fsck+0x176>
    80205f9c:	74aa                	ld	s1,168(sp)
    80205f9e:	790a                	ld	s2,160(sp)
    80205fa0:	69ea                	ld	s3,152(sp)
    80205fa2:	6b0a                	ld	s6,128(sp)
    80205fa4:	7be6                	ld	s7,120(sp)
    80205fa6:	7ca6                	ld	s9,104(sp)
    80205fa8:	7d06                	ld	s10,96(sp)
    80205faa:	6de6                	ld	s11,88(sp)
                }
            }
        }
    }

    pfree(seen);
    80205fac:	8552                	mv	a0,s4
    80205fae:	ffffb097          	auipc	ra,0xffffb
    80205fb2:	276080e7          	jalr	630(ra) # 80201224 <pfree>
    return violation;
    80205fb6:	6a4a                	ld	s4,144(sp)
    80205fb8:	6aaa                	ld	s5,136(sp)
}
    80205fba:	8562                	mv	a0,s8
    80205fbc:	70ea                	ld	ra,184(sp)
    80205fbe:	744a                	ld	s0,176(sp)
    80205fc0:	7c46                	ld	s8,112(sp)
    80205fc2:	6129                	addi	sp,sp,192
    80205fc4:	8082                	ret
    int violation = 0;
    80205fc6:	4c01                	li	s8,0
    80205fc8:	b7d5                	j	80205fac <fsck+0x19c>
    80205fca:	74aa                	ld	s1,168(sp)
    80205fcc:	790a                	ld	s2,160(sp)
    80205fce:	69ea                	ld	s3,152(sp)
    80205fd0:	6b0a                	ld	s6,128(sp)
    80205fd2:	7be6                	ld	s7,120(sp)
    80205fd4:	7ca6                	ld	s9,104(sp)
    80205fd6:	7d06                	ld	s10,96(sp)
    80205fd8:	6de6                	ld	s11,88(sp)
    80205fda:	bfc9                	j	80205fac <fsck+0x19c>
    if (sb.ndata > FSCK_MAXDATA) return -99;      /* fs too big for this checker */
    80205fdc:	f9d00c13          	li	s8,-99
    80205fe0:	bfe9                	j	80205fba <fsck+0x1aa>
    if (!seen) return -1;
    80205fe2:	5c7d                	li	s8,-1
    80205fe4:	6a4a                	ld	s4,144(sp)
    80205fe6:	6aaa                	ld	s5,136(sp)
    80205fe8:	bfc9                	j	80205fba <fsck+0x1aa>
                    struct buf *bp = bread(dev, ib);
    80205fea:	85ea                	mv	a1,s10
    80205fec:	855e                	mv	a0,s7
    80205fee:	00001097          	auipc	ra,0x1
    80205ff2:	864080e7          	jalr	-1948(ra) # 80206852 <bread>
    80205ff6:	f4a43023          	sd	a0,-192(s0)
                    if (!bmap_used(dev, ib)) violation = 5;
    80205ffa:	4c15                	li	s8,5
    80205ffc:	b769                	j	80205f86 <fsck+0x176>
            if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80205ffe:	4c0d                	li	s8,3
    for (uint32 inum = 1; inum < sb.ninodes && !violation; inum++) {
    80206000:	2985                	addiw	s3,s3,1
    80206002:	00c92783          	lw	a5,12(s2)
    80206006:	fcf9f2e3          	bgeu	s3,a5,80205fca <fsck+0x1ba>
    8020600a:	f80c19e3          	bnez	s8,80205f9c <fsck+0x18c>
        struct buf *ibp = bread(dev, IBBLOCK(inum, sb));
    8020600e:	00d9d59b          	srliw	a1,s3,0xd
    80206012:	01492783          	lw	a5,20(s2)
    80206016:	9dbd                	addw	a1,a1,a5
    80206018:	855e                	mv	a0,s7
    8020601a:	00001097          	auipc	ra,0x1
    8020601e:	838080e7          	jalr	-1992(ra) # 80206852 <bread>
        struct dinode *din = (struct dinode *)ibp->data + (inum % IPB);
    80206022:	05850713          	addi	a4,a0,88
    80206026:	00f9f793          	andi	a5,s3,15
    8020602a:	079a                	slli	a5,a5,0x6
    8020602c:	973e                	add	a4,a4,a5
        int type = din->type;
    8020602e:	00075d03          	lhu	s10,0(a4)
        int nlink = din->nlink;
    80206032:	00675d83          	lhu	s11,6(a4)
        for (int k = 0; k < NDIRECT + 1; k++) addrs[k] = din->addrs[k];
    80206036:	0731                	addi	a4,a4,12
    80206038:	f5840c13          	addi	s8,s0,-168
        int nlink = din->nlink;
    8020603c:	87e2                	mv	a5,s8
        for (int k = 0; k < NDIRECT + 1; k++) addrs[k] = din->addrs[k];
    8020603e:	4314                	lw	a3,0(a4)
    80206040:	c394                	sw	a3,0(a5)
    80206042:	0711                	addi	a4,a4,4
    80206044:	0791                	addi	a5,a5,4 # 8004 <_entry-0x801f7ffc>
    80206046:	fe979ce3          	bne	a5,s1,8020603e <fsck+0x22e>
        brelse(ibp);
    8020604a:	00001097          	auipc	ra,0x1
    8020604e:	938080e7          	jalr	-1736(ra) # 80206982 <brelse>
        if (type != T_DIR && type != T_FILE && type != T_DEV)
    80206052:	3d7d                	addiw	s10,s10,-1
    80206054:	e3acf5e3          	bgeu	s9,s10,80205e7e <fsck+0x6e>
    for (uint32 inum = 1; inum < sb.ninodes && !violation; inum++) {
    80206058:	2985                	addiw	s3,s3,1
    8020605a:	00c92783          	lw	a5,12(s2)
    8020605e:	faf9e8e3          	bltu	s3,a5,8020600e <fsck+0x1fe>
    80206062:	4c01                	li	s8,0
    80206064:	74aa                	ld	s1,168(sp)
    80206066:	790a                	ld	s2,160(sp)
    80206068:	69ea                	ld	s3,152(sp)
    8020606a:	6b0a                	ld	s6,128(sp)
    8020606c:	7be6                	ld	s7,120(sp)
    8020606e:	7ca6                	ld	s9,104(sp)
    80206070:	7d06                	ld	s10,96(sp)
    80206072:	6de6                	ld	s11,88(sp)
    80206074:	bf25                	j	80205fac <fsck+0x19c>
            if (b < sb.datastart || b >= sb.datastart + sb.ndata) { violation = 3; break; }
    80206076:	4c0d                	li	s8,3
    80206078:	b761                	j	80206000 <fsck+0x1f0>
            if (seen[di / 8] & (1 << (di % 8))) { violation = 4; break; }   /* double-alloc */
    8020607a:	4c11                	li	s8,4
    8020607c:	b751                	j	80206000 <fsck+0x1f0>
        if (!violation && addrs[NDIRECT]) {
    8020607e:	f8842d03          	lw	s10,-120(s0)
    80206082:	4c01                	li	s8,0
    80206084:	f60d0ee3          	beqz	s10,80206000 <fsck+0x1f0>
            if (ib < sb.datastart || ib >= sb.datastart + sb.ndata) { violation = 3; }
    80206088:	02092783          	lw	a5,32(s2)
    8020608c:	4c0d                	li	s8,3
    8020608e:	f6fd69e3          	bltu	s10,a5,80206000 <fsck+0x1f0>
    80206092:	0014e717          	auipc	a4,0x14e
    80206096:	be672703          	lw	a4,-1050(a4) # 80353c78 <sb+0x10>
    8020609a:	9f3d                	addw	a4,a4,a5
    8020609c:	f6ed72e3          	bgeu	s10,a4,80206000 <fsck+0x1f0>
                uint32 di = ib - sb.datastart;
    802060a0:	40fd07bb          	subw	a5,s10,a5
                if (seen[di / 8] & (1 << (di % 8))) violation = 4;
    802060a4:	0037d71b          	srliw	a4,a5,0x3
    802060a8:	9752                	add	a4,a4,s4
    802060aa:	00074683          	lbu	a3,0(a4)
    802060ae:	8b9d                	andi	a5,a5,7
    802060b0:	40f6dc3b          	sraw	s8,a3,a5
    802060b4:	001c7c13          	andi	s8,s8,1
    802060b8:	e20c0be3          	beqz	s8,80205eee <fsck+0xde>
    802060bc:	4c11                	li	s8,4
    802060be:	b789                	j	80206000 <fsck+0x1f0>

00000000802060c0 <consolewrite>:
    devsw[CONSOLE].read  = consoleread;
    devsw[CONSOLE].write = consolewrite;
}

int consolewrite(uint64 src, int n)
{
    802060c0:	7139                	addi	sp,sp,-64
    802060c2:	fc06                	sd	ra,56(sp)
    802060c4:	f822                	sd	s0,48(sp)
    802060c6:	ec4e                	sd	s3,24(sp)
    802060c8:	0080                	addi	s0,sp,64
    802060ca:	89ae                	mv	s3,a1
    for (int i = 0; i < n; i++) {
    802060cc:	04b05563          	blez	a1,80206116 <consolewrite+0x56>
    802060d0:	f426                	sd	s1,40(sp)
    802060d2:	f04a                	sd	s2,32(sp)
    802060d4:	84aa                	mv	s1,a0
    802060d6:	00a58933          	add	s2,a1,a0
        char c;
        /* copyin, not a direct dereference - src is a USER pointer. */
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    802060da:	ffffc097          	auipc	ra,0xffffc
    802060de:	816080e7          	jalr	-2026(ra) # 802018f0 <myproc>
    802060e2:	4685                	li	a3,1
    802060e4:	8626                	mv	a2,s1
    802060e6:	fcf40593          	addi	a1,s0,-49
    802060ea:	6928                	ld	a0,80(a0)
    802060ec:	ffffd097          	auipc	ra,0xffffd
    802060f0:	494080e7          	jalr	1172(ra) # 80203580 <copyin>
    802060f4:	00054e63          	bltz	a0,80206110 <consolewrite+0x50>
        hal_console_putc(c);
    802060f8:	fcf44503          	lbu	a0,-49(s0)
    802060fc:	00002097          	auipc	ra,0x2
    80206100:	13c080e7          	jalr	316(ra) # 80208238 <hal_console_putc>
    for (int i = 0; i < n; i++) {
    80206104:	0485                	addi	s1,s1,1
    80206106:	fd249ae3          	bne	s1,s2,802060da <consolewrite+0x1a>
    8020610a:	74a2                	ld	s1,40(sp)
    8020610c:	7902                	ld	s2,32(sp)
    8020610e:	a021                	j	80206116 <consolewrite+0x56>
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    80206110:	59fd                	li	s3,-1
    80206112:	74a2                	ld	s1,40(sp)
    80206114:	7902                	ld	s2,32(sp)
    }
    return n;
}
    80206116:	854e                	mv	a0,s3
    80206118:	70e2                	ld	ra,56(sp)
    8020611a:	7442                	ld	s0,48(sp)
    8020611c:	69e2                	ld	s3,24(sp)
    8020611e:	6121                	addi	sp,sp,64
    80206120:	8082                	ret

0000000080206122 <consoleread>:

int consoleread(uint64 dst, int n)
{
    80206122:	715d                	addi	sp,sp,-80
    80206124:	e486                	sd	ra,72(sp)
    80206126:	e0a2                	sd	s0,64(sp)
    80206128:	fc26                	sd	s1,56(sp)
    8020612a:	f84a                	sd	s2,48(sp)
    8020612c:	f44e                	sd	s3,40(sp)
    8020612e:	f052                	sd	s4,32(sp)
    80206130:	ec56                	sd	s5,24(sp)
    80206132:	0880                	addi	s0,sp,80
    80206134:	8a2a                	mv	s4,a0
    80206136:	89ae                	mv	s3,a1
    int target = n;
    acquire(&cons.lock);
    80206138:	00145517          	auipc	a0,0x145
    8020613c:	3c850513          	addi	a0,a0,968 # 8034b500 <cons>
    80206140:	ffffb097          	auipc	ra,0xffffb
    80206144:	348080e7          	jalr	840(ra) # 80201488 <acquire>
    while (n > 0) {
    80206148:	8ace                	mv	s5,s3
        while (cons.r == cons.w) {
    8020614a:	00145497          	auipc	s1,0x145
    8020614e:	3b648493          	addi	s1,s1,950 # 8034b500 <cons>
            if (myproc()->killed) { release(&cons.lock); return -1; }
            sleep(&cons.r, &cons.lock);
    80206152:	00145917          	auipc	s2,0x145
    80206156:	44690913          	addi	s2,s2,1094 # 8034b598 <cons+0x98>
    while (n > 0) {
    8020615a:	09305463          	blez	s3,802061e2 <consoleread+0xc0>
        while (cons.r == cons.w) {
    8020615e:	0984a783          	lw	a5,152(s1)
    80206162:	09c4a703          	lw	a4,156(s1)
    80206166:	02f71463          	bne	a4,a5,8020618e <consoleread+0x6c>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    8020616a:	ffffb097          	auipc	ra,0xffffb
    8020616e:	786080e7          	jalr	1926(ra) # 802018f0 <myproc>
    80206172:	551c                	lw	a5,40(a0)
    80206174:	e3d1                	bnez	a5,802061f8 <consoleread+0xd6>
            sleep(&cons.r, &cons.lock);
    80206176:	85a6                	mv	a1,s1
    80206178:	854a                	mv	a0,s2
    8020617a:	ffffc097          	auipc	ra,0xffffc
    8020617e:	f6c080e7          	jalr	-148(ra) # 802020e6 <sleep>
        while (cons.r == cons.w) {
    80206182:	0984a783          	lw	a5,152(s1)
    80206186:	09c4a703          	lw	a4,156(s1)
    8020618a:	fef700e3          	beq	a4,a5,8020616a <consoleread+0x48>
        }
        char c = cons.buf[cons.r++ % INBUF];
    8020618e:	00145717          	auipc	a4,0x145
    80206192:	37270713          	addi	a4,a4,882 # 8034b500 <cons>
    80206196:	0017869b          	addiw	a3,a5,1
    8020619a:	08d72c23          	sw	a3,152(a4)
    8020619e:	07f7f793          	andi	a5,a5,127
    802061a2:	973e                	add	a4,a4,a5
    802061a4:	01874783          	lbu	a5,24(a4)
    802061a8:	faf40fa3          	sb	a5,-65(s0)
        if (c == 4) break;                       /* Ctrl-D */
    802061ac:	4711                	li	a4,4
    802061ae:	02e78a63          	beq	a5,a4,802061e2 <consoleread+0xc0>
        if (copyout(myproc()->pagetable, dst, &c, 1) < 0) break;
    802061b2:	ffffb097          	auipc	ra,0xffffb
    802061b6:	73e080e7          	jalr	1854(ra) # 802018f0 <myproc>
    802061ba:	4685                	li	a3,1
    802061bc:	fbf40613          	addi	a2,s0,-65
    802061c0:	85d2                	mv	a1,s4
    802061c2:	6928                	ld	a0,80(a0)
    802061c4:	ffffd097          	auipc	ra,0xffffd
    802061c8:	296080e7          	jalr	662(ra) # 8020345a <copyout>
    802061cc:	00054b63          	bltz	a0,802061e2 <consoleread+0xc0>
        dst++; n--;
    802061d0:	0a05                	addi	s4,s4,1
    802061d2:	3afd                	addiw	s5,s5,-1
        if (c == '\n') break;
    802061d4:	fbf44703          	lbu	a4,-65(s0)
    802061d8:	47a9                	li	a5,10
    802061da:	00f70463          	beq	a4,a5,802061e2 <consoleread+0xc0>
    while (n > 0) {
    802061de:	f80a90e3          	bnez	s5,8020615e <consoleread+0x3c>
    }
    release(&cons.lock);
    802061e2:	00145517          	auipc	a0,0x145
    802061e6:	31e50513          	addi	a0,a0,798 # 8034b500 <cons>
    802061ea:	ffffb097          	auipc	ra,0xffffb
    802061ee:	352080e7          	jalr	850(ra) # 8020153c <release>
    return target - n;
    802061f2:	4159853b          	subw	a0,s3,s5
    802061f6:	a811                	j	8020620a <consoleread+0xe8>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    802061f8:	00145517          	auipc	a0,0x145
    802061fc:	30850513          	addi	a0,a0,776 # 8034b500 <cons>
    80206200:	ffffb097          	auipc	ra,0xffffb
    80206204:	33c080e7          	jalr	828(ra) # 8020153c <release>
    80206208:	557d                	li	a0,-1
}
    8020620a:	60a6                	ld	ra,72(sp)
    8020620c:	6406                	ld	s0,64(sp)
    8020620e:	74e2                	ld	s1,56(sp)
    80206210:	7942                	ld	s2,48(sp)
    80206212:	79a2                	ld	s3,40(sp)
    80206214:	7a02                	ld	s4,32(sp)
    80206216:	6ae2                	ld	s5,24(sp)
    80206218:	6161                	addi	sp,sp,80
    8020621a:	8082                	ret

000000008020621c <consoleinit>:
{
    8020621c:	1141                	addi	sp,sp,-16
    8020621e:	e406                	sd	ra,8(sp)
    80206220:	e022                	sd	s0,0(sp)
    80206222:	0800                	addi	s0,sp,16
    initlock(&cons.lock, "cons");
    80206224:	00004597          	auipc	a1,0x4
    80206228:	93c58593          	addi	a1,a1,-1732 # 80209b60 <etext+0xb60>
    8020622c:	00145517          	auipc	a0,0x145
    80206230:	2d450513          	addi	a0,a0,724 # 8034b500 <cons>
    80206234:	ffffb097          	auipc	ra,0xffffb
    80206238:	1d8080e7          	jalr	472(ra) # 8020140c <initlock>
    devsw[CONSOLE].read  = consoleread;
    8020623c:	0014f797          	auipc	a5,0x14f
    80206240:	50478793          	addi	a5,a5,1284 # 80355740 <devsw>
    80206244:	00000717          	auipc	a4,0x0
    80206248:	ede70713          	addi	a4,a4,-290 # 80206122 <consoleread>
    8020624c:	eb98                	sd	a4,16(a5)
    devsw[CONSOLE].write = consolewrite;
    8020624e:	00000717          	auipc	a4,0x0
    80206252:	e7270713          	addi	a4,a4,-398 # 802060c0 <consolewrite>
    80206256:	ef98                	sd	a4,24(a5)
}
    80206258:	60a2                	ld	ra,8(sp)
    8020625a:	6402                	ld	s0,0(sp)
    8020625c:	0141                	addi	sp,sp,16
    8020625e:	8082                	ret

0000000080206260 <consoleintr>:

/* Called from the trap handler when the UART raises an interrupt. */
void consoleintr(int c)
{
    80206260:	1101                	addi	sp,sp,-32
    80206262:	ec06                	sd	ra,24(sp)
    80206264:	e822                	sd	s0,16(sp)
    80206266:	e426                	sd	s1,8(sp)
    80206268:	1000                	addi	s0,sp,32
    8020626a:	84aa                	mv	s1,a0
    acquire(&cons.lock);
    8020626c:	00145517          	auipc	a0,0x145
    80206270:	29450513          	addi	a0,a0,660 # 8034b500 <cons>
    80206274:	ffffb097          	auipc	ra,0xffffb
    80206278:	214080e7          	jalr	532(ra) # 80201488 <acquire>
    switch (c) {
    8020627c:	47c1                	li	a5,16
    8020627e:	08f48463          	beq	s1,a5,80206306 <consoleintr+0xa6>
    80206282:	07f00793          	li	a5,127
    80206286:	0af48163          	beq	s1,a5,80206328 <consoleintr+0xc8>
    8020628a:	47a1                	li	a5,8
    8020628c:	08f48e63          	beq	s1,a5,80206328 <consoleintr+0xc8>
            cons.e--;
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
        }
        break;
    default:
        if (c != 0 && cons.e - cons.r < INBUF) {
    80206290:	ccbd                	beqz	s1,8020630e <consoleintr+0xae>
    80206292:	00145717          	auipc	a4,0x145
    80206296:	26e70713          	addi	a4,a4,622 # 8034b500 <cons>
    8020629a:	0a072783          	lw	a5,160(a4)
    8020629e:	09872703          	lw	a4,152(a4)
    802062a2:	9f99                	subw	a5,a5,a4
    802062a4:	07f00713          	li	a4,127
    802062a8:	06f76363          	bltu	a4,a5,8020630e <consoleintr+0xae>
            c = (c == '\r') ? '\n' : c;
    802062ac:	47b5                	li	a5,13
    802062ae:	0cf48f63          	beq	s1,a5,8020638c <consoleintr+0x12c>
    802062b2:	e04a                	sd	s2,0(sp)
            hal_console_putc(c);                 /* echo */
    802062b4:	0ff4f913          	zext.b	s2,s1
    802062b8:	854a                	mv	a0,s2
    802062ba:	00002097          	auipc	ra,0x2
    802062be:	f7e080e7          	jalr	-130(ra) # 80208238 <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    802062c2:	00145797          	auipc	a5,0x145
    802062c6:	23e78793          	addi	a5,a5,574 # 8034b500 <cons>
    802062ca:	0a07a703          	lw	a4,160(a5)
    802062ce:	0017069b          	addiw	a3,a4,1
    802062d2:	0006861b          	sext.w	a2,a3
    802062d6:	0ad7a023          	sw	a3,160(a5)
    802062da:	07f77713          	andi	a4,a4,127
    802062de:	97ba                	add	a5,a5,a4
    802062e0:	01278c23          	sb	s2,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    802062e4:	47a9                	li	a5,10
    802062e6:	08f48363          	beq	s1,a5,8020636c <consoleintr+0x10c>
    802062ea:	4791                	li	a5,4
    802062ec:	08f48263          	beq	s1,a5,80206370 <consoleintr+0x110>
    802062f0:	00145797          	auipc	a5,0x145
    802062f4:	2a87a783          	lw	a5,680(a5) # 8034b598 <cons+0x98>
    802062f8:	9e9d                	subw	a3,a3,a5
    802062fa:	08000793          	li	a5,128
    802062fe:	06f68563          	beq	a3,a5,80206368 <consoleintr+0x108>
    80206302:	6902                	ld	s2,0(sp)
    80206304:	a029                	j	8020630e <consoleintr+0xae>
        procdump();
    80206306:	ffffc097          	auipc	ra,0xffffc
    8020630a:	316080e7          	jalr	790(ra) # 8020261c <procdump>
                wakeup(&cons.r);
            }
        }
        break;
    }
    release(&cons.lock);
    8020630e:	00145517          	auipc	a0,0x145
    80206312:	1f250513          	addi	a0,a0,498 # 8034b500 <cons>
    80206316:	ffffb097          	auipc	ra,0xffffb
    8020631a:	226080e7          	jalr	550(ra) # 8020153c <release>
}
    8020631e:	60e2                	ld	ra,24(sp)
    80206320:	6442                	ld	s0,16(sp)
    80206322:	64a2                	ld	s1,8(sp)
    80206324:	6105                	addi	sp,sp,32
    80206326:	8082                	ret
        if (cons.e != cons.w) {
    80206328:	00145717          	auipc	a4,0x145
    8020632c:	1d870713          	addi	a4,a4,472 # 8034b500 <cons>
    80206330:	0a072783          	lw	a5,160(a4)
    80206334:	09c72703          	lw	a4,156(a4)
    80206338:	fcf70be3          	beq	a4,a5,8020630e <consoleintr+0xae>
            cons.e--;
    8020633c:	37fd                	addiw	a5,a5,-1
    8020633e:	00145717          	auipc	a4,0x145
    80206342:	26f72123          	sw	a5,610(a4) # 8034b5a0 <cons+0xa0>
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
    80206346:	4521                	li	a0,8
    80206348:	00002097          	auipc	ra,0x2
    8020634c:	ef0080e7          	jalr	-272(ra) # 80208238 <hal_console_putc>
    80206350:	02000513          	li	a0,32
    80206354:	00002097          	auipc	ra,0x2
    80206358:	ee4080e7          	jalr	-284(ra) # 80208238 <hal_console_putc>
    8020635c:	4521                	li	a0,8
    8020635e:	00002097          	auipc	ra,0x2
    80206362:	eda080e7          	jalr	-294(ra) # 80208238 <hal_console_putc>
    80206366:	b765                	j	8020630e <consoleintr+0xae>
    80206368:	6902                	ld	s2,0(sp)
    8020636a:	a021                	j	80206372 <consoleintr+0x112>
    8020636c:	6902                	ld	s2,0(sp)
    8020636e:	a011                	j	80206372 <consoleintr+0x112>
    80206370:	6902                	ld	s2,0(sp)
                cons.w = cons.e;
    80206372:	00145797          	auipc	a5,0x145
    80206376:	22c7a523          	sw	a2,554(a5) # 8034b59c <cons+0x9c>
                wakeup(&cons.r);
    8020637a:	00145517          	auipc	a0,0x145
    8020637e:	21e50513          	addi	a0,a0,542 # 8034b598 <cons+0x98>
    80206382:	ffffc097          	auipc	ra,0xffffc
    80206386:	eea080e7          	jalr	-278(ra) # 8020226c <wakeup>
    8020638a:	b751                	j	8020630e <consoleintr+0xae>
            hal_console_putc(c);                 /* echo */
    8020638c:	4529                	li	a0,10
    8020638e:	00002097          	auipc	ra,0x2
    80206392:	eaa080e7          	jalr	-342(ra) # 80208238 <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    80206396:	00145797          	auipc	a5,0x145
    8020639a:	16a78793          	addi	a5,a5,362 # 8034b500 <cons>
    8020639e:	0a07a703          	lw	a4,160(a5)
    802063a2:	0017069b          	addiw	a3,a4,1
    802063a6:	0006861b          	sext.w	a2,a3
    802063aa:	0ad7a023          	sw	a3,160(a5)
    802063ae:	07f77713          	andi	a4,a4,127
    802063b2:	97ba                	add	a5,a5,a4
    802063b4:	4729                	li	a4,10
    802063b6:	00e78c23          	sb	a4,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    802063ba:	bf65                	j	80206372 <consoleintr+0x112>

00000000802063bc <exec>:
    }
    return 0;
}

int exec(char *path, char **argv)
{
    802063bc:	7125                	addi	sp,sp,-416
    802063be:	ef06                	sd	ra,408(sp)
    802063c0:	eb22                	sd	s0,400(sp)
    802063c2:	e726                	sd	s1,392(sp)
    802063c4:	1300                	addi	s0,sp,416
    802063c6:	e8a43023          	sd	a0,-384(s0)
    802063ca:	e6b43c23          	sd	a1,-392(s0)
    struct inode *ip = namei(path);
    802063ce:	00001097          	auipc	ra,0x1
    802063d2:	554080e7          	jalr	1364(ra) # 80207922 <namei>
    if (ip == 0) return -1;
    802063d6:	3e050163          	beqz	a0,802067b8 <exec+0x3fc>
    802063da:	f2da                	sd	s6,352(sp)
    802063dc:	8b2a                	mv	s6,a0
    ilock(ip);
    802063de:	00001097          	auipc	ra,0x1
    802063e2:	cb0080e7          	jalr	-848(ra) # 8020708e <ilock>

    struct elfhdr eh;
    pagetable_t newpt = 0;
    uint64 sz = 0;

    if (readi(ip, 0, (uint64)&eh, 0, sizeof(eh)) != sizeof(eh)) goto bad;
    802063e6:	04000713          	li	a4,64
    802063ea:	4681                	li	a3,0
    802063ec:	f5040613          	addi	a2,s0,-176
    802063f0:	4581                	li	a1,0
    802063f2:	855a                	mv	a0,s6
    802063f4:	00001097          	auipc	ra,0x1
    802063f8:	fc8080e7          	jalr	-56(ra) # 802073bc <readi>
    802063fc:	04000793          	li	a5,64
    80206400:	02f51263          	bne	a0,a5,80206424 <exec+0x68>
    if (eh.magic != ELF_MAGIC) goto bad;              /* reject, do not run */
    80206404:	f5042703          	lw	a4,-176(s0)
    80206408:	464c47b7          	lui	a5,0x464c4
    8020640c:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39d3ba81>
    80206410:	00f71a63          	bne	a4,a5,80206424 <exec+0x68>
    if (eh.phnum == 0 || eh.phnum > 16) goto bad;
    80206414:	f8845783          	lhu	a5,-120(s0)
    80206418:	37fd                	addiw	a5,a5,-1
    8020641a:	17c2                	slli	a5,a5,0x30
    8020641c:	93c1                	srli	a5,a5,0x30
    8020641e:	473d                	li	a4,15
    80206420:	00f77f63          	bgeu	a4,a5,8020643e <exec+0x82>
    uvmfree(oldpt, oldsz);
    return argc;

bad:
    if (newpt) uvmfree(newpt, sz);
    if (ip) iunlockput(ip);
    80206424:	855a                	mv	a0,s6
    80206426:	00001097          	auipc	ra,0x1
    8020642a:	f44080e7          	jalr	-188(ra) # 8020736a <iunlockput>
    return -1;
    8020642e:	54fd                	li	s1,-1
    80206430:	7b16                	ld	s6,352(sp)
}
    80206432:	8526                	mv	a0,s1
    80206434:	60fa                	ld	ra,408(sp)
    80206436:	645a                	ld	s0,400(sp)
    80206438:	64ba                	ld	s1,392(sp)
    8020643a:	611d                	addi	sp,sp,416
    8020643c:	8082                	ret
    8020643e:	eae2                	sd	s8,336(sp)
    if ((newpt = uvmcreate()) == 0) goto bad;
    80206440:	ffffd097          	auipc	ra,0xffffd
    80206444:	d86080e7          	jalr	-634(ra) # 802031c6 <uvmcreate>
    80206448:	8c2a                	mv	s8,a0
    8020644a:	36050563          	beqz	a0,802067b4 <exec+0x3f8>
    8020644e:	e34a                	sd	s2,384(sp)
    80206450:	fece                	sd	s3,376(sp)
    80206452:	fad2                	sd	s4,368(sp)
    80206454:	f6d6                	sd	s5,360(sp)
    80206456:	eede                	sd	s7,344(sp)
    80206458:	e6e6                	sd	s9,328(sp)
    8020645a:	e2ea                	sd	s10,320(sp)
    8020645c:	fe6e                	sd	s11,312(sp)
    for (int i = 0; i < eh.phnum; i++) {
    8020645e:	f8845783          	lhu	a5,-120(s0)
    80206462:	16078563          	beqz	a5,802065cc <exec+0x210>
    80206466:	4c81                	li	s9,0
    80206468:	4d01                	li	s10,0
    uint64 sz = 0;
    8020646a:	e8043423          	sd	zero,-376(s0)
        if (ph.type != ELF_PROG_LOAD) continue;
    8020646e:	4d85                	li	s11,1
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    80206470:	800007b7          	lui	a5,0x80000
    80206474:	fff7c793          	not	a5,a5
    80206478:	e6f43823          	sd	a5,-400(s0)
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    8020647c:	6a05                	lui	s4,0x1
    8020647e:	fffa0793          	addi	a5,s4,-1 # fff <_entry-0x801ff001>
    80206482:	e6f43423          	sd	a5,-408(s0)
    80206486:	a0d1                	j	8020654a <exec+0x18e>
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    80206488:	00c4f563          	bgeu	s1,a2,80206492 <exec+0xd6>
    8020648c:	8e05                	sub	a2,a2,s1
    8020648e:	4781                	li	a5,0
    80206490:	a09d                	j	802064f6 <exec+0x13a>
    80206492:	4781                	li	a5,0
    80206494:	4601                	li	a2,0
    80206496:	a085                	j	802064f6 <exec+0x13a>
            if (readi(ip, 0, (uint64)(mem + dst_off),
    80206498:	2981                	sext.w	s3,s3
    8020649a:	874e                	mv	a4,s3
    8020649c:	e9843683          	ld	a3,-360(s0)
    802064a0:	9ebd                	addw	a3,a3,a5
    802064a2:	964a                	add	a2,a2,s2
    802064a4:	4581                	li	a1,0
    802064a6:	855a                	mv	a0,s6
    802064a8:	00001097          	auipc	ra,0x1
    802064ac:	f14080e7          	jalr	-236(ra) # 802073bc <readi>
    802064b0:	05351f63          	bne	a0,s3,8020650e <exec+0x152>
        if (mappages(pt, va, PGSIZE, (uint64)mem, perm) != 0) {
    802064b4:	875e                	mv	a4,s7
    802064b6:	86ca                	mv	a3,s2
    802064b8:	8652                	mv	a2,s4
    802064ba:	85a6                	mv	a1,s1
    802064bc:	8562                	mv	a0,s8
    802064be:	ffffd097          	auipc	ra,0xffffd
    802064c2:	af6080e7          	jalr	-1290(ra) # 80202fb4 <mappages>
    802064c6:	e931                	bnez	a0,8020651a <exec+0x15e>
    for (uint64 va = start; va < end; va += PGSIZE) {
    802064c8:	94d2                	add	s1,s1,s4
    802064ca:	0554fe63          	bgeu	s1,s5,80206526 <exec+0x16a>
        char *mem = palloc();
    802064ce:	ffffb097          	auipc	ra,0xffffb
    802064d2:	c18080e7          	jalr	-1000(ra) # 802010e6 <palloc>
    802064d6:	892a                	mv	s2,a0
        if (!mem) return -1;
    802064d8:	1c050063          	beqz	a0,80206698 <exec+0x2dc>
        memset(mem, 0, PGSIZE);                    /* zero first: this IS the .bss */
    802064dc:	8652                	mv	a2,s4
    802064de:	4581                	li	a1,0
    802064e0:	ffffa097          	auipc	ra,0xffffa
    802064e4:	1dc080e7          	jalr	476(ra) # 802006bc <memset>
        uint64 seg_off = (va > ph->vaddr) ? (va - ph->vaddr) : 0;
    802064e8:	ea043603          	ld	a2,-352(s0)
    802064ec:	f8967ee3          	bgeu	a2,s1,80206488 <exec+0xcc>
    802064f0:	40c487b3          	sub	a5,s1,a2
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    802064f4:	4601                	li	a2,0
        if (seg_off < ph->filesz) {
    802064f6:	eb043983          	ld	s3,-336(s0)
    802064fa:	fb37fde3          	bgeu	a5,s3,802064b4 <exec+0xf8>
            if (n > PGSIZE - dst_off) n = PGSIZE - dst_off;
    802064fe:	40ca0733          	sub	a4,s4,a2
    80206502:	40f989b3          	sub	s3,s3,a5
    80206506:	f93779e3          	bgeu	a4,s3,80206498 <exec+0xdc>
    8020650a:	89ba                	mv	s3,a4
    8020650c:	b771                	j	80206498 <exec+0xdc>
                pfree(mem);
    8020650e:	854a                	mv	a0,s2
    80206510:	ffffb097          	auipc	ra,0xffffb
    80206514:	d14080e7          	jalr	-748(ra) # 80201224 <pfree>
                return -1;
    80206518:	a241                	j	80206698 <exec+0x2dc>
            pfree(mem);
    8020651a:	854a                	mv	a0,s2
    8020651c:	ffffb097          	auipc	ra,0xffffb
    80206520:	d08080e7          	jalr	-760(ra) # 80201224 <pfree>
            return -1;
    80206524:	aa95                	j	80206698 <exec+0x2dc>
        if (ph.vaddr + ph.memsz > sz) sz = ph.vaddr + ph.memsz;
    80206526:	ea043783          	ld	a5,-352(s0)
    8020652a:	eb843703          	ld	a4,-328(s0)
    8020652e:	97ba                	add	a5,a5,a4
    80206530:	e8843703          	ld	a4,-376(s0)
    80206534:	00f77463          	bgeu	a4,a5,8020653c <exec+0x180>
    80206538:	e8f43423          	sd	a5,-376(s0)
    for (int i = 0; i < eh.phnum; i++) {
    8020653c:	2d05                	addiw	s10,s10,1
    8020653e:	038c8c9b          	addiw	s9,s9,56
    80206542:	f8845783          	lhu	a5,-120(s0)
    80206546:	08fd5563          	bge	s10,a5,802065d0 <exec+0x214>
        if (readi(ip, 0, (uint64)&ph, eh.phoff + i * sizeof(ph),
    8020654a:	03800713          	li	a4,56
    8020654e:	f7043683          	ld	a3,-144(s0)
    80206552:	019686bb          	addw	a3,a3,s9
    80206556:	e9040613          	addi	a2,s0,-368
    8020655a:	4581                	li	a1,0
    8020655c:	855a                	mv	a0,s6
    8020655e:	00001097          	auipc	ra,0x1
    80206562:	e5e080e7          	jalr	-418(ra) # 802073bc <readi>
    80206566:	03800793          	li	a5,56
    8020656a:	12f51763          	bne	a0,a5,80206698 <exec+0x2dc>
        if (ph.type != ELF_PROG_LOAD) continue;
    8020656e:	e9042783          	lw	a5,-368(s0)
    80206572:	fdb795e3          	bne	a5,s11,8020653c <exec+0x180>
        if (ph.memsz < ph.filesz) goto bad;           /* malformed */
    80206576:	eb843a83          	ld	s5,-328(s0)
    8020657a:	eb043783          	ld	a5,-336(s0)
    8020657e:	10faed63          	bltu	s5,a5,80206698 <exec+0x2dc>
        if (ph.vaddr + ph.memsz < ph.vaddr) goto bad; /* overflow  */
    80206582:	ea043483          	ld	s1,-352(s0)
    80206586:	9aa6                	add	s5,s5,s1
    80206588:	109ae863          	bltu	s5,s1,80206698 <exec+0x2dc>
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    8020658c:	e7043783          	ld	a5,-400(s0)
    80206590:	1157e463          	bltu	a5,s5,80206698 <exec+0x2dc>
    if (ph->flags & ELF_PROG_FLAG_READ)  perm |= PTE_R;
    80206594:	e9442783          	lw	a5,-364(s0)
    80206598:	0047f713          	andi	a4,a5,4
    8020659c:	4bc9                	li	s7,18
    8020659e:	e311                	bnez	a4,802065a2 <exec+0x1e6>
    int perm = PTE_U;
    802065a0:	4bc1                	li	s7,16
    if (ph->flags & ELF_PROG_FLAG_WRITE) perm |= PTE_W;
    802065a2:	0027f713          	andi	a4,a5,2
    802065a6:	c319                	beqz	a4,802065ac <exec+0x1f0>
    802065a8:	004beb93          	ori	s7,s7,4
    if (ph->flags & ELF_PROG_FLAG_EXEC)  perm |= PTE_X;
    802065ac:	8b85                	andi	a5,a5,1
    802065ae:	0037979b          	slliw	a5,a5,0x3
    802065b2:	00fbebb3          	or	s7,s7,a5
    802065b6:	2b81                	sext.w	s7,s7
    uint64 start = PGROUNDDOWN(ph->vaddr);
    802065b8:	77fd                	lui	a5,0xfffff
    802065ba:	8cfd                	and	s1,s1,a5
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    802065bc:	e6843703          	ld	a4,-408(s0)
    802065c0:	9aba                	add	s5,s5,a4
    802065c2:	00fafab3          	and	s5,s5,a5
    for (uint64 va = start; va < end; va += PGSIZE) {
    802065c6:	f154e4e3          	bltu	s1,s5,802064ce <exec+0x112>
    802065ca:	bfb1                	j	80206526 <exec+0x16a>
    uint64 sz = 0;
    802065cc:	e8043423          	sd	zero,-376(s0)
    iunlockput(ip);
    802065d0:	855a                	mv	a0,s6
    802065d2:	00001097          	auipc	ra,0x1
    802065d6:	d98080e7          	jalr	-616(ra) # 8020736a <iunlockput>
    sz = PGROUNDUP(sz);
    802065da:	6785                	lui	a5,0x1
    802065dc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    802065de:	e8843703          	ld	a4,-376(s0)
    802065e2:	97ba                	add	a5,a5,a4
    802065e4:	7dfd                	lui	s11,0xfffff
    802065e6:	01b7f4b3          	and	s1,a5,s11
    802065ea:	e8943423          	sd	s1,-376(s0)
    char *stack = palloc();
    802065ee:	ffffb097          	auipc	ra,0xffffb
    802065f2:	af8080e7          	jalr	-1288(ra) # 802010e6 <palloc>
    802065f6:	8b2a                	mv	s6,a0
    if (!stack) goto bad;
    802065f8:	c145                	beqz	a0,80206698 <exec+0x2dc>
    uint64 stackbase = guard + PGSIZE;
    802065fa:	6a85                	lui	s5,0x1
    802065fc:	9aa6                	add	s5,s5,s1
    memset(stack, 0, PGSIZE);
    802065fe:	6605                	lui	a2,0x1
    80206600:	4581                	li	a1,0
    80206602:	ffffa097          	auipc	ra,0xffffa
    80206606:	0ba080e7          	jalr	186(ra) # 802006bc <memset>
    if (mappages(newpt, stackbase, PGSIZE, (uint64)stack,
    8020660a:	4759                	li	a4,22
    8020660c:	86da                	mv	a3,s6
    8020660e:	6605                	lui	a2,0x1
    80206610:	85d6                	mv	a1,s5
    80206612:	8562                	mv	a0,s8
    80206614:	ffffd097          	auipc	ra,0xffffd
    80206618:	9a0080e7          	jalr	-1632(ra) # 80202fb4 <mappages>
    8020661c:	84aa                	mv	s1,a0
    8020661e:	e505                	bnez	a0,80206646 <exec+0x28a>
    uint64 sp    = stackbase + PGSIZE;
    80206620:	6789                	lui	a5,0x2
    80206622:	e8843703          	ld	a4,-376(s0)
    80206626:	00f70d33          	add	s10,a4,a5
    struct proc *pp = myproc();
    8020662a:	ffffb097          	auipc	ra,0xffffb
    8020662e:	2c6080e7          	jalr	710(ra) # 802018f0 <myproc>
    80206632:	8baa                	mv	s7,a0
    for (; argv && argv[argc]; argc++) {
    80206634:	e7843783          	ld	a5,-392(s0)
    80206638:	c7c9                	beqz	a5,802066c2 <exec+0x306>
    8020663a:	893e                	mv	s2,a5
    8020663c:	ec840a13          	addi	s4,s0,-312
    uint64 sp    = stackbase + PGSIZE;
    80206640:	89ea                	mv	s3,s10
        if (argc >= MAXARG) goto bad;
    80206642:	4cc1                	li	s9,16
    80206644:	a821                	j	8020665c <exec+0x2a0>
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    80206646:	855a                	mv	a0,s6
    80206648:	ffffb097          	auipc	ra,0xffffb
    8020664c:	bdc080e7          	jalr	-1060(ra) # 80201224 <pfree>
    ip = 0;
    80206650:	4b01                	li	s6,0
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    80206652:	a099                	j	80206698 <exec+0x2dc>
        ustack[argc] = sp;
    80206654:	013a3023          	sd	s3,0(s4)
    for (; argv && argv[argc]; argc++) {
    80206658:	2485                	addiw	s1,s1,1
    8020665a:	0a21                	addi	s4,s4,8
    8020665c:	8b4a                	mv	s6,s2
    8020665e:	00093503          	ld	a0,0(s2)
    80206662:	c12d                	beqz	a0,802066c4 <exec+0x308>
        if (argc >= MAXARG) goto bad;
    80206664:	03948963          	beq	s1,s9,80206696 <exec+0x2da>
        uint64 len = strlen(argv[argc]) + 1;
    80206668:	ffffa097          	auipc	ra,0xffffa
    8020666c:	152080e7          	jalr	338(ra) # 802007ba <strlen>
    80206670:	0015069b          	addiw	a3,a0,1
        sp -= len;
    80206674:	40d989b3          	sub	s3,s3,a3
        sp &= ~7UL;                                   /* keep it 8-aligned */
    80206678:	ff89f993          	andi	s3,s3,-8
        if (sp < stackbase) goto bad;
    8020667c:	0159ed63          	bltu	s3,s5,80206696 <exec+0x2da>
        if (copyout(newpt, sp, argv[argc], len) < 0) goto bad;
    80206680:	000b3603          	ld	a2,0(s6)
    80206684:	85ce                	mv	a1,s3
    80206686:	8562                	mv	a0,s8
    80206688:	ffffd097          	auipc	ra,0xffffd
    8020668c:	dd2080e7          	jalr	-558(ra) # 8020345a <copyout>
    80206690:	0921                	addi	s2,s2,8
    80206692:	fc0551e3          	bgez	a0,80206654 <exec+0x298>
    if (newpt) uvmfree(newpt, sz);
    80206696:	4b01                	li	s6,0
    80206698:	e8843583          	ld	a1,-376(s0)
    8020669c:	8562                	mv	a0,s8
    8020669e:	ffffd097          	auipc	ra,0xffffd
    802066a2:	be8080e7          	jalr	-1048(ra) # 80203286 <uvmfree>
    return -1;
    802066a6:	54fd                	li	s1,-1
    if (ip) iunlockput(ip);
    802066a8:	0e0b1c63          	bnez	s6,802067a0 <exec+0x3e4>
    802066ac:	691a                	ld	s2,384(sp)
    802066ae:	79f6                	ld	s3,376(sp)
    802066b0:	7a56                	ld	s4,368(sp)
    802066b2:	7ab6                	ld	s5,360(sp)
    802066b4:	7b16                	ld	s6,352(sp)
    802066b6:	6bf6                	ld	s7,344(sp)
    802066b8:	6c56                	ld	s8,336(sp)
    802066ba:	6cb6                	ld	s9,328(sp)
    802066bc:	6d16                	ld	s10,320(sp)
    802066be:	7df2                	ld	s11,312(sp)
    802066c0:	bb8d                	j	80206432 <exec+0x76>
    uint64 sp    = stackbase + PGSIZE;
    802066c2:	89ea                	mv	s3,s10
    ustack[argc] = 0;
    802066c4:	00349793          	slli	a5,s1,0x3
    802066c8:	f9078793          	addi	a5,a5,-112 # 1f90 <_entry-0x801fe070>
    802066cc:	97a2                	add	a5,a5,s0
    802066ce:	f207bc23          	sd	zero,-200(a5)
    sp -= (argc + 1) * sizeof(uint64);
    802066d2:	0014869b          	addiw	a3,s1,1
    802066d6:	068e                	slli	a3,a3,0x3
    802066d8:	40d98933          	sub	s2,s3,a3
    sp &= ~15UL;                                      /* 16-byte ABI alignment */
    802066dc:	ff097913          	andi	s2,s2,-16
    ip = 0;
    802066e0:	4b01                	li	s6,0
    if (sp < stackbase) goto bad;
    802066e2:	fb596be3          	bltu	s2,s5,80206698 <exec+0x2dc>
    if (copyout(newpt, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) < 0) goto bad;
    802066e6:	ec840613          	addi	a2,s0,-312
    802066ea:	85ca                	mv	a1,s2
    802066ec:	8562                	mv	a0,s8
    802066ee:	ffffd097          	auipc	ra,0xffffd
    802066f2:	d6c080e7          	jalr	-660(ra) # 8020345a <copyout>
    802066f6:	0c054363          	bltz	a0,802067bc <exec+0x400>
    pagetable_t oldpt = pp->pagetable;
    802066fa:	050bb983          	ld	s3,80(s7) # 1050 <_entry-0x801fefb0>
    uint64      oldsz = pp->sz;
    802066fe:	048bba03          	ld	s4,72(s7)
    if (usysinfo_remap(pp, newpt) < 0) goto bad;   /* Lab 3 */
    80206702:	85e2                	mv	a1,s8
    80206704:	855e                	mv	a0,s7
    80206706:	fffff097          	auipc	ra,0xfffff
    8020670a:	a52080e7          	jalr	-1454(ra) # 80205158 <usysinfo_remap>
    8020670e:	0a054963          	bltz	a0,802067c0 <exec+0x404>
    pp->pagetable = newpt;
    80206712:	058bb823          	sd	s8,80(s7)
    pp->sz        = newsz;
    80206716:	05abb423          	sd	s10,72(s7)
    pp->tf->epc   = eh.entry;
    8020671a:	058bb783          	ld	a5,88(s7)
    8020671e:	f6843703          	ld	a4,-152(s0)
    80206722:	ef98                	sd	a4,24(a5)
    pp->tf->sp    = sp;
    80206724:	058bb783          	ld	a5,88(s7)
    80206728:	0327b823          	sd	s2,48(a5)
    pp->tf->a1    = sp;                               /* argv for main() */
    8020672c:	058bb783          	ld	a5,88(s7)
    80206730:	0727bc23          	sd	s2,120(a5)
    for (const char *s = path; *s; s++) if (*s == '/') last = s + 1;
    80206734:	e8043783          	ld	a5,-384(s0)
    80206738:	0007c703          	lbu	a4,0(a5)
    8020673c:	cf11                	beqz	a4,80206758 <exec+0x39c>
    8020673e:	0785                	addi	a5,a5,1
    80206740:	02f00693          	li	a3,47
    80206744:	a029                	j	8020674e <exec+0x392>
    80206746:	0785                	addi	a5,a5,1
    80206748:	fff7c703          	lbu	a4,-1(a5)
    8020674c:	c711                	beqz	a4,80206758 <exec+0x39c>
    8020674e:	fed71ce3          	bne	a4,a3,80206746 <exec+0x38a>
    80206752:	e8f43023          	sd	a5,-384(s0)
    80206756:	bfc5                	j	80206746 <exec+0x38a>
    strncpy(pp->name, last, sizeof(pp->name));
    80206758:	4641                	li	a2,16
    8020675a:	e8043583          	ld	a1,-384(s0)
    8020675e:	158b8513          	addi	a0,s7,344
    80206762:	ffffa097          	auipc	ra,0xffffa
    80206766:	01c080e7          	jalr	28(ra) # 8020077e <strncpy>
    w_satp(MAKE_SATP(pp->pagetable));                 /* we are running on it now */
    8020676a:	050bb783          	ld	a5,80(s7)
    8020676e:	83b1                	srli	a5,a5,0xc
    80206770:	577d                	li	a4,-1
    80206772:	177e                	slli	a4,a4,0x3f
    80206774:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80206776:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    8020677a:	12000073          	sfence.vma
    uvmfree(oldpt, oldsz);
    8020677e:	85d2                	mv	a1,s4
    80206780:	854e                	mv	a0,s3
    80206782:	ffffd097          	auipc	ra,0xffffd
    80206786:	b04080e7          	jalr	-1276(ra) # 80203286 <uvmfree>
    return argc;
    8020678a:	691a                	ld	s2,384(sp)
    8020678c:	79f6                	ld	s3,376(sp)
    8020678e:	7a56                	ld	s4,368(sp)
    80206790:	7ab6                	ld	s5,360(sp)
    80206792:	7b16                	ld	s6,352(sp)
    80206794:	6bf6                	ld	s7,344(sp)
    80206796:	6c56                	ld	s8,336(sp)
    80206798:	6cb6                	ld	s9,328(sp)
    8020679a:	6d16                	ld	s10,320(sp)
    8020679c:	7df2                	ld	s11,312(sp)
    8020679e:	b951                	j	80206432 <exec+0x76>
    802067a0:	691a                	ld	s2,384(sp)
    802067a2:	79f6                	ld	s3,376(sp)
    802067a4:	7a56                	ld	s4,368(sp)
    802067a6:	7ab6                	ld	s5,360(sp)
    802067a8:	6bf6                	ld	s7,344(sp)
    802067aa:	6c56                	ld	s8,336(sp)
    802067ac:	6cb6                	ld	s9,328(sp)
    802067ae:	6d16                	ld	s10,320(sp)
    802067b0:	7df2                	ld	s11,312(sp)
    802067b2:	b98d                	j	80206424 <exec+0x68>
    802067b4:	6c56                	ld	s8,336(sp)
    802067b6:	b1bd                	j	80206424 <exec+0x68>
    if (ip == 0) return -1;
    802067b8:	54fd                	li	s1,-1
    802067ba:	b9a5                	j	80206432 <exec+0x76>
    ip = 0;
    802067bc:	4b01                	li	s6,0
    802067be:	bde9                	j	80206698 <exec+0x2dc>
    802067c0:	4b01                	li	s6,0
    if (newpt) uvmfree(newpt, sz);
    802067c2:	bdd9                	j	80206698 <exec+0x2dc>

00000000802067c4 <binit>:
    struct buf buf[NBUF];
    struct buf head;          /* LRU list: head.next = most recent */
} bcache;

void binit(void)
{
    802067c4:	7179                	addi	sp,sp,-48
    802067c6:	f406                	sd	ra,40(sp)
    802067c8:	f022                	sd	s0,32(sp)
    802067ca:	ec26                	sd	s1,24(sp)
    802067cc:	e84a                	sd	s2,16(sp)
    802067ce:	e44e                	sd	s3,8(sp)
    802067d0:	e052                	sd	s4,0(sp)
    802067d2:	1800                	addi	s0,sp,48
    initlock(&bcache.lock, "bcache");
    802067d4:	00003597          	auipc	a1,0x3
    802067d8:	39458593          	addi	a1,a1,916 # 80209b68 <etext+0xb68>
    802067dc:	00145517          	auipc	a0,0x145
    802067e0:	dcc50513          	addi	a0,a0,-564 # 8034b5a8 <bcache>
    802067e4:	ffffb097          	auipc	ra,0xffffb
    802067e8:	c28080e7          	jalr	-984(ra) # 8020140c <initlock>
    bcache.head.prev = &bcache.head;
    802067ec:	0014d797          	auipc	a5,0x14d
    802067f0:	dbc78793          	addi	a5,a5,-580 # 803535a8 <bcache+0x8000>
    802067f4:	0014d717          	auipc	a4,0x14d
    802067f8:	01c70713          	addi	a4,a4,28 # 80353810 <bcache+0x8268>
    802067fc:	2ae7b823          	sd	a4,688(a5)
    bcache.head.next = &bcache.head;
    80206800:	2ae7bc23          	sd	a4,696(a5)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80206804:	00145497          	auipc	s1,0x145
    80206808:	dbc48493          	addi	s1,s1,-580 # 8034b5c0 <bcache+0x18>
        b->next = bcache.head.next;
    8020680c:	893e                	mv	s2,a5
        b->prev = &bcache.head;
    8020680e:	89ba                	mv	s3,a4
        initsleeplock(&b->lock, "buffer");
    80206810:	00003a17          	auipc	s4,0x3
    80206814:	360a0a13          	addi	s4,s4,864 # 80209b70 <etext+0xb70>
        b->next = bcache.head.next;
    80206818:	2b893783          	ld	a5,696(s2)
    8020681c:	e8bc                	sd	a5,80(s1)
        b->prev = &bcache.head;
    8020681e:	0534b423          	sd	s3,72(s1)
        initsleeplock(&b->lock, "buffer");
    80206822:	85d2                	mv	a1,s4
    80206824:	01048513          	addi	a0,s1,16
    80206828:	ffffb097          	auipc	ra,0xffffb
    8020682c:	d5c080e7          	jalr	-676(ra) # 80201584 <initsleeplock>
        bcache.head.next->prev = b;
    80206830:	2b893783          	ld	a5,696(s2)
    80206834:	e7a4                	sd	s1,72(a5)
        bcache.head.next = b;
    80206836:	2a993c23          	sd	s1,696(s2)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    8020683a:	45848493          	addi	s1,s1,1112
    8020683e:	fd349de3          	bne	s1,s3,80206818 <binit+0x54>
    }
}
    80206842:	70a2                	ld	ra,40(sp)
    80206844:	7402                	ld	s0,32(sp)
    80206846:	64e2                	ld	s1,24(sp)
    80206848:	6942                	ld	s2,16(sp)
    8020684a:	69a2                	ld	s3,8(sp)
    8020684c:	6a02                	ld	s4,0(sp)
    8020684e:	6145                	addi	sp,sp,48
    80206850:	8082                	ret

0000000080206852 <bread>:
    }
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
}

struct buf *bread(uint32 dev, uint32 blockno)
{
    80206852:	7179                	addi	sp,sp,-48
    80206854:	f406                	sd	ra,40(sp)
    80206856:	f022                	sd	s0,32(sp)
    80206858:	ec26                	sd	s1,24(sp)
    8020685a:	e84a                	sd	s2,16(sp)
    8020685c:	e44e                	sd	s3,8(sp)
    8020685e:	1800                	addi	s0,sp,48
    80206860:	892a                	mv	s2,a0
    80206862:	89ae                	mv	s3,a1
    acquire(&bcache.lock);
    80206864:	00145517          	auipc	a0,0x145
    80206868:	d4450513          	addi	a0,a0,-700 # 8034b5a8 <bcache>
    8020686c:	ffffb097          	auipc	ra,0xffffb
    80206870:	c1c080e7          	jalr	-996(ra) # 80201488 <acquire>
    for (struct buf *b = bcache.head.next; b != &bcache.head; b = b->next) {
    80206874:	0014d497          	auipc	s1,0x14d
    80206878:	fec4b483          	ld	s1,-20(s1) # 80353860 <bcache+0x82b8>
    8020687c:	0014d797          	auipc	a5,0x14d
    80206880:	f9478793          	addi	a5,a5,-108 # 80353810 <bcache+0x8268>
    80206884:	02f48f63          	beq	s1,a5,802068c2 <bread+0x70>
    80206888:	873e                	mv	a4,a5
    8020688a:	a021                	j	80206892 <bread+0x40>
    8020688c:	68a4                	ld	s1,80(s1)
    8020688e:	02e48a63          	beq	s1,a4,802068c2 <bread+0x70>
        if (b->dev == dev && b->blockno == blockno) {
    80206892:	449c                	lw	a5,8(s1)
    80206894:	ff279ce3          	bne	a5,s2,8020688c <bread+0x3a>
    80206898:	44dc                	lw	a5,12(s1)
    8020689a:	ff3799e3          	bne	a5,s3,8020688c <bread+0x3a>
            b->refcnt++;
    8020689e:	40bc                	lw	a5,64(s1)
    802068a0:	2785                	addiw	a5,a5,1
    802068a2:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    802068a4:	00145517          	auipc	a0,0x145
    802068a8:	d0450513          	addi	a0,a0,-764 # 8034b5a8 <bcache>
    802068ac:	ffffb097          	auipc	ra,0xffffb
    802068b0:	c90080e7          	jalr	-880(ra) # 8020153c <release>
            acquiresleep(&b->lock);
    802068b4:	01048513          	addi	a0,s1,16
    802068b8:	ffffb097          	auipc	ra,0xffffb
    802068bc:	d06080e7          	jalr	-762(ra) # 802015be <acquiresleep>
            return b;
    802068c0:	a8b9                	j	8020691e <bread+0xcc>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    802068c2:	0014d497          	auipc	s1,0x14d
    802068c6:	f964b483          	ld	s1,-106(s1) # 80353858 <bcache+0x82b0>
    802068ca:	0014d797          	auipc	a5,0x14d
    802068ce:	f4678793          	addi	a5,a5,-186 # 80353810 <bcache+0x8268>
    802068d2:	00f48863          	beq	s1,a5,802068e2 <bread+0x90>
    802068d6:	873e                	mv	a4,a5
        if (b->refcnt == 0) {
    802068d8:	40bc                	lw	a5,64(s1)
    802068da:	cf81                	beqz	a5,802068f2 <bread+0xa0>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    802068dc:	64a4                	ld	s1,72(s1)
    802068de:	fee49de3          	bne	s1,a4,802068d8 <bread+0x86>
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
    802068e2:	00003517          	auipc	a0,0x3
    802068e6:	29650513          	addi	a0,a0,662 # 80209b78 <etext+0xb78>
    802068ea:	ffffa097          	auipc	ra,0xffffa
    802068ee:	d2c080e7          	jalr	-724(ra) # 80200616 <panic>
            b->dev = dev;
    802068f2:	0124a423          	sw	s2,8(s1)
            b->blockno = blockno;
    802068f6:	0134a623          	sw	s3,12(s1)
            b->valid = 0;
    802068fa:	0004a023          	sw	zero,0(s1)
            b->refcnt = 1;
    802068fe:	4785                	li	a5,1
    80206900:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    80206902:	00145517          	auipc	a0,0x145
    80206906:	ca650513          	addi	a0,a0,-858 # 8034b5a8 <bcache>
    8020690a:	ffffb097          	auipc	ra,0xffffb
    8020690e:	c32080e7          	jalr	-974(ra) # 8020153c <release>
            acquiresleep(&b->lock);
    80206912:	01048513          	addi	a0,s1,16
    80206916:	ffffb097          	auipc	ra,0xffffb
    8020691a:	ca8080e7          	jalr	-856(ra) # 802015be <acquiresleep>
    struct buf *b = bget(dev, blockno);
    if (!b->valid) {
    8020691e:	409c                	lw	a5,0(s1)
    80206920:	cb89                	beqz	a5,80206932 <bread+0xe0>
        hal_block_rw(b, 0);
        b->valid = 1;
    }
    return b;
}
    80206922:	8526                	mv	a0,s1
    80206924:	70a2                	ld	ra,40(sp)
    80206926:	7402                	ld	s0,32(sp)
    80206928:	64e2                	ld	s1,24(sp)
    8020692a:	6942                	ld	s2,16(sp)
    8020692c:	69a2                	ld	s3,8(sp)
    8020692e:	6145                	addi	sp,sp,48
    80206930:	8082                	ret
        hal_block_rw(b, 0);
    80206932:	4581                	li	a1,0
    80206934:	8526                	mv	a0,s1
    80206936:	00002097          	auipc	ra,0x2
    8020693a:	c5a080e7          	jalr	-934(ra) # 80208590 <hal_block_rw>
        b->valid = 1;
    8020693e:	4785                	li	a5,1
    80206940:	c09c                	sw	a5,0(s1)
    return b;
    80206942:	b7c5                	j	80206922 <bread+0xd0>

0000000080206944 <bwrite>:

/* Caller must hold b->lock (i.e. this buf came from bread). */
void bwrite(struct buf *b)
{
    80206944:	1101                	addi	sp,sp,-32
    80206946:	ec06                	sd	ra,24(sp)
    80206948:	e822                	sd	s0,16(sp)
    8020694a:	e426                	sd	s1,8(sp)
    8020694c:	1000                	addi	s0,sp,32
    8020694e:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80206950:	0541                	addi	a0,a0,16
    80206952:	ffffb097          	auipc	ra,0xffffb
    80206956:	d06080e7          	jalr	-762(ra) # 80201658 <holdingsleep>
    8020695a:	cd01                	beqz	a0,80206972 <bwrite+0x2e>
    hal_block_rw(b, 1);
    8020695c:	4585                	li	a1,1
    8020695e:	8526                	mv	a0,s1
    80206960:	00002097          	auipc	ra,0x2
    80206964:	c30080e7          	jalr	-976(ra) # 80208590 <hal_block_rw>
}
    80206968:	60e2                	ld	ra,24(sp)
    8020696a:	6442                	ld	s0,16(sp)
    8020696c:	64a2                	ld	s1,8(sp)
    8020696e:	6105                	addi	sp,sp,32
    80206970:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80206972:	00003517          	auipc	a0,0x3
    80206976:	24650513          	addi	a0,a0,582 # 80209bb8 <etext+0xbb8>
    8020697a:	ffffa097          	auipc	ra,0xffffa
    8020697e:	c9c080e7          	jalr	-868(ra) # 80200616 <panic>

0000000080206982 <brelse>:

void brelse(struct buf *b)
{
    80206982:	1101                	addi	sp,sp,-32
    80206984:	ec06                	sd	ra,24(sp)
    80206986:	e822                	sd	s0,16(sp)
    80206988:	e426                	sd	s1,8(sp)
    8020698a:	e04a                	sd	s2,0(sp)
    8020698c:	1000                	addi	s0,sp,32
    8020698e:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80206990:	01050913          	addi	s2,a0,16
    80206994:	854a                	mv	a0,s2
    80206996:	ffffb097          	auipc	ra,0xffffb
    8020699a:	cc2080e7          	jalr	-830(ra) # 80201658 <holdingsleep>
    8020699e:	c925                	beqz	a0,80206a0e <brelse+0x8c>
    releasesleep(&b->lock);
    802069a0:	854a                	mv	a0,s2
    802069a2:	ffffb097          	auipc	ra,0xffffb
    802069a6:	c72080e7          	jalr	-910(ra) # 80201614 <releasesleep>

    acquire(&bcache.lock);
    802069aa:	00145517          	auipc	a0,0x145
    802069ae:	bfe50513          	addi	a0,a0,-1026 # 8034b5a8 <bcache>
    802069b2:	ffffb097          	auipc	ra,0xffffb
    802069b6:	ad6080e7          	jalr	-1322(ra) # 80201488 <acquire>
    b->refcnt--;
    802069ba:	40bc                	lw	a5,64(s1)
    802069bc:	37fd                	addiw	a5,a5,-1
    802069be:	0007871b          	sext.w	a4,a5
    802069c2:	c0bc                	sw	a5,64(s1)
    if (b->refcnt == 0) {
    802069c4:	e71d                	bnez	a4,802069f2 <brelse+0x70>
        /* Move to the front: most recently used. */
        b->next->prev = b->prev;
    802069c6:	68b8                	ld	a4,80(s1)
    802069c8:	64bc                	ld	a5,72(s1)
    802069ca:	e73c                	sd	a5,72(a4)
        b->prev->next = b->next;
    802069cc:	68b8                	ld	a4,80(s1)
    802069ce:	ebb8                	sd	a4,80(a5)
        b->next = bcache.head.next;
    802069d0:	0014d797          	auipc	a5,0x14d
    802069d4:	bd878793          	addi	a5,a5,-1064 # 803535a8 <bcache+0x8000>
    802069d8:	2b87b703          	ld	a4,696(a5)
    802069dc:	e8b8                	sd	a4,80(s1)
        b->prev = &bcache.head;
    802069de:	0014d717          	auipc	a4,0x14d
    802069e2:	e3270713          	addi	a4,a4,-462 # 80353810 <bcache+0x8268>
    802069e6:	e4b8                	sd	a4,72(s1)
        bcache.head.next->prev = b;
    802069e8:	2b87b703          	ld	a4,696(a5)
    802069ec:	e724                	sd	s1,72(a4)
        bcache.head.next = b;
    802069ee:	2a97bc23          	sd	s1,696(a5)
    }
    release(&bcache.lock);
    802069f2:	00145517          	auipc	a0,0x145
    802069f6:	bb650513          	addi	a0,a0,-1098 # 8034b5a8 <bcache>
    802069fa:	ffffb097          	auipc	ra,0xffffb
    802069fe:	b42080e7          	jalr	-1214(ra) # 8020153c <release>
}
    80206a02:	60e2                	ld	ra,24(sp)
    80206a04:	6442                	ld	s0,16(sp)
    80206a06:	64a2                	ld	s1,8(sp)
    80206a08:	6902                	ld	s2,0(sp)
    80206a0a:	6105                	addi	sp,sp,32
    80206a0c:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80206a0e:	00003517          	auipc	a0,0x3
    80206a12:	1c250513          	addi	a0,a0,450 # 80209bd0 <etext+0xbd0>
    80206a16:	ffffa097          	auipc	ra,0xffffa
    80206a1a:	c00080e7          	jalr	-1024(ra) # 80200616 <panic>

0000000080206a1e <bfree>:
    printf("luitfs: out of data blocks\n");
    return 0;
}

static void bfree(int dev, uint32 b)
{
    80206a1e:	1101                	addi	sp,sp,-32
    80206a20:	ec06                	sd	ra,24(sp)
    80206a22:	e822                	sd	s0,16(sp)
    80206a24:	e426                	sd	s1,8(sp)
    80206a26:	e04a                	sd	s2,0(sp)
    80206a28:	1000                	addi	s0,sp,32
    80206a2a:	84ae                	mv	s1,a1
    struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80206a2c:	00d5d59b          	srliw	a1,a1,0xd
    80206a30:	0014d797          	auipc	a5,0x14d
    80206a34:	2507a783          	lw	a5,592(a5) # 80353c80 <sb+0x18>
    80206a38:	9dbd                	addw	a1,a1,a5
    80206a3a:	00000097          	auipc	ra,0x0
    80206a3e:	e18080e7          	jalr	-488(ra) # 80206852 <bread>
    uint32 bi = b % BPB;
    int m = 1 << (bi % 8);
    80206a42:	0074f713          	andi	a4,s1,7
    80206a46:	4785                	li	a5,1
    80206a48:	00e797bb          	sllw	a5,a5,a4
    uint32 bi = b % BPB;
    80206a4c:	14ce                	slli	s1,s1,0x33
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80206a4e:	0364d713          	srli	a4,s1,0x36
    80206a52:	00e504b3          	add	s1,a0,a4
    80206a56:	0584c683          	lbu	a3,88(s1)
    80206a5a:	00d7f633          	and	a2,a5,a3
    80206a5e:	ca0d                	beqz	a2,80206a90 <bfree+0x72>
    80206a60:	892a                	mv	s2,a0
    bp->data[bi / 8] &= ~m;
    80206a62:	1702                	slli	a4,a4,0x20
    80206a64:	9301                	srli	a4,a4,0x20
    80206a66:	972a                	add	a4,a4,a0
    80206a68:	fff7c793          	not	a5,a5
    80206a6c:	8efd                	and	a3,a3,a5
    80206a6e:	04d70c23          	sb	a3,88(a4)
    bwrite(bp);
    80206a72:	00000097          	auipc	ra,0x0
    80206a76:	ed2080e7          	jalr	-302(ra) # 80206944 <bwrite>
    brelse(bp);
    80206a7a:	854a                	mv	a0,s2
    80206a7c:	00000097          	auipc	ra,0x0
    80206a80:	f06080e7          	jalr	-250(ra) # 80206982 <brelse>
}
    80206a84:	60e2                	ld	ra,24(sp)
    80206a86:	6442                	ld	s0,16(sp)
    80206a88:	64a2                	ld	s1,8(sp)
    80206a8a:	6902                	ld	s2,0(sp)
    80206a8c:	6105                	addi	sp,sp,32
    80206a8e:	8082                	ret
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80206a90:	00003517          	auipc	a0,0x3
    80206a94:	15850513          	addi	a0,a0,344 # 80209be8 <etext+0xbe8>
    80206a98:	ffffa097          	auipc	ra,0xffffa
    80206a9c:	b7e080e7          	jalr	-1154(ra) # 80200616 <panic>

0000000080206aa0 <balloc>:
{
    80206aa0:	711d                	addi	sp,sp,-96
    80206aa2:	ec86                	sd	ra,88(sp)
    80206aa4:	e8a2                	sd	s0,80(sp)
    80206aa6:	e4a6                	sd	s1,72(sp)
    80206aa8:	1080                	addi	s0,sp,96
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80206aaa:	0014d797          	auipc	a5,0x14d
    80206aae:	1c67a783          	lw	a5,454(a5) # 80353c70 <sb+0x8>
    80206ab2:	10078463          	beqz	a5,80206bba <balloc+0x11a>
    80206ab6:	e0ca                	sd	s2,64(sp)
    80206ab8:	fc4e                	sd	s3,56(sp)
    80206aba:	f852                	sd	s4,48(sp)
    80206abc:	f456                	sd	s5,40(sp)
    80206abe:	f05a                	sd	s6,32(sp)
    80206ac0:	ec5e                	sd	s7,24(sp)
    80206ac2:	e862                	sd	s8,16(sp)
    80206ac4:	e466                	sd	s9,8(sp)
    80206ac6:	8baa                	mv	s7,a0
    80206ac8:	4a81                	li	s5,0
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80206aca:	0014db17          	auipc	s6,0x14d
    80206ace:	19eb0b13          	addi	s6,s6,414 # 80353c68 <sb>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80206ad2:	4c01                	li	s8,0
            int m = 1 << (bi % 8);
    80206ad4:	4985                	li	s3,1
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80206ad6:	6a09                	lui	s4,0x2
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80206ad8:	6c89                	lui	s9,0x2
    80206ada:	a061                	j	80206b62 <balloc+0xc2>
                bp->data[bi / 8] |= m;              /* claim it... */
    80206adc:	1582                	slli	a1,a1,0x20
    80206ade:	9181                	srli	a1,a1,0x20
    80206ae0:	95ca                	add	a1,a1,s2
    80206ae2:	8ed9                	or	a3,a3,a4
    80206ae4:	04d58c23          	sb	a3,88(a1)
                bwrite(bp);                         /* ...ON DISK, before use */
    80206ae8:	854a                	mv	a0,s2
    80206aea:	00000097          	auipc	ra,0x0
    80206aee:	e5a080e7          	jalr	-422(ra) # 80206944 <bwrite>
                brelse(bp);
    80206af2:	854a                	mv	a0,s2
    80206af4:	00000097          	auipc	ra,0x0
    80206af8:	e8e080e7          	jalr	-370(ra) # 80206982 <brelse>
    struct buf *bp = bread(dev, bno);
    80206afc:	85a6                	mv	a1,s1
    80206afe:	855e                	mv	a0,s7
    80206b00:	00000097          	auipc	ra,0x0
    80206b04:	d52080e7          	jalr	-686(ra) # 80206852 <bread>
    80206b08:	892a                	mv	s2,a0
    memset(bp->data, 0, BSIZE);
    80206b0a:	40000613          	li	a2,1024
    80206b0e:	4581                	li	a1,0
    80206b10:	05850513          	addi	a0,a0,88
    80206b14:	ffffa097          	auipc	ra,0xffffa
    80206b18:	ba8080e7          	jalr	-1112(ra) # 802006bc <memset>
    bwrite(bp);
    80206b1c:	854a                	mv	a0,s2
    80206b1e:	00000097          	auipc	ra,0x0
    80206b22:	e26080e7          	jalr	-474(ra) # 80206944 <bwrite>
    brelse(bp);
    80206b26:	854a                	mv	a0,s2
    80206b28:	00000097          	auipc	ra,0x0
    80206b2c:	e5a080e7          	jalr	-422(ra) # 80206982 <brelse>
}
    80206b30:	6906                	ld	s2,64(sp)
    80206b32:	79e2                	ld	s3,56(sp)
    80206b34:	7a42                	ld	s4,48(sp)
    80206b36:	7aa2                	ld	s5,40(sp)
    80206b38:	7b02                	ld	s6,32(sp)
    80206b3a:	6be2                	ld	s7,24(sp)
    80206b3c:	6c42                	ld	s8,16(sp)
    80206b3e:	6ca2                	ld	s9,8(sp)
}
    80206b40:	8526                	mv	a0,s1
    80206b42:	60e6                	ld	ra,88(sp)
    80206b44:	6446                	ld	s0,80(sp)
    80206b46:	64a6                	ld	s1,72(sp)
    80206b48:	6125                	addi	sp,sp,96
    80206b4a:	8082                	ret
        brelse(bp);
    80206b4c:	854a                	mv	a0,s2
    80206b4e:	00000097          	auipc	ra,0x0
    80206b52:	e34080e7          	jalr	-460(ra) # 80206982 <brelse>
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80206b56:	015c8abb          	addw	s5,s9,s5
    80206b5a:	008b2783          	lw	a5,8(s6)
    80206b5e:	04faf663          	bgeu	s5,a5,80206baa <balloc+0x10a>
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80206b62:	00dad59b          	srliw	a1,s5,0xd
    80206b66:	018b2783          	lw	a5,24(s6)
    80206b6a:	9dbd                	addw	a1,a1,a5
    80206b6c:	855e                	mv	a0,s7
    80206b6e:	00000097          	auipc	ra,0x0
    80206b72:	ce4080e7          	jalr	-796(ra) # 80206852 <bread>
    80206b76:	892a                	mv	s2,a0
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80206b78:	008b2503          	lw	a0,8(s6)
    80206b7c:	84d6                	mv	s1,s5
    80206b7e:	87e2                	mv	a5,s8
    80206b80:	fca4f6e3          	bgeu	s1,a0,80206b4c <balloc+0xac>
            int m = 1 << (bi % 8);
    80206b84:	0077f713          	andi	a4,a5,7
    80206b88:	00e9973b          	sllw	a4,s3,a4
            if ((bp->data[bi / 8] & m) == 0) {
    80206b8c:	0037d59b          	srliw	a1,a5,0x3
    80206b90:	0037d69b          	srliw	a3,a5,0x3
    80206b94:	96ca                	add	a3,a3,s2
    80206b96:	0586c683          	lbu	a3,88(a3)
    80206b9a:	00d77633          	and	a2,a4,a3
    80206b9e:	de1d                	beqz	a2,80206adc <balloc+0x3c>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80206ba0:	2785                	addiw	a5,a5,1
    80206ba2:	2485                	addiw	s1,s1,1
    80206ba4:	fd479ee3          	bne	a5,s4,80206b80 <balloc+0xe0>
    80206ba8:	b755                	j	80206b4c <balloc+0xac>
    80206baa:	6906                	ld	s2,64(sp)
    80206bac:	79e2                	ld	s3,56(sp)
    80206bae:	7a42                	ld	s4,48(sp)
    80206bb0:	7aa2                	ld	s5,40(sp)
    80206bb2:	7b02                	ld	s6,32(sp)
    80206bb4:	6be2                	ld	s7,24(sp)
    80206bb6:	6c42                	ld	s8,16(sp)
    80206bb8:	6ca2                	ld	s9,8(sp)
    printf("luitfs: out of data blocks\n");
    80206bba:	00003517          	auipc	a0,0x3
    80206bbe:	04e50513          	addi	a0,a0,78 # 80209c08 <etext+0xc08>
    80206bc2:	ffff9097          	auipc	ra,0xffff9
    80206bc6:	7e2080e7          	jalr	2018(ra) # 802003a4 <printf>
    return 0;
    80206bca:	4481                	li	s1,0
    80206bcc:	bf95                	j	80206b40 <balloc+0xa0>

0000000080206bce <bmap>:
/* ---------- block mapping ---------- */

/* Return the disk block holding byte-offset block `bn` of ip, allocating it
 * (and the indirect block) on demand. 0 = out of space. Caller holds ip->lock. */
static uint32 bmap(struct inode *ip, uint32 bn)
{
    80206bce:	7179                	addi	sp,sp,-48
    80206bd0:	f406                	sd	ra,40(sp)
    80206bd2:	f022                	sd	s0,32(sp)
    80206bd4:	ec26                	sd	s1,24(sp)
    80206bd6:	e84a                	sd	s2,16(sp)
    80206bd8:	e44e                	sd	s3,8(sp)
    80206bda:	1800                	addi	s0,sp,48
    80206bdc:	89aa                	mv	s3,a0
    if (bn < NDIRECT) {
    80206bde:	47ad                	li	a5,11
    80206be0:	02b7e863          	bltu	a5,a1,80206c10 <bmap+0x42>
        uint32 addr = ip->addrs[bn];
    80206be4:	02059793          	slli	a5,a1,0x20
    80206be8:	01e7d593          	srli	a1,a5,0x1e
    80206bec:	00b504b3          	add	s1,a0,a1
    80206bf0:	0504a903          	lw	s2,80(s1)
        if (addr == 0) {
    80206bf4:	08091263          	bnez	s2,80206c78 <bmap+0xaa>
            addr = balloc(ip->dev);
    80206bf8:	4108                	lw	a0,0(a0)
    80206bfa:	00000097          	auipc	ra,0x0
    80206bfe:	ea6080e7          	jalr	-346(ra) # 80206aa0 <balloc>
    80206c02:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80206c06:	06090963          	beqz	s2,80206c78 <bmap+0xaa>
            ip->addrs[bn] = addr;
    80206c0a:	0524a823          	sw	s2,80(s1)
    80206c0e:	a0ad                	j	80206c78 <bmap+0xaa>
        }
        return addr;
    }
    bn -= NDIRECT;
    80206c10:	ff45849b          	addiw	s1,a1,-12
    80206c14:	0004871b          	sext.w	a4,s1
    if (bn < NINDIRECT) {
    80206c18:	0ff00793          	li	a5,255
    80206c1c:	08e7e863          	bltu	a5,a4,80206cac <bmap+0xde>
        /* Lab 9 extends this function with a DOUBLE-indirect level. */
        uint32 addr = ip->addrs[NDIRECT];
    80206c20:	08052903          	lw	s2,128(a0)
        if (addr == 0) {
    80206c24:	00091f63          	bnez	s2,80206c42 <bmap+0x74>
            addr = balloc(ip->dev);
    80206c28:	4108                	lw	a0,0(a0)
    80206c2a:	00000097          	auipc	ra,0x0
    80206c2e:	e76080e7          	jalr	-394(ra) # 80206aa0 <balloc>
    80206c32:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80206c36:	04090163          	beqz	s2,80206c78 <bmap+0xaa>
    80206c3a:	e052                	sd	s4,0(sp)
            ip->addrs[NDIRECT] = addr;
    80206c3c:	0929a023          	sw	s2,128(s3)
    80206c40:	a011                	j	80206c44 <bmap+0x76>
    80206c42:	e052                	sd	s4,0(sp)
        }
        struct buf *bp = bread(ip->dev, addr);
    80206c44:	85ca                	mv	a1,s2
    80206c46:	0009a503          	lw	a0,0(s3)
    80206c4a:	00000097          	auipc	ra,0x0
    80206c4e:	c08080e7          	jalr	-1016(ra) # 80206852 <bread>
    80206c52:	8a2a                	mv	s4,a0
        uint32 *a = (uint32 *)bp->data;
    80206c54:	05850793          	addi	a5,a0,88
        if ((addr = a[bn]) == 0) {
    80206c58:	02049713          	slli	a4,s1,0x20
    80206c5c:	01e75593          	srli	a1,a4,0x1e
    80206c60:	00b784b3          	add	s1,a5,a1
    80206c64:	0004a903          	lw	s2,0(s1)
    80206c68:	02090063          	beqz	s2,80206c88 <bmap+0xba>
            addr = balloc(ip->dev);
            if (addr) { a[bn] = addr; bwrite(bp); }
        }
        brelse(bp);
    80206c6c:	8552                	mv	a0,s4
    80206c6e:	00000097          	auipc	ra,0x0
    80206c72:	d14080e7          	jalr	-748(ra) # 80206982 <brelse>
        return addr;
    80206c76:	6a02                	ld	s4,0(sp)
    }
    panic("bmap: block number beyond MAXFILE");
}
    80206c78:	854a                	mv	a0,s2
    80206c7a:	70a2                	ld	ra,40(sp)
    80206c7c:	7402                	ld	s0,32(sp)
    80206c7e:	64e2                	ld	s1,24(sp)
    80206c80:	6942                	ld	s2,16(sp)
    80206c82:	69a2                	ld	s3,8(sp)
    80206c84:	6145                	addi	sp,sp,48
    80206c86:	8082                	ret
            addr = balloc(ip->dev);
    80206c88:	0009a503          	lw	a0,0(s3)
    80206c8c:	00000097          	auipc	ra,0x0
    80206c90:	e14080e7          	jalr	-492(ra) # 80206aa0 <balloc>
    80206c94:	0005091b          	sext.w	s2,a0
            if (addr) { a[bn] = addr; bwrite(bp); }
    80206c98:	fc090ae3          	beqz	s2,80206c6c <bmap+0x9e>
    80206c9c:	0124a023          	sw	s2,0(s1)
    80206ca0:	8552                	mv	a0,s4
    80206ca2:	00000097          	auipc	ra,0x0
    80206ca6:	ca2080e7          	jalr	-862(ra) # 80206944 <bwrite>
    80206caa:	b7c9                	j	80206c6c <bmap+0x9e>
    80206cac:	e052                	sd	s4,0(sp)
    panic("bmap: block number beyond MAXFILE");
    80206cae:	00003517          	auipc	a0,0x3
    80206cb2:	f7a50513          	addi	a0,a0,-134 # 80209c28 <etext+0xc28>
    80206cb6:	ffffa097          	auipc	ra,0xffffa
    80206cba:	960080e7          	jalr	-1696(ra) # 80200616 <panic>

0000000080206cbe <iget>:
{
    80206cbe:	7179                	addi	sp,sp,-48
    80206cc0:	f406                	sd	ra,40(sp)
    80206cc2:	f022                	sd	s0,32(sp)
    80206cc4:	ec26                	sd	s1,24(sp)
    80206cc6:	e84a                	sd	s2,16(sp)
    80206cc8:	e44e                	sd	s3,8(sp)
    80206cca:	e052                	sd	s4,0(sp)
    80206ccc:	1800                	addi	s0,sp,48
    80206cce:	89aa                	mv	s3,a0
    80206cd0:	8a2e                	mv	s4,a1
    acquire(&icache.lock);
    80206cd2:	0014d517          	auipc	a0,0x14d
    80206cd6:	fc650513          	addi	a0,a0,-58 # 80353c98 <icache>
    80206cda:	ffffa097          	auipc	ra,0xffffa
    80206cde:	7ae080e7          	jalr	1966(ra) # 80201488 <acquire>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80206ce2:	0014d497          	auipc	s1,0x14d
    80206ce6:	fce48493          	addi	s1,s1,-50 # 80353cb0 <icache+0x18>
    struct inode *empty = 0;
    80206cea:	4901                	li	s2,0
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80206cec:	0014f697          	auipc	a3,0x14f
    80206cf0:	a5468693          	addi	a3,a3,-1452 # 80355740 <devsw>
    80206cf4:	a039                	j	80206d02 <iget+0x44>
        if (empty == 0 && ip->ref == 0)
    80206cf6:	02090b63          	beqz	s2,80206d2c <iget+0x6e>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80206cfa:	08848493          	addi	s1,s1,136
    80206cfe:	02d48a63          	beq	s1,a3,80206d32 <iget+0x74>
        if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80206d02:	449c                	lw	a5,8(s1)
    80206d04:	fef059e3          	blez	a5,80206cf6 <iget+0x38>
    80206d08:	4098                	lw	a4,0(s1)
    80206d0a:	ff3716e3          	bne	a4,s3,80206cf6 <iget+0x38>
    80206d0e:	40d8                	lw	a4,4(s1)
    80206d10:	ff4713e3          	bne	a4,s4,80206cf6 <iget+0x38>
            ip->ref++;
    80206d14:	2785                	addiw	a5,a5,1
    80206d16:	c49c                	sw	a5,8(s1)
            release(&icache.lock);
    80206d18:	0014d517          	auipc	a0,0x14d
    80206d1c:	f8050513          	addi	a0,a0,-128 # 80353c98 <icache>
    80206d20:	ffffb097          	auipc	ra,0xffffb
    80206d24:	81c080e7          	jalr	-2020(ra) # 8020153c <release>
            return ip;
    80206d28:	8926                	mv	s2,s1
    80206d2a:	a03d                	j	80206d58 <iget+0x9a>
        if (empty == 0 && ip->ref == 0)
    80206d2c:	f7f9                	bnez	a5,80206cfa <iget+0x3c>
            empty = ip;
    80206d2e:	8926                	mv	s2,s1
    80206d30:	b7e9                	j	80206cfa <iget+0x3c>
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80206d32:	02090c63          	beqz	s2,80206d6a <iget+0xac>
    ip->dev = dev; ip->inum = inum; ip->ref = 1; ip->valid = 0;
    80206d36:	01392023          	sw	s3,0(s2)
    80206d3a:	01492223          	sw	s4,4(s2)
    80206d3e:	4785                	li	a5,1
    80206d40:	00f92423          	sw	a5,8(s2)
    80206d44:	04092023          	sw	zero,64(s2)
    release(&icache.lock);
    80206d48:	0014d517          	auipc	a0,0x14d
    80206d4c:	f5050513          	addi	a0,a0,-176 # 80353c98 <icache>
    80206d50:	ffffa097          	auipc	ra,0xffffa
    80206d54:	7ec080e7          	jalr	2028(ra) # 8020153c <release>
}
    80206d58:	854a                	mv	a0,s2
    80206d5a:	70a2                	ld	ra,40(sp)
    80206d5c:	7402                	ld	s0,32(sp)
    80206d5e:	64e2                	ld	s1,24(sp)
    80206d60:	6942                	ld	s2,16(sp)
    80206d62:	69a2                	ld	s3,8(sp)
    80206d64:	6a02                	ld	s4,0(sp)
    80206d66:	6145                	addi	sp,sp,48
    80206d68:	8082                	ret
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80206d6a:	00003517          	auipc	a0,0x3
    80206d6e:	ee650513          	addi	a0,a0,-282 # 80209c50 <etext+0xc50>
    80206d72:	ffffa097          	auipc	ra,0xffffa
    80206d76:	8a4080e7          	jalr	-1884(ra) # 80200616 <panic>

0000000080206d7a <fsinit>:
{
    80206d7a:	7179                	addi	sp,sp,-48
    80206d7c:	f406                	sd	ra,40(sp)
    80206d7e:	f022                	sd	s0,32(sp)
    80206d80:	ec26                	sd	s1,24(sp)
    80206d82:	e84a                	sd	s2,16(sp)
    80206d84:	e44e                	sd	s3,8(sp)
    80206d86:	1800                	addi	s0,sp,48
    80206d88:	892a                	mv	s2,a0
    struct buf *bp = bread(dev, 1);
    80206d8a:	4585                	li	a1,1
    80206d8c:	00000097          	auipc	ra,0x0
    80206d90:	ac6080e7          	jalr	-1338(ra) # 80206852 <bread>
    80206d94:	84aa                	mv	s1,a0
    memmove(&sb, bp->data, sizeof(sb));
    80206d96:	0014d997          	auipc	s3,0x14d
    80206d9a:	ed298993          	addi	s3,s3,-302 # 80353c68 <sb>
    80206d9e:	02c00613          	li	a2,44
    80206da2:	05850593          	addi	a1,a0,88
    80206da6:	854e                	mv	a0,s3
    80206da8:	ffffa097          	auipc	ra,0xffffa
    80206dac:	930080e7          	jalr	-1744(ra) # 802006d8 <memmove>
    brelse(bp);
    80206db0:	8526                	mv	a0,s1
    80206db2:	00000097          	auipc	ra,0x0
    80206db6:	bd0080e7          	jalr	-1072(ra) # 80206982 <brelse>
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80206dba:	0009a703          	lw	a4,0(s3)
    80206dbe:	4c5557b7          	lui	a5,0x4c555
    80206dc2:	95478793          	addi	a5,a5,-1708 # 4c554954 <_entry-0x33cab6ac>
    80206dc6:	04f71663          	bne	a4,a5,80206e12 <fsinit+0x98>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80206dca:	0014d717          	auipc	a4,0x14d
    80206dce:	ea272703          	lw	a4,-350(a4) # 80353c6c <sb+0x4>
    80206dd2:	4785                	li	a5,1
    80206dd4:	04f71763          	bne	a4,a5,80206e22 <fsinit+0xa8>
    printf("luitfs: %d blocks, %d inodes, data at block %d, log at %d (%d blocks)\n",
    80206dd8:	0014d597          	auipc	a1,0x14d
    80206ddc:	e9058593          	addi	a1,a1,-368 # 80353c68 <sb>
    80206de0:	51dc                	lw	a5,36(a1)
    80206de2:	5598                	lw	a4,40(a1)
    80206de4:	5194                	lw	a3,32(a1)
    80206de6:	45d0                	lw	a2,12(a1)
    80206de8:	458c                	lw	a1,8(a1)
    80206dea:	00003517          	auipc	a0,0x3
    80206dee:	ed650513          	addi	a0,a0,-298 # 80209cc0 <etext+0xcc0>
    80206df2:	ffff9097          	auipc	ra,0xffff9
    80206df6:	5b2080e7          	jalr	1458(ra) # 802003a4 <printf>
    log_init(dev);                 /* Lab 11: init journal + recover */
    80206dfa:	854a                	mv	a0,s2
    80206dfc:	fffff097          	auipc	ra,0xfffff
    80206e00:	d5c080e7          	jalr	-676(ra) # 80205b58 <log_init>
}
    80206e04:	70a2                	ld	ra,40(sp)
    80206e06:	7402                	ld	s0,32(sp)
    80206e08:	64e2                	ld	s1,24(sp)
    80206e0a:	6942                	ld	s2,16(sp)
    80206e0c:	69a2                	ld	s3,8(sp)
    80206e0e:	6145                	addi	sp,sp,48
    80206e10:	8082                	ret
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80206e12:	00003517          	auipc	a0,0x3
    80206e16:	e6650513          	addi	a0,a0,-410 # 80209c78 <etext+0xc78>
    80206e1a:	ffff9097          	auipc	ra,0xffff9
    80206e1e:	7fc080e7          	jalr	2044(ra) # 80200616 <panic>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80206e22:	00003517          	auipc	a0,0x3
    80206e26:	e7e50513          	addi	a0,a0,-386 # 80209ca0 <etext+0xca0>
    80206e2a:	ffff9097          	auipc	ra,0xffff9
    80206e2e:	7ec080e7          	jalr	2028(ra) # 80200616 <panic>

0000000080206e32 <iinit>:
{
    80206e32:	7179                	addi	sp,sp,-48
    80206e34:	f406                	sd	ra,40(sp)
    80206e36:	f022                	sd	s0,32(sp)
    80206e38:	ec26                	sd	s1,24(sp)
    80206e3a:	e84a                	sd	s2,16(sp)
    80206e3c:	e44e                	sd	s3,8(sp)
    80206e3e:	1800                	addi	s0,sp,48
    initlock(&icache.lock, "icache");
    80206e40:	00003597          	auipc	a1,0x3
    80206e44:	ec858593          	addi	a1,a1,-312 # 80209d08 <etext+0xd08>
    80206e48:	0014d517          	auipc	a0,0x14d
    80206e4c:	e5050513          	addi	a0,a0,-432 # 80353c98 <icache>
    80206e50:	ffffa097          	auipc	ra,0xffffa
    80206e54:	5bc080e7          	jalr	1468(ra) # 8020140c <initlock>
    for (int i = 0; i < NINODE; i++)
    80206e58:	0014d497          	auipc	s1,0x14d
    80206e5c:	e6848493          	addi	s1,s1,-408 # 80353cc0 <icache+0x28>
    80206e60:	0014f997          	auipc	s3,0x14f
    80206e64:	8f098993          	addi	s3,s3,-1808 # 80355750 <devsw+0x10>
        initsleeplock(&icache.inode[i].lock, "inode");
    80206e68:	00003917          	auipc	s2,0x3
    80206e6c:	ea890913          	addi	s2,s2,-344 # 80209d10 <etext+0xd10>
    80206e70:	85ca                	mv	a1,s2
    80206e72:	8526                	mv	a0,s1
    80206e74:	ffffa097          	auipc	ra,0xffffa
    80206e78:	710080e7          	jalr	1808(ra) # 80201584 <initsleeplock>
    for (int i = 0; i < NINODE; i++)
    80206e7c:	08848493          	addi	s1,s1,136
    80206e80:	ff3498e3          	bne	s1,s3,80206e70 <iinit+0x3e>
}
    80206e84:	70a2                	ld	ra,40(sp)
    80206e86:	7402                	ld	s0,32(sp)
    80206e88:	64e2                	ld	s1,24(sp)
    80206e8a:	6942                	ld	s2,16(sp)
    80206e8c:	69a2                	ld	s3,8(sp)
    80206e8e:	6145                	addi	sp,sp,48
    80206e90:	8082                	ret

0000000080206e92 <ialloc>:
{
    80206e92:	715d                	addi	sp,sp,-80
    80206e94:	e486                	sd	ra,72(sp)
    80206e96:	e0a2                	sd	s0,64(sp)
    80206e98:	0880                	addi	s0,sp,80
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80206e9a:	0014d717          	auipc	a4,0x14d
    80206e9e:	dda72703          	lw	a4,-550(a4) # 80353c74 <sb+0xc>
    80206ea2:	4785                	li	a5,1
    80206ea4:	06e7fe63          	bgeu	a5,a4,80206f20 <ialloc+0x8e>
    80206ea8:	fc26                	sd	s1,56(sp)
    80206eaa:	f84a                	sd	s2,48(sp)
    80206eac:	f44e                	sd	s3,40(sp)
    80206eae:	f052                	sd	s4,32(sp)
    80206eb0:	ec56                	sd	s5,24(sp)
    80206eb2:	e85a                	sd	s6,16(sp)
    80206eb4:	e45e                	sd	s7,8(sp)
    80206eb6:	8a2a                	mv	s4,a0
    80206eb8:	8bae                	mv	s7,a1
    80206eba:	4485                	li	s1,1
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80206ebc:	0014d997          	auipc	s3,0x14d
    80206ec0:	dac98993          	addi	s3,s3,-596 # 80353c68 <sb>
        int m = 1 << (bi % 8);
    80206ec4:	4b05                	li	s6,1
        uint32 bi = i % BPB;
    80206ec6:	6a89                	lui	s5,0x2
    80206ec8:	1afd                	addi	s5,s5,-1 # 1fff <_entry-0x801fe001>
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80206eca:	00d4d59b          	srliw	a1,s1,0xd
    80206ece:	0149a783          	lw	a5,20(s3)
    80206ed2:	9dbd                	addw	a1,a1,a5
    80206ed4:	8552                	mv	a0,s4
    80206ed6:	00000097          	auipc	ra,0x0
    80206eda:	97c080e7          	jalr	-1668(ra) # 80206852 <bread>
    80206ede:	892a                	mv	s2,a0
        int m = 1 << (bi % 8);
    80206ee0:	0074f713          	andi	a4,s1,7
    80206ee4:	00eb173b          	sllw	a4,s6,a4
        uint32 bi = i % BPB;
    80206ee8:	0154f7b3          	and	a5,s1,s5
        if ((bp->data[bi / 8] & m) == 0) {
    80206eec:	0037d61b          	srliw	a2,a5,0x3
    80206ef0:	0037d79b          	srliw	a5,a5,0x3
    80206ef4:	97aa                	add	a5,a5,a0
    80206ef6:	0587c783          	lbu	a5,88(a5)
    80206efa:	00f776b3          	and	a3,a4,a5
    80206efe:	ce95                	beqz	a3,80206f3a <ialloc+0xa8>
        brelse(bp);
    80206f00:	00000097          	auipc	ra,0x0
    80206f04:	a82080e7          	jalr	-1406(ra) # 80206982 <brelse>
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80206f08:	2485                	addiw	s1,s1,1
    80206f0a:	00c9a783          	lw	a5,12(s3)
    80206f0e:	faf4eee3          	bltu	s1,a5,80206eca <ialloc+0x38>
    80206f12:	74e2                	ld	s1,56(sp)
    80206f14:	7942                	ld	s2,48(sp)
    80206f16:	79a2                	ld	s3,40(sp)
    80206f18:	7a02                	ld	s4,32(sp)
    80206f1a:	6ae2                	ld	s5,24(sp)
    80206f1c:	6b42                	ld	s6,16(sp)
    80206f1e:	6ba2                	ld	s7,8(sp)
    printf("luitfs: out of inodes\n");
    80206f20:	00003517          	auipc	a0,0x3
    80206f24:	df850513          	addi	a0,a0,-520 # 80209d18 <etext+0xd18>
    80206f28:	ffff9097          	auipc	ra,0xffff9
    80206f2c:	47c080e7          	jalr	1148(ra) # 802003a4 <printf>
    return 0;
    80206f30:	4501                	li	a0,0
}
    80206f32:	60a6                	ld	ra,72(sp)
    80206f34:	6406                	ld	s0,64(sp)
    80206f36:	6161                	addi	sp,sp,80
    80206f38:	8082                	ret
            bp->data[bi / 8] |= m;
    80206f3a:	1602                	slli	a2,a2,0x20
    80206f3c:	9201                	srli	a2,a2,0x20
    80206f3e:	962a                	add	a2,a2,a0
    80206f40:	8fd9                	or	a5,a5,a4
    80206f42:	04f60c23          	sb	a5,88(a2) # 1058 <_entry-0x801fefa8>
            bwrite(bp);
    80206f46:	00000097          	auipc	ra,0x0
    80206f4a:	9fe080e7          	jalr	-1538(ra) # 80206944 <bwrite>
            brelse(bp);
    80206f4e:	854a                	mv	a0,s2
    80206f50:	00000097          	auipc	ra,0x0
    80206f54:	a32080e7          	jalr	-1486(ra) # 80206982 <brelse>
            bp = bread(dev, IBLOCK(i, sb));
    80206f58:	0044d59b          	srliw	a1,s1,0x4
    80206f5c:	0014d797          	auipc	a5,0x14d
    80206f60:	d287a783          	lw	a5,-728(a5) # 80353c84 <sb+0x1c>
    80206f64:	9dbd                	addw	a1,a1,a5
    80206f66:	8552                	mv	a0,s4
    80206f68:	00000097          	auipc	ra,0x0
    80206f6c:	8ea080e7          	jalr	-1814(ra) # 80206852 <bread>
    80206f70:	892a                	mv	s2,a0
            struct dinode *dip = (struct dinode *)bp->data + i % IPB;
    80206f72:	05850993          	addi	s3,a0,88
    80206f76:	00f4f793          	andi	a5,s1,15
    80206f7a:	079a                	slli	a5,a5,0x6
    80206f7c:	99be                	add	s3,s3,a5
            memset(dip, 0, sizeof(*dip));
    80206f7e:	04000613          	li	a2,64
    80206f82:	4581                	li	a1,0
    80206f84:	854e                	mv	a0,s3
    80206f86:	ffff9097          	auipc	ra,0xffff9
    80206f8a:	736080e7          	jalr	1846(ra) # 802006bc <memset>
            dip->type = type;
    80206f8e:	01799023          	sh	s7,0(s3)
            bwrite(bp);
    80206f92:	854a                	mv	a0,s2
    80206f94:	00000097          	auipc	ra,0x0
    80206f98:	9b0080e7          	jalr	-1616(ra) # 80206944 <bwrite>
            brelse(bp);
    80206f9c:	854a                	mv	a0,s2
    80206f9e:	00000097          	auipc	ra,0x0
    80206fa2:	9e4080e7          	jalr	-1564(ra) # 80206982 <brelse>
            return iget(dev, i);
    80206fa6:	85a6                	mv	a1,s1
    80206fa8:	8552                	mv	a0,s4
    80206faa:	00000097          	auipc	ra,0x0
    80206fae:	d14080e7          	jalr	-748(ra) # 80206cbe <iget>
    80206fb2:	74e2                	ld	s1,56(sp)
    80206fb4:	7942                	ld	s2,48(sp)
    80206fb6:	79a2                	ld	s3,40(sp)
    80206fb8:	7a02                	ld	s4,32(sp)
    80206fba:	6ae2                	ld	s5,24(sp)
    80206fbc:	6b42                	ld	s6,16(sp)
    80206fbe:	6ba2                	ld	s7,8(sp)
    80206fc0:	bf8d                	j	80206f32 <ialloc+0xa0>

0000000080206fc2 <iupdate>:
{
    80206fc2:	1101                	addi	sp,sp,-32
    80206fc4:	ec06                	sd	ra,24(sp)
    80206fc6:	e822                	sd	s0,16(sp)
    80206fc8:	e426                	sd	s1,8(sp)
    80206fca:	e04a                	sd	s2,0(sp)
    80206fcc:	1000                	addi	s0,sp,32
    80206fce:	84aa                	mv	s1,a0
    struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80206fd0:	415c                	lw	a5,4(a0)
    80206fd2:	0047d79b          	srliw	a5,a5,0x4
    80206fd6:	0014d597          	auipc	a1,0x14d
    80206fda:	cae5a583          	lw	a1,-850(a1) # 80353c84 <sb+0x1c>
    80206fde:	9dbd                	addw	a1,a1,a5
    80206fe0:	4108                	lw	a0,0(a0)
    80206fe2:	00000097          	auipc	ra,0x0
    80206fe6:	870080e7          	jalr	-1936(ra) # 80206852 <bread>
    80206fea:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    80206fec:	05850793          	addi	a5,a0,88
    80206ff0:	40d8                	lw	a4,4(s1)
    80206ff2:	8b3d                	andi	a4,a4,15
    80206ff4:	071a                	slli	a4,a4,0x6
    80206ff6:	97ba                	add	a5,a5,a4
    dip->type  = ip->type;
    80206ff8:	0444d703          	lhu	a4,68(s1)
    80206ffc:	00e79023          	sh	a4,0(a5)
    dip->major = ip->major;
    80207000:	0464d703          	lhu	a4,70(s1)
    80207004:	00e79123          	sh	a4,2(a5)
    dip->minor = ip->minor;
    80207008:	0484d703          	lhu	a4,72(s1)
    8020700c:	00e79223          	sh	a4,4(a5)
    dip->nlink = ip->nlink;
    80207010:	04a4d703          	lhu	a4,74(s1)
    80207014:	00e79323          	sh	a4,6(a5)
    dip->size  = ip->size;
    80207018:	44f8                	lw	a4,76(s1)
    8020701a:	c798                	sw	a4,8(a5)
    memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8020701c:	03400613          	li	a2,52
    80207020:	05048593          	addi	a1,s1,80
    80207024:	00c78513          	addi	a0,a5,12
    80207028:	ffff9097          	auipc	ra,0xffff9
    8020702c:	6b0080e7          	jalr	1712(ra) # 802006d8 <memmove>
    bwrite(bp);
    80207030:	854a                	mv	a0,s2
    80207032:	00000097          	auipc	ra,0x0
    80207036:	912080e7          	jalr	-1774(ra) # 80206944 <bwrite>
    brelse(bp);
    8020703a:	854a                	mv	a0,s2
    8020703c:	00000097          	auipc	ra,0x0
    80207040:	946080e7          	jalr	-1722(ra) # 80206982 <brelse>
}
    80207044:	60e2                	ld	ra,24(sp)
    80207046:	6442                	ld	s0,16(sp)
    80207048:	64a2                	ld	s1,8(sp)
    8020704a:	6902                	ld	s2,0(sp)
    8020704c:	6105                	addi	sp,sp,32
    8020704e:	8082                	ret

0000000080207050 <idup>:
{
    80207050:	1101                	addi	sp,sp,-32
    80207052:	ec06                	sd	ra,24(sp)
    80207054:	e822                	sd	s0,16(sp)
    80207056:	e426                	sd	s1,8(sp)
    80207058:	1000                	addi	s0,sp,32
    8020705a:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    8020705c:	0014d517          	auipc	a0,0x14d
    80207060:	c3c50513          	addi	a0,a0,-964 # 80353c98 <icache>
    80207064:	ffffa097          	auipc	ra,0xffffa
    80207068:	424080e7          	jalr	1060(ra) # 80201488 <acquire>
    ip->ref++;
    8020706c:	449c                	lw	a5,8(s1)
    8020706e:	2785                	addiw	a5,a5,1
    80207070:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    80207072:	0014d517          	auipc	a0,0x14d
    80207076:	c2650513          	addi	a0,a0,-986 # 80353c98 <icache>
    8020707a:	ffffa097          	auipc	ra,0xffffa
    8020707e:	4c2080e7          	jalr	1218(ra) # 8020153c <release>
}
    80207082:	8526                	mv	a0,s1
    80207084:	60e2                	ld	ra,24(sp)
    80207086:	6442                	ld	s0,16(sp)
    80207088:	64a2                	ld	s1,8(sp)
    8020708a:	6105                	addi	sp,sp,32
    8020708c:	8082                	ret

000000008020708e <ilock>:
{
    8020708e:	1101                	addi	sp,sp,-32
    80207090:	ec06                	sd	ra,24(sp)
    80207092:	e822                	sd	s0,16(sp)
    80207094:	e426                	sd	s1,8(sp)
    80207096:	1000                	addi	s0,sp,32
    if (ip == 0 || ip->ref < 1) panic("ilock");
    80207098:	c10d                	beqz	a0,802070ba <ilock+0x2c>
    8020709a:	84aa                	mv	s1,a0
    8020709c:	451c                	lw	a5,8(a0)
    8020709e:	00f05e63          	blez	a5,802070ba <ilock+0x2c>
    acquiresleep(&ip->lock);
    802070a2:	0541                	addi	a0,a0,16
    802070a4:	ffffa097          	auipc	ra,0xffffa
    802070a8:	51a080e7          	jalr	1306(ra) # 802015be <acquiresleep>
    if (!ip->valid) {
    802070ac:	40bc                	lw	a5,64(s1)
    802070ae:	cf99                	beqz	a5,802070cc <ilock+0x3e>
}
    802070b0:	60e2                	ld	ra,24(sp)
    802070b2:	6442                	ld	s0,16(sp)
    802070b4:	64a2                	ld	s1,8(sp)
    802070b6:	6105                	addi	sp,sp,32
    802070b8:	8082                	ret
    802070ba:	e04a                	sd	s2,0(sp)
    if (ip == 0 || ip->ref < 1) panic("ilock");
    802070bc:	00003517          	auipc	a0,0x3
    802070c0:	c7450513          	addi	a0,a0,-908 # 80209d30 <etext+0xd30>
    802070c4:	ffff9097          	auipc	ra,0xffff9
    802070c8:	552080e7          	jalr	1362(ra) # 80200616 <panic>
    802070cc:	e04a                	sd	s2,0(sp)
        struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    802070ce:	40dc                	lw	a5,4(s1)
    802070d0:	0047d79b          	srliw	a5,a5,0x4
    802070d4:	0014d597          	auipc	a1,0x14d
    802070d8:	bb05a583          	lw	a1,-1104(a1) # 80353c84 <sb+0x1c>
    802070dc:	9dbd                	addw	a1,a1,a5
    802070de:	4088                	lw	a0,0(s1)
    802070e0:	fffff097          	auipc	ra,0xfffff
    802070e4:	772080e7          	jalr	1906(ra) # 80206852 <bread>
    802070e8:	892a                	mv	s2,a0
        struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    802070ea:	05850593          	addi	a1,a0,88
    802070ee:	40dc                	lw	a5,4(s1)
    802070f0:	8bbd                	andi	a5,a5,15
    802070f2:	079a                	slli	a5,a5,0x6
    802070f4:	95be                	add	a1,a1,a5
        ip->type  = dip->type;
    802070f6:	0005d783          	lhu	a5,0(a1)
    802070fa:	04f49223          	sh	a5,68(s1)
        ip->major = dip->major;
    802070fe:	0025d783          	lhu	a5,2(a1)
    80207102:	04f49323          	sh	a5,70(s1)
        ip->minor = dip->minor;
    80207106:	0045d783          	lhu	a5,4(a1)
    8020710a:	04f49423          	sh	a5,72(s1)
        ip->nlink = dip->nlink;
    8020710e:	0065d783          	lhu	a5,6(a1)
    80207112:	04f49523          	sh	a5,74(s1)
        ip->size  = dip->size;
    80207116:	459c                	lw	a5,8(a1)
    80207118:	c4fc                	sw	a5,76(s1)
        memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8020711a:	03400613          	li	a2,52
    8020711e:	05b1                	addi	a1,a1,12
    80207120:	05048513          	addi	a0,s1,80
    80207124:	ffff9097          	auipc	ra,0xffff9
    80207128:	5b4080e7          	jalr	1460(ra) # 802006d8 <memmove>
        brelse(bp);
    8020712c:	854a                	mv	a0,s2
    8020712e:	00000097          	auipc	ra,0x0
    80207132:	854080e7          	jalr	-1964(ra) # 80206982 <brelse>
        ip->valid = 1;
    80207136:	4785                	li	a5,1
    80207138:	c0bc                	sw	a5,64(s1)
        if (ip->type == 0) panic("ilock: inode has no type (bitmap out of sync)");
    8020713a:	0444d783          	lhu	a5,68(s1)
    8020713e:	c399                	beqz	a5,80207144 <ilock+0xb6>
    80207140:	6902                	ld	s2,0(sp)
    80207142:	b7bd                	j	802070b0 <ilock+0x22>
    80207144:	00003517          	auipc	a0,0x3
    80207148:	bf450513          	addi	a0,a0,-1036 # 80209d38 <etext+0xd38>
    8020714c:	ffff9097          	auipc	ra,0xffff9
    80207150:	4ca080e7          	jalr	1226(ra) # 80200616 <panic>

0000000080207154 <iunlock>:
{
    80207154:	1101                	addi	sp,sp,-32
    80207156:	ec06                	sd	ra,24(sp)
    80207158:	e822                	sd	s0,16(sp)
    8020715a:	e426                	sd	s1,8(sp)
    8020715c:	e04a                	sd	s2,0(sp)
    8020715e:	1000                	addi	s0,sp,32
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    80207160:	c905                	beqz	a0,80207190 <iunlock+0x3c>
    80207162:	84aa                	mv	s1,a0
    80207164:	01050913          	addi	s2,a0,16
    80207168:	854a                	mv	a0,s2
    8020716a:	ffffa097          	auipc	ra,0xffffa
    8020716e:	4ee080e7          	jalr	1262(ra) # 80201658 <holdingsleep>
    80207172:	cd19                	beqz	a0,80207190 <iunlock+0x3c>
    80207174:	449c                	lw	a5,8(s1)
    80207176:	00f05d63          	blez	a5,80207190 <iunlock+0x3c>
    releasesleep(&ip->lock);
    8020717a:	854a                	mv	a0,s2
    8020717c:	ffffa097          	auipc	ra,0xffffa
    80207180:	498080e7          	jalr	1176(ra) # 80201614 <releasesleep>
}
    80207184:	60e2                	ld	ra,24(sp)
    80207186:	6442                	ld	s0,16(sp)
    80207188:	64a2                	ld	s1,8(sp)
    8020718a:	6902                	ld	s2,0(sp)
    8020718c:	6105                	addi	sp,sp,32
    8020718e:	8082                	ret
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    80207190:	00003517          	auipc	a0,0x3
    80207194:	bd850513          	addi	a0,a0,-1064 # 80209d68 <etext+0xd68>
    80207198:	ffff9097          	auipc	ra,0xffff9
    8020719c:	47e080e7          	jalr	1150(ra) # 80200616 <panic>

00000000802071a0 <itrunc>:

/* Free all data blocks of ip and set size 0. Caller holds ip->lock. */
void itrunc(struct inode *ip)
{
    802071a0:	7179                	addi	sp,sp,-48
    802071a2:	f406                	sd	ra,40(sp)
    802071a4:	f022                	sd	s0,32(sp)
    802071a6:	ec26                	sd	s1,24(sp)
    802071a8:	e84a                	sd	s2,16(sp)
    802071aa:	e44e                	sd	s3,8(sp)
    802071ac:	1800                	addi	s0,sp,48
    802071ae:	89aa                	mv	s3,a0
    for (int i = 0; i < NDIRECT; i++) {
    802071b0:	05050493          	addi	s1,a0,80
    802071b4:	08050913          	addi	s2,a0,128
    802071b8:	a021                	j	802071c0 <itrunc+0x20>
    802071ba:	0491                	addi	s1,s1,4
    802071bc:	01248d63          	beq	s1,s2,802071d6 <itrunc+0x36>
        if (ip->addrs[i]) { bfree(ip->dev, ip->addrs[i]); ip->addrs[i] = 0; }
    802071c0:	408c                	lw	a1,0(s1)
    802071c2:	dde5                	beqz	a1,802071ba <itrunc+0x1a>
    802071c4:	0009a503          	lw	a0,0(s3)
    802071c8:	00000097          	auipc	ra,0x0
    802071cc:	856080e7          	jalr	-1962(ra) # 80206a1e <bfree>
    802071d0:	0004a023          	sw	zero,0(s1)
    802071d4:	b7dd                	j	802071ba <itrunc+0x1a>
    }
    if (ip->addrs[NDIRECT]) {
    802071d6:	0809a583          	lw	a1,128(s3)
    802071da:	ed99                	bnez	a1,802071f8 <itrunc+0x58>
            if (a[j]) bfree(ip->dev, a[j]);
        brelse(bp);
        bfree(ip->dev, ip->addrs[NDIRECT]);
        ip->addrs[NDIRECT] = 0;
    }
    ip->size = 0;
    802071dc:	0409a623          	sw	zero,76(s3)
    iupdate(ip);
    802071e0:	854e                	mv	a0,s3
    802071e2:	00000097          	auipc	ra,0x0
    802071e6:	de0080e7          	jalr	-544(ra) # 80206fc2 <iupdate>
}
    802071ea:	70a2                	ld	ra,40(sp)
    802071ec:	7402                	ld	s0,32(sp)
    802071ee:	64e2                	ld	s1,24(sp)
    802071f0:	6942                	ld	s2,16(sp)
    802071f2:	69a2                	ld	s3,8(sp)
    802071f4:	6145                	addi	sp,sp,48
    802071f6:	8082                	ret
    802071f8:	e052                	sd	s4,0(sp)
        struct buf *bp = bread(ip->dev, ip->addrs[NDIRECT]);
    802071fa:	0009a503          	lw	a0,0(s3)
    802071fe:	fffff097          	auipc	ra,0xfffff
    80207202:	654080e7          	jalr	1620(ra) # 80206852 <bread>
    80207206:	8a2a                	mv	s4,a0
        for (uint32 j = 0; j < NINDIRECT; j++)
    80207208:	05850493          	addi	s1,a0,88
    8020720c:	45850913          	addi	s2,a0,1112
    80207210:	a021                	j	80207218 <itrunc+0x78>
    80207212:	0491                	addi	s1,s1,4
    80207214:	01248b63          	beq	s1,s2,8020722a <itrunc+0x8a>
            if (a[j]) bfree(ip->dev, a[j]);
    80207218:	408c                	lw	a1,0(s1)
    8020721a:	dde5                	beqz	a1,80207212 <itrunc+0x72>
    8020721c:	0009a503          	lw	a0,0(s3)
    80207220:	fffff097          	auipc	ra,0xfffff
    80207224:	7fe080e7          	jalr	2046(ra) # 80206a1e <bfree>
    80207228:	b7ed                	j	80207212 <itrunc+0x72>
        brelse(bp);
    8020722a:	8552                	mv	a0,s4
    8020722c:	fffff097          	auipc	ra,0xfffff
    80207230:	756080e7          	jalr	1878(ra) # 80206982 <brelse>
        bfree(ip->dev, ip->addrs[NDIRECT]);
    80207234:	0809a583          	lw	a1,128(s3)
    80207238:	0009a503          	lw	a0,0(s3)
    8020723c:	fffff097          	auipc	ra,0xfffff
    80207240:	7e2080e7          	jalr	2018(ra) # 80206a1e <bfree>
        ip->addrs[NDIRECT] = 0;
    80207244:	0809a023          	sw	zero,128(s3)
    80207248:	6a02                	ld	s4,0(sp)
    8020724a:	bf49                	j	802071dc <itrunc+0x3c>

000000008020724c <iput>:
{
    8020724c:	7179                	addi	sp,sp,-48
    8020724e:	f406                	sd	ra,40(sp)
    80207250:	f022                	sd	s0,32(sp)
    80207252:	ec26                	sd	s1,24(sp)
    80207254:	1800                	addi	s0,sp,48
    80207256:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    80207258:	0014d517          	auipc	a0,0x14d
    8020725c:	a4050513          	addi	a0,a0,-1472 # 80353c98 <icache>
    80207260:	ffffa097          	auipc	ra,0xffffa
    80207264:	228080e7          	jalr	552(ra) # 80201488 <acquire>
    if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80207268:	4498                	lw	a4,8(s1)
    8020726a:	4785                	li	a5,1
    8020726c:	00f71763          	bne	a4,a5,8020727a <iput+0x2e>
    80207270:	40bc                	lw	a5,64(s1)
    80207272:	c781                	beqz	a5,8020727a <iput+0x2e>
    80207274:	04a4d783          	lhu	a5,74(s1)
    80207278:	c38d                	beqz	a5,8020729a <iput+0x4e>
    ip->ref--;
    8020727a:	449c                	lw	a5,8(s1)
    8020727c:	37fd                	addiw	a5,a5,-1
    8020727e:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    80207280:	0014d517          	auipc	a0,0x14d
    80207284:	a1850513          	addi	a0,a0,-1512 # 80353c98 <icache>
    80207288:	ffffa097          	auipc	ra,0xffffa
    8020728c:	2b4080e7          	jalr	692(ra) # 8020153c <release>
}
    80207290:	70a2                	ld	ra,40(sp)
    80207292:	7402                	ld	s0,32(sp)
    80207294:	64e2                	ld	s1,24(sp)
    80207296:	6145                	addi	sp,sp,48
    80207298:	8082                	ret
    8020729a:	e84a                	sd	s2,16(sp)
    8020729c:	e44e                	sd	s3,8(sp)
        acquiresleep(&ip->lock);
    8020729e:	01048993          	addi	s3,s1,16
    802072a2:	854e                	mv	a0,s3
    802072a4:	ffffa097          	auipc	ra,0xffffa
    802072a8:	31a080e7          	jalr	794(ra) # 802015be <acquiresleep>
        release(&icache.lock);
    802072ac:	0014d517          	auipc	a0,0x14d
    802072b0:	9ec50513          	addi	a0,a0,-1556 # 80353c98 <icache>
    802072b4:	ffffa097          	auipc	ra,0xffffa
    802072b8:	288080e7          	jalr	648(ra) # 8020153c <release>
        itrunc(ip);
    802072bc:	8526                	mv	a0,s1
    802072be:	00000097          	auipc	ra,0x0
    802072c2:	ee2080e7          	jalr	-286(ra) # 802071a0 <itrunc>
        ip->type = 0;
    802072c6:	04049223          	sh	zero,68(s1)
        iupdate(ip);
    802072ca:	8526                	mv	a0,s1
    802072cc:	00000097          	auipc	ra,0x0
    802072d0:	cf6080e7          	jalr	-778(ra) # 80206fc2 <iupdate>
        struct buf *bp = bread(ip->dev, IBBLOCK(ip->inum, sb));
    802072d4:	40dc                	lw	a5,4(s1)
    802072d6:	00d7d79b          	srliw	a5,a5,0xd
    802072da:	0014d597          	auipc	a1,0x14d
    802072de:	9a25a583          	lw	a1,-1630(a1) # 80353c7c <sb+0x14>
    802072e2:	9dbd                	addw	a1,a1,a5
    802072e4:	4088                	lw	a0,0(s1)
    802072e6:	fffff097          	auipc	ra,0xfffff
    802072ea:	56c080e7          	jalr	1388(ra) # 80206852 <bread>
    802072ee:	892a                	mv	s2,a0
        uint32 bi = ip->inum % BPB;
    802072f0:	40d4                	lw	a3,4(s1)
    802072f2:	03369793          	slli	a5,a3,0x33
        if ((bp->data[bi / 8] & (1 << (bi % 8))) == 0)
    802072f6:	0367d713          	srli	a4,a5,0x36
    802072fa:	00e507b3          	add	a5,a0,a4
    802072fe:	0587c603          	lbu	a2,88(a5)
    80207302:	8a9d                	andi	a3,a3,7
    80207304:	40d657bb          	sraw	a5,a2,a3
    80207308:	8b85                	andi	a5,a5,1
    8020730a:	cba1                	beqz	a5,8020735a <iput+0x10e>
        bp->data[bi / 8] &= ~(1 << (bi % 8));
    8020730c:	02071793          	slli	a5,a4,0x20
    80207310:	9381                	srli	a5,a5,0x20
    80207312:	97aa                	add	a5,a5,a0
    80207314:	4705                	li	a4,1
    80207316:	00d7173b          	sllw	a4,a4,a3
    8020731a:	fff74713          	not	a4,a4
    8020731e:	8e79                	and	a2,a2,a4
    80207320:	04c78c23          	sb	a2,88(a5)
        bwrite(bp);
    80207324:	fffff097          	auipc	ra,0xfffff
    80207328:	620080e7          	jalr	1568(ra) # 80206944 <bwrite>
        brelse(bp);
    8020732c:	854a                	mv	a0,s2
    8020732e:	fffff097          	auipc	ra,0xfffff
    80207332:	654080e7          	jalr	1620(ra) # 80206982 <brelse>
        ip->valid = 0;
    80207336:	0404a023          	sw	zero,64(s1)
        releasesleep(&ip->lock);
    8020733a:	854e                	mv	a0,s3
    8020733c:	ffffa097          	auipc	ra,0xffffa
    80207340:	2d8080e7          	jalr	728(ra) # 80201614 <releasesleep>
        acquire(&icache.lock);
    80207344:	0014d517          	auipc	a0,0x14d
    80207348:	95450513          	addi	a0,a0,-1708 # 80353c98 <icache>
    8020734c:	ffffa097          	auipc	ra,0xffffa
    80207350:	13c080e7          	jalr	316(ra) # 80201488 <acquire>
    80207354:	6942                	ld	s2,16(sp)
    80207356:	69a2                	ld	s3,8(sp)
    80207358:	b70d                	j	8020727a <iput+0x2e>
            panic("iput: inode bitmap already clear");
    8020735a:	00003517          	auipc	a0,0x3
    8020735e:	a1650513          	addi	a0,a0,-1514 # 80209d70 <etext+0xd70>
    80207362:	ffff9097          	auipc	ra,0xffff9
    80207366:	2b4080e7          	jalr	692(ra) # 80200616 <panic>

000000008020736a <iunlockput>:
void iunlockput(struct inode *ip) { iunlock(ip); iput(ip); }
    8020736a:	1101                	addi	sp,sp,-32
    8020736c:	ec06                	sd	ra,24(sp)
    8020736e:	e822                	sd	s0,16(sp)
    80207370:	e426                	sd	s1,8(sp)
    80207372:	1000                	addi	s0,sp,32
    80207374:	84aa                	mv	s1,a0
    80207376:	00000097          	auipc	ra,0x0
    8020737a:	dde080e7          	jalr	-546(ra) # 80207154 <iunlock>
    8020737e:	8526                	mv	a0,s1
    80207380:	00000097          	auipc	ra,0x0
    80207384:	ecc080e7          	jalr	-308(ra) # 8020724c <iput>
    80207388:	60e2                	ld	ra,24(sp)
    8020738a:	6442                	ld	s0,16(sp)
    8020738c:	64a2                	ld	s1,8(sp)
    8020738e:	6105                	addi	sp,sp,32
    80207390:	8082                	ret

0000000080207392 <stati>:

void stati(struct inode *ip, struct stat *st)
{
    80207392:	1141                	addi	sp,sp,-16
    80207394:	e422                	sd	s0,8(sp)
    80207396:	0800                	addi	s0,sp,16
    st->dev   = ip->dev;
    80207398:	411c                	lw	a5,0(a0)
    8020739a:	c19c                	sw	a5,0(a1)
    st->ino   = ip->inum;
    8020739c:	415c                	lw	a5,4(a0)
    8020739e:	c1dc                	sw	a5,4(a1)
    st->type  = ip->type;
    802073a0:	04455783          	lhu	a5,68(a0)
    802073a4:	00f59423          	sh	a5,8(a1)
    st->nlink = ip->nlink;
    802073a8:	04a55783          	lhu	a5,74(a0)
    802073ac:	00f59523          	sh	a5,10(a1)
    st->size  = ip->size;
    802073b0:	04c56783          	lwu	a5,76(a0)
    802073b4:	e99c                	sd	a5,16(a1)
}
    802073b6:	6422                	ld	s0,8(sp)
    802073b8:	0141                	addi	sp,sp,16
    802073ba:	8082                	ret

00000000802073bc <readi>:

/* Read n bytes at offset off into dst (user va if user_dst, else kernel).
 * Returns bytes read, or -1. Caller holds ip->lock. */
int readi(struct inode *ip, int user_dst, uint64 dst, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return 0;
    802073bc:	457c                	lw	a5,76(a0)
    802073be:	12d7e763          	bltu	a5,a3,802074ec <readi+0x130>
{
    802073c2:	7159                	addi	sp,sp,-112
    802073c4:	f486                	sd	ra,104(sp)
    802073c6:	f0a2                	sd	s0,96(sp)
    802073c8:	eca6                	sd	s1,88(sp)
    802073ca:	e0d2                	sd	s4,64(sp)
    802073cc:	f45e                	sd	s7,40(sp)
    802073ce:	f062                	sd	s8,32(sp)
    802073d0:	ec66                	sd	s9,24(sp)
    802073d2:	1880                	addi	s0,sp,112
    802073d4:	8c2a                	mv	s8,a0
    802073d6:	8cae                	mv	s9,a1
    802073d8:	8a32                	mv	s4,a2
    802073da:	84b6                	mv	s1,a3
    802073dc:	8bba                	mv	s7,a4
    if (off > ip->size || off + n < off) return 0;
    802073de:	9f35                	addw	a4,a4,a3
    802073e0:	4501                	li	a0,0
    802073e2:	0ed76c63          	bltu	a4,a3,802074da <readi+0x11e>
    802073e6:	e4ce                	sd	s3,72(sp)
    if (off + n > ip->size) n = ip->size - off;
    802073e8:	00e7f463          	bgeu	a5,a4,802073f0 <readi+0x34>
    802073ec:	40d78bbb          	subw	s7,a5,a3

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    802073f0:	0c0b8b63          	beqz	s7,802074c6 <readi+0x10a>
    802073f4:	e8ca                	sd	s2,80(sp)
    802073f6:	fc56                	sd	s5,56(sp)
    802073f8:	f85a                	sd	s6,48(sp)
    802073fa:	e86a                	sd	s10,16(sp)
    802073fc:	e46e                	sd	s11,8(sp)
    802073fe:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80207400:	40000d13          	li	s10,1024
    80207404:	a81d                	j	8020743a <readi+0x7e>
                brelse(bp);
                tot = -1;
                break;
            }
        } else {
            memmove((void *)dst, bp->data + off % BSIZE, m);
    80207406:	05890593          	addi	a1,s2,88
    8020740a:	020a9613          	slli	a2,s5,0x20
    8020740e:	9201                	srli	a2,a2,0x20
    80207410:	95da                	add	a1,a1,s6
    80207412:	8552                	mv	a0,s4
    80207414:	ffff9097          	auipc	ra,0xffff9
    80207418:	2c4080e7          	jalr	708(ra) # 802006d8 <memmove>
        }
        brelse(bp);
    8020741c:	854a                	mv	a0,s2
    8020741e:	fffff097          	auipc	ra,0xfffff
    80207422:	564080e7          	jalr	1380(ra) # 80206982 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80207426:	013d89bb          	addw	s3,s11,s3
    8020742a:	009d84bb          	addw	s1,s11,s1
    8020742e:	1d82                	slli	s11,s11,0x20
    80207430:	020ddd93          	srli	s11,s11,0x20
    80207434:	9a6e                	add	s4,s4,s11
    80207436:	0979f263          	bgeu	s3,s7,802074ba <readi+0xfe>
        uint32 addr = bmap(ip, off / BSIZE);
    8020743a:	00a4d59b          	srliw	a1,s1,0xa
    8020743e:	8562                	mv	a0,s8
    80207440:	fffff097          	auipc	ra,0xfffff
    80207444:	78e080e7          	jalr	1934(ra) # 80206bce <bmap>
    80207448:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;
    8020744c:	cdbd                	beqz	a1,802074ca <readi+0x10e>
        struct buf *bp = bread(ip->dev, addr);
    8020744e:	000c2503          	lw	a0,0(s8)
    80207452:	fffff097          	auipc	ra,0xfffff
    80207456:	400080e7          	jalr	1024(ra) # 80206852 <bread>
    8020745a:	892a                	mv	s2,a0
        m = BSIZE - off % BSIZE;
    8020745c:	3ff4fb13          	andi	s6,s1,1023
        if (m > n - tot) m = n - tot;
    80207460:	413b87bb          	subw	a5,s7,s3
        m = BSIZE - off % BSIZE;
    80207464:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    80207468:	8abe                	mv	s5,a5
    8020746a:	2781                	sext.w	a5,a5
    8020746c:	0007069b          	sext.w	a3,a4
    80207470:	00f6f363          	bgeu	a3,a5,80207476 <readi+0xba>
    80207474:	8aba                	mv	s5,a4
    80207476:	000a8d9b          	sext.w	s11,s5
        if (user_dst) {
    8020747a:	f80c86e3          	beqz	s9,80207406 <readi+0x4a>
            if (copyout(myproc()->pagetable, dst,
    8020747e:	ffffa097          	auipc	ra,0xffffa
    80207482:	472080e7          	jalr	1138(ra) # 802018f0 <myproc>
                        (char *)bp->data + off % BSIZE, m) < 0) {
    80207486:	05890613          	addi	a2,s2,88
            if (copyout(myproc()->pagetable, dst,
    8020748a:	020a9693          	slli	a3,s5,0x20
    8020748e:	9281                	srli	a3,a3,0x20
    80207490:	965a                	add	a2,a2,s6
    80207492:	85d2                	mv	a1,s4
    80207494:	6928                	ld	a0,80(a0)
    80207496:	ffffc097          	auipc	ra,0xffffc
    8020749a:	fc4080e7          	jalr	-60(ra) # 8020345a <copyout>
    8020749e:	f6055fe3          	bgez	a0,8020741c <readi+0x60>
                brelse(bp);
    802074a2:	854a                	mv	a0,s2
    802074a4:	fffff097          	auipc	ra,0xfffff
    802074a8:	4de080e7          	jalr	1246(ra) # 80206982 <brelse>
                tot = -1;
    802074ac:	59fd                	li	s3,-1
                break;
    802074ae:	6946                	ld	s2,80(sp)
    802074b0:	7ae2                	ld	s5,56(sp)
    802074b2:	7b42                	ld	s6,48(sp)
    802074b4:	6d42                	ld	s10,16(sp)
    802074b6:	6da2                	ld	s11,8(sp)
    802074b8:	a831                	j	802074d4 <readi+0x118>
    802074ba:	6946                	ld	s2,80(sp)
    802074bc:	7ae2                	ld	s5,56(sp)
    802074be:	7b42                	ld	s6,48(sp)
    802074c0:	6d42                	ld	s10,16(sp)
    802074c2:	6da2                	ld	s11,8(sp)
    802074c4:	a801                	j	802074d4 <readi+0x118>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    802074c6:	89de                	mv	s3,s7
    802074c8:	a031                	j	802074d4 <readi+0x118>
    802074ca:	6946                	ld	s2,80(sp)
    802074cc:	7ae2                	ld	s5,56(sp)
    802074ce:	7b42                	ld	s6,48(sp)
    802074d0:	6d42                	ld	s10,16(sp)
    802074d2:	6da2                	ld	s11,8(sp)
    }
    return tot;
    802074d4:	0009851b          	sext.w	a0,s3
    802074d8:	69a6                	ld	s3,72(sp)
}
    802074da:	70a6                	ld	ra,104(sp)
    802074dc:	7406                	ld	s0,96(sp)
    802074de:	64e6                	ld	s1,88(sp)
    802074e0:	6a06                	ld	s4,64(sp)
    802074e2:	7ba2                	ld	s7,40(sp)
    802074e4:	7c02                	ld	s8,32(sp)
    802074e6:	6ce2                	ld	s9,24(sp)
    802074e8:	6165                	addi	sp,sp,112
    802074ea:	8082                	ret
    if (off > ip->size || off + n < off) return 0;
    802074ec:	4501                	li	a0,0
}
    802074ee:	8082                	ret

00000000802074f0 <writei>:

/* Write n bytes at off from src. Grows the file if needed. Caller holds lock. */
int writei(struct inode *ip, int user_src, uint64 src, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return -1;
    802074f0:	457c                	lw	a5,76(a0)
    802074f2:	14d7e063          	bltu	a5,a3,80207632 <writei+0x142>
{
    802074f6:	7159                	addi	sp,sp,-112
    802074f8:	f486                	sd	ra,104(sp)
    802074fa:	f0a2                	sd	s0,96(sp)
    802074fc:	e8ca                	sd	s2,80(sp)
    802074fe:	fc56                	sd	s5,56(sp)
    80207500:	f45e                	sd	s7,40(sp)
    80207502:	f062                	sd	s8,32(sp)
    80207504:	ec66                	sd	s9,24(sp)
    80207506:	1880                	addi	s0,sp,112
    80207508:	8baa                	mv	s7,a0
    8020750a:	8cae                	mv	s9,a1
    8020750c:	8ab2                	mv	s5,a2
    8020750e:	8936                	mv	s2,a3
    80207510:	8c3a                	mv	s8,a4
    if (off > ip->size || off + n < off) return -1;
    80207512:	00e687bb          	addw	a5,a3,a4
    80207516:	12d7e063          	bltu	a5,a3,80207636 <writei+0x146>
    if (off + n > MAXFILE * BSIZE) return -1;
    8020751a:	00043737          	lui	a4,0x43
    8020751e:	10f76e63          	bltu	a4,a5,8020763a <writei+0x14a>
    80207522:	e4ce                	sd	s3,72(sp)

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80207524:	0e0c0f63          	beqz	s8,80207622 <writei+0x132>
    80207528:	eca6                	sd	s1,88(sp)
    8020752a:	e0d2                	sd	s4,64(sp)
    8020752c:	f85a                	sd	s6,48(sp)
    8020752e:	e86a                	sd	s10,16(sp)
    80207530:	e46e                	sd	s11,8(sp)
    80207532:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;                     /* disk full: partial write */
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80207534:	40000d13          	li	s10,1024
    80207538:	a081                	j	80207578 <writei+0x88>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
                brelse(bp);
                break;
            }
        } else {
            memmove(bp->data + off % BSIZE, (void *)src, m);
    8020753a:	05848513          	addi	a0,s1,88
    8020753e:	020a1613          	slli	a2,s4,0x20
    80207542:	9201                	srli	a2,a2,0x20
    80207544:	85d6                	mv	a1,s5
    80207546:	955a                	add	a0,a0,s6
    80207548:	ffff9097          	auipc	ra,0xffff9
    8020754c:	190080e7          	jalr	400(ra) # 802006d8 <memmove>
        }
        bwrite(bp);
    80207550:	8526                	mv	a0,s1
    80207552:	fffff097          	auipc	ra,0xfffff
    80207556:	3f2080e7          	jalr	1010(ra) # 80206944 <bwrite>
        brelse(bp);
    8020755a:	8526                	mv	a0,s1
    8020755c:	fffff097          	auipc	ra,0xfffff
    80207560:	426080e7          	jalr	1062(ra) # 80206982 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80207564:	013d89bb          	addw	s3,s11,s3
    80207568:	012d893b          	addw	s2,s11,s2
    8020756c:	1d82                	slli	s11,s11,0x20
    8020756e:	020ddd93          	srli	s11,s11,0x20
    80207572:	9aee                	add	s5,s5,s11
    80207574:	0789fb63          	bgeu	s3,s8,802075ea <writei+0xfa>
        uint32 addr = bmap(ip, off / BSIZE);
    80207578:	00a9559b          	srliw	a1,s2,0xa
    8020757c:	855e                	mv	a0,s7
    8020757e:	fffff097          	auipc	ra,0xfffff
    80207582:	650080e7          	jalr	1616(ra) # 80206bce <bmap>
    80207586:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;                     /* disk full: partial write */
    8020758a:	c1a5                	beqz	a1,802075ea <writei+0xfa>
        struct buf *bp = bread(ip->dev, addr);
    8020758c:	000ba503          	lw	a0,0(s7)
    80207590:	fffff097          	auipc	ra,0xfffff
    80207594:	2c2080e7          	jalr	706(ra) # 80206852 <bread>
    80207598:	84aa                	mv	s1,a0
        m = BSIZE - off % BSIZE;
    8020759a:	3ff97b13          	andi	s6,s2,1023
        if (m > n - tot) m = n - tot;
    8020759e:	413c07bb          	subw	a5,s8,s3
        m = BSIZE - off % BSIZE;
    802075a2:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    802075a6:	8a3e                	mv	s4,a5
    802075a8:	2781                	sext.w	a5,a5
    802075aa:	0007069b          	sext.w	a3,a4
    802075ae:	00f6f363          	bgeu	a3,a5,802075b4 <writei+0xc4>
    802075b2:	8a3a                	mv	s4,a4
    802075b4:	000a0d9b          	sext.w	s11,s4
        if (user_src) {
    802075b8:	f80c81e3          	beqz	s9,8020753a <writei+0x4a>
            if (copyin(myproc()->pagetable,
    802075bc:	ffffa097          	auipc	ra,0xffffa
    802075c0:	334080e7          	jalr	820(ra) # 802018f0 <myproc>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
    802075c4:	05848593          	addi	a1,s1,88
            if (copyin(myproc()->pagetable,
    802075c8:	020a1693          	slli	a3,s4,0x20
    802075cc:	9281                	srli	a3,a3,0x20
    802075ce:	8656                	mv	a2,s5
    802075d0:	95da                	add	a1,a1,s6
    802075d2:	6928                	ld	a0,80(a0)
    802075d4:	ffffc097          	auipc	ra,0xffffc
    802075d8:	fac080e7          	jalr	-84(ra) # 80203580 <copyin>
    802075dc:	f6055ae3          	bgez	a0,80207550 <writei+0x60>
                brelse(bp);
    802075e0:	8526                	mv	a0,s1
    802075e2:	fffff097          	auipc	ra,0xfffff
    802075e6:	3a0080e7          	jalr	928(ra) # 80206982 <brelse>
    }
    if (off > ip->size) ip->size = off;
    802075ea:	04cba783          	lw	a5,76(s7)
    802075ee:	0327fc63          	bgeu	a5,s2,80207626 <writei+0x136>
    802075f2:	052ba623          	sw	s2,76(s7)
    802075f6:	64e6                	ld	s1,88(sp)
    802075f8:	6a06                	ld	s4,64(sp)
    802075fa:	7b42                	ld	s6,48(sp)
    802075fc:	6d42                	ld	s10,16(sp)
    802075fe:	6da2                	ld	s11,8(sp)
    iupdate(ip);                    /* size and any new addrs[] hit the disk */
    80207600:	855e                	mv	a0,s7
    80207602:	00000097          	auipc	ra,0x0
    80207606:	9c0080e7          	jalr	-1600(ra) # 80206fc2 <iupdate>
    return tot;
    8020760a:	0009851b          	sext.w	a0,s3
    8020760e:	69a6                	ld	s3,72(sp)
}
    80207610:	70a6                	ld	ra,104(sp)
    80207612:	7406                	ld	s0,96(sp)
    80207614:	6946                	ld	s2,80(sp)
    80207616:	7ae2                	ld	s5,56(sp)
    80207618:	7ba2                	ld	s7,40(sp)
    8020761a:	7c02                	ld	s8,32(sp)
    8020761c:	6ce2                	ld	s9,24(sp)
    8020761e:	6165                	addi	sp,sp,112
    80207620:	8082                	ret
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80207622:	89e2                	mv	s3,s8
    80207624:	bff1                	j	80207600 <writei+0x110>
    80207626:	64e6                	ld	s1,88(sp)
    80207628:	6a06                	ld	s4,64(sp)
    8020762a:	7b42                	ld	s6,48(sp)
    8020762c:	6d42                	ld	s10,16(sp)
    8020762e:	6da2                	ld	s11,8(sp)
    80207630:	bfc1                	j	80207600 <writei+0x110>
    if (off > ip->size || off + n < off) return -1;
    80207632:	557d                	li	a0,-1
}
    80207634:	8082                	ret
    if (off > ip->size || off + n < off) return -1;
    80207636:	557d                	li	a0,-1
    80207638:	bfe1                	j	80207610 <writei+0x120>
    if (off + n > MAXFILE * BSIZE) return -1;
    8020763a:	557d                	li	a0,-1
    8020763c:	bfd1                	j	80207610 <writei+0x120>

000000008020763e <namecmp>:

/* ---------- directories ---------- */

int namecmp(const char *s, const char *t) { return strncmp(s, t, DIRSIZ); }
    8020763e:	1141                	addi	sp,sp,-16
    80207640:	e406                	sd	ra,8(sp)
    80207642:	e022                	sd	s0,0(sp)
    80207644:	0800                	addi	s0,sp,16
    80207646:	4671                	li	a2,28
    80207648:	ffff9097          	auipc	ra,0xffff9
    8020764c:	100080e7          	jalr	256(ra) # 80200748 <strncmp>
    80207650:	60a2                	ld	ra,8(sp)
    80207652:	6402                	ld	s0,0(sp)
    80207654:	0141                	addi	sp,sp,16
    80207656:	8082                	ret

0000000080207658 <dirlookup>:

/* Look up name in directory dp. Returns unlocked inode; *poff = entry offset. */
struct inode *dirlookup(struct inode *dp, char *name, uint32 *poff)
{
    80207658:	715d                	addi	sp,sp,-80
    8020765a:	e486                	sd	ra,72(sp)
    8020765c:	e0a2                	sd	s0,64(sp)
    8020765e:	fc26                	sd	s1,56(sp)
    80207660:	f84a                	sd	s2,48(sp)
    80207662:	f44e                	sd	s3,40(sp)
    80207664:	f052                	sd	s4,32(sp)
    80207666:	0880                	addi	s0,sp,80
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    80207668:	04455703          	lhu	a4,68(a0)
    8020766c:	4785                	li	a5,1
    8020766e:	00f71a63          	bne	a4,a5,80207682 <dirlookup+0x2a>
    80207672:	892a                	mv	s2,a0
    80207674:	89ae                	mv	s3,a1
    80207676:	8a32                	mv	s4,a2

    struct dirent de;
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80207678:	457c                	lw	a5,76(a0)
    8020767a:	4481                	li	s1,0
        if (namecmp(name, de.name) == 0) {
            if (poff) *poff = off;
            return iget(dp->dev, de.inum);
        }
    }
    return 0;
    8020767c:	4501                	li	a0,0
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    8020767e:	eb85                	bnez	a5,802076ae <dirlookup+0x56>
    80207680:	a8bd                	j	802076fe <dirlookup+0xa6>
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    80207682:	00002517          	auipc	a0,0x2
    80207686:	71650513          	addi	a0,a0,1814 # 80209d98 <etext+0xd98>
    8020768a:	ffff9097          	auipc	ra,0xffff9
    8020768e:	f8c080e7          	jalr	-116(ra) # 80200616 <panic>
            panic("dirlookup: short directory read");
    80207692:	00002517          	auipc	a0,0x2
    80207696:	72650513          	addi	a0,a0,1830 # 80209db8 <etext+0xdb8>
    8020769a:	ffff9097          	auipc	ra,0xffff9
    8020769e:	f7c080e7          	jalr	-132(ra) # 80200616 <panic>
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    802076a2:	0204849b          	addiw	s1,s1,32
    802076a6:	04c92783          	lw	a5,76(s2)
    802076aa:	04f4f963          	bgeu	s1,a5,802076fc <dirlookup+0xa4>
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    802076ae:	02000713          	li	a4,32
    802076b2:	86a6                	mv	a3,s1
    802076b4:	fb040613          	addi	a2,s0,-80
    802076b8:	4581                	li	a1,0
    802076ba:	854a                	mv	a0,s2
    802076bc:	00000097          	auipc	ra,0x0
    802076c0:	d00080e7          	jalr	-768(ra) # 802073bc <readi>
    802076c4:	02000793          	li	a5,32
    802076c8:	fcf515e3          	bne	a0,a5,80207692 <dirlookup+0x3a>
        if (de.inum == 0) continue;
    802076cc:	fb042783          	lw	a5,-80(s0)
    802076d0:	dbe9                	beqz	a5,802076a2 <dirlookup+0x4a>
        if (namecmp(name, de.name) == 0) {
    802076d2:	fb440593          	addi	a1,s0,-76
    802076d6:	854e                	mv	a0,s3
    802076d8:	00000097          	auipc	ra,0x0
    802076dc:	f66080e7          	jalr	-154(ra) # 8020763e <namecmp>
    802076e0:	f169                	bnez	a0,802076a2 <dirlookup+0x4a>
            if (poff) *poff = off;
    802076e2:	000a0463          	beqz	s4,802076ea <dirlookup+0x92>
    802076e6:	009a2023          	sw	s1,0(s4) # 2000 <_entry-0x801fe000>
            return iget(dp->dev, de.inum);
    802076ea:	fb042583          	lw	a1,-80(s0)
    802076ee:	00092503          	lw	a0,0(s2)
    802076f2:	fffff097          	auipc	ra,0xfffff
    802076f6:	5cc080e7          	jalr	1484(ra) # 80206cbe <iget>
    802076fa:	a011                	j	802076fe <dirlookup+0xa6>
    return 0;
    802076fc:	4501                	li	a0,0
}
    802076fe:	60a6                	ld	ra,72(sp)
    80207700:	6406                	ld	s0,64(sp)
    80207702:	74e2                	ld	s1,56(sp)
    80207704:	7942                	ld	s2,48(sp)
    80207706:	79a2                	ld	s3,40(sp)
    80207708:	7a02                	ld	s4,32(sp)
    8020770a:	6161                	addi	sp,sp,80
    8020770c:	8082                	ret

000000008020770e <namex>:
}

/* Walk path from / (or the cwd). If parent, stop one level early and copy the
 * final element into name. The RETURNED inode is unlocked and referenced. */
static struct inode *namex(char *path, int nameiparent_, char *name)
{
    8020770e:	711d                	addi	sp,sp,-96
    80207710:	ec86                	sd	ra,88(sp)
    80207712:	e8a2                	sd	s0,80(sp)
    80207714:	e4a6                	sd	s1,72(sp)
    80207716:	e0ca                	sd	s2,64(sp)
    80207718:	fc4e                	sd	s3,56(sp)
    8020771a:	f852                	sd	s4,48(sp)
    8020771c:	f456                	sd	s5,40(sp)
    8020771e:	f05a                	sd	s6,32(sp)
    80207720:	ec5e                	sd	s7,24(sp)
    80207722:	e862                	sd	s8,16(sp)
    80207724:	e466                	sd	s9,8(sp)
    80207726:	1080                	addi	s0,sp,96
    80207728:	84aa                	mv	s1,a0
    8020772a:	8b2e                	mv	s6,a1
    8020772c:	8ab2                	mv	s5,a2
    struct inode *ip;
    if (*path == '/')
    8020772e:	00054703          	lbu	a4,0(a0)
    80207732:	02f00793          	li	a5,47
    80207736:	02f70263          	beq	a4,a5,8020775a <namex+0x4c>
        ip = iget(ROOTDEV, ROOTINO);
    else
        ip = idup(myproc()->cwd);
    8020773a:	ffffa097          	auipc	ra,0xffffa
    8020773e:	1b6080e7          	jalr	438(ra) # 802018f0 <myproc>
    80207742:	15053503          	ld	a0,336(a0)
    80207746:	00000097          	auipc	ra,0x0
    8020774a:	90a080e7          	jalr	-1782(ra) # 80207050 <idup>
    8020774e:	8a2a                	mv	s4,a0
    while (*path == '/') path++;
    80207750:	02f00913          	li	s2,47
    if (len >= DIRSIZ) {
    80207754:	4c6d                	li	s8,27

    while ((path = skipelem(path, name)) != 0) {
        ilock(ip);
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80207756:	4b85                	li	s7,1
    80207758:	a865                	j	80207810 <namex+0x102>
        ip = iget(ROOTDEV, ROOTINO);
    8020775a:	4585                	li	a1,1
    8020775c:	4501                	li	a0,0
    8020775e:	fffff097          	auipc	ra,0xfffff
    80207762:	560080e7          	jalr	1376(ra) # 80206cbe <iget>
    80207766:	8a2a                	mv	s4,a0
    80207768:	b7e5                	j	80207750 <namex+0x42>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    8020776a:	8552                	mv	a0,s4
    8020776c:	00000097          	auipc	ra,0x0
    80207770:	bfe080e7          	jalr	-1026(ra) # 8020736a <iunlockput>
    80207774:	4a01                	li	s4,0
        iunlockput(ip);
        ip = next;
    }
    if (nameiparent_) { iput(ip); return 0; }
    return ip;
}
    80207776:	8552                	mv	a0,s4
    80207778:	60e6                	ld	ra,88(sp)
    8020777a:	6446                	ld	s0,80(sp)
    8020777c:	64a6                	ld	s1,72(sp)
    8020777e:	6906                	ld	s2,64(sp)
    80207780:	79e2                	ld	s3,56(sp)
    80207782:	7a42                	ld	s4,48(sp)
    80207784:	7aa2                	ld	s5,40(sp)
    80207786:	7b02                	ld	s6,32(sp)
    80207788:	6be2                	ld	s7,24(sp)
    8020778a:	6c42                	ld	s8,16(sp)
    8020778c:	6ca2                	ld	s9,8(sp)
    8020778e:	6125                	addi	sp,sp,96
    80207790:	8082                	ret
            iunlock(ip);                          /* stop at the parent */
    80207792:	8552                	mv	a0,s4
    80207794:	00000097          	auipc	ra,0x0
    80207798:	9c0080e7          	jalr	-1600(ra) # 80207154 <iunlock>
            return ip;
    8020779c:	bfe9                	j	80207776 <namex+0x68>
        if (next == 0) { iunlockput(ip); return 0; }
    8020779e:	8552                	mv	a0,s4
    802077a0:	00000097          	auipc	ra,0x0
    802077a4:	bca080e7          	jalr	-1078(ra) # 8020736a <iunlockput>
    802077a8:	8a4e                	mv	s4,s3
    802077aa:	b7f1                	j	80207776 <namex+0x68>
    int len = path - s;
    802077ac:	40998cbb          	subw	s9,s3,s1
    if (len >= DIRSIZ) {
    802077b0:	099c5763          	bge	s8,s9,8020783e <namex+0x130>
        memmove(name, s, DIRSIZ);                 /* truncate long names */
    802077b4:	4671                	li	a2,28
    802077b6:	85a6                	mv	a1,s1
    802077b8:	8556                	mv	a0,s5
    802077ba:	ffff9097          	auipc	ra,0xffff9
    802077be:	f1e080e7          	jalr	-226(ra) # 802006d8 <memmove>
    802077c2:	84ce                	mv	s1,s3
    while (*path == '/') path++;
    802077c4:	0004c783          	lbu	a5,0(s1)
    802077c8:	01279763          	bne	a5,s2,802077d6 <namex+0xc8>
    802077cc:	0485                	addi	s1,s1,1
    802077ce:	0004c783          	lbu	a5,0(s1)
    802077d2:	ff278de3          	beq	a5,s2,802077cc <namex+0xbe>
        ilock(ip);
    802077d6:	8552                	mv	a0,s4
    802077d8:	00000097          	auipc	ra,0x0
    802077dc:	8b6080e7          	jalr	-1866(ra) # 8020708e <ilock>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    802077e0:	044a5783          	lhu	a5,68(s4)
    802077e4:	f97793e3          	bne	a5,s7,8020776a <namex+0x5c>
        if (nameiparent_ && *path == '\0') {
    802077e8:	000b0563          	beqz	s6,802077f2 <namex+0xe4>
    802077ec:	0004c783          	lbu	a5,0(s1)
    802077f0:	d3cd                	beqz	a5,80207792 <namex+0x84>
        struct inode *next = dirlookup(ip, name, 0);
    802077f2:	4601                	li	a2,0
    802077f4:	85d6                	mv	a1,s5
    802077f6:	8552                	mv	a0,s4
    802077f8:	00000097          	auipc	ra,0x0
    802077fc:	e60080e7          	jalr	-416(ra) # 80207658 <dirlookup>
    80207800:	89aa                	mv	s3,a0
        if (next == 0) { iunlockput(ip); return 0; }
    80207802:	dd51                	beqz	a0,8020779e <namex+0x90>
        iunlockput(ip);
    80207804:	8552                	mv	a0,s4
    80207806:	00000097          	auipc	ra,0x0
    8020780a:	b64080e7          	jalr	-1180(ra) # 8020736a <iunlockput>
        ip = next;
    8020780e:	8a4e                	mv	s4,s3
    while (*path == '/') path++;
    80207810:	0004c783          	lbu	a5,0(s1)
    80207814:	01279763          	bne	a5,s2,80207822 <namex+0x114>
    80207818:	0485                	addi	s1,s1,1
    8020781a:	0004c783          	lbu	a5,0(s1)
    8020781e:	ff278de3          	beq	a5,s2,80207818 <namex+0x10a>
    if (*path == 0) return 0;
    80207822:	cb95                	beqz	a5,80207856 <namex+0x148>
    while (*path != '/' && *path != 0) path++;
    80207824:	0004c783          	lbu	a5,0(s1)
    80207828:	89a6                	mv	s3,s1
    int len = path - s;
    8020782a:	4c81                	li	s9,0
    while (*path != '/' && *path != 0) path++;
    8020782c:	01278963          	beq	a5,s2,8020783e <namex+0x130>
    80207830:	dfb5                	beqz	a5,802077ac <namex+0x9e>
    80207832:	0985                	addi	s3,s3,1
    80207834:	0009c783          	lbu	a5,0(s3)
    80207838:	ff279ce3          	bne	a5,s2,80207830 <namex+0x122>
    8020783c:	bf85                	j	802077ac <namex+0x9e>
        memmove(name, s, len);
    8020783e:	8666                	mv	a2,s9
    80207840:	85a6                	mv	a1,s1
    80207842:	8556                	mv	a0,s5
    80207844:	ffff9097          	auipc	ra,0xffff9
    80207848:	e94080e7          	jalr	-364(ra) # 802006d8 <memmove>
        name[len] = 0;
    8020784c:	9cd6                	add	s9,s9,s5
    8020784e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x801fe000>
    80207852:	84ce                	mv	s1,s3
    80207854:	bf85                	j	802077c4 <namex+0xb6>
    if (nameiparent_) { iput(ip); return 0; }
    80207856:	f20b00e3          	beqz	s6,80207776 <namex+0x68>
    8020785a:	8552                	mv	a0,s4
    8020785c:	00000097          	auipc	ra,0x0
    80207860:	9f0080e7          	jalr	-1552(ra) # 8020724c <iput>
    80207864:	4a01                	li	s4,0
    80207866:	bf01                	j	80207776 <namex+0x68>

0000000080207868 <dirlink>:
{
    80207868:	715d                	addi	sp,sp,-80
    8020786a:	e486                	sd	ra,72(sp)
    8020786c:	e0a2                	sd	s0,64(sp)
    8020786e:	f84a                	sd	s2,48(sp)
    80207870:	f44e                	sd	s3,40(sp)
    80207872:	f052                	sd	s4,32(sp)
    80207874:	0880                	addi	s0,sp,80
    80207876:	892a                	mv	s2,a0
    80207878:	8a2e                	mv	s4,a1
    8020787a:	89b2                	mv	s3,a2
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    8020787c:	4601                	li	a2,0
    8020787e:	00000097          	auipc	ra,0x0
    80207882:	dda080e7          	jalr	-550(ra) # 80207658 <dirlookup>
    80207886:	e141                	bnez	a0,80207906 <dirlink+0x9e>
    80207888:	fc26                	sd	s1,56(sp)
    for (off = 0; off < dp->size; off += sizeof(de)) {
    8020788a:	04c92483          	lw	s1,76(s2)
    8020788e:	c895                	beqz	s1,802078c2 <dirlink+0x5a>
    80207890:	4481                	li	s1,0
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80207892:	02000713          	li	a4,32
    80207896:	86a6                	mv	a3,s1
    80207898:	fb040613          	addi	a2,s0,-80
    8020789c:	4581                	li	a1,0
    8020789e:	854a                	mv	a0,s2
    802078a0:	00000097          	auipc	ra,0x0
    802078a4:	b1c080e7          	jalr	-1252(ra) # 802073bc <readi>
    802078a8:	02000793          	li	a5,32
    802078ac:	06f51363          	bne	a0,a5,80207912 <dirlink+0xaa>
        if (de.inum == 0) break;                  /* reuse a freed slot */
    802078b0:	fb042783          	lw	a5,-80(s0)
    802078b4:	c799                	beqz	a5,802078c2 <dirlink+0x5a>
    for (off = 0; off < dp->size; off += sizeof(de)) {
    802078b6:	0204849b          	addiw	s1,s1,32
    802078ba:	04c92783          	lw	a5,76(s2)
    802078be:	fcf4eae3          	bltu	s1,a5,80207892 <dirlink+0x2a>
    strncpy(de.name, name, DIRSIZ);
    802078c2:	4671                	li	a2,28
    802078c4:	85d2                	mv	a1,s4
    802078c6:	fb440513          	addi	a0,s0,-76
    802078ca:	ffff9097          	auipc	ra,0xffff9
    802078ce:	eb4080e7          	jalr	-332(ra) # 8020077e <strncpy>
    de.inum = inum;
    802078d2:	fb342823          	sw	s3,-80(s0)
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    802078d6:	02000713          	li	a4,32
    802078da:	86a6                	mv	a3,s1
    802078dc:	fb040613          	addi	a2,s0,-80
    802078e0:	4581                	li	a1,0
    802078e2:	854a                	mv	a0,s2
    802078e4:	00000097          	auipc	ra,0x0
    802078e8:	c0c080e7          	jalr	-1012(ra) # 802074f0 <writei>
    802078ec:	1501                	addi	a0,a0,-32
    802078ee:	00a03533          	snez	a0,a0
    802078f2:	40a00533          	neg	a0,a0
    802078f6:	74e2                	ld	s1,56(sp)
}
    802078f8:	60a6                	ld	ra,72(sp)
    802078fa:	6406                	ld	s0,64(sp)
    802078fc:	7942                	ld	s2,48(sp)
    802078fe:	79a2                	ld	s3,40(sp)
    80207900:	7a02                	ld	s4,32(sp)
    80207902:	6161                	addi	sp,sp,80
    80207904:	8082                	ret
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    80207906:	00000097          	auipc	ra,0x0
    8020790a:	946080e7          	jalr	-1722(ra) # 8020724c <iput>
    8020790e:	557d                	li	a0,-1
    80207910:	b7e5                	j	802078f8 <dirlink+0x90>
            panic("dirlink: short directory read");
    80207912:	00002517          	auipc	a0,0x2
    80207916:	4c650513          	addi	a0,a0,1222 # 80209dd8 <etext+0xdd8>
    8020791a:	ffff9097          	auipc	ra,0xffff9
    8020791e:	cfc080e7          	jalr	-772(ra) # 80200616 <panic>

0000000080207922 <namei>:

struct inode *namei(char *path)
{
    80207922:	7179                	addi	sp,sp,-48
    80207924:	f406                	sd	ra,40(sp)
    80207926:	f022                	sd	s0,32(sp)
    80207928:	1800                	addi	s0,sp,48
    char name[DIRSIZ];
    return namex(path, 0, name);
    8020792a:	fd040613          	addi	a2,s0,-48
    8020792e:	4581                	li	a1,0
    80207930:	00000097          	auipc	ra,0x0
    80207934:	dde080e7          	jalr	-546(ra) # 8020770e <namex>
}
    80207938:	70a2                	ld	ra,40(sp)
    8020793a:	7402                	ld	s0,32(sp)
    8020793c:	6145                	addi	sp,sp,48
    8020793e:	8082                	ret

0000000080207940 <nameiparent>:

struct inode *nameiparent(char *path, char *name)
{
    80207940:	1141                	addi	sp,sp,-16
    80207942:	e406                	sd	ra,8(sp)
    80207944:	e022                	sd	s0,0(sp)
    80207946:	0800                	addi	s0,sp,16
    80207948:	862e                	mv	a2,a1
    return namex(path, 1, name);
    8020794a:	4585                	li	a1,1
    8020794c:	00000097          	auipc	ra,0x0
    80207950:	dc2080e7          	jalr	-574(ra) # 8020770e <namex>
}
    80207954:	60a2                	ld	ra,8(sp)
    80207956:	6402                	ld	s0,0(sp)
    80207958:	0141                	addi	sp,sp,16
    8020795a:	8082                	ret

000000008020795c <fileinit>:
static struct {
    struct spinlock lock;
    struct file file[NFILE];
} ftable;

void fileinit(void) { initlock(&ftable.lock, "ftable"); }
    8020795c:	1141                	addi	sp,sp,-16
    8020795e:	e406                	sd	ra,8(sp)
    80207960:	e022                	sd	s0,0(sp)
    80207962:	0800                	addi	s0,sp,16
    80207964:	00002597          	auipc	a1,0x2
    80207968:	49458593          	addi	a1,a1,1172 # 80209df8 <etext+0xdf8>
    8020796c:	0014e517          	auipc	a0,0x14e
    80207970:	e7450513          	addi	a0,a0,-396 # 803557e0 <ftable>
    80207974:	ffffa097          	auipc	ra,0xffffa
    80207978:	a98080e7          	jalr	-1384(ra) # 8020140c <initlock>
    8020797c:	60a2                	ld	ra,8(sp)
    8020797e:	6402                	ld	s0,0(sp)
    80207980:	0141                	addi	sp,sp,16
    80207982:	8082                	ret

0000000080207984 <filealloc>:

struct file *filealloc(void)
{
    80207984:	1101                	addi	sp,sp,-32
    80207986:	ec06                	sd	ra,24(sp)
    80207988:	e822                	sd	s0,16(sp)
    8020798a:	e426                	sd	s1,8(sp)
    8020798c:	1000                	addi	s0,sp,32
    acquire(&ftable.lock);
    8020798e:	0014e517          	auipc	a0,0x14e
    80207992:	e5250513          	addi	a0,a0,-430 # 803557e0 <ftable>
    80207996:	ffffa097          	auipc	ra,0xffffa
    8020799a:	af2080e7          	jalr	-1294(ra) # 80201488 <acquire>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    8020799e:	0014e497          	auipc	s1,0x14e
    802079a2:	e5a48493          	addi	s1,s1,-422 # 803557f8 <ftable+0x18>
    802079a6:	0014f717          	auipc	a4,0x14f
    802079aa:	df270713          	addi	a4,a4,-526 # 80356798 <ftable+0xfb8>
        if (f->ref == 0) {
    802079ae:	40dc                	lw	a5,4(s1)
    802079b0:	cf99                	beqz	a5,802079ce <filealloc+0x4a>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    802079b2:	02848493          	addi	s1,s1,40
    802079b6:	fee49ce3          	bne	s1,a4,802079ae <filealloc+0x2a>
            f->ref = 1;
            release(&ftable.lock);
            return f;
        }
    }
    release(&ftable.lock);
    802079ba:	0014e517          	auipc	a0,0x14e
    802079be:	e2650513          	addi	a0,a0,-474 # 803557e0 <ftable>
    802079c2:	ffffa097          	auipc	ra,0xffffa
    802079c6:	b7a080e7          	jalr	-1158(ra) # 8020153c <release>
    return 0;
    802079ca:	4481                	li	s1,0
    802079cc:	a819                	j	802079e2 <filealloc+0x5e>
            f->ref = 1;
    802079ce:	4785                	li	a5,1
    802079d0:	c0dc                	sw	a5,4(s1)
            release(&ftable.lock);
    802079d2:	0014e517          	auipc	a0,0x14e
    802079d6:	e0e50513          	addi	a0,a0,-498 # 803557e0 <ftable>
    802079da:	ffffa097          	auipc	ra,0xffffa
    802079de:	b62080e7          	jalr	-1182(ra) # 8020153c <release>
}
    802079e2:	8526                	mv	a0,s1
    802079e4:	60e2                	ld	ra,24(sp)
    802079e6:	6442                	ld	s0,16(sp)
    802079e8:	64a2                	ld	s1,8(sp)
    802079ea:	6105                	addi	sp,sp,32
    802079ec:	8082                	ret

00000000802079ee <filedup>:

struct file *filedup(struct file *f)
{
    802079ee:	1101                	addi	sp,sp,-32
    802079f0:	ec06                	sd	ra,24(sp)
    802079f2:	e822                	sd	s0,16(sp)
    802079f4:	e426                	sd	s1,8(sp)
    802079f6:	1000                	addi	s0,sp,32
    802079f8:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    802079fa:	0014e517          	auipc	a0,0x14e
    802079fe:	de650513          	addi	a0,a0,-538 # 803557e0 <ftable>
    80207a02:	ffffa097          	auipc	ra,0xffffa
    80207a06:	a86080e7          	jalr	-1402(ra) # 80201488 <acquire>
    if (f->ref < 1) panic("filedup");
    80207a0a:	40dc                	lw	a5,4(s1)
    80207a0c:	02f05263          	blez	a5,80207a30 <filedup+0x42>
    f->ref++;
    80207a10:	2785                	addiw	a5,a5,1
    80207a12:	c0dc                	sw	a5,4(s1)
    release(&ftable.lock);
    80207a14:	0014e517          	auipc	a0,0x14e
    80207a18:	dcc50513          	addi	a0,a0,-564 # 803557e0 <ftable>
    80207a1c:	ffffa097          	auipc	ra,0xffffa
    80207a20:	b20080e7          	jalr	-1248(ra) # 8020153c <release>
    return f;
}
    80207a24:	8526                	mv	a0,s1
    80207a26:	60e2                	ld	ra,24(sp)
    80207a28:	6442                	ld	s0,16(sp)
    80207a2a:	64a2                	ld	s1,8(sp)
    80207a2c:	6105                	addi	sp,sp,32
    80207a2e:	8082                	ret
    if (f->ref < 1) panic("filedup");
    80207a30:	00002517          	auipc	a0,0x2
    80207a34:	3d050513          	addi	a0,a0,976 # 80209e00 <etext+0xe00>
    80207a38:	ffff9097          	auipc	ra,0xffff9
    80207a3c:	bde080e7          	jalr	-1058(ra) # 80200616 <panic>

0000000080207a40 <fileclose>:

void fileclose(struct file *f)
{
    80207a40:	7139                	addi	sp,sp,-64
    80207a42:	fc06                	sd	ra,56(sp)
    80207a44:	f822                	sd	s0,48(sp)
    80207a46:	f426                	sd	s1,40(sp)
    80207a48:	0080                	addi	s0,sp,64
    80207a4a:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    80207a4c:	0014e517          	auipc	a0,0x14e
    80207a50:	d9450513          	addi	a0,a0,-620 # 803557e0 <ftable>
    80207a54:	ffffa097          	auipc	ra,0xffffa
    80207a58:	a34080e7          	jalr	-1484(ra) # 80201488 <acquire>
    if (f->ref < 1) panic("fileclose");
    80207a5c:	40dc                	lw	a5,4(s1)
    80207a5e:	04f05c63          	blez	a5,80207ab6 <fileclose+0x76>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80207a62:	37fd                	addiw	a5,a5,-1
    80207a64:	0007871b          	sext.w	a4,a5
    80207a68:	c0dc                	sw	a5,4(s1)
    80207a6a:	06e04263          	bgtz	a4,80207ace <fileclose+0x8e>
    80207a6e:	f04a                	sd	s2,32(sp)
    80207a70:	ec4e                	sd	s3,24(sp)
    80207a72:	e852                	sd	s4,16(sp)
    80207a74:	e456                	sd	s5,8(sp)

    struct file ff = *f;                 /* copy, then free the slot */
    80207a76:	0004a903          	lw	s2,0(s1)
    80207a7a:	0094ca83          	lbu	s5,9(s1)
    80207a7e:	0104ba03          	ld	s4,16(s1)
    80207a82:	0184b983          	ld	s3,24(s1)
    f->ref = 0;
    80207a86:	0004a223          	sw	zero,4(s1)
    f->type = FD_NONE;
    80207a8a:	0004a023          	sw	zero,0(s1)
    release(&ftable.lock);
    80207a8e:	0014e517          	auipc	a0,0x14e
    80207a92:	d5250513          	addi	a0,a0,-686 # 803557e0 <ftable>
    80207a96:	ffffa097          	auipc	ra,0xffffa
    80207a9a:	aa6080e7          	jalr	-1370(ra) # 8020153c <release>

    if (ff.type == FD_PIPE)
    80207a9e:	4785                	li	a5,1
    80207aa0:	04f90463          	beq	s2,a5,80207ae8 <fileclose+0xa8>
        pipeclose(ff.pipe, ff.writable);
    else if (ff.type == FD_INODE || ff.type == FD_DEVICE)
    80207aa4:	3979                	addiw	s2,s2,-2
    80207aa6:	4785                	li	a5,1
    80207aa8:	0527fb63          	bgeu	a5,s2,80207afe <fileclose+0xbe>
    80207aac:	7902                	ld	s2,32(sp)
    80207aae:	69e2                	ld	s3,24(sp)
    80207ab0:	6a42                	ld	s4,16(sp)
    80207ab2:	6aa2                	ld	s5,8(sp)
    80207ab4:	a02d                	j	80207ade <fileclose+0x9e>
    80207ab6:	f04a                	sd	s2,32(sp)
    80207ab8:	ec4e                	sd	s3,24(sp)
    80207aba:	e852                	sd	s4,16(sp)
    80207abc:	e456                	sd	s5,8(sp)
    if (f->ref < 1) panic("fileclose");
    80207abe:	00002517          	auipc	a0,0x2
    80207ac2:	34a50513          	addi	a0,a0,842 # 80209e08 <etext+0xe08>
    80207ac6:	ffff9097          	auipc	ra,0xffff9
    80207aca:	b50080e7          	jalr	-1200(ra) # 80200616 <panic>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80207ace:	0014e517          	auipc	a0,0x14e
    80207ad2:	d1250513          	addi	a0,a0,-750 # 803557e0 <ftable>
    80207ad6:	ffffa097          	auipc	ra,0xffffa
    80207ada:	a66080e7          	jalr	-1434(ra) # 8020153c <release>
        iput(ff.ip);
}
    80207ade:	70e2                	ld	ra,56(sp)
    80207ae0:	7442                	ld	s0,48(sp)
    80207ae2:	74a2                	ld	s1,40(sp)
    80207ae4:	6121                	addi	sp,sp,64
    80207ae6:	8082                	ret
        pipeclose(ff.pipe, ff.writable);
    80207ae8:	85d6                	mv	a1,s5
    80207aea:	8552                	mv	a0,s4
    80207aec:	00000097          	auipc	ra,0x0
    80207af0:	324080e7          	jalr	804(ra) # 80207e10 <pipeclose>
    80207af4:	7902                	ld	s2,32(sp)
    80207af6:	69e2                	ld	s3,24(sp)
    80207af8:	6a42                	ld	s4,16(sp)
    80207afa:	6aa2                	ld	s5,8(sp)
    80207afc:	b7cd                	j	80207ade <fileclose+0x9e>
        iput(ff.ip);
    80207afe:	854e                	mv	a0,s3
    80207b00:	fffff097          	auipc	ra,0xfffff
    80207b04:	74c080e7          	jalr	1868(ra) # 8020724c <iput>
    80207b08:	7902                	ld	s2,32(sp)
    80207b0a:	69e2                	ld	s3,24(sp)
    80207b0c:	6a42                	ld	s4,16(sp)
    80207b0e:	6aa2                	ld	s5,8(sp)
    80207b10:	b7f9                	j	80207ade <fileclose+0x9e>

0000000080207b12 <filestat>:

int filestat(struct file *f, uint64 uaddr)
{
    if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80207b12:	411c                	lw	a5,0(a0)
    80207b14:	37f9                	addiw	a5,a5,-2
    80207b16:	4705                	li	a4,1
    80207b18:	06f76063          	bltu	a4,a5,80207b78 <filestat+0x66>
{
    80207b1c:	7139                	addi	sp,sp,-64
    80207b1e:	fc06                	sd	ra,56(sp)
    80207b20:	f822                	sd	s0,48(sp)
    80207b22:	f426                	sd	s1,40(sp)
    80207b24:	f04a                	sd	s2,32(sp)
    80207b26:	0080                	addi	s0,sp,64
    80207b28:	84aa                	mv	s1,a0
    80207b2a:	892e                	mv	s2,a1
        struct stat st;
        ilock(f->ip);
    80207b2c:	6d08                	ld	a0,24(a0)
    80207b2e:	fffff097          	auipc	ra,0xfffff
    80207b32:	560080e7          	jalr	1376(ra) # 8020708e <ilock>
        stati(f->ip, &st);
    80207b36:	fc840593          	addi	a1,s0,-56
    80207b3a:	6c88                	ld	a0,24(s1)
    80207b3c:	00000097          	auipc	ra,0x0
    80207b40:	856080e7          	jalr	-1962(ra) # 80207392 <stati>
        iunlock(f->ip);
    80207b44:	6c88                	ld	a0,24(s1)
    80207b46:	fffff097          	auipc	ra,0xfffff
    80207b4a:	60e080e7          	jalr	1550(ra) # 80207154 <iunlock>
        if (copyout(myproc()->pagetable, uaddr, (char *)&st, sizeof(st)) < 0)
    80207b4e:	ffffa097          	auipc	ra,0xffffa
    80207b52:	da2080e7          	jalr	-606(ra) # 802018f0 <myproc>
    80207b56:	46e1                	li	a3,24
    80207b58:	fc840613          	addi	a2,s0,-56
    80207b5c:	85ca                	mv	a1,s2
    80207b5e:	6928                	ld	a0,80(a0)
    80207b60:	ffffc097          	auipc	ra,0xffffc
    80207b64:	8fa080e7          	jalr	-1798(ra) # 8020345a <copyout>
    80207b68:	41f5551b          	sraiw	a0,a0,0x1f
            return -1;
        return 0;
    }
    return -1;
}
    80207b6c:	70e2                	ld	ra,56(sp)
    80207b6e:	7442                	ld	s0,48(sp)
    80207b70:	74a2                	ld	s1,40(sp)
    80207b72:	7902                	ld	s2,32(sp)
    80207b74:	6121                	addi	sp,sp,64
    80207b76:	8082                	ret
    return -1;
    80207b78:	557d                	li	a0,-1
}
    80207b7a:	8082                	ret

0000000080207b7c <fileread>:

int fileread(struct file *f, uint64 uaddr, int n)
{
    80207b7c:	7179                	addi	sp,sp,-48
    80207b7e:	f406                	sd	ra,40(sp)
    80207b80:	f022                	sd	s0,32(sp)
    80207b82:	e84a                	sd	s2,16(sp)
    80207b84:	1800                	addi	s0,sp,48
    if (f->readable == 0) return -1;
    80207b86:	00854783          	lbu	a5,8(a0)
    80207b8a:	cbcd                	beqz	a5,80207c3c <fileread+0xc0>
    80207b8c:	ec26                	sd	s1,24(sp)
    80207b8e:	e44e                	sd	s3,8(sp)
    80207b90:	84aa                	mv	s1,a0
    80207b92:	89ae                	mv	s3,a1
    80207b94:	8932                	mv	s2,a2

    if (f->type == FD_PIPE)
    80207b96:	411c                	lw	a5,0(a0)
    80207b98:	4705                	li	a4,1
    80207b9a:	04e78963          	beq	a5,a4,80207bec <fileread+0x70>
        return piperead(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80207b9e:	470d                	li	a4,3
    80207ba0:	04e78f63          	beq	a5,a4,80207bfe <fileread+0x82>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
        return devsw[f->major].read(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80207ba4:	4709                	li	a4,2
    80207ba6:	08e79363          	bne	a5,a4,80207c2c <fileread+0xb0>
        ilock(f->ip);
    80207baa:	6d08                	ld	a0,24(a0)
    80207bac:	fffff097          	auipc	ra,0xfffff
    80207bb0:	4e2080e7          	jalr	1250(ra) # 8020708e <ilock>
        int r = readi(f->ip, 1, uaddr, f->off, n);
    80207bb4:	874a                	mv	a4,s2
    80207bb6:	5094                	lw	a3,32(s1)
    80207bb8:	864e                	mv	a2,s3
    80207bba:	4585                	li	a1,1
    80207bbc:	6c88                	ld	a0,24(s1)
    80207bbe:	fffff097          	auipc	ra,0xfffff
    80207bc2:	7fe080e7          	jalr	2046(ra) # 802073bc <readi>
    80207bc6:	892a                	mv	s2,a0
        if (r > 0) f->off += r;          /* offset update under the inode lock */
    80207bc8:	00a05563          	blez	a0,80207bd2 <fileread+0x56>
    80207bcc:	509c                	lw	a5,32(s1)
    80207bce:	9fa9                	addw	a5,a5,a0
    80207bd0:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80207bd2:	6c88                	ld	a0,24(s1)
    80207bd4:	fffff097          	auipc	ra,0xfffff
    80207bd8:	580080e7          	jalr	1408(ra) # 80207154 <iunlock>
        return r;
    80207bdc:	64e2                	ld	s1,24(sp)
    80207bde:	69a2                	ld	s3,8(sp)
    }
    panic("fileread");
}
    80207be0:	854a                	mv	a0,s2
    80207be2:	70a2                	ld	ra,40(sp)
    80207be4:	7402                	ld	s0,32(sp)
    80207be6:	6942                	ld	s2,16(sp)
    80207be8:	6145                	addi	sp,sp,48
    80207bea:	8082                	ret
        return piperead(f->pipe, uaddr, n);
    80207bec:	6908                	ld	a0,16(a0)
    80207bee:	00000097          	auipc	ra,0x0
    80207bf2:	38a080e7          	jalr	906(ra) # 80207f78 <piperead>
    80207bf6:	892a                	mv	s2,a0
    80207bf8:	64e2                	ld	s1,24(sp)
    80207bfa:	69a2                	ld	s3,8(sp)
    80207bfc:	b7d5                	j	80207be0 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80207bfe:	02451783          	lh	a5,36(a0)
    80207c02:	03079693          	slli	a3,a5,0x30
    80207c06:	92c1                	srli	a3,a3,0x30
    80207c08:	4725                	li	a4,9
    80207c0a:	02d76b63          	bltu	a4,a3,80207c40 <fileread+0xc4>
    80207c0e:	0792                	slli	a5,a5,0x4
    80207c10:	0014e717          	auipc	a4,0x14e
    80207c14:	b3070713          	addi	a4,a4,-1232 # 80355740 <devsw>
    80207c18:	97ba                	add	a5,a5,a4
    80207c1a:	639c                	ld	a5,0(a5)
    80207c1c:	c795                	beqz	a5,80207c48 <fileread+0xcc>
        return devsw[f->major].read(uaddr, n);
    80207c1e:	85b2                	mv	a1,a2
    80207c20:	854e                	mv	a0,s3
    80207c22:	9782                	jalr	a5
    80207c24:	892a                	mv	s2,a0
    80207c26:	64e2                	ld	s1,24(sp)
    80207c28:	69a2                	ld	s3,8(sp)
    80207c2a:	bf5d                	j	80207be0 <fileread+0x64>
    panic("fileread");
    80207c2c:	00002517          	auipc	a0,0x2
    80207c30:	1ec50513          	addi	a0,a0,492 # 80209e18 <etext+0xe18>
    80207c34:	ffff9097          	auipc	ra,0xffff9
    80207c38:	9e2080e7          	jalr	-1566(ra) # 80200616 <panic>
    if (f->readable == 0) return -1;
    80207c3c:	597d                	li	s2,-1
    80207c3e:	b74d                	j	80207be0 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80207c40:	597d                	li	s2,-1
    80207c42:	64e2                	ld	s1,24(sp)
    80207c44:	69a2                	ld	s3,8(sp)
    80207c46:	bf69                	j	80207be0 <fileread+0x64>
    80207c48:	597d                	li	s2,-1
    80207c4a:	64e2                	ld	s1,24(sp)
    80207c4c:	69a2                	ld	s3,8(sp)
    80207c4e:	bf49                	j	80207be0 <fileread+0x64>

0000000080207c50 <filewrite>:

int filewrite(struct file *f, uint64 uaddr, int n)
{
    80207c50:	7179                	addi	sp,sp,-48
    80207c52:	f406                	sd	ra,40(sp)
    80207c54:	f022                	sd	s0,32(sp)
    80207c56:	e84a                	sd	s2,16(sp)
    80207c58:	1800                	addi	s0,sp,48
    if (f->writable == 0) return -1;
    80207c5a:	00954783          	lbu	a5,9(a0)
    80207c5e:	cfdd                	beqz	a5,80207d1c <filewrite+0xcc>
    80207c60:	ec26                	sd	s1,24(sp)
    80207c62:	e44e                	sd	s3,8(sp)
    80207c64:	84aa                	mv	s1,a0
    80207c66:	892e                	mv	s2,a1
    80207c68:	89b2                	mv	s3,a2

    if (f->type == FD_PIPE)
    80207c6a:	411c                	lw	a5,0(a0)
    80207c6c:	4705                	li	a4,1
    80207c6e:	04e78c63          	beq	a5,a4,80207cc6 <filewrite+0x76>
        return pipewrite(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80207c72:	470d                	li	a4,3
    80207c74:	06e78263          	beq	a5,a4,80207cd8 <filewrite+0x88>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
        return devsw[f->major].write(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80207c78:	4709                	li	a4,2
    80207c7a:	08e79963          	bne	a5,a4,80207d0c <filewrite+0xbc>
        ilock(f->ip);
    80207c7e:	6d08                	ld	a0,24(a0)
    80207c80:	fffff097          	auipc	ra,0xfffff
    80207c84:	40e080e7          	jalr	1038(ra) # 8020708e <ilock>
        int r = writei(f->ip, 1, uaddr, f->off, n);
    80207c88:	874e                	mv	a4,s3
    80207c8a:	5094                	lw	a3,32(s1)
    80207c8c:	864a                	mv	a2,s2
    80207c8e:	4585                	li	a1,1
    80207c90:	6c88                	ld	a0,24(s1)
    80207c92:	00000097          	auipc	ra,0x0
    80207c96:	85e080e7          	jalr	-1954(ra) # 802074f0 <writei>
    80207c9a:	892a                	mv	s2,a0
        if (r > 0) f->off += r;
    80207c9c:	00a05563          	blez	a0,80207ca6 <filewrite+0x56>
    80207ca0:	509c                	lw	a5,32(s1)
    80207ca2:	9fa9                	addw	a5,a5,a0
    80207ca4:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80207ca6:	6c88                	ld	a0,24(s1)
    80207ca8:	fffff097          	auipc	ra,0xfffff
    80207cac:	4ac080e7          	jalr	1196(ra) # 80207154 <iunlock>
        return (r == n) ? n : -1;        /* short write = disk full = error */
    80207cb0:	05298b63          	beq	s3,s2,80207d06 <filewrite+0xb6>
    80207cb4:	597d                	li	s2,-1
    80207cb6:	64e2                	ld	s1,24(sp)
    80207cb8:	69a2                	ld	s3,8(sp)
    }
    panic("filewrite");
}
    80207cba:	854a                	mv	a0,s2
    80207cbc:	70a2                	ld	ra,40(sp)
    80207cbe:	7402                	ld	s0,32(sp)
    80207cc0:	6942                	ld	s2,16(sp)
    80207cc2:	6145                	addi	sp,sp,48
    80207cc4:	8082                	ret
        return pipewrite(f->pipe, uaddr, n);
    80207cc6:	6908                	ld	a0,16(a0)
    80207cc8:	00000097          	auipc	ra,0x0
    80207ccc:	1b8080e7          	jalr	440(ra) # 80207e80 <pipewrite>
    80207cd0:	892a                	mv	s2,a0
    80207cd2:	64e2                	ld	s1,24(sp)
    80207cd4:	69a2                	ld	s3,8(sp)
    80207cd6:	b7d5                	j	80207cba <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80207cd8:	02451783          	lh	a5,36(a0)
    80207cdc:	03079693          	slli	a3,a5,0x30
    80207ce0:	92c1                	srli	a3,a3,0x30
    80207ce2:	4725                	li	a4,9
    80207ce4:	02d76e63          	bltu	a4,a3,80207d20 <filewrite+0xd0>
    80207ce8:	0792                	slli	a5,a5,0x4
    80207cea:	0014e717          	auipc	a4,0x14e
    80207cee:	a5670713          	addi	a4,a4,-1450 # 80355740 <devsw>
    80207cf2:	97ba                	add	a5,a5,a4
    80207cf4:	679c                	ld	a5,8(a5)
    80207cf6:	cb8d                	beqz	a5,80207d28 <filewrite+0xd8>
        return devsw[f->major].write(uaddr, n);
    80207cf8:	85b2                	mv	a1,a2
    80207cfa:	854a                	mv	a0,s2
    80207cfc:	9782                	jalr	a5
    80207cfe:	892a                	mv	s2,a0
    80207d00:	64e2                	ld	s1,24(sp)
    80207d02:	69a2                	ld	s3,8(sp)
    80207d04:	bf5d                	j	80207cba <filewrite+0x6a>
    80207d06:	64e2                	ld	s1,24(sp)
    80207d08:	69a2                	ld	s3,8(sp)
    80207d0a:	bf45                	j	80207cba <filewrite+0x6a>
    panic("filewrite");
    80207d0c:	00002517          	auipc	a0,0x2
    80207d10:	11c50513          	addi	a0,a0,284 # 80209e28 <etext+0xe28>
    80207d14:	ffff9097          	auipc	ra,0xffff9
    80207d18:	902080e7          	jalr	-1790(ra) # 80200616 <panic>
    if (f->writable == 0) return -1;
    80207d1c:	597d                	li	s2,-1
    80207d1e:	bf71                	j	80207cba <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80207d20:	597d                	li	s2,-1
    80207d22:	64e2                	ld	s1,24(sp)
    80207d24:	69a2                	ld	s3,8(sp)
    80207d26:	bf51                	j	80207cba <filewrite+0x6a>
    80207d28:	597d                	li	s2,-1
    80207d2a:	64e2                	ld	s1,24(sp)
    80207d2c:	69a2                	ld	s3,8(sp)
    80207d2e:	b771                	j	80207cba <filewrite+0x6a>

0000000080207d30 <pipealloc>:
    int    readopen;
    int    writeopen;
};

int pipealloc(struct file **f0, struct file **f1)
{
    80207d30:	7179                	addi	sp,sp,-48
    80207d32:	f406                	sd	ra,40(sp)
    80207d34:	f022                	sd	s0,32(sp)
    80207d36:	ec26                	sd	s1,24(sp)
    80207d38:	e052                	sd	s4,0(sp)
    80207d3a:	1800                	addi	s0,sp,48
    80207d3c:	84aa                	mv	s1,a0
    80207d3e:	8a2e                	mv	s4,a1
    struct pipe *pi = 0;
    *f0 = *f1 = 0;
    80207d40:	0005b023          	sd	zero,0(a1)
    80207d44:	00053023          	sd	zero,0(a0)

    if ((*f0 = filealloc()) == 0) goto bad;
    80207d48:	00000097          	auipc	ra,0x0
    80207d4c:	c3c080e7          	jalr	-964(ra) # 80207984 <filealloc>
    80207d50:	e088                	sd	a0,0(s1)
    80207d52:	cd49                	beqz	a0,80207dec <pipealloc+0xbc>
    if ((*f1 = filealloc()) == 0) goto bad;
    80207d54:	00000097          	auipc	ra,0x0
    80207d58:	c30080e7          	jalr	-976(ra) # 80207984 <filealloc>
    80207d5c:	00aa3023          	sd	a0,0(s4)
    80207d60:	c141                	beqz	a0,80207de0 <pipealloc+0xb0>
    80207d62:	e84a                	sd	s2,16(sp)
    if ((pi = (struct pipe *)palloc()) == 0) goto bad;
    80207d64:	ffff9097          	auipc	ra,0xffff9
    80207d68:	382080e7          	jalr	898(ra) # 802010e6 <palloc>
    80207d6c:	892a                	mv	s2,a0
    80207d6e:	c13d                	beqz	a0,80207dd4 <pipealloc+0xa4>
    80207d70:	e44e                	sd	s3,8(sp)

    pi->readopen  = 1;
    80207d72:	4985                	li	s3,1
    80207d74:	23352023          	sw	s3,544(a0)
    pi->writeopen = 1;
    80207d78:	23352223          	sw	s3,548(a0)
    pi->nread  = 0;
    80207d7c:	20052c23          	sw	zero,536(a0)
    pi->nwrite = 0;
    80207d80:	20052e23          	sw	zero,540(a0)
    initlock(&pi->lock, "pipe");
    80207d84:	00002597          	auipc	a1,0x2
    80207d88:	bd458593          	addi	a1,a1,-1068 # 80209958 <etext+0x958>
    80207d8c:	ffff9097          	auipc	ra,0xffff9
    80207d90:	680080e7          	jalr	1664(ra) # 8020140c <initlock>

    (*f0)->type = FD_PIPE; (*f0)->readable = 1; (*f0)->writable = 0; (*f0)->pipe = pi;
    80207d94:	609c                	ld	a5,0(s1)
    80207d96:	0137a023          	sw	s3,0(a5)
    80207d9a:	609c                	ld	a5,0(s1)
    80207d9c:	01378423          	sb	s3,8(a5)
    80207da0:	609c                	ld	a5,0(s1)
    80207da2:	000784a3          	sb	zero,9(a5)
    80207da6:	609c                	ld	a5,0(s1)
    80207da8:	0127b823          	sd	s2,16(a5)
    (*f1)->type = FD_PIPE; (*f1)->readable = 0; (*f1)->writable = 1; (*f1)->pipe = pi;
    80207dac:	000a3783          	ld	a5,0(s4)
    80207db0:	0137a023          	sw	s3,0(a5)
    80207db4:	000a3783          	ld	a5,0(s4)
    80207db8:	00078423          	sb	zero,8(a5)
    80207dbc:	000a3783          	ld	a5,0(s4)
    80207dc0:	013784a3          	sb	s3,9(a5)
    80207dc4:	000a3783          	ld	a5,0(s4)
    80207dc8:	0127b823          	sd	s2,16(a5)
    return 0;
    80207dcc:	4501                	li	a0,0
    80207dce:	6942                	ld	s2,16(sp)
    80207dd0:	69a2                	ld	s3,8(sp)
    80207dd2:	a03d                	j	80207e00 <pipealloc+0xd0>

bad:
    if (*f0) fileclose(*f0);
    80207dd4:	6088                	ld	a0,0(s1)
    80207dd6:	c119                	beqz	a0,80207ddc <pipealloc+0xac>
    80207dd8:	6942                	ld	s2,16(sp)
    80207dda:	a029                	j	80207de4 <pipealloc+0xb4>
    80207ddc:	6942                	ld	s2,16(sp)
    80207dde:	a039                	j	80207dec <pipealloc+0xbc>
    80207de0:	6088                	ld	a0,0(s1)
    80207de2:	c50d                	beqz	a0,80207e0c <pipealloc+0xdc>
    80207de4:	00000097          	auipc	ra,0x0
    80207de8:	c5c080e7          	jalr	-932(ra) # 80207a40 <fileclose>
    if (*f1) fileclose(*f1);
    80207dec:	000a3783          	ld	a5,0(s4)
    return -1;
    80207df0:	557d                	li	a0,-1
    if (*f1) fileclose(*f1);
    80207df2:	c799                	beqz	a5,80207e00 <pipealloc+0xd0>
    80207df4:	853e                	mv	a0,a5
    80207df6:	00000097          	auipc	ra,0x0
    80207dfa:	c4a080e7          	jalr	-950(ra) # 80207a40 <fileclose>
    return -1;
    80207dfe:	557d                	li	a0,-1
}
    80207e00:	70a2                	ld	ra,40(sp)
    80207e02:	7402                	ld	s0,32(sp)
    80207e04:	64e2                	ld	s1,24(sp)
    80207e06:	6a02                	ld	s4,0(sp)
    80207e08:	6145                	addi	sp,sp,48
    80207e0a:	8082                	ret
    return -1;
    80207e0c:	557d                	li	a0,-1
    80207e0e:	bfcd                	j	80207e00 <pipealloc+0xd0>

0000000080207e10 <pipeclose>:

void pipeclose(struct pipe *pi, int writable)
{
    80207e10:	1101                	addi	sp,sp,-32
    80207e12:	ec06                	sd	ra,24(sp)
    80207e14:	e822                	sd	s0,16(sp)
    80207e16:	e426                	sd	s1,8(sp)
    80207e18:	e04a                	sd	s2,0(sp)
    80207e1a:	1000                	addi	s0,sp,32
    80207e1c:	84aa                	mv	s1,a0
    80207e1e:	892e                	mv	s2,a1
    acquire(&pi->lock);
    80207e20:	ffff9097          	auipc	ra,0xffff9
    80207e24:	668080e7          	jalr	1640(ra) # 80201488 <acquire>
    if (writable) {
    80207e28:	02090d63          	beqz	s2,80207e62 <pipeclose+0x52>
        pi->writeopen = 0;
    80207e2c:	2204a223          	sw	zero,548(s1)
        wakeup(&pi->nread);          /* blocked readers must see EOF */
    80207e30:	21848513          	addi	a0,s1,536
    80207e34:	ffffa097          	auipc	ra,0xffffa
    80207e38:	438080e7          	jalr	1080(ra) # 8020226c <wakeup>
    } else {
        pi->readopen = 0;
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    }
    if (pi->readopen == 0 && pi->writeopen == 0) {
    80207e3c:	2204b783          	ld	a5,544(s1)
    80207e40:	eb95                	bnez	a5,80207e74 <pipeclose+0x64>
        release(&pi->lock);
    80207e42:	8526                	mv	a0,s1
    80207e44:	ffff9097          	auipc	ra,0xffff9
    80207e48:	6f8080e7          	jalr	1784(ra) # 8020153c <release>
        pfree(pi);
    80207e4c:	8526                	mv	a0,s1
    80207e4e:	ffff9097          	auipc	ra,0xffff9
    80207e52:	3d6080e7          	jalr	982(ra) # 80201224 <pfree>
    } else {
        release(&pi->lock);
    }
}
    80207e56:	60e2                	ld	ra,24(sp)
    80207e58:	6442                	ld	s0,16(sp)
    80207e5a:	64a2                	ld	s1,8(sp)
    80207e5c:	6902                	ld	s2,0(sp)
    80207e5e:	6105                	addi	sp,sp,32
    80207e60:	8082                	ret
        pi->readopen = 0;
    80207e62:	2204a023          	sw	zero,544(s1)
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    80207e66:	21c48513          	addi	a0,s1,540
    80207e6a:	ffffa097          	auipc	ra,0xffffa
    80207e6e:	402080e7          	jalr	1026(ra) # 8020226c <wakeup>
    80207e72:	b7e9                	j	80207e3c <pipeclose+0x2c>
        release(&pi->lock);
    80207e74:	8526                	mv	a0,s1
    80207e76:	ffff9097          	auipc	ra,0xffff9
    80207e7a:	6c6080e7          	jalr	1734(ra) # 8020153c <release>
}
    80207e7e:	bfe1                	j	80207e56 <pipeclose+0x46>

0000000080207e80 <pipewrite>:

int pipewrite(struct pipe *pi, uint64 uaddr, int n)
{
    80207e80:	711d                	addi	sp,sp,-96
    80207e82:	ec86                	sd	ra,88(sp)
    80207e84:	e8a2                	sd	s0,80(sp)
    80207e86:	e4a6                	sd	s1,72(sp)
    80207e88:	e0ca                	sd	s2,64(sp)
    80207e8a:	fc4e                	sd	s3,56(sp)
    80207e8c:	f852                	sd	s4,48(sp)
    80207e8e:	f456                	sd	s5,40(sp)
    80207e90:	1080                	addi	s0,sp,96
    80207e92:	84aa                	mv	s1,a0
    80207e94:	8aae                	mv	s5,a1
    80207e96:	8a32                	mv	s4,a2
    struct proc *pr = myproc();
    80207e98:	ffffa097          	auipc	ra,0xffffa
    80207e9c:	a58080e7          	jalr	-1448(ra) # 802018f0 <myproc>
    80207ea0:	89aa                	mv	s3,a0
    int i = 0;

    acquire(&pi->lock);
    80207ea2:	8526                	mv	a0,s1
    80207ea4:	ffff9097          	auipc	ra,0xffff9
    80207ea8:	5e4080e7          	jalr	1508(ra) # 80201488 <acquire>
    while (i < n) {
    80207eac:	0d405163          	blez	s4,80207f6e <pipewrite+0xee>
    80207eb0:	f05a                	sd	s6,32(sp)
    80207eb2:	ec5e                	sd	s7,24(sp)
    int i = 0;
    80207eb4:	4901                	li	s2,0
        if (pi->readopen == 0 || pr->killed) {
            release(&pi->lock);
            return -1;
        }
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
            wakeup(&pi->nread);
    80207eb6:	21848b93          	addi	s7,s1,536
            sleep(&pi->nwrite, &pi->lock);
    80207eba:	21c48b13          	addi	s6,s1,540
    80207ebe:	a081                	j	80207efe <pipewrite+0x7e>
            release(&pi->lock);
    80207ec0:	8526                	mv	a0,s1
    80207ec2:	ffff9097          	auipc	ra,0xffff9
    80207ec6:	67a080e7          	jalr	1658(ra) # 8020153c <release>
            return -1;
    80207eca:	597d                	li	s2,-1
    80207ecc:	7b02                	ld	s6,32(sp)
    80207ece:	6be2                	ld	s7,24(sp)
        }
    }
    wakeup(&pi->nread);
    release(&pi->lock);
    return i;
}
    80207ed0:	854a                	mv	a0,s2
    80207ed2:	60e6                	ld	ra,88(sp)
    80207ed4:	6446                	ld	s0,80(sp)
    80207ed6:	64a6                	ld	s1,72(sp)
    80207ed8:	6906                	ld	s2,64(sp)
    80207eda:	79e2                	ld	s3,56(sp)
    80207edc:	7a42                	ld	s4,48(sp)
    80207ede:	7aa2                	ld	s5,40(sp)
    80207ee0:	6125                	addi	sp,sp,96
    80207ee2:	8082                	ret
            wakeup(&pi->nread);
    80207ee4:	855e                	mv	a0,s7
    80207ee6:	ffffa097          	auipc	ra,0xffffa
    80207eea:	386080e7          	jalr	902(ra) # 8020226c <wakeup>
            sleep(&pi->nwrite, &pi->lock);
    80207eee:	85a6                	mv	a1,s1
    80207ef0:	855a                	mv	a0,s6
    80207ef2:	ffffa097          	auipc	ra,0xffffa
    80207ef6:	1f4080e7          	jalr	500(ra) # 802020e6 <sleep>
    while (i < n) {
    80207efa:	05495c63          	bge	s2,s4,80207f52 <pipewrite+0xd2>
        if (pi->readopen == 0 || pr->killed) {
    80207efe:	2204a783          	lw	a5,544(s1)
    80207f02:	dfdd                	beqz	a5,80207ec0 <pipewrite+0x40>
    80207f04:	0289a783          	lw	a5,40(s3)
    80207f08:	ffc5                	bnez	a5,80207ec0 <pipewrite+0x40>
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
    80207f0a:	2184a783          	lw	a5,536(s1)
    80207f0e:	21c4a703          	lw	a4,540(s1)
    80207f12:	2007879b          	addiw	a5,a5,512
    80207f16:	fcf707e3          	beq	a4,a5,80207ee4 <pipewrite+0x64>
            if (copyin(pr->pagetable, &ch, uaddr + i, 1) < 0) break;
    80207f1a:	4685                	li	a3,1
    80207f1c:	01590633          	add	a2,s2,s5
    80207f20:	faf40593          	addi	a1,s0,-81
    80207f24:	0509b503          	ld	a0,80(s3)
    80207f28:	ffffb097          	auipc	ra,0xffffb
    80207f2c:	658080e7          	jalr	1624(ra) # 80203580 <copyin>
    80207f30:	04054163          	bltz	a0,80207f72 <pipewrite+0xf2>
            pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80207f34:	21c4a783          	lw	a5,540(s1)
    80207f38:	0017871b          	addiw	a4,a5,1
    80207f3c:	20e4ae23          	sw	a4,540(s1)
    80207f40:	1ff7f793          	andi	a5,a5,511
    80207f44:	97a6                	add	a5,a5,s1
    80207f46:	faf44703          	lbu	a4,-81(s0)
    80207f4a:	00e78c23          	sb	a4,24(a5)
            i++;
    80207f4e:	2905                	addiw	s2,s2,1
    80207f50:	b76d                	j	80207efa <pipewrite+0x7a>
    80207f52:	7b02                	ld	s6,32(sp)
    80207f54:	6be2                	ld	s7,24(sp)
    wakeup(&pi->nread);
    80207f56:	21848513          	addi	a0,s1,536
    80207f5a:	ffffa097          	auipc	ra,0xffffa
    80207f5e:	312080e7          	jalr	786(ra) # 8020226c <wakeup>
    release(&pi->lock);
    80207f62:	8526                	mv	a0,s1
    80207f64:	ffff9097          	auipc	ra,0xffff9
    80207f68:	5d8080e7          	jalr	1496(ra) # 8020153c <release>
    return i;
    80207f6c:	b795                	j	80207ed0 <pipewrite+0x50>
    int i = 0;
    80207f6e:	4901                	li	s2,0
    80207f70:	b7dd                	j	80207f56 <pipewrite+0xd6>
    80207f72:	7b02                	ld	s6,32(sp)
    80207f74:	6be2                	ld	s7,24(sp)
    80207f76:	b7c5                	j	80207f56 <pipewrite+0xd6>

0000000080207f78 <piperead>:

int piperead(struct pipe *pi, uint64 uaddr, int n)
{
    80207f78:	715d                	addi	sp,sp,-80
    80207f7a:	e486                	sd	ra,72(sp)
    80207f7c:	e0a2                	sd	s0,64(sp)
    80207f7e:	fc26                	sd	s1,56(sp)
    80207f80:	f84a                	sd	s2,48(sp)
    80207f82:	f44e                	sd	s3,40(sp)
    80207f84:	f052                	sd	s4,32(sp)
    80207f86:	ec56                	sd	s5,24(sp)
    80207f88:	0880                	addi	s0,sp,80
    80207f8a:	84aa                	mv	s1,a0
    80207f8c:	892e                	mv	s2,a1
    80207f8e:	8ab2                	mv	s5,a2
    struct proc *pr = myproc();
    80207f90:	ffffa097          	auipc	ra,0xffffa
    80207f94:	960080e7          	jalr	-1696(ra) # 802018f0 <myproc>
    80207f98:	8a2a                	mv	s4,a0

    acquire(&pi->lock);
    80207f9a:	8526                	mv	a0,s1
    80207f9c:	ffff9097          	auipc	ra,0xffff9
    80207fa0:	4ec080e7          	jalr	1260(ra) # 80201488 <acquire>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80207fa4:	2184a703          	lw	a4,536(s1)
    80207fa8:	21c4a783          	lw	a5,540(s1)
        if (pr->killed) { release(&pi->lock); return -1; }
        sleep(&pi->nread, &pi->lock);
    80207fac:	21848993          	addi	s3,s1,536
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80207fb0:	02f71463          	bne	a4,a5,80207fd8 <piperead+0x60>
    80207fb4:	2244a783          	lw	a5,548(s1)
    80207fb8:	c385                	beqz	a5,80207fd8 <piperead+0x60>
        if (pr->killed) { release(&pi->lock); return -1; }
    80207fba:	028a2783          	lw	a5,40(s4)
    80207fbe:	e7d9                	bnez	a5,8020804c <piperead+0xd4>
        sleep(&pi->nread, &pi->lock);
    80207fc0:	85a6                	mv	a1,s1
    80207fc2:	854e                	mv	a0,s3
    80207fc4:	ffffa097          	auipc	ra,0xffffa
    80207fc8:	122080e7          	jalr	290(ra) # 802020e6 <sleep>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80207fcc:	2184a703          	lw	a4,536(s1)
    80207fd0:	21c4a783          	lw	a5,540(s1)
    80207fd4:	fef700e3          	beq	a4,a5,80207fb4 <piperead+0x3c>
    }
    int i;
    for (i = 0; i < n; i++) {
    80207fd8:	4981                	li	s3,0
    80207fda:	05505463          	blez	s5,80208022 <piperead+0xaa>
        if (pi->nread == pi->nwrite) break;             /* drained */
    80207fde:	2184a783          	lw	a5,536(s1)
    80207fe2:	21c4a703          	lw	a4,540(s1)
    80207fe6:	02f70e63          	beq	a4,a5,80208022 <piperead+0xaa>
        char ch = pi->data[pi->nread++ % PIPESIZE];
    80207fea:	0017871b          	addiw	a4,a5,1
    80207fee:	20e4ac23          	sw	a4,536(s1)
    80207ff2:	1ff7f793          	andi	a5,a5,511
    80207ff6:	97a6                	add	a5,a5,s1
    80207ff8:	0187c783          	lbu	a5,24(a5)
    80207ffc:	faf40fa3          	sb	a5,-65(s0)
        if (copyout(pr->pagetable, uaddr + i, &ch, 1) < 0) break;
    80208000:	4685                	li	a3,1
    80208002:	fbf40613          	addi	a2,s0,-65
    80208006:	85ca                	mv	a1,s2
    80208008:	050a3503          	ld	a0,80(s4)
    8020800c:	ffffb097          	auipc	ra,0xffffb
    80208010:	44e080e7          	jalr	1102(ra) # 8020345a <copyout>
    80208014:	00054763          	bltz	a0,80208022 <piperead+0xaa>
    for (i = 0; i < n; i++) {
    80208018:	2985                	addiw	s3,s3,1
    8020801a:	0905                	addi	s2,s2,1
    8020801c:	fd3a91e3          	bne	s5,s3,80207fde <piperead+0x66>
    80208020:	89d6                	mv	s3,s5
    }
    wakeup(&pi->nwrite);
    80208022:	21c48513          	addi	a0,s1,540
    80208026:	ffffa097          	auipc	ra,0xffffa
    8020802a:	246080e7          	jalr	582(ra) # 8020226c <wakeup>
    release(&pi->lock);
    8020802e:	8526                	mv	a0,s1
    80208030:	ffff9097          	auipc	ra,0xffff9
    80208034:	50c080e7          	jalr	1292(ra) # 8020153c <release>
    return i;                                           /* 0 here = EOF */
}
    80208038:	854e                	mv	a0,s3
    8020803a:	60a6                	ld	ra,72(sp)
    8020803c:	6406                	ld	s0,64(sp)
    8020803e:	74e2                	ld	s1,56(sp)
    80208040:	7942                	ld	s2,48(sp)
    80208042:	79a2                	ld	s3,40(sp)
    80208044:	7a02                	ld	s4,32(sp)
    80208046:	6ae2                	ld	s5,24(sp)
    80208048:	6161                	addi	sp,sp,80
    8020804a:	8082                	ret
        if (pr->killed) { release(&pi->lock); return -1; }
    8020804c:	8526                	mv	a0,s1
    8020804e:	ffff9097          	auipc	ra,0xffff9
    80208052:	4ee080e7          	jalr	1262(ra) # 8020153c <release>
    80208056:	59fd                	li	s3,-1
    80208058:	b7c5                	j	80208038 <piperead+0xc0>

000000008020805a <hal_intc_init>:
#define PLIC_PRIORITY(irq)   (plic + (irq) * 4)
#define PLIC_SENABLE(h)      (plic + 0x2080 + (h) * 0x100)
#define PLIC_STHRESHOLD(h)   (plic + 0x201000 + (h) * 0x2000)
#define PLIC_SCLAIM(h)       (plic + 0x201004 + (h) * 0x2000)

void hal_intc_init(uint64 plic_base) { plic = plic_base; }
    8020805a:	1141                	addi	sp,sp,-16
    8020805c:	e422                	sd	s0,8(sp)
    8020805e:	0800                	addi	s0,sp,16
    80208060:	00152797          	auipc	a5,0x152
    80208064:	fca7b423          	sd	a0,-56(a5) # 8035a028 <plic>
    80208068:	6422                	ld	s0,8(sp)
    8020806a:	0141                	addi	sp,sp,16
    8020806c:	8082                	ret

000000008020806e <hal_intc_enable>:

void hal_intc_enable(int irq)
{
    8020806e:	1141                	addi	sp,sp,-16
    80208070:	e422                	sd	s0,8(sp)
    80208072:	0800                	addi	s0,sp,16
    if (!plic) return;
    80208074:	00152797          	auipc	a5,0x152
    80208078:	fb47b783          	ld	a5,-76(a5) # 8035a028 <plic>
    8020807c:	c791                	beqz	a5,80208088 <hal_intc_enable+0x1a>
    *(volatile uint32 *)PLIC_PRIORITY(irq) = 1;   /* priority 0 = never fire */
    8020807e:	0025151b          	slliw	a0,a0,0x2
    80208082:	953e                	add	a0,a0,a5
    80208084:	4785                	li	a5,1
    80208086:	c11c                	sw	a5,0(a0)
}
    80208088:	6422                	ld	s0,8(sp)
    8020808a:	0141                	addi	sp,sp,16
    8020808c:	8082                	ret

000000008020808e <hal_intc_hart_init>:

void hal_intc_hart_init(int hart)
{
    8020808e:	1141                	addi	sp,sp,-16
    80208090:	e422                	sd	s0,8(sp)
    80208092:	0800                	addi	s0,sp,16
    if (!plic) return;
    80208094:	00152797          	auipc	a5,0x152
    80208098:	f947b783          	ld	a5,-108(a5) # 8035a028 <plic>
    8020809c:	cb89                	beqz	a5,802080ae <hal_intc_hart_init+0x20>
    *(volatile uint32 *)PLIC_STHRESHOLD(hart) = 0; /* accept any priority > 0 */
    8020809e:	00d5151b          	slliw	a0,a0,0xd
    802080a2:	00201737          	lui	a4,0x201
    802080a6:	97ba                	add	a5,a5,a4
    802080a8:	953e                	add	a0,a0,a5
    802080aa:	00052023          	sw	zero,0(a0)
}
    802080ae:	6422                	ld	s0,8(sp)
    802080b0:	0141                	addi	sp,sp,16
    802080b2:	8082                	ret

00000000802080b4 <hal_intc_enable_hart>:

/* Enable irq for this hart (must be called after hal_intc_enable). */
void hal_intc_enable_hart(int hart, int irq)
{
    802080b4:	1141                	addi	sp,sp,-16
    802080b6:	e422                	sd	s0,8(sp)
    802080b8:	0800                	addi	s0,sp,16
    if (!plic) return;
    802080ba:	00152797          	auipc	a5,0x152
    802080be:	f6e7b783          	ld	a5,-146(a5) # 8035a028 <plic>
    802080c2:	cb85                	beqz	a5,802080f2 <hal_intc_enable_hart+0x3e>
    volatile uint32 *en = (volatile uint32 *)PLIC_SENABLE(hart);
    802080c4:	0085151b          	slliw	a0,a0,0x8
    802080c8:	6709                	lui	a4,0x2
    802080ca:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    802080ce:	97ba                	add	a5,a5,a4
    802080d0:	953e                	add	a0,a0,a5
    en[irq / 32] |= (1u << (irq % 32));
    802080d2:	41f5d79b          	sraiw	a5,a1,0x1f
    802080d6:	01b7d79b          	srliw	a5,a5,0x1b
    802080da:	9fad                	addw	a5,a5,a1
    802080dc:	4057d79b          	sraiw	a5,a5,0x5
    802080e0:	078a                	slli	a5,a5,0x2
    802080e2:	953e                	add	a0,a0,a5
    802080e4:	411c                	lw	a5,0(a0)
    802080e6:	4705                	li	a4,1
    802080e8:	00b7173b          	sllw	a4,a4,a1
    802080ec:	8fd9                	or	a5,a5,a4
    802080ee:	2781                	sext.w	a5,a5
    802080f0:	c11c                	sw	a5,0(a0)
}
    802080f2:	6422                	ld	s0,8(sp)
    802080f4:	0141                	addi	sp,sp,16
    802080f6:	8082                	ret

00000000802080f8 <hal_intc_claim>:

int hal_intc_claim(void)
{
    802080f8:	1141                	addi	sp,sp,-16
    802080fa:	e422                	sd	s0,8(sp)
    802080fc:	0800                	addi	s0,sp,16
    if (!plic) return 0;
    802080fe:	00152797          	auipc	a5,0x152
    80208102:	f2a7b783          	ld	a5,-214(a5) # 8035a028 <plic>
    80208106:	4501                	li	a0,0
    80208108:	e781                	bnez	a5,80208110 <hal_intc_claim+0x18>
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
}
    8020810a:	6422                	ld	s0,8(sp)
    8020810c:	0141                	addi	sp,sp,16
    8020810e:	8082                	ret
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    80208110:	8712                	mv	a4,tp
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
    80208112:	00d7171b          	slliw	a4,a4,0xd
    80208116:	002016b7          	lui	a3,0x201
    8020811a:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    8020811c:	97b6                	add	a5,a5,a3
    8020811e:	97ba                	add	a5,a5,a4
    80208120:	4388                	lw	a0,0(a5)
    80208122:	b7e5                	j	8020810a <hal_intc_claim+0x12>

0000000080208124 <hal_intc_complete>:

void hal_intc_complete(int irq)
{
    80208124:	1141                	addi	sp,sp,-16
    80208126:	e422                	sd	s0,8(sp)
    80208128:	0800                	addi	s0,sp,16
    if (!plic) return;
    8020812a:	00152797          	auipc	a5,0x152
    8020812e:	efe7b783          	ld	a5,-258(a5) # 8035a028 <plic>
    80208132:	e781                	bnez	a5,8020813a <hal_intc_complete+0x16>
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
}
    80208134:	6422                	ld	s0,8(sp)
    80208136:	0141                	addi	sp,sp,16
    80208138:	8082                	ret
    8020813a:	8712                	mv	a4,tp
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
    8020813c:	00d7171b          	slliw	a4,a4,0xd
    80208140:	002016b7          	lui	a3,0x201
    80208144:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    80208146:	97b6                	add	a5,a5,a3
    80208148:	97ba                	add	a5,a5,a4
    8020814a:	2501                	sext.w	a0,a0
    8020814c:	c388                	sw	a0,0(a5)
    8020814e:	b7dd                	j	80208134 <hal_intc_complete+0x10>

0000000080208150 <hal_hart_id>:

int hal_hart_id(void) { return (int)r_tp(); }
    80208150:	1141                	addi	sp,sp,-16
    80208152:	e422                	sd	s0,8(sp)
    80208154:	0800                	addi	s0,sp,16
    80208156:	8512                	mv	a0,tp
    80208158:	2501                	sext.w	a0,a0
    8020815a:	6422                	ld	s0,8(sp)
    8020815c:	0141                	addi	sp,sp,16
    8020815e:	8082                	ret

0000000080208160 <plic_dbg>:

int plic_dbg(int which)
{
    80208160:	1141                	addi	sp,sp,-16
    80208162:	e422                	sd	s0,8(sp)
    80208164:	0800                	addi	s0,sp,16
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    80208166:	cd09                	beqz	a0,80208180 <plic_dbg+0x20>
    return *(volatile uint32 *)PLIC_SENABLE(0);
    80208168:	6709                	lui	a4,0x2
    8020816a:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    8020816e:	00152797          	auipc	a5,0x152
    80208172:	eba7b783          	ld	a5,-326(a5) # 8035a028 <plic>
    80208176:	97ba                	add	a5,a5,a4
    80208178:	4388                	lw	a0,0(a5)
}
    8020817a:	6422                	ld	s0,8(sp)
    8020817c:	0141                	addi	sp,sp,16
    8020817e:	8082                	ret
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    80208180:	00152797          	auipc	a5,0x152
    80208184:	ea87b783          	ld	a5,-344(a5) # 8035a028 <plic>
    80208188:	5788                	lw	a0,40(a5)
    8020818a:	bfc5                	j	8020817a <plic_dbg+0x1a>

000000008020818c <hal_time_read>:
#include "hal.h"
#include "riscv.h"
#include "defs.h"

void    hal_timer_init(void)          { hal_timer_next(1000000); }
uint64  hal_time_read(void)           { return r_time(); }
    8020818c:	1141                	addi	sp,sp,-16
    8020818e:	e422                	sd	s0,8(sp)
    80208190:	0800                	addi	s0,sp,16
static inline uint64 r_time(void){ uint64 x; asm volatile("rdtime %0":"=r"(x)); return x; }
    80208192:	c0102573          	rdtime	a0
    80208196:	6422                	ld	s0,8(sp)
    80208198:	0141                	addi	sp,sp,16
    8020819a:	8082                	ret

000000008020819c <hal_timer_set>:
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    8020819c:	1141                	addi	sp,sp,-16
    8020819e:	e406                	sd	ra,8(sp)
    802081a0:	e022                	sd	s0,0(sp)
    802081a2:	0800                	addi	s0,sp,16
    802081a4:	ffff8097          	auipc	ra,0xffff8
    802081a8:	674080e7          	jalr	1652(ra) # 80200818 <sbi_set_timer>
    802081ac:	60a2                	ld	ra,8(sp)
    802081ae:	6402                	ld	s0,0(sp)
    802081b0:	0141                	addi	sp,sp,16
    802081b2:	8082                	ret

00000000802081b4 <hal_timer_ack>:
void    hal_timer_ack(void)           { /* SBI: next set_timer clears STIP */ }
    802081b4:	1141                	addi	sp,sp,-16
    802081b6:	e422                	sd	s0,8(sp)
    802081b8:	0800                	addi	s0,sp,16
    802081ba:	6422                	ld	s0,8(sp)
    802081bc:	0141                	addi	sp,sp,16
    802081be:	8082                	ret

00000000802081c0 <hal_timer_next>:
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    802081c0:	1141                	addi	sp,sp,-16
    802081c2:	e406                	sd	ra,8(sp)
    802081c4:	e022                	sd	s0,0(sp)
    802081c6:	0800                	addi	s0,sp,16
    802081c8:	c01027f3          	rdtime	a5
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    802081cc:	953e                	add	a0,a0,a5
    802081ce:	ffff8097          	auipc	ra,0xffff8
    802081d2:	64a080e7          	jalr	1610(ra) # 80200818 <sbi_set_timer>
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    802081d6:	60a2                	ld	ra,8(sp)
    802081d8:	6402                	ld	s0,0(sp)
    802081da:	0141                	addi	sp,sp,16
    802081dc:	8082                	ret

00000000802081de <hal_timer_init>:
void    hal_timer_init(void)          { hal_timer_next(1000000); }
    802081de:	1141                	addi	sp,sp,-16
    802081e0:	e406                	sd	ra,8(sp)
    802081e2:	e022                	sd	s0,0(sp)
    802081e4:	0800                	addi	s0,sp,16
    802081e6:	000f4537          	lui	a0,0xf4
    802081ea:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    802081ee:	00000097          	auipc	ra,0x0
    802081f2:	fd2080e7          	jalr	-46(ra) # 802081c0 <hal_timer_next>
    802081f6:	60a2                	ld	ra,8(sp)
    802081f8:	6402                	ld	s0,0(sp)
    802081fa:	0141                	addi	sp,sp,16
    802081fc:	8082                	ret

00000000802081fe <hal_console_init>:
#define LSR 5   /* line status              */
#define LSR_RX_READY  (1 << 0)
#define LSR_TX_IDLE   (1 << 5)

void hal_console_init(uint64 uart_base)
{
    802081fe:	1141                	addi	sp,sp,-16
    80208200:	e422                	sd	s0,8(sp)
    80208202:	0800                	addi	s0,sp,16
    uart = (volatile uint8 *)uart_base;
    80208204:	00152797          	auipc	a5,0x152
    80208208:	e2a7b623          	sd	a0,-468(a5) # 8035a030 <uart>
    uart[IER] = 0x00;              /* interrupts off while we configure */
    8020820c:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x80;              /* DLAB=1: divisor latch visible     */
    80208210:	f8000793          	li	a5,-128
    80208214:	00f501a3          	sb	a5,3(a0)
    uart[0]   = 0x03;              /* divisor low: 38.4K                */
    80208218:	478d                	li	a5,3
    8020821a:	00f50023          	sb	a5,0(a0)
    uart[1]   = 0x00;              /* divisor high                      */
    8020821e:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x03;              /* DLAB=0, 8 bits, no parity, 1 stop */
    80208222:	00f501a3          	sb	a5,3(a0)
    uart[FCR] = 0x07;              /* enable + clear FIFOs              */
    80208226:	479d                	li	a5,7
    80208228:	00f50123          	sb	a5,2(a0)
    uart[IER] = 0x01;              /* receive interrupts on             */
    8020822c:	4785                	li	a5,1
    8020822e:	00f500a3          	sb	a5,1(a0)
}
    80208232:	6422                	ld	s0,8(sp)
    80208234:	0141                	addi	sp,sp,16
    80208236:	8082                	ret

0000000080208238 <hal_console_putc>:

void hal_console_putc(char c)
{
    80208238:	1141                	addi	sp,sp,-16
    8020823a:	e422                	sd	s0,8(sp)
    8020823c:	0800                	addi	s0,sp,16
    if (!uart) { return; }
    8020823e:	00152717          	auipc	a4,0x152
    80208242:	df273703          	ld	a4,-526(a4) # 8035a030 <uart>
    80208246:	cb01                	beqz	a4,80208256 <hal_console_putc+0x1e>
    while ((uart[LSR] & LSR_TX_IDLE) == 0)   /* wait for the holding reg */
    80208248:	00574783          	lbu	a5,5(a4)
    8020824c:	0207f793          	andi	a5,a5,32
    80208250:	dfe5                	beqz	a5,80208248 <hal_console_putc+0x10>
        ;
    uart[THR] = c;
    80208252:	00a70023          	sb	a0,0(a4)
}
    80208256:	6422                	ld	s0,8(sp)
    80208258:	0141                	addi	sp,sp,16
    8020825a:	8082                	ret

000000008020825c <hal_console_getc>:

int hal_console_getc(void)
{
    8020825c:	1141                	addi	sp,sp,-16
    8020825e:	e422                	sd	s0,8(sp)
    80208260:	0800                	addi	s0,sp,16
    if (!uart) return -1;
    80208262:	00152717          	auipc	a4,0x152
    80208266:	dce73703          	ld	a4,-562(a4) # 8035a030 <uart>
    8020826a:	cb11                	beqz	a4,8020827e <hal_console_getc+0x22>
    if (uart[LSR] & LSR_RX_READY)
    8020826c:	00574783          	lbu	a5,5(a4)
    80208270:	8b85                	andi	a5,a5,1
    80208272:	cb81                	beqz	a5,80208282 <hal_console_getc+0x26>
        return uart[RHR];
    80208274:	00074503          	lbu	a0,0(a4)
    return -1;
}
    80208278:	6422                	ld	s0,8(sp)
    8020827a:	0141                	addi	sp,sp,16
    8020827c:	8082                	ret
    if (!uart) return -1;
    8020827e:	557d                	li	a0,-1
    80208280:	bfe5                	j	80208278 <hal_console_getc+0x1c>
    return -1;
    80208282:	557d                	li	a0,-1
    80208284:	bfd5                	j	80208278 <hal_console_getc+0x1c>

0000000080208286 <free_desc>:
    for (int i = 0; i < VNUM; i++)
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    return -1;
}
static void free_desc(int i)
{
    80208286:	1141                	addi	sp,sp,-16
    80208288:	e406                	sd	ra,8(sp)
    8020828a:	e022                	sd	s0,0(sp)
    8020828c:	0800                	addi	s0,sp,16
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    8020828e:	479d                	li	a5,7
    80208290:	04a7c663          	blt	a5,a0,802082dc <free_desc+0x56>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    80208294:	0014f797          	auipc	a5,0x14f
    80208298:	d6c78793          	addi	a5,a5,-660 # 80357000 <vdisk>
    8020829c:	97aa                	add	a5,a5,a0
    8020829e:	0287c783          	lbu	a5,40(a5)
    802082a2:	e7a9                	bnez	a5,802082ec <free_desc+0x66>
    vdisk.desc[i] = (struct virtq_desc){0};
    802082a4:	0014f797          	auipc	a5,0x14f
    802082a8:	d5c78793          	addi	a5,a5,-676 # 80357000 <vdisk>
    802082ac:	6b98                	ld	a4,16(a5)
    802082ae:	00451693          	slli	a3,a0,0x4
    802082b2:	9736                	add	a4,a4,a3
    802082b4:	00073023          	sd	zero,0(a4)
    802082b8:	00073423          	sd	zero,8(a4)
    vdisk.free[i] = 1;
    802082bc:	97aa                	add	a5,a5,a0
    802082be:	4705                	li	a4,1
    802082c0:	02e78423          	sb	a4,40(a5)
    wakeup(&vdisk.free[0]);
    802082c4:	0014f517          	auipc	a0,0x14f
    802082c8:	d6450513          	addi	a0,a0,-668 # 80357028 <vdisk+0x28>
    802082cc:	ffffa097          	auipc	ra,0xffffa
    802082d0:	fa0080e7          	jalr	-96(ra) # 8020226c <wakeup>
}
    802082d4:	60a2                	ld	ra,8(sp)
    802082d6:	6402                	ld	s0,0(sp)
    802082d8:	0141                	addi	sp,sp,16
    802082da:	8082                	ret
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    802082dc:	00002517          	auipc	a0,0x2
    802082e0:	b5c50513          	addi	a0,a0,-1188 # 80209e38 <etext+0xe38>
    802082e4:	ffff8097          	auipc	ra,0xffff8
    802082e8:	332080e7          	jalr	818(ra) # 80200616 <panic>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    802082ec:	00002517          	auipc	a0,0x2
    802082f0:	b6c50513          	addi	a0,a0,-1172 # 80209e58 <etext+0xe58>
    802082f4:	ffff8097          	auipc	ra,0xffff8
    802082f8:	322080e7          	jalr	802(ra) # 80200616 <panic>

00000000802082fc <hal_block_irq>:
int hal_block_irq(void) { return vdisk.base ? vdisk.irq : 0; }
    802082fc:	1141                	addi	sp,sp,-16
    802082fe:	e422                	sd	s0,8(sp)
    80208300:	0800                	addi	s0,sp,16
    80208302:	0014f797          	auipc	a5,0x14f
    80208306:	cfe7b783          	ld	a5,-770(a5) # 80357000 <vdisk>
    8020830a:	4501                	li	a0,0
    8020830c:	c789                	beqz	a5,80208316 <hal_block_irq+0x1a>
    8020830e:	0014f517          	auipc	a0,0x14f
    80208312:	cfa52503          	lw	a0,-774(a0) # 80357008 <vdisk+0x8>
    80208316:	6422                	ld	s0,8(sp)
    80208318:	0141                	addi	sp,sp,16
    8020831a:	8082                	ret

000000008020831c <hal_block_init>:
{
    8020831c:	7139                	addi	sp,sp,-64
    8020831e:	fc06                	sd	ra,56(sp)
    80208320:	f822                	sd	s0,48(sp)
    80208322:	f426                	sd	s1,40(sp)
    80208324:	0080                	addi	s0,sp,64
    initlock(&vdisk.lock, "virtio_blk");
    80208326:	00002597          	auipc	a1,0x2
    8020832a:	b5258593          	addi	a1,a1,-1198 # 80209e78 <etext+0xe78>
    8020832e:	0014f517          	auipc	a0,0x14f
    80208332:	e0a50513          	addi	a0,a0,-502 # 80357138 <vdisk+0x138>
    80208336:	ffff9097          	auipc	ra,0xffff9
    8020833a:	0d6080e7          	jalr	214(ra) # 8020140c <initlock>
    for (int i = 0; i < fdt.nvirtio; i++) {
    8020833e:	00024797          	auipc	a5,0x24
    80208342:	d627a783          	lw	a5,-670(a5) # 8022c0a0 <fdt+0x88>
    80208346:	08f05c63          	blez	a5,802083de <hal_block_init+0xc2>
    8020834a:	f04a                	sd	s2,32(sp)
    8020834c:	ec4e                	sd	s3,24(sp)
    8020834e:	e852                	sd	s4,16(sp)
    80208350:	e456                	sd	s5,8(sp)
    80208352:	e05a                	sd	s6,0(sp)
    80208354:	00024917          	auipc	s2,0x24
    80208358:	cc490913          	addi	s2,s2,-828 # 8022c018 <fdt>
    8020835c:	4481                	li	s1,0
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    8020835e:	747279b7          	lui	s3,0x74727
    80208362:	97698993          	addi	s3,s3,-1674 # 74726976 <_entry-0xbad968a>
    80208366:	4a89                	li	s5,2
    80208368:	4b05                	li	s6,1
    for (int i = 0; i < fdt.nvirtio; i++) {
    8020836a:	8a4a                	mv	s4,s2
    8020836c:	a039                	j	8020837a <hal_block_init+0x5e>
    8020836e:	2485                	addiw	s1,s1,1
    80208370:	0921                	addi	s2,s2,8
    80208372:	088a2783          	lw	a5,136(s4)
    80208376:	04f4df63          	bge	s1,a5,802083d4 <hal_block_init+0xb8>
        uint64 va = mmio_alias(fdt.virtio_base[i]);
    8020837a:	02893503          	ld	a0,40(s2)
    8020837e:	ffffb097          	auipc	ra,0xffffb
    80208382:	b3e080e7          	jalr	-1218(ra) # 80202ebc <mmio_alias>
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    80208386:	411c                	lw	a5,0(a0)
    80208388:	2781                	sext.w	a5,a5
    8020838a:	ff3792e3          	bne	a5,s3,8020836e <hal_block_init+0x52>
    8020838e:	451c                	lw	a5,8(a0)
    80208390:	2781                	sext.w	a5,a5
    80208392:	fd579ee3          	bne	a5,s5,8020836e <hal_block_init+0x52>
    80208396:	415c                	lw	a5,4(a0)
    80208398:	2781                	sext.w	a5,a5
    8020839a:	01678663          	beq	a5,s6,802083a6 <hal_block_init+0x8a>
    8020839e:	415c                	lw	a5,4(a0)
    802083a0:	2781                	sext.w	a5,a5
    802083a2:	fd5796e3          	bne	a5,s5,8020836e <hal_block_init+0x52>
            vdisk.base    = va;
    802083a6:	0014f717          	auipc	a4,0x14f
    802083aa:	c5a70713          	addi	a4,a4,-934 # 80357000 <vdisk>
    802083ae:	e308                	sd	a0,0(a4)
            vdisk.irq     = fdt.virtio_irq[i];
    802083b0:	01848793          	addi	a5,s1,24
    802083b4:	078a                	slli	a5,a5,0x2
    802083b6:	00024697          	auipc	a3,0x24
    802083ba:	c6268693          	addi	a3,a3,-926 # 8022c018 <fdt>
    802083be:	97b6                	add	a5,a5,a3
    802083c0:	479c                	lw	a5,8(a5)
    802083c2:	c71c                	sw	a5,8(a4)
            vdisk.version = *vers;
    802083c4:	415c                	lw	a5,4(a0)
    802083c6:	c75c                	sw	a5,12(a4)
            break;
    802083c8:	7902                	ld	s2,32(sp)
    802083ca:	69e2                	ld	s3,24(sp)
    802083cc:	6a42                	ld	s4,16(sp)
    802083ce:	6aa2                	ld	s5,8(sp)
    802083d0:	6b02                	ld	s6,0(sp)
    802083d2:	a031                	j	802083de <hal_block_init+0xc2>
    802083d4:	7902                	ld	s2,32(sp)
    802083d6:	69e2                	ld	s3,24(sp)
    802083d8:	6a42                	ld	s4,16(sp)
    802083da:	6aa2                	ld	s5,8(sp)
    802083dc:	6b02                	ld	s6,0(sp)
    if (!vdisk.base) return -1;                   /* no disk on this board */
    802083de:	0014f797          	auipc	a5,0x14f
    802083e2:	c227b783          	ld	a5,-990(a5) # 80357000 <vdisk>
    802083e6:	1a078363          	beqz	a5,8020858c <hal_block_init+0x270>
    *R(VIRTIO_MMIO_STATUS) = 0;
    802083ea:	0607a823          	sw	zero,112(a5)
    *R(VIRTIO_MMIO_STATUS) = status;
    802083ee:	0014f797          	auipc	a5,0x14f
    802083f2:	c1278793          	addi	a5,a5,-1006 # 80357000 <vdisk>
    802083f6:	6398                	ld	a4,0(a5)
    802083f8:	4685                	li	a3,1
    802083fa:	db34                	sw	a3,112(a4)
    *R(VIRTIO_MMIO_STATUS) = status;
    802083fc:	6398                	ld	a4,0(a5)
    802083fe:	468d                	li	a3,3
    80208400:	db34                	sw	a3,112(a4)
    uint32 feats = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80208402:	6390                	ld	a2,0(a5)
    80208404:	4a18                	lw	a4,16(a2)
    feats &= ~(1u << VIRTIO_RING_F_EVENT_IDX);
    80208406:	c7ffe6b7          	lui	a3,0xc7ffe
    8020840a:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <uart+0xffffffff47ca472f>
    8020840e:	8f75                	and	a4,a4,a3
    *R(VIRTIO_MMIO_DRIVER_FEATURES) = feats;
    80208410:	d218                	sw	a4,32(a2)
    if (vdisk.version == 2) {
    80208412:	47d8                	lw	a4,12(a5)
    80208414:	4789                	li	a5,2
    status |= VIRTIO_CONFIG_S_DRIVER;
    80208416:	448d                	li	s1,3
    if (vdisk.version == 2) {
    80208418:	0ef70563          	beq	a4,a5,80208502 <hal_block_init+0x1e6>
    *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8020841c:	0014f797          	auipc	a5,0x14f
    80208420:	be478793          	addi	a5,a5,-1052 # 80357000 <vdisk>
    80208424:	6398                	ld	a4,0(a5)
    80208426:	02072823          	sw	zero,48(a4)
    uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8020842a:	6398                	ld	a4,0(a5)
    8020842c:	5b5c                	lw	a5,52(a4)
    8020842e:	2781                	sext.w	a5,a5
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80208430:	10078263          	beqz	a5,80208534 <hal_block_init+0x218>
    if (max < VNUM) panic("virtio_blk: queue too short");
    80208434:	469d                	li	a3,7
    80208436:	10f6fc63          	bgeu	a3,a5,8020854e <hal_block_init+0x232>
    *R(VIRTIO_MMIO_QUEUE_NUM) = VNUM;
    8020843a:	47a1                	li	a5,8
    8020843c:	df1c                	sw	a5,56(a4)
    memset(pages, 0, sizeof(pages));
    8020843e:	6609                	lui	a2,0x2
    80208440:	4581                	li	a1,0
    80208442:	00150517          	auipc	a0,0x150
    80208446:	bbe50513          	addi	a0,a0,-1090 # 80358000 <pages.0>
    8020844a:	ffff8097          	auipc	ra,0xffff8
    8020844e:	272080e7          	jalr	626(ra) # 802006bc <memset>
    vdisk.desc  = (struct virtq_desc *)pages;
    80208452:	0014f797          	auipc	a5,0x14f
    80208456:	bae78793          	addi	a5,a5,-1106 # 80357000 <vdisk>
    8020845a:	00150717          	auipc	a4,0x150
    8020845e:	ba670713          	addi	a4,a4,-1114 # 80358000 <pages.0>
    80208462:	eb98                	sd	a4,16(a5)
    vdisk.avail = (struct virtq_avail *)(pages + VNUM * sizeof(struct virtq_desc));
    80208464:	00150717          	auipc	a4,0x150
    80208468:	c1c70713          	addi	a4,a4,-996 # 80358080 <pages.0+0x80>
    8020846c:	ef98                	sd	a4,24(a5)
    vdisk.used  = (struct virtq_used *)(pages + PGSIZE);
    8020846e:	00151717          	auipc	a4,0x151
    80208472:	b9270713          	addi	a4,a4,-1134 # 80359000 <pages.0+0x1000>
    80208476:	f398                	sd	a4,32(a5)
    if (vdisk.version == 1) {
    80208478:	47d8                	lw	a4,12(a5)
    8020847a:	4785                	li	a5,1
    8020847c:	0ef70663          	beq	a4,a5,80208568 <hal_block_init+0x24c>
        *R(VIRTIO_MMIO_QUEUE_DESC_LOW)   = (uint64)vdisk.desc;
    80208480:	0014f797          	auipc	a5,0x14f
    80208484:	b8078793          	addi	a5,a5,-1152 # 80357000 <vdisk>
    80208488:	6398                	ld	a4,0(a5)
    8020848a:	00150697          	auipc	a3,0x150
    8020848e:	b7668693          	addi	a3,a3,-1162 # 80358000 <pages.0>
    80208492:	08d72023          	sw	a3,128(a4)
        *R(VIRTIO_MMIO_QUEUE_DESC_HIGH)  = (uint64)vdisk.desc >> 32;
    80208496:	6398                	ld	a4,0(a5)
    80208498:	4bd4                	lw	a3,20(a5)
    8020849a:	08d72223          	sw	a3,132(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_LOW)  = (uint64)vdisk.avail;
    8020849e:	6398                	ld	a4,0(a5)
    802084a0:	4f94                	lw	a3,24(a5)
    802084a2:	08d72823          	sw	a3,144(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)vdisk.avail >> 32;
    802084a6:	6398                	ld	a4,0(a5)
    802084a8:	4fd4                	lw	a3,28(a5)
    802084aa:	08d72a23          	sw	a3,148(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_LOW)  = (uint64)vdisk.used;
    802084ae:	6398                	ld	a4,0(a5)
    802084b0:	5394                	lw	a3,32(a5)
    802084b2:	0ad72023          	sw	a3,160(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)vdisk.used >> 32;
    802084b6:	6398                	ld	a4,0(a5)
    802084b8:	53d4                	lw	a3,36(a5)
    802084ba:	0ad72223          	sw	a3,164(a4)
        *R(VIRTIO_MMIO_QUEUE_READY) = 1;
    802084be:	639c                	ld	a5,0(a5)
    802084c0:	4705                	li	a4,1
    802084c2:	c3f8                	sw	a4,68(a5)
    for (int i = 0; i < VNUM; i++) vdisk.free[i] = 1;
    802084c4:	0014f797          	auipc	a5,0x14f
    802084c8:	b3c78793          	addi	a5,a5,-1220 # 80357000 <vdisk>
    802084cc:	4705                	li	a4,1
    802084ce:	02e78423          	sb	a4,40(a5)
    802084d2:	02e784a3          	sb	a4,41(a5)
    802084d6:	02e78523          	sb	a4,42(a5)
    802084da:	02e785a3          	sb	a4,43(a5)
    802084de:	02e78623          	sb	a4,44(a5)
    802084e2:	02e786a3          	sb	a4,45(a5)
    802084e6:	02e78723          	sb	a4,46(a5)
    802084ea:	02e787a3          	sb	a4,47(a5)
    status |= VIRTIO_CONFIG_S_DRIVER_OK;
    802084ee:	0044e493          	ori	s1,s1,4
    *R(VIRTIO_MMIO_STATUS) = status;
    802084f2:	639c                	ld	a5,0(a5)
    802084f4:	dba4                	sw	s1,112(a5)
    return 0;
    802084f6:	4501                	li	a0,0
}
    802084f8:	70e2                	ld	ra,56(sp)
    802084fa:	7442                	ld	s0,48(sp)
    802084fc:	74a2                	ld	s1,40(sp)
    802084fe:	6121                	addi	sp,sp,64
    80208500:	8082                	ret
        *R(VIRTIO_MMIO_STATUS) = status;
    80208502:	0014f797          	auipc	a5,0x14f
    80208506:	afe78793          	addi	a5,a5,-1282 # 80357000 <vdisk>
    8020850a:	6398                	ld	a4,0(a5)
    8020850c:	46ad                	li	a3,11
    8020850e:	db34                	sw	a3,112(a4)
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80208510:	639c                	ld	a5,0(a5)
    80208512:	5bbc                	lw	a5,112(a5)
    80208514:	8ba1                	andi	a5,a5,8
        status |= VIRTIO_CONFIG_S_FEATURES_OK;
    80208516:	44ad                	li	s1,11
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80208518:	f391                	bnez	a5,8020841c <hal_block_init+0x100>
    8020851a:	f04a                	sd	s2,32(sp)
    8020851c:	ec4e                	sd	s3,24(sp)
    8020851e:	e852                	sd	s4,16(sp)
    80208520:	e456                	sd	s5,8(sp)
    80208522:	e05a                	sd	s6,0(sp)
            panic("virtio_blk: device rejected our feature set");
    80208524:	00002517          	auipc	a0,0x2
    80208528:	96450513          	addi	a0,a0,-1692 # 80209e88 <etext+0xe88>
    8020852c:	ffff8097          	auipc	ra,0xffff8
    80208530:	0ea080e7          	jalr	234(ra) # 80200616 <panic>
    80208534:	f04a                	sd	s2,32(sp)
    80208536:	ec4e                	sd	s3,24(sp)
    80208538:	e852                	sd	s4,16(sp)
    8020853a:	e456                	sd	s5,8(sp)
    8020853c:	e05a                	sd	s6,0(sp)
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    8020853e:	00002517          	auipc	a0,0x2
    80208542:	97a50513          	addi	a0,a0,-1670 # 80209eb8 <etext+0xeb8>
    80208546:	ffff8097          	auipc	ra,0xffff8
    8020854a:	0d0080e7          	jalr	208(ra) # 80200616 <panic>
    8020854e:	f04a                	sd	s2,32(sp)
    80208550:	ec4e                	sd	s3,24(sp)
    80208552:	e852                	sd	s4,16(sp)
    80208554:	e456                	sd	s5,8(sp)
    80208556:	e05a                	sd	s6,0(sp)
    if (max < VNUM) panic("virtio_blk: queue too short");
    80208558:	00002517          	auipc	a0,0x2
    8020855c:	98850513          	addi	a0,a0,-1656 # 80209ee0 <etext+0xee0>
    80208560:	ffff8097          	auipc	ra,0xffff8
    80208564:	0b6080e7          	jalr	182(ra) # 80200616 <panic>
        *R(VIRTIO_MMIO_GUEST_PAGE_SIZE) = PGSIZE;
    80208568:	0014f797          	auipc	a5,0x14f
    8020856c:	a9878793          	addi	a5,a5,-1384 # 80357000 <vdisk>
    80208570:	6394                	ld	a3,0(a5)
    80208572:	6705                	lui	a4,0x1
    80208574:	d698                	sw	a4,40(a3)
        *R(VIRTIO_MMIO_QUEUE_ALIGN)     = PGSIZE;
    80208576:	6394                	ld	a3,0(a5)
    80208578:	ded8                	sw	a4,60(a3)
        *R(VIRTIO_MMIO_QUEUE_PFN)       = ((uint64)pages) >> 12;
    8020857a:	6398                	ld	a4,0(a5)
    8020857c:	00150797          	auipc	a5,0x150
    80208580:	a8478793          	addi	a5,a5,-1404 # 80358000 <pages.0>
    80208584:	83b1                	srli	a5,a5,0xc
    80208586:	2781                	sext.w	a5,a5
    80208588:	c33c                	sw	a5,64(a4)
    8020858a:	bf2d                	j	802084c4 <hal_block_init+0x1a8>
    if (!vdisk.base) return -1;                   /* no disk on this board */
    8020858c:	557d                	li	a0,-1
    8020858e:	b7ad                	j	802084f8 <hal_block_init+0x1dc>

0000000080208590 <hal_block_rw>:
    }
    return 0;
}

void hal_block_rw(struct buf *b, int write)
{
    80208590:	7159                	addi	sp,sp,-112
    80208592:	f486                	sd	ra,104(sp)
    80208594:	f0a2                	sd	s0,96(sp)
    80208596:	eca6                	sd	s1,88(sp)
    80208598:	e8ca                	sd	s2,80(sp)
    8020859a:	e4ce                	sd	s3,72(sp)
    8020859c:	e0d2                	sd	s4,64(sp)
    8020859e:	fc56                	sd	s5,56(sp)
    802085a0:	f85a                	sd	s6,48(sp)
    802085a2:	f45e                	sd	s7,40(sp)
    802085a4:	f062                	sd	s8,32(sp)
    802085a6:	ec66                	sd	s9,24(sp)
    802085a8:	1880                	addi	s0,sp,112
    802085aa:	8a2a                	mv	s4,a0
    802085ac:	8cae                	mv	s9,a1
    /* LuitFS blocks are 1024 bytes = two 512-byte disk sectors. */
    uint64 sector = b->blockno * (BSIZE / 512);
    802085ae:	00c52c03          	lw	s8,12(a0)
    802085b2:	001c1c1b          	slliw	s8,s8,0x1
    802085b6:	1c02                	slli	s8,s8,0x20
    802085b8:	020c5c13          	srli	s8,s8,0x20

    acquire(&vdisk.lock);
    802085bc:	0014f517          	auipc	a0,0x14f
    802085c0:	b7c50513          	addi	a0,a0,-1156 # 80357138 <vdisk+0x138>
    802085c4:	ffff9097          	auipc	ra,0xffff9
    802085c8:	ec4080e7          	jalr	-316(ra) # 80201488 <acquire>
    for (int i = 0; i < 3; i++) {
    802085cc:	4981                	li	s3,0
    for (int i = 0; i < VNUM; i++)
    802085ce:	44a1                	li	s1,8
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    802085d0:	0014fb17          	auipc	s6,0x14f
    802085d4:	a30b0b13          	addi	s6,s6,-1488 # 80357000 <vdisk>
    for (int i = 0; i < 3; i++) {
    802085d8:	4a8d                	li	s5,3

    int idx[3];
    while (alloc3_desc(idx) != 0)
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    802085da:	0014fb97          	auipc	s7,0x14f
    802085de:	b5eb8b93          	addi	s7,s7,-1186 # 80357138 <vdisk+0x138>
    while (alloc3_desc(idx) != 0)
    802085e2:	a0ad                	j	8020864c <hal_block_rw+0xbc>
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    802085e4:	00fb0733          	add	a4,s6,a5
    802085e8:	02070423          	sb	zero,40(a4) # 1028 <_entry-0x801fefd8>
        idx[i] = alloc_desc();
    802085ec:	c19c                	sw	a5,0(a1)
        if (idx[i] < 0) {
    802085ee:	0207c563          	bltz	a5,80208618 <hal_block_rw+0x88>
    for (int i = 0; i < 3; i++) {
    802085f2:	2905                	addiw	s2,s2,1
    802085f4:	0611                	addi	a2,a2,4 # 2004 <_entry-0x801fdffc>
    802085f6:	05590f63          	beq	s2,s5,80208654 <hal_block_rw+0xc4>
        idx[i] = alloc_desc();
    802085fa:	85b2                	mv	a1,a2
    for (int i = 0; i < VNUM; i++)
    802085fc:	0014f717          	auipc	a4,0x14f
    80208600:	a0470713          	addi	a4,a4,-1532 # 80357000 <vdisk>
    80208604:	87ce                	mv	a5,s3
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80208606:	02874683          	lbu	a3,40(a4)
    8020860a:	fee9                	bnez	a3,802085e4 <hal_block_rw+0x54>
    for (int i = 0; i < VNUM; i++)
    8020860c:	2785                	addiw	a5,a5,1
    8020860e:	0705                	addi	a4,a4,1
    80208610:	fe979be3          	bne	a5,s1,80208606 <hal_block_rw+0x76>
        idx[i] = alloc_desc();
    80208614:	57fd                	li	a5,-1
    80208616:	c19c                	sw	a5,0(a1)
            for (int j = 0; j < i; j++) free_desc(idx[j]);
    80208618:	03205163          	blez	s2,8020863a <hal_block_rw+0xaa>
    8020861c:	f9042503          	lw	a0,-112(s0)
    80208620:	00000097          	auipc	ra,0x0
    80208624:	c66080e7          	jalr	-922(ra) # 80208286 <free_desc>
    80208628:	4785                	li	a5,1
    8020862a:	0127d863          	bge	a5,s2,8020863a <hal_block_rw+0xaa>
    8020862e:	f9442503          	lw	a0,-108(s0)
    80208632:	00000097          	auipc	ra,0x0
    80208636:	c54080e7          	jalr	-940(ra) # 80208286 <free_desc>
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    8020863a:	85de                	mv	a1,s7
    8020863c:	0014f517          	auipc	a0,0x14f
    80208640:	9ec50513          	addi	a0,a0,-1556 # 80357028 <vdisk+0x28>
    80208644:	ffffa097          	auipc	ra,0xffffa
    80208648:	aa2080e7          	jalr	-1374(ra) # 802020e6 <sleep>
    for (int i = 0; i < 3; i++) {
    8020864c:	f9040613          	addi	a2,s0,-112
    80208650:	894e                	mv	s2,s3
    80208652:	b765                	j	802085fa <hal_block_rw+0x6a>

    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80208654:	f9042683          	lw	a3,-112(s0)
    80208658:	00268793          	addi	a5,a3,2
    8020865c:	0796                	slli	a5,a5,0x5
    req->type     = write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN;
    8020865e:	0014f597          	auipc	a1,0x14f
    80208662:	9a258593          	addi	a1,a1,-1630 # 80357000 <vdisk>
    80208666:	00569713          	slli	a4,a3,0x5
    8020866a:	972e                	add	a4,a4,a1
    8020866c:	01903633          	snez	a2,s9
    80208670:	c330                	sw	a2,64(a4)
    req->reserved = 0;
    80208672:	04072223          	sw	zero,68(a4)
    req->sector   = sector;
    80208676:	05873423          	sd	s8,72(a4)

    vdisk.desc[idx[0]] = (struct virtq_desc){
    8020867a:	00469613          	slli	a2,a3,0x4
    8020867e:	6998                	ld	a4,16(a1)
    80208680:	9732                	add	a4,a4,a2
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80208682:	f9442603          	lw	a2,-108(s0)
    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80208686:	00f58533          	add	a0,a1,a5
    vdisk.desc[idx[0]] = (struct virtq_desc){
    8020868a:	e308                	sd	a0,0(a4)
    8020868c:	4541                	li	a0,16
    8020868e:	c708                	sw	a0,8(a4)
    80208690:	4505                	li	a0,1
    80208692:	00a71623          	sh	a0,12(a4)
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80208696:	00c71723          	sh	a2,14(a4)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    8020869a:	0612                	slli	a2,a2,0x4
    8020869c:	6998                	ld	a4,16(a1)
    8020869e:	9732                	add	a4,a4,a2
        (uint64)b->data, BSIZE,
    802086a0:	058a0513          	addi	a0,s4,88
        (uint16)((write ? 0 : VRING_DESC_F_WRITE) | VRING_DESC_F_NEXT),
    802086a4:	460d                	li	a2,3
    802086a6:	000c8363          	beqz	s9,802086ac <hal_block_rw+0x11c>
    802086aa:	4605                	li	a2,1
        (uint16)idx[2] };
    802086ac:	f9842583          	lw	a1,-104(s0)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    802086b0:	e308                	sd	a0,0(a4)
    802086b2:	40000513          	li	a0,1024
    802086b6:	c708                	sw	a0,8(a4)
    802086b8:	00c71623          	sh	a2,12(a4)
        (uint16)idx[2] };
    802086bc:	00b71723          	sh	a1,14(a4)
    vdisk.info[idx[0]].status = 0xff;             /* device overwrites on success */
    802086c0:	0014f717          	auipc	a4,0x14f
    802086c4:	94070713          	addi	a4,a4,-1728 # 80357000 <vdisk>
    802086c8:	00268613          	addi	a2,a3,2
    802086cc:	0616                	slli	a2,a2,0x5
    802086ce:	963a                	add	a2,a2,a4
    802086d0:	557d                	li	a0,-1
    802086d2:	00a60823          	sb	a0,16(a2)
    vdisk.desc[idx[2]] = (struct virtq_desc){
    802086d6:	0592                	slli	a1,a1,0x4
    802086d8:	6b10                	ld	a2,16(a4)
    802086da:	962e                	add	a2,a2,a1
        (uint64)&vdisk.info[idx[0]].status, 1, VRING_DESC_F_WRITE, 0 };
    802086dc:	07c1                	addi	a5,a5,16
    802086de:	97ba                	add	a5,a5,a4
    vdisk.desc[idx[2]] = (struct virtq_desc){
    802086e0:	e21c                	sd	a5,0(a2)
    802086e2:	4585                	li	a1,1
    802086e4:	c60c                	sw	a1,8(a2)
    802086e6:	4789                	li	a5,2
    802086e8:	00f61623          	sh	a5,12(a2)
    802086ec:	00061723          	sh	zero,14(a2)

    b->disk = 1;                                  /* I2: device owns b->data */
    802086f0:	00ba2223          	sw	a1,4(s4)
    vdisk.info[idx[0]].b = b;                     /* I3 */
    802086f4:	00569793          	slli	a5,a3,0x5
    802086f8:	97ba                	add	a5,a5,a4
    802086fa:	0347bc23          	sd	s4,56(a5)

    vdisk.avail->ring[vdisk.avail->idx % VNUM] = idx[0];
    802086fe:	6f10                	ld	a2,24(a4)
    80208700:	00265783          	lhu	a5,2(a2)
    80208704:	8b9d                	andi	a5,a5,7
    80208706:	0786                	slli	a5,a5,0x1
    80208708:	963e                	add	a2,a2,a5
    8020870a:	00d61223          	sh	a3,4(a2)
    __sync_synchronize();          /* ring entry visible BEFORE idx bump */
    8020870e:	0ff0000f          	fence
    vdisk.avail->idx += 1;
    80208712:	6f14                	ld	a3,24(a4)
    80208714:	0026d783          	lhu	a5,2(a3)
    80208718:	2785                	addiw	a5,a5,1
    8020871a:	00f69123          	sh	a5,2(a3)
    __sync_synchronize();          /* idx visible BEFORE the doorbell    */
    8020871e:	0ff0000f          	fence
    *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0;
    80208722:	631c                	ld	a5,0(a4)
    80208724:	0407a823          	sw	zero,80(a5)

    while (b->disk == 1)
    80208728:	004a2783          	lw	a5,4(s4)
    8020872c:	02b79163          	bne	a5,a1,8020874e <hal_block_rw+0x1be>
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    80208730:	0014f917          	auipc	s2,0x14f
    80208734:	a0890913          	addi	s2,s2,-1528 # 80357138 <vdisk+0x138>
    while (b->disk == 1)
    80208738:	4485                	li	s1,1
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    8020873a:	85ca                	mv	a1,s2
    8020873c:	8552                	mv	a0,s4
    8020873e:	ffffa097          	auipc	ra,0xffffa
    80208742:	9a8080e7          	jalr	-1624(ra) # 802020e6 <sleep>
    while (b->disk == 1)
    80208746:	004a2783          	lw	a5,4(s4)
    8020874a:	fe9788e3          	beq	a5,s1,8020873a <hal_block_rw+0x1aa>

    vdisk.info[idx[0]].b = 0;
    8020874e:	f9042503          	lw	a0,-112(s0)
    80208752:	00551713          	slli	a4,a0,0x5
    80208756:	0014f797          	auipc	a5,0x14f
    8020875a:	8aa78793          	addi	a5,a5,-1878 # 80357000 <vdisk>
    8020875e:	97ba                	add	a5,a5,a4
    80208760:	0207bc23          	sd	zero,56(a5)
    free_desc(idx[0]); free_desc(idx[1]); free_desc(idx[2]);
    80208764:	00000097          	auipc	ra,0x0
    80208768:	b22080e7          	jalr	-1246(ra) # 80208286 <free_desc>
    8020876c:	f9442503          	lw	a0,-108(s0)
    80208770:	00000097          	auipc	ra,0x0
    80208774:	b16080e7          	jalr	-1258(ra) # 80208286 <free_desc>
    80208778:	f9842503          	lw	a0,-104(s0)
    8020877c:	00000097          	auipc	ra,0x0
    80208780:	b0a080e7          	jalr	-1270(ra) # 80208286 <free_desc>

    release(&vdisk.lock);
    80208784:	0014f517          	auipc	a0,0x14f
    80208788:	9b450513          	addi	a0,a0,-1612 # 80357138 <vdisk+0x138>
    8020878c:	ffff9097          	auipc	ra,0xffff9
    80208790:	db0080e7          	jalr	-592(ra) # 8020153c <release>
}
    80208794:	70a6                	ld	ra,104(sp)
    80208796:	7406                	ld	s0,96(sp)
    80208798:	64e6                	ld	s1,88(sp)
    8020879a:	6946                	ld	s2,80(sp)
    8020879c:	69a6                	ld	s3,72(sp)
    8020879e:	6a06                	ld	s4,64(sp)
    802087a0:	7ae2                	ld	s5,56(sp)
    802087a2:	7b42                	ld	s6,48(sp)
    802087a4:	7ba2                	ld	s7,40(sp)
    802087a6:	7c02                	ld	s8,32(sp)
    802087a8:	6ce2                	ld	s9,24(sp)
    802087aa:	6165                	addi	sp,sp,112
    802087ac:	8082                	ret

00000000802087ae <hal_block_intr>:

void hal_block_intr(void)
{
    802087ae:	1101                	addi	sp,sp,-32
    802087b0:	ec06                	sd	ra,24(sp)
    802087b2:	e822                	sd	s0,16(sp)
    802087b4:	e426                	sd	s1,8(sp)
    802087b6:	1000                	addi	s0,sp,32
    acquire(&vdisk.lock);
    802087b8:	0014f497          	auipc	s1,0x14f
    802087bc:	84848493          	addi	s1,s1,-1976 # 80357000 <vdisk>
    802087c0:	0014f517          	auipc	a0,0x14f
    802087c4:	97850513          	addi	a0,a0,-1672 # 80357138 <vdisk+0x138>
    802087c8:	ffff9097          	auipc	ra,0xffff9
    802087cc:	cc0080e7          	jalr	-832(ra) # 80201488 <acquire>

    /* Ack FIRST: a completion that lands after this read re-raises the
     * interrupt instead of being lost. */
    *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    802087d0:	6098                	ld	a4,0(s1)
    802087d2:	533c                	lw	a5,96(a4)
    802087d4:	8b8d                	andi	a5,a5,3
    802087d6:	d37c                	sw	a5,100(a4)
    __sync_synchronize();
    802087d8:	0ff0000f          	fence

    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    802087dc:	709c                	ld	a5,32(s1)
    802087de:	0304d703          	lhu	a4,48(s1)
    802087e2:	0027d783          	lhu	a5,2(a5)
    802087e6:	04f70e63          	beq	a4,a5,80208842 <hal_block_intr+0x94>
    802087ea:	e04a                	sd	s2,0(sp)

        if (vdisk.info[id].status != 0)
            panic("virtio_blk: request failed (status byte nonzero)");

        struct buf *b = vdisk.info[id].b;
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    802087ec:	4905                	li	s2,1
        __sync_synchronize();
    802087ee:	0ff0000f          	fence
        int id = vdisk.used->ring[vdisk.used_idx % VNUM].id;
    802087f2:	7098                	ld	a4,32(s1)
    802087f4:	0304d783          	lhu	a5,48(s1)
    802087f8:	8b9d                	andi	a5,a5,7
    802087fa:	078e                	slli	a5,a5,0x3
    802087fc:	97ba                	add	a5,a5,a4
    802087fe:	43dc                	lw	a5,4(a5)
        if (vdisk.info[id].status != 0)
    80208800:	00278713          	addi	a4,a5,2
    80208804:	0716                	slli	a4,a4,0x5
    80208806:	9726                	add	a4,a4,s1
    80208808:	01074703          	lbu	a4,16(a4)
    8020880c:	eb21                	bnez	a4,8020885c <hal_block_intr+0xae>
        struct buf *b = vdisk.info[id].b;
    8020880e:	0796                	slli	a5,a5,0x5
    80208810:	97a6                	add	a5,a5,s1
    80208812:	7f88                	ld	a0,56(a5)
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    80208814:	cd21                	beqz	a0,8020886c <hal_block_intr+0xbe>
    80208816:	415c                	lw	a5,4(a0)
    80208818:	05279a63          	bne	a5,s2,8020886c <hal_block_intr+0xbe>
        b->disk = 0;                              /* I2: hart owns data again */
    8020881c:	00052223          	sw	zero,4(a0)
        wakeup(b);
    80208820:	ffffa097          	auipc	ra,0xffffa
    80208824:	a4c080e7          	jalr	-1460(ra) # 8020226c <wakeup>

        vdisk.used_idx += 1;
    80208828:	0304d783          	lhu	a5,48(s1)
    8020882c:	2785                	addiw	a5,a5,1
    8020882e:	17c2                	slli	a5,a5,0x30
    80208830:	93c1                	srli	a5,a5,0x30
    80208832:	02f49823          	sh	a5,48(s1)
    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    80208836:	7098                	ld	a4,32(s1)
    80208838:	00275703          	lhu	a4,2(a4)
    8020883c:	faf719e3          	bne	a4,a5,802087ee <hal_block_intr+0x40>
    80208840:	6902                	ld	s2,0(sp)
    }
    release(&vdisk.lock);
    80208842:	0014f517          	auipc	a0,0x14f
    80208846:	8f650513          	addi	a0,a0,-1802 # 80357138 <vdisk+0x138>
    8020884a:	ffff9097          	auipc	ra,0xffff9
    8020884e:	cf2080e7          	jalr	-782(ra) # 8020153c <release>
}
    80208852:	60e2                	ld	ra,24(sp)
    80208854:	6442                	ld	s0,16(sp)
    80208856:	64a2                	ld	s1,8(sp)
    80208858:	6105                	addi	sp,sp,32
    8020885a:	8082                	ret
            panic("virtio_blk: request failed (status byte nonzero)");
    8020885c:	00001517          	auipc	a0,0x1
    80208860:	6a450513          	addi	a0,a0,1700 # 80209f00 <etext+0xf00>
    80208864:	ffff8097          	auipc	ra,0xffff8
    80208868:	db2080e7          	jalr	-590(ra) # 80200616 <panic>
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    8020886c:	00001517          	auipc	a0,0x1
    80208870:	6cc50513          	addi	a0,a0,1740 # 80209f38 <etext+0xf38>
    80208874:	ffff8097          	auipc	ra,0xffff8
    80208878:	da2080e7          	jalr	-606(ra) # 80200616 <panic>
