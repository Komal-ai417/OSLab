kernel/syscall.o: kernel/syscall.c kernel/types.h kernel/defs.h \
 kernel/riscv.h kernel/stat.h kernel/param.h kernel/fs.h kernel/buf.h \
 kernel/file.h kernel/syscallnums.h kernel/futex.h kernel/pstat.h \
 kernel/syscalltab.h
