kernel/trace.o: kernel/trace.c kernel/types.h kernel/defs.h \
 kernel/riscv.h kernel/stat.h kernel/param.h kernel/fs.h kernel/buf.h \
 kernel/file.h kernel/syscallnums.h hal/hal.h kernel/types.h \
 kernel/trace.h
