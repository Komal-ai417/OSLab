kernel/log.o: kernel/log.c kernel/types.h kernel/defs.h kernel/riscv.h \
 kernel/stat.h kernel/param.h kernel/fs.h kernel/buf.h kernel/file.h \
 kernel/syscallnums.h
