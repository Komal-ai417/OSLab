/* GENERATED from kernel/syscall.tbl. Included ONLY by syscall.c. */
extern uint64 sys_fork(void);
extern uint64 sys_exit(void);
extern uint64 sys_wait(void);
extern uint64 sys_pipe(void);
extern uint64 sys_read(void);
extern uint64 sys_kill(void);
extern uint64 sys_exec(void);
extern uint64 sys_fstat(void);
extern uint64 sys_chdir(void);
extern uint64 sys_dup(void);
extern uint64 sys_getpid(void);
extern uint64 sys_sbrk(void);
extern uint64 sys_sleep(void);
extern uint64 sys_uptime(void);
extern uint64 sys_open(void);
extern uint64 sys_write(void);
extern uint64 sys_unlink(void);
extern uint64 sys_link(void);
extern uint64 sys_mkdir(void);
extern uint64 sys_close(void);
extern uint64 sys_freepages(void);
extern uint64 sys_procstat(void);
extern uint64 sys_tracectl(void);
extern uint64 sys_traceread(void);
extern uint64 sys_pgrefstat(void);
extern uint64 sys_pgaudit(void);
extern uint64 sys_clone(void);
extern uint64 sys_gettid(void);
extern uint64 sys_futex(void);
extern uint64 sys_fdstat(void);
extern uint64 sys_abimeta(void);
extern uint64 sys_sigalarm(void);
extern uint64 sys_sigreturn(void);
extern uint64 sys_event_stack(void);
extern uint64 sys_alloc_stats(void);
extern uint64 sys_alloc_audit(void);
extern uint64 sys_rename(void);
extern uint64 sys_mmap(void);
extern uint64 sys_munmap(void);
extern uint64 sys_logtest(void);
extern uint64 sys_logcrash(void);
extern uint64 sys_logverify(void);
extern uint64 sys_fsck(void);
static uint64 (*syscalls[])(void) = {
    [1] sys_fork,
    [2] sys_exit,
    [3] sys_wait,
    [4] sys_pipe,
    [5] sys_read,
    [6] sys_kill,
    [7] sys_exec,
    [8] sys_fstat,
    [9] sys_chdir,
    [10] sys_dup,
    [11] sys_getpid,
    [12] sys_sbrk,
    [13] sys_sleep,
    [14] sys_uptime,
    [15] sys_open,
    [16] sys_write,
    [18] sys_unlink,
    [19] sys_link,
    [20] sys_mkdir,
    [21] sys_close,
    [22] sys_freepages,
    [23] sys_procstat,
    [24] sys_tracectl,
    [25] sys_traceread,
    [26] sys_pgrefstat,
    [27] sys_pgaudit,
    [28] sys_clone,
    [29] sys_gettid,
    [30] sys_futex,
    [31] sys_fdstat,
    [32] sys_abimeta,
    [33] sys_sigalarm,
    [34] sys_sigreturn,
    [35] sys_event_stack,
    [36] sys_alloc_stats,
    [37] sys_alloc_audit,
    [38] sys_rename,
    [39] sys_mmap,
    [40] sys_munmap,
    [41] sys_logtest,
    [42] sys_logcrash,
    [43] sys_logverify,
    [44] sys_fsck,
};
static const char *syscall_names[] = {
    [1] "fork",
    [2] "exit",
    [3] "wait",
    [4] "pipe",
    [5] "read",
    [6] "kill",
    [7] "exec",
    [8] "fstat",
    [9] "chdir",
    [10] "dup",
    [11] "getpid",
    [12] "sbrk",
    [13] "sleep",
    [14] "uptime",
    [15] "open",
    [16] "write",
    [18] "unlink",
    [19] "link",
    [20] "mkdir",
    [21] "close",
    [22] "freepages",
    [23] "procstat",
    [24] "tracectl",
    [25] "traceread",
    [26] "pgrefstat",
    [27] "pgaudit",
    [28] "clone",
    [29] "gettid",
    [30] "futex",
    [31] "fdstat",
    [32] "abimeta",
    [33] "sigalarm",
    [34] "sigreturn",
    [35] "event_stack",
    [36] "alloc_stats",
    [37] "alloc_audit",
    [38] "rename",
    [39] "mmap",
    [40] "munmap",
    [41] "logtest",
    [42] "logcrash",
    [43] "logverify",
    [44] "fsck",
};
/* silence -Wunused for the names table until Lab 3 uses it */
static inline const char *syscall_name(int n){ return (n > 0 && n < (int)(sizeof(syscall_names)/sizeof(char*)) && syscall_names[n]) ? syscall_names[n] : "?"; }
