
kernel.elf:     file format elf64-littleriscv


Disassembly of section .text:

0000000080200000 <_entry>:
# Implementation note.
# a0 = hartid, a1 = physical address of the FDT blob. Both must survive to start().
.section .text.entry
.globl _entry
_entry:
        la      t0, boot_stacks
    80200000:	00009297          	auipc	t0,0x9
    80200004:	00028293          	mv	t0,t0
        li      t1, 16384
    80200008:	6311                	lui	t1,0x4
        addi    t2, a0, 1
    8020000a:	00150393          	addi	t2,a0,1
        mul     t1, t1, t2
    8020000e:	02730333          	mul	t1,t1,t2
        add     sp, t0, t1      # sp = boot_stacks + (hartid+1)*16384
    80200012:	00628133          	add	sp,t0,t1
        mv      tp, a0          # tp = hartid, for mycpu()
    80200016:	822a                	mv	tp,a0
        call    start
    80200018:	00000097          	auipc	ra,0x0
    8020001c:	00e080e7          	jalr	14(ra) # 80200026 <start>

0000000080200020 <spin>:
spin:   wfi
    80200020:	10500073          	wfi
        j       spin
    80200024:	bff5                	j	80200020 <spin>

0000000080200026 <start>:
    printf("hart %d: online\n", hal_hart_id());
    scheduler();            /* never returns */
}

void start(uint64 hartid, uint64 fdt_pa)
{
    80200026:	7179                	addi	sp,sp,-48
    80200028:	f406                	sd	ra,40(sp)
    8020002a:	f022                	sd	s0,32(sp)
    8020002c:	1800                	addi	s0,sp,48
        }

        scheduler();
    } else {
        /* --- secondary harts --- */
        while (started == 0)
    8020002e:	0013f717          	auipc	a4,0x13f
    80200032:	fd270713          	addi	a4,a4,-46 # 8033f000 <started>
    if (hartid == 0) {
    80200036:	c139                	beqz	a0,8020007c <start+0x56>
    80200038:	ec26                	sd	s1,24(sp)
    8020003a:	e84a                	sd	s2,16(sp)
    8020003c:	e44e                	sd	s3,8(sp)
    8020003e:	e052                	sd	s4,0(sp)
        while (started == 0)
    80200040:	431c                	lw	a5,0(a4)
    80200042:	2781                	sext.w	a5,a5
    80200044:	dff5                	beqz	a5,80200040 <start+0x1a>
            ;
        __sync_synchronize();
    80200046:	0ff0000f          	fence
    kvminithart();          /* same kernel page table */
    8020004a:	00003097          	auipc	ra,0x3
    8020004e:	c74080e7          	jalr	-908(ra) # 80202cbe <kvminithart>
    trapinit_hart();        /* own stvec, own timer, own PLIC context */
    80200052:	00002097          	auipc	ra,0x2
    80200056:	39c080e7          	jalr	924(ra) # 802023ee <trapinit_hart>
    printf("hart %d: online\n", hal_hart_id());
    8020005a:	00006097          	auipc	ra,0x6
    8020005e:	028080e7          	jalr	40(ra) # 80206082 <hal_hart_id>
    80200062:	85aa                	mv	a1,a0
    80200064:	00007517          	auipc	a0,0x7
    80200068:	11c50513          	addi	a0,a0,284 # 80207180 <etext+0x180>
    8020006c:	00000097          	auipc	ra,0x0
    80200070:	2dc080e7          	jalr	732(ra) # 80200348 <printf>
    scheduler();            /* never returns */
    80200074:	00002097          	auipc	ra,0x2
    80200078:	ad2080e7          	jalr	-1326(ra) # 80201b46 <scheduler>
    8020007c:	ec26                	sd	s1,24(sp)
    8020007e:	e84a                	sd	s2,16(sp)
    80200080:	e44e                	sd	s3,8(sp)
        fdt_init(fdt_pa);
    80200082:	852e                	mv	a0,a1
    80200084:	00001097          	auipc	ra,0x1
    80200088:	836080e7          	jalr	-1994(ra) # 802008ba <fdt_init>
        printf("\n");
    8020008c:	00007517          	auipc	a0,0x7
    80200090:	f7450513          	addi	a0,a0,-140 # 80207000 <etext>
    80200094:	00000097          	auipc	ra,0x0
    80200098:	2b4080e7          	jalr	692(ra) # 80200348 <printf>
        printf("=========================================\n");
    8020009c:	00007517          	auipc	a0,0x7
    802000a0:	f6c50513          	addi	a0,a0,-148 # 80207008 <etext+0x8>
    802000a4:	00000097          	auipc	ra,0x0
    802000a8:	2a4080e7          	jalr	676(ra) # 80200348 <printf>
        printf("  BrahmaputraOS / kernel Luit\n");
    802000ac:	00007517          	auipc	a0,0x7
    802000b0:	f8c50513          	addi	a0,a0,-116 # 80207038 <etext+0x38>
    802000b4:	00000097          	auipc	ra,0x0
    802000b8:	294080e7          	jalr	660(ra) # 80200348 <printf>
        printf("  IIT Guwahati - CS3106L\n");
    802000bc:	00007517          	auipc	a0,0x7
    802000c0:	f9c50513          	addi	a0,a0,-100 # 80207058 <etext+0x58>
    802000c4:	00000097          	auipc	ra,0x0
    802000c8:	284080e7          	jalr	644(ra) # 80200348 <printf>
        printf("=========================================\n");
    802000cc:	00007517          	auipc	a0,0x7
    802000d0:	f3c50513          	addi	a0,a0,-196 # 80207008 <etext+0x8>
    802000d4:	00000097          	auipc	ra,0x0
    802000d8:	274080e7          	jalr	628(ra) # 80200348 <printf>
        printf("fdt   : blob at %p (%d bytes)\n", fdt.blob, fdt.blob_size);
    802000dc:	00029497          	auipc	s1,0x29
    802000e0:	f3c48493          	addi	s1,s1,-196 # 80229018 <fdt>
    802000e4:	6490                	ld	a2,8(s1)
    802000e6:	608c                	ld	a1,0(s1)
    802000e8:	00007517          	auipc	a0,0x7
    802000ec:	f9050513          	addi	a0,a0,-112 # 80207078 <etext+0x78>
    802000f0:	00000097          	auipc	ra,0x0
    802000f4:	258080e7          	jalr	600(ra) # 80200348 <printf>
        printf("uart  : %p  (discovered, not hardcoded)\n", fdt.uart_base);
    802000f8:	688c                	ld	a1,16(s1)
    802000fa:	00007517          	auipc	a0,0x7
    802000fe:	f9e50513          	addi	a0,a0,-98 # 80207098 <etext+0x98>
    80200102:	00000097          	auipc	ra,0x0
    80200106:	246080e7          	jalr	582(ra) # 80200348 <printf>
        printf("plic  : %p\n", fdt.plic_base);
    8020010a:	6c8c                	ld	a1,24(s1)
    8020010c:	00007517          	auipc	a0,0x7
    80200110:	fbc50513          	addi	a0,a0,-68 # 802070c8 <etext+0xc8>
    80200114:	00000097          	auipc	ra,0x0
    80200118:	234080e7          	jalr	564(ra) # 80200348 <printf>
        printf("memory: %p + %d MiB\n", fdt.mem_base, fdt.mem_size >> 20);
    8020011c:	6cd0                	ld	a2,152(s1)
    8020011e:	8251                	srli	a2,a2,0x14
    80200120:	68cc                	ld	a1,144(s1)
    80200122:	00007517          	auipc	a0,0x7
    80200126:	fb650513          	addi	a0,a0,-74 # 802070d8 <etext+0xd8>
    8020012a:	00000097          	auipc	ra,0x0
    8020012e:	21e080e7          	jalr	542(ra) # 80200348 <printf>
        printf("harts : %d\n", fdt.ncpu);
    80200132:	0a04a583          	lw	a1,160(s1)
    80200136:	00007517          	auipc	a0,0x7
    8020013a:	fba50513          	addi	a0,a0,-70 # 802070f0 <etext+0xf0>
    8020013e:	00000097          	auipc	ra,0x0
    80200142:	20a080e7          	jalr	522(ra) # 80200348 <printf>
        hal_console_init(fdt.uart_base);
    80200146:	6888                	ld	a0,16(s1)
    80200148:	00006097          	auipc	ra,0x6
    8020014c:	fe8080e7          	jalr	-24(ra) # 80206130 <hal_console_init>
        hal_intc_init(fdt.plic_base);
    80200150:	6c88                	ld	a0,24(s1)
    80200152:	00006097          	auipc	ra,0x6
    80200156:	e3a080e7          	jalr	-454(ra) # 80205f8c <hal_intc_init>
        console_ready = 1;
    8020015a:	0013f917          	auipc	s2,0x13f
    8020015e:	eaa90913          	addi	s2,s2,-342 # 8033f004 <console_ready>
    80200162:	4985                	li	s3,1
    80200164:	01392023          	sw	s3,0(s2)
        palloc_init();
    80200168:	00001097          	auipc	ra,0x1
    8020016c:	dde080e7          	jalr	-546(ra) # 80200f46 <palloc_init>
        printfinit();       /* locked printf, now that we have locks + memory */
    80200170:	00000097          	auipc	ra,0x0
    80200174:	418080e7          	jalr	1048(ra) # 80200588 <printfinit>
        procinit();
    80200178:	00001097          	auipc	ra,0x1
    8020017c:	60a080e7          	jalr	1546(ra) # 80201782 <procinit>
        kvminit();
    80200180:	00003097          	auipc	ra,0x3
    80200184:	a2c080e7          	jalr	-1492(ra) # 80202bac <kvminit>
        kvminithart();      /* paging ON for this hart */
    80200188:	00003097          	auipc	ra,0x3
    8020018c:	b36080e7          	jalr	-1226(ra) # 80202cbe <kvminithart>
        console_ready = 0;                    /* SBI console while we re-point */
    80200190:	00092023          	sw	zero,0(s2)
        hal_console_init(mmio_alias(fdt.uart_base));
    80200194:	6888                	ld	a0,16(s1)
    80200196:	00003097          	auipc	ra,0x3
    8020019a:	846080e7          	jalr	-1978(ra) # 802029dc <mmio_alias>
    8020019e:	00006097          	auipc	ra,0x6
    802001a2:	f92080e7          	jalr	-110(ra) # 80206130 <hal_console_init>
        console_ready = 1;
    802001a6:	01392023          	sw	s3,0(s2)
        hal_intc_init(mmio_alias(fdt.plic_base));
    802001aa:	6c88                	ld	a0,24(s1)
    802001ac:	00003097          	auipc	ra,0x3
    802001b0:	830080e7          	jalr	-2000(ra) # 802029dc <mmio_alias>
    802001b4:	00006097          	auipc	ra,0x6
    802001b8:	dd8080e7          	jalr	-552(ra) # 80205f8c <hal_intc_init>
        consoleinit();      /* console device (major CONSOLE)         */
    802001bc:	00004097          	auipc	ra,0x4
    802001c0:	fba080e7          	jalr	-70(ra) # 80204176 <consoleinit>
        binit();            /* buffer cache                           */
    802001c4:	00004097          	auipc	ra,0x4
    802001c8:	546080e7          	jalr	1350(ra) # 8020470a <binit>
        iinit();            /* inode cache                            */
    802001cc:	00005097          	auipc	ra,0x5
    802001d0:	b98080e7          	jalr	-1128(ra) # 80204d64 <iinit>
        fileinit();         /* system-wide open-file table            */
    802001d4:	00005097          	auipc	ra,0x5
    802001d8:	6ba080e7          	jalr	1722(ra) # 8020588e <fileinit>
        if (hal_block_init() < 0)
    802001dc:	00006097          	auipc	ra,0x6
    802001e0:	072080e7          	jalr	114(ra) # 8020624e <hal_block_init>
    802001e4:	04054e63          	bltz	a0,80200240 <start+0x21a>
    802001e8:	e052                	sd	s4,0(sp)
        trapinit_hart();    /* traps, timer, PLIC (incl. the disk irq) */
    802001ea:	00002097          	auipc	ra,0x2
    802001ee:	204080e7          	jalr	516(ra) # 802023ee <trapinit_hart>
        userinit();         /* the first user process                 */
    802001f2:	00001097          	auipc	ra,0x1
    802001f6:	628080e7          	jalr	1576(ra) # 8020181a <userinit>
        printf("hart 0: online\n");
    802001fa:	00007517          	auipc	a0,0x7
    802001fe:	f4e50513          	addi	a0,a0,-178 # 80207148 <etext+0x148>
    80200202:	00000097          	auipc	ra,0x0
    80200206:	146080e7          	jalr	326(ra) # 80200348 <printf>
        __sync_synchronize();
    8020020a:	0ff0000f          	fence
        started = 1;
    8020020e:	4785                	li	a5,1
    80200210:	0013f717          	auipc	a4,0x13f
    80200214:	def72823          	sw	a5,-528(a4) # 8033f000 <started>
        for (int i = 1; i < fdt.ncpu; i++) {
    80200218:	00029717          	auipc	a4,0x29
    8020021c:	ea072703          	lw	a4,-352(a4) # 802290b8 <fdt+0xa0>
    80200220:	06e7d163          	bge	a5,a4,80200282 <start+0x25c>
    80200224:	4485                	li	s1,1
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    80200226:	00000997          	auipc	s3,0x0
    8020022a:	dda98993          	addi	s3,s3,-550 # 80200000 <_entry>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    8020022e:	00007a17          	auipc	s4,0x7
    80200232:	f2aa0a13          	addi	s4,s4,-214 # 80207158 <etext+0x158>
        for (int i = 1; i < fdt.ncpu; i++) {
    80200236:	00029917          	auipc	s2,0x29
    8020023a:	de290913          	addi	s2,s2,-542 # 80229018 <fdt>
    8020023e:	a00d                	j	80200260 <start+0x23a>
    80200240:	e052                	sd	s4,0(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
    80200242:	00007517          	auipc	a0,0x7
    80200246:	ebe50513          	addi	a0,a0,-322 # 80207100 <etext+0x100>
    8020024a:	00000097          	auipc	ra,0x0
    8020024e:	370080e7          	jalr	880(ra) # 802005ba <panic>
        for (int i = 1; i < fdt.ncpu; i++) {
    80200252:	0485                	addi	s1,s1,1
    80200254:	0a092703          	lw	a4,160(s2)
    80200258:	0004879b          	sext.w	a5,s1
    8020025c:	02e7d363          	bge	a5,a4,80200282 <start+0x25c>
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    80200260:	4601                	li	a2,0
    80200262:	85ce                	mv	a1,s3
    80200264:	8526                	mv	a0,s1
    80200266:	00000097          	auipc	ra,0x0
    8020026a:	574080e7          	jalr	1396(ra) # 802007da <sbi_hart_start>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    8020026e:	d175                	beqz	a0,80200252 <start+0x22c>
    80200270:	862a                	mv	a2,a0
    80200272:	0004859b          	sext.w	a1,s1
    80200276:	8552                	mv	a0,s4
    80200278:	00000097          	auipc	ra,0x0
    8020027c:	0d0080e7          	jalr	208(ra) # 80200348 <printf>
    80200280:	bfc9                	j	80200252 <start+0x22c>
        scheduler();
    80200282:	00002097          	auipc	ra,0x2
    80200286:	8c4080e7          	jalr	-1852(ra) # 80201b46 <scheduler>

000000008020028a <putc>:

/* Before the UART driver exists (i.e. before the device tree has told us where
 * the UART is), fall back to OpenSBI's console. This is why a panic inside
 * fdt_init() is still visible - a silent early panic is a nightmare to debug. */
int console_ready = 0;
static void putc(char c) { if (console_ready) hal_console_putc(c); else sbi_putchar(c); }
    8020028a:	1141                	addi	sp,sp,-16
    8020028c:	e406                	sd	ra,8(sp)
    8020028e:	e022                	sd	s0,0(sp)
    80200290:	0800                	addi	s0,sp,16
    80200292:	0013f797          	auipc	a5,0x13f
    80200296:	d727a783          	lw	a5,-654(a5) # 8033f004 <console_ready>
    8020029a:	cb89                	beqz	a5,802002ac <putc+0x22>
    8020029c:	00006097          	auipc	ra,0x6
    802002a0:	ece080e7          	jalr	-306(ra) # 8020616a <hal_console_putc>
    802002a4:	60a2                	ld	ra,8(sp)
    802002a6:	6402                	ld	s0,0(sp)
    802002a8:	0141                	addi	sp,sp,16
    802002aa:	8082                	ret
    802002ac:	00000097          	auipc	ra,0x0
    802002b0:	4dc080e7          	jalr	1244(ra) # 80200788 <sbi_putchar>
    802002b4:	bfc5                	j	802002a4 <putc+0x1a>

00000000802002b6 <printint>:

static void printint(long long xx, int base, int sign)
{
    802002b6:	7139                	addi	sp,sp,-64
    802002b8:	fc06                	sd	ra,56(sp)
    802002ba:	f822                	sd	s0,48(sp)
    802002bc:	0080                	addi	s0,sp,64
    char buf[24];
    int i = 0;
    unsigned long long x;

    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    802002be:	c219                	beqz	a2,802002c4 <printint+0xe>
    802002c0:	08054163          	bltz	a0,80200342 <printint+0x8c>
    802002c4:	4601                	li	a2,0
    802002c6:	fc840693          	addi	a3,s0,-56
    802002ca:	4781                	li	a5,0
    do { buf[i++] = digits[x % base]; } while ((x /= base) != 0);
    802002cc:	00008817          	auipc	a6,0x8
    802002d0:	aec80813          	addi	a6,a6,-1300 # 80207db8 <digits>
    802002d4:	88be                	mv	a7,a5
    802002d6:	2785                	addiw	a5,a5,1
    802002d8:	02b57733          	remu	a4,a0,a1
    802002dc:	9742                	add	a4,a4,a6
    802002de:	00074703          	lbu	a4,0(a4)
    802002e2:	00e68023          	sb	a4,0(a3)
    802002e6:	872a                	mv	a4,a0
    802002e8:	02b55533          	divu	a0,a0,a1
    802002ec:	0685                	addi	a3,a3,1
    802002ee:	feb773e3          	bgeu	a4,a1,802002d4 <printint+0x1e>
    if (sign) buf[i++] = '-';
    802002f2:	ca09                	beqz	a2,80200304 <printint+0x4e>
    802002f4:	1781                	addi	a5,a5,-32
    802002f6:	97a2                	add	a5,a5,s0
    802002f8:	02d00713          	li	a4,45
    802002fc:	fee78423          	sb	a4,-24(a5)
    80200300:	0028879b          	addiw	a5,a7,2
    while (--i >= 0) putc(buf[i]);
    80200304:	02f05b63          	blez	a5,8020033a <printint+0x84>
    80200308:	f426                	sd	s1,40(sp)
    8020030a:	f04a                	sd	s2,32(sp)
    8020030c:	fc840713          	addi	a4,s0,-56
    80200310:	00f704b3          	add	s1,a4,a5
    80200314:	fff70913          	addi	s2,a4,-1
    80200318:	993e                	add	s2,s2,a5
    8020031a:	37fd                	addiw	a5,a5,-1
    8020031c:	1782                	slli	a5,a5,0x20
    8020031e:	9381                	srli	a5,a5,0x20
    80200320:	40f90933          	sub	s2,s2,a5
    80200324:	fff4c503          	lbu	a0,-1(s1)
    80200328:	00000097          	auipc	ra,0x0
    8020032c:	f62080e7          	jalr	-158(ra) # 8020028a <putc>
    80200330:	14fd                	addi	s1,s1,-1
    80200332:	ff2499e3          	bne	s1,s2,80200324 <printint+0x6e>
    80200336:	74a2                	ld	s1,40(sp)
    80200338:	7902                	ld	s2,32(sp)
}
    8020033a:	70e2                	ld	ra,56(sp)
    8020033c:	7442                	ld	s0,48(sp)
    8020033e:	6121                	addi	sp,sp,64
    80200340:	8082                	ret
    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    80200342:	40a00533          	neg	a0,a0
    80200346:	b741                	j	802002c6 <printint+0x10>

0000000080200348 <printf>:
    for (int i = 0; i < 16; i++, x <<= 4)
        putc(digits[x >> 60]);
}

void printf(const char *fmt, ...)
{
    80200348:	7171                	addi	sp,sp,-176
    8020034a:	f486                	sd	ra,104(sp)
    8020034c:	f0a2                	sd	s0,96(sp)
    8020034e:	e0d2                	sd	s4,64(sp)
    80200350:	f062                	sd	s8,32(sp)
    80200352:	1880                	addi	s0,sp,112
    80200354:	8a2a                	mv	s4,a0
    80200356:	e40c                	sd	a1,8(s0)
    80200358:	e810                	sd	a2,16(s0)
    8020035a:	ec14                	sd	a3,24(s0)
    8020035c:	f018                	sd	a4,32(s0)
    8020035e:	f41c                	sd	a5,40(s0)
    80200360:	03043823          	sd	a6,48(s0)
    80200364:	03143c23          	sd	a7,56(s0)
    va_list ap;
    int locking = pr_locking;
    80200368:	0013fc17          	auipc	s8,0x13f
    8020036c:	ca0c2c03          	lw	s8,-864(s8) # 8033f008 <pr_locking>
    if (locking) acquire(&pr_lock);
    80200370:	020c1863          	bnez	s8,802003a0 <printf+0x58>

    va_start(ap, fmt);
    80200374:	00840793          	addi	a5,s0,8
    80200378:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    8020037c:	00054503          	lbu	a0,0(a0)
    80200380:	1e050063          	beqz	a0,80200560 <printf+0x218>
    80200384:	eca6                	sd	s1,88(sp)
    80200386:	e8ca                	sd	s2,80(sp)
    80200388:	fc56                	sd	s5,56(sp)
    8020038a:	f85a                	sd	s6,48(sp)
    8020038c:	f45e                	sd	s7,40(sp)
    8020038e:	4481                	li	s1,0
        char c = fmt[i];
        if (c != '%') { putc(c); continue; }
    80200390:	02500a93          	li	s5,37
        c = fmt[++i];
        if (!c) break;
        switch (c) {
    80200394:	4b55                	li	s6,21
    80200396:	00008b97          	auipc	s7,0x8
    8020039a:	9cab8b93          	addi	s7,s7,-1590 # 80207d60 <etext+0xd60>
    8020039e:	a825                	j	802003d6 <printf+0x8e>
    if (locking) acquire(&pr_lock);
    802003a0:	00029517          	auipc	a0,0x29
    802003a4:	c6050513          	addi	a0,a0,-928 # 80229000 <pr_lock>
    802003a8:	00001097          	auipc	ra,0x1
    802003ac:	f48080e7          	jalr	-184(ra) # 802012f0 <acquire>
    va_start(ap, fmt);
    802003b0:	00840793          	addi	a5,s0,8
    802003b4:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003b8:	000a4503          	lbu	a0,0(s4)
    802003bc:	f561                	bnez	a0,80200384 <printf+0x3c>
    802003be:	aa65                	j	80200576 <printf+0x22e>
        if (c != '%') { putc(c); continue; }
    802003c0:	00000097          	auipc	ra,0x0
    802003c4:	eca080e7          	jalr	-310(ra) # 8020028a <putc>
    for (int i = 0; fmt[i]; i++) {
    802003c8:	2485                	addiw	s1,s1,1
    802003ca:	009a07b3          	add	a5,s4,s1
    802003ce:	0007c503          	lbu	a0,0(a5)
    802003d2:	18050063          	beqz	a0,80200552 <printf+0x20a>
        if (c != '%') { putc(c); continue; }
    802003d6:	ff5515e3          	bne	a0,s5,802003c0 <printf+0x78>
        c = fmt[++i];
    802003da:	2485                	addiw	s1,s1,1
    802003dc:	009a07b3          	add	a5,s4,s1
    802003e0:	0007c903          	lbu	s2,0(a5)
        if (!c) break;
    802003e4:	16090763          	beqz	s2,80200552 <printf+0x20a>
        switch (c) {
    802003e8:	15590263          	beq	s2,s5,8020052c <printf+0x1e4>
    802003ec:	f9d9079b          	addiw	a5,s2,-99
    802003f0:	0ff7f793          	zext.b	a5,a5
    802003f4:	14fb6363          	bltu	s6,a5,8020053a <printf+0x1f2>
    802003f8:	f9d9079b          	addiw	a5,s2,-99
    802003fc:	0ff7f713          	zext.b	a4,a5
    80200400:	12eb6d63          	bltu	s6,a4,8020053a <printf+0x1f2>
    80200404:	00271793          	slli	a5,a4,0x2
    80200408:	97de                	add	a5,a5,s7
    8020040a:	439c                	lw	a5,0(a5)
    8020040c:	97de                	add	a5,a5,s7
    8020040e:	8782                	jr	a5
        case 'd': printint(va_arg(ap, int), 10, 1); break;
    80200410:	f9843783          	ld	a5,-104(s0)
    80200414:	00878713          	addi	a4,a5,8
    80200418:	f8e43c23          	sd	a4,-104(s0)
    8020041c:	4605                	li	a2,1
    8020041e:	45a9                	li	a1,10
    80200420:	4388                	lw	a0,0(a5)
    80200422:	00000097          	auipc	ra,0x0
    80200426:	e94080e7          	jalr	-364(ra) # 802002b6 <printint>
    8020042a:	bf79                	j	802003c8 <printf+0x80>
        case 'l': printint(va_arg(ap, uint64), 10, 0); break;
    8020042c:	f9843783          	ld	a5,-104(s0)
    80200430:	00878713          	addi	a4,a5,8
    80200434:	f8e43c23          	sd	a4,-104(s0)
    80200438:	4601                	li	a2,0
    8020043a:	45a9                	li	a1,10
    8020043c:	6388                	ld	a0,0(a5)
    8020043e:	00000097          	auipc	ra,0x0
    80200442:	e78080e7          	jalr	-392(ra) # 802002b6 <printint>
    80200446:	b749                	j	802003c8 <printf+0x80>
        case 'u': printint(va_arg(ap, uint64), 10, 0); break;
    80200448:	f9843783          	ld	a5,-104(s0)
    8020044c:	00878713          	addi	a4,a5,8
    80200450:	f8e43c23          	sd	a4,-104(s0)
    80200454:	4601                	li	a2,0
    80200456:	45a9                	li	a1,10
    80200458:	6388                	ld	a0,0(a5)
    8020045a:	00000097          	auipc	ra,0x0
    8020045e:	e5c080e7          	jalr	-420(ra) # 802002b6 <printint>
    80200462:	b79d                	j	802003c8 <printf+0x80>
        case 'x': printint(va_arg(ap, uint64), 16, 0); break;
    80200464:	f9843783          	ld	a5,-104(s0)
    80200468:	00878713          	addi	a4,a5,8
    8020046c:	f8e43c23          	sd	a4,-104(s0)
    80200470:	4601                	li	a2,0
    80200472:	45c1                	li	a1,16
    80200474:	6388                	ld	a0,0(a5)
    80200476:	00000097          	auipc	ra,0x0
    8020047a:	e40080e7          	jalr	-448(ra) # 802002b6 <printint>
    8020047e:	b7a9                	j	802003c8 <printf+0x80>
    80200480:	e4ce                	sd	s3,72(sp)
    80200482:	ec66                	sd	s9,24(sp)
        case 'p': printptr(va_arg(ap, uint64)); break;
    80200484:	f9843783          	ld	a5,-104(s0)
    80200488:	00878713          	addi	a4,a5,8
    8020048c:	f8e43c23          	sd	a4,-104(s0)
    80200490:	0007b983          	ld	s3,0(a5)
    putc('0'); putc('x');
    80200494:	03000513          	li	a0,48
    80200498:	00000097          	auipc	ra,0x0
    8020049c:	df2080e7          	jalr	-526(ra) # 8020028a <putc>
    802004a0:	07800513          	li	a0,120
    802004a4:	00000097          	auipc	ra,0x0
    802004a8:	de6080e7          	jalr	-538(ra) # 8020028a <putc>
    802004ac:	4941                	li	s2,16
        putc(digits[x >> 60]);
    802004ae:	00008c97          	auipc	s9,0x8
    802004b2:	90ac8c93          	addi	s9,s9,-1782 # 80207db8 <digits>
    802004b6:	03c9d793          	srli	a5,s3,0x3c
    802004ba:	97e6                	add	a5,a5,s9
    802004bc:	0007c503          	lbu	a0,0(a5)
    802004c0:	00000097          	auipc	ra,0x0
    802004c4:	dca080e7          	jalr	-566(ra) # 8020028a <putc>
    for (int i = 0; i < 16; i++, x <<= 4)
    802004c8:	0992                	slli	s3,s3,0x4
    802004ca:	397d                	addiw	s2,s2,-1
    802004cc:	fe0915e3          	bnez	s2,802004b6 <printf+0x16e>
    802004d0:	69a6                	ld	s3,72(sp)
    802004d2:	6ce2                	ld	s9,24(sp)
    802004d4:	bdd5                	j	802003c8 <printf+0x80>
        case 'c': putc((char)va_arg(ap, int)); break;
    802004d6:	f9843783          	ld	a5,-104(s0)
    802004da:	00878713          	addi	a4,a5,8
    802004de:	f8e43c23          	sd	a4,-104(s0)
    802004e2:	0007c503          	lbu	a0,0(a5)
    802004e6:	00000097          	auipc	ra,0x0
    802004ea:	da4080e7          	jalr	-604(ra) # 8020028a <putc>
    802004ee:	bde9                	j	802003c8 <printf+0x80>
        case 's': {
            const char *s = va_arg(ap, const char *);
    802004f0:	f9843783          	ld	a5,-104(s0)
    802004f4:	00878713          	addi	a4,a5,8
    802004f8:	f8e43c23          	sd	a4,-104(s0)
    802004fc:	0007b903          	ld	s2,0(a5)
            if (!s) s = "(null)";
    80200500:	00090f63          	beqz	s2,8020051e <printf+0x1d6>
            while (*s) putc(*s++);
    80200504:	00094503          	lbu	a0,0(s2)
    80200508:	ec0500e3          	beqz	a0,802003c8 <printf+0x80>
    8020050c:	0905                	addi	s2,s2,1
    8020050e:	00000097          	auipc	ra,0x0
    80200512:	d7c080e7          	jalr	-644(ra) # 8020028a <putc>
    80200516:	00094503          	lbu	a0,0(s2)
    8020051a:	f96d                	bnez	a0,8020050c <printf+0x1c4>
    8020051c:	b575                	j	802003c8 <printf+0x80>
            if (!s) s = "(null)";
    8020051e:	00007917          	auipc	s2,0x7
    80200522:	c7a90913          	addi	s2,s2,-902 # 80207198 <etext+0x198>
            while (*s) putc(*s++);
    80200526:	02800513          	li	a0,40
    8020052a:	b7cd                	j	8020050c <printf+0x1c4>
            break;
        }
        case '%': putc('%'); break;
    8020052c:	02500513          	li	a0,37
    80200530:	00000097          	auipc	ra,0x0
    80200534:	d5a080e7          	jalr	-678(ra) # 8020028a <putc>
    80200538:	bd41                	j	802003c8 <printf+0x80>
        default:  putc('%'); putc(c); break;
    8020053a:	02500513          	li	a0,37
    8020053e:	00000097          	auipc	ra,0x0
    80200542:	d4c080e7          	jalr	-692(ra) # 8020028a <putc>
    80200546:	854a                	mv	a0,s2
    80200548:	00000097          	auipc	ra,0x0
    8020054c:	d42080e7          	jalr	-702(ra) # 8020028a <putc>
    80200550:	bda5                	j	802003c8 <printf+0x80>
        }
    }
    va_end(ap);
    if (locking) release(&pr_lock);
    80200552:	000c1d63          	bnez	s8,8020056c <printf+0x224>
    80200556:	64e6                	ld	s1,88(sp)
    80200558:	6946                	ld	s2,80(sp)
    8020055a:	7ae2                	ld	s5,56(sp)
    8020055c:	7b42                	ld	s6,48(sp)
    8020055e:	7ba2                	ld	s7,40(sp)
}
    80200560:	70a6                	ld	ra,104(sp)
    80200562:	7406                	ld	s0,96(sp)
    80200564:	6a06                	ld	s4,64(sp)
    80200566:	7c02                	ld	s8,32(sp)
    80200568:	614d                	addi	sp,sp,176
    8020056a:	8082                	ret
    8020056c:	64e6                	ld	s1,88(sp)
    8020056e:	6946                	ld	s2,80(sp)
    80200570:	7ae2                	ld	s5,56(sp)
    80200572:	7b42                	ld	s6,48(sp)
    80200574:	7ba2                	ld	s7,40(sp)
    if (locking) release(&pr_lock);
    80200576:	00029517          	auipc	a0,0x29
    8020057a:	a8a50513          	addi	a0,a0,-1398 # 80229000 <pr_lock>
    8020057e:	00001097          	auipc	ra,0x1
    80200582:	e26080e7          	jalr	-474(ra) # 802013a4 <release>
}
    80200586:	bfe9                	j	80200560 <printf+0x218>

0000000080200588 <printfinit>:

void printfinit(void) { initlock(&pr_lock, "pr"); pr_locking = 1; }
    80200588:	1141                	addi	sp,sp,-16
    8020058a:	e406                	sd	ra,8(sp)
    8020058c:	e022                	sd	s0,0(sp)
    8020058e:	0800                	addi	s0,sp,16
    80200590:	00007597          	auipc	a1,0x7
    80200594:	c1058593          	addi	a1,a1,-1008 # 802071a0 <etext+0x1a0>
    80200598:	00029517          	auipc	a0,0x29
    8020059c:	a6850513          	addi	a0,a0,-1432 # 80229000 <pr_lock>
    802005a0:	00001097          	auipc	ra,0x1
    802005a4:	cd4080e7          	jalr	-812(ra) # 80201274 <initlock>
    802005a8:	4785                	li	a5,1
    802005aa:	0013f717          	auipc	a4,0x13f
    802005ae:	a4f72f23          	sw	a5,-1442(a4) # 8033f008 <pr_locking>
    802005b2:	60a2                	ld	ra,8(sp)
    802005b4:	6402                	ld	s0,0(sp)
    802005b6:	0141                	addi	sp,sp,16
    802005b8:	8082                	ret

00000000802005ba <panic>:

void panic(const char *s)
{
    802005ba:	1101                	addi	sp,sp,-32
    802005bc:	ec06                	sd	ra,24(sp)
    802005be:	e822                	sd	s0,16(sp)
    802005c0:	e426                	sd	s1,8(sp)
    802005c2:	1000                	addi	s0,sp,32
    802005c4:	84aa                	mv	s1,a0
    pr_locking = 0;                       /* never deadlock inside a panic */
    802005c6:	0013f797          	auipc	a5,0x13f
    802005ca:	a407a123          	sw	zero,-1470(a5) # 8033f008 <pr_locking>
    printf("\n=== KERNEL PANIC (hart %d) ===\n", hal_hart_id());
    802005ce:	00006097          	auipc	ra,0x6
    802005d2:	ab4080e7          	jalr	-1356(ra) # 80206082 <hal_hart_id>
    802005d6:	85aa                	mv	a1,a0
    802005d8:	00007517          	auipc	a0,0x7
    802005dc:	bd050513          	addi	a0,a0,-1072 # 802071a8 <etext+0x1a8>
    802005e0:	00000097          	auipc	ra,0x0
    802005e4:	d68080e7          	jalr	-664(ra) # 80200348 <printf>
    printf("  %s\n", s);
    802005e8:	85a6                	mv	a1,s1
    802005ea:	00007517          	auipc	a0,0x7
    802005ee:	be650513          	addi	a0,a0,-1050 # 802071d0 <etext+0x1d0>
    802005f2:	00000097          	auipc	ra,0x0
    802005f6:	d56080e7          	jalr	-682(ra) # 80200348 <printf>
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    802005fa:	141025f3          	csrr	a1,sepc
    printf("  sepc   = %p\n", r_sepc());
    802005fe:	00007517          	auipc	a0,0x7
    80200602:	bda50513          	addi	a0,a0,-1062 # 802071d8 <etext+0x1d8>
    80200606:	00000097          	auipc	ra,0x0
    8020060a:	d42080e7          	jalr	-702(ra) # 80200348 <printf>
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    8020060e:	142025f3          	csrr	a1,scause
    printf("  scause = %p\n", r_scause());
    80200612:	00007517          	auipc	a0,0x7
    80200616:	bd650513          	addi	a0,a0,-1066 # 802071e8 <etext+0x1e8>
    8020061a:	00000097          	auipc	ra,0x0
    8020061e:	d2e080e7          	jalr	-722(ra) # 80200348 <printf>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80200622:	143025f3          	csrr	a1,stval
    printf("  stval  = %p\n", r_stval());
    80200626:	00007517          	auipc	a0,0x7
    8020062a:	bd250513          	addi	a0,a0,-1070 # 802071f8 <etext+0x1f8>
    8020062e:	00000097          	auipc	ra,0x0
    80200632:	d1a080e7          	jalr	-742(ra) # 80200348 <printf>
static inline void   w_sscratch(uint64 x){ asm volatile("csrw sscratch, %0"::"r"(x)); }
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    80200636:	180025f3          	csrr	a1,satp
    printf("  satp   = %p\n", r_satp());
    8020063a:	00007517          	auipc	a0,0x7
    8020063e:	bce50513          	addi	a0,a0,-1074 # 80207208 <etext+0x208>
    80200642:	00000097          	auipc	ra,0x0
    80200646:	d06080e7          	jalr	-762(ra) # 80200348 <printf>
    printf("=============================\n");
    8020064a:	00007517          	auipc	a0,0x7
    8020064e:	bce50513          	addi	a0,a0,-1074 # 80207218 <etext+0x218>
    80200652:	00000097          	auipc	ra,0x0
    80200656:	cf6080e7          	jalr	-778(ra) # 80200348 <printf>
    for (;;) asm volatile("wfi");
    8020065a:	10500073          	wfi
    8020065e:	bff5                	j	8020065a <panic+0xa0>

0000000080200660 <memset>:
#include "types.h"
#include "defs.h"
void *memset(void *dst, int c, usize n){ char *d=dst; while(n--) *d++=(char)c; return dst; }
    80200660:	1141                	addi	sp,sp,-16
    80200662:	e422                	sd	s0,8(sp)
    80200664:	0800                	addi	s0,sp,16
    80200666:	ca01                	beqz	a2,80200676 <memset+0x16>
    80200668:	962a                	add	a2,a2,a0
    8020066a:	87aa                	mv	a5,a0
    8020066c:	0785                	addi	a5,a5,1
    8020066e:	feb78fa3          	sb	a1,-1(a5)
    80200672:	fef61de3          	bne	a2,a5,8020066c <memset+0xc>
    80200676:	6422                	ld	s0,8(sp)
    80200678:	0141                	addi	sp,sp,16
    8020067a:	8082                	ret

000000008020067c <memmove>:
void *memmove(void *dst, const void *src, usize n){
    8020067c:	1141                	addi	sp,sp,-16
    8020067e:	e422                	sd	s0,8(sp)
    80200680:	0800                	addi	s0,sp,16
    char *d=dst; const char *s=src;
    if (d < s) { while(n--) *d++ = *s++; }
    80200682:	02b57063          	bgeu	a0,a1,802006a2 <memmove+0x26>
    80200686:	ca19                	beqz	a2,8020069c <memmove+0x20>
    80200688:	962a                	add	a2,a2,a0
    char *d=dst; const char *s=src;
    8020068a:	87aa                	mv	a5,a0
    if (d < s) { while(n--) *d++ = *s++; }
    8020068c:	0585                	addi	a1,a1,1
    8020068e:	0785                	addi	a5,a5,1
    80200690:	fff5c703          	lbu	a4,-1(a1)
    80200694:	fee78fa3          	sb	a4,-1(a5)
    80200698:	fef61ae3          	bne	a2,a5,8020068c <memmove+0x10>
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    return dst;
}
    8020069c:	6422                	ld	s0,8(sp)
    8020069e:	0141                	addi	sp,sp,16
    802006a0:	8082                	ret
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    802006a2:	00c507b3          	add	a5,a0,a2
    802006a6:	95b2                	add	a1,a1,a2
    802006a8:	da75                	beqz	a2,8020069c <memmove+0x20>
    802006aa:	15fd                	addi	a1,a1,-1
    802006ac:	17fd                	addi	a5,a5,-1
    802006ae:	0005c703          	lbu	a4,0(a1)
    802006b2:	00e78023          	sb	a4,0(a5)
    802006b6:	fef51ae3          	bne	a0,a5,802006aa <memmove+0x2e>
    802006ba:	b7cd                	j	8020069c <memmove+0x20>

00000000802006bc <memcmp>:
int memcmp(const void *a, const void *b, usize n){
    802006bc:	1141                	addi	sp,sp,-16
    802006be:	e422                	sd	s0,8(sp)
    802006c0:	0800                	addi	s0,sp,16
    const uint8 *x=a,*y=b;
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    802006c2:	c21d                	beqz	a2,802006e8 <memcmp+0x2c>
    802006c4:	962a                	add	a2,a2,a0
    802006c6:	00054783          	lbu	a5,0(a0)
    802006ca:	0005c703          	lbu	a4,0(a1)
    802006ce:	00e79863          	bne	a5,a4,802006de <memcmp+0x22>
    802006d2:	0505                	addi	a0,a0,1
    802006d4:	0585                	addi	a1,a1,1
    802006d6:	fea618e3          	bne	a2,a0,802006c6 <memcmp+0xa>
    return 0;
    802006da:	4501                	li	a0,0
    802006dc:	a019                	j	802006e2 <memcmp+0x26>
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    802006de:	40e7853b          	subw	a0,a5,a4
}
    802006e2:	6422                	ld	s0,8(sp)
    802006e4:	0141                	addi	sp,sp,16
    802006e6:	8082                	ret
    return 0;
    802006e8:	4501                	li	a0,0
    802006ea:	bfe5                	j	802006e2 <memcmp+0x26>

00000000802006ec <strncmp>:
int strncmp(const char *a, const char *b, usize n){
    802006ec:	1141                	addi	sp,sp,-16
    802006ee:	e422                	sd	s0,8(sp)
    802006f0:	0800                	addi	s0,sp,16
    while(n > 0 && *a && *a == *b){ a++; b++; n--; }
    802006f2:	ce11                	beqz	a2,8020070e <strncmp+0x22>
    802006f4:	00054783          	lbu	a5,0(a0)
    802006f8:	cf89                	beqz	a5,80200712 <strncmp+0x26>
    802006fa:	0005c703          	lbu	a4,0(a1)
    802006fe:	00f71a63          	bne	a4,a5,80200712 <strncmp+0x26>
    80200702:	0505                	addi	a0,a0,1
    80200704:	0585                	addi	a1,a1,1
    80200706:	167d                	addi	a2,a2,-1
    80200708:	f675                	bnez	a2,802006f4 <strncmp+0x8>
    if(n == 0) return 0;
    8020070a:	4501                	li	a0,0
    8020070c:	a801                	j	8020071c <strncmp+0x30>
    8020070e:	4501                	li	a0,0
    80200710:	a031                	j	8020071c <strncmp+0x30>
    return (uint8)*a - (uint8)*b;
    80200712:	00054503          	lbu	a0,0(a0)
    80200716:	0005c783          	lbu	a5,0(a1)
    8020071a:	9d1d                	subw	a0,a0,a5
}
    8020071c:	6422                	ld	s0,8(sp)
    8020071e:	0141                	addi	sp,sp,16
    80200720:	8082                	ret

0000000080200722 <strncpy>:
char *strncpy(char *d, const char *s, int n){
    80200722:	1141                	addi	sp,sp,-16
    80200724:	e422                	sd	s0,8(sp)
    80200726:	0800                	addi	s0,sp,16
    char *r=d;
    while(n-- > 0 && (*d++ = *s++) != 0) ;
    80200728:	87aa                	mv	a5,a0
    8020072a:	86b2                	mv	a3,a2
    8020072c:	367d                	addiw	a2,a2,-1
    8020072e:	02d05563          	blez	a3,80200758 <strncpy+0x36>
    80200732:	0785                	addi	a5,a5,1
    80200734:	0005c703          	lbu	a4,0(a1)
    80200738:	fee78fa3          	sb	a4,-1(a5)
    8020073c:	0585                	addi	a1,a1,1
    8020073e:	f775                	bnez	a4,8020072a <strncpy+0x8>
    while(n-- > 0) *d++ = 0;
    80200740:	873e                	mv	a4,a5
    80200742:	9fb5                	addw	a5,a5,a3
    80200744:	37fd                	addiw	a5,a5,-1
    80200746:	00c05963          	blez	a2,80200758 <strncpy+0x36>
    8020074a:	0705                	addi	a4,a4,1
    8020074c:	fe070fa3          	sb	zero,-1(a4)
    80200750:	40e786bb          	subw	a3,a5,a4
    80200754:	fed04be3          	bgtz	a3,8020074a <strncpy+0x28>
    return r;
}
    80200758:	6422                	ld	s0,8(sp)
    8020075a:	0141                	addi	sp,sp,16
    8020075c:	8082                	ret

000000008020075e <strlen>:
int strlen(const char *s){ int n=0; while(s[n]) n++; return n; }
    8020075e:	1141                	addi	sp,sp,-16
    80200760:	e422                	sd	s0,8(sp)
    80200762:	0800                	addi	s0,sp,16
    80200764:	00054783          	lbu	a5,0(a0)
    80200768:	cf91                	beqz	a5,80200784 <strlen+0x26>
    8020076a:	0505                	addi	a0,a0,1
    8020076c:	87aa                	mv	a5,a0
    8020076e:	86be                	mv	a3,a5
    80200770:	0785                	addi	a5,a5,1
    80200772:	fff7c703          	lbu	a4,-1(a5)
    80200776:	ff65                	bnez	a4,8020076e <strlen+0x10>
    80200778:	40a6853b          	subw	a0,a3,a0
    8020077c:	2505                	addiw	a0,a0,1
    8020077e:	6422                	ld	s0,8(sp)
    80200780:	0141                	addi	sp,sp,16
    80200782:	8082                	ret
    80200784:	4501                	li	a0,0
    80200786:	bfe5                	j	8020077e <strlen+0x20>

0000000080200788 <sbi_putchar>:




void sbi_putchar(int c)
{
    80200788:	1141                	addi	sp,sp,-16
    8020078a:	e422                	sd	s0,8(sp)
    8020078c:	0800                	addi	s0,sp,16
    8020078e:	87aa                	mv	a5,a0
    unsigned char ch = (unsigned char)c;
    /* DBCN console_write_byte = EID 0x4442434E, FID 2 */
    struct sbiret r = sbi_call(0x4442434E, 2, ch, 0, 0);
    80200790:	0ff57513          	zext.b	a0,a0
    register long r_a1 asm("a1") = a1;
    80200794:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    80200796:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    80200798:	4809                	li	a6,2
    register long r_a7 asm("a7") = eid;
    8020079a:	444248b7          	lui	a7,0x44424
    8020079e:	34e88893          	addi	a7,a7,846 # 4442434e <_entry-0x3bddbcb2>
    asm volatile ("ecall"
    802007a2:	00000073          	ecall
    if (r.error != 0)
    802007a6:	e501                	bnez	a0,802007ae <sbi_putchar+0x26>
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
}
    802007a8:	6422                	ld	s0,8(sp)
    802007aa:	0141                	addi	sp,sp,16
    802007ac:	8082                	ret
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
    802007ae:	853e                	mv	a0,a5
    register long r_a1 asm("a1") = a1;
    802007b0:	4581                	li	a1,0
    register long r_a6 asm("a6") = fid;
    802007b2:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    802007b4:	4885                	li	a7,1
    asm volatile ("ecall"
    802007b6:	00000073          	ecall
}
    802007ba:	b7fd                	j	802007a8 <sbi_putchar+0x20>

00000000802007bc <sbi_set_timer>:

/* TIME extension: set the next timer interrupt (absolute time). */
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    802007bc:	1141                	addi	sp,sp,-16
    802007be:	e422                	sd	s0,8(sp)
    802007c0:	0800                	addi	s0,sp,16
    register long r_a1 asm("a1") = a1;
    802007c2:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    802007c4:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    802007c6:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    802007c8:	544958b7          	lui	a7,0x54495
    802007cc:	d4588893          	addi	a7,a7,-699 # 54494d45 <_entry-0x2bd6b2bb>
    asm volatile ("ecall"
    802007d0:	00000073          	ecall
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    802007d4:	6422                	ld	s0,8(sp)
    802007d6:	0141                	addi	sp,sp,16
    802007d8:	8082                	ret

00000000802007da <sbi_hart_start>:

/* Implementation note. */
long sbi_hart_start(uint64 hartid, uint64 addr, uint64 opaque)
{
    802007da:	1141                	addi	sp,sp,-16
    802007dc:	e422                	sd	s0,8(sp)
    802007de:	0800                	addi	s0,sp,16
    register long r_a6 asm("a6") = fid;
    802007e0:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    802007e2:	004858b7          	lui	a7,0x485
    802007e6:	34d88893          	addi	a7,a7,845 # 48534d <_entry-0x7fd7acb3>
    asm volatile ("ecall"
    802007ea:	00000073          	ecall
    return sbi_call(0x48534D, 0, hartid, addr, opaque).error;
}
    802007ee:	6422                	ld	s0,8(sp)
    802007f0:	0141                	addi	sp,sp,16
    802007f2:	8082                	ret

00000000802007f4 <be32>:
    uint32 off_mem_rsvmap, version, last_comp_version;
    uint32 boot_cpuid_phys, size_dt_strings, size_dt_struct;
};

/* The FDT is big-endian; RISC-V is little-endian. Swap on every read. */
static uint32 be32(uint32 x) {
    802007f4:	1141                	addi	sp,sp,-16
    802007f6:	e422                	sd	s0,8(sp)
    802007f8:	0800                	addi	s0,sp,16
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    802007fa:	0185179b          	slliw	a5,a0,0x18
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    802007fe:	0185571b          	srliw	a4,a0,0x18
    80200802:	8fd9                	or	a5,a5,a4
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    80200804:	0085171b          	slliw	a4,a0,0x8
    80200808:	00ff06b7          	lui	a3,0xff0
    8020080c:	8f75                	and	a4,a4,a3
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    8020080e:	8fd9                	or	a5,a5,a4
    80200810:	0085551b          	srliw	a0,a0,0x8
    80200814:	6741                	lui	a4,0x10
    80200816:	f0070713          	addi	a4,a4,-256 # ff00 <_entry-0x801f0100>
    8020081a:	8d79                	and	a0,a0,a4
    8020081c:	8d5d                	or	a0,a0,a5
}
    8020081e:	2501                	sext.w	a0,a0
    80200820:	6422                	ld	s0,8(sp)
    80200822:	0141                	addi	sp,sp,16
    80200824:	8082                	ret

0000000080200826 <streq>:
#define MAXDEPTH 16

struct fdt_info fdt;                 /* what we discovered about this board */
static const char *strings;          /* strings block base */

static int streq(const char *a, const char *b) {
    80200826:	1141                	addi	sp,sp,-16
    80200828:	e422                	sd	s0,8(sp)
    8020082a:	0800                	addi	s0,sp,16
    while (*a && *a == *b) { a++; b++; }
    8020082c:	00054783          	lbu	a5,0(a0)
    80200830:	cb91                	beqz	a5,80200844 <streq+0x1e>
    80200832:	0005c703          	lbu	a4,0(a1)
    80200836:	00f71763          	bne	a4,a5,80200844 <streq+0x1e>
    8020083a:	0505                	addi	a0,a0,1
    8020083c:	0585                	addi	a1,a1,1
    8020083e:	00054783          	lbu	a5,0(a0)
    80200842:	fbe5                	bnez	a5,80200832 <streq+0xc>
    return *a == *b;
    80200844:	0005c503          	lbu	a0,0(a1)
    80200848:	8d1d                	sub	a0,a0,a5
}
    8020084a:	00153513          	seqz	a0,a0
    8020084e:	6422                	ld	s0,8(sp)
    80200850:	0141                	addi	sp,sp,16
    80200852:	8082                	ret

0000000080200854 <strlist_has>:
/* does `list` (a NUL-separated string list of length len) contain `want`? */
static int strlist_has(const char *list, int len, const char *want) {
    int i = 0;
    while (i < len) {
    80200854:	04b05f63          	blez	a1,802008b2 <strlist_has+0x5e>
static int strlist_has(const char *list, int len, const char *want) {
    80200858:	7139                	addi	sp,sp,-64
    8020085a:	fc06                	sd	ra,56(sp)
    8020085c:	f822                	sd	s0,48(sp)
    8020085e:	f426                	sd	s1,40(sp)
    80200860:	f04a                	sd	s2,32(sp)
    80200862:	ec4e                	sd	s3,24(sp)
    80200864:	e852                	sd	s4,16(sp)
    80200866:	e456                	sd	s5,8(sp)
    80200868:	0080                	addi	s0,sp,64
    8020086a:	8a2a                	mv	s4,a0
    8020086c:	89ae                	mv	s3,a1
    8020086e:	8ab2                	mv	s5,a2
    int i = 0;
    80200870:	4481                	li	s1,0
    80200872:	a021                	j	8020087a <strlist_has+0x26>
        if (streq(&list[i], want)) return 1;
        while (i < len && list[i]) i++;
        i++;
    80200874:	2485                	addiw	s1,s1,1
    while (i < len) {
    80200876:	0334d563          	bge	s1,s3,802008a0 <strlist_has+0x4c>
        if (streq(&list[i], want)) return 1;
    8020087a:	009a0933          	add	s2,s4,s1
    8020087e:	85d6                	mv	a1,s5
    80200880:	854a                	mv	a0,s2
    80200882:	00000097          	auipc	ra,0x0
    80200886:	fa4080e7          	jalr	-92(ra) # 80200826 <streq>
    8020088a:	e515                	bnez	a0,802008b6 <strlist_has+0x62>
        while (i < len && list[i]) i++;
    8020088c:	ff34d4e3          	bge	s1,s3,80200874 <strlist_has+0x20>
    80200890:	87ca                	mv	a5,s2
    80200892:	0007c703          	lbu	a4,0(a5)
    80200896:	df79                	beqz	a4,80200874 <strlist_has+0x20>
    80200898:	2485                	addiw	s1,s1,1
    8020089a:	0785                	addi	a5,a5,1
    8020089c:	fe999be3          	bne	s3,s1,80200892 <strlist_has+0x3e>
    }
    return 0;
}
    802008a0:	70e2                	ld	ra,56(sp)
    802008a2:	7442                	ld	s0,48(sp)
    802008a4:	74a2                	ld	s1,40(sp)
    802008a6:	7902                	ld	s2,32(sp)
    802008a8:	69e2                	ld	s3,24(sp)
    802008aa:	6a42                	ld	s4,16(sp)
    802008ac:	6aa2                	ld	s5,8(sp)
    802008ae:	6121                	addi	sp,sp,64
    802008b0:	8082                	ret
    return 0;
    802008b2:	4501                	li	a0,0
}
    802008b4:	8082                	ret
        if (streq(&list[i], want)) return 1;
    802008b6:	4505                	li	a0,1
    802008b8:	b7e5                	j	802008a0 <strlist_has+0x4c>

00000000802008ba <fdt_init>:




void fdt_init(uint64 fdt_pa)
{
    802008ba:	712d                	addi	sp,sp,-288
    802008bc:	ee06                	sd	ra,280(sp)
    802008be:	ea22                	sd	s0,272(sp)
    802008c0:	fdce                	sd	s3,248(sp)
    802008c2:	1200                	addi	s0,sp,288
    802008c4:	89aa                	mv	s3,a0
    struct fdt_header *h = (struct fdt_header *)fdt_pa;

    if (be32(h->magic) != FDT_MAGIC)
    802008c6:	4108                	lw	a0,0(a0)
    802008c8:	00000097          	auipc	ra,0x0
    802008cc:	f2c080e7          	jalr	-212(ra) # 802007f4 <be32>
    802008d0:	2501                	sext.w	a0,a0
    802008d2:	d00e07b7          	lui	a5,0xd00e0
    802008d6:	eed78793          	addi	a5,a5,-275 # ffffffffd00dfeed <uart+0xffffffff4fda0ebd>
    802008da:	0cf51263          	bne	a0,a5,8020099e <fdt_init+0xe4>
    802008de:	e626                	sd	s1,264(sp)
    802008e0:	e24a                	sd	s2,256(sp)
    802008e2:	f9d2                	sd	s4,240(sp)
    802008e4:	f5d6                	sd	s5,232(sp)
    802008e6:	f1da                	sd	s6,224(sp)
    802008e8:	edde                	sd	s7,216(sp)
    802008ea:	e9e2                	sd	s8,208(sp)
    802008ec:	e1ea                	sd	s10,192(sp)
        panic("fdt: bad magic - is a1 really the device tree?");

    strings = (const char *)(fdt_pa + be32(h->off_dt_strings));
    802008ee:	00c9a503          	lw	a0,12(s3)
    802008f2:	00000097          	auipc	ra,0x0
    802008f6:	f02080e7          	jalr	-254(ra) # 802007f4 <be32>
    802008fa:	02051b13          	slli	s6,a0,0x20
    802008fe:	020b5b13          	srli	s6,s6,0x20
    80200902:	9b4e                	add	s6,s6,s3
    const uint32 *p = (const uint32 *)(fdt_pa + be32(h->off_dt_struct));
    80200904:	0089a503          	lw	a0,8(s3)
    80200908:	00000097          	auipc	ra,0x0
    8020090c:	eec080e7          	jalr	-276(ra) # 802007f4 <be32>
    80200910:	02051493          	slli	s1,a0,0x20
    80200914:	9081                	srli	s1,s1,0x20
    80200916:	94ce                	add	s1,s1,s3

    fdt.blob = fdt_pa;
    80200918:	00028917          	auipc	s2,0x28
    8020091c:	70090913          	addi	s2,s2,1792 # 80229018 <fdt>
    80200920:	01393023          	sd	s3,0(s2)
    fdt.blob_size = be32(h->totalsize);
    80200924:	0049a503          	lw	a0,4(s3)
    80200928:	00000097          	auipc	ra,0x0
    8020092c:	ecc080e7          	jalr	-308(ra) # 802007f4 <be32>
    80200930:	1502                	slli	a0,a0,0x20
    80200932:	9101                	srli	a0,a0,0x20
    80200934:	00a93423          	sd	a0,8(s2)
    fdt.ncpu = 0;
    80200938:	0a092023          	sw	zero,160(s2)
    fdt.uart_base = 0; fdt.plic_base = 0; fdt.uart_irq = 0;
    8020093c:	00093823          	sd	zero,16(s2)
    80200940:	00093c23          	sd	zero,24(s2)
    80200944:	02092023          	sw	zero,32(s2)
    fdt.nvirtio = 0;
    80200948:	08092423          	sw	zero,136(s2)
    fdt.mem_base = 0;  fdt.mem_size = 0;
    8020094c:	08093823          	sd	zero,144(s2)
    80200950:	08093c23          	sd	zero,152(s2)

    /* #address-cells / #size-cells, one slot per depth. Defaults per spec. */
    int ac[MAXDEPTH], sc[MAXDEPTH];
    ac[0] = 2; sc[0] = 2;
    80200954:	4789                	li	a5,2
    80200956:	f4f42823          	sw	a5,-176(s0)
    8020095a:	f0f42823          	sw	a5,-240(s0)

    /* properties buffered for the node we are currently inside */
    int    kind = PEND_NONE;
    int    have_reg = 0;
    uint64 reg_base = 0, reg_size = 0;
    int    have_irq = 0, irq = 0;
    8020095e:	ee043423          	sd	zero,-280(s0)
    80200962:	ee043823          	sd	zero,-272(s0)
    uint64 reg_base = 0, reg_size = 0;
    80200966:	f0043023          	sd	zero,-256(s0)
    8020096a:	f0043423          	sd	zero,-248(s0)
    int    have_reg = 0;
    8020096e:	4d01                	li	s10,0
    int    kind = PEND_NONE;
    80200970:	4c01                	li	s8,0
    int cpus_depth = -1;
    80200972:	5bfd                	li	s7,-1
    int depth = 0;
    80200974:	4981                	li	s3,0
    80200976:	4aa5                	li	s5,9
    80200978:	00007917          	auipc	s2,0x7
    8020097c:	45490913          	addi	s2,s2,1108 # 80207dcc <digits+0x14>

    for (;;) {
        uint32 tok = be32(*p++);
    80200980:	00448a13          	addi	s4,s1,4
    80200984:	4088                	lw	a0,0(s1)
    80200986:	00000097          	auipc	ra,0x0
    8020098a:	e6e080e7          	jalr	-402(ra) # 802007f4 <be32>
    8020098e:	2501                	sext.w	a0,a0

        if (tok == FDT_END) break;
    80200990:	4eaaee63          	bltu	s5,a0,80200e8c <fdt_init+0x5d2>
    80200994:	050a                	slli	a0,a0,0x2
    80200996:	954a                	add	a0,a0,s2
    80200998:	411c                	lw	a5,0(a0)
    8020099a:	97ca                	add	a5,a5,s2
    8020099c:	8782                	jr	a5
    8020099e:	e626                	sd	s1,264(sp)
    802009a0:	e24a                	sd	s2,256(sp)
    802009a2:	f9d2                	sd	s4,240(sp)
    802009a4:	f5d6                	sd	s5,232(sp)
    802009a6:	f1da                	sd	s6,224(sp)
    802009a8:	edde                	sd	s7,216(sp)
    802009aa:	e9e2                	sd	s8,208(sp)
    802009ac:	e5e6                	sd	s9,200(sp)
    802009ae:	e1ea                	sd	s10,192(sp)
    802009b0:	fd6e                	sd	s11,184(sp)
        panic("fdt: bad magic - is a1 really the device tree?");
    802009b2:	00007517          	auipc	a0,0x7
    802009b6:	88e50513          	addi	a0,a0,-1906 # 80207240 <etext+0x240>
    802009ba:	00000097          	auipc	ra,0x0
    802009be:	c00080e7          	jalr	-1024(ra) # 802005ba <panic>
        uint32 tok = be32(*p++);
    802009c2:	84d2                	mv	s1,s4
    802009c4:	bf75                	j	80200980 <fdt_init+0xc6>
        if (tok == FDT_BEGIN_NODE) {
            const char *name = (const char *)p;
            int len = 0; while (name[len]) len++;
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */

            depth++;
    802009c6:	89e2                	mv	s3,s8
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
            sc[depth] = sc[depth - 1];

            /* start a fresh property buffer for this node */
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
            have_irq = 0; irq = 0;
    802009c8:	ee043423          	sd	zero,-280(s0)
    802009cc:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    802009d0:	f0043023          	sd	zero,-256(s0)
    802009d4:	f0043423          	sd	zero,-248(s0)
    802009d8:	4d01                	li	s10,0
    802009da:	4c01                	li	s8,0
    802009dc:	b755                	j	80200980 <fdt_init+0xc6>
        if (tok == FDT_PROP) {
            uint32 len     = be32(*p++);
            uint32 nameoff = be32(*p++);
            const char *pname = &strings[nameoff];
            const uint32 *val = p;
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    802009de:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
                else if (strlist_has(c, len, "riscv,plic0") ||
                         strlist_has(c, len, "sifive,plic-1.0.0"))
                    kind = PEND_PLIC;
                else if (strlist_has(c, len, "virtio,mmio"))
                    kind = PEND_VIRTIO;
    802009e2:	4c0d                	li	s8,3
    802009e4:	6cae                	ld	s9,200(sp)
    802009e6:	7dea                	ld	s11,184(sp)
    802009e8:	bf61                	j	80200980 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    802009ea:	ef843483          	ld	s1,-264(s0)
            } else if (streq(pname, "device_type")) {
                if (strlist_has((const char *)val, len, "memory"))
                    kind = PEND_MEM;
    802009ee:	4c11                	li	s8,4
    802009f0:	6cae                	ld	s9,200(sp)
    802009f2:	7dea                	ld	s11,184(sp)
    802009f4:	b771                	j	80200980 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    802009f6:	ef843483          	ld	s1,-264(s0)
    802009fa:	6cae                	ld	s9,200(sp)
    802009fc:	7dea                	ld	s11,184(sp)
    802009fe:	b749                	j	80200980 <fdt_init+0xc6>
    80200a00:	ef843483          	ld	s1,-264(s0)
    80200a04:	6cae                	ld	s9,200(sp)
    80200a06:	7dea                	ld	s11,184(sp)
    80200a08:	bfa5                	j	80200980 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200a0a:	0044c783          	lbu	a5,4(s1)
    80200a0e:	c7d9                	beqz	a5,80200a9c <fdt_init+0x1e2>
    80200a10:	0495                	addi	s1,s1,5
    80200a12:	87a6                	mv	a5,s1
    80200a14:	86be                	mv	a3,a5
    80200a16:	0785                	addi	a5,a5,1
    80200a18:	fff7c703          	lbu	a4,-1(a5)
    80200a1c:	ff65                	bnez	a4,80200a14 <fdt_init+0x15a>
    80200a1e:	9e85                	subw	a3,a3,s1
    80200a20:	2685                	addiw	a3,a3,1 # ff0001 <_entry-0x7f20ffff>
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */
    80200a22:	2691                	addiw	a3,a3,4
    80200a24:	41f6d49b          	sraiw	s1,a3,0x1f
    80200a28:	01e4d49b          	srliw	s1,s1,0x1e
    80200a2c:	9cb5                	addw	s1,s1,a3
    80200a2e:	4024d49b          	sraiw	s1,s1,0x2
    80200a32:	048a                	slli	s1,s1,0x2
    80200a34:	94d2                	add	s1,s1,s4
            depth++;
    80200a36:	00198c1b          	addiw	s8,s3,1
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200a3a:	47bd                	li	a5,15
    80200a3c:	0787c263          	blt	a5,s8,80200aa0 <fdt_init+0x1e6>
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
    80200a40:	00299713          	slli	a4,s3,0x2
    80200a44:	f9070793          	addi	a5,a4,-112
    80200a48:	00878733          	add	a4,a5,s0
    80200a4c:	fc072683          	lw	a3,-64(a4)
    80200a50:	002c1793          	slli	a5,s8,0x2
    80200a54:	f9078793          	addi	a5,a5,-112
    80200a58:	97a2                	add	a5,a5,s0
    80200a5a:	fcd7a023          	sw	a3,-64(a5)
            sc[depth] = sc[depth - 1];
    80200a5e:	f8072703          	lw	a4,-128(a4)
    80200a62:	f8e7a023          	sw	a4,-128(a5)
            if (streq(name, "cpus")) cpus_depth = depth;
    80200a66:	00007597          	auipc	a1,0x7
    80200a6a:	82258593          	addi	a1,a1,-2014 # 80207288 <etext+0x288>
    80200a6e:	8552                	mv	a0,s4
    80200a70:	00000097          	auipc	ra,0x0
    80200a74:	db6080e7          	jalr	-586(ra) # 80200826 <streq>
    80200a78:	c111                	beqz	a0,80200a7c <fdt_init+0x1c2>
    80200a7a:	8be2                	mv	s7,s8
            if (cpus_depth > 0 && depth == cpus_depth + 1 && startswith(name, "cpu@"))
    80200a7c:	f57055e3          	blez	s7,802009c6 <fdt_init+0x10c>
    80200a80:	03798a63          	beq	s3,s7,80200ab4 <fdt_init+0x1fa>
            depth++;
    80200a84:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200a86:	ee043423          	sd	zero,-280(s0)
    80200a8a:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200a8e:	f0043023          	sd	zero,-256(s0)
    80200a92:	f0043423          	sd	zero,-248(s0)
    80200a96:	4d01                	li	s10,0
    80200a98:	4c01                	li	s8,0
    80200a9a:	b5dd                	j	80200980 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200a9c:	4681                	li	a3,0
    80200a9e:	b751                	j	80200a22 <fdt_init+0x168>
    80200aa0:	e5e6                	sd	s9,200(sp)
    80200aa2:	fd6e                	sd	s11,184(sp)
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200aa4:	00006517          	auipc	a0,0x6
    80200aa8:	7cc50513          	addi	a0,a0,1996 # 80207270 <etext+0x270>
    80200aac:	00000097          	auipc	ra,0x0
    80200ab0:	b0e080e7          	jalr	-1266(ra) # 802005ba <panic>
    80200ab4:	00006797          	auipc	a5,0x6
    80200ab8:	78478793          	addi	a5,a5,1924 # 80207238 <etext+0x238>
    while (*pre) { if (*s++ != *pre++) return 0; }
    80200abc:	0007c703          	lbu	a4,0(a5)
    80200ac0:	44070e63          	beqz	a4,80200f1c <fdt_init+0x662>
    80200ac4:	0a05                	addi	s4,s4,1
    80200ac6:	0785                	addi	a5,a5,1
    80200ac8:	fffa4683          	lbu	a3,-1(s4)
    80200acc:	fee688e3          	beq	a3,a4,80200abc <fdt_init+0x202>
            depth++;
    80200ad0:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200ad2:	ee043423          	sd	zero,-280(s0)
    80200ad6:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200ada:	f0043023          	sd	zero,-256(s0)
    80200ade:	f0043423          	sd	zero,-248(s0)
    80200ae2:	4d01                	li	s10,0
    80200ae4:	4c01                	li	s8,0
    80200ae6:	bd69                	j	80200980 <fdt_init+0xc6>
            if (have_reg && kind != PEND_NONE) {
    80200ae8:	040d0863          	beqz	s10,80200b38 <fdt_init+0x27e>
    80200aec:	040c0663          	beqz	s8,80200b38 <fdt_init+0x27e>
                switch (kind) {
    80200af0:	478d                	li	a5,3
    80200af2:	06fc0f63          	beq	s8,a5,80200b70 <fdt_init+0x2b6>
    80200af6:	0387c463          	blt	a5,s8,80200b1e <fdt_init+0x264>
    80200afa:	4785                	li	a5,1
    80200afc:	04fc0563          	beq	s8,a5,80200b46 <fdt_init+0x28c>
    80200b00:	4789                	li	a5,2
    80200b02:	02fc1b63          	bne	s8,a5,80200b38 <fdt_init+0x27e>
                case PEND_PLIC:   if (!fdt.plic_base) fdt.plic_base = reg_base; break;
    80200b06:	00028797          	auipc	a5,0x28
    80200b0a:	52a7b783          	ld	a5,1322(a5) # 80229030 <fdt+0x18>
    80200b0e:	e78d                	bnez	a5,80200b38 <fdt_init+0x27e>
    80200b10:	f0843703          	ld	a4,-248(s0)
    80200b14:	00028797          	auipc	a5,0x28
    80200b18:	50e7be23          	sd	a4,1308(a5) # 80229030 <fdt+0x18>
    80200b1c:	a831                	j	80200b38 <fdt_init+0x27e>
                switch (kind) {
    80200b1e:	4791                	li	a5,4
    80200b20:	00fc1c63          	bne	s8,a5,80200b38 <fdt_init+0x27e>
                case PEND_MEM:    fdt.mem_base = reg_base; fdt.mem_size = reg_size; break;
    80200b24:	00028797          	auipc	a5,0x28
    80200b28:	4f478793          	addi	a5,a5,1268 # 80229018 <fdt>
    80200b2c:	f0843703          	ld	a4,-248(s0)
    80200b30:	ebd8                	sd	a4,144(a5)
    80200b32:	f0043703          	ld	a4,-256(s0)
    80200b36:	efd8                	sd	a4,152(a5)
            if (depth == cpus_depth) cpus_depth = -1;
    80200b38:	09798163          	beq	s3,s7,80200bba <fdt_init+0x300>
            depth--;
    80200b3c:	39fd                	addiw	s3,s3,-1
        uint32 tok = be32(*p++);
    80200b3e:	84d2                	mv	s1,s4
            kind = PEND_NONE; have_reg = 0;
    80200b40:	4d01                	li	s10,0
    80200b42:	4c01                	li	s8,0
            continue;
    80200b44:	bd35                	j	80200980 <fdt_init+0xc6>
                    if (!fdt.uart_base) {
    80200b46:	00028797          	auipc	a5,0x28
    80200b4a:	4e27b783          	ld	a5,1250(a5) # 80229028 <fdt+0x10>
    80200b4e:	f7ed                	bnez	a5,80200b38 <fdt_init+0x27e>
                        fdt.uart_base = reg_base;
    80200b50:	f0843703          	ld	a4,-248(s0)
    80200b54:	00028797          	auipc	a5,0x28
    80200b58:	4ce7ba23          	sd	a4,1236(a5) # 80229028 <fdt+0x10>
                        if (have_irq) fdt.uart_irq = irq;
    80200b5c:	ef043783          	ld	a5,-272(s0)
    80200b60:	dfe1                	beqz	a5,80200b38 <fdt_init+0x27e>
    80200b62:	ee843703          	ld	a4,-280(s0)
    80200b66:	00028797          	auipc	a5,0x28
    80200b6a:	4ce7a923          	sw	a4,1234(a5) # 80229038 <fdt+0x20>
    80200b6e:	b7e9                	j	80200b38 <fdt_init+0x27e>
                    if (fdt.nvirtio < FDT_MAX_VIRTIO) {
    80200b70:	00028797          	auipc	a5,0x28
    80200b74:	5307a783          	lw	a5,1328(a5) # 802290a0 <fdt+0x88>
    80200b78:	471d                	li	a4,7
    80200b7a:	faf74fe3          	blt	a4,a5,80200b38 <fdt_init+0x27e>
                        fdt.virtio_base[fdt.nvirtio] = reg_base;
    80200b7e:	00478693          	addi	a3,a5,4
    80200b82:	068e                	slli	a3,a3,0x3
    80200b84:	00028717          	auipc	a4,0x28
    80200b88:	49470713          	addi	a4,a4,1172 # 80229018 <fdt>
    80200b8c:	9736                	add	a4,a4,a3
    80200b8e:	f0843683          	ld	a3,-248(s0)
    80200b92:	e714                	sd	a3,8(a4)
                        fdt.virtio_irq[fdt.nvirtio]  = have_irq ? irq : 0;
    80200b94:	ef043703          	ld	a4,-272(s0)
    80200b98:	863a                	mv	a2,a4
    80200b9a:	c319                	beqz	a4,80200ba0 <fdt_init+0x2e6>
    80200b9c:	ee843603          	ld	a2,-280(s0)
    80200ba0:	00028697          	auipc	a3,0x28
    80200ba4:	47868693          	addi	a3,a3,1144 # 80229018 <fdt>
    80200ba8:	01878713          	addi	a4,a5,24
    80200bac:	070a                	slli	a4,a4,0x2
    80200bae:	9736                	add	a4,a4,a3
    80200bb0:	c710                	sw	a2,8(a4)
                        fdt.nvirtio++;
    80200bb2:	2785                	addiw	a5,a5,1
    80200bb4:	08f6a423          	sw	a5,136(a3)
    80200bb8:	b741                	j	80200b38 <fdt_init+0x27e>
            if (depth == cpus_depth) cpus_depth = -1;
    80200bba:	5bfd                	li	s7,-1
    80200bbc:	b741                	j	80200b3c <fdt_init+0x282>
    80200bbe:	e5e6                	sd	s9,200(sp)
    80200bc0:	fd6e                	sd	s11,184(sp)
            uint32 len     = be32(*p++);
    80200bc2:	40c8                	lw	a0,4(s1)
    80200bc4:	00000097          	auipc	ra,0x0
    80200bc8:	c30080e7          	jalr	-976(ra) # 802007f4 <be32>
    80200bcc:	00050c9b          	sext.w	s9,a0
            uint32 nameoff = be32(*p++);
    80200bd0:	00c48d93          	addi	s11,s1,12
    80200bd4:	4488                	lw	a0,8(s1)
    80200bd6:	00000097          	auipc	ra,0x0
    80200bda:	c1e080e7          	jalr	-994(ra) # 802007f4 <be32>
            const char *pname = &strings[nameoff];
    80200bde:	02051a13          	slli	s4,a0,0x20
    80200be2:	020a5a13          	srli	s4,s4,0x20
    80200be6:	9a5a                	add	s4,s4,s6
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200be8:	003c879b          	addiw	a5,s9,3
    80200bec:	0027d79b          	srliw	a5,a5,0x2
    80200bf0:	078a                	slli	a5,a5,0x2
    80200bf2:	97ee                	add	a5,a5,s11
    80200bf4:	eef43c23          	sd	a5,-264(s0)
            if (streq(pname, "#address-cells")) {
    80200bf8:	00006597          	auipc	a1,0x6
    80200bfc:	69858593          	addi	a1,a1,1688 # 80207290 <etext+0x290>
    80200c00:	8552                	mv	a0,s4
    80200c02:	00000097          	auipc	ra,0x0
    80200c06:	c24080e7          	jalr	-988(ra) # 80200826 <streq>
    80200c0a:	c11d                	beqz	a0,80200c30 <fdt_init+0x376>
                ac[depth] = be32(val[0]);
    80200c0c:	44c8                	lw	a0,12(s1)
    80200c0e:	00000097          	auipc	ra,0x0
    80200c12:	be6080e7          	jalr	-1050(ra) # 802007f4 <be32>
    80200c16:	00299793          	slli	a5,s3,0x2
    80200c1a:	f9078713          	addi	a4,a5,-112
    80200c1e:	008707b3          	add	a5,a4,s0
    80200c22:	fca7a023          	sw	a0,-64(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c26:	ef843483          	ld	s1,-264(s0)
    80200c2a:	6cae                	ld	s9,200(sp)
    80200c2c:	7dea                	ld	s11,184(sp)
    80200c2e:	bb89                	j	80200980 <fdt_init+0xc6>
            } else if (streq(pname, "#size-cells")) {
    80200c30:	00006597          	auipc	a1,0x6
    80200c34:	67058593          	addi	a1,a1,1648 # 802072a0 <etext+0x2a0>
    80200c38:	8552                	mv	a0,s4
    80200c3a:	00000097          	auipc	ra,0x0
    80200c3e:	bec080e7          	jalr	-1044(ra) # 80200826 <streq>
    80200c42:	c115                	beqz	a0,80200c66 <fdt_init+0x3ac>
                sc[depth] = be32(val[0]);
    80200c44:	44c8                	lw	a0,12(s1)
    80200c46:	00000097          	auipc	ra,0x0
    80200c4a:	bae080e7          	jalr	-1106(ra) # 802007f4 <be32>
    80200c4e:	00299793          	slli	a5,s3,0x2
    80200c52:	f9078793          	addi	a5,a5,-112
    80200c56:	97a2                	add	a5,a5,s0
    80200c58:	f8a7a023          	sw	a0,-128(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c5c:	ef843483          	ld	s1,-264(s0)
    80200c60:	6cae                	ld	s9,200(sp)
    80200c62:	7dea                	ld	s11,184(sp)
    80200c64:	bb31                	j	80200980 <fdt_init+0xc6>
            } else if (streq(pname, "compatible")) {
    80200c66:	00006597          	auipc	a1,0x6
    80200c6a:	64a58593          	addi	a1,a1,1610 # 802072b0 <etext+0x2b0>
    80200c6e:	8552                	mv	a0,s4
    80200c70:	00000097          	auipc	ra,0x0
    80200c74:	bb6080e7          	jalr	-1098(ra) # 80200826 <streq>
    80200c78:	c55d                	beqz	a0,80200d26 <fdt_init+0x46c>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200c7a:	2c81                	sext.w	s9,s9
    80200c7c:	00006617          	auipc	a2,0x6
    80200c80:	64460613          	addi	a2,a2,1604 # 802072c0 <etext+0x2c0>
    80200c84:	85e6                	mv	a1,s9
    80200c86:	856e                	mv	a0,s11
    80200c88:	00000097          	auipc	ra,0x0
    80200c8c:	bcc080e7          	jalr	-1076(ra) # 80200854 <strlist_has>
    80200c90:	c519                	beqz	a0,80200c9e <fdt_init+0x3e4>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c92:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200c96:	4c05                	li	s8,1
    80200c98:	6cae                	ld	s9,200(sp)
    80200c9a:	7dea                	ld	s11,184(sp)
    80200c9c:	b1d5                	j	80200980 <fdt_init+0xc6>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200c9e:	00006617          	auipc	a2,0x6
    80200ca2:	63260613          	addi	a2,a2,1586 # 802072d0 <etext+0x2d0>
    80200ca6:	85e6                	mv	a1,s9
    80200ca8:	856e                	mv	a0,s11
    80200caa:	00000097          	auipc	ra,0x0
    80200cae:	baa080e7          	jalr	-1110(ra) # 80200854 <strlist_has>
    80200cb2:	c519                	beqz	a0,80200cc0 <fdt_init+0x406>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cb4:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cb8:	4c05                	li	s8,1
    80200cba:	6cae                	ld	s9,200(sp)
    80200cbc:	7dea                	ld	s11,184(sp)
    80200cbe:	b1c9                	j	80200980 <fdt_init+0xc6>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200cc0:	00006617          	auipc	a2,0x6
    80200cc4:	61860613          	addi	a2,a2,1560 # 802072d8 <etext+0x2d8>
    80200cc8:	85e6                	mv	a1,s9
    80200cca:	856e                	mv	a0,s11
    80200ccc:	00000097          	auipc	ra,0x0
    80200cd0:	b88080e7          	jalr	-1144(ra) # 80200854 <strlist_has>
    80200cd4:	c519                	beqz	a0,80200ce2 <fdt_init+0x428>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cd6:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200cda:	4c09                	li	s8,2
    80200cdc:	6cae                	ld	s9,200(sp)
    80200cde:	7dea                	ld	s11,184(sp)
    80200ce0:	b145                	j	80200980 <fdt_init+0xc6>
                         strlist_has(c, len, "sifive,plic-1.0.0"))
    80200ce2:	00006617          	auipc	a2,0x6
    80200ce6:	60660613          	addi	a2,a2,1542 # 802072e8 <etext+0x2e8>
    80200cea:	85e6                	mv	a1,s9
    80200cec:	856e                	mv	a0,s11
    80200cee:	00000097          	auipc	ra,0x0
    80200cf2:	b66080e7          	jalr	-1178(ra) # 80200854 <strlist_has>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200cf6:	c519                	beqz	a0,80200d04 <fdt_init+0x44a>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cf8:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200cfc:	4c09                	li	s8,2
    80200cfe:	6cae                	ld	s9,200(sp)
    80200d00:	7dea                	ld	s11,184(sp)
    80200d02:	b9bd                	j	80200980 <fdt_init+0xc6>
                else if (strlist_has(c, len, "virtio,mmio"))
    80200d04:	00006617          	auipc	a2,0x6
    80200d08:	5fc60613          	addi	a2,a2,1532 # 80207300 <etext+0x300>
    80200d0c:	85e6                	mv	a1,s9
    80200d0e:	856e                	mv	a0,s11
    80200d10:	00000097          	auipc	ra,0x0
    80200d14:	b44080e7          	jalr	-1212(ra) # 80200854 <strlist_has>
    80200d18:	cc0513e3          	bnez	a0,802009de <fdt_init+0x124>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d1c:	ef843483          	ld	s1,-264(s0)
    80200d20:	6cae                	ld	s9,200(sp)
    80200d22:	7dea                	ld	s11,184(sp)
    80200d24:	b9b1                	j	80200980 <fdt_init+0xc6>
            } else if (streq(pname, "device_type")) {
    80200d26:	00006597          	auipc	a1,0x6
    80200d2a:	5ea58593          	addi	a1,a1,1514 # 80207310 <etext+0x310>
    80200d2e:	8552                	mv	a0,s4
    80200d30:	00000097          	auipc	ra,0x0
    80200d34:	af6080e7          	jalr	-1290(ra) # 80200826 <streq>
    80200d38:	c115                	beqz	a0,80200d5c <fdt_init+0x4a2>
                if (strlist_has((const char *)val, len, "memory"))
    80200d3a:	00006617          	auipc	a2,0x6
    80200d3e:	5e660613          	addi	a2,a2,1510 # 80207320 <etext+0x320>
    80200d42:	85e6                	mv	a1,s9
    80200d44:	856e                	mv	a0,s11
    80200d46:	00000097          	auipc	ra,0x0
    80200d4a:	b0e080e7          	jalr	-1266(ra) # 80200854 <strlist_has>
    80200d4e:	c8051ee3          	bnez	a0,802009ea <fdt_init+0x130>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d52:	ef843483          	ld	s1,-264(s0)
    80200d56:	6cae                	ld	s9,200(sp)
    80200d58:	7dea                	ld	s11,184(sp)
    80200d5a:	b11d                	j	80200980 <fdt_init+0xc6>
            } else if (streq(pname, "interrupts")) {
    80200d5c:	00006597          	auipc	a1,0x6
    80200d60:	5cc58593          	addi	a1,a1,1484 # 80207328 <etext+0x328>
    80200d64:	8552                	mv	a0,s4
    80200d66:	00000097          	auipc	ra,0x0
    80200d6a:	ac0080e7          	jalr	-1344(ra) # 80200826 <streq>
    80200d6e:	c50d                	beqz	a0,80200d98 <fdt_init+0x4de>
                /* First cell = PLIC source number (qemu virt uses plain
                 * one-cell specifiers for uart and virtio). */
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200d70:	478d                	li	a5,3
    80200d72:	c997f2e3          	bgeu	a5,s9,802009f6 <fdt_init+0x13c>
    80200d76:	44c8                	lw	a0,12(s1)
    80200d78:	00000097          	auipc	ra,0x0
    80200d7c:	a7c080e7          	jalr	-1412(ra) # 802007f4 <be32>
    80200d80:	0005079b          	sext.w	a5,a0
    80200d84:	eef43423          	sd	a5,-280(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d88:	ef843483          	ld	s1,-264(s0)
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200d8c:	4785                	li	a5,1
    80200d8e:	eef43823          	sd	a5,-272(s0)
    80200d92:	6cae                	ld	s9,200(sp)
    80200d94:	7dea                	ld	s11,184(sp)
    80200d96:	b6ed                	j	80200980 <fdt_init+0xc6>
            } else if (streq(pname, "reg")) {
    80200d98:	00006597          	auipc	a1,0x6
    80200d9c:	5a058593          	addi	a1,a1,1440 # 80207338 <etext+0x338>
    80200da0:	8552                	mv	a0,s4
    80200da2:	00000097          	auipc	ra,0x0
    80200da6:	a84080e7          	jalr	-1404(ra) # 80200826 <streq>
    80200daa:	c4050be3          	beqz	a0,80200a00 <fdt_init+0x146>
                /* Decode with the PARENT's cell counts. */
                int pac = ac[depth - 1];
    80200dae:	fff9879b          	addiw	a5,s3,-1
    80200db2:	078a                	slli	a5,a5,0x2
    80200db4:	f9078793          	addi	a5,a5,-112
    80200db8:	97a2                	add	a5,a5,s0
    80200dba:	fc07aa03          	lw	s4,-64(a5)
                int psc = sc[depth - 1];
    80200dbe:	f807ad03          	lw	s10,-128(a5)
                if (pac == 2)      reg_base = be64(val);
    80200dc2:	4789                	li	a5,2
    80200dc4:	02fa0563          	beq	s4,a5,80200dee <fdt_init+0x534>
                else if (pac == 1) reg_base = be32(val[0]);
    80200dc8:	4785                	li	a5,1
                else               reg_base = 0;
    80200dca:	f0043423          	sd	zero,-248(s0)
                else if (pac == 1) reg_base = be32(val[0]);
    80200dce:	04fa0563          	beq	s4,a5,80200e18 <fdt_init+0x55e>

                if (psc == 2)      reg_size = be64(&val[pac]);
    80200dd2:	4789                	li	a5,2
    80200dd4:	04fd0d63          	beq	s10,a5,80200e2e <fdt_init+0x574>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200dd8:	4785                	li	a5,1
    80200dda:	08fd0763          	beq	s10,a5,80200e68 <fdt_init+0x5ae>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200dde:	ef843483          	ld	s1,-264(s0)
                else               reg_size = 0;
    80200de2:	f0043023          	sd	zero,-256(s0)
                have_reg = 1;
    80200de6:	4d05                	li	s10,1
    80200de8:	6cae                	ld	s9,200(sp)
    80200dea:	7dea                	ld	s11,184(sp)
    80200dec:	be51                	j	80200980 <fdt_init+0xc6>
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200dee:	44c8                	lw	a0,12(s1)
    80200df0:	00000097          	auipc	ra,0x0
    80200df4:	a04080e7          	jalr	-1532(ra) # 802007f4 <be32>
    80200df8:	00050c9b          	sext.w	s9,a0
    80200dfc:	4888                	lw	a0,16(s1)
    80200dfe:	00000097          	auipc	ra,0x0
    80200e02:	9f6080e7          	jalr	-1546(ra) # 802007f4 <be32>
    80200e06:	1c82                	slli	s9,s9,0x20
    80200e08:	02051793          	slli	a5,a0,0x20
    80200e0c:	9381                	srli	a5,a5,0x20
    80200e0e:	00fce7b3          	or	a5,s9,a5
    80200e12:	f0f43423          	sd	a5,-248(s0)
    80200e16:	bf75                	j	80200dd2 <fdt_init+0x518>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e18:	44c8                	lw	a0,12(s1)
    80200e1a:	00000097          	auipc	ra,0x0
    80200e1e:	9da080e7          	jalr	-1574(ra) # 802007f4 <be32>
    80200e22:	02051793          	slli	a5,a0,0x20
    80200e26:	9381                	srli	a5,a5,0x20
    80200e28:	f0f43423          	sd	a5,-248(s0)
    80200e2c:	b75d                	j	80200dd2 <fdt_init+0x518>
                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e2e:	002a1493          	slli	s1,s4,0x2
    80200e32:	94ee                	add	s1,s1,s11
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e34:	4088                	lw	a0,0(s1)
    80200e36:	00000097          	auipc	ra,0x0
    80200e3a:	9be080e7          	jalr	-1602(ra) # 802007f4 <be32>
    80200e3e:	00050a1b          	sext.w	s4,a0
    80200e42:	40c8                	lw	a0,4(s1)
    80200e44:	00000097          	auipc	ra,0x0
    80200e48:	9b0080e7          	jalr	-1616(ra) # 802007f4 <be32>
    80200e4c:	1a02                	slli	s4,s4,0x20
    80200e4e:	02051793          	slli	a5,a0,0x20
    80200e52:	9381                	srli	a5,a5,0x20
    80200e54:	00fa67b3          	or	a5,s4,a5
    80200e58:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e5c:	ef843483          	ld	s1,-264(s0)
                have_reg = 1;
    80200e60:	4d05                	li	s10,1
    80200e62:	6cae                	ld	s9,200(sp)
    80200e64:	7dea                	ld	s11,184(sp)
    80200e66:	be29                	j	80200980 <fdt_init+0xc6>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200e68:	0a0a                	slli	s4,s4,0x2
    80200e6a:	9dd2                	add	s11,s11,s4
    80200e6c:	000da503          	lw	a0,0(s11)
    80200e70:	00000097          	auipc	ra,0x0
    80200e74:	984080e7          	jalr	-1660(ra) # 802007f4 <be32>
    80200e78:	02051793          	slli	a5,a0,0x20
    80200e7c:	9381                	srli	a5,a5,0x20
    80200e7e:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e82:	ef843483          	ld	s1,-264(s0)
    80200e86:	6cae                	ld	s9,200(sp)
    80200e88:	7dea                	ld	s11,184(sp)
    80200e8a:	bcdd                	j	80200980 <fdt_init+0xc6>
    80200e8c:	e5e6                	sd	s9,200(sp)
    80200e8e:	fd6e                	sd	s11,184(sp)
            }
            continue;
        }
        panic("fdt: unknown token in structure block");
    80200e90:	00006517          	auipc	a0,0x6
    80200e94:	4b050513          	addi	a0,a0,1200 # 80207340 <etext+0x340>
    80200e98:	fffff097          	auipc	ra,0xfffff
    80200e9c:	722080e7          	jalr	1826(ra) # 802005ba <panic>
    }

    if (fdt.ncpu == 0) fdt.ncpu = 1;
    80200ea0:	00028797          	auipc	a5,0x28
    80200ea4:	2187a783          	lw	a5,536(a5) # 802290b8 <fdt+0xa0>
    80200ea8:	ef8d                	bnez	a5,80200ee2 <fdt_init+0x628>
    80200eaa:	4785                	li	a5,1
    80200eac:	00028717          	auipc	a4,0x28
    80200eb0:	20f72623          	sw	a5,524(a4) # 802290b8 <fdt+0xa0>
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200eb4:	00028797          	auipc	a5,0x28
    80200eb8:	1747b783          	ld	a5,372(a5) # 80229028 <fdt+0x10>
    80200ebc:	cf85                	beqz	a5,80200ef4 <fdt_init+0x63a>
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200ebe:	00028797          	auipc	a5,0x28
    80200ec2:	1f27b783          	ld	a5,498(a5) # 802290b0 <fdt+0x98>
    80200ec6:	c3a9                	beqz	a5,80200f08 <fdt_init+0x64e>
    80200ec8:	64b2                	ld	s1,264(sp)
    80200eca:	6912                	ld	s2,256(sp)
    80200ecc:	7a4e                	ld	s4,240(sp)
    80200ece:	7aae                	ld	s5,232(sp)
    80200ed0:	7b0e                	ld	s6,224(sp)
    80200ed2:	6bee                	ld	s7,216(sp)
    80200ed4:	6c4e                	ld	s8,208(sp)
    80200ed6:	6d0e                	ld	s10,192(sp)
}
    80200ed8:	60f2                	ld	ra,280(sp)
    80200eda:	6452                	ld	s0,272(sp)
    80200edc:	79ee                	ld	s3,248(sp)
    80200ede:	6115                	addi	sp,sp,288
    80200ee0:	8082                	ret
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    80200ee2:	4721                	li	a4,8
    80200ee4:	fcf758e3          	bge	a4,a5,80200eb4 <fdt_init+0x5fa>
    80200ee8:	47a1                	li	a5,8
    80200eea:	00028717          	auipc	a4,0x28
    80200eee:	1cf72723          	sw	a5,462(a4) # 802290b8 <fdt+0xa0>
    80200ef2:	b7c9                	j	80200eb4 <fdt_init+0x5fa>
    80200ef4:	e5e6                	sd	s9,200(sp)
    80200ef6:	fd6e                	sd	s11,184(sp)
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200ef8:	00006517          	auipc	a0,0x6
    80200efc:	47050513          	addi	a0,a0,1136 # 80207368 <etext+0x368>
    80200f00:	fffff097          	auipc	ra,0xfffff
    80200f04:	6ba080e7          	jalr	1722(ra) # 802005ba <panic>
    80200f08:	e5e6                	sd	s9,200(sp)
    80200f0a:	fd6e                	sd	s11,184(sp)
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f0c:	00006517          	auipc	a0,0x6
    80200f10:	48450513          	addi	a0,a0,1156 # 80207390 <etext+0x390>
    80200f14:	fffff097          	auipc	ra,0xfffff
    80200f18:	6a6080e7          	jalr	1702(ra) # 802005ba <panic>
                fdt.ncpu++;
    80200f1c:	00028717          	auipc	a4,0x28
    80200f20:	0fc70713          	addi	a4,a4,252 # 80229018 <fdt>
    80200f24:	0a072783          	lw	a5,160(a4)
    80200f28:	2785                	addiw	a5,a5,1
    80200f2a:	0af72023          	sw	a5,160(a4)
            depth++;
    80200f2e:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200f30:	ee043423          	sd	zero,-280(s0)
    80200f34:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200f38:	f0043023          	sd	zero,-256(s0)
    80200f3c:	f0043423          	sd	zero,-248(s0)
    80200f40:	4d01                	li	s10,0
    80200f42:	4c01                	li	s8,0
    80200f44:	bc35                	j	80200980 <fdt_init+0xc6>

0000000080200f46 <palloc_init>:
} kmem;

#define PA2IDX(pa) (((uint64)(pa) - kmem.base) >> PGSHIFT)

void palloc_init(void)
{
    80200f46:	715d                	addi	sp,sp,-80
    80200f48:	e486                	sd	ra,72(sp)
    80200f4a:	e0a2                	sd	s0,64(sp)
    80200f4c:	fc26                	sd	s1,56(sp)
    80200f4e:	f84a                	sd	s2,48(sp)
    80200f50:	f44e                	sd	s3,40(sp)
    80200f52:	f052                	sd	s4,32(sp)
    80200f54:	ec56                	sd	s5,24(sp)
    80200f56:	e85a                	sd	s6,16(sp)
    80200f58:	e45e                	sd	s7,8(sp)
    80200f5a:	e062                	sd	s8,0(sp)
    80200f5c:	0880                	addi	s0,sp,80
    initlock(&kmem.lock, "kmem");
    80200f5e:	00028b97          	auipc	s7,0x28
    80200f62:	162b8b93          	addi	s7,s7,354 # 802290c0 <kmem>
    80200f66:	00006597          	auipc	a1,0x6
    80200f6a:	44258593          	addi	a1,a1,1090 # 802073a8 <etext+0x3a8>
    80200f6e:	855e                	mv	a0,s7
    80200f70:	00000097          	auipc	ra,0x0
    80200f74:	304080e7          	jalr	772(ra) # 80201274 <initlock>

    uint64 mem_start = fdt.mem_base;
    80200f78:	00028717          	auipc	a4,0x28
    80200f7c:	0a070713          	addi	a4,a4,160 # 80229018 <fdt>
    80200f80:	09073a83          	ld	s5,144(a4)
    uint64 mem_end   = fdt.mem_base + fdt.mem_size;
    80200f84:	09873a03          	ld	s4,152(a4)
    80200f88:	9a56                	add	s4,s4,s5





    uint64 free_start = PGROUNDUP((uint64)kernel_end);
    80200f8a:	6c05                	lui	s8,0x1
    80200f8c:	fffc0693          	addi	a3,s8,-1 # fff <_entry-0x801ff001>
    80200f90:	77fd                	lui	a5,0xfffff
    80200f92:	0013f617          	auipc	a2,0x13f
    80200f96:	06d60613          	addi	a2,a2,109 # 8033ffff <uart+0xfcf>
    80200f9a:	00f674b3          	and	s1,a2,a5
    uint64 fdt_lo = PGROUNDDOWN(fdt.blob);
    80200f9e:	00073903          	ld	s2,0(a4)
    80200fa2:	00f979b3          	and	s3,s2,a5
    uint64 fdt_hi = PGROUNDUP(fdt.blob + fdt.blob_size);
    80200fa6:	6718                	ld	a4,8(a4)
    80200fa8:	993a                	add	s2,s2,a4
    80200faa:	9936                	add	s2,s2,a3
    80200fac:	00f97933          	and	s2,s2,a5

    uint64 npages = (mem_end - free_start) >> PGSHIFT;
    80200fb0:	409a0b33          	sub	s6,s4,s1
    80200fb4:	00cb5b13          	srli	s6,s6,0xc

    /* Implementation note. */

    uint64 refbytes = PGROUNDUP(npages);
    80200fb8:	9b36                	add	s6,s6,a3
    80200fba:	00fb7b33          	and	s6,s6,a5
    kmem.refcnt = (uint8 *)free_start;
    80200fbe:	029bbc23          	sd	s1,56(s7)
    memset(kmem.refcnt, 0, refbytes);
    80200fc2:	865a                	mv	a2,s6
    80200fc4:	4581                	li	a1,0
    80200fc6:	8526                	mv	a0,s1
    80200fc8:	fffff097          	auipc	ra,0xfffff
    80200fcc:	698080e7          	jalr	1688(ra) # 80200660 <memset>
    free_start += refbytes;
    80200fd0:	01648633          	add	a2,s1,s6

    kmem.base = free_start;
    80200fd4:	02cbb023          	sd	a2,32(s7)
    kmem.top  = mem_end;
    80200fd8:	034bb423          	sd	s4,40(s7)
    kmem.freelist = 0;
    80200fdc:	000bbc23          	sd	zero,24(s7)
    kmem.nfree = 0;
    80200fe0:	020ba823          	sw	zero,48(s7)

    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80200fe4:	9c32                	add	s8,s8,a2
    80200fe6:	058a6063          	bltu	s4,s8,80201026 <palloc_init+0xe0>
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
            continue;                       /* never hand this page out    */
        struct run *r = (struct run *)p;
        kmem.refcnt[PA2IDX(p)] = 0;
    80200fea:	87de                	mv	a5,s7
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80200fec:	6505                	lui	a0,0x1
    80200fee:	6589                	lui	a1,0x2
    80200ff0:	a035                	j	8020101c <palloc_init+0xd6>
        kmem.refcnt[PA2IDX(p)] = 0;
    80200ff2:	7398                	ld	a4,32(a5)
    80200ff4:	40e60733          	sub	a4,a2,a4
    80200ff8:	8331                	srli	a4,a4,0xc
    80200ffa:	7f94                	ld	a3,56(a5)
    80200ffc:	9736                	add	a4,a4,a3
    80200ffe:	00070023          	sb	zero,0(a4)
        r->next = kmem.freelist;
    80201002:	6f98                	ld	a4,24(a5)
    80201004:	e218                	sd	a4,0(a2)
        kmem.freelist = r;
    80201006:	ef90                	sd	a2,24(a5)
        kmem.nfree++;
    80201008:	5b98                	lw	a4,48(a5)
    8020100a:	2705                	addiw	a4,a4,1
    8020100c:	db98                	sw	a4,48(a5)
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    8020100e:	00a606b3          	add	a3,a2,a0
    80201012:	962e                	add	a2,a2,a1
    80201014:	7798                	ld	a4,40(a5)
    80201016:	00c76863          	bltu	a4,a2,80201026 <palloc_init+0xe0>
    8020101a:	8636                	mv	a2,a3
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
    8020101c:	fd366be3          	bltu	a2,s3,80200ff2 <palloc_init+0xac>
    80201020:	fd2679e3          	bgeu	a2,s2,80200ff2 <palloc_init+0xac>
    80201024:	b7ed                	j	8020100e <palloc_init+0xc8>
    }
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    80201026:	00028697          	auipc	a3,0x28
    8020102a:	0ca6a683          	lw	a3,202(a3) # 802290f0 <kmem+0x30>
           mem_start, mem_end, kmem.nfree, (kmem.nfree * PGSIZE) >> 20);
    8020102e:	00c6971b          	slliw	a4,a3,0xc
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    80201032:	4147571b          	sraiw	a4,a4,0x14
    80201036:	8652                	mv	a2,s4
    80201038:	85d6                	mv	a1,s5
    8020103a:	00006517          	auipc	a0,0x6
    8020103e:	37650513          	addi	a0,a0,886 # 802073b0 <etext+0x3b0>
    80201042:	fffff097          	auipc	ra,0xfffff
    80201046:	306080e7          	jalr	774(ra) # 80200348 <printf>
}
    8020104a:	60a6                	ld	ra,72(sp)
    8020104c:	6406                	ld	s0,64(sp)
    8020104e:	74e2                	ld	s1,56(sp)
    80201050:	7942                	ld	s2,48(sp)
    80201052:	79a2                	ld	s3,40(sp)
    80201054:	7a02                	ld	s4,32(sp)
    80201056:	6ae2                	ld	s5,24(sp)
    80201058:	6b42                	ld	s6,16(sp)
    8020105a:	6ba2                	ld	s7,8(sp)
    8020105c:	6c02                	ld	s8,0(sp)
    8020105e:	6161                	addi	sp,sp,80
    80201060:	8082                	ret

0000000080201062 <palloc>:

void *palloc(void)
{
    80201062:	1101                	addi	sp,sp,-32
    80201064:	ec06                	sd	ra,24(sp)
    80201066:	e822                	sd	s0,16(sp)
    80201068:	e426                	sd	s1,8(sp)
    8020106a:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    8020106c:	00028497          	auipc	s1,0x28
    80201070:	05448493          	addi	s1,s1,84 # 802290c0 <kmem>
    80201074:	8526                	mv	a0,s1
    80201076:	00000097          	auipc	ra,0x0
    8020107a:	27a080e7          	jalr	634(ra) # 802012f0 <acquire>
    struct run *r = kmem.freelist;
    8020107e:	6c84                	ld	s1,24(s1)
    if (r) {
    80201080:	c4a1                	beqz	s1,802010c8 <palloc+0x66>
        kmem.freelist = r->next;
    80201082:	609c                	ld	a5,0(s1)
    80201084:	00028517          	auipc	a0,0x28
    80201088:	03c50513          	addi	a0,a0,60 # 802290c0 <kmem>
    8020108c:	ed1c                	sd	a5,24(a0)
        kmem.nfree--;
    8020108e:	591c                	lw	a5,48(a0)
    80201090:	37fd                	addiw	a5,a5,-1 # ffffffffffffefff <uart+0xffffffff7fcbffcf>
    80201092:	d91c                	sw	a5,48(a0)
        kmem.refcnt[PA2IDX(r)] = 1;
    80201094:	711c                	ld	a5,32(a0)
    80201096:	40f487b3          	sub	a5,s1,a5
    8020109a:	83b1                	srli	a5,a5,0xc
    8020109c:	7d18                	ld	a4,56(a0)
    8020109e:	97ba                	add	a5,a5,a4
    802010a0:	4705                	li	a4,1
    802010a2:	00e78023          	sb	a4,0(a5)
    }
    release(&kmem.lock);
    802010a6:	00000097          	auipc	ra,0x0
    802010aa:	2fe080e7          	jalr	766(ra) # 802013a4 <release>

    if (r)
        memset((void *)r, 5, PGSIZE);   /* poison: catch use-before-init */
    802010ae:	6605                	lui	a2,0x1
    802010b0:	4595                	li	a1,5
    802010b2:	8526                	mv	a0,s1
    802010b4:	fffff097          	auipc	ra,0xfffff
    802010b8:	5ac080e7          	jalr	1452(ra) # 80200660 <memset>
    return (void *)r;
}
    802010bc:	8526                	mv	a0,s1
    802010be:	60e2                	ld	ra,24(sp)
    802010c0:	6442                	ld	s0,16(sp)
    802010c2:	64a2                	ld	s1,8(sp)
    802010c4:	6105                	addi	sp,sp,32
    802010c6:	8082                	ret
    release(&kmem.lock);
    802010c8:	00028517          	auipc	a0,0x28
    802010cc:	ff850513          	addi	a0,a0,-8 # 802290c0 <kmem>
    802010d0:	00000097          	auipc	ra,0x0
    802010d4:	2d4080e7          	jalr	724(ra) # 802013a4 <release>
    if (r)
    802010d8:	b7d5                	j	802010bc <palloc+0x5a>

00000000802010da <palloc_ref_inc>:

void palloc_ref_inc(void *pa)
{
    802010da:	1101                	addi	sp,sp,-32
    802010dc:	ec06                	sd	ra,24(sp)
    802010de:	e822                	sd	s0,16(sp)
    802010e0:	e426                	sd	s1,8(sp)
    802010e2:	e04a                	sd	s2,0(sp)
    802010e4:	1000                	addi	s0,sp,32
    802010e6:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    802010e8:	00028917          	auipc	s2,0x28
    802010ec:	fd890913          	addi	s2,s2,-40 # 802290c0 <kmem>
    802010f0:	854a                	mv	a0,s2
    802010f2:	00000097          	auipc	ra,0x0
    802010f6:	1fe080e7          	jalr	510(ra) # 802012f0 <acquire>
    kmem.refcnt[PA2IDX(pa)]++;
    802010fa:	02093783          	ld	a5,32(s2)
    802010fe:	8c9d                	sub	s1,s1,a5
    80201100:	80b1                	srli	s1,s1,0xc
    80201102:	03893783          	ld	a5,56(s2)
    80201106:	97a6                	add	a5,a5,s1
    80201108:	0007c703          	lbu	a4,0(a5)
    8020110c:	2705                	addiw	a4,a4,1
    8020110e:	00e78023          	sb	a4,0(a5)
    release(&kmem.lock);
    80201112:	854a                	mv	a0,s2
    80201114:	00000097          	auipc	ra,0x0
    80201118:	290080e7          	jalr	656(ra) # 802013a4 <release>
}
    8020111c:	60e2                	ld	ra,24(sp)
    8020111e:	6442                	ld	s0,16(sp)
    80201120:	64a2                	ld	s1,8(sp)
    80201122:	6902                	ld	s2,0(sp)
    80201124:	6105                	addi	sp,sp,32
    80201126:	8082                	ret

0000000080201128 <palloc_ref_get>:

int palloc_ref_get(void *pa)
{
    80201128:	1101                	addi	sp,sp,-32
    8020112a:	ec06                	sd	ra,24(sp)
    8020112c:	e822                	sd	s0,16(sp)
    8020112e:	e426                	sd	s1,8(sp)
    80201130:	e04a                	sd	s2,0(sp)
    80201132:	1000                	addi	s0,sp,32
    80201134:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    80201136:	00028917          	auipc	s2,0x28
    8020113a:	f8a90913          	addi	s2,s2,-118 # 802290c0 <kmem>
    8020113e:	854a                	mv	a0,s2
    80201140:	00000097          	auipc	ra,0x0
    80201144:	1b0080e7          	jalr	432(ra) # 802012f0 <acquire>
    int n = kmem.refcnt[PA2IDX(pa)];
    80201148:	02093783          	ld	a5,32(s2)
    8020114c:	8c9d                	sub	s1,s1,a5
    8020114e:	80b1                	srli	s1,s1,0xc
    80201150:	03893783          	ld	a5,56(s2)
    80201154:	97a6                	add	a5,a5,s1
    80201156:	0007c483          	lbu	s1,0(a5)
    release(&kmem.lock);
    8020115a:	854a                	mv	a0,s2
    8020115c:	00000097          	auipc	ra,0x0
    80201160:	248080e7          	jalr	584(ra) # 802013a4 <release>
    return n;
}
    80201164:	8526                	mv	a0,s1
    80201166:	60e2                	ld	ra,24(sp)
    80201168:	6442                	ld	s0,16(sp)
    8020116a:	64a2                	ld	s1,8(sp)
    8020116c:	6902                	ld	s2,0(sp)
    8020116e:	6105                	addi	sp,sp,32
    80201170:	8082                	ret

0000000080201172 <pfree>:

void pfree(void *pa)
{
    80201172:	1101                	addi	sp,sp,-32
    80201174:	ec06                	sd	ra,24(sp)
    80201176:	e822                	sd	s0,16(sp)
    80201178:	e426                	sd	s1,8(sp)
    8020117a:	e04a                	sd	s2,0(sp)
    8020117c:	1000                	addi	s0,sp,32
    if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < kmem.base || (uint64)pa >= kmem.top)
    8020117e:	03451713          	slli	a4,a0,0x34
    80201182:	e359                	bnez	a4,80201208 <pfree+0x96>
    80201184:	84aa                	mv	s1,a0
    80201186:	00028717          	auipc	a4,0x28
    8020118a:	f5a73703          	ld	a4,-166(a4) # 802290e0 <kmem+0x20>
    8020118e:	06e56d63          	bltu	a0,a4,80201208 <pfree+0x96>
    80201192:	00028717          	auipc	a4,0x28
    80201196:	f5673703          	ld	a4,-170(a4) # 802290e8 <kmem+0x28>
    8020119a:	06e57763          	bgeu	a0,a4,80201208 <pfree+0x96>
        panic("pfree: bad pointer");

    acquire(&kmem.lock);
    8020119e:	00028917          	auipc	s2,0x28
    802011a2:	f2290913          	addi	s2,s2,-222 # 802290c0 <kmem>
    802011a6:	854a                	mv	a0,s2
    802011a8:	00000097          	auipc	ra,0x0
    802011ac:	148080e7          	jalr	328(ra) # 802012f0 <acquire>
    uint64 i = PA2IDX(pa);
    802011b0:	02093783          	ld	a5,32(s2)
    802011b4:	40f487b3          	sub	a5,s1,a5
    802011b8:	83b1                	srli	a5,a5,0xc
    if (kmem.refcnt[i] < 1)
    802011ba:	03893703          	ld	a4,56(s2)
    802011be:	973e                	add	a4,a4,a5
    802011c0:	00074783          	lbu	a5,0(a4)
    802011c4:	cbb1                	beqz	a5,80201218 <pfree+0xa6>
        panic("pfree: double free / refcount underflow");

    if (--kmem.refcnt[i] > 0) {          /* Implementation note. */
    802011c6:	37fd                	addiw	a5,a5,-1
    802011c8:	0ff7f793          	zext.b	a5,a5
    802011cc:	00f70023          	sb	a5,0(a4)
    802011d0:	efa1                	bnez	a5,80201228 <pfree+0xb6>
        release(&kmem.lock);
        return;
    }
    memset(pa, 1, PGSIZE);               /* poison: catch use-after-free */
    802011d2:	6605                	lui	a2,0x1
    802011d4:	4585                	li	a1,1
    802011d6:	8526                	mv	a0,s1
    802011d8:	fffff097          	auipc	ra,0xfffff
    802011dc:	488080e7          	jalr	1160(ra) # 80200660 <memset>
    struct run *r = (struct run *)pa;
    r->next = kmem.freelist;
    802011e0:	00028517          	auipc	a0,0x28
    802011e4:	ee050513          	addi	a0,a0,-288 # 802290c0 <kmem>
    802011e8:	6d1c                	ld	a5,24(a0)
    802011ea:	e09c                	sd	a5,0(s1)
    kmem.freelist = r;
    802011ec:	ed04                	sd	s1,24(a0)
    kmem.nfree++;
    802011ee:	591c                	lw	a5,48(a0)
    802011f0:	2785                	addiw	a5,a5,1
    802011f2:	d91c                	sw	a5,48(a0)
    release(&kmem.lock);
    802011f4:	00000097          	auipc	ra,0x0
    802011f8:	1b0080e7          	jalr	432(ra) # 802013a4 <release>
}
    802011fc:	60e2                	ld	ra,24(sp)
    802011fe:	6442                	ld	s0,16(sp)
    80201200:	64a2                	ld	s1,8(sp)
    80201202:	6902                	ld	s2,0(sp)
    80201204:	6105                	addi	sp,sp,32
    80201206:	8082                	ret
        panic("pfree: bad pointer");
    80201208:	00006517          	auipc	a0,0x6
    8020120c:	1e050513          	addi	a0,a0,480 # 802073e8 <etext+0x3e8>
    80201210:	fffff097          	auipc	ra,0xfffff
    80201214:	3aa080e7          	jalr	938(ra) # 802005ba <panic>
        panic("pfree: double free / refcount underflow");
    80201218:	00006517          	auipc	a0,0x6
    8020121c:	1e850513          	addi	a0,a0,488 # 80207400 <etext+0x400>
    80201220:	fffff097          	auipc	ra,0xfffff
    80201224:	39a080e7          	jalr	922(ra) # 802005ba <panic>
        release(&kmem.lock);
    80201228:	00028517          	auipc	a0,0x28
    8020122c:	e9850513          	addi	a0,a0,-360 # 802290c0 <kmem>
    80201230:	00000097          	auipc	ra,0x0
    80201234:	174080e7          	jalr	372(ra) # 802013a4 <release>
        return;
    80201238:	b7d1                	j	802011fc <pfree+0x8a>

000000008020123a <palloc_free_count>:

int palloc_free_count(void)
{
    8020123a:	1101                	addi	sp,sp,-32
    8020123c:	ec06                	sd	ra,24(sp)
    8020123e:	e822                	sd	s0,16(sp)
    80201240:	e426                	sd	s1,8(sp)
    80201242:	e04a                	sd	s2,0(sp)
    80201244:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    80201246:	00028497          	auipc	s1,0x28
    8020124a:	e7a48493          	addi	s1,s1,-390 # 802290c0 <kmem>
    8020124e:	8526                	mv	a0,s1
    80201250:	00000097          	auipc	ra,0x0
    80201254:	0a0080e7          	jalr	160(ra) # 802012f0 <acquire>
    int n = kmem.nfree;
    80201258:	0304a903          	lw	s2,48(s1)
    release(&kmem.lock);
    8020125c:	8526                	mv	a0,s1
    8020125e:	00000097          	auipc	ra,0x0
    80201262:	146080e7          	jalr	326(ra) # 802013a4 <release>
    return n;
}
    80201266:	854a                	mv	a0,s2
    80201268:	60e2                	ld	ra,24(sp)
    8020126a:	6442                	ld	s0,16(sp)
    8020126c:	64a2                	ld	s1,8(sp)
    8020126e:	6902                	ld	s2,0(sp)
    80201270:	6105                	addi	sp,sp,32
    80201272:	8082                	ret

0000000080201274 <initlock>:
#include "types.h"
#include "defs.h"
#include "hal.h"

void initlock(struct spinlock *lk, const char *name)
{
    80201274:	1141                	addi	sp,sp,-16
    80201276:	e422                	sd	s0,8(sp)
    80201278:	0800                	addi	s0,sp,16
    lk->name = name; lk->locked = 0; lk->cpu = -1;
    8020127a:	e50c                	sd	a1,8(a0)
    8020127c:	00052023          	sw	zero,0(a0)
    80201280:	57fd                	li	a5,-1
    80201282:	c91c                	sw	a5,16(a0)
}
    80201284:	6422                	ld	s0,8(sp)
    80201286:	0141                	addi	sp,sp,16
    80201288:	8082                	ret

000000008020128a <holding>:
    pop_off();
}

int holding(struct spinlock *lk)
{
    return lk->locked && lk->cpu == hal_hart_id();
    8020128a:	411c                	lw	a5,0(a0)
    8020128c:	e399                	bnez	a5,80201292 <holding+0x8>
    8020128e:	4501                	li	a0,0
}
    80201290:	8082                	ret
{
    80201292:	1101                	addi	sp,sp,-32
    80201294:	ec06                	sd	ra,24(sp)
    80201296:	e822                	sd	s0,16(sp)
    80201298:	e426                	sd	s1,8(sp)
    8020129a:	1000                	addi	s0,sp,32
    return lk->locked && lk->cpu == hal_hart_id();
    8020129c:	4904                	lw	s1,16(a0)
    8020129e:	00005097          	auipc	ra,0x5
    802012a2:	de4080e7          	jalr	-540(ra) # 80206082 <hal_hart_id>
    802012a6:	40a48533          	sub	a0,s1,a0
    802012aa:	00153513          	seqz	a0,a0
}
    802012ae:	60e2                	ld	ra,24(sp)
    802012b0:	6442                	ld	s0,16(sp)
    802012b2:	64a2                	ld	s1,8(sp)
    802012b4:	6105                	addi	sp,sp,32
    802012b6:	8082                	ret

00000000802012b8 <push_off>:

void push_off(void)
{
    802012b8:	1101                	addi	sp,sp,-32
    802012ba:	ec06                	sd	ra,24(sp)
    802012bc:	e822                	sd	s0,16(sp)
    802012be:	e426                	sd	s1,8(sp)
    802012c0:	1000                	addi	s0,sp,32
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802012c2:	100024f3          	csrr	s1,sstatus
    802012c6:	100027f3          	csrr	a5,sstatus
#define SIE_SSIE (1L << 1)
#define SIE_STIE (1L << 5)       /* timer  */
#define SIE_SEIE (1L << 9)       /* external */

static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    802012ca:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802012cc:	10079073          	csrw	sstatus,a5
    int old = intr_get();
    intr_off();
    struct cpu *c = mycpu();
    802012d0:	00000097          	auipc	ra,0x0
    802012d4:	3e6080e7          	jalr	998(ra) # 802016b6 <mycpu>
    if (c->noff == 0) c->intena = old;   /* remember the ORIGINAL state */
    802012d8:	5d3c                	lw	a5,120(a0)
    802012da:	e781                	bnez	a5,802012e2 <push_off+0x2a>
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    802012dc:	8085                	srli	s1,s1,0x1
    802012de:	8885                	andi	s1,s1,1
    802012e0:	dd64                	sw	s1,124(a0)
    c->noff++;
    802012e2:	2785                	addiw	a5,a5,1
    802012e4:	dd3c                	sw	a5,120(a0)
}
    802012e6:	60e2                	ld	ra,24(sp)
    802012e8:	6442                	ld	s0,16(sp)
    802012ea:	64a2                	ld	s1,8(sp)
    802012ec:	6105                	addi	sp,sp,32
    802012ee:	8082                	ret

00000000802012f0 <acquire>:
{
    802012f0:	1101                	addi	sp,sp,-32
    802012f2:	ec06                	sd	ra,24(sp)
    802012f4:	e822                	sd	s0,16(sp)
    802012f6:	e426                	sd	s1,8(sp)
    802012f8:	1000                	addi	s0,sp,32
    802012fa:	84aa                	mv	s1,a0
    push_off();
    802012fc:	00000097          	auipc	ra,0x0
    80201300:	fbc080e7          	jalr	-68(ra) # 802012b8 <push_off>
    if (holding(lk)) panic("acquire: already holding this lock");
    80201304:	8526                	mv	a0,s1
    80201306:	00000097          	auipc	ra,0x0
    8020130a:	f84080e7          	jalr	-124(ra) # 8020128a <holding>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    8020130e:	4705                	li	a4,1
    if (holding(lk)) panic("acquire: already holding this lock");
    80201310:	e115                	bnez	a0,80201334 <acquire+0x44>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80201312:	87ba                	mv	a5,a4
    80201314:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80201318:	2781                	sext.w	a5,a5
    8020131a:	ffe5                	bnez	a5,80201312 <acquire+0x22>
    __sync_synchronize();          /* fence: nothing below moves above this */
    8020131c:	0ff0000f          	fence
    lk->cpu = hal_hart_id();
    80201320:	00005097          	auipc	ra,0x5
    80201324:	d62080e7          	jalr	-670(ra) # 80206082 <hal_hart_id>
    80201328:	c888                	sw	a0,16(s1)
}
    8020132a:	60e2                	ld	ra,24(sp)
    8020132c:	6442                	ld	s0,16(sp)
    8020132e:	64a2                	ld	s1,8(sp)
    80201330:	6105                	addi	sp,sp,32
    80201332:	8082                	ret
    if (holding(lk)) panic("acquire: already holding this lock");
    80201334:	00006517          	auipc	a0,0x6
    80201338:	0f450513          	addi	a0,a0,244 # 80207428 <etext+0x428>
    8020133c:	fffff097          	auipc	ra,0xfffff
    80201340:	27e080e7          	jalr	638(ra) # 802005ba <panic>

0000000080201344 <pop_off>:

void pop_off(void)
{
    80201344:	1141                	addi	sp,sp,-16
    80201346:	e406                	sd	ra,8(sp)
    80201348:	e022                	sd	s0,0(sp)
    8020134a:	0800                	addi	s0,sp,16
    struct cpu *c = mycpu();
    8020134c:	00000097          	auipc	ra,0x0
    80201350:	36a080e7          	jalr	874(ra) # 802016b6 <mycpu>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201354:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201358:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("pop_off: interrupts already on");
    8020135a:	e78d                	bnez	a5,80201384 <pop_off+0x40>
    if (c->noff < 1) panic("pop_off: unbalanced");
    8020135c:	5d3c                	lw	a5,120(a0)
    8020135e:	02f05b63          	blez	a5,80201394 <pop_off+0x50>
    c->noff--;
    80201362:	37fd                	addiw	a5,a5,-1
    80201364:	0007871b          	sext.w	a4,a5
    80201368:	dd3c                	sw	a5,120(a0)
    if (c->noff == 0 && c->intena) intr_on();
    8020136a:	eb09                	bnez	a4,8020137c <pop_off+0x38>
    8020136c:	5d7c                	lw	a5,124(a0)
    8020136e:	c799                	beqz	a5,8020137c <pop_off+0x38>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201370:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80201374:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201378:	10079073          	csrw	sstatus,a5
}
    8020137c:	60a2                	ld	ra,8(sp)
    8020137e:	6402                	ld	s0,0(sp)
    80201380:	0141                	addi	sp,sp,16
    80201382:	8082                	ret
    if (intr_get()) panic("pop_off: interrupts already on");
    80201384:	00006517          	auipc	a0,0x6
    80201388:	0cc50513          	addi	a0,a0,204 # 80207450 <etext+0x450>
    8020138c:	fffff097          	auipc	ra,0xfffff
    80201390:	22e080e7          	jalr	558(ra) # 802005ba <panic>
    if (c->noff < 1) panic("pop_off: unbalanced");
    80201394:	00006517          	auipc	a0,0x6
    80201398:	0dc50513          	addi	a0,a0,220 # 80207470 <etext+0x470>
    8020139c:	fffff097          	auipc	ra,0xfffff
    802013a0:	21e080e7          	jalr	542(ra) # 802005ba <panic>

00000000802013a4 <release>:
{
    802013a4:	1101                	addi	sp,sp,-32
    802013a6:	ec06                	sd	ra,24(sp)
    802013a8:	e822                	sd	s0,16(sp)
    802013aa:	e426                	sd	s1,8(sp)
    802013ac:	1000                	addi	s0,sp,32
    802013ae:	84aa                	mv	s1,a0
    if (!holding(lk)) panic("release: not holding this lock");
    802013b0:	00000097          	auipc	ra,0x0
    802013b4:	eda080e7          	jalr	-294(ra) # 8020128a <holding>
    802013b8:	c115                	beqz	a0,802013dc <release+0x38>
    lk->cpu = -1;
    802013ba:	57fd                	li	a5,-1
    802013bc:	c89c                	sw	a5,16(s1)
    __sync_synchronize();          /* fence: nothing above moves below this */
    802013be:	0ff0000f          	fence
    __sync_lock_release(&lk->locked);
    802013c2:	0f50000f          	fence	iorw,ow
    802013c6:	0804a02f          	amoswap.w	zero,zero,(s1)
    pop_off();
    802013ca:	00000097          	auipc	ra,0x0
    802013ce:	f7a080e7          	jalr	-134(ra) # 80201344 <pop_off>
}
    802013d2:	60e2                	ld	ra,24(sp)
    802013d4:	6442                	ld	s0,16(sp)
    802013d6:	64a2                	ld	s1,8(sp)
    802013d8:	6105                	addi	sp,sp,32
    802013da:	8082                	ret
    if (!holding(lk)) panic("release: not holding this lock");
    802013dc:	00006517          	auipc	a0,0x6
    802013e0:	0ac50513          	addi	a0,a0,172 # 80207488 <etext+0x488>
    802013e4:	fffff097          	auipc	ra,0xfffff
    802013e8:	1d6080e7          	jalr	470(ra) # 802005ba <panic>

00000000802013ec <initsleeplock>:
 */
#include "types.h"
#include "defs.h"

void initsleeplock(struct sleeplock *lk, const char *name)
{
    802013ec:	1101                	addi	sp,sp,-32
    802013ee:	ec06                	sd	ra,24(sp)
    802013f0:	e822                	sd	s0,16(sp)
    802013f2:	e426                	sd	s1,8(sp)
    802013f4:	e04a                	sd	s2,0(sp)
    802013f6:	1000                	addi	s0,sp,32
    802013f8:	84aa                	mv	s1,a0
    802013fa:	892e                	mv	s2,a1
    initlock(&lk->lk, "sleep lock");
    802013fc:	00006597          	auipc	a1,0x6
    80201400:	0ac58593          	addi	a1,a1,172 # 802074a8 <etext+0x4a8>
    80201404:	0521                	addi	a0,a0,8
    80201406:	00000097          	auipc	ra,0x0
    8020140a:	e6e080e7          	jalr	-402(ra) # 80201274 <initlock>
    lk->name = name;
    8020140e:	0324b023          	sd	s2,32(s1)
    lk->locked = 0;
    80201412:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    80201416:	0204a423          	sw	zero,40(s1)
}
    8020141a:	60e2                	ld	ra,24(sp)
    8020141c:	6442                	ld	s0,16(sp)
    8020141e:	64a2                	ld	s1,8(sp)
    80201420:	6902                	ld	s2,0(sp)
    80201422:	6105                	addi	sp,sp,32
    80201424:	8082                	ret

0000000080201426 <acquiresleep>:

void acquiresleep(struct sleeplock *lk)
{
    80201426:	1101                	addi	sp,sp,-32
    80201428:	ec06                	sd	ra,24(sp)
    8020142a:	e822                	sd	s0,16(sp)
    8020142c:	e426                	sd	s1,8(sp)
    8020142e:	e04a                	sd	s2,0(sp)
    80201430:	1000                	addi	s0,sp,32
    80201432:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201434:	00850913          	addi	s2,a0,8
    80201438:	854a                	mv	a0,s2
    8020143a:	00000097          	auipc	ra,0x0
    8020143e:	eb6080e7          	jalr	-330(ra) # 802012f0 <acquire>
    while (lk->locked)
    80201442:	409c                	lw	a5,0(s1)
    80201444:	cb89                	beqz	a5,80201456 <acquiresleep+0x30>
        sleep(lk, &lk->lk);       /* releases lk->lk while asleep */
    80201446:	85ca                	mv	a1,s2
    80201448:	8526                	mv	a0,s1
    8020144a:	00001097          	auipc	ra,0x1
    8020144e:	8f4080e7          	jalr	-1804(ra) # 80201d3e <sleep>
    while (lk->locked)
    80201452:	409c                	lw	a5,0(s1)
    80201454:	fbed                	bnez	a5,80201446 <acquiresleep+0x20>
    lk->locked = 1;
    80201456:	4785                	li	a5,1
    80201458:	c09c                	sw	a5,0(s1)
    lk->pid = myproc()->pid;
    8020145a:	00000097          	auipc	ra,0x0
    8020145e:	280080e7          	jalr	640(ra) # 802016da <myproc>
    80201462:	591c                	lw	a5,48(a0)
    80201464:	d49c                	sw	a5,40(s1)
    release(&lk->lk);
    80201466:	854a                	mv	a0,s2
    80201468:	00000097          	auipc	ra,0x0
    8020146c:	f3c080e7          	jalr	-196(ra) # 802013a4 <release>
}
    80201470:	60e2                	ld	ra,24(sp)
    80201472:	6442                	ld	s0,16(sp)
    80201474:	64a2                	ld	s1,8(sp)
    80201476:	6902                	ld	s2,0(sp)
    80201478:	6105                	addi	sp,sp,32
    8020147a:	8082                	ret

000000008020147c <releasesleep>:

void releasesleep(struct sleeplock *lk)
{
    8020147c:	1101                	addi	sp,sp,-32
    8020147e:	ec06                	sd	ra,24(sp)
    80201480:	e822                	sd	s0,16(sp)
    80201482:	e426                	sd	s1,8(sp)
    80201484:	e04a                	sd	s2,0(sp)
    80201486:	1000                	addi	s0,sp,32
    80201488:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    8020148a:	00850913          	addi	s2,a0,8
    8020148e:	854a                	mv	a0,s2
    80201490:	00000097          	auipc	ra,0x0
    80201494:	e60080e7          	jalr	-416(ra) # 802012f0 <acquire>
    lk->locked = 0;
    80201498:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    8020149c:	0204a423          	sw	zero,40(s1)
    wakeup(lk);
    802014a0:	8526                	mv	a0,s1
    802014a2:	00001097          	auipc	ra,0x1
    802014a6:	a22080e7          	jalr	-1502(ra) # 80201ec4 <wakeup>
    release(&lk->lk);
    802014aa:	854a                	mv	a0,s2
    802014ac:	00000097          	auipc	ra,0x0
    802014b0:	ef8080e7          	jalr	-264(ra) # 802013a4 <release>
}
    802014b4:	60e2                	ld	ra,24(sp)
    802014b6:	6442                	ld	s0,16(sp)
    802014b8:	64a2                	ld	s1,8(sp)
    802014ba:	6902                	ld	s2,0(sp)
    802014bc:	6105                	addi	sp,sp,32
    802014be:	8082                	ret

00000000802014c0 <holdingsleep>:

int holdingsleep(struct sleeplock *lk)
{
    802014c0:	7179                	addi	sp,sp,-48
    802014c2:	f406                	sd	ra,40(sp)
    802014c4:	f022                	sd	s0,32(sp)
    802014c6:	ec26                	sd	s1,24(sp)
    802014c8:	e84a                	sd	s2,16(sp)
    802014ca:	1800                	addi	s0,sp,48
    802014cc:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    802014ce:	00850913          	addi	s2,a0,8
    802014d2:	854a                	mv	a0,s2
    802014d4:	00000097          	auipc	ra,0x0
    802014d8:	e1c080e7          	jalr	-484(ra) # 802012f0 <acquire>
    int r = lk->locked && (lk->pid == myproc()->pid);
    802014dc:	409c                	lw	a5,0(s1)
    802014de:	ef91                	bnez	a5,802014fa <holdingsleep+0x3a>
    802014e0:	4481                	li	s1,0
    release(&lk->lk);
    802014e2:	854a                	mv	a0,s2
    802014e4:	00000097          	auipc	ra,0x0
    802014e8:	ec0080e7          	jalr	-320(ra) # 802013a4 <release>
    return r;
}
    802014ec:	8526                	mv	a0,s1
    802014ee:	70a2                	ld	ra,40(sp)
    802014f0:	7402                	ld	s0,32(sp)
    802014f2:	64e2                	ld	s1,24(sp)
    802014f4:	6942                	ld	s2,16(sp)
    802014f6:	6145                	addi	sp,sp,48
    802014f8:	8082                	ret
    802014fa:	e44e                	sd	s3,8(sp)
    int r = lk->locked && (lk->pid == myproc()->pid);
    802014fc:	0284a983          	lw	s3,40(s1)
    80201500:	00000097          	auipc	ra,0x0
    80201504:	1da080e7          	jalr	474(ra) # 802016da <myproc>
    80201508:	5904                	lw	s1,48(a0)
    8020150a:	413484b3          	sub	s1,s1,s3
    8020150e:	0014b493          	seqz	s1,s1
    80201512:	69a2                	ld	s3,8(sp)
    80201514:	b7f9                	j	802014e2 <holdingsleep+0x22>

0000000080201516 <freeproc>:
        p->kstack = 0;
    }
}

static void freeproc(struct proc *p)
{
    80201516:	1101                	addi	sp,sp,-32
    80201518:	ec06                	sd	ra,24(sp)
    8020151a:	e822                	sd	s0,16(sp)
    8020151c:	e426                	sd	s1,8(sp)
    8020151e:	1000                	addi	s0,sp,32
    80201520:	84aa                	mv	s1,a0
    if (p->tf) pfree((void *)p->tf);
    80201522:	6d28                	ld	a0,88(a0)
    80201524:	c509                	beqz	a0,8020152e <freeproc+0x18>
    80201526:	00000097          	auipc	ra,0x0
    8020152a:	c4c080e7          	jalr	-948(ra) # 80201172 <pfree>
    p->tf = 0;
    8020152e:	0404bc23          	sd	zero,88(s1)
    if (p->pagetable) uvmfree(p->pagetable, p->sz);
    80201532:	68a8                	ld	a0,80(s1)
    80201534:	c511                	beqz	a0,80201540 <freeproc+0x2a>
    80201536:	64ac                	ld	a1,72(s1)
    80201538:	00002097          	auipc	ra,0x2
    8020153c:	86e080e7          	jalr	-1938(ra) # 80202da6 <uvmfree>
    p->pagetable = 0;
    80201540:	0404b823          	sd	zero,80(s1)
    p->kstack = 0;              /* statically allocated - nothing to free */
    80201544:	0404b023          	sd	zero,64(s1)
    p->sz = 0; p->pid = 0; p->parent = 0;
    80201548:	0404b423          	sd	zero,72(s1)
    8020154c:	0204a823          	sw	zero,48(s1)
    80201550:	0204bc23          	sd	zero,56(s1)
    p->name[0] = 0; p->chan = 0; p->killed = 0; p->xstate = 0;
    80201554:	14048c23          	sb	zero,344(s1)
    80201558:	0204b023          	sd	zero,32(s1)
    8020155c:	0204a423          	sw	zero,40(s1)
    80201560:	0204a623          	sw	zero,44(s1)
    p->state = UNUSED;
    80201564:	0004ac23          	sw	zero,24(s1)
}
    80201568:	60e2                	ld	ra,24(sp)
    8020156a:	6442                	ld	s0,16(sp)
    8020156c:	64a2                	ld	s1,8(sp)
    8020156e:	6105                	addi	sp,sp,32
    80201570:	8082                	ret

0000000080201572 <allocproc>:
    }
    usertrapret();
}

static struct proc *allocproc(void)
{
    80201572:	7179                	addi	sp,sp,-48
    80201574:	f406                	sd	ra,40(sp)
    80201576:	f022                	sd	s0,32(sp)
    80201578:	ec26                	sd	s1,24(sp)
    8020157a:	e84a                	sd	s2,16(sp)
    8020157c:	1800                	addi	s0,sp,48
    struct proc *p;
    for (p = proc; p < &proc[NPROC]; p++) {
    8020157e:	0012a497          	auipc	s1,0x12a
    80201582:	a8248493          	addi	s1,s1,-1406 # 8032b000 <proc>
    80201586:	0012f917          	auipc	s2,0x12f
    8020158a:	47a90913          	addi	s2,s2,1146 # 80330a00 <tickslock>
        acquire(&p->lock);
    8020158e:	8526                	mv	a0,s1
    80201590:	00000097          	auipc	ra,0x0
    80201594:	d60080e7          	jalr	-672(ra) # 802012f0 <acquire>
        if (p->state == UNUSED) goto found;
    80201598:	4c9c                	lw	a5,24(s1)
    8020159a:	cf81                	beqz	a5,802015b2 <allocproc+0x40>
        release(&p->lock);
    8020159c:	8526                	mv	a0,s1
    8020159e:	00000097          	auipc	ra,0x0
    802015a2:	e06080e7          	jalr	-506(ra) # 802013a4 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    802015a6:	16848493          	addi	s1,s1,360
    802015aa:	ff2492e3          	bne	s1,s2,8020158e <allocproc+0x1c>
    }
    return 0;
    802015ae:	4481                	li	s1,0
    802015b0:	a0d1                	j	80201674 <allocproc+0x102>
    802015b2:	e44e                	sd	s3,8(sp)
    acquire(&pid_lock);
    802015b4:	00029997          	auipc	s3,0x29
    802015b8:	a4c98993          	addi	s3,s3,-1460 # 8022a000 <pid_lock>
    802015bc:	854e                	mv	a0,s3
    802015be:	00000097          	auipc	ra,0x0
    802015c2:	d32080e7          	jalr	-718(ra) # 802012f0 <acquire>
    int pid = nextpid++;
    802015c6:	00007797          	auipc	a5,0x7
    802015ca:	a3e78793          	addi	a5,a5,-1474 # 80208004 <nextpid>
    802015ce:	0007a903          	lw	s2,0(a5)
    802015d2:	0019071b          	addiw	a4,s2,1
    802015d6:	c398                	sw	a4,0(a5)
    release(&pid_lock);
    802015d8:	854e                	mv	a0,s3
    802015da:	00000097          	auipc	ra,0x0
    802015de:	dca080e7          	jalr	-566(ra) # 802013a4 <release>

found:
    p->pid    = allocpid();
    802015e2:	0324a823          	sw	s2,48(s1)
    p->state  = USED;
    802015e6:	4785                	li	a5,1
    802015e8:	cc9c                	sw	a5,24(s1)
    p->killed = 0;
    802015ea:	0204a423          	sw	zero,40(s1)
    p->xstate = 0;
    802015ee:	0204a623          	sw	zero,44(s1)
    p->chan   = 0;
    802015f2:	0204b023          	sd	zero,32(s1)

    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    802015f6:	00000097          	auipc	ra,0x0
    802015fa:	a6c080e7          	jalr	-1428(ra) # 80201062 <palloc>
    802015fe:	892a                	mv	s2,a0
    80201600:	eca8                	sd	a0,88(s1)
    80201602:	c141                	beqz	a0,80201682 <allocproc+0x110>

    /* Contiguous, statically reserved. See the note at the top of this file. */
    p->kstack = (uint64)kstacks[p - proc];
    80201604:	0012a797          	auipc	a5,0x12a
    80201608:	9fc78793          	addi	a5,a5,-1540 # 8032b000 <proc>
    8020160c:	40f487b3          	sub	a5,s1,a5
    80201610:	4037d713          	srai	a4,a5,0x3
    80201614:	04fa57b7          	lui	a5,0x4fa5
    80201618:	fa578793          	addi	a5,a5,-91 # 4fa4fa5 <_entry-0x7b25b05b>
    8020161c:	07b2                	slli	a5,a5,0xc
    8020161e:	fa578793          	addi	a5,a5,-91
    80201622:	07b2                	slli	a5,a5,0xc
    80201624:	fa578793          	addi	a5,a5,-91
    80201628:	07b2                	slli	a5,a5,0xc
    8020162a:	fa578793          	addi	a5,a5,-91
    8020162e:	02f707b3          	mul	a5,a4,a5
    80201632:	07ba                	slli	a5,a5,0xe
    80201634:	0002a717          	auipc	a4,0x2a
    80201638:	9cc70713          	addi	a4,a4,-1588 # 8022b000 <kstacks>
    8020163c:	97ba                	add	a5,a5,a4
    8020163e:	e0bc                	sd	a5,64(s1)

    p->pagetable = uvmcreate();
    80201640:	00001097          	auipc	ra,0x1
    80201644:	6a6080e7          	jalr	1702(ra) # 80202ce6 <uvmcreate>
    80201648:	892a                	mv	s2,a0
    8020164a:	e8a8                	sd	a0,80(s1)
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    8020164c:	c921                	beqz	a0,8020169c <allocproc+0x12a>

    memset(&p->context, 0, sizeof(p->context));
    8020164e:	07000613          	li	a2,112
    80201652:	4581                	li	a1,0
    80201654:	06048513          	addi	a0,s1,96
    80201658:	fffff097          	auipc	ra,0xfffff
    8020165c:	008080e7          	jalr	8(ra) # 80200660 <memset>
    p->context.ra = (uint64)forkret;
    80201660:	00000797          	auipc	a5,0x0
    80201664:	0b678793          	addi	a5,a5,182 # 80201716 <forkret>
    80201668:	f0bc                	sd	a5,96(s1)
    p->context.sp = p->kstack + KSTACK_SIZE;
    8020166a:	60bc                	ld	a5,64(s1)
    8020166c:	6711                	lui	a4,0x4
    8020166e:	97ba                	add	a5,a5,a4
    80201670:	f4bc                	sd	a5,104(s1)
    80201672:	69a2                	ld	s3,8(sp)
    return p;
}
    80201674:	8526                	mv	a0,s1
    80201676:	70a2                	ld	ra,40(sp)
    80201678:	7402                	ld	s0,32(sp)
    8020167a:	64e2                	ld	s1,24(sp)
    8020167c:	6942                	ld	s2,16(sp)
    8020167e:	6145                	addi	sp,sp,48
    80201680:	8082                	ret
    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    80201682:	8526                	mv	a0,s1
    80201684:	00000097          	auipc	ra,0x0
    80201688:	e92080e7          	jalr	-366(ra) # 80201516 <freeproc>
    8020168c:	8526                	mv	a0,s1
    8020168e:	00000097          	auipc	ra,0x0
    80201692:	d16080e7          	jalr	-746(ra) # 802013a4 <release>
    80201696:	84ca                	mv	s1,s2
    80201698:	69a2                	ld	s3,8(sp)
    8020169a:	bfe9                	j	80201674 <allocproc+0x102>
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    8020169c:	8526                	mv	a0,s1
    8020169e:	00000097          	auipc	ra,0x0
    802016a2:	e78080e7          	jalr	-392(ra) # 80201516 <freeproc>
    802016a6:	8526                	mv	a0,s1
    802016a8:	00000097          	auipc	ra,0x0
    802016ac:	cfc080e7          	jalr	-772(ra) # 802013a4 <release>
    802016b0:	84ca                	mv	s1,s2
    802016b2:	69a2                	ld	s3,8(sp)
    802016b4:	b7c1                	j	80201674 <allocproc+0x102>

00000000802016b6 <mycpu>:
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    802016b6:	1141                	addi	sp,sp,-16
    802016b8:	e406                	sd	ra,8(sp)
    802016ba:	e022                	sd	s0,0(sp)
    802016bc:	0800                	addi	s0,sp,16
    802016be:	00005097          	auipc	ra,0x5
    802016c2:	9c4080e7          	jalr	-1596(ra) # 80206082 <hal_hart_id>
    802016c6:	051e                	slli	a0,a0,0x7
    802016c8:	00029797          	auipc	a5,0x29
    802016cc:	95078793          	addi	a5,a5,-1712 # 8022a018 <cpus>
    802016d0:	953e                	add	a0,a0,a5
    802016d2:	60a2                	ld	ra,8(sp)
    802016d4:	6402                	ld	s0,0(sp)
    802016d6:	0141                	addi	sp,sp,16
    802016d8:	8082                	ret

00000000802016da <myproc>:
{
    802016da:	1101                	addi	sp,sp,-32
    802016dc:	ec06                	sd	ra,24(sp)
    802016de:	e822                	sd	s0,16(sp)
    802016e0:	e426                	sd	s1,8(sp)
    802016e2:	1000                	addi	s0,sp,32
    push_off();
    802016e4:	00000097          	auipc	ra,0x0
    802016e8:	bd4080e7          	jalr	-1068(ra) # 802012b8 <push_off>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    802016ec:	00005097          	auipc	ra,0x5
    802016f0:	996080e7          	jalr	-1642(ra) # 80206082 <hal_hart_id>
    struct proc *p = mycpu()->proc;
    802016f4:	051e                	slli	a0,a0,0x7
    802016f6:	00029797          	auipc	a5,0x29
    802016fa:	90a78793          	addi	a5,a5,-1782 # 8022a000 <pid_lock>
    802016fe:	97aa                	add	a5,a5,a0
    80201700:	6f84                	ld	s1,24(a5)
    pop_off();
    80201702:	00000097          	auipc	ra,0x0
    80201706:	c42080e7          	jalr	-958(ra) # 80201344 <pop_off>
}
    8020170a:	8526                	mv	a0,s1
    8020170c:	60e2                	ld	ra,24(sp)
    8020170e:	6442                	ld	s0,16(sp)
    80201710:	64a2                	ld	s1,8(sp)
    80201712:	6105                	addi	sp,sp,32
    80201714:	8082                	ret

0000000080201716 <forkret>:
{
    80201716:	1101                	addi	sp,sp,-32
    80201718:	ec06                	sd	ra,24(sp)
    8020171a:	e822                	sd	s0,16(sp)
    8020171c:	1000                	addi	s0,sp,32
    release(&myproc()->lock);
    8020171e:	00000097          	auipc	ra,0x0
    80201722:	fbc080e7          	jalr	-68(ra) # 802016da <myproc>
    80201726:	00000097          	auipc	ra,0x0
    8020172a:	c7e080e7          	jalr	-898(ra) # 802013a4 <release>
    if (first) {
    8020172e:	00007797          	auipc	a5,0x7
    80201732:	8d27a783          	lw	a5,-1838(a5) # 80208000 <first.1>
    80201736:	eb89                	bnez	a5,80201748 <forkret+0x32>
    usertrapret();
    80201738:	00001097          	auipc	ra,0x1
    8020173c:	e2c080e7          	jalr	-468(ra) # 80202564 <usertrapret>
}
    80201740:	60e2                	ld	ra,24(sp)
    80201742:	6442                	ld	s0,16(sp)
    80201744:	6105                	addi	sp,sp,32
    80201746:	8082                	ret
    80201748:	e426                	sd	s1,8(sp)
        first = 0;
    8020174a:	00007797          	auipc	a5,0x7
    8020174e:	8a07ab23          	sw	zero,-1866(a5) # 80208000 <first.1>
        fsinit(ROOTDEV);
    80201752:	4501                	li	a0,0
    80201754:	00003097          	auipc	ra,0x3
    80201758:	56c080e7          	jalr	1388(ra) # 80204cc0 <fsinit>
        myproc()->cwd = namei("/");
    8020175c:	00000097          	auipc	ra,0x0
    80201760:	f7e080e7          	jalr	-130(ra) # 802016da <myproc>
    80201764:	84aa                	mv	s1,a0
    80201766:	00006517          	auipc	a0,0x6
    8020176a:	d5250513          	addi	a0,a0,-686 # 802074b8 <etext+0x4b8>
    8020176e:	00004097          	auipc	ra,0x4
    80201772:	0e6080e7          	jalr	230(ra) # 80205854 <namei>
    80201776:	14a4b823          	sd	a0,336(s1)
        __sync_synchronize();
    8020177a:	0ff0000f          	fence
    8020177e:	64a2                	ld	s1,8(sp)
    80201780:	bf65                	j	80201738 <forkret+0x22>

0000000080201782 <procinit>:
{
    80201782:	7179                	addi	sp,sp,-48
    80201784:	f406                	sd	ra,40(sp)
    80201786:	f022                	sd	s0,32(sp)
    80201788:	ec26                	sd	s1,24(sp)
    8020178a:	e84a                	sd	s2,16(sp)
    8020178c:	e44e                	sd	s3,8(sp)
    8020178e:	1800                	addi	s0,sp,48
    initlock(&pid_lock,  "nextpid");
    80201790:	00006597          	auipc	a1,0x6
    80201794:	d3058593          	addi	a1,a1,-720 # 802074c0 <etext+0x4c0>
    80201798:	00029517          	auipc	a0,0x29
    8020179c:	86850513          	addi	a0,a0,-1944 # 8022a000 <pid_lock>
    802017a0:	00000097          	auipc	ra,0x0
    802017a4:	ad4080e7          	jalr	-1324(ra) # 80201274 <initlock>
    initlock(&wait_lock, "wait_lock");
    802017a8:	00006597          	auipc	a1,0x6
    802017ac:	d2058593          	addi	a1,a1,-736 # 802074c8 <etext+0x4c8>
    802017b0:	00029517          	auipc	a0,0x29
    802017b4:	c6850513          	addi	a0,a0,-920 # 8022a418 <wait_lock>
    802017b8:	00000097          	auipc	ra,0x0
    802017bc:	abc080e7          	jalr	-1348(ra) # 80201274 <initlock>
    initlock(&tickslock, "time");
    802017c0:	00006597          	auipc	a1,0x6
    802017c4:	d1858593          	addi	a1,a1,-744 # 802074d8 <etext+0x4d8>
    802017c8:	0012f517          	auipc	a0,0x12f
    802017cc:	23850513          	addi	a0,a0,568 # 80330a00 <tickslock>
    802017d0:	00000097          	auipc	ra,0x0
    802017d4:	aa4080e7          	jalr	-1372(ra) # 80201274 <initlock>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802017d8:	0012a497          	auipc	s1,0x12a
    802017dc:	82848493          	addi	s1,s1,-2008 # 8032b000 <proc>
        initlock(&p->lock, "proc");
    802017e0:	00006997          	auipc	s3,0x6
    802017e4:	d0098993          	addi	s3,s3,-768 # 802074e0 <etext+0x4e0>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802017e8:	0012f917          	auipc	s2,0x12f
    802017ec:	21890913          	addi	s2,s2,536 # 80330a00 <tickslock>
        initlock(&p->lock, "proc");
    802017f0:	85ce                	mv	a1,s3
    802017f2:	8526                	mv	a0,s1
    802017f4:	00000097          	auipc	ra,0x0
    802017f8:	a80080e7          	jalr	-1408(ra) # 80201274 <initlock>
        p->state  = UNUSED;
    802017fc:	0004ac23          	sw	zero,24(s1)
        p->kstack = 0;
    80201800:	0404b023          	sd	zero,64(s1)
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201804:	16848493          	addi	s1,s1,360
    80201808:	ff2494e3          	bne	s1,s2,802017f0 <procinit+0x6e>
}
    8020180c:	70a2                	ld	ra,40(sp)
    8020180e:	7402                	ld	s0,32(sp)
    80201810:	64e2                	ld	s1,24(sp)
    80201812:	6942                	ld	s2,16(sp)
    80201814:	69a2                	ld	s3,8(sp)
    80201816:	6145                	addi	sp,sp,48
    80201818:	8082                	ret

000000008020181a <userinit>:

/* --- the very first user process, built by hand --- */
extern char _binary_user_initcode_start[], _binary_user_initcode_end[];

void userinit(void)
{
    8020181a:	7179                	addi	sp,sp,-48
    8020181c:	f406                	sd	ra,40(sp)
    8020181e:	f022                	sd	s0,32(sp)
    80201820:	ec26                	sd	s1,24(sp)
    80201822:	e84a                	sd	s2,16(sp)
    80201824:	e44e                	sd	s3,8(sp)
    80201826:	1800                	addi	s0,sp,48
    struct proc *p = allocproc();
    80201828:	00000097          	auipc	ra,0x0
    8020182c:	d4a080e7          	jalr	-694(ra) # 80201572 <allocproc>
    if (!p) panic("userinit: allocproc failed");
    80201830:	c569                	beqz	a0,802018fa <userinit+0xe0>
    80201832:	84aa                	mv	s1,a0
    initproc = p;
    80201834:	0013d797          	auipc	a5,0x13d
    80201838:	7ca7be23          	sd	a0,2012(a5) # 8033f010 <initproc>

    uint64 sz = (uint64)(_binary_user_initcode_end - _binary_user_initcode_start);
    8020183c:	00006997          	auipc	s3,0x6
    80201840:	73c98993          	addi	s3,s3,1852 # 80207f78 <_binary_user_initcode_end>
    80201844:	00006797          	auipc	a5,0x6
    80201848:	6fc78793          	addi	a5,a5,1788 # 80207f40 <_binary_user_initcode_start>
    8020184c:	40f989b3          	sub	s3,s3,a5
    if (sz > PGSIZE) panic("userinit: initcode too big");
    80201850:	6785                	lui	a5,0x1
    80201852:	0b37ec63          	bltu	a5,s3,8020190a <userinit+0xf0>

    char *mem = palloc();
    80201856:	00000097          	auipc	ra,0x0
    8020185a:	80c080e7          	jalr	-2036(ra) # 80201062 <palloc>
    8020185e:	892a                	mv	s2,a0
    memset(mem, 0, PGSIZE);
    80201860:	6605                	lui	a2,0x1
    80201862:	4581                	li	a1,0
    80201864:	fffff097          	auipc	ra,0xfffff
    80201868:	dfc080e7          	jalr	-516(ra) # 80200660 <memset>
    memmove(mem, _binary_user_initcode_start, sz);
    8020186c:	864e                	mv	a2,s3
    8020186e:	00006597          	auipc	a1,0x6
    80201872:	6d258593          	addi	a1,a1,1746 # 80207f40 <_binary_user_initcode_start>
    80201876:	854a                	mv	a0,s2
    80201878:	fffff097          	auipc	ra,0xfffff
    8020187c:	e04080e7          	jalr	-508(ra) # 8020067c <memmove>
    mappages(p->pagetable, 0, PGSIZE, (uint64)mem, PTE_R | PTE_W | PTE_X | PTE_U);
    80201880:	4779                	li	a4,30
    80201882:	86ca                	mv	a3,s2
    80201884:	6605                	lui	a2,0x1
    80201886:	4581                	li	a1,0
    80201888:	68a8                	ld	a0,80(s1)
    8020188a:	00001097          	auipc	ra,0x1
    8020188e:	24a080e7          	jalr	586(ra) # 80202ad4 <mappages>

    char *stack = palloc();
    80201892:	fffff097          	auipc	ra,0xfffff
    80201896:	7d0080e7          	jalr	2000(ra) # 80201062 <palloc>
    8020189a:	892a                	mv	s2,a0
    memset(stack, 0, PGSIZE);
    8020189c:	6605                	lui	a2,0x1
    8020189e:	4581                	li	a1,0
    802018a0:	fffff097          	auipc	ra,0xfffff
    802018a4:	dc0080e7          	jalr	-576(ra) # 80200660 <memset>
    mappages(p->pagetable, PGSIZE, PGSIZE, (uint64)stack, PTE_R | PTE_W | PTE_U);
    802018a8:	4759                	li	a4,22
    802018aa:	86ca                	mv	a3,s2
    802018ac:	6605                	lui	a2,0x1
    802018ae:	6585                	lui	a1,0x1
    802018b0:	68a8                	ld	a0,80(s1)
    802018b2:	00001097          	auipc	ra,0x1
    802018b6:	222080e7          	jalr	546(ra) # 80202ad4 <mappages>

    p->sz       = 2 * PGSIZE;
    802018ba:	6789                	lui	a5,0x2
    802018bc:	e4bc                	sd	a5,72(s1)
    p->tf->epc  = 0;                    /* start at the first byte of initcode */
    802018be:	6cb8                	ld	a4,88(s1)
    802018c0:	00073c23          	sd	zero,24(a4) # 4018 <_entry-0x801fbfe8>
    p->tf->sp   = 2 * PGSIZE;           /* stack grows down from the top       */
    802018c4:	6cb8                	ld	a4,88(s1)
    802018c6:	fb1c                	sd	a5,48(a4)
    strncpy(p->name, "initcode", sizeof(p->name));
    802018c8:	4641                	li	a2,16
    802018ca:	00006597          	auipc	a1,0x6
    802018ce:	c5e58593          	addi	a1,a1,-930 # 80207528 <etext+0x528>
    802018d2:	15848513          	addi	a0,s1,344
    802018d6:	fffff097          	auipc	ra,0xfffff
    802018da:	e4c080e7          	jalr	-436(ra) # 80200722 <strncpy>
    /* p->cwd is set by forkret once the filesystem is initialized. */
    p->state    = RUNNABLE;
    802018de:	478d                	li	a5,3
    802018e0:	cc9c                	sw	a5,24(s1)
    release(&p->lock);
    802018e2:	8526                	mv	a0,s1
    802018e4:	00000097          	auipc	ra,0x0
    802018e8:	ac0080e7          	jalr	-1344(ra) # 802013a4 <release>
}
    802018ec:	70a2                	ld	ra,40(sp)
    802018ee:	7402                	ld	s0,32(sp)
    802018f0:	64e2                	ld	s1,24(sp)
    802018f2:	6942                	ld	s2,16(sp)
    802018f4:	69a2                	ld	s3,8(sp)
    802018f6:	6145                	addi	sp,sp,48
    802018f8:	8082                	ret
    if (!p) panic("userinit: allocproc failed");
    802018fa:	00006517          	auipc	a0,0x6
    802018fe:	bee50513          	addi	a0,a0,-1042 # 802074e8 <etext+0x4e8>
    80201902:	fffff097          	auipc	ra,0xfffff
    80201906:	cb8080e7          	jalr	-840(ra) # 802005ba <panic>
    if (sz > PGSIZE) panic("userinit: initcode too big");
    8020190a:	00006517          	auipc	a0,0x6
    8020190e:	bfe50513          	addi	a0,a0,-1026 # 80207508 <etext+0x508>
    80201912:	fffff097          	auipc	ra,0xfffff
    80201916:	ca8080e7          	jalr	-856(ra) # 802005ba <panic>

000000008020191a <growproc>:

int growproc(int n)
{
    8020191a:	7139                	addi	sp,sp,-64
    8020191c:	fc06                	sd	ra,56(sp)
    8020191e:	f822                	sd	s0,48(sp)
    80201920:	ec4e                	sd	s3,24(sp)
    80201922:	e852                	sd	s4,16(sp)
    80201924:	e456                	sd	s5,8(sp)
    80201926:	0080                	addi	s0,sp,64
    80201928:	8a2a                	mv	s4,a0
    struct proc *p = myproc();
    8020192a:	00000097          	auipc	ra,0x0
    8020192e:	db0080e7          	jalr	-592(ra) # 802016da <myproc>
    80201932:	89aa                	mv	s3,a0
    uint64 sz = p->sz;
    80201934:	04853a83          	ld	s5,72(a0)

    if (n > 0) {
    80201938:	07405863          	blez	s4,802019a8 <growproc+0x8e>
    8020193c:	f04a                	sd	s2,32(sp)
    8020193e:	e05a                	sd	s6,0(sp)
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    80201940:	6905                	lui	s2,0x1
    80201942:	197d                	addi	s2,s2,-1 # fff <_entry-0x801ff001>
    80201944:	9956                	add	s2,s2,s5
    80201946:	77fd                	lui	a5,0xfffff
    80201948:	00f97933          	and	s2,s2,a5
    8020194c:	015a0b33          	add	s6,s4,s5
    80201950:	0b697263          	bgeu	s2,s6,802019f4 <growproc+0xda>
    80201954:	f426                	sd	s1,40(sp)
            char *mem = palloc();
    80201956:	fffff097          	auipc	ra,0xfffff
    8020195a:	70c080e7          	jalr	1804(ra) # 80201062 <palloc>
    8020195e:	84aa                	mv	s1,a0
            if (!mem) return -1;
    80201960:	cd49                	beqz	a0,802019fa <growproc+0xe0>
            memset(mem, 0, PGSIZE);
    80201962:	6605                	lui	a2,0x1
    80201964:	4581                	li	a1,0
    80201966:	fffff097          	auipc	ra,0xfffff
    8020196a:	cfa080e7          	jalr	-774(ra) # 80200660 <memset>
            if (mappages(p->pagetable, a, PGSIZE, (uint64)mem,
    8020196e:	4759                	li	a4,22
    80201970:	86a6                	mv	a3,s1
    80201972:	6605                	lui	a2,0x1
    80201974:	85ca                	mv	a1,s2
    80201976:	0509b503          	ld	a0,80(s3)
    8020197a:	00001097          	auipc	ra,0x1
    8020197e:	15a080e7          	jalr	346(ra) # 80202ad4 <mappages>
    80201982:	e909                	bnez	a0,80201994 <growproc+0x7a>
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    80201984:	6785                	lui	a5,0x1
    80201986:	993e                	add	s2,s2,a5
    80201988:	fd6967e3          	bltu	s2,s6,80201956 <growproc+0x3c>
    8020198c:	74a2                	ld	s1,40(sp)
    8020198e:	7902                	ld	s2,32(sp)
    80201990:	6b02                	ld	s6,0(sp)
    80201992:	a829                	j	802019ac <growproc+0x92>
                         PTE_R | PTE_W | PTE_U) != 0) {
                pfree(mem);
    80201994:	8526                	mv	a0,s1
    80201996:	fffff097          	auipc	ra,0xfffff
    8020199a:	7dc080e7          	jalr	2012(ra) # 80201172 <pfree>
                return -1;
    8020199e:	557d                	li	a0,-1
    802019a0:	74a2                	ld	s1,40(sp)
    802019a2:	7902                	ld	s2,32(sp)
    802019a4:	6b02                	ld	s6,0(sp)
    802019a6:	a039                	j	802019b4 <growproc+0x9a>
            }
        }
    } else if (n < 0) {
    802019a8:	000a4d63          	bltz	s4,802019c2 <growproc+0xa8>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
        sz = newsz;
        p->sz = sz;
        return 0;
    }
    p->sz = sz + n;
    802019ac:	9a56                	add	s4,s4,s5
    802019ae:	0549b423          	sd	s4,72(s3)
    return 0;
    802019b2:	4501                	li	a0,0
}
    802019b4:	70e2                	ld	ra,56(sp)
    802019b6:	7442                	ld	s0,48(sp)
    802019b8:	69e2                	ld	s3,24(sp)
    802019ba:	6a42                	ld	s4,16(sp)
    802019bc:	6aa2                	ld	s5,8(sp)
    802019be:	6121                	addi	sp,sp,64
    802019c0:	8082                	ret
        uint64 newsz = sz + n;
    802019c2:	9a56                	add	s4,s4,s5
        if (PGROUNDUP(newsz) < PGROUNDUP(sz))
    802019c4:	6785                	lui	a5,0x1
    802019c6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    802019c8:	00fa05b3          	add	a1,s4,a5
    802019cc:	777d                	lui	a4,0xfffff
    802019ce:	8df9                	and	a1,a1,a4
    802019d0:	97d6                	add	a5,a5,s5
    802019d2:	8ff9                	and	a5,a5,a4
    802019d4:	00f5e663          	bltu	a1,a5,802019e0 <growproc+0xc6>
        p->sz = sz;
    802019d8:	0549b423          	sd	s4,72(s3)
        return 0;
    802019dc:	4501                	li	a0,0
    802019de:	bfd9                	j	802019b4 <growproc+0x9a>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
    802019e0:	8f8d                	sub	a5,a5,a1
            uvmunmap(p->pagetable, PGROUNDUP(newsz),
    802019e2:	4685                	li	a3,1
    802019e4:	00c7d613          	srli	a2,a5,0xc
    802019e8:	6928                	ld	a0,80(a0)
    802019ea:	00001097          	auipc	ra,0x1
    802019ee:	348080e7          	jalr	840(ra) # 80202d32 <uvmunmap>
    802019f2:	b7dd                	j	802019d8 <growproc+0xbe>
    802019f4:	7902                	ld	s2,32(sp)
    802019f6:	6b02                	ld	s6,0(sp)
    802019f8:	bf55                	j	802019ac <growproc+0x92>
            if (!mem) return -1;
    802019fa:	557d                	li	a0,-1
    802019fc:	74a2                	ld	s1,40(sp)
    802019fe:	7902                	ld	s2,32(sp)
    80201a00:	6b02                	ld	s6,0(sp)
    80201a02:	bf4d                	j	802019b4 <growproc+0x9a>

0000000080201a04 <fork>:

int fork(void)
{
    80201a04:	7139                	addi	sp,sp,-64
    80201a06:	fc06                	sd	ra,56(sp)
    80201a08:	f822                	sd	s0,48(sp)
    80201a0a:	f04a                	sd	s2,32(sp)
    80201a0c:	e456                	sd	s5,8(sp)
    80201a0e:	0080                	addi	s0,sp,64
    struct proc *parent = myproc();
    80201a10:	00000097          	auipc	ra,0x0
    80201a14:	cca080e7          	jalr	-822(ra) # 802016da <myproc>
    80201a18:	8aaa                	mv	s5,a0
    struct proc *np = allocproc();
    80201a1a:	00000097          	auipc	ra,0x0
    80201a1e:	b58080e7          	jalr	-1192(ra) # 80201572 <allocproc>
    if (!np) return -1;
    80201a22:	12050063          	beqz	a0,80201b42 <fork+0x13e>
    80201a26:	e852                	sd	s4,16(sp)
    80201a28:	8a2a                	mv	s4,a0

    /* Implementation note. */


    if (uvmcopy(parent->pagetable, np->pagetable, parent->sz) < 0) {
    80201a2a:	048ab603          	ld	a2,72(s5)
    80201a2e:	692c                	ld	a1,80(a0)
    80201a30:	050ab503          	ld	a0,80(s5)
    80201a34:	00001097          	auipc	ra,0x1
    80201a38:	3ae080e7          	jalr	942(ra) # 80202de2 <uvmcopy>
    80201a3c:	04054a63          	bltz	a0,80201a90 <fork+0x8c>
    80201a40:	f426                	sd	s1,40(sp)
    80201a42:	ec4e                	sd	s3,24(sp)
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = parent->sz;
    80201a44:	048ab783          	ld	a5,72(s5)
    80201a48:	04fa3423          	sd	a5,72(s4)
    *(np->tf) = *(parent->tf);
    80201a4c:	058ab683          	ld	a3,88(s5)
    80201a50:	87b6                	mv	a5,a3
    80201a52:	058a3703          	ld	a4,88(s4)
    80201a56:	12068693          	addi	a3,a3,288
    80201a5a:	0007b803          	ld	a6,0(a5)
    80201a5e:	6788                	ld	a0,8(a5)
    80201a60:	6b8c                	ld	a1,16(a5)
    80201a62:	6f90                	ld	a2,24(a5)
    80201a64:	01073023          	sd	a6,0(a4) # fffffffffffff000 <uart+0xffffffff7fcbffd0>
    80201a68:	e708                	sd	a0,8(a4)
    80201a6a:	eb0c                	sd	a1,16(a4)
    80201a6c:	ef10                	sd	a2,24(a4)
    80201a6e:	02078793          	addi	a5,a5,32
    80201a72:	02070713          	addi	a4,a4,32
    80201a76:	fed792e3          	bne	a5,a3,80201a5a <fork+0x56>
    np->tf->a0 = 0;                 /* the child sees fork() return 0 */
    80201a7a:	058a3783          	ld	a5,88(s4)
    80201a7e:	0607b823          	sd	zero,112(a5)

    /* The child INHERITS the parent's open files and cwd - this is what makes
     * `cmd > file` work: the shell redirects, then forks, and the child keeps
     * the redirected descriptor. Same struct file, same offset. */
    for (int i = 0; i < NOFILE; i++)
    80201a82:	0d0a8493          	addi	s1,s5,208
    80201a86:	0d0a0913          	addi	s2,s4,208
    80201a8a:	150a8993          	addi	s3,s5,336
    80201a8e:	a015                	j	80201ab2 <fork+0xae>
        freeproc(np);
    80201a90:	8552                	mv	a0,s4
    80201a92:	00000097          	auipc	ra,0x0
    80201a96:	a84080e7          	jalr	-1404(ra) # 80201516 <freeproc>
        release(&np->lock);
    80201a9a:	8552                	mv	a0,s4
    80201a9c:	00000097          	auipc	ra,0x0
    80201aa0:	908080e7          	jalr	-1784(ra) # 802013a4 <release>
        return -1;
    80201aa4:	597d                	li	s2,-1
    80201aa6:	6a42                	ld	s4,16(sp)
    80201aa8:	a071                	j	80201b34 <fork+0x130>
    for (int i = 0; i < NOFILE; i++)
    80201aaa:	04a1                	addi	s1,s1,8
    80201aac:	0921                	addi	s2,s2,8
    80201aae:	01348b63          	beq	s1,s3,80201ac4 <fork+0xc0>
        if (parent->ofile[i])
    80201ab2:	6088                	ld	a0,0(s1)
    80201ab4:	d97d                	beqz	a0,80201aaa <fork+0xa6>
            np->ofile[i] = filedup(parent->ofile[i]);
    80201ab6:	00004097          	auipc	ra,0x4
    80201aba:	e6a080e7          	jalr	-406(ra) # 80205920 <filedup>
    80201abe:	00a93023          	sd	a0,0(s2)
    80201ac2:	b7e5                	j	80201aaa <fork+0xa6>
    np->cwd = idup(parent->cwd);
    80201ac4:	150ab503          	ld	a0,336(s5)
    80201ac8:	00003097          	auipc	ra,0x3
    80201acc:	4ba080e7          	jalr	1210(ra) # 80204f82 <idup>
    80201ad0:	14aa3823          	sd	a0,336(s4)

    strncpy(np->name, parent->name, sizeof(np->name));
    80201ad4:	4641                	li	a2,16
    80201ad6:	158a8593          	addi	a1,s5,344
    80201ada:	158a0513          	addi	a0,s4,344
    80201ade:	fffff097          	auipc	ra,0xfffff
    80201ae2:	c44080e7          	jalr	-956(ra) # 80200722 <strncpy>
    int pid = np->pid;
    80201ae6:	030a2903          	lw	s2,48(s4)
    release(&np->lock);
    80201aea:	8552                	mv	a0,s4
    80201aec:	00000097          	auipc	ra,0x0
    80201af0:	8b8080e7          	jalr	-1864(ra) # 802013a4 <release>

    acquire(&wait_lock);
    80201af4:	00029497          	auipc	s1,0x29
    80201af8:	92448493          	addi	s1,s1,-1756 # 8022a418 <wait_lock>
    80201afc:	8526                	mv	a0,s1
    80201afe:	fffff097          	auipc	ra,0xfffff
    80201b02:	7f2080e7          	jalr	2034(ra) # 802012f0 <acquire>
    np->parent = parent;
    80201b06:	035a3c23          	sd	s5,56(s4)
    release(&wait_lock);
    80201b0a:	8526                	mv	a0,s1
    80201b0c:	00000097          	auipc	ra,0x0
    80201b10:	898080e7          	jalr	-1896(ra) # 802013a4 <release>

    acquire(&np->lock);
    80201b14:	8552                	mv	a0,s4
    80201b16:	fffff097          	auipc	ra,0xfffff
    80201b1a:	7da080e7          	jalr	2010(ra) # 802012f0 <acquire>
    np->state = RUNNABLE;
    80201b1e:	478d                	li	a5,3
    80201b20:	00fa2c23          	sw	a5,24(s4)
    release(&np->lock);
    80201b24:	8552                	mv	a0,s4
    80201b26:	00000097          	auipc	ra,0x0
    80201b2a:	87e080e7          	jalr	-1922(ra) # 802013a4 <release>
    return pid;
    80201b2e:	74a2                	ld	s1,40(sp)
    80201b30:	69e2                	ld	s3,24(sp)
    80201b32:	6a42                	ld	s4,16(sp)
}
    80201b34:	854a                	mv	a0,s2
    80201b36:	70e2                	ld	ra,56(sp)
    80201b38:	7442                	ld	s0,48(sp)
    80201b3a:	7902                	ld	s2,32(sp)
    80201b3c:	6aa2                	ld	s5,8(sp)
    80201b3e:	6121                	addi	sp,sp,64
    80201b40:	8082                	ret
    if (!np) return -1;
    80201b42:	597d                	li	s2,-1
    80201b44:	bfc5                	j	80201b34 <fork+0x130>

0000000080201b46 <scheduler>:
    }
}

/* Implementation note. */
void scheduler(void)
{
    80201b46:	715d                	addi	sp,sp,-80
    80201b48:	e486                	sd	ra,72(sp)
    80201b4a:	e0a2                	sd	s0,64(sp)
    80201b4c:	fc26                	sd	s1,56(sp)
    80201b4e:	f84a                	sd	s2,48(sp)
    80201b50:	f44e                	sd	s3,40(sp)
    80201b52:	f052                	sd	s4,32(sp)
    80201b54:	ec56                	sd	s5,24(sp)
    80201b56:	e85a                	sd	s6,16(sp)
    80201b58:	e45e                	sd	s7,8(sp)
    80201b5a:	0880                	addi	s0,sp,80
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201b5c:	00004097          	auipc	ra,0x4
    80201b60:	526080e7          	jalr	1318(ra) # 80206082 <hal_hart_id>
    struct cpu *c = mycpu();
    c->proc = 0;
    80201b64:	00751b13          	slli	s6,a0,0x7
    80201b68:	00028717          	auipc	a4,0x28
    80201b6c:	49870713          	addi	a4,a4,1176 # 8022a000 <pid_lock>
    80201b70:	975a                	add	a4,a4,s6
    80201b72:	00073c23          	sd	zero,24(a4)
                p->state = RUNNING;
                c->proc  = p;
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
                sfence_vma();

                swtch(&c->context, &p->context);
    80201b76:	00028717          	auipc	a4,0x28
    80201b7a:	4aa70713          	addi	a4,a4,1194 # 8022a020 <cpus+0x8>
    80201b7e:	9b3a                	add	s6,s6,a4
                c->proc  = p;
    80201b80:	00751793          	slli	a5,a0,0x7
    80201b84:	00028a97          	auipc	s5,0x28
    80201b88:	47ca8a93          	addi	s5,s5,1148 # 8022a000 <pid_lock>
    80201b8c:	9abe                	add	s5,s5,a5
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201b8e:	5a7d                	li	s4,-1
    80201b90:	1a7e                	slli	s4,s4,0x3f

                w_satp(MAKE_SATP(kernel_pagetable));
    80201b92:	0013db97          	auipc	s7,0x13d
    80201b96:	48eb8b93          	addi	s7,s7,1166 # 8033f020 <kernel_pagetable>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201b9a:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80201b9e:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201ba2:	10079073          	csrw	sstatus,a5
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201ba6:	00129497          	auipc	s1,0x129
    80201baa:	45a48493          	addi	s1,s1,1114 # 8032b000 <proc>
            if (p->state == RUNNABLE) {
    80201bae:	498d                	li	s3,3
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201bb0:	0012f917          	auipc	s2,0x12f
    80201bb4:	e5090913          	addi	s2,s2,-432 # 80330a00 <tickslock>
    80201bb8:	a811                	j	80201bcc <scheduler+0x86>
                sfence_vma();
                c->proc = 0;
            }
            release(&p->lock);
    80201bba:	8526                	mv	a0,s1
    80201bbc:	fffff097          	auipc	ra,0xfffff
    80201bc0:	7e8080e7          	jalr	2024(ra) # 802013a4 <release>
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201bc4:	16848493          	addi	s1,s1,360
    80201bc8:	fd2489e3          	beq	s1,s2,80201b9a <scheduler+0x54>
            acquire(&p->lock);
    80201bcc:	8526                	mv	a0,s1
    80201bce:	fffff097          	auipc	ra,0xfffff
    80201bd2:	722080e7          	jalr	1826(ra) # 802012f0 <acquire>
            if (p->state == RUNNABLE) {
    80201bd6:	4c9c                	lw	a5,24(s1)
    80201bd8:	ff3791e3          	bne	a5,s3,80201bba <scheduler+0x74>
                p->state = RUNNING;
    80201bdc:	4791                	li	a5,4
    80201bde:	cc9c                	sw	a5,24(s1)
                c->proc  = p;
    80201be0:	009abc23          	sd	s1,24(s5)
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201be4:	68bc                	ld	a5,80(s1)
    80201be6:	83b1                	srli	a5,a5,0xc
    80201be8:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201bec:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201bf0:	12000073          	sfence.vma
                swtch(&c->context, &p->context);
    80201bf4:	06048593          	addi	a1,s1,96
    80201bf8:	855a                	mv	a0,s6
    80201bfa:	00000097          	auipc	ra,0x0
    80201bfe:	5fe080e7          	jalr	1534(ra) # 802021f8 <swtch>
                w_satp(MAKE_SATP(kernel_pagetable));
    80201c02:	000bb783          	ld	a5,0(s7)
    80201c06:	83b1                	srli	a5,a5,0xc
    80201c08:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201c0c:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201c10:	12000073          	sfence.vma
                c->proc = 0;
    80201c14:	000abc23          	sd	zero,24(s5)
    80201c18:	b74d                	j	80201bba <scheduler+0x74>

0000000080201c1a <sched>:
    }
}

/* Switch to the scheduler. Must hold p->lock and have changed p->state. */
void sched(void)
{
    80201c1a:	7179                	addi	sp,sp,-48
    80201c1c:	f406                	sd	ra,40(sp)
    80201c1e:	f022                	sd	s0,32(sp)
    80201c20:	ec26                	sd	s1,24(sp)
    80201c22:	e84a                	sd	s2,16(sp)
    80201c24:	e44e                	sd	s3,8(sp)
    80201c26:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    80201c28:	00000097          	auipc	ra,0x0
    80201c2c:	ab2080e7          	jalr	-1358(ra) # 802016da <myproc>
    80201c30:	84aa                	mv	s1,a0
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201c32:	fffff097          	auipc	ra,0xfffff
    80201c36:	658080e7          	jalr	1624(ra) # 8020128a <holding>
    80201c3a:	c541                	beqz	a0,80201cc2 <sched+0xa8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201c3c:	00004097          	auipc	ra,0x4
    80201c40:	446080e7          	jalr	1094(ra) # 80206082 <hal_hart_id>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201c44:	051e                	slli	a0,a0,0x7
    80201c46:	00028797          	auipc	a5,0x28
    80201c4a:	3ba78793          	addi	a5,a5,954 # 8022a000 <pid_lock>
    80201c4e:	97aa                	add	a5,a5,a0
    80201c50:	0907a703          	lw	a4,144(a5)
    80201c54:	4785                	li	a5,1
    80201c56:	06f71e63          	bne	a4,a5,80201cd2 <sched+0xb8>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201c5a:	4c98                	lw	a4,24(s1)
    80201c5c:	4791                	li	a5,4
    80201c5e:	08f70263          	beq	a4,a5,80201ce2 <sched+0xc8>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201c62:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201c66:	8b89                	andi	a5,a5,2
    if (intr_get())           panic("sched: interrupts are on");
    80201c68:	e7c9                	bnez	a5,80201cf2 <sched+0xd8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201c6a:	00004097          	auipc	ra,0x4
    80201c6e:	418080e7          	jalr	1048(ra) # 80206082 <hal_hart_id>

    int intena = mycpu()->intena;
    80201c72:	00028917          	auipc	s2,0x28
    80201c76:	38e90913          	addi	s2,s2,910 # 8022a000 <pid_lock>
    80201c7a:	00751793          	slli	a5,a0,0x7
    80201c7e:	97ca                	add	a5,a5,s2
    80201c80:	0947a983          	lw	s3,148(a5)
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201c84:	00004097          	auipc	ra,0x4
    80201c88:	3fe080e7          	jalr	1022(ra) # 80206082 <hal_hart_id>
    swtch(&p->context, &mycpu()->context);
    80201c8c:	051e                	slli	a0,a0,0x7
    80201c8e:	00028597          	auipc	a1,0x28
    80201c92:	39258593          	addi	a1,a1,914 # 8022a020 <cpus+0x8>
    80201c96:	95aa                	add	a1,a1,a0
    80201c98:	06048513          	addi	a0,s1,96
    80201c9c:	00000097          	auipc	ra,0x0
    80201ca0:	55c080e7          	jalr	1372(ra) # 802021f8 <swtch>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201ca4:	00004097          	auipc	ra,0x4
    80201ca8:	3de080e7          	jalr	990(ra) # 80206082 <hal_hart_id>
    mycpu()->intena = intena;
    80201cac:	051e                	slli	a0,a0,0x7
    80201cae:	992a                	add	s2,s2,a0
    80201cb0:	09392a23          	sw	s3,148(s2)
}
    80201cb4:	70a2                	ld	ra,40(sp)
    80201cb6:	7402                	ld	s0,32(sp)
    80201cb8:	64e2                	ld	s1,24(sp)
    80201cba:	6942                	ld	s2,16(sp)
    80201cbc:	69a2                	ld	s3,8(sp)
    80201cbe:	6145                	addi	sp,sp,48
    80201cc0:	8082                	ret
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201cc2:	00006517          	auipc	a0,0x6
    80201cc6:	87650513          	addi	a0,a0,-1930 # 80207538 <etext+0x538>
    80201cca:	fffff097          	auipc	ra,0xfffff
    80201cce:	8f0080e7          	jalr	-1808(ra) # 802005ba <panic>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201cd2:	00006517          	auipc	a0,0x6
    80201cd6:	88650513          	addi	a0,a0,-1914 # 80207558 <etext+0x558>
    80201cda:	fffff097          	auipc	ra,0xfffff
    80201cde:	8e0080e7          	jalr	-1824(ra) # 802005ba <panic>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201ce2:	00006517          	auipc	a0,0x6
    80201ce6:	89650513          	addi	a0,a0,-1898 # 80207578 <etext+0x578>
    80201cea:	fffff097          	auipc	ra,0xfffff
    80201cee:	8d0080e7          	jalr	-1840(ra) # 802005ba <panic>
    if (intr_get())           panic("sched: interrupts are on");
    80201cf2:	00006517          	auipc	a0,0x6
    80201cf6:	8a650513          	addi	a0,a0,-1882 # 80207598 <etext+0x598>
    80201cfa:	fffff097          	auipc	ra,0xfffff
    80201cfe:	8c0080e7          	jalr	-1856(ra) # 802005ba <panic>

0000000080201d02 <yield>:

void yield(void)
{
    80201d02:	1101                	addi	sp,sp,-32
    80201d04:	ec06                	sd	ra,24(sp)
    80201d06:	e822                	sd	s0,16(sp)
    80201d08:	e426                	sd	s1,8(sp)
    80201d0a:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    80201d0c:	00000097          	auipc	ra,0x0
    80201d10:	9ce080e7          	jalr	-1586(ra) # 802016da <myproc>
    80201d14:	84aa                	mv	s1,a0
    acquire(&p->lock);
    80201d16:	fffff097          	auipc	ra,0xfffff
    80201d1a:	5da080e7          	jalr	1498(ra) # 802012f0 <acquire>
    p->state = RUNNABLE;
    80201d1e:	478d                	li	a5,3
    80201d20:	cc9c                	sw	a5,24(s1)
    sched();
    80201d22:	00000097          	auipc	ra,0x0
    80201d26:	ef8080e7          	jalr	-264(ra) # 80201c1a <sched>
    release(&p->lock);
    80201d2a:	8526                	mv	a0,s1
    80201d2c:	fffff097          	auipc	ra,0xfffff
    80201d30:	678080e7          	jalr	1656(ra) # 802013a4 <release>
}
    80201d34:	60e2                	ld	ra,24(sp)
    80201d36:	6442                	ld	s0,16(sp)
    80201d38:	64a2                	ld	s1,8(sp)
    80201d3a:	6105                	addi	sp,sp,32
    80201d3c:	8082                	ret

0000000080201d3e <sleep>:

void sleep(void *chan, struct spinlock *lk)
{
    80201d3e:	7179                	addi	sp,sp,-48
    80201d40:	f406                	sd	ra,40(sp)
    80201d42:	f022                	sd	s0,32(sp)
    80201d44:	ec26                	sd	s1,24(sp)
    80201d46:	e84a                	sd	s2,16(sp)
    80201d48:	e44e                	sd	s3,8(sp)
    80201d4a:	1800                	addi	s0,sp,48
    80201d4c:	89aa                	mv	s3,a0
    80201d4e:	892e                	mv	s2,a1
    struct proc *p = myproc();
    80201d50:	00000097          	auipc	ra,0x0
    80201d54:	98a080e7          	jalr	-1654(ra) # 802016da <myproc>
    80201d58:	84aa                	mv	s1,a0

    /* Acquire p->lock BEFORE releasing lk. If we did it the other way round, a
     * wakeup could slip in between and be lost - the classic missed-wakeup race. */
    acquire(&p->lock);
    80201d5a:	fffff097          	auipc	ra,0xfffff
    80201d5e:	596080e7          	jalr	1430(ra) # 802012f0 <acquire>
    release(lk);
    80201d62:	854a                	mv	a0,s2
    80201d64:	fffff097          	auipc	ra,0xfffff
    80201d68:	640080e7          	jalr	1600(ra) # 802013a4 <release>

    p->chan  = chan;
    80201d6c:	0334b023          	sd	s3,32(s1)
    p->state = SLEEPING;
    80201d70:	4789                	li	a5,2
    80201d72:	cc9c                	sw	a5,24(s1)
    sched();
    80201d74:	00000097          	auipc	ra,0x0
    80201d78:	ea6080e7          	jalr	-346(ra) # 80201c1a <sched>

    p->chan = 0;
    80201d7c:	0204b023          	sd	zero,32(s1)
    release(&p->lock);
    80201d80:	8526                	mv	a0,s1
    80201d82:	fffff097          	auipc	ra,0xfffff
    80201d86:	622080e7          	jalr	1570(ra) # 802013a4 <release>
    acquire(lk);
    80201d8a:	854a                	mv	a0,s2
    80201d8c:	fffff097          	auipc	ra,0xfffff
    80201d90:	564080e7          	jalr	1380(ra) # 802012f0 <acquire>
}
    80201d94:	70a2                	ld	ra,40(sp)
    80201d96:	7402                	ld	s0,32(sp)
    80201d98:	64e2                	ld	s1,24(sp)
    80201d9a:	6942                	ld	s2,16(sp)
    80201d9c:	69a2                	ld	s3,8(sp)
    80201d9e:	6145                	addi	sp,sp,48
    80201da0:	8082                	ret

0000000080201da2 <wait>:
{
    80201da2:	715d                	addi	sp,sp,-80
    80201da4:	e486                	sd	ra,72(sp)
    80201da6:	e0a2                	sd	s0,64(sp)
    80201da8:	fc26                	sd	s1,56(sp)
    80201daa:	f84a                	sd	s2,48(sp)
    80201dac:	f44e                	sd	s3,40(sp)
    80201dae:	f052                	sd	s4,32(sp)
    80201db0:	ec56                	sd	s5,24(sp)
    80201db2:	e85a                	sd	s6,16(sp)
    80201db4:	e45e                	sd	s7,8(sp)
    80201db6:	0880                	addi	s0,sp,80
    80201db8:	8b2a                	mv	s6,a0
    struct proc *p = myproc();
    80201dba:	00000097          	auipc	ra,0x0
    80201dbe:	920080e7          	jalr	-1760(ra) # 802016da <myproc>
    80201dc2:	892a                	mv	s2,a0
    acquire(&wait_lock);
    80201dc4:	00028517          	auipc	a0,0x28
    80201dc8:	65450513          	addi	a0,a0,1620 # 8022a418 <wait_lock>
    80201dcc:	fffff097          	auipc	ra,0xfffff
    80201dd0:	524080e7          	jalr	1316(ra) # 802012f0 <acquire>
        int havekids = 0;
    80201dd4:	4b81                	li	s7,0
            if (pp->state == ZOMBIE) {
    80201dd6:	4a15                	li	s4,5
            havekids = 1;
    80201dd8:	4a85                	li	s5,1
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201dda:	0012f997          	auipc	s3,0x12f
    80201dde:	c2698993          	addi	s3,s3,-986 # 80330a00 <tickslock>
    80201de2:	00129497          	auipc	s1,0x129
    80201de6:	21e48493          	addi	s1,s1,542 # 8032b000 <proc>
        int havekids = 0;
    80201dea:	875e                	mv	a4,s7
    80201dec:	a051                	j	80201e70 <wait+0xce>
                int pid = pp->pid;
    80201dee:	0304a983          	lw	s3,48(s1)
                if (addr && copyout(p->pagetable, addr,
    80201df2:	000b0e63          	beqz	s6,80201e0e <wait+0x6c>
    80201df6:	4691                	li	a3,4
    80201df8:	02c48613          	addi	a2,s1,44
    80201dfc:	85da                	mv	a1,s6
    80201dfe:	05093503          	ld	a0,80(s2)
    80201e02:	00001097          	auipc	ra,0x1
    80201e06:	0ac080e7          	jalr	172(ra) # 80202eae <copyout>
    80201e0a:	04054063          	bltz	a0,80201e4a <wait+0xa8>
                freeproc(pp);
    80201e0e:	8526                	mv	a0,s1
    80201e10:	fffff097          	auipc	ra,0xfffff
    80201e14:	706080e7          	jalr	1798(ra) # 80201516 <freeproc>
                release(&pp->lock);
    80201e18:	8526                	mv	a0,s1
    80201e1a:	fffff097          	auipc	ra,0xfffff
    80201e1e:	58a080e7          	jalr	1418(ra) # 802013a4 <release>
                release(&wait_lock);
    80201e22:	00028517          	auipc	a0,0x28
    80201e26:	5f650513          	addi	a0,a0,1526 # 8022a418 <wait_lock>
    80201e2a:	fffff097          	auipc	ra,0xfffff
    80201e2e:	57a080e7          	jalr	1402(ra) # 802013a4 <release>
}
    80201e32:	854e                	mv	a0,s3
    80201e34:	60a6                	ld	ra,72(sp)
    80201e36:	6406                	ld	s0,64(sp)
    80201e38:	74e2                	ld	s1,56(sp)
    80201e3a:	7942                	ld	s2,48(sp)
    80201e3c:	79a2                	ld	s3,40(sp)
    80201e3e:	7a02                	ld	s4,32(sp)
    80201e40:	6ae2                	ld	s5,24(sp)
    80201e42:	6b42                	ld	s6,16(sp)
    80201e44:	6ba2                	ld	s7,8(sp)
    80201e46:	6161                	addi	sp,sp,80
    80201e48:	8082                	ret
                    release(&pp->lock);
    80201e4a:	8526                	mv	a0,s1
    80201e4c:	fffff097          	auipc	ra,0xfffff
    80201e50:	558080e7          	jalr	1368(ra) # 802013a4 <release>
                    release(&wait_lock);
    80201e54:	00028517          	auipc	a0,0x28
    80201e58:	5c450513          	addi	a0,a0,1476 # 8022a418 <wait_lock>
    80201e5c:	fffff097          	auipc	ra,0xfffff
    80201e60:	548080e7          	jalr	1352(ra) # 802013a4 <release>
                    return -1;
    80201e64:	59fd                	li	s3,-1
    80201e66:	b7f1                	j	80201e32 <wait+0x90>
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201e68:	16848493          	addi	s1,s1,360
    80201e6c:	03348463          	beq	s1,s3,80201e94 <wait+0xf2>
            if (pp->parent != p) continue;
    80201e70:	7c9c                	ld	a5,56(s1)
    80201e72:	ff279be3          	bne	a5,s2,80201e68 <wait+0xc6>
            acquire(&pp->lock);
    80201e76:	8526                	mv	a0,s1
    80201e78:	fffff097          	auipc	ra,0xfffff
    80201e7c:	478080e7          	jalr	1144(ra) # 802012f0 <acquire>
            if (pp->state == ZOMBIE) {
    80201e80:	4c9c                	lw	a5,24(s1)
    80201e82:	f74786e3          	beq	a5,s4,80201dee <wait+0x4c>
            release(&pp->lock);
    80201e86:	8526                	mv	a0,s1
    80201e88:	fffff097          	auipc	ra,0xfffff
    80201e8c:	51c080e7          	jalr	1308(ra) # 802013a4 <release>
            havekids = 1;
    80201e90:	8756                	mv	a4,s5
    80201e92:	bfd9                	j	80201e68 <wait+0xc6>
        if (!havekids || p->killed) {
    80201e94:	cf11                	beqz	a4,80201eb0 <wait+0x10e>
    80201e96:	02892783          	lw	a5,40(s2)
    80201e9a:	eb99                	bnez	a5,80201eb0 <wait+0x10e>
        sleep(p, &wait_lock);
    80201e9c:	00028597          	auipc	a1,0x28
    80201ea0:	57c58593          	addi	a1,a1,1404 # 8022a418 <wait_lock>
    80201ea4:	854a                	mv	a0,s2
    80201ea6:	00000097          	auipc	ra,0x0
    80201eaa:	e98080e7          	jalr	-360(ra) # 80201d3e <sleep>
    for (;;) {
    80201eae:	bf15                	j	80201de2 <wait+0x40>
            release(&wait_lock);
    80201eb0:	00028517          	auipc	a0,0x28
    80201eb4:	56850513          	addi	a0,a0,1384 # 8022a418 <wait_lock>
    80201eb8:	fffff097          	auipc	ra,0xfffff
    80201ebc:	4ec080e7          	jalr	1260(ra) # 802013a4 <release>
            return -1;
    80201ec0:	59fd                	li	s3,-1
    80201ec2:	bf85                	j	80201e32 <wait+0x90>

0000000080201ec4 <wakeup>:

void wakeup(void *chan)
{
    80201ec4:	7139                	addi	sp,sp,-64
    80201ec6:	fc06                	sd	ra,56(sp)
    80201ec8:	f822                	sd	s0,48(sp)
    80201eca:	f426                	sd	s1,40(sp)
    80201ecc:	f04a                	sd	s2,32(sp)
    80201ece:	ec4e                	sd	s3,24(sp)
    80201ed0:	e852                	sd	s4,16(sp)
    80201ed2:	e456                	sd	s5,8(sp)
    80201ed4:	0080                	addi	s0,sp,64
    80201ed6:	8a2a                	mv	s4,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201ed8:	00129497          	auipc	s1,0x129
    80201edc:	12848493          	addi	s1,s1,296 # 8032b000 <proc>
        if (p != myproc()) {
            acquire(&p->lock);
            if (p->state == SLEEPING && p->chan == chan)
    80201ee0:	4989                	li	s3,2
                p->state = RUNNABLE;
    80201ee2:	4a8d                	li	s5,3
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201ee4:	0012f917          	auipc	s2,0x12f
    80201ee8:	b1c90913          	addi	s2,s2,-1252 # 80330a00 <tickslock>
    80201eec:	a811                	j	80201f00 <wakeup+0x3c>
            release(&p->lock);
    80201eee:	8526                	mv	a0,s1
    80201ef0:	fffff097          	auipc	ra,0xfffff
    80201ef4:	4b4080e7          	jalr	1204(ra) # 802013a4 <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201ef8:	16848493          	addi	s1,s1,360
    80201efc:	03248663          	beq	s1,s2,80201f28 <wakeup+0x64>
        if (p != myproc()) {
    80201f00:	fffff097          	auipc	ra,0xfffff
    80201f04:	7da080e7          	jalr	2010(ra) # 802016da <myproc>
    80201f08:	fea488e3          	beq	s1,a0,80201ef8 <wakeup+0x34>
            acquire(&p->lock);
    80201f0c:	8526                	mv	a0,s1
    80201f0e:	fffff097          	auipc	ra,0xfffff
    80201f12:	3e2080e7          	jalr	994(ra) # 802012f0 <acquire>
            if (p->state == SLEEPING && p->chan == chan)
    80201f16:	4c9c                	lw	a5,24(s1)
    80201f18:	fd379be3          	bne	a5,s3,80201eee <wakeup+0x2a>
    80201f1c:	709c                	ld	a5,32(s1)
    80201f1e:	fd4798e3          	bne	a5,s4,80201eee <wakeup+0x2a>
                p->state = RUNNABLE;
    80201f22:	0154ac23          	sw	s5,24(s1)
    80201f26:	b7e1                	j	80201eee <wakeup+0x2a>
        }
    }
}
    80201f28:	70e2                	ld	ra,56(sp)
    80201f2a:	7442                	ld	s0,48(sp)
    80201f2c:	74a2                	ld	s1,40(sp)
    80201f2e:	7902                	ld	s2,32(sp)
    80201f30:	69e2                	ld	s3,24(sp)
    80201f32:	6a42                	ld	s4,16(sp)
    80201f34:	6aa2                	ld	s5,8(sp)
    80201f36:	6121                	addi	sp,sp,64
    80201f38:	8082                	ret

0000000080201f3a <exit>:
{
    80201f3a:	7139                	addi	sp,sp,-64
    80201f3c:	fc06                	sd	ra,56(sp)
    80201f3e:	f822                	sd	s0,48(sp)
    80201f40:	f426                	sd	s1,40(sp)
    80201f42:	f04a                	sd	s2,32(sp)
    80201f44:	ec4e                	sd	s3,24(sp)
    80201f46:	e456                	sd	s5,8(sp)
    80201f48:	0080                	addi	s0,sp,64
    80201f4a:	8aaa                	mv	s5,a0
    struct proc *p = myproc();
    80201f4c:	fffff097          	auipc	ra,0xfffff
    80201f50:	78e080e7          	jalr	1934(ra) # 802016da <myproc>
    80201f54:	892a                	mv	s2,a0
    if (p == initproc) panic("init exiting");
    80201f56:	0013d797          	auipc	a5,0x13d
    80201f5a:	0ba7b783          	ld	a5,186(a5) # 8033f010 <initproc>
    80201f5e:	0d050493          	addi	s1,a0,208
    80201f62:	15050993          	addi	s3,a0,336
    80201f66:	00a78463          	beq	a5,a0,80201f6e <exit+0x34>
    80201f6a:	e852                	sd	s4,16(sp)
    80201f6c:	a01d                	j	80201f92 <exit+0x58>
    80201f6e:	e852                	sd	s4,16(sp)
    80201f70:	00005517          	auipc	a0,0x5
    80201f74:	64850513          	addi	a0,a0,1608 # 802075b8 <etext+0x5b8>
    80201f78:	ffffe097          	auipc	ra,0xffffe
    80201f7c:	642080e7          	jalr	1602(ra) # 802005ba <panic>
            fileclose(p->ofile[fd]);
    80201f80:	00004097          	auipc	ra,0x4
    80201f84:	9f2080e7          	jalr	-1550(ra) # 80205972 <fileclose>
            p->ofile[fd] = 0;
    80201f88:	0004b023          	sd	zero,0(s1)
    for (int fd = 0; fd < NOFILE; fd++) {
    80201f8c:	04a1                	addi	s1,s1,8
    80201f8e:	01348563          	beq	s1,s3,80201f98 <exit+0x5e>
        if (p->ofile[fd]) {
    80201f92:	6088                	ld	a0,0(s1)
    80201f94:	f575                	bnez	a0,80201f80 <exit+0x46>
    80201f96:	bfdd                	j	80201f8c <exit+0x52>
    iput(p->cwd);
    80201f98:	15093503          	ld	a0,336(s2)
    80201f9c:	00003097          	auipc	ra,0x3
    80201fa0:	1e2080e7          	jalr	482(ra) # 8020517e <iput>
    p->cwd = 0;
    80201fa4:	14093823          	sd	zero,336(s2)
    acquire(&wait_lock);
    80201fa8:	00028517          	auipc	a0,0x28
    80201fac:	47050513          	addi	a0,a0,1136 # 8022a418 <wait_lock>
    80201fb0:	fffff097          	auipc	ra,0xfffff
    80201fb4:	340080e7          	jalr	832(ra) # 802012f0 <acquire>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201fb8:	00129497          	auipc	s1,0x129
    80201fbc:	04848493          	addi	s1,s1,72 # 8032b000 <proc>
            pp->parent = initproc;
    80201fc0:	0013da17          	auipc	s4,0x13d
    80201fc4:	050a0a13          	addi	s4,s4,80 # 8033f010 <initproc>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201fc8:	0012f997          	auipc	s3,0x12f
    80201fcc:	a3898993          	addi	s3,s3,-1480 # 80330a00 <tickslock>
    80201fd0:	a821                	j	80201fe8 <exit+0xae>
            pp->parent = initproc;
    80201fd2:	000a3503          	ld	a0,0(s4)
    80201fd6:	fc88                	sd	a0,56(s1)
            wakeup(initproc);
    80201fd8:	00000097          	auipc	ra,0x0
    80201fdc:	eec080e7          	jalr	-276(ra) # 80201ec4 <wakeup>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201fe0:	16848493          	addi	s1,s1,360
    80201fe4:	01348663          	beq	s1,s3,80201ff0 <exit+0xb6>
        if (pp->parent == p) {
    80201fe8:	7c9c                	ld	a5,56(s1)
    80201fea:	fef91be3          	bne	s2,a5,80201fe0 <exit+0xa6>
    80201fee:	b7d5                	j	80201fd2 <exit+0x98>
    wakeup(p->parent);
    80201ff0:	03893503          	ld	a0,56(s2)
    80201ff4:	00000097          	auipc	ra,0x0
    80201ff8:	ed0080e7          	jalr	-304(ra) # 80201ec4 <wakeup>
    acquire(&p->lock);
    80201ffc:	854a                	mv	a0,s2
    80201ffe:	fffff097          	auipc	ra,0xfffff
    80202002:	2f2080e7          	jalr	754(ra) # 802012f0 <acquire>
    p->xstate = status;
    80202006:	03592623          	sw	s5,44(s2)
    p->state  = ZOMBIE;
    8020200a:	4795                	li	a5,5
    8020200c:	00f92c23          	sw	a5,24(s2)
    release(&wait_lock);
    80202010:	00028517          	auipc	a0,0x28
    80202014:	40850513          	addi	a0,a0,1032 # 8022a418 <wait_lock>
    80202018:	fffff097          	auipc	ra,0xfffff
    8020201c:	38c080e7          	jalr	908(ra) # 802013a4 <release>
    sched();                        /* never returns */
    80202020:	00000097          	auipc	ra,0x0
    80202024:	bfa080e7          	jalr	-1030(ra) # 80201c1a <sched>
    panic("zombie exit");
    80202028:	00005517          	auipc	a0,0x5
    8020202c:	5a050513          	addi	a0,a0,1440 # 802075c8 <etext+0x5c8>
    80202030:	ffffe097          	auipc	ra,0xffffe
    80202034:	58a080e7          	jalr	1418(ra) # 802005ba <panic>

0000000080202038 <kill>:

int kill(int pid)
{
    80202038:	7179                	addi	sp,sp,-48
    8020203a:	f406                	sd	ra,40(sp)
    8020203c:	f022                	sd	s0,32(sp)
    8020203e:	ec26                	sd	s1,24(sp)
    80202040:	e84a                	sd	s2,16(sp)
    80202042:	e44e                	sd	s3,8(sp)
    80202044:	1800                	addi	s0,sp,48
    80202046:	892a                	mv	s2,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202048:	00129497          	auipc	s1,0x129
    8020204c:	fb848493          	addi	s1,s1,-72 # 8032b000 <proc>
    80202050:	0012f997          	auipc	s3,0x12f
    80202054:	9b098993          	addi	s3,s3,-1616 # 80330a00 <tickslock>
        acquire(&p->lock);
    80202058:	8526                	mv	a0,s1
    8020205a:	fffff097          	auipc	ra,0xfffff
    8020205e:	296080e7          	jalr	662(ra) # 802012f0 <acquire>
        if (p->pid == pid) {
    80202062:	589c                	lw	a5,48(s1)
    80202064:	01278d63          	beq	a5,s2,8020207e <kill+0x46>
            p->killed = 1;
            if (p->state == SLEEPING) p->state = RUNNABLE;
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    80202068:	8526                	mv	a0,s1
    8020206a:	fffff097          	auipc	ra,0xfffff
    8020206e:	33a080e7          	jalr	826(ra) # 802013a4 <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202072:	16848493          	addi	s1,s1,360
    80202076:	ff3491e3          	bne	s1,s3,80202058 <kill+0x20>
    }
    return -1;
    8020207a:	557d                	li	a0,-1
    8020207c:	a829                	j	80202096 <kill+0x5e>
            p->killed = 1;
    8020207e:	4785                	li	a5,1
    80202080:	d49c                	sw	a5,40(s1)
            if (p->state == SLEEPING) p->state = RUNNABLE;
    80202082:	4c98                	lw	a4,24(s1)
    80202084:	4789                	li	a5,2
    80202086:	00f70f63          	beq	a4,a5,802020a4 <kill+0x6c>
            release(&p->lock);
    8020208a:	8526                	mv	a0,s1
    8020208c:	fffff097          	auipc	ra,0xfffff
    80202090:	318080e7          	jalr	792(ra) # 802013a4 <release>
            return 0;
    80202094:	4501                	li	a0,0
}
    80202096:	70a2                	ld	ra,40(sp)
    80202098:	7402                	ld	s0,32(sp)
    8020209a:	64e2                	ld	s1,24(sp)
    8020209c:	6942                	ld	s2,16(sp)
    8020209e:	69a2                	ld	s3,8(sp)
    802020a0:	6145                	addi	sp,sp,48
    802020a2:	8082                	ret
            if (p->state == SLEEPING) p->state = RUNNABLE;
    802020a4:	478d                	li	a5,3
    802020a6:	cc9c                	sw	a5,24(s1)
    802020a8:	b7cd                	j	8020208a <kill+0x52>

00000000802020aa <procstat>:

/* Copy up to max process records to user space; returns the count. Backs the
 * procstat() syscall and the `ps` utility. Reads are racy-by-design (a
 * snapshot, not a transaction) but each slot is read under its own lock. */
int procstat(uint64 uaddr, int max)
{
    802020aa:	711d                	addi	sp,sp,-96
    802020ac:	ec86                	sd	ra,88(sp)
    802020ae:	e8a2                	sd	s0,80(sp)
    802020b0:	e0ca                	sd	s2,64(sp)
    802020b2:	1080                	addi	s0,sp,96
    struct pstat ps;
    int n = 0;
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802020b4:	0ab05663          	blez	a1,80202160 <procstat+0xb6>
    802020b8:	e4a6                	sd	s1,72(sp)
    802020ba:	fc4e                	sd	s3,56(sp)
    802020bc:	f852                	sd	s4,48(sp)
    802020be:	f456                	sd	s5,40(sp)
    802020c0:	8aaa                	mv	s5,a0
    802020c2:	89ae                	mv	s3,a1
    802020c4:	00129497          	auipc	s1,0x129
    802020c8:	f3c48493          	addi	s1,s1,-196 # 8032b000 <proc>
    int n = 0;
    802020cc:	4901                	li	s2,0
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802020ce:	0012fa17          	auipc	s4,0x12f
    802020d2:	932a0a13          	addi	s4,s4,-1742 # 80330a00 <tickslock>
    802020d6:	a821                	j	802020ee <procstat+0x44>
        acquire(&p->lock);
        if (p->state == UNUSED) { release(&p->lock); continue; }
    802020d8:	8526                	mv	a0,s1
    802020da:	fffff097          	auipc	ra,0xfffff
    802020de:	2ca080e7          	jalr	714(ra) # 802013a4 <release>
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802020e2:	16848493          	addi	s1,s1,360
    802020e6:	09448563          	beq	s1,s4,80202170 <procstat+0xc6>
    802020ea:	07395163          	bge	s2,s3,8020214c <procstat+0xa2>
        acquire(&p->lock);
    802020ee:	8526                	mv	a0,s1
    802020f0:	fffff097          	auipc	ra,0xfffff
    802020f4:	200080e7          	jalr	512(ra) # 802012f0 <acquire>
        if (p->state == UNUSED) { release(&p->lock); continue; }
    802020f8:	4c9c                	lw	a5,24(s1)
    802020fa:	dff9                	beqz	a5,802020d8 <procstat+0x2e>
        ps.pid   = p->pid;
    802020fc:	5898                	lw	a4,48(s1)
    802020fe:	fae42423          	sw	a4,-88(s0)
        ps.state = p->state;
    80202102:	faf42623          	sw	a5,-84(s0)
        memmove(ps.name, p->name, sizeof(ps.name));
    80202106:	4641                	li	a2,16
    80202108:	15848593          	addi	a1,s1,344
    8020210c:	fb040513          	addi	a0,s0,-80
    80202110:	ffffe097          	auipc	ra,0xffffe
    80202114:	56c080e7          	jalr	1388(ra) # 8020067c <memmove>
        release(&p->lock);
    80202118:	8526                	mv	a0,s1
    8020211a:	fffff097          	auipc	ra,0xfffff
    8020211e:	28a080e7          	jalr	650(ra) # 802013a4 <release>
        if (copyout(myproc()->pagetable, uaddr + n * sizeof(ps),
    80202122:	fffff097          	auipc	ra,0xfffff
    80202126:	5b8080e7          	jalr	1464(ra) # 802016da <myproc>
    8020212a:	00191593          	slli	a1,s2,0x1
    8020212e:	95ca                	add	a1,a1,s2
    80202130:	058e                	slli	a1,a1,0x3
    80202132:	46e1                	li	a3,24
    80202134:	fa840613          	addi	a2,s0,-88
    80202138:	95d6                	add	a1,a1,s5
    8020213a:	6928                	ld	a0,80(a0)
    8020213c:	00001097          	auipc	ra,0x1
    80202140:	d72080e7          	jalr	-654(ra) # 80202eae <copyout>
    80202144:	02054063          	bltz	a0,80202164 <procstat+0xba>
                    (char *)&ps, sizeof(ps)) < 0)
            return -1;
        n++;
    80202148:	2905                	addiw	s2,s2,1
    8020214a:	bf61                	j	802020e2 <procstat+0x38>
    8020214c:	64a6                	ld	s1,72(sp)
    8020214e:	79e2                	ld	s3,56(sp)
    80202150:	7a42                	ld	s4,48(sp)
    80202152:	7aa2                	ld	s5,40(sp)
    }
    return n;
}
    80202154:	854a                	mv	a0,s2
    80202156:	60e6                	ld	ra,88(sp)
    80202158:	6446                	ld	s0,80(sp)
    8020215a:	6906                	ld	s2,64(sp)
    8020215c:	6125                	addi	sp,sp,96
    8020215e:	8082                	ret
    return n;
    80202160:	4901                	li	s2,0
    80202162:	bfcd                	j	80202154 <procstat+0xaa>
            return -1;
    80202164:	597d                	li	s2,-1
    80202166:	64a6                	ld	s1,72(sp)
    80202168:	79e2                	ld	s3,56(sp)
    8020216a:	7a42                	ld	s4,48(sp)
    8020216c:	7aa2                	ld	s5,40(sp)
    8020216e:	b7dd                	j	80202154 <procstat+0xaa>
    80202170:	64a6                	ld	s1,72(sp)
    80202172:	79e2                	ld	s3,56(sp)
    80202174:	7a42                	ld	s4,48(sp)
    80202176:	7aa2                	ld	s5,40(sp)
    80202178:	bff1                	j	80202154 <procstat+0xaa>

000000008020217a <procdump>:

void procdump(void)
{
    8020217a:	7179                	addi	sp,sp,-48
    8020217c:	f406                	sd	ra,40(sp)
    8020217e:	f022                	sd	s0,32(sp)
    80202180:	ec26                	sd	s1,24(sp)
    80202182:	e84a                	sd	s2,16(sp)
    80202184:	e44e                	sd	s3,8(sp)
    80202186:	e052                	sd	s4,0(sp)
    80202188:	1800                	addi	s0,sp,48
    static const char *st[] = {
        [UNUSED]"unused", [USED]"used", [SLEEPING]"sleep",
        [RUNNABLE]"runble", [RUNNING]"run", [ZOMBIE]"zombie"
    };
    printf("\n--- process table ---\n");
    8020218a:	00005517          	auipc	a0,0x5
    8020218e:	44e50513          	addi	a0,a0,1102 # 802075d8 <etext+0x5d8>
    80202192:	ffffe097          	auipc	ra,0xffffe
    80202196:	1b6080e7          	jalr	438(ra) # 80200348 <printf>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020219a:	00129497          	auipc	s1,0x129
    8020219e:	fbe48493          	addi	s1,s1,-66 # 8032b158 <proc+0x158>
    802021a2:	0012f917          	auipc	s2,0x12f
    802021a6:	9b690913          	addi	s2,s2,-1610 # 80330b58 <bcache+0x98>
        if (p->state == UNUSED) continue;
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    802021aa:	00006a17          	auipc	s4,0x6
    802021ae:	c4ea0a13          	addi	s4,s4,-946 # 80207df8 <st.0>
    802021b2:	00005997          	auipc	s3,0x5
    802021b6:	43e98993          	addi	s3,s3,1086 # 802075f0 <etext+0x5f0>
    802021ba:	a029                	j	802021c4 <procdump+0x4a>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802021bc:	16848493          	addi	s1,s1,360
    802021c0:	03248463          	beq	s1,s2,802021e8 <procdump+0x6e>
        if (p->state == UNUSED) continue;
    802021c4:	ec04a783          	lw	a5,-320(s1)
    802021c8:	dbf5                	beqz	a5,802021bc <procdump+0x42>
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    802021ca:	02079713          	slli	a4,a5,0x20
    802021ce:	01d75793          	srli	a5,a4,0x1d
    802021d2:	97d2                	add	a5,a5,s4
    802021d4:	86a6                	mv	a3,s1
    802021d6:	6390                	ld	a2,0(a5)
    802021d8:	ed84a583          	lw	a1,-296(s1)
    802021dc:	854e                	mv	a0,s3
    802021de:	ffffe097          	auipc	ra,0xffffe
    802021e2:	16a080e7          	jalr	362(ra) # 80200348 <printf>
    802021e6:	bfd9                	j	802021bc <procdump+0x42>
    }
}
    802021e8:	70a2                	ld	ra,40(sp)
    802021ea:	7402                	ld	s0,32(sp)
    802021ec:	64e2                	ld	s1,24(sp)
    802021ee:	6942                	ld	s2,16(sp)
    802021f0:	69a2                	ld	s3,8(sp)
    802021f2:	6a02                	ld	s4,0(sp)
    802021f4:	6145                	addi	sp,sp,48
    802021f6:	8082                	ret

00000000802021f8 <swtch>:
# Implementation note.
# calling convention says the caller already spilled anything else it cared about.
# Nine loads, nine stores, one ret - and a process wakes up years later, unaware.
        .globl swtch
swtch:
        sd ra,  0(a0)
    802021f8:	00153023          	sd	ra,0(a0)
        sd sp,  8(a0)
    802021fc:	00253423          	sd	sp,8(a0)
        sd s0,  16(a0)
    80202200:	e900                	sd	s0,16(a0)
        sd s1,  24(a0)
    80202202:	ed04                	sd	s1,24(a0)
        sd s2,  32(a0)
    80202204:	03253023          	sd	s2,32(a0)
        sd s3,  40(a0)
    80202208:	03353423          	sd	s3,40(a0)
        sd s4,  48(a0)
    8020220c:	03453823          	sd	s4,48(a0)
        sd s5,  56(a0)
    80202210:	03553c23          	sd	s5,56(a0)
        sd s6,  64(a0)
    80202214:	05653023          	sd	s6,64(a0)
        sd s7,  72(a0)
    80202218:	05753423          	sd	s7,72(a0)
        sd s8,  80(a0)
    8020221c:	05853823          	sd	s8,80(a0)
        sd s9,  88(a0)
    80202220:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80202224:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80202228:	07b53423          	sd	s11,104(a0)

        ld ra,  0(a1)
    8020222c:	0005b083          	ld	ra,0(a1)
        ld sp,  8(a1)
    80202230:	0085b103          	ld	sp,8(a1)
        ld s0,  16(a1)
    80202234:	6980                	ld	s0,16(a1)
        ld s1,  24(a1)
    80202236:	6d84                	ld	s1,24(a1)
        ld s2,  32(a1)
    80202238:	0205b903          	ld	s2,32(a1)
        ld s3,  40(a1)
    8020223c:	0285b983          	ld	s3,40(a1)
        ld s4,  48(a1)
    80202240:	0305ba03          	ld	s4,48(a1)
        ld s5,  56(a1)
    80202244:	0385ba83          	ld	s5,56(a1)
        ld s6,  64(a1)
    80202248:	0405bb03          	ld	s6,64(a1)
        ld s7,  72(a1)
    8020224c:	0485bb83          	ld	s7,72(a1)
        ld s8,  80(a1)
    80202250:	0505bc03          	ld	s8,80(a1)
        ld s9,  88(a1)
    80202254:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80202258:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8020225c:	0685bd83          	ld	s11,104(a1)
        ret
    80202260:	8082                	ret

0000000080202262 <cause_str>:
    }
    return 0;
}

static const char *cause_str(uint64 c)
{
    80202262:	1141                	addi	sp,sp,-16
    80202264:	e422                	sd	s0,8(sp)
    80202266:	0800                	addi	s0,sp,16
    switch (c) {
    80202268:	47bd                	li	a5,15
    8020226a:	06a7ea63          	bltu	a5,a0,802022de <cause_str+0x7c>
    8020226e:	050a                	slli	a0,a0,0x2
    80202270:	00006717          	auipc	a4,0x6
    80202274:	bb870713          	addi	a4,a4,-1096 # 80207e28 <st.0+0x30>
    80202278:	953a                	add	a0,a0,a4
    8020227a:	411c                	lw	a5,0(a0)
    8020227c:	97ba                	add	a5,a5,a4
    8020227e:	8782                	jr	a5
    case 0:  return "instruction address misaligned";
    80202280:	00005517          	auipc	a0,0x5
    80202284:	3b050513          	addi	a0,a0,944 # 80207630 <etext+0x630>
    80202288:	a029                	j	80202292 <cause_str+0x30>
    case 1:  return "instruction access fault";
    case 2:  return "illegal instruction";
    8020228a:	00005517          	auipc	a0,0x5
    8020228e:	3e650513          	addi	a0,a0,998 # 80207670 <etext+0x670>
    case 12: return "instruction page fault";
    case 13: return "load page fault";
    case 15: return "store page fault";
    default: return "unknown";
    }
}
    80202292:	6422                	ld	s0,8(sp)
    80202294:	0141                	addi	sp,sp,16
    80202296:	8082                	ret
    case 3:  return "breakpoint";
    80202298:	00005517          	auipc	a0,0x5
    8020229c:	3f050513          	addi	a0,a0,1008 # 80207688 <etext+0x688>
    802022a0:	bfcd                	j	80202292 <cause_str+0x30>
    case 5:  return "load access fault";
    802022a2:	00005517          	auipc	a0,0x5
    802022a6:	3f650513          	addi	a0,a0,1014 # 80207698 <etext+0x698>
    802022aa:	b7e5                	j	80202292 <cause_str+0x30>
    case 7:  return "store access fault";
    802022ac:	00005517          	auipc	a0,0x5
    802022b0:	40450513          	addi	a0,a0,1028 # 802076b0 <etext+0x6b0>
    802022b4:	bff9                	j	80202292 <cause_str+0x30>
    case 8:  return "ecall from user";
    802022b6:	00005517          	auipc	a0,0x5
    802022ba:	41250513          	addi	a0,a0,1042 # 802076c8 <etext+0x6c8>
    802022be:	bfd1                	j	80202292 <cause_str+0x30>
    case 12: return "instruction page fault";
    802022c0:	00005517          	auipc	a0,0x5
    802022c4:	41850513          	addi	a0,a0,1048 # 802076d8 <etext+0x6d8>
    802022c8:	b7e9                	j	80202292 <cause_str+0x30>
    case 13: return "load page fault";
    802022ca:	00005517          	auipc	a0,0x5
    802022ce:	42650513          	addi	a0,a0,1062 # 802076f0 <etext+0x6f0>
    802022d2:	b7c1                	j	80202292 <cause_str+0x30>
    case 15: return "store page fault";
    802022d4:	00005517          	auipc	a0,0x5
    802022d8:	42c50513          	addi	a0,a0,1068 # 80207700 <etext+0x700>
    802022dc:	bf5d                	j	80202292 <cause_str+0x30>
    default: return "unknown";
    802022de:	00005517          	auipc	a0,0x5
    802022e2:	43a50513          	addi	a0,a0,1082 # 80207718 <etext+0x718>
    802022e6:	b775                	j	80202292 <cause_str+0x30>
    switch (c) {
    802022e8:	00005517          	auipc	a0,0x5
    802022ec:	36850513          	addi	a0,a0,872 # 80207650 <etext+0x650>
    802022f0:	b74d                	j	80202292 <cause_str+0x30>

00000000802022f2 <devintr>:
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    802022f2:	142027f3          	csrr	a5,scause
    if (!(scause & 0x8000000000000000UL)) return 0;   /* top bit = interrupt */
    802022f6:	4501                	li	a0,0
    802022f8:	0e07da63          	bgez	a5,802023ec <devintr+0xfa>
{
    802022fc:	1101                	addi	sp,sp,-32
    802022fe:	ec06                	sd	ra,24(sp)
    80202300:	e822                	sd	s0,16(sp)
    80202302:	1000                	addi	s0,sp,32
    uint64 code = scause & 0xff;
    80202304:	0ff7f793          	zext.b	a5,a5
    if (code == 9) {                     /* supervisor external -> PLIC */
    80202308:	4725                	li	a4,9
    8020230a:	00e78a63          	beq	a5,a4,8020231e <devintr+0x2c>
    if (code == 5) {
    8020230e:	4715                	li	a4,5
    return 0;
    80202310:	4501                	li	a0,0
    if (code == 5) {
    80202312:	08e78263          	beq	a5,a4,80202396 <devintr+0xa4>
}
    80202316:	60e2                	ld	ra,24(sp)
    80202318:	6442                	ld	s0,16(sp)
    8020231a:	6105                	addi	sp,sp,32
    8020231c:	8082                	ret
    8020231e:	e426                	sd	s1,8(sp)
        int irq = hal_intc_claim();
    80202320:	00004097          	auipc	ra,0x4
    80202324:	d0a080e7          	jalr	-758(ra) # 8020602a <hal_intc_claim>
    80202328:	84aa                	mv	s1,a0
        if (irq == fdt.uart_irq) {
    8020232a:	00027797          	auipc	a5,0x27
    8020232e:	d0e7a783          	lw	a5,-754(a5) # 80229038 <fdt+0x20>
    80202332:	00a78663          	beq	a5,a0,8020233e <devintr+0x4c>
        return 1;
    80202336:	4505                	li	a0,1
        } else if (irq && irq == hal_block_irq()) {
    80202338:	e09d                	bnez	s1,8020235e <devintr+0x6c>
    8020233a:	64a2                	ld	s1,8(sp)
    8020233c:	bfe9                	j	80202316 <devintr+0x24>
            int c = hal_console_getc();
    8020233e:	00004097          	auipc	ra,0x4
    80202342:	e50080e7          	jalr	-432(ra) # 8020618e <hal_console_getc>
            if (c != -1) consoleintr(c);
    80202346:	57fd                	li	a5,-1
    80202348:	00f51663          	bne	a0,a5,80202354 <devintr+0x62>
        return 1;
    8020234c:	4505                	li	a0,1
        if (irq) hal_intc_complete(irq);
    8020234e:	e49d                	bnez	s1,8020237c <devintr+0x8a>
    80202350:	64a2                	ld	s1,8(sp)
    80202352:	b7d1                	j	80202316 <devintr+0x24>
            if (c != -1) consoleintr(c);
    80202354:	00002097          	auipc	ra,0x2
    80202358:	e66080e7          	jalr	-410(ra) # 802041ba <consoleintr>
    8020235c:	bfc5                	j	8020234c <devintr+0x5a>
        } else if (irq && irq == hal_block_irq()) {
    8020235e:	00004097          	auipc	ra,0x4
    80202362:	ed0080e7          	jalr	-304(ra) # 8020622e <hal_block_irq>
    80202366:	02950363          	beq	a0,s1,8020238c <devintr+0x9a>
            printf("devintr: unexpected PLIC irq %d\n", irq);
    8020236a:	85a6                	mv	a1,s1
    8020236c:	00005517          	auipc	a0,0x5
    80202370:	3b450513          	addi	a0,a0,948 # 80207720 <etext+0x720>
    80202374:	ffffe097          	auipc	ra,0xffffe
    80202378:	fd4080e7          	jalr	-44(ra) # 80200348 <printf>
        if (irq) hal_intc_complete(irq);
    8020237c:	8526                	mv	a0,s1
    8020237e:	00004097          	auipc	ra,0x4
    80202382:	cd8080e7          	jalr	-808(ra) # 80206056 <hal_intc_complete>
        return 1;
    80202386:	4505                	li	a0,1
    80202388:	64a2                	ld	s1,8(sp)
    8020238a:	b771                	j	80202316 <devintr+0x24>
            hal_block_intr();
    8020238c:	00004097          	auipc	ra,0x4
    80202390:	354080e7          	jalr	852(ra) # 802066e0 <hal_block_intr>
    80202394:	b7e5                	j	8020237c <devintr+0x8a>
        if (hal_hart_id() == 0) {        /* only hart 0 keeps the clock */
    80202396:	00004097          	auipc	ra,0x4
    8020239a:	cec080e7          	jalr	-788(ra) # 80206082 <hal_hart_id>
    8020239e:	c919                	beqz	a0,802023b4 <devintr+0xc2>
        hal_timer_next(1000000);
    802023a0:	000f4537          	lui	a0,0xf4
    802023a4:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    802023a8:	00004097          	auipc	ra,0x4
    802023ac:	d4a080e7          	jalr	-694(ra) # 802060f2 <hal_timer_next>
        return 2;
    802023b0:	4509                	li	a0,2
    802023b2:	b795                	j	80202316 <devintr+0x24>
    802023b4:	e426                	sd	s1,8(sp)
            acquire(&tickslock);
    802023b6:	0012e497          	auipc	s1,0x12e
    802023ba:	64a48493          	addi	s1,s1,1610 # 80330a00 <tickslock>
    802023be:	8526                	mv	a0,s1
    802023c0:	fffff097          	auipc	ra,0xfffff
    802023c4:	f30080e7          	jalr	-208(ra) # 802012f0 <acquire>
            ticks++;
    802023c8:	0013d517          	auipc	a0,0x13d
    802023cc:	c5050513          	addi	a0,a0,-944 # 8033f018 <ticks>
    802023d0:	611c                	ld	a5,0(a0)
    802023d2:	0785                	addi	a5,a5,1
    802023d4:	e11c                	sd	a5,0(a0)
            wakeup(&ticks);
    802023d6:	00000097          	auipc	ra,0x0
    802023da:	aee080e7          	jalr	-1298(ra) # 80201ec4 <wakeup>
            release(&tickslock);
    802023de:	8526                	mv	a0,s1
    802023e0:	fffff097          	auipc	ra,0xfffff
    802023e4:	fc4080e7          	jalr	-60(ra) # 802013a4 <release>
    802023e8:	64a2                	ld	s1,8(sp)
    802023ea:	bf5d                	j	802023a0 <devintr+0xae>
}
    802023ec:	8082                	ret

00000000802023ee <trapinit_hart>:
{
    802023ee:	1101                	addi	sp,sp,-32
    802023f0:	ec06                	sd	ra,24(sp)
    802023f2:	e822                	sd	s0,16(sp)
    802023f4:	e426                	sd	s1,8(sp)
    802023f6:	1000                	addi	s0,sp,32
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    802023f8:	00000797          	auipc	a5,0x0
    802023fc:	32878793          	addi	a5,a5,808 # 80202720 <kernelvec>
    80202400:	10579073          	csrw	stvec,a5
    hal_intc_enable(fdt.uart_irq);              /* priority 1; 0 = never fires */
    80202404:	00027497          	auipc	s1,0x27
    80202408:	c1448493          	addi	s1,s1,-1004 # 80229018 <fdt>
    8020240c:	5088                	lw	a0,32(s1)
    8020240e:	00004097          	auipc	ra,0x4
    80202412:	b92080e7          	jalr	-1134(ra) # 80205fa0 <hal_intc_enable>
    hal_intc_hart_init(hal_hart_id());
    80202416:	00004097          	auipc	ra,0x4
    8020241a:	c6c080e7          	jalr	-916(ra) # 80206082 <hal_hart_id>
    8020241e:	00004097          	auipc	ra,0x4
    80202422:	ba2080e7          	jalr	-1118(ra) # 80205fc0 <hal_intc_hart_init>
    hal_intc_enable_hart(hal_hart_id(), fdt.uart_irq);
    80202426:	00004097          	auipc	ra,0x4
    8020242a:	c5c080e7          	jalr	-932(ra) # 80206082 <hal_hart_id>
    8020242e:	508c                	lw	a1,32(s1)
    80202430:	00004097          	auipc	ra,0x4
    80202434:	bb6080e7          	jalr	-1098(ra) # 80205fe6 <hal_intc_enable_hart>
    if (hal_block_irq()) {
    80202438:	00004097          	auipc	ra,0x4
    8020243c:	df6080e7          	jalr	-522(ra) # 8020622e <hal_block_irq>
    80202440:	e915                	bnez	a0,80202474 <trapinit_hart+0x86>
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
    80202442:	104027f3          	csrr	a5,sie
    w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80202446:	2227e793          	ori	a5,a5,546
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
    8020244a:	10479073          	csrw	sie,a5
    hal_timer_next(1000000);
    8020244e:	000f4537          	lui	a0,0xf4
    80202452:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    80202456:	00004097          	auipc	ra,0x4
    8020245a:	c9c080e7          	jalr	-868(ra) # 802060f2 <hal_timer_next>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020245e:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202462:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202466:	10079073          	csrw	sstatus,a5
}
    8020246a:	60e2                	ld	ra,24(sp)
    8020246c:	6442                	ld	s0,16(sp)
    8020246e:	64a2                	ld	s1,8(sp)
    80202470:	6105                	addi	sp,sp,32
    80202472:	8082                	ret
        hal_intc_enable(hal_block_irq());
    80202474:	00004097          	auipc	ra,0x4
    80202478:	dba080e7          	jalr	-582(ra) # 8020622e <hal_block_irq>
    8020247c:	00004097          	auipc	ra,0x4
    80202480:	b24080e7          	jalr	-1244(ra) # 80205fa0 <hal_intc_enable>
        hal_intc_enable_hart(hal_hart_id(), hal_block_irq());
    80202484:	00004097          	auipc	ra,0x4
    80202488:	bfe080e7          	jalr	-1026(ra) # 80206082 <hal_hart_id>
    8020248c:	84aa                	mv	s1,a0
    8020248e:	00004097          	auipc	ra,0x4
    80202492:	da0080e7          	jalr	-608(ra) # 8020622e <hal_block_irq>
    80202496:	85aa                	mv	a1,a0
    80202498:	8526                	mv	a0,s1
    8020249a:	00004097          	auipc	ra,0x4
    8020249e:	b4c080e7          	jalr	-1204(ra) # 80205fe6 <hal_intc_enable_hart>
    802024a2:	b745                	j	80202442 <trapinit_hart+0x54>

00000000802024a4 <kerneltrap>:

/* Trap while already in the kernel. */
void kerneltrap(void)
{
    802024a4:	7179                	addi	sp,sp,-48
    802024a6:	f406                	sd	ra,40(sp)
    802024a8:	f022                	sd	s0,32(sp)
    802024aa:	ec26                	sd	s1,24(sp)
    802024ac:	e84a                	sd	s2,16(sp)
    802024ae:	e44e                	sd	s3,8(sp)
    802024b0:	1800                	addi	s0,sp,48
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    802024b2:	14102973          	csrr	s2,sepc
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802024b6:	100024f3          	csrr	s1,sstatus
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    802024ba:	142029f3          	csrr	s3,scause
    uint64 sepc     = r_sepc();
    uint64 sstatus  = r_sstatus();
    uint64 scause   = r_scause();

    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    802024be:	1004f793          	andi	a5,s1,256
    802024c2:	cb85                	beqz	a5,802024f2 <kerneltrap+0x4e>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802024c4:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    802024c8:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    802024ca:	ef85                	bnez	a5,80202502 <kerneltrap+0x5e>

    int which = devintr();
    802024cc:	00000097          	auipc	ra,0x0
    802024d0:	e26080e7          	jalr	-474(ra) # 802022f2 <devintr>
    if (which == 0) {
    802024d4:	cd1d                	beqz	a0,80202512 <kerneltrap+0x6e>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
        panic("kernel exception");
    }
    /* Timer: give up the CPU, but only if we are running a process. */
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    802024d6:	4789                	li	a5,2
    802024d8:	06f50463          	beq	a0,a5,80202540 <kerneltrap+0x9c>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    802024dc:	14191073          	csrw	sepc,s2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802024e0:	10049073          	csrw	sstatus,s1
        yield();

    /* yield() may have run other code; restore what sret needs. */
    w_sepc(sepc);
    w_sstatus(sstatus);
}
    802024e4:	70a2                	ld	ra,40(sp)
    802024e6:	7402                	ld	s0,32(sp)
    802024e8:	64e2                	ld	s1,24(sp)
    802024ea:	6942                	ld	s2,16(sp)
    802024ec:	69a2                	ld	s3,8(sp)
    802024ee:	6145                	addi	sp,sp,48
    802024f0:	8082                	ret
    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    802024f2:	00005517          	auipc	a0,0x5
    802024f6:	25650513          	addi	a0,a0,598 # 80207748 <etext+0x748>
    802024fa:	ffffe097          	auipc	ra,0xffffe
    802024fe:	0c0080e7          	jalr	192(ra) # 802005ba <panic>
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    80202502:	00005517          	auipc	a0,0x5
    80202506:	26650513          	addi	a0,a0,614 # 80207768 <etext+0x768>
    8020250a:	ffffe097          	auipc	ra,0xffffe
    8020250e:	0b0080e7          	jalr	176(ra) # 802005ba <panic>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
    80202512:	0ff9f513          	zext.b	a0,s3
    80202516:	00000097          	auipc	ra,0x0
    8020251a:	d4c080e7          	jalr	-692(ra) # 80202262 <cause_str>
    8020251e:	85aa                	mv	a1,a0
    80202520:	00005517          	auipc	a0,0x5
    80202524:	27050513          	addi	a0,a0,624 # 80207790 <etext+0x790>
    80202528:	ffffe097          	auipc	ra,0xffffe
    8020252c:	e20080e7          	jalr	-480(ra) # 80200348 <printf>
        panic("kernel exception");
    80202530:	00005517          	auipc	a0,0x5
    80202534:	27850513          	addi	a0,a0,632 # 802077a8 <etext+0x7a8>
    80202538:	ffffe097          	auipc	ra,0xffffe
    8020253c:	082080e7          	jalr	130(ra) # 802005ba <panic>
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    80202540:	fffff097          	auipc	ra,0xfffff
    80202544:	19a080e7          	jalr	410(ra) # 802016da <myproc>
    80202548:	d951                	beqz	a0,802024dc <kerneltrap+0x38>
    8020254a:	fffff097          	auipc	ra,0xfffff
    8020254e:	190080e7          	jalr	400(ra) # 802016da <myproc>
    80202552:	4d18                	lw	a4,24(a0)
    80202554:	4791                	li	a5,4
    80202556:	f8f713e3          	bne	a4,a5,802024dc <kerneltrap+0x38>
        yield();
    8020255a:	fffff097          	auipc	ra,0xfffff
    8020255e:	7a8080e7          	jalr	1960(ra) # 80201d02 <yield>
    80202562:	bfad                	j	802024dc <kerneltrap+0x38>

0000000080202564 <usertrapret>:
    if (p->killed) exit(-1);
    usertrapret();
}

void usertrapret(void)
{
    80202564:	1141                	addi	sp,sp,-16
    80202566:	e406                	sd	ra,8(sp)
    80202568:	e022                	sd	s0,0(sp)
    8020256a:	0800                	addi	s0,sp,16
    struct proc *p = myproc();
    8020256c:	fffff097          	auipc	ra,0xfffff
    80202570:	16e080e7          	jalr	366(ra) # 802016da <myproc>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202574:	100027f3          	csrr	a5,sstatus
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    80202578:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    8020257a:	10079073          	csrw	sstatus,a5
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    8020257e:	00000797          	auipc	a5,0x0
    80202582:	20278793          	addi	a5,a5,514 # 80202780 <uservec>
    80202586:	10579073          	csrw	stvec,a5

    intr_off();                       /* no interrupts between stvec and sret */
    w_stvec((uint64)uservec);

    p->tf->kernel_satp   = r_satp();
    8020258a:	6d3c                	ld	a5,88(a0)
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    8020258c:	18002773          	csrr	a4,satp
    80202590:	e398                	sd	a4,0(a5)
    p->tf->kernel_sp     = p->kstack + 4 * PGSIZE;   /* top of the kernel stack */
    80202592:	6d38                	ld	a4,88(a0)
    80202594:	613c                	ld	a5,64(a0)
    80202596:	6691                	lui	a3,0x4
    80202598:	97b6                	add	a5,a5,a3
    8020259a:	e71c                	sd	a5,8(a4)
    p->tf->kernel_trap   = (uint64)usertrap;
    8020259c:	6d3c                	ld	a5,88(a0)
    8020259e:	00000717          	auipc	a4,0x0
    802025a2:	03870713          	addi	a4,a4,56 # 802025d6 <usertrap>
    802025a6:	eb98                	sd	a4,16(a5)
    p->tf->kernel_hartid = r_tp();
    802025a8:	6d3c                	ld	a5,88(a0)
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    802025aa:	8712                	mv	a4,tp
    802025ac:	f398                	sd	a4,32(a5)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802025ae:	100027f3          	csrr	a5,sstatus

    uint64 x = r_sstatus();
    x &= ~SSTATUS_SPP;                /* SPP=0 -> sret drops us to U-mode */
    802025b2:	eff7f793          	andi	a5,a5,-257
    x |= SSTATUS_SPIE;                /* re-enable interrupts in user mode */
    802025b6:	0207e793          	ori	a5,a5,32
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802025ba:	10079073          	csrw	sstatus,a5
    w_sstatus(x);
    w_sepc(p->tf->epc);
    802025be:	6d28                	ld	a0,88(a0)
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    802025c0:	6d1c                	ld	a5,24(a0)
    802025c2:	14179073          	csrw	sepc,a5

    userret(p->tf);
    802025c6:	00000097          	auipc	ra,0x0
    802025ca:	246080e7          	jalr	582(ra) # 8020280c <userret>
}
    802025ce:	60a2                	ld	ra,8(sp)
    802025d0:	6402                	ld	s0,0(sp)
    802025d2:	0141                	addi	sp,sp,16
    802025d4:	8082                	ret

00000000802025d6 <usertrap>:
{
    802025d6:	7179                	addi	sp,sp,-48
    802025d8:	f406                	sd	ra,40(sp)
    802025da:	f022                	sd	s0,32(sp)
    802025dc:	1800                	addi	s0,sp,48
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802025de:	100027f3          	csrr	a5,sstatus
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    802025e2:	1007f793          	andi	a5,a5,256
    802025e6:	efa9                	bnez	a5,80202640 <usertrap+0x6a>
    802025e8:	ec26                	sd	s1,24(sp)
    802025ea:	e84a                	sd	s2,16(sp)
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    802025ec:	00000797          	auipc	a5,0x0
    802025f0:	13478793          	addi	a5,a5,308 # 80202720 <kernelvec>
    802025f4:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    802025f8:	fffff097          	auipc	ra,0xfffff
    802025fc:	0e2080e7          	jalr	226(ra) # 802016da <myproc>
    80202600:	84aa                	mv	s1,a0
    p->tf->epc = r_sepc();
    80202602:	6d3c                	ld	a5,88(a0)
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80202604:	14102773          	csrr	a4,sepc
    80202608:	ef98                	sd	a4,24(a5)
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    8020260a:	14202973          	csrr	s2,scause
    if (scause == 8) {               /* ecall: a system call */
    8020260e:	47a1                	li	a5,8
    80202610:	04f90463          	beq	s2,a5,80202658 <usertrap+0x82>
    } else if (scause == 15 || scause == 13) {   /* store / load page fault */
    80202614:	ffd97793          	andi	a5,s2,-3
    80202618:	4735                	li	a4,13
    8020261a:	08e78263          	beq	a5,a4,8020269e <usertrap+0xc8>
        int which = devintr();
    8020261e:	00000097          	auipc	ra,0x0
    80202622:	cd4080e7          	jalr	-812(ra) # 802022f2 <devintr>
        if (which == 0) {
    80202626:	c95d                	beqz	a0,802026dc <usertrap+0x106>
        if (which == 2 && p->state == RUNNING) yield();
    80202628:	4789                	li	a5,2
    8020262a:	04f51763          	bne	a0,a5,80202678 <usertrap+0xa2>
    8020262e:	4c98                	lw	a4,24(s1)
    80202630:	4791                	li	a5,4
    80202632:	04f71363          	bne	a4,a5,80202678 <usertrap+0xa2>
    80202636:	fffff097          	auipc	ra,0xfffff
    8020263a:	6cc080e7          	jalr	1740(ra) # 80201d02 <yield>
    8020263e:	a82d                	j	80202678 <usertrap+0xa2>
    80202640:	ec26                	sd	s1,24(sp)
    80202642:	e84a                	sd	s2,16(sp)
    80202644:	e44e                	sd	s3,8(sp)
    80202646:	e052                	sd	s4,0(sp)
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    80202648:	00005517          	auipc	a0,0x5
    8020264c:	17850513          	addi	a0,a0,376 # 802077c0 <etext+0x7c0>
    80202650:	ffffe097          	auipc	ra,0xffffe
    80202654:	f6a080e7          	jalr	-150(ra) # 802005ba <panic>
        if (p->killed) exit(-1);
    80202658:	551c                	lw	a5,40(a0)
    8020265a:	eb9d                	bnez	a5,80202690 <usertrap+0xba>
        p->tf->epc += 4;             /* return AFTER the ecall, not onto it */
    8020265c:	6d38                	ld	a4,88(a0)
    8020265e:	6f1c                	ld	a5,24(a4)
    80202660:	0791                	addi	a5,a5,4
    80202662:	ef1c                	sd	a5,24(a4)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202664:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202668:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    8020266c:	10079073          	csrw	sstatus,a5
        syscall();
    80202670:	00001097          	auipc	ra,0x1
    80202674:	e0e080e7          	jalr	-498(ra) # 8020347e <syscall>
    if (p->killed) exit(-1);
    80202678:	549c                	lw	a5,40(s1)
    8020267a:	ebd9                	bnez	a5,80202710 <usertrap+0x13a>
    usertrapret();
    8020267c:	00000097          	auipc	ra,0x0
    80202680:	ee8080e7          	jalr	-280(ra) # 80202564 <usertrapret>
    80202684:	64e2                	ld	s1,24(sp)
    80202686:	6942                	ld	s2,16(sp)
}
    80202688:	70a2                	ld	ra,40(sp)
    8020268a:	7402                	ld	s0,32(sp)
    8020268c:	6145                	addi	sp,sp,48
    8020268e:	8082                	ret
    80202690:	e44e                	sd	s3,8(sp)
    80202692:	e052                	sd	s4,0(sp)
        if (p->killed) exit(-1);
    80202694:	557d                	li	a0,-1
    80202696:	00000097          	auipc	ra,0x0
    8020269a:	8a4080e7          	jalr	-1884(ra) # 80201f3a <exit>
    8020269e:	e44e                	sd	s3,8(sp)
    802026a0:	e052                	sd	s4,0(sp)
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    802026a2:	14302a73          	csrr	s4,stval
        printf("usertrap: pid %d %s at va %p (sepc %p) - killing\n",
    802026a6:	03052983          	lw	s3,48(a0)
    802026aa:	854a                	mv	a0,s2
    802026ac:	00000097          	auipc	ra,0x0
    802026b0:	bb6080e7          	jalr	-1098(ra) # 80202262 <cause_str>
    802026b4:	862a                	mv	a2,a0
    802026b6:	6cbc                	ld	a5,88(s1)
    802026b8:	6f98                	ld	a4,24(a5)
    802026ba:	86d2                	mv	a3,s4
    802026bc:	85ce                	mv	a1,s3
    802026be:	00005517          	auipc	a0,0x5
    802026c2:	12250513          	addi	a0,a0,290 # 802077e0 <etext+0x7e0>
    802026c6:	ffffe097          	auipc	ra,0xffffe
    802026ca:	c82080e7          	jalr	-894(ra) # 80200348 <printf>
        p->killed = 1;
    802026ce:	4785                	li	a5,1
    802026d0:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    802026d2:	557d                	li	a0,-1
    802026d4:	00000097          	auipc	ra,0x0
    802026d8:	866080e7          	jalr	-1946(ra) # 80201f3a <exit>
    802026dc:	e44e                	sd	s3,8(sp)
            printf("usertrap: pid %d unexpected %s (scause %p, stval %p) - killing\n",
    802026de:	0304a983          	lw	s3,48(s1)
    802026e2:	0ff97513          	zext.b	a0,s2
    802026e6:	00000097          	auipc	ra,0x0
    802026ea:	b7c080e7          	jalr	-1156(ra) # 80202262 <cause_str>
    802026ee:	862a                	mv	a2,a0
    802026f0:	14302773          	csrr	a4,stval
    802026f4:	86ca                	mv	a3,s2
    802026f6:	85ce                	mv	a1,s3
    802026f8:	00005517          	auipc	a0,0x5
    802026fc:	12050513          	addi	a0,a0,288 # 80207818 <etext+0x818>
    80202700:	ffffe097          	auipc	ra,0xffffe
    80202704:	c48080e7          	jalr	-952(ra) # 80200348 <printf>
            p->killed = 1;
    80202708:	4785                	li	a5,1
    8020270a:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    8020270c:	e052                	sd	s4,0(sp)
    8020270e:	b7d1                	j	802026d2 <usertrap+0xfc>
    80202710:	e44e                	sd	s3,8(sp)
    80202712:	e052                	sd	s4,0(sp)
    80202714:	bf7d                	j	802026d2 <usertrap+0xfc>
	...

0000000080202720 <kernelvec>:
        .globl kernelvec
        .align 4
kernelvec:
        # We were already in the kernel: our sp is a valid kernel stack.
        # Save every caller-saved register - kerneltrap() is C and may clobber them.
        addi    sp, sp, -256
    80202720:	7111                	addi	sp,sp,-256
        sd      ra, 0(sp)
    80202722:	e006                	sd	ra,0(sp)
        sd      sp, 8(sp)
    80202724:	e40a                	sd	sp,8(sp)
        sd      gp, 16(sp)
    80202726:	e80e                	sd	gp,16(sp)
        sd      tp, 24(sp)
    80202728:	ec12                	sd	tp,24(sp)
        sd      t0, 32(sp)
    8020272a:	f016                	sd	t0,32(sp)
        sd      t1, 40(sp)
    8020272c:	f41a                	sd	t1,40(sp)
        sd      t2, 48(sp)
    8020272e:	f81e                	sd	t2,48(sp)
        sd      a0, 72(sp)
    80202730:	e4aa                	sd	a0,72(sp)
        sd      a1, 80(sp)
    80202732:	e8ae                	sd	a1,80(sp)
        sd      a2, 88(sp)
    80202734:	ecb2                	sd	a2,88(sp)
        sd      a3, 96(sp)
    80202736:	f0b6                	sd	a3,96(sp)
        sd      a4, 104(sp)
    80202738:	f4ba                	sd	a4,104(sp)
        sd      a5, 112(sp)
    8020273a:	f8be                	sd	a5,112(sp)
        sd      a6, 120(sp)
    8020273c:	fcc2                	sd	a6,120(sp)
        sd      a7, 128(sp)
    8020273e:	e146                	sd	a7,128(sp)
        sd      t3, 216(sp)
    80202740:	edf2                	sd	t3,216(sp)
        sd      t4, 224(sp)
    80202742:	f1f6                	sd	t4,224(sp)
        sd      t5, 232(sp)
    80202744:	f5fa                	sd	t5,232(sp)
        sd      t6, 240(sp)
    80202746:	f9fe                	sd	t6,240(sp)

        call    kerneltrap
    80202748:	00000097          	auipc	ra,0x0
    8020274c:	d5c080e7          	jalr	-676(ra) # 802024a4 <kerneltrap>

        ld      ra, 0(sp)
    80202750:	6082                	ld	ra,0(sp)
        ld      gp, 16(sp)
    80202752:	61c2                	ld	gp,16(sp)
        # NOT tp - kerneltrap may have moved us to another hart's scheduler.
        ld      t0, 32(sp)
    80202754:	7282                	ld	t0,32(sp)
        ld      t1, 40(sp)
    80202756:	7322                	ld	t1,40(sp)
        ld      t2, 48(sp)
    80202758:	73c2                	ld	t2,48(sp)
        ld      a0, 72(sp)
    8020275a:	6526                	ld	a0,72(sp)
        ld      a1, 80(sp)
    8020275c:	65c6                	ld	a1,80(sp)
        ld      a2, 88(sp)
    8020275e:	6666                	ld	a2,88(sp)
        ld      a3, 96(sp)
    80202760:	7686                	ld	a3,96(sp)
        ld      a4, 104(sp)
    80202762:	7726                	ld	a4,104(sp)
        ld      a5, 112(sp)
    80202764:	77c6                	ld	a5,112(sp)
        ld      a6, 120(sp)
    80202766:	7866                	ld	a6,120(sp)
        ld      a7, 128(sp)
    80202768:	688a                	ld	a7,128(sp)
        ld      t3, 216(sp)
    8020276a:	6e6e                	ld	t3,216(sp)
        ld      t4, 224(sp)
    8020276c:	7e8e                	ld	t4,224(sp)
        ld      t5, 232(sp)
    8020276e:	7f2e                	ld	t5,232(sp)
        ld      t6, 240(sp)
    80202770:	7fce                	ld	t6,240(sp)
        addi    sp, sp, 256
    80202772:	6111                	addi	sp,sp,256
        # sepc/sstatus were saved+restored by kerneltrap() in C.
        sret
    80202774:	10200073          	sret
    80202778:	00000013          	nop
    8020277c:	00000013          	nop

0000000080202780 <uservec>:
        .globl uservec
        .globl userret
        .globl usertrap
        .align 4
uservec:
        csrrw   a0, sscratch, a0        # a0 = &tf ; sscratch = user's a0
    80202780:	14051573          	csrrw	a0,sscratch,a0

        sd ra,  40(a0)
    80202784:	02153423          	sd	ra,40(a0)
        sd sp,  48(a0)
    80202788:	02253823          	sd	sp,48(a0)
        sd gp,  56(a0)
    8020278c:	02353c23          	sd	gp,56(a0)
        sd tp,  64(a0)
    80202790:	04453023          	sd	tp,64(a0)
        sd t0,  72(a0)
    80202794:	04553423          	sd	t0,72(a0)
        sd t1,  80(a0)
    80202798:	04653823          	sd	t1,80(a0)
        sd t2,  88(a0)
    8020279c:	04753c23          	sd	t2,88(a0)
        sd s0,  96(a0)
    802027a0:	f120                	sd	s0,96(a0)
        sd s1,  104(a0)
    802027a2:	f524                	sd	s1,104(a0)
        sd a1,  120(a0)
    802027a4:	fd2c                	sd	a1,120(a0)
        sd a2,  128(a0)
    802027a6:	e150                	sd	a2,128(a0)
        sd a3,  136(a0)
    802027a8:	e554                	sd	a3,136(a0)
        sd a4,  144(a0)
    802027aa:	e958                	sd	a4,144(a0)
        sd a5,  152(a0)
    802027ac:	ed5c                	sd	a5,152(a0)
        sd a6,  160(a0)
    802027ae:	0b053023          	sd	a6,160(a0)
        sd a7,  168(a0)
    802027b2:	0b153423          	sd	a7,168(a0)
        sd s2,  176(a0)
    802027b6:	0b253823          	sd	s2,176(a0)
        sd s3,  184(a0)
    802027ba:	0b353c23          	sd	s3,184(a0)
        sd s4,  192(a0)
    802027be:	0d453023          	sd	s4,192(a0)
        sd s5,  200(a0)
    802027c2:	0d553423          	sd	s5,200(a0)
        sd s6,  208(a0)
    802027c6:	0d653823          	sd	s6,208(a0)
        sd s7,  216(a0)
    802027ca:	0d753c23          	sd	s7,216(a0)
        sd s8,  224(a0)
    802027ce:	0f853023          	sd	s8,224(a0)
        sd s9,  232(a0)
    802027d2:	0f953423          	sd	s9,232(a0)
        sd s10, 240(a0)
    802027d6:	0fa53823          	sd	s10,240(a0)
        sd s11, 248(a0)
    802027da:	0fb53c23          	sd	s11,248(a0)
        sd t3,  256(a0)
    802027de:	11c53023          	sd	t3,256(a0)
        sd t4,  264(a0)
    802027e2:	11d53423          	sd	t4,264(a0)
        sd t5,  272(a0)
    802027e6:	11e53823          	sd	t5,272(a0)
        sd t6,  280(a0)
    802027ea:	11f53c23          	sd	t6,280(a0)

        csrr    t0, sscratch            # t0 = user's original a0
    802027ee:	140022f3          	csrr	t0,sscratch
        sd      t0, 112(a0)             # tf->a0
    802027f2:	06553823          	sd	t0,112(a0)

        csrr    t1, sepc
    802027f6:	14102373          	csrr	t1,sepc
        sd      t1, 24(a0)              # tf->epc = where user was
    802027fa:	00653c23          	sd	t1,24(a0)

        ld      tp, 32(a0)              # restore our hartid into tp
    802027fe:	02053203          	ld	tp,32(a0)
        ld      sp, 8(a0)               # switch to the kernel stack
    80202802:	00853103          	ld	sp,8(a0)
        ld      t1, 16(a0)              # tf->kernel_trap = &usertrap
    80202806:	01053303          	ld	t1,16(a0)
        jr      t1
    8020280a:	8302                	jr	t1

000000008020280c <userret>:

# void userret(struct trapframe *tf)  -- a0 = tf
userret:
        csrw    sscratch, a0            # so the next uservec can find it
    8020280c:	14051073          	csrw	sscratch,a0

        ld t0,  24(a0)
    80202810:	01853283          	ld	t0,24(a0)
        csrw    sepc, t0                # return to where the user left off
    80202814:	14129073          	csrw	sepc,t0

        ld ra,  40(a0)
    80202818:	02853083          	ld	ra,40(a0)
        ld sp,  48(a0)
    8020281c:	03053103          	ld	sp,48(a0)
        ld gp,  56(a0)
    80202820:	03853183          	ld	gp,56(a0)
        ld tp,  64(a0)
    80202824:	04053203          	ld	tp,64(a0)
        ld t0,  72(a0)
    80202828:	04853283          	ld	t0,72(a0)
        ld t1,  80(a0)
    8020282c:	05053303          	ld	t1,80(a0)
        ld t2,  88(a0)
    80202830:	05853383          	ld	t2,88(a0)
        ld s0,  96(a0)
    80202834:	7120                	ld	s0,96(a0)
        ld s1,  104(a0)
    80202836:	7524                	ld	s1,104(a0)
        ld a1,  120(a0)
    80202838:	7d2c                	ld	a1,120(a0)
        ld a2,  128(a0)
    8020283a:	6150                	ld	a2,128(a0)
        ld a3,  136(a0)
    8020283c:	6554                	ld	a3,136(a0)
        ld a4,  144(a0)
    8020283e:	6958                	ld	a4,144(a0)
        ld a5,  152(a0)
    80202840:	6d5c                	ld	a5,152(a0)
        ld a6,  160(a0)
    80202842:	0a053803          	ld	a6,160(a0)
        ld a7,  168(a0)
    80202846:	0a853883          	ld	a7,168(a0)
        ld s2,  176(a0)
    8020284a:	0b053903          	ld	s2,176(a0)
        ld s3,  184(a0)
    8020284e:	0b853983          	ld	s3,184(a0)
        ld s4,  192(a0)
    80202852:	0c053a03          	ld	s4,192(a0)
        ld s5,  200(a0)
    80202856:	0c853a83          	ld	s5,200(a0)
        ld s6,  208(a0)
    8020285a:	0d053b03          	ld	s6,208(a0)
        ld s7,  216(a0)
    8020285e:	0d853b83          	ld	s7,216(a0)
        ld s8,  224(a0)
    80202862:	0e053c03          	ld	s8,224(a0)
        ld s9,  232(a0)
    80202866:	0e853c83          	ld	s9,232(a0)
        ld s10, 240(a0)
    8020286a:	0f053d03          	ld	s10,240(a0)
        ld s11, 248(a0)
    8020286e:	0f853d83          	ld	s11,248(a0)
        ld t3,  256(a0)
    80202872:	10053e03          	ld	t3,256(a0)
        ld t4,  264(a0)
    80202876:	10853e83          	ld	t4,264(a0)
        ld t5,  272(a0)
    8020287a:	11053f03          	ld	t5,272(a0)
        ld t6,  280(a0)
    8020287e:	11853f83          	ld	t6,280(a0)

        ld a0,  112(a0)                 # finally, the user's a0 (syscall retval)
    80202882:	7928                	ld	a0,112(a0)
        sret
    80202884:	10200073          	sret
    80202888:	00000013          	nop
    8020288c:	00000013          	nop

0000000080202890 <freewalk_user>:
}

/* Free ONLY the user half of the tree (indices 0..1). Kernel entries are
 * borrowed, not owned - freeing them would take down every other process. */
static void freewalk_user(pagetable_t pt, int level)
{
    80202890:	7139                	addi	sp,sp,-64
    80202892:	fc06                	sd	ra,56(sp)
    80202894:	f822                	sd	s0,48(sp)
    80202896:	f426                	sd	s1,40(sp)
    80202898:	f04a                	sd	s2,32(sp)
    8020289a:	ec4e                	sd	s3,24(sp)
    8020289c:	e852                	sd	s4,16(sp)
    8020289e:	e456                	sd	s5,8(sp)
    802028a0:	0080                	addi	s0,sp,64
    802028a2:	89aa                	mv	s3,a0
    802028a4:	8a2e                	mv	s4,a1
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    802028a6:	4789                	li	a5,2
    802028a8:	20000913          	li	s2,512
    802028ac:	02f58c63          	beq	a1,a5,802028e4 <freewalk_user+0x54>
    for (int i = 0; i < limit; i++) {
    802028b0:	84ce                	mv	s1,s3
    802028b2:	090e                	slli	s2,s2,0x3
    802028b4:	994e                	add	s2,s2,s3
        pte_t pte = pt[i];
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    802028b6:	4a85                	li	s5,1
        pte_t pte = pt[i];
    802028b8:	609c                	ld	a5,0(s1)
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    802028ba:	00f7f713          	andi	a4,a5,15
    802028be:	03570563          	beq	a4,s5,802028e8 <freewalk_user+0x58>
    for (int i = 0; i < limit; i++) {
    802028c2:	04a1                	addi	s1,s1,8
    802028c4:	ff249ae3          	bne	s1,s2,802028b8 <freewalk_user+0x28>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
            pt[i] = 0;
        }
    }
    pfree((void *)pt);
    802028c8:	854e                	mv	a0,s3
    802028ca:	fffff097          	auipc	ra,0xfffff
    802028ce:	8a8080e7          	jalr	-1880(ra) # 80201172 <pfree>
}
    802028d2:	70e2                	ld	ra,56(sp)
    802028d4:	7442                	ld	s0,48(sp)
    802028d6:	74a2                	ld	s1,40(sp)
    802028d8:	7902                	ld	s2,32(sp)
    802028da:	69e2                	ld	s3,24(sp)
    802028dc:	6a42                	ld	s4,16(sp)
    802028de:	6aa2                	ld	s5,8(sp)
    802028e0:	6121                	addi	sp,sp,64
    802028e2:	8082                	ret
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    802028e4:	892e                	mv	s2,a1
    802028e6:	b7e9                	j	802028b0 <freewalk_user+0x20>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
    802028e8:	83a9                	srli	a5,a5,0xa
    802028ea:	fffa059b          	addiw	a1,s4,-1
    802028ee:	00c79513          	slli	a0,a5,0xc
    802028f2:	00000097          	auipc	ra,0x0
    802028f6:	f9e080e7          	jalr	-98(ra) # 80202890 <freewalk_user>
            pt[i] = 0;
    802028fa:	0004b023          	sd	zero,0(s1)
    802028fe:	b7d1                	j	802028c2 <freewalk_user+0x32>

0000000080202900 <vmprint_lvl>:
    return got_null ? 0 : -1;
}

/* Implementation note. */
static void vmprint_lvl(pagetable_t pt, int level)
{
    80202900:	711d                	addi	sp,sp,-96
    80202902:	ec86                	sd	ra,88(sp)
    80202904:	e8a2                	sd	s0,80(sp)
    80202906:	e4a6                	sd	s1,72(sp)
    80202908:	e0ca                	sd	s2,64(sp)
    8020290a:	fc4e                	sd	s3,56(sp)
    8020290c:	f852                	sd	s4,48(sp)
    8020290e:	f456                	sd	s5,40(sp)
    80202910:	f05a                	sd	s6,32(sp)
    80202912:	ec5e                	sd	s7,24(sp)
    80202914:	e862                	sd	s8,16(sp)
    80202916:	e466                	sd	s9,8(sp)
    80202918:	e06a                	sd	s10,0(sp)
    8020291a:	1080                	addi	s0,sp,96
    8020291c:	892e                	mv	s2,a1
    for (int i = 0; i < 512; i++) {
    8020291e:	8b2a                	mv	s6,a0
    80202920:	4a01                	li	s4,0
        pte_t pte = pt[i];
        if (!(pte & PTE_V)) continue;
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202922:	4b89                	li	s7,2
        for (int d = 2; d >= level; d--) printf(" ..");
    80202924:	00005a97          	auipc	s5,0x5
    80202928:	f34a8a93          	addi	s5,s5,-204 # 80207858 <etext+0x858>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    8020292c:	00005c97          	auipc	s9,0x5
    80202930:	f34c8c93          	addi	s9,s9,-204 # 80207860 <etext+0x860>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202934:	4d05                	li	s10,1
    for (int i = 0; i < 512; i++) {
    80202936:	20000c13          	li	s8,512
    8020293a:	a089                	j	8020297c <vmprint_lvl+0x7c>
        for (int d = 2; d >= level; d--) printf(" ..");
    8020293c:	84de                	mv	s1,s7
    8020293e:	052bca63          	blt	s7,s2,80202992 <vmprint_lvl+0x92>
    80202942:	8556                	mv	a0,s5
    80202944:	ffffe097          	auipc	ra,0xffffe
    80202948:	a04080e7          	jalr	-1532(ra) # 80200348 <printf>
    8020294c:	34fd                	addiw	s1,s1,-1
    8020294e:	ff24dae3          	bge	s1,s2,80202942 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202952:	00a9d493          	srli	s1,s3,0xa
    80202956:	04b2                	slli	s1,s1,0xc
    80202958:	86a6                	mv	a3,s1
    8020295a:	864e                	mv	a2,s3
    8020295c:	85d2                	mv	a1,s4
    8020295e:	8566                	mv	a0,s9
    80202960:	ffffe097          	auipc	ra,0xffffe
    80202964:	9e8080e7          	jalr	-1560(ra) # 80200348 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202968:	00e9f993          	andi	s3,s3,14
    8020296c:	00099463          	bnez	s3,80202974 <vmprint_lvl+0x74>
    80202970:	05204063          	bgtz	s2,802029b0 <vmprint_lvl+0xb0>
    for (int i = 0; i < 512; i++) {
    80202974:	2a05                	addiw	s4,s4,1
    80202976:	0b21                	addi	s6,s6,8
    80202978:	058a0463          	beq	s4,s8,802029c0 <vmprint_lvl+0xc0>
        pte_t pte = pt[i];
    8020297c:	000b3983          	ld	s3,0(s6)
        if (!(pte & PTE_V)) continue;
    80202980:	0019f793          	andi	a5,s3,1
    80202984:	dbe5                	beqz	a5,80202974 <vmprint_lvl+0x74>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202986:	fb791be3          	bne	s2,s7,8020293c <vmprint_lvl+0x3c>
    8020298a:	ff4d45e3          	blt	s10,s4,80202974 <vmprint_lvl+0x74>
    8020298e:	84ca                	mv	s1,s2
    80202990:	bf4d                	j	80202942 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202992:	00a9d493          	srli	s1,s3,0xa
    80202996:	04b2                	slli	s1,s1,0xc
    80202998:	86a6                	mv	a3,s1
    8020299a:	864e                	mv	a2,s3
    8020299c:	85d2                	mv	a1,s4
    8020299e:	8566                	mv	a0,s9
    802029a0:	ffffe097          	auipc	ra,0xffffe
    802029a4:	9a8080e7          	jalr	-1624(ra) # 80200348 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    802029a8:	00e9f993          	andi	s3,s3,14
    802029ac:	fc0994e3          	bnez	s3,80202974 <vmprint_lvl+0x74>
            vmprint_lvl((pagetable_t)PTE2PA(pte), level - 1);
    802029b0:	fff9059b          	addiw	a1,s2,-1
    802029b4:	8526                	mv	a0,s1
    802029b6:	00000097          	auipc	ra,0x0
    802029ba:	f4a080e7          	jalr	-182(ra) # 80202900 <vmprint_lvl>
    802029be:	bf5d                	j	80202974 <vmprint_lvl+0x74>
    }
}
    802029c0:	60e6                	ld	ra,88(sp)
    802029c2:	6446                	ld	s0,80(sp)
    802029c4:	64a6                	ld	s1,72(sp)
    802029c6:	6906                	ld	s2,64(sp)
    802029c8:	79e2                	ld	s3,56(sp)
    802029ca:	7a42                	ld	s4,48(sp)
    802029cc:	7aa2                	ld	s5,40(sp)
    802029ce:	7b02                	ld	s6,32(sp)
    802029d0:	6be2                	ld	s7,24(sp)
    802029d2:	6c42                	ld	s8,16(sp)
    802029d4:	6ca2                	ld	s9,8(sp)
    802029d6:	6d02                	ld	s10,0(sp)
    802029d8:	6125                	addi	sp,sp,96
    802029da:	8082                	ret

00000000802029dc <mmio_alias>:
uint64 mmio_alias(uint64 pa) { return MMIO_VA(pa); }
    802029dc:	1141                	addi	sp,sp,-16
    802029de:	e422                	sd	s0,8(sp)
    802029e0:	0800                	addi	s0,sp,16
    802029e2:	4785                	li	a5,1
    802029e4:	1782                	slli	a5,a5,0x20
    802029e6:	953e                	add	a0,a0,a5
    802029e8:	6422                	ld	s0,8(sp)
    802029ea:	0141                	addi	sp,sp,16
    802029ec:	8082                	ret

00000000802029ee <walk>:
{
    802029ee:	7139                	addi	sp,sp,-64
    802029f0:	fc06                	sd	ra,56(sp)
    802029f2:	f822                	sd	s0,48(sp)
    802029f4:	f426                	sd	s1,40(sp)
    802029f6:	f04a                	sd	s2,32(sp)
    802029f8:	ec4e                	sd	s3,24(sp)
    802029fa:	e852                	sd	s4,16(sp)
    802029fc:	e456                	sd	s5,8(sp)
    802029fe:	e05a                	sd	s6,0(sp)
    80202a00:	0080                	addi	s0,sp,64
    80202a02:	84aa                	mv	s1,a0
    80202a04:	89ae                	mv	s3,a1
    80202a06:	8ab2                	mv	s5,a2
    if (va >= MAXVA) panic("walk: va out of range");
    80202a08:	57fd                	li	a5,-1
    80202a0a:	83e9                	srli	a5,a5,0x1a
    80202a0c:	4a79                	li	s4,30
    for (int level = 2; level > 0; level--) {
    80202a0e:	4b31                	li	s6,12
    if (va >= MAXVA) panic("walk: va out of range");
    80202a10:	04b7f263          	bgeu	a5,a1,80202a54 <walk+0x66>
    80202a14:	00005517          	auipc	a0,0x5
    80202a18:	e6450513          	addi	a0,a0,-412 # 80207878 <etext+0x878>
    80202a1c:	ffffe097          	auipc	ra,0xffffe
    80202a20:	b9e080e7          	jalr	-1122(ra) # 802005ba <panic>
            if (!alloc) return 0;
    80202a24:	060a8663          	beqz	s5,80202a90 <walk+0xa2>
            pt = (pagetable_t)palloc();
    80202a28:	ffffe097          	auipc	ra,0xffffe
    80202a2c:	63a080e7          	jalr	1594(ra) # 80201062 <palloc>
    80202a30:	84aa                	mv	s1,a0
            if (!pt) return 0;
    80202a32:	c529                	beqz	a0,80202a7c <walk+0x8e>
            memset(pt, 0, PGSIZE);
    80202a34:	6605                	lui	a2,0x1
    80202a36:	4581                	li	a1,0
    80202a38:	ffffe097          	auipc	ra,0xffffe
    80202a3c:	c28080e7          	jalr	-984(ra) # 80200660 <memset>
            *pte = PA2PTE(pt) | PTE_V;
    80202a40:	00c4d793          	srli	a5,s1,0xc
    80202a44:	07aa                	slli	a5,a5,0xa
    80202a46:	0017e793          	ori	a5,a5,1
    80202a4a:	00f93023          	sd	a5,0(s2)
    for (int level = 2; level > 0; level--) {
    80202a4e:	3a5d                	addiw	s4,s4,-9
    80202a50:	036a0063          	beq	s4,s6,80202a70 <walk+0x82>
        pte_t *pte = &pt[PX(level, va)];
    80202a54:	0149d933          	srl	s2,s3,s4
    80202a58:	1ff97913          	andi	s2,s2,511
    80202a5c:	090e                	slli	s2,s2,0x3
    80202a5e:	9926                	add	s2,s2,s1
        if (*pte & PTE_V) {
    80202a60:	00093483          	ld	s1,0(s2)
    80202a64:	0014f793          	andi	a5,s1,1
    80202a68:	dfd5                	beqz	a5,80202a24 <walk+0x36>
            pt = (pagetable_t)PTE2PA(*pte);
    80202a6a:	80a9                	srli	s1,s1,0xa
    80202a6c:	04b2                	slli	s1,s1,0xc
    80202a6e:	b7c5                	j	80202a4e <walk+0x60>
    return &pt[PX(0, va)];
    80202a70:	00c9d513          	srli	a0,s3,0xc
    80202a74:	1ff57513          	andi	a0,a0,511
    80202a78:	050e                	slli	a0,a0,0x3
    80202a7a:	9526                	add	a0,a0,s1
}
    80202a7c:	70e2                	ld	ra,56(sp)
    80202a7e:	7442                	ld	s0,48(sp)
    80202a80:	74a2                	ld	s1,40(sp)
    80202a82:	7902                	ld	s2,32(sp)
    80202a84:	69e2                	ld	s3,24(sp)
    80202a86:	6a42                	ld	s4,16(sp)
    80202a88:	6aa2                	ld	s5,8(sp)
    80202a8a:	6b02                	ld	s6,0(sp)
    80202a8c:	6121                	addi	sp,sp,64
    80202a8e:	8082                	ret
            if (!alloc) return 0;
    80202a90:	4501                	li	a0,0
    80202a92:	b7ed                	j	80202a7c <walk+0x8e>

0000000080202a94 <walkaddr>:
    if (va >= MAXVA) return 0;
    80202a94:	57fd                	li	a5,-1
    80202a96:	83e9                	srli	a5,a5,0x1a
    80202a98:	00b7f463          	bgeu	a5,a1,80202aa0 <walkaddr+0xc>
    80202a9c:	4501                	li	a0,0
}
    80202a9e:	8082                	ret
{
    80202aa0:	1141                	addi	sp,sp,-16
    80202aa2:	e406                	sd	ra,8(sp)
    80202aa4:	e022                	sd	s0,0(sp)
    80202aa6:	0800                	addi	s0,sp,16
    pte_t *pte = walk(pt, va, 0);
    80202aa8:	4601                	li	a2,0
    80202aaa:	00000097          	auipc	ra,0x0
    80202aae:	f44080e7          	jalr	-188(ra) # 802029ee <walk>
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202ab2:	cd19                	beqz	a0,80202ad0 <walkaddr+0x3c>
    80202ab4:	611c                	ld	a5,0(a0)
    80202ab6:	0117f693          	andi	a3,a5,17
    80202aba:	4745                	li	a4,17
    80202abc:	4501                	li	a0,0
    80202abe:	00e69563          	bne	a3,a4,80202ac8 <walkaddr+0x34>
    return PTE2PA(*pte);
    80202ac2:	83a9                	srli	a5,a5,0xa
    80202ac4:	00c79513          	slli	a0,a5,0xc
}
    80202ac8:	60a2                	ld	ra,8(sp)
    80202aca:	6402                	ld	s0,0(sp)
    80202acc:	0141                	addi	sp,sp,16
    80202ace:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202ad0:	4501                	li	a0,0
    80202ad2:	bfdd                	j	80202ac8 <walkaddr+0x34>

0000000080202ad4 <mappages>:
{
    80202ad4:	715d                	addi	sp,sp,-80
    80202ad6:	e486                	sd	ra,72(sp)
    80202ad8:	e0a2                	sd	s0,64(sp)
    80202ada:	fc26                	sd	s1,56(sp)
    80202adc:	f84a                	sd	s2,48(sp)
    80202ade:	f44e                	sd	s3,40(sp)
    80202ae0:	f052                	sd	s4,32(sp)
    80202ae2:	ec56                	sd	s5,24(sp)
    80202ae4:	e85a                	sd	s6,16(sp)
    80202ae6:	e45e                	sd	s7,8(sp)
    80202ae8:	0880                	addi	s0,sp,80
    if (size == 0) panic("mappages: zero size");
    80202aea:	c639                	beqz	a2,80202b38 <mappages+0x64>
    80202aec:	8aaa                	mv	s5,a0
    80202aee:	8b3a                	mv	s6,a4
    uint64 a    = PGROUNDDOWN(va);
    80202af0:	777d                	lui	a4,0xfffff
    80202af2:	00e5f7b3          	and	a5,a1,a4
    uint64 last = PGROUNDDOWN(va + size - 1);
    80202af6:	fff58993          	addi	s3,a1,-1
    80202afa:	99b2                	add	s3,s3,a2
    80202afc:	00e9f9b3          	and	s3,s3,a4
    uint64 a    = PGROUNDDOWN(va);
    80202b00:	893e                	mv	s2,a5
    80202b02:	40f68a33          	sub	s4,a3,a5
        a  += PGSIZE;
    80202b06:	6b85                	lui	s7,0x1
    80202b08:	014904b3          	add	s1,s2,s4
        pte_t *pte = walk(pt, a, 1);
    80202b0c:	4605                	li	a2,1
    80202b0e:	85ca                	mv	a1,s2
    80202b10:	8556                	mv	a0,s5
    80202b12:	00000097          	auipc	ra,0x0
    80202b16:	edc080e7          	jalr	-292(ra) # 802029ee <walk>
        if (!pte) return -1;
    80202b1a:	cd1d                	beqz	a0,80202b58 <mappages+0x84>
        if (*pte & PTE_V) panic("mappages: remap");
    80202b1c:	611c                	ld	a5,0(a0)
    80202b1e:	8b85                	andi	a5,a5,1
    80202b20:	e785                	bnez	a5,80202b48 <mappages+0x74>
        *pte = PA2PTE(pa) | perm | PTE_V;
    80202b22:	80b1                	srli	s1,s1,0xc
    80202b24:	04aa                	slli	s1,s1,0xa
    80202b26:	0164e4b3          	or	s1,s1,s6
    80202b2a:	0014e493          	ori	s1,s1,1
    80202b2e:	e104                	sd	s1,0(a0)
        if (a == last) break;
    80202b30:	05390063          	beq	s2,s3,80202b70 <mappages+0x9c>
        a  += PGSIZE;
    80202b34:	995e                	add	s2,s2,s7
    for (;;) {
    80202b36:	bfc9                	j	80202b08 <mappages+0x34>
    if (size == 0) panic("mappages: zero size");
    80202b38:	00005517          	auipc	a0,0x5
    80202b3c:	d5850513          	addi	a0,a0,-680 # 80207890 <etext+0x890>
    80202b40:	ffffe097          	auipc	ra,0xffffe
    80202b44:	a7a080e7          	jalr	-1414(ra) # 802005ba <panic>
        if (*pte & PTE_V) panic("mappages: remap");
    80202b48:	00005517          	auipc	a0,0x5
    80202b4c:	d6050513          	addi	a0,a0,-672 # 802078a8 <etext+0x8a8>
    80202b50:	ffffe097          	auipc	ra,0xffffe
    80202b54:	a6a080e7          	jalr	-1430(ra) # 802005ba <panic>
        if (!pte) return -1;
    80202b58:	557d                	li	a0,-1
}
    80202b5a:	60a6                	ld	ra,72(sp)
    80202b5c:	6406                	ld	s0,64(sp)
    80202b5e:	74e2                	ld	s1,56(sp)
    80202b60:	7942                	ld	s2,48(sp)
    80202b62:	79a2                	ld	s3,40(sp)
    80202b64:	7a02                	ld	s4,32(sp)
    80202b66:	6ae2                	ld	s5,24(sp)
    80202b68:	6b42                	ld	s6,16(sp)
    80202b6a:	6ba2                	ld	s7,8(sp)
    80202b6c:	6161                	addi	sp,sp,80
    80202b6e:	8082                	ret
    return 0;
    80202b70:	4501                	li	a0,0
    80202b72:	b7e5                	j	80202b5a <mappages+0x86>

0000000080202b74 <kvmmap>:
{
    80202b74:	1141                	addi	sp,sp,-16
    80202b76:	e406                	sd	ra,8(sp)
    80202b78:	e022                	sd	s0,0(sp)
    80202b7a:	0800                	addi	s0,sp,16
    80202b7c:	8736                	mv	a4,a3
    if (mappages(kernel_pagetable, va, sz, pa, perm) != 0)
    80202b7e:	86ae                	mv	a3,a1
    80202b80:	85aa                	mv	a1,a0
    80202b82:	0013c517          	auipc	a0,0x13c
    80202b86:	49e53503          	ld	a0,1182(a0) # 8033f020 <kernel_pagetable>
    80202b8a:	00000097          	auipc	ra,0x0
    80202b8e:	f4a080e7          	jalr	-182(ra) # 80202ad4 <mappages>
    80202b92:	e509                	bnez	a0,80202b9c <kvmmap+0x28>
}
    80202b94:	60a2                	ld	ra,8(sp)
    80202b96:	6402                	ld	s0,0(sp)
    80202b98:	0141                	addi	sp,sp,16
    80202b9a:	8082                	ret
        panic("kvmmap");
    80202b9c:	00005517          	auipc	a0,0x5
    80202ba0:	d1c50513          	addi	a0,a0,-740 # 802078b8 <etext+0x8b8>
    80202ba4:	ffffe097          	auipc	ra,0xffffe
    80202ba8:	a16080e7          	jalr	-1514(ra) # 802005ba <panic>

0000000080202bac <kvminit>:
{
    80202bac:	7179                	addi	sp,sp,-48
    80202bae:	f406                	sd	ra,40(sp)
    80202bb0:	f022                	sd	s0,32(sp)
    80202bb2:	ec26                	sd	s1,24(sp)
    80202bb4:	e84a                	sd	s2,16(sp)
    80202bb6:	1800                	addi	s0,sp,48
    kernel_pagetable = (pagetable_t)palloc();
    80202bb8:	ffffe097          	auipc	ra,0xffffe
    80202bbc:	4aa080e7          	jalr	1194(ra) # 80201062 <palloc>
    80202bc0:	0013c717          	auipc	a4,0x13c
    80202bc4:	46a73023          	sd	a0,1120(a4) # 8033f020 <kernel_pagetable>
    memset(kernel_pagetable, 0, PGSIZE);
    80202bc8:	6605                	lui	a2,0x1
    80202bca:	4581                	li	a1,0
    80202bcc:	ffffe097          	auipc	ra,0xffffe
    80202bd0:	a94080e7          	jalr	-1388(ra) # 80200660 <memset>
    kvmmap(MMIO_VA(fdt.uart_base), fdt.uart_base, PGSIZE, PTE_R | PTE_W);
    80202bd4:	00026497          	auipc	s1,0x26
    80202bd8:	44448493          	addi	s1,s1,1092 # 80229018 <fdt>
    80202bdc:	688c                	ld	a1,16(s1)
    80202bde:	4505                	li	a0,1
    80202be0:	1502                	slli	a0,a0,0x20
    80202be2:	4699                	li	a3,6
    80202be4:	6605                	lui	a2,0x1
    80202be6:	952e                	add	a0,a0,a1
    80202be8:	00000097          	auipc	ra,0x0
    80202bec:	f8c080e7          	jalr	-116(ra) # 80202b74 <kvmmap>
    if (fdt.plic_base)
    80202bf0:	6c8c                	ld	a1,24(s1)
    80202bf2:	e1d5                	bnez	a1,80202c96 <kvminit+0xea>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202bf4:	00026797          	auipc	a5,0x26
    80202bf8:	4ac7a783          	lw	a5,1196(a5) # 802290a0 <fdt+0x88>
    80202bfc:	02f05e63          	blez	a5,80202c38 <kvminit+0x8c>
    80202c00:	e44e                	sd	s3,8(sp)
    80202c02:	e052                	sd	s4,0(sp)
    80202c04:	00026917          	auipc	s2,0x26
    80202c08:	41490913          	addi	s2,s2,1044 # 80229018 <fdt>
    80202c0c:	4481                	li	s1,0
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202c0e:	4985                	li	s3,1
    80202c10:	1982                	slli	s3,s3,0x20
    for (int i = 0; i < fdt.nvirtio; i++)
    80202c12:	8a4a                	mv	s4,s2
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202c14:	02893583          	ld	a1,40(s2)
    80202c18:	4699                	li	a3,6
    80202c1a:	6605                	lui	a2,0x1
    80202c1c:	01358533          	add	a0,a1,s3
    80202c20:	00000097          	auipc	ra,0x0
    80202c24:	f54080e7          	jalr	-172(ra) # 80202b74 <kvmmap>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202c28:	2485                	addiw	s1,s1,1
    80202c2a:	0921                	addi	s2,s2,8
    80202c2c:	088a2783          	lw	a5,136(s4)
    80202c30:	fef4c2e3          	blt	s1,a5,80202c14 <kvminit+0x68>
    80202c34:	69a2                	ld	s3,8(sp)
    80202c36:	6a02                	ld	s4,0(sp)
    kvmmap(ktext, ktext, (uint64)etext - ktext, PTE_R | PTE_X);
    80202c38:	00004497          	auipc	s1,0x4
    80202c3c:	3c848493          	addi	s1,s1,968 # 80207000 <etext>
    80202c40:	bff00613          	li	a2,-1025
    80202c44:	0656                	slli	a2,a2,0x15
    80202c46:	46a9                	li	a3,10
    80202c48:	9626                	add	a2,a2,s1
    80202c4a:	40100593          	li	a1,1025
    80202c4e:	05d6                	slli	a1,a1,0x15
    80202c50:	852e                	mv	a0,a1
    80202c52:	00000097          	auipc	ra,0x0
    80202c56:	f22080e7          	jalr	-222(ra) # 80202b74 <kvmmap>
    uint64 mem_end = fdt.mem_base + fdt.mem_size;
    80202c5a:	00026917          	auipc	s2,0x26
    80202c5e:	3be90913          	addi	s2,s2,958 # 80229018 <fdt>
    80202c62:	09093603          	ld	a2,144(s2)
    80202c66:	09893783          	ld	a5,152(s2)
    80202c6a:	963e                	add	a2,a2,a5
    kvmmap((uint64)etext, (uint64)etext, mem_end - (uint64)etext, PTE_R | PTE_W);
    80202c6c:	4699                	li	a3,6
    80202c6e:	8e05                	sub	a2,a2,s1
    80202c70:	85a6                	mv	a1,s1
    80202c72:	8526                	mv	a0,s1
    80202c74:	00000097          	auipc	ra,0x0
    80202c78:	f00080e7          	jalr	-256(ra) # 80202b74 <kvmmap>
    if (fdt.mem_base < ktext)
    80202c7c:	09093503          	ld	a0,144(s2)
    80202c80:	40100793          	li	a5,1025
    80202c84:	07d6                	slli	a5,a5,0x15
    80202c86:	02f56363          	bltu	a0,a5,80202cac <kvminit+0x100>
}
    80202c8a:	70a2                	ld	ra,40(sp)
    80202c8c:	7402                	ld	s0,32(sp)
    80202c8e:	64e2                	ld	s1,24(sp)
    80202c90:	6942                	ld	s2,16(sp)
    80202c92:	6145                	addi	sp,sp,48
    80202c94:	8082                	ret
        kvmmap(MMIO_VA(fdt.plic_base), fdt.plic_base, 0x400000, PTE_R | PTE_W);
    80202c96:	4505                	li	a0,1
    80202c98:	1502                	slli	a0,a0,0x20
    80202c9a:	4699                	li	a3,6
    80202c9c:	00400637          	lui	a2,0x400
    80202ca0:	952e                	add	a0,a0,a1
    80202ca2:	00000097          	auipc	ra,0x0
    80202ca6:	ed2080e7          	jalr	-302(ra) # 80202b74 <kvmmap>
    80202caa:	b7a9                	j	80202bf4 <kvminit+0x48>
        kvmmap(fdt.mem_base, fdt.mem_base, ktext - fdt.mem_base, PTE_R | PTE_W);
    80202cac:	4699                	li	a3,6
    80202cae:	40a78633          	sub	a2,a5,a0
    80202cb2:	85aa                	mv	a1,a0
    80202cb4:	00000097          	auipc	ra,0x0
    80202cb8:	ec0080e7          	jalr	-320(ra) # 80202b74 <kvmmap>
}
    80202cbc:	b7f9                	j	80202c8a <kvminit+0xde>

0000000080202cbe <kvminithart>:
{
    80202cbe:	1141                	addi	sp,sp,-16
    80202cc0:	e422                	sd	s0,8(sp)
    80202cc2:	0800                	addi	s0,sp,16
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202cc4:	12000073          	sfence.vma
    w_satp(MAKE_SATP(kernel_pagetable));
    80202cc8:	0013c797          	auipc	a5,0x13c
    80202ccc:	3587b783          	ld	a5,856(a5) # 8033f020 <kernel_pagetable>
    80202cd0:	83b1                	srli	a5,a5,0xc
    80202cd2:	577d                	li	a4,-1
    80202cd4:	177e                	slli	a4,a4,0x3f
    80202cd6:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80202cd8:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202cdc:	12000073          	sfence.vma
}
    80202ce0:	6422                	ld	s0,8(sp)
    80202ce2:	0141                	addi	sp,sp,16
    80202ce4:	8082                	ret

0000000080202ce6 <uvmcreate>:
{
    80202ce6:	1101                	addi	sp,sp,-32
    80202ce8:	ec06                	sd	ra,24(sp)
    80202cea:	e822                	sd	s0,16(sp)
    80202cec:	e426                	sd	s1,8(sp)
    80202cee:	1000                	addi	s0,sp,32
    pagetable_t pt = (pagetable_t)palloc();
    80202cf0:	ffffe097          	auipc	ra,0xffffe
    80202cf4:	372080e7          	jalr	882(ra) # 80201062 <palloc>
    80202cf8:	84aa                	mv	s1,a0
    if (!pt) return 0;
    80202cfa:	c515                	beqz	a0,80202d26 <uvmcreate+0x40>
    memset(pt, 0, PGSIZE);
    80202cfc:	6605                	lui	a2,0x1
    80202cfe:	4581                	li	a1,0
    80202d00:	ffffe097          	auipc	ra,0xffffe
    80202d04:	960080e7          	jalr	-1696(ra) # 80200660 <memset>
    80202d08:	47c1                	li	a5,16
        pt[i] = kernel_pagetable[i];
    80202d0a:	0013c597          	auipc	a1,0x13c
    80202d0e:	31658593          	addi	a1,a1,790 # 8033f020 <kernel_pagetable>
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202d12:	6605                	lui	a2,0x1
        pt[i] = kernel_pagetable[i];
    80202d14:	6198                	ld	a4,0(a1)
    80202d16:	973e                	add	a4,a4,a5
    80202d18:	6314                	ld	a3,0(a4)
    80202d1a:	00f48733          	add	a4,s1,a5
    80202d1e:	e314                	sd	a3,0(a4)
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202d20:	07a1                	addi	a5,a5,8
    80202d22:	fec799e3          	bne	a5,a2,80202d14 <uvmcreate+0x2e>
}
    80202d26:	8526                	mv	a0,s1
    80202d28:	60e2                	ld	ra,24(sp)
    80202d2a:	6442                	ld	s0,16(sp)
    80202d2c:	64a2                	ld	s1,8(sp)
    80202d2e:	6105                	addi	sp,sp,32
    80202d30:	8082                	ret

0000000080202d32 <uvmunmap>:
{
    80202d32:	7139                	addi	sp,sp,-64
    80202d34:	fc06                	sd	ra,56(sp)
    80202d36:	f822                	sd	s0,48(sp)
    80202d38:	ec4e                	sd	s3,24(sp)
    80202d3a:	0080                	addi	s0,sp,64
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202d3c:	0632                	slli	a2,a2,0xc
    80202d3e:	00b609b3          	add	s3,a2,a1
    80202d42:	0535fd63          	bgeu	a1,s3,80202d9c <uvmunmap+0x6a>
    80202d46:	f426                	sd	s1,40(sp)
    80202d48:	f04a                	sd	s2,32(sp)
    80202d4a:	e852                	sd	s4,16(sp)
    80202d4c:	e456                	sd	s5,8(sp)
    80202d4e:	e05a                	sd	s6,0(sp)
    80202d50:	8a2a                	mv	s4,a0
    80202d52:	892e                	mv	s2,a1
    80202d54:	8ab6                	mv	s5,a3
    80202d56:	6b05                	lui	s6,0x1
    80202d58:	a031                	j	80202d64 <uvmunmap+0x32>
        *pte = 0;
    80202d5a:	0004b023          	sd	zero,0(s1)
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202d5e:	995a                	add	s2,s2,s6
    80202d60:	03397963          	bgeu	s2,s3,80202d92 <uvmunmap+0x60>
        pte_t *pte = walk(pt, a, 0);
    80202d64:	4601                	li	a2,0
    80202d66:	85ca                	mv	a1,s2
    80202d68:	8552                	mv	a0,s4
    80202d6a:	00000097          	auipc	ra,0x0
    80202d6e:	c84080e7          	jalr	-892(ra) # 802029ee <walk>
    80202d72:	84aa                	mv	s1,a0
        if (!pte || !(*pte & PTE_V)) continue;     /* lazily-allocated: fine */
    80202d74:	d56d                	beqz	a0,80202d5e <uvmunmap+0x2c>
    80202d76:	611c                	ld	a5,0(a0)
    80202d78:	0017f713          	andi	a4,a5,1
    80202d7c:	d36d                	beqz	a4,80202d5e <uvmunmap+0x2c>
        if (do_free) pfree((void *)PTE2PA(*pte));
    80202d7e:	fc0a8ee3          	beqz	s5,80202d5a <uvmunmap+0x28>
    80202d82:	83a9                	srli	a5,a5,0xa
    80202d84:	00c79513          	slli	a0,a5,0xc
    80202d88:	ffffe097          	auipc	ra,0xffffe
    80202d8c:	3ea080e7          	jalr	1002(ra) # 80201172 <pfree>
    80202d90:	b7e9                	j	80202d5a <uvmunmap+0x28>
    80202d92:	74a2                	ld	s1,40(sp)
    80202d94:	7902                	ld	s2,32(sp)
    80202d96:	6a42                	ld	s4,16(sp)
    80202d98:	6aa2                	ld	s5,8(sp)
    80202d9a:	6b02                	ld	s6,0(sp)
}
    80202d9c:	70e2                	ld	ra,56(sp)
    80202d9e:	7442                	ld	s0,48(sp)
    80202da0:	69e2                	ld	s3,24(sp)
    80202da2:	6121                	addi	sp,sp,64
    80202da4:	8082                	ret

0000000080202da6 <uvmfree>:
{
    80202da6:	1101                	addi	sp,sp,-32
    80202da8:	ec06                	sd	ra,24(sp)
    80202daa:	e822                	sd	s0,16(sp)
    80202dac:	e426                	sd	s1,8(sp)
    80202dae:	1000                	addi	s0,sp,32
    80202db0:	84aa                	mv	s1,a0
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202db2:	ed81                	bnez	a1,80202dca <uvmfree+0x24>
    freewalk_user(pt, 2);
    80202db4:	4589                	li	a1,2
    80202db6:	8526                	mv	a0,s1
    80202db8:	00000097          	auipc	ra,0x0
    80202dbc:	ad8080e7          	jalr	-1320(ra) # 80202890 <freewalk_user>
}
    80202dc0:	60e2                	ld	ra,24(sp)
    80202dc2:	6442                	ld	s0,16(sp)
    80202dc4:	64a2                	ld	s1,8(sp)
    80202dc6:	6105                	addi	sp,sp,32
    80202dc8:	8082                	ret
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202dca:	6785                	lui	a5,0x1
    80202dcc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80202dce:	95be                	add	a1,a1,a5
    80202dd0:	4685                	li	a3,1
    80202dd2:	00c5d613          	srli	a2,a1,0xc
    80202dd6:	4581                	li	a1,0
    80202dd8:	00000097          	auipc	ra,0x0
    80202ddc:	f5a080e7          	jalr	-166(ra) # 80202d32 <uvmunmap>
    80202de0:	bfd1                	j	80202db4 <uvmfree+0xe>

0000000080202de2 <uvmcopy>:
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202de2:	c661                	beqz	a2,80202eaa <uvmcopy+0xc8>
{
    80202de4:	715d                	addi	sp,sp,-80
    80202de6:	e486                	sd	ra,72(sp)
    80202de8:	e0a2                	sd	s0,64(sp)
    80202dea:	fc26                	sd	s1,56(sp)
    80202dec:	f84a                	sd	s2,48(sp)
    80202dee:	f44e                	sd	s3,40(sp)
    80202df0:	f052                	sd	s4,32(sp)
    80202df2:	ec56                	sd	s5,24(sp)
    80202df4:	e85a                	sd	s6,16(sp)
    80202df6:	e45e                	sd	s7,8(sp)
    80202df8:	0880                	addi	s0,sp,80
    80202dfa:	8aaa                	mv	s5,a0
    80202dfc:	8b2e                	mv	s6,a1
    80202dfe:	8a32                	mv	s4,a2
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202e00:	4481                	li	s1,0
    80202e02:	a005                	j	80202e22 <uvmcopy+0x40>
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202e04:	4685                	li	a3,1
    80202e06:	00c4d613          	srli	a2,s1,0xc
    80202e0a:	4581                	li	a1,0
    80202e0c:	855a                	mv	a0,s6
    80202e0e:	00000097          	auipc	ra,0x0
    80202e12:	f24080e7          	jalr	-220(ra) # 80202d32 <uvmunmap>
    80202e16:	557d                	li	a0,-1
    80202e18:	a8b5                	j	80202e94 <uvmcopy+0xb2>
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202e1a:	6785                	lui	a5,0x1
    80202e1c:	94be                	add	s1,s1,a5
    80202e1e:	0744fa63          	bgeu	s1,s4,80202e92 <uvmcopy+0xb0>
        pte_t *pte = walk(old, i, 0);
    80202e22:	4601                	li	a2,0
    80202e24:	85a6                	mv	a1,s1
    80202e26:	8556                	mv	a0,s5
    80202e28:	00000097          	auipc	ra,0x0
    80202e2c:	bc6080e7          	jalr	-1082(ra) # 802029ee <walk>
        if (!pte || !(*pte & PTE_V)) continue;
    80202e30:	d56d                	beqz	a0,80202e1a <uvmcopy+0x38>
    80202e32:	6118                	ld	a4,0(a0)
    80202e34:	00177793          	andi	a5,a4,1
    80202e38:	d3ed                	beqz	a5,80202e1a <uvmcopy+0x38>
        uint64 pa    = PTE2PA(*pte);
    80202e3a:	00a75593          	srli	a1,a4,0xa
    80202e3e:	00c59b93          	slli	s7,a1,0xc
        uint64 flags = PTE_FLAGS(*pte);
    80202e42:	3ff77913          	andi	s2,a4,1023
        char *mem = palloc();
    80202e46:	ffffe097          	auipc	ra,0xffffe
    80202e4a:	21c080e7          	jalr	540(ra) # 80201062 <palloc>
    80202e4e:	89aa                	mv	s3,a0
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202e50:	d955                	beqz	a0,80202e04 <uvmcopy+0x22>
        memmove(mem, (void *)pa, PGSIZE);
    80202e52:	6605                	lui	a2,0x1
    80202e54:	85de                	mv	a1,s7
    80202e56:	ffffe097          	auipc	ra,0xffffe
    80202e5a:	826080e7          	jalr	-2010(ra) # 8020067c <memmove>
        if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    80202e5e:	874a                	mv	a4,s2
    80202e60:	86ce                	mv	a3,s3
    80202e62:	6605                	lui	a2,0x1
    80202e64:	85a6                	mv	a1,s1
    80202e66:	855a                	mv	a0,s6
    80202e68:	00000097          	auipc	ra,0x0
    80202e6c:	c6c080e7          	jalr	-916(ra) # 80202ad4 <mappages>
    80202e70:	d54d                	beqz	a0,80202e1a <uvmcopy+0x38>
            pfree(mem);
    80202e72:	854e                	mv	a0,s3
    80202e74:	ffffe097          	auipc	ra,0xffffe
    80202e78:	2fe080e7          	jalr	766(ra) # 80201172 <pfree>
            uvmunmap(new, 0, i / PGSIZE, 1);
    80202e7c:	4685                	li	a3,1
    80202e7e:	00c4d613          	srli	a2,s1,0xc
    80202e82:	4581                	li	a1,0
    80202e84:	855a                	mv	a0,s6
    80202e86:	00000097          	auipc	ra,0x0
    80202e8a:	eac080e7          	jalr	-340(ra) # 80202d32 <uvmunmap>
            return -1;
    80202e8e:	557d                	li	a0,-1
    80202e90:	a011                	j	80202e94 <uvmcopy+0xb2>
    return 0;
    80202e92:	4501                	li	a0,0
}
    80202e94:	60a6                	ld	ra,72(sp)
    80202e96:	6406                	ld	s0,64(sp)
    80202e98:	74e2                	ld	s1,56(sp)
    80202e9a:	7942                	ld	s2,48(sp)
    80202e9c:	79a2                	ld	s3,40(sp)
    80202e9e:	7a02                	ld	s4,32(sp)
    80202ea0:	6ae2                	ld	s5,24(sp)
    80202ea2:	6b42                	ld	s6,16(sp)
    80202ea4:	6ba2                	ld	s7,8(sp)
    80202ea6:	6161                	addi	sp,sp,80
    80202ea8:	8082                	ret
    return 0;
    80202eaa:	4501                	li	a0,0
}
    80202eac:	8082                	ret

0000000080202eae <copyout>:
    while (len > 0) {
    80202eae:	c2d5                	beqz	a3,80202f52 <copyout+0xa4>
{
    80202eb0:	711d                	addi	sp,sp,-96
    80202eb2:	ec86                	sd	ra,88(sp)
    80202eb4:	e8a2                	sd	s0,80(sp)
    80202eb6:	e4a6                	sd	s1,72(sp)
    80202eb8:	fc4e                	sd	s3,56(sp)
    80202eba:	f456                	sd	s5,40(sp)
    80202ebc:	f05a                	sd	s6,32(sp)
    80202ebe:	ec5e                	sd	s7,24(sp)
    80202ec0:	1080                	addi	s0,sp,96
    80202ec2:	8baa                	mv	s7,a0
    80202ec4:	8aae                	mv	s5,a1
    80202ec6:	8b32                	mv	s6,a2
    80202ec8:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(dstva);
    80202eca:	74fd                	lui	s1,0xfffff
    80202ecc:	8ced                	and	s1,s1,a1
        if (va0 >= USER_TOP) return -1;
    80202ece:	800007b7          	lui	a5,0x80000
    80202ed2:	fff7c793          	not	a5,a5
    80202ed6:	0897e063          	bltu	a5,s1,80202f56 <copyout+0xa8>
    80202eda:	e0ca                	sd	s2,64(sp)
    80202edc:	f852                	sd	s4,48(sp)
    80202ede:	e862                	sd	s8,16(sp)
    80202ee0:	e466                	sd	s9,8(sp)
    80202ee2:	e06a                	sd	s10,0(sp)
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202ee4:	4cc5                	li	s9,17
    80202ee6:	6d05                	lui	s10,0x1
        if (va0 >= USER_TOP) return -1;
    80202ee8:	8c3e                	mv	s8,a5
    80202eea:	a02d                	j	80202f14 <copyout+0x66>
        uint64 pa0 = PTE2PA(*pte);
    80202eec:	83a9                	srli	a5,a5,0xa
    80202eee:	07b2                	slli	a5,a5,0xc
        memmove((void *)(pa0 + (dstva - va0)), src, n);
    80202ef0:	409a8533          	sub	a0,s5,s1
    80202ef4:	864a                	mv	a2,s2
    80202ef6:	85da                	mv	a1,s6
    80202ef8:	953e                	add	a0,a0,a5
    80202efa:	ffffd097          	auipc	ra,0xffffd
    80202efe:	782080e7          	jalr	1922(ra) # 8020067c <memmove>
        len -= n; src += n; dstva = va0 + PGSIZE;
    80202f02:	412989b3          	sub	s3,s3,s2
    80202f06:	9b4a                	add	s6,s6,s2
    while (len > 0) {
    80202f08:	02098e63          	beqz	s3,80202f44 <copyout+0x96>
        if (va0 >= USER_TOP) return -1;
    80202f0c:	054c6763          	bltu	s8,s4,80202f5a <copyout+0xac>
    80202f10:	84d2                	mv	s1,s4
    80202f12:	8ad2                	mv	s5,s4
        pte_t *pte = walk(pt, va0, 0);
    80202f14:	4601                	li	a2,0
    80202f16:	85a6                	mv	a1,s1
    80202f18:	855e                	mv	a0,s7
    80202f1a:	00000097          	auipc	ra,0x0
    80202f1e:	ad4080e7          	jalr	-1324(ra) # 802029ee <walk>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202f22:	c139                	beqz	a0,80202f68 <copyout+0xba>
    80202f24:	611c                	ld	a5,0(a0)
    80202f26:	0117f713          	andi	a4,a5,17
    80202f2a:	05971e63          	bne	a4,s9,80202f86 <copyout+0xd8>
        if (!(*pte & PTE_W)) return -1;   /* Implementation note. */
    80202f2e:	0047f713          	andi	a4,a5,4
    80202f32:	c32d                	beqz	a4,80202f94 <copyout+0xe6>
        uint64 n = PGSIZE - (dstva - va0);
    80202f34:	01a48a33          	add	s4,s1,s10
    80202f38:	415a0933          	sub	s2,s4,s5
        if (n > len) n = len;
    80202f3c:	fb29f8e3          	bgeu	s3,s2,80202eec <copyout+0x3e>
    80202f40:	894e                	mv	s2,s3
    80202f42:	b76d                	j	80202eec <copyout+0x3e>
    return 0;
    80202f44:	4501                	li	a0,0
    80202f46:	6906                	ld	s2,64(sp)
    80202f48:	7a42                	ld	s4,48(sp)
    80202f4a:	6c42                	ld	s8,16(sp)
    80202f4c:	6ca2                	ld	s9,8(sp)
    80202f4e:	6d02                	ld	s10,0(sp)
    80202f50:	a015                	j	80202f74 <copyout+0xc6>
    80202f52:	4501                	li	a0,0
}
    80202f54:	8082                	ret
        if (va0 >= USER_TOP) return -1;
    80202f56:	557d                	li	a0,-1
    80202f58:	a831                	j	80202f74 <copyout+0xc6>
    80202f5a:	557d                	li	a0,-1
    80202f5c:	6906                	ld	s2,64(sp)
    80202f5e:	7a42                	ld	s4,48(sp)
    80202f60:	6c42                	ld	s8,16(sp)
    80202f62:	6ca2                	ld	s9,8(sp)
    80202f64:	6d02                	ld	s10,0(sp)
    80202f66:	a039                	j	80202f74 <copyout+0xc6>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202f68:	557d                	li	a0,-1
    80202f6a:	6906                	ld	s2,64(sp)
    80202f6c:	7a42                	ld	s4,48(sp)
    80202f6e:	6c42                	ld	s8,16(sp)
    80202f70:	6ca2                	ld	s9,8(sp)
    80202f72:	6d02                	ld	s10,0(sp)
}
    80202f74:	60e6                	ld	ra,88(sp)
    80202f76:	6446                	ld	s0,80(sp)
    80202f78:	64a6                	ld	s1,72(sp)
    80202f7a:	79e2                	ld	s3,56(sp)
    80202f7c:	7aa2                	ld	s5,40(sp)
    80202f7e:	7b02                	ld	s6,32(sp)
    80202f80:	6be2                	ld	s7,24(sp)
    80202f82:	6125                	addi	sp,sp,96
    80202f84:	8082                	ret
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202f86:	557d                	li	a0,-1
    80202f88:	6906                	ld	s2,64(sp)
    80202f8a:	7a42                	ld	s4,48(sp)
    80202f8c:	6c42                	ld	s8,16(sp)
    80202f8e:	6ca2                	ld	s9,8(sp)
    80202f90:	6d02                	ld	s10,0(sp)
    80202f92:	b7cd                	j	80202f74 <copyout+0xc6>
        if (!(*pte & PTE_W)) return -1;   /* Implementation note. */
    80202f94:	557d                	li	a0,-1
    80202f96:	6906                	ld	s2,64(sp)
    80202f98:	7a42                	ld	s4,48(sp)
    80202f9a:	6c42                	ld	s8,16(sp)
    80202f9c:	6ca2                	ld	s9,8(sp)
    80202f9e:	6d02                	ld	s10,0(sp)
    80202fa0:	bfd1                	j	80202f74 <copyout+0xc6>

0000000080202fa2 <copyin>:
    while (len > 0) {
    80202fa2:	c6bd                	beqz	a3,80203010 <copyin+0x6e>
{
    80202fa4:	715d                	addi	sp,sp,-80
    80202fa6:	e486                	sd	ra,72(sp)
    80202fa8:	e0a2                	sd	s0,64(sp)
    80202faa:	fc26                	sd	s1,56(sp)
    80202fac:	f84a                	sd	s2,48(sp)
    80202fae:	f44e                	sd	s3,40(sp)
    80202fb0:	f052                	sd	s4,32(sp)
    80202fb2:	ec56                	sd	s5,24(sp)
    80202fb4:	e85a                	sd	s6,16(sp)
    80202fb6:	e45e                	sd	s7,8(sp)
    80202fb8:	e062                	sd	s8,0(sp)
    80202fba:	0880                	addi	s0,sp,80
    80202fbc:	8b2a                	mv	s6,a0
    80202fbe:	8a2e                	mv	s4,a1
    80202fc0:	8c32                	mv	s8,a2
    80202fc2:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    80202fc4:	7bfd                	lui	s7,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    80202fc6:	6a85                	lui	s5,0x1
    80202fc8:	a015                	j	80202fec <copyin+0x4a>
        memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80202fca:	018505b3          	add	a1,a0,s8
    80202fce:	8626                	mv	a2,s1
    80202fd0:	412585b3          	sub	a1,a1,s2
    80202fd4:	8552                	mv	a0,s4
    80202fd6:	ffffd097          	auipc	ra,0xffffd
    80202fda:	6a6080e7          	jalr	1702(ra) # 8020067c <memmove>
        len -= n; dst += n; srcva = va0 + PGSIZE;
    80202fde:	409989b3          	sub	s3,s3,s1
    80202fe2:	9a26                	add	s4,s4,s1
    80202fe4:	01590c33          	add	s8,s2,s5
    while (len > 0) {
    80202fe8:	02098263          	beqz	s3,8020300c <copyin+0x6a>
        uint64 va0 = PGROUNDDOWN(srcva);
    80202fec:	017c7933          	and	s2,s8,s7
        uint64 pa0 = walkaddr(pt, va0);
    80202ff0:	85ca                	mv	a1,s2
    80202ff2:	855a                	mv	a0,s6
    80202ff4:	00000097          	auipc	ra,0x0
    80202ff8:	aa0080e7          	jalr	-1376(ra) # 80202a94 <walkaddr>
        if (pa0 == 0) return -1;
    80202ffc:	cd01                	beqz	a0,80203014 <copyin+0x72>
        uint64 n = PGSIZE - (srcva - va0);
    80202ffe:	418904b3          	sub	s1,s2,s8
    80203002:	94d6                	add	s1,s1,s5
        if (n > len) n = len;
    80203004:	fc99f3e3          	bgeu	s3,s1,80202fca <copyin+0x28>
    80203008:	84ce                	mv	s1,s3
    8020300a:	b7c1                	j	80202fca <copyin+0x28>
    return 0;
    8020300c:	4501                	li	a0,0
    8020300e:	a021                	j	80203016 <copyin+0x74>
    80203010:	4501                	li	a0,0
}
    80203012:	8082                	ret
        if (pa0 == 0) return -1;
    80203014:	557d                	li	a0,-1
}
    80203016:	60a6                	ld	ra,72(sp)
    80203018:	6406                	ld	s0,64(sp)
    8020301a:	74e2                	ld	s1,56(sp)
    8020301c:	7942                	ld	s2,48(sp)
    8020301e:	79a2                	ld	s3,40(sp)
    80203020:	7a02                	ld	s4,32(sp)
    80203022:	6ae2                	ld	s5,24(sp)
    80203024:	6b42                	ld	s6,16(sp)
    80203026:	6ba2                	ld	s7,8(sp)
    80203028:	6c02                	ld	s8,0(sp)
    8020302a:	6161                	addi	sp,sp,80
    8020302c:	8082                	ret

000000008020302e <copyinstr>:
    while (got_null == 0 && max > 0) {
    8020302e:	c6cd                	beqz	a3,802030d8 <copyinstr+0xaa>
{
    80203030:	715d                	addi	sp,sp,-80
    80203032:	e486                	sd	ra,72(sp)
    80203034:	e0a2                	sd	s0,64(sp)
    80203036:	fc26                	sd	s1,56(sp)
    80203038:	f84a                	sd	s2,48(sp)
    8020303a:	f44e                	sd	s3,40(sp)
    8020303c:	f052                	sd	s4,32(sp)
    8020303e:	ec56                	sd	s5,24(sp)
    80203040:	e85a                	sd	s6,16(sp)
    80203042:	e45e                	sd	s7,8(sp)
    80203044:	0880                	addi	s0,sp,80
    80203046:	8a2a                	mv	s4,a0
    80203048:	8b2e                	mv	s6,a1
    8020304a:	8bb2                	mv	s7,a2
    8020304c:	8936                	mv	s2,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    8020304e:	7afd                	lui	s5,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    80203050:	6985                	lui	s3,0x1
    80203052:	a811                	j	80203066 <copyinstr+0x38>
    80203054:	01258733          	add	a4,a1,s2
            dst++; p++; n--; max--;
    80203058:	40f70933          	sub	s2,a4,a5
        srcva = va0 + PGSIZE;
    8020305c:	01348bb3          	add	s7,s1,s3
    while (got_null == 0 && max > 0) {
    80203060:	06e78463          	beq	a5,a4,802030c8 <copyinstr+0x9a>
{
    80203064:	8b3e                	mv	s6,a5
        uint64 va0 = PGROUNDDOWN(srcva);
    80203066:	015bf4b3          	and	s1,s7,s5
        uint64 pa0 = walkaddr(pt, va0);
    8020306a:	85a6                	mv	a1,s1
    8020306c:	8552                	mv	a0,s4
    8020306e:	00000097          	auipc	ra,0x0
    80203072:	a26080e7          	jalr	-1498(ra) # 80202a94 <walkaddr>
        if (pa0 == 0) return -1;
    80203076:	c939                	beqz	a0,802030cc <copyinstr+0x9e>
        uint64 n = PGSIZE - (srcva - va0);
    80203078:	417486b3          	sub	a3,s1,s7
    8020307c:	96ce                	add	a3,a3,s3
        if (n > max) n = max;
    8020307e:	00d97363          	bgeu	s2,a3,80203084 <copyinstr+0x56>
    80203082:	86ca                	mv	a3,s2
        char *p = (char *)(pa0 + (srcva - va0));
    80203084:	955e                	add	a0,a0,s7
    80203086:	8d05                	sub	a0,a0,s1
        while (n > 0) {
    80203088:	c6a1                	beqz	a3,802030d0 <copyinstr+0xa2>
    8020308a:	87da                	mv	a5,s6
    8020308c:	85da                	mv	a1,s6
            *dst = *p;
    8020308e:	41650633          	sub	a2,a0,s6
        while (n > 0) {
    80203092:	96da                	add	a3,a3,s6
            *dst = *p;
    80203094:	00c78733          	add	a4,a5,a2
    80203098:	00074703          	lbu	a4,0(a4)
    8020309c:	00e78023          	sb	a4,0(a5) # ffffffff80000000 <uart+0xfffffffeffcc0fd0>
            if (*p == '\0') { got_null = 1; break; }
    802030a0:	c709                	beqz	a4,802030aa <copyinstr+0x7c>
            dst++; p++; n--; max--;
    802030a2:	0785                	addi	a5,a5,1
        while (n > 0) {
    802030a4:	fef698e3          	bne	a3,a5,80203094 <copyinstr+0x66>
    802030a8:	b775                	j	80203054 <copyinstr+0x26>
    802030aa:	4785                	li	a5,1
    return got_null ? 0 : -1;
    802030ac:	37fd                	addiw	a5,a5,-1
    802030ae:	0007851b          	sext.w	a0,a5
}
    802030b2:	60a6                	ld	ra,72(sp)
    802030b4:	6406                	ld	s0,64(sp)
    802030b6:	74e2                	ld	s1,56(sp)
    802030b8:	7942                	ld	s2,48(sp)
    802030ba:	79a2                	ld	s3,40(sp)
    802030bc:	7a02                	ld	s4,32(sp)
    802030be:	6ae2                	ld	s5,24(sp)
    802030c0:	6b42                	ld	s6,16(sp)
    802030c2:	6ba2                	ld	s7,8(sp)
    802030c4:	6161                	addi	sp,sp,80
    802030c6:	8082                	ret
    802030c8:	4781                	li	a5,0
    802030ca:	b7cd                	j	802030ac <copyinstr+0x7e>
        if (pa0 == 0) return -1;
    802030cc:	557d                	li	a0,-1
    802030ce:	b7d5                	j	802030b2 <copyinstr+0x84>
        srcva = va0 + PGSIZE;
    802030d0:	6b85                	lui	s7,0x1
    802030d2:	9ba6                	add	s7,s7,s1
    802030d4:	87da                	mv	a5,s6
    802030d6:	b779                	j	80203064 <copyinstr+0x36>
    int got_null = 0;
    802030d8:	4781                	li	a5,0
    return got_null ? 0 : -1;
    802030da:	37fd                	addiw	a5,a5,-1
    802030dc:	0007851b          	sext.w	a0,a5
}
    802030e0:	8082                	ret

00000000802030e2 <vmprint>:
void vmprint(pagetable_t pt)
{
    802030e2:	1101                	addi	sp,sp,-32
    802030e4:	ec06                	sd	ra,24(sp)
    802030e6:	e822                	sd	s0,16(sp)
    802030e8:	e426                	sd	s1,8(sp)
    802030ea:	1000                	addi	s0,sp,32
    802030ec:	84aa                	mv	s1,a0
    printf("page table %p (user half)\n", pt);
    802030ee:	85aa                	mv	a1,a0
    802030f0:	00004517          	auipc	a0,0x4
    802030f4:	7d050513          	addi	a0,a0,2000 # 802078c0 <etext+0x8c0>
    802030f8:	ffffd097          	auipc	ra,0xffffd
    802030fc:	250080e7          	jalr	592(ra) # 80200348 <printf>
    vmprint_lvl(pt, 2);
    80203100:	4589                	li	a1,2
    80203102:	8526                	mv	a0,s1
    80203104:	fffff097          	auipc	ra,0xfffff
    80203108:	7fc080e7          	jalr	2044(ra) # 80202900 <vmprint_lvl>
}
    8020310c:	60e2                	ld	ra,24(sp)
    8020310e:	6442                	ld	s0,16(sp)
    80203110:	64a2                	ld	s1,8(sp)
    80203112:	6105                	addi	sp,sp,32
    80203114:	8082                	ret

0000000080203116 <sys_getpid>:
    int n; argint(0, &n);
    exit(n);
    return 0;
}

uint64 sys_getpid(void) { return myproc()->pid; }
    80203116:	1141                	addi	sp,sp,-16
    80203118:	e406                	sd	ra,8(sp)
    8020311a:	e022                	sd	s0,0(sp)
    8020311c:	0800                	addi	s0,sp,16
    8020311e:	ffffe097          	auipc	ra,0xffffe
    80203122:	5bc080e7          	jalr	1468(ra) # 802016da <myproc>
    80203126:	5908                	lw	a0,48(a0)
    80203128:	60a2                	ld	ra,8(sp)
    8020312a:	6402                	ld	s0,0(sp)
    8020312c:	0141                	addi	sp,sp,16
    8020312e:	8082                	ret

0000000080203130 <argraw>:
{
    80203130:	1101                	addi	sp,sp,-32
    80203132:	ec06                	sd	ra,24(sp)
    80203134:	e822                	sd	s0,16(sp)
    80203136:	e426                	sd	s1,8(sp)
    80203138:	1000                	addi	s0,sp,32
    8020313a:	84aa                	mv	s1,a0
    struct trapframe *tf = myproc()->tf;
    8020313c:	ffffe097          	auipc	ra,0xffffe
    80203140:	59e080e7          	jalr	1438(ra) # 802016da <myproc>
    80203144:	6d34                	ld	a3,88(a0)
    switch (n) {
    80203146:	4795                	li	a5,5
    80203148:	0297eb63          	bltu	a5,s1,8020317e <argraw+0x4e>
    8020314c:	048a                	slli	s1,s1,0x2
    8020314e:	00005717          	auipc	a4,0x5
    80203152:	d1a70713          	addi	a4,a4,-742 # 80207e68 <st.0+0x70>
    80203156:	94ba                	add	s1,s1,a4
    80203158:	409c                	lw	a5,0(s1)
    8020315a:	97ba                	add	a5,a5,a4
    8020315c:	8782                	jr	a5
    case 0: return tf->a0;
    8020315e:	7aa8                	ld	a0,112(a3)
}
    80203160:	60e2                	ld	ra,24(sp)
    80203162:	6442                	ld	s0,16(sp)
    80203164:	64a2                	ld	s1,8(sp)
    80203166:	6105                	addi	sp,sp,32
    80203168:	8082                	ret
    case 1: return tf->a1;
    8020316a:	7ea8                	ld	a0,120(a3)
    8020316c:	bfd5                	j	80203160 <argraw+0x30>
    case 2: return tf->a2;
    8020316e:	62c8                	ld	a0,128(a3)
    80203170:	bfc5                	j	80203160 <argraw+0x30>
    case 3: return tf->a3;
    80203172:	66c8                	ld	a0,136(a3)
    80203174:	b7f5                	j	80203160 <argraw+0x30>
    case 4: return tf->a4;
    80203176:	6ac8                	ld	a0,144(a3)
    80203178:	b7e5                	j	80203160 <argraw+0x30>
    case 5: return tf->a5;
    8020317a:	6ec8                	ld	a0,152(a3)
    8020317c:	b7d5                	j	80203160 <argraw+0x30>
    panic("argraw: bad arg index");
    8020317e:	00004517          	auipc	a0,0x4
    80203182:	76250513          	addi	a0,a0,1890 # 802078e0 <etext+0x8e0>
    80203186:	ffffd097          	auipc	ra,0xffffd
    8020318a:	434080e7          	jalr	1076(ra) # 802005ba <panic>

000000008020318e <sys_fork>:

uint64 sys_fork(void)   { return fork(); }
    8020318e:	1141                	addi	sp,sp,-16
    80203190:	e406                	sd	ra,8(sp)
    80203192:	e022                	sd	s0,0(sp)
    80203194:	0800                	addi	s0,sp,16
    80203196:	fffff097          	auipc	ra,0xfffff
    8020319a:	86e080e7          	jalr	-1938(ra) # 80201a04 <fork>
    8020319e:	60a2                	ld	ra,8(sp)
    802031a0:	6402                	ld	s0,0(sp)
    802031a2:	0141                	addi	sp,sp,16
    802031a4:	8082                	ret

00000000802031a6 <sys_uptime>:
    int pid; argint(0, &pid);
    return kill(pid);
}

uint64 sys_uptime(void)
{
    802031a6:	1101                	addi	sp,sp,-32
    802031a8:	ec06                	sd	ra,24(sp)
    802031aa:	e822                	sd	s0,16(sp)
    802031ac:	e426                	sd	s1,8(sp)
    802031ae:	1000                	addi	s0,sp,32
    acquire(&tickslock);
    802031b0:	0012e517          	auipc	a0,0x12e
    802031b4:	85050513          	addi	a0,a0,-1968 # 80330a00 <tickslock>
    802031b8:	ffffe097          	auipc	ra,0xffffe
    802031bc:	138080e7          	jalr	312(ra) # 802012f0 <acquire>
    uint64 t = ticks;
    802031c0:	0013c497          	auipc	s1,0x13c
    802031c4:	e584b483          	ld	s1,-424(s1) # 8033f018 <ticks>
    release(&tickslock);
    802031c8:	0012e517          	auipc	a0,0x12e
    802031cc:	83850513          	addi	a0,a0,-1992 # 80330a00 <tickslock>
    802031d0:	ffffe097          	auipc	ra,0xffffe
    802031d4:	1d4080e7          	jalr	468(ra) # 802013a4 <release>
    return t;
}
    802031d8:	8526                	mv	a0,s1
    802031da:	60e2                	ld	ra,24(sp)
    802031dc:	6442                	ld	s0,16(sp)
    802031de:	64a2                	ld	s1,8(sp)
    802031e0:	6105                	addi	sp,sp,32
    802031e2:	8082                	ret

00000000802031e4 <sys_freepages>:

/* Luit extras: test hooks and observability (used by meminfo and ps). */
uint64 sys_freepages(void) { return palloc_free_count(); }
    802031e4:	1141                	addi	sp,sp,-16
    802031e6:	e406                	sd	ra,8(sp)
    802031e8:	e022                	sd	s0,0(sp)
    802031ea:	0800                	addi	s0,sp,16
    802031ec:	ffffe097          	auipc	ra,0xffffe
    802031f0:	04e080e7          	jalr	78(ra) # 8020123a <palloc_free_count>
    802031f4:	60a2                	ld	ra,8(sp)
    802031f6:	6402                	ld	s0,0(sp)
    802031f8:	0141                	addi	sp,sp,16
    802031fa:	8082                	ret

00000000802031fc <argint>:
int argint(int n, int *ip)     { *ip = (int)argraw(n); return 0; }
    802031fc:	1101                	addi	sp,sp,-32
    802031fe:	ec06                	sd	ra,24(sp)
    80203200:	e822                	sd	s0,16(sp)
    80203202:	e426                	sd	s1,8(sp)
    80203204:	1000                	addi	s0,sp,32
    80203206:	84ae                	mv	s1,a1
    80203208:	00000097          	auipc	ra,0x0
    8020320c:	f28080e7          	jalr	-216(ra) # 80203130 <argraw>
    80203210:	c088                	sw	a0,0(s1)
    80203212:	4501                	li	a0,0
    80203214:	60e2                	ld	ra,24(sp)
    80203216:	6442                	ld	s0,16(sp)
    80203218:	64a2                	ld	s1,8(sp)
    8020321a:	6105                	addi	sp,sp,32
    8020321c:	8082                	ret

000000008020321e <sys_exit>:
{
    8020321e:	1101                	addi	sp,sp,-32
    80203220:	ec06                	sd	ra,24(sp)
    80203222:	e822                	sd	s0,16(sp)
    80203224:	1000                	addi	s0,sp,32
    int n; argint(0, &n);
    80203226:	fec40593          	addi	a1,s0,-20
    8020322a:	4501                	li	a0,0
    8020322c:	00000097          	auipc	ra,0x0
    80203230:	fd0080e7          	jalr	-48(ra) # 802031fc <argint>
    exit(n);
    80203234:	fec42503          	lw	a0,-20(s0)
    80203238:	fffff097          	auipc	ra,0xfffff
    8020323c:	d02080e7          	jalr	-766(ra) # 80201f3a <exit>

0000000080203240 <sys_sbrk>:
{
    80203240:	7179                	addi	sp,sp,-48
    80203242:	f406                	sd	ra,40(sp)
    80203244:	f022                	sd	s0,32(sp)
    80203246:	ec26                	sd	s1,24(sp)
    80203248:	1800                	addi	s0,sp,48
    int n; argint(0, &n);
    8020324a:	fdc40593          	addi	a1,s0,-36
    8020324e:	4501                	li	a0,0
    80203250:	00000097          	auipc	ra,0x0
    80203254:	fac080e7          	jalr	-84(ra) # 802031fc <argint>
    uint64 addr = myproc()->sz;
    80203258:	ffffe097          	auipc	ra,0xffffe
    8020325c:	482080e7          	jalr	1154(ra) # 802016da <myproc>
    80203260:	6524                	ld	s1,72(a0)
    if (growproc(n) < 0) return -1;
    80203262:	fdc42503          	lw	a0,-36(s0)
    80203266:	ffffe097          	auipc	ra,0xffffe
    8020326a:	6b4080e7          	jalr	1716(ra) # 8020191a <growproc>
    8020326e:	00054863          	bltz	a0,8020327e <sys_sbrk+0x3e>
}
    80203272:	8526                	mv	a0,s1
    80203274:	70a2                	ld	ra,40(sp)
    80203276:	7402                	ld	s0,32(sp)
    80203278:	64e2                	ld	s1,24(sp)
    8020327a:	6145                	addi	sp,sp,48
    8020327c:	8082                	ret
    if (growproc(n) < 0) return -1;
    8020327e:	54fd                	li	s1,-1
    80203280:	bfcd                	j	80203272 <sys_sbrk+0x32>

0000000080203282 <sys_sleep>:
{
    80203282:	7139                	addi	sp,sp,-64
    80203284:	fc06                	sd	ra,56(sp)
    80203286:	f822                	sd	s0,48(sp)
    80203288:	f04a                	sd	s2,32(sp)
    8020328a:	ec4e                	sd	s3,24(sp)
    8020328c:	0080                	addi	s0,sp,64
    int n; argint(0, &n);
    8020328e:	fcc40593          	addi	a1,s0,-52
    80203292:	4501                	li	a0,0
    80203294:	00000097          	auipc	ra,0x0
    80203298:	f68080e7          	jalr	-152(ra) # 802031fc <argint>
    acquire(&tickslock);
    8020329c:	0012d517          	auipc	a0,0x12d
    802032a0:	76450513          	addi	a0,a0,1892 # 80330a00 <tickslock>
    802032a4:	ffffe097          	auipc	ra,0xffffe
    802032a8:	04c080e7          	jalr	76(ra) # 802012f0 <acquire>
    uint64 t0 = ticks;
    802032ac:	0013c997          	auipc	s3,0x13c
    802032b0:	d6c9b983          	ld	s3,-660(s3) # 8033f018 <ticks>
    while (ticks - t0 < (uint64)n) {
    802032b4:	fcc42903          	lw	s2,-52(s0)
    802032b8:	02090f63          	beqz	s2,802032f6 <sys_sleep+0x74>
    802032bc:	f426                	sd	s1,40(sp)
    802032be:	e852                	sd	s4,16(sp)
        sleep(&ticks, &tickslock);
    802032c0:	0012da17          	auipc	s4,0x12d
    802032c4:	740a0a13          	addi	s4,s4,1856 # 80330a00 <tickslock>
    802032c8:	0013c497          	auipc	s1,0x13c
    802032cc:	d5048493          	addi	s1,s1,-688 # 8033f018 <ticks>
        if (myproc()->killed) { release(&tickslock); return -1; }
    802032d0:	ffffe097          	auipc	ra,0xffffe
    802032d4:	40a080e7          	jalr	1034(ra) # 802016da <myproc>
    802032d8:	551c                	lw	a5,40(a0)
    802032da:	ef8d                	bnez	a5,80203314 <sys_sleep+0x92>
        sleep(&ticks, &tickslock);
    802032dc:	85d2                	mv	a1,s4
    802032de:	8526                	mv	a0,s1
    802032e0:	fffff097          	auipc	ra,0xfffff
    802032e4:	a5e080e7          	jalr	-1442(ra) # 80201d3e <sleep>
    while (ticks - t0 < (uint64)n) {
    802032e8:	609c                	ld	a5,0(s1)
    802032ea:	413787b3          	sub	a5,a5,s3
    802032ee:	ff27e1e3          	bltu	a5,s2,802032d0 <sys_sleep+0x4e>
    802032f2:	74a2                	ld	s1,40(sp)
    802032f4:	6a42                	ld	s4,16(sp)
    release(&tickslock);
    802032f6:	0012d517          	auipc	a0,0x12d
    802032fa:	70a50513          	addi	a0,a0,1802 # 80330a00 <tickslock>
    802032fe:	ffffe097          	auipc	ra,0xffffe
    80203302:	0a6080e7          	jalr	166(ra) # 802013a4 <release>
    return 0;
    80203306:	4501                	li	a0,0
}
    80203308:	70e2                	ld	ra,56(sp)
    8020330a:	7442                	ld	s0,48(sp)
    8020330c:	7902                	ld	s2,32(sp)
    8020330e:	69e2                	ld	s3,24(sp)
    80203310:	6121                	addi	sp,sp,64
    80203312:	8082                	ret
        if (myproc()->killed) { release(&tickslock); return -1; }
    80203314:	0012d517          	auipc	a0,0x12d
    80203318:	6ec50513          	addi	a0,a0,1772 # 80330a00 <tickslock>
    8020331c:	ffffe097          	auipc	ra,0xffffe
    80203320:	088080e7          	jalr	136(ra) # 802013a4 <release>
    80203324:	557d                	li	a0,-1
    80203326:	74a2                	ld	s1,40(sp)
    80203328:	6a42                	ld	s4,16(sp)
    8020332a:	bff9                	j	80203308 <sys_sleep+0x86>

000000008020332c <sys_kill>:
{
    8020332c:	1101                	addi	sp,sp,-32
    8020332e:	ec06                	sd	ra,24(sp)
    80203330:	e822                	sd	s0,16(sp)
    80203332:	1000                	addi	s0,sp,32
    int pid; argint(0, &pid);
    80203334:	fec40593          	addi	a1,s0,-20
    80203338:	4501                	li	a0,0
    8020333a:	00000097          	auipc	ra,0x0
    8020333e:	ec2080e7          	jalr	-318(ra) # 802031fc <argint>
    return kill(pid);
    80203342:	fec42503          	lw	a0,-20(s0)
    80203346:	fffff097          	auipc	ra,0xfffff
    8020334a:	cf2080e7          	jalr	-782(ra) # 80202038 <kill>
}
    8020334e:	60e2                	ld	ra,24(sp)
    80203350:	6442                	ld	s0,16(sp)
    80203352:	6105                	addi	sp,sp,32
    80203354:	8082                	ret

0000000080203356 <argaddr>:
int argaddr(int n, uint64 *ap) { *ap = argraw(n); return 0; }
    80203356:	1101                	addi	sp,sp,-32
    80203358:	ec06                	sd	ra,24(sp)
    8020335a:	e822                	sd	s0,16(sp)
    8020335c:	e426                	sd	s1,8(sp)
    8020335e:	1000                	addi	s0,sp,32
    80203360:	84ae                	mv	s1,a1
    80203362:	00000097          	auipc	ra,0x0
    80203366:	dce080e7          	jalr	-562(ra) # 80203130 <argraw>
    8020336a:	e088                	sd	a0,0(s1)
    8020336c:	4501                	li	a0,0
    8020336e:	60e2                	ld	ra,24(sp)
    80203370:	6442                	ld	s0,16(sp)
    80203372:	64a2                	ld	s1,8(sp)
    80203374:	6105                	addi	sp,sp,32
    80203376:	8082                	ret

0000000080203378 <sys_wait>:
{
    80203378:	1101                	addi	sp,sp,-32
    8020337a:	ec06                	sd	ra,24(sp)
    8020337c:	e822                	sd	s0,16(sp)
    8020337e:	1000                	addi	s0,sp,32
    uint64 p; argaddr(0, &p);
    80203380:	fe840593          	addi	a1,s0,-24
    80203384:	4501                	li	a0,0
    80203386:	00000097          	auipc	ra,0x0
    8020338a:	fd0080e7          	jalr	-48(ra) # 80203356 <argaddr>
    return wait(p);
    8020338e:	fe843503          	ld	a0,-24(s0)
    80203392:	fffff097          	auipc	ra,0xfffff
    80203396:	a10080e7          	jalr	-1520(ra) # 80201da2 <wait>
}
    8020339a:	60e2                	ld	ra,24(sp)
    8020339c:	6442                	ld	s0,16(sp)
    8020339e:	6105                	addi	sp,sp,32
    802033a0:	8082                	ret

00000000802033a2 <sys_procstat>:

uint64 sys_procstat(void)
{
    802033a2:	1101                	addi	sp,sp,-32
    802033a4:	ec06                	sd	ra,24(sp)
    802033a6:	e822                	sd	s0,16(sp)
    802033a8:	1000                	addi	s0,sp,32
    uint64 uaddr;
    int max;
    argaddr(0, &uaddr);
    802033aa:	fe840593          	addi	a1,s0,-24
    802033ae:	4501                	li	a0,0
    802033b0:	00000097          	auipc	ra,0x0
    802033b4:	fa6080e7          	jalr	-90(ra) # 80203356 <argaddr>
    argint(1, &max);
    802033b8:	fe440593          	addi	a1,s0,-28
    802033bc:	4505                	li	a0,1
    802033be:	00000097          	auipc	ra,0x0
    802033c2:	e3e080e7          	jalr	-450(ra) # 802031fc <argint>
    if (max <= 0) return -1;
    802033c6:	fe442783          	lw	a5,-28(s0)
    802033ca:	02f05663          	blez	a5,802033f6 <sys_procstat+0x54>
    if (max > NPROC) max = NPROC;
    802033ce:	04000713          	li	a4,64
    802033d2:	00f75663          	bge	a4,a5,802033de <sys_procstat+0x3c>
    802033d6:	04000793          	li	a5,64
    802033da:	fef42223          	sw	a5,-28(s0)
    return procstat(uaddr, max);
    802033de:	fe442583          	lw	a1,-28(s0)
    802033e2:	fe843503          	ld	a0,-24(s0)
    802033e6:	fffff097          	auipc	ra,0xfffff
    802033ea:	cc4080e7          	jalr	-828(ra) # 802020aa <procstat>
}
    802033ee:	60e2                	ld	ra,24(sp)
    802033f0:	6442                	ld	s0,16(sp)
    802033f2:	6105                	addi	sp,sp,32
    802033f4:	8082                	ret
    if (max <= 0) return -1;
    802033f6:	557d                	li	a0,-1
    802033f8:	bfdd                	j	802033ee <sys_procstat+0x4c>

00000000802033fa <fetchstr>:
{
    802033fa:	7179                	addi	sp,sp,-48
    802033fc:	f406                	sd	ra,40(sp)
    802033fe:	f022                	sd	s0,32(sp)
    80203400:	ec26                	sd	s1,24(sp)
    80203402:	e84a                	sd	s2,16(sp)
    80203404:	e44e                	sd	s3,8(sp)
    80203406:	1800                	addi	s0,sp,48
    80203408:	892a                	mv	s2,a0
    8020340a:	84ae                	mv	s1,a1
    8020340c:	89b2                	mv	s3,a2
    struct proc *p = myproc();
    8020340e:	ffffe097          	auipc	ra,0xffffe
    80203412:	2cc080e7          	jalr	716(ra) # 802016da <myproc>
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    80203416:	86ce                	mv	a3,s3
    80203418:	864a                	mv	a2,s2
    8020341a:	85a6                	mv	a1,s1
    8020341c:	6928                	ld	a0,80(a0)
    8020341e:	00000097          	auipc	ra,0x0
    80203422:	c10080e7          	jalr	-1008(ra) # 8020302e <copyinstr>
    80203426:	00054e63          	bltz	a0,80203442 <fetchstr+0x48>
    return strlen(buf);
    8020342a:	8526                	mv	a0,s1
    8020342c:	ffffd097          	auipc	ra,0xffffd
    80203430:	332080e7          	jalr	818(ra) # 8020075e <strlen>
}
    80203434:	70a2                	ld	ra,40(sp)
    80203436:	7402                	ld	s0,32(sp)
    80203438:	64e2                	ld	s1,24(sp)
    8020343a:	6942                	ld	s2,16(sp)
    8020343c:	69a2                	ld	s3,8(sp)
    8020343e:	6145                	addi	sp,sp,48
    80203440:	8082                	ret
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    80203442:	557d                	li	a0,-1
    80203444:	bfc5                	j	80203434 <fetchstr+0x3a>

0000000080203446 <argstr>:
{
    80203446:	7179                	addi	sp,sp,-48
    80203448:	f406                	sd	ra,40(sp)
    8020344a:	f022                	sd	s0,32(sp)
    8020344c:	ec26                	sd	s1,24(sp)
    8020344e:	e84a                	sd	s2,16(sp)
    80203450:	1800                	addi	s0,sp,48
    80203452:	84ae                	mv	s1,a1
    80203454:	8932                	mv	s2,a2
    argaddr(n, &addr);
    80203456:	fd840593          	addi	a1,s0,-40
    8020345a:	00000097          	auipc	ra,0x0
    8020345e:	efc080e7          	jalr	-260(ra) # 80203356 <argaddr>
    return fetchstr(addr, buf, max);
    80203462:	864a                	mv	a2,s2
    80203464:	85a6                	mv	a1,s1
    80203466:	fd843503          	ld	a0,-40(s0)
    8020346a:	00000097          	auipc	ra,0x0
    8020346e:	f90080e7          	jalr	-112(ra) # 802033fa <fetchstr>
}
    80203472:	70a2                	ld	ra,40(sp)
    80203474:	7402                	ld	s0,32(sp)
    80203476:	64e2                	ld	s1,24(sp)
    80203478:	6942                	ld	s2,16(sp)
    8020347a:	6145                	addi	sp,sp,48
    8020347c:	8082                	ret

000000008020347e <syscall>:
/* ---- dispatch ---- */

#include "syscalltab.h"     /* GENERATED: syscalls[] and syscall_names[] */

void syscall(void)
{
    8020347e:	1101                	addi	sp,sp,-32
    80203480:	ec06                	sd	ra,24(sp)
    80203482:	e822                	sd	s0,16(sp)
    80203484:	e426                	sd	s1,8(sp)
    80203486:	e04a                	sd	s2,0(sp)
    80203488:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    8020348a:	ffffe097          	auipc	ra,0xffffe
    8020348e:	250080e7          	jalr	592(ra) # 802016da <myproc>
    80203492:	84aa                	mv	s1,a0
    uint64 num = p->tf->a7;
    80203494:	05853903          	ld	s2,88(a0)
    80203498:	0a893683          	ld	a3,168(s2)

    /* Implementation note. */


    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    8020349c:	fff68713          	addi	a4,a3,-1 # 3fff <_entry-0x801fc001>
    802034a0:	47d9                	li	a5,22
    802034a2:	00e7ef63          	bltu	a5,a4,802034c0 <syscall+0x42>
    802034a6:	00369713          	slli	a4,a3,0x3
    802034aa:	00005797          	auipc	a5,0x5
    802034ae:	9d678793          	addi	a5,a5,-1578 # 80207e80 <syscalls>
    802034b2:	97ba                	add	a5,a5,a4
    802034b4:	639c                	ld	a5,0(a5)
    802034b6:	c789                	beqz	a5,802034c0 <syscall+0x42>
        p->tf->a0 = syscalls[num]();
    802034b8:	9782                	jalr	a5
    802034ba:	06a93823          	sd	a0,112(s2)
    802034be:	a839                	j	802034dc <syscall+0x5e>
    } else {
        printf("pid %d (%s): unknown syscall %d\n", p->pid, p->name, num);
    802034c0:	15848613          	addi	a2,s1,344
    802034c4:	588c                	lw	a1,48(s1)
    802034c6:	00004517          	auipc	a0,0x4
    802034ca:	43250513          	addi	a0,a0,1074 # 802078f8 <etext+0x8f8>
    802034ce:	ffffd097          	auipc	ra,0xffffd
    802034d2:	e7a080e7          	jalr	-390(ra) # 80200348 <printf>
        p->tf->a0 = -1;
    802034d6:	6cbc                	ld	a5,88(s1)
    802034d8:	577d                	li	a4,-1
    802034da:	fbb8                	sd	a4,112(a5)
    }
    (void)syscall_name;      /* Implementation note. */
}
    802034dc:	60e2                	ld	ra,24(sp)
    802034de:	6442                	ld	s0,16(sp)
    802034e0:	64a2                	ld	s1,8(sp)
    802034e2:	6902                	ld	s2,0(sp)
    802034e4:	6105                	addi	sp,sp,32
    802034e6:	8082                	ret

00000000802034e8 <argfd>:
#include "defs.h"
#include "fcntl.h"

/* Fetch the n'th arg as a file descriptor; return the struct file too. */
static int argfd(int n, int *pfd, struct file **pf)
{
    802034e8:	7179                	addi	sp,sp,-48
    802034ea:	f406                	sd	ra,40(sp)
    802034ec:	f022                	sd	s0,32(sp)
    802034ee:	ec26                	sd	s1,24(sp)
    802034f0:	e84a                	sd	s2,16(sp)
    802034f2:	1800                	addi	s0,sp,48
    802034f4:	892e                	mv	s2,a1
    802034f6:	84b2                	mv	s1,a2
    int fd;
    argint(n, &fd);
    802034f8:	fdc40593          	addi	a1,s0,-36
    802034fc:	00000097          	auipc	ra,0x0
    80203500:	d00080e7          	jalr	-768(ra) # 802031fc <argint>
    if (fd < 0 || fd >= NOFILE) return -1;
    80203504:	fdc42703          	lw	a4,-36(s0)
    80203508:	47bd                	li	a5,15
    8020350a:	02e7eb63          	bltu	a5,a4,80203540 <argfd+0x58>
    struct file *f = myproc()->ofile[fd];
    8020350e:	ffffe097          	auipc	ra,0xffffe
    80203512:	1cc080e7          	jalr	460(ra) # 802016da <myproc>
    80203516:	fdc42703          	lw	a4,-36(s0)
    8020351a:	01a70793          	addi	a5,a4,26
    8020351e:	078e                	slli	a5,a5,0x3
    80203520:	953e                	add	a0,a0,a5
    80203522:	611c                	ld	a5,0(a0)
    if (f == 0) return -1;
    80203524:	c385                	beqz	a5,80203544 <argfd+0x5c>
    if (pfd) *pfd = fd;
    80203526:	00090463          	beqz	s2,8020352e <argfd+0x46>
    8020352a:	00e92023          	sw	a4,0(s2)
    if (pf)  *pf  = f;
    return 0;
    8020352e:	4501                	li	a0,0
    if (pf)  *pf  = f;
    80203530:	c091                	beqz	s1,80203534 <argfd+0x4c>
    80203532:	e09c                	sd	a5,0(s1)
}
    80203534:	70a2                	ld	ra,40(sp)
    80203536:	7402                	ld	s0,32(sp)
    80203538:	64e2                	ld	s1,24(sp)
    8020353a:	6942                	ld	s2,16(sp)
    8020353c:	6145                	addi	sp,sp,48
    8020353e:	8082                	ret
    if (fd < 0 || fd >= NOFILE) return -1;
    80203540:	557d                	li	a0,-1
    80203542:	bfcd                	j	80203534 <argfd+0x4c>
    if (f == 0) return -1;
    80203544:	557d                	li	a0,-1
    80203546:	b7fd                	j	80203534 <argfd+0x4c>

0000000080203548 <fdalloc>:

/* Install f in the first free slot of the fd table. */
static int fdalloc(struct file *f)
{
    80203548:	1101                	addi	sp,sp,-32
    8020354a:	ec06                	sd	ra,24(sp)
    8020354c:	e822                	sd	s0,16(sp)
    8020354e:	e426                	sd	s1,8(sp)
    80203550:	1000                	addi	s0,sp,32
    80203552:	84aa                	mv	s1,a0
    struct proc *p = myproc();
    80203554:	ffffe097          	auipc	ra,0xffffe
    80203558:	186080e7          	jalr	390(ra) # 802016da <myproc>
    8020355c:	862a                	mv	a2,a0
    for (int fd = 0; fd < NOFILE; fd++) {
    8020355e:	0d050793          	addi	a5,a0,208
    80203562:	4501                	li	a0,0
    80203564:	46c1                	li	a3,16
        if (p->ofile[fd] == 0) {
    80203566:	6398                	ld	a4,0(a5)
    80203568:	cb19                	beqz	a4,8020357e <fdalloc+0x36>
    for (int fd = 0; fd < NOFILE; fd++) {
    8020356a:	2505                	addiw	a0,a0,1
    8020356c:	07a1                	addi	a5,a5,8
    8020356e:	fed51ce3          	bne	a0,a3,80203566 <fdalloc+0x1e>
            p->ofile[fd] = f;
            return fd;
        }
    }
    return -1;
    80203572:	557d                	li	a0,-1
}
    80203574:	60e2                	ld	ra,24(sp)
    80203576:	6442                	ld	s0,16(sp)
    80203578:	64a2                	ld	s1,8(sp)
    8020357a:	6105                	addi	sp,sp,32
    8020357c:	8082                	ret
            p->ofile[fd] = f;
    8020357e:	01a50793          	addi	a5,a0,26
    80203582:	078e                	slli	a5,a5,0x3
    80203584:	963e                	add	a2,a2,a5
    80203586:	e204                	sd	s1,0(a2)
            return fd;
    80203588:	b7f5                	j	80203574 <fdalloc+0x2c>

000000008020358a <create>:
}

/* Create path as type. Returns LOCKED inode, or 0. Handles the T_DIR case
 * (".", "..", parent nlink) and open(O_CREATE) racing an existing file. */
static struct inode *create(char *path, uint16 type, uint16 major, uint16 minor)
{
    8020358a:	711d                	addi	sp,sp,-96
    8020358c:	ec86                	sd	ra,88(sp)
    8020358e:	e8a2                	sd	s0,80(sp)
    80203590:	e4a6                	sd	s1,72(sp)
    80203592:	e0ca                	sd	s2,64(sp)
    80203594:	fc4e                	sd	s3,56(sp)
    80203596:	f456                	sd	s5,40(sp)
    80203598:	f05a                	sd	s6,32(sp)
    8020359a:	1080                	addi	s0,sp,96
    8020359c:	8b2e                	mv	s6,a1
    8020359e:	89b2                	mv	s3,a2
    802035a0:	8936                	mv	s2,a3
    char name[DIRSIZ];
    struct inode *dp = nameiparent(path, name);
    802035a2:	fa040593          	addi	a1,s0,-96
    802035a6:	00002097          	auipc	ra,0x2
    802035aa:	2cc080e7          	jalr	716(ra) # 80205872 <nameiparent>
    802035ae:	84aa                	mv	s1,a0
    if (dp == 0) return 0;
    802035b0:	16050263          	beqz	a0,80203714 <create+0x18a>
    ilock(dp);
    802035b4:	00002097          	auipc	ra,0x2
    802035b8:	a0c080e7          	jalr	-1524(ra) # 80204fc0 <ilock>

    struct inode *ip = dirlookup(dp, name, 0);
    802035bc:	4601                	li	a2,0
    802035be:	fa040593          	addi	a1,s0,-96
    802035c2:	8526                	mv	a0,s1
    802035c4:	00002097          	auipc	ra,0x2
    802035c8:	fc6080e7          	jalr	-58(ra) # 8020558a <dirlookup>
    802035cc:	8aaa                	mv	s5,a0
    if (ip != 0) {
    802035ce:	c929                	beqz	a0,80203620 <create+0x96>
        iunlockput(dp);
    802035d0:	8526                	mv	a0,s1
    802035d2:	00002097          	auipc	ra,0x2
    802035d6:	cca080e7          	jalr	-822(ra) # 8020529c <iunlockput>
        ilock(ip);
    802035da:	8556                	mv	a0,s5
    802035dc:	00002097          	auipc	ra,0x2
    802035e0:	9e4080e7          	jalr	-1564(ra) # 80204fc0 <ilock>
        if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEV))
    802035e4:	000b059b          	sext.w	a1,s6
    802035e8:	4789                	li	a5,2
    802035ea:	02f59463          	bne	a1,a5,80203612 <create+0x88>
    802035ee:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <uart+0xffffffff7fcc0014>
    802035f2:	37f9                	addiw	a5,a5,-2
    802035f4:	17c2                	slli	a5,a5,0x30
    802035f6:	93c1                	srli	a5,a5,0x30
    802035f8:	4705                	li	a4,1
    802035fa:	00f76c63          	bltu	a4,a5,80203612 <create+0x88>
    ip->nlink = 0;
    iupdate(ip);
    iunlockput(ip);
    iunlockput(dp);
    return 0;
}
    802035fe:	8556                	mv	a0,s5
    80203600:	60e6                	ld	ra,88(sp)
    80203602:	6446                	ld	s0,80(sp)
    80203604:	64a6                	ld	s1,72(sp)
    80203606:	6906                	ld	s2,64(sp)
    80203608:	79e2                	ld	s3,56(sp)
    8020360a:	7aa2                	ld	s5,40(sp)
    8020360c:	7b02                	ld	s6,32(sp)
    8020360e:	6125                	addi	sp,sp,96
    80203610:	8082                	ret
        iunlockput(ip);
    80203612:	8556                	mv	a0,s5
    80203614:	00002097          	auipc	ra,0x2
    80203618:	c88080e7          	jalr	-888(ra) # 8020529c <iunlockput>
        return 0;
    8020361c:	4a81                	li	s5,0
    8020361e:	b7c5                	j	802035fe <create+0x74>
    80203620:	f852                	sd	s4,48(sp)
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    80203622:	85da                	mv	a1,s6
    80203624:	4088                	lw	a0,0(s1)
    80203626:	00001097          	auipc	ra,0x1
    8020362a:	79e080e7          	jalr	1950(ra) # 80204dc4 <ialloc>
    8020362e:	8a2a                	mv	s4,a0
    80203630:	c921                	beqz	a0,80203680 <create+0xf6>
    ilock(ip);
    80203632:	00002097          	auipc	ra,0x2
    80203636:	98e080e7          	jalr	-1650(ra) # 80204fc0 <ilock>
    ip->major = major;
    8020363a:	053a1323          	sh	s3,70(s4)
    ip->minor = minor;
    8020363e:	052a1423          	sh	s2,72(s4)
    ip->nlink = 1;
    80203642:	4905                	li	s2,1
    80203644:	052a1523          	sh	s2,74(s4)
    iupdate(ip);
    80203648:	8552                	mv	a0,s4
    8020364a:	00002097          	auipc	ra,0x2
    8020364e:	8aa080e7          	jalr	-1878(ra) # 80204ef4 <iupdate>
    if (type == T_DIR) {
    80203652:	000b059b          	sext.w	a1,s6
    80203656:	03258d63          	beq	a1,s2,80203690 <create+0x106>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    8020365a:	004a2603          	lw	a2,4(s4)
    8020365e:	fa040593          	addi	a1,s0,-96
    80203662:	8526                	mv	a0,s1
    80203664:	00002097          	auipc	ra,0x2
    80203668:	136080e7          	jalr	310(ra) # 8020579a <dirlink>
    8020366c:	08054163          	bltz	a0,802036ee <create+0x164>
    iunlockput(dp);
    80203670:	8526                	mv	a0,s1
    80203672:	00002097          	auipc	ra,0x2
    80203676:	c2a080e7          	jalr	-982(ra) # 8020529c <iunlockput>
    return ip;
    8020367a:	8ad2                	mv	s5,s4
    8020367c:	7a42                	ld	s4,48(sp)
    8020367e:	b741                	j	802035fe <create+0x74>
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    80203680:	8526                	mv	a0,s1
    80203682:	00002097          	auipc	ra,0x2
    80203686:	c1a080e7          	jalr	-998(ra) # 8020529c <iunlockput>
    8020368a:	8ad2                	mv	s5,s4
    8020368c:	7a42                	ld	s4,48(sp)
    8020368e:	bf85                	j	802035fe <create+0x74>
        if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80203690:	004a2603          	lw	a2,4(s4)
    80203694:	00004597          	auipc	a1,0x4
    80203698:	28c58593          	addi	a1,a1,652 # 80207920 <etext+0x920>
    8020369c:	8552                	mv	a0,s4
    8020369e:	00002097          	auipc	ra,0x2
    802036a2:	0fc080e7          	jalr	252(ra) # 8020579a <dirlink>
    802036a6:	04054463          	bltz	a0,802036ee <create+0x164>
    802036aa:	40d0                	lw	a2,4(s1)
    802036ac:	00004597          	auipc	a1,0x4
    802036b0:	27c58593          	addi	a1,a1,636 # 80207928 <etext+0x928>
    802036b4:	8552                	mv	a0,s4
    802036b6:	00002097          	auipc	ra,0x2
    802036ba:	0e4080e7          	jalr	228(ra) # 8020579a <dirlink>
    802036be:	02054863          	bltz	a0,802036ee <create+0x164>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    802036c2:	004a2603          	lw	a2,4(s4)
    802036c6:	fa040593          	addi	a1,s0,-96
    802036ca:	8526                	mv	a0,s1
    802036cc:	00002097          	auipc	ra,0x2
    802036d0:	0ce080e7          	jalr	206(ra) # 8020579a <dirlink>
    802036d4:	00054d63          	bltz	a0,802036ee <create+0x164>
        dp->nlink++;
    802036d8:	04a4d783          	lhu	a5,74(s1)
    802036dc:	2785                	addiw	a5,a5,1
    802036de:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    802036e2:	8526                	mv	a0,s1
    802036e4:	00002097          	auipc	ra,0x2
    802036e8:	810080e7          	jalr	-2032(ra) # 80204ef4 <iupdate>
    802036ec:	b751                	j	80203670 <create+0xe6>
    ip->nlink = 0;
    802036ee:	040a1523          	sh	zero,74(s4)
    iupdate(ip);
    802036f2:	8552                	mv	a0,s4
    802036f4:	00002097          	auipc	ra,0x2
    802036f8:	800080e7          	jalr	-2048(ra) # 80204ef4 <iupdate>
    iunlockput(ip);
    802036fc:	8552                	mv	a0,s4
    802036fe:	00002097          	auipc	ra,0x2
    80203702:	b9e080e7          	jalr	-1122(ra) # 8020529c <iunlockput>
    iunlockput(dp);
    80203706:	8526                	mv	a0,s1
    80203708:	00002097          	auipc	ra,0x2
    8020370c:	b94080e7          	jalr	-1132(ra) # 8020529c <iunlockput>
    return 0;
    80203710:	7a42                	ld	s4,48(sp)
    80203712:	b5f5                	j	802035fe <create+0x74>
    if (dp == 0) return 0;
    80203714:	8aaa                	mv	s5,a0
    80203716:	b5e5                	j	802035fe <create+0x74>

0000000080203718 <sys_dup>:
{
    80203718:	7179                	addi	sp,sp,-48
    8020371a:	f406                	sd	ra,40(sp)
    8020371c:	f022                	sd	s0,32(sp)
    8020371e:	1800                	addi	s0,sp,48
    if (argfd(0, 0, &f) < 0) return -1;
    80203720:	fd840613          	addi	a2,s0,-40
    80203724:	4581                	li	a1,0
    80203726:	4501                	li	a0,0
    80203728:	00000097          	auipc	ra,0x0
    8020372c:	dc0080e7          	jalr	-576(ra) # 802034e8 <argfd>
    80203730:	57fd                	li	a5,-1
    80203732:	02054763          	bltz	a0,80203760 <sys_dup+0x48>
    80203736:	ec26                	sd	s1,24(sp)
    80203738:	e84a                	sd	s2,16(sp)
    int fd = fdalloc(f);
    8020373a:	fd843903          	ld	s2,-40(s0)
    8020373e:	854a                	mv	a0,s2
    80203740:	00000097          	auipc	ra,0x0
    80203744:	e08080e7          	jalr	-504(ra) # 80203548 <fdalloc>
    80203748:	84aa                	mv	s1,a0
    if (fd < 0) return -1;
    8020374a:	57fd                	li	a5,-1
    8020374c:	00054f63          	bltz	a0,8020376a <sys_dup+0x52>
    filedup(f);
    80203750:	854a                	mv	a0,s2
    80203752:	00002097          	auipc	ra,0x2
    80203756:	1ce080e7          	jalr	462(ra) # 80205920 <filedup>
    return fd;
    8020375a:	87a6                	mv	a5,s1
    8020375c:	64e2                	ld	s1,24(sp)
    8020375e:	6942                	ld	s2,16(sp)
}
    80203760:	853e                	mv	a0,a5
    80203762:	70a2                	ld	ra,40(sp)
    80203764:	7402                	ld	s0,32(sp)
    80203766:	6145                	addi	sp,sp,48
    80203768:	8082                	ret
    8020376a:	64e2                	ld	s1,24(sp)
    8020376c:	6942                	ld	s2,16(sp)
    8020376e:	bfcd                	j	80203760 <sys_dup+0x48>

0000000080203770 <sys_read>:
{
    80203770:	7179                	addi	sp,sp,-48
    80203772:	f406                	sd	ra,40(sp)
    80203774:	f022                	sd	s0,32(sp)
    80203776:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    80203778:	fd840593          	addi	a1,s0,-40
    8020377c:	4505                	li	a0,1
    8020377e:	00000097          	auipc	ra,0x0
    80203782:	bd8080e7          	jalr	-1064(ra) # 80203356 <argaddr>
    argint(2, &n);
    80203786:	fe440593          	addi	a1,s0,-28
    8020378a:	4509                	li	a0,2
    8020378c:	00000097          	auipc	ra,0x0
    80203790:	a70080e7          	jalr	-1424(ra) # 802031fc <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203794:	fe840613          	addi	a2,s0,-24
    80203798:	4581                	li	a1,0
    8020379a:	4501                	li	a0,0
    8020379c:	00000097          	auipc	ra,0x0
    802037a0:	d4c080e7          	jalr	-692(ra) # 802034e8 <argfd>
    802037a4:	02054363          	bltz	a0,802037ca <sys_read+0x5a>
    802037a8:	fe442603          	lw	a2,-28(s0)
    802037ac:	557d                	li	a0,-1
    802037ae:	00064a63          	bltz	a2,802037c2 <sys_read+0x52>
    return fileread(f, p, n);
    802037b2:	fd843583          	ld	a1,-40(s0)
    802037b6:	fe843503          	ld	a0,-24(s0)
    802037ba:	00002097          	auipc	ra,0x2
    802037be:	2f4080e7          	jalr	756(ra) # 80205aae <fileread>
}
    802037c2:	70a2                	ld	ra,40(sp)
    802037c4:	7402                	ld	s0,32(sp)
    802037c6:	6145                	addi	sp,sp,48
    802037c8:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    802037ca:	557d                	li	a0,-1
    802037cc:	bfdd                	j	802037c2 <sys_read+0x52>

00000000802037ce <sys_write>:
{
    802037ce:	7179                	addi	sp,sp,-48
    802037d0:	f406                	sd	ra,40(sp)
    802037d2:	f022                	sd	s0,32(sp)
    802037d4:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    802037d6:	fd840593          	addi	a1,s0,-40
    802037da:	4505                	li	a0,1
    802037dc:	00000097          	auipc	ra,0x0
    802037e0:	b7a080e7          	jalr	-1158(ra) # 80203356 <argaddr>
    argint(2, &n);
    802037e4:	fe440593          	addi	a1,s0,-28
    802037e8:	4509                	li	a0,2
    802037ea:	00000097          	auipc	ra,0x0
    802037ee:	a12080e7          	jalr	-1518(ra) # 802031fc <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    802037f2:	fe840613          	addi	a2,s0,-24
    802037f6:	4581                	li	a1,0
    802037f8:	4501                	li	a0,0
    802037fa:	00000097          	auipc	ra,0x0
    802037fe:	cee080e7          	jalr	-786(ra) # 802034e8 <argfd>
    80203802:	02054363          	bltz	a0,80203828 <sys_write+0x5a>
    80203806:	fe442603          	lw	a2,-28(s0)
    8020380a:	557d                	li	a0,-1
    8020380c:	00064a63          	bltz	a2,80203820 <sys_write+0x52>
    return filewrite(f, p, n);
    80203810:	fd843583          	ld	a1,-40(s0)
    80203814:	fe843503          	ld	a0,-24(s0)
    80203818:	00002097          	auipc	ra,0x2
    8020381c:	36a080e7          	jalr	874(ra) # 80205b82 <filewrite>
}
    80203820:	70a2                	ld	ra,40(sp)
    80203822:	7402                	ld	s0,32(sp)
    80203824:	6145                	addi	sp,sp,48
    80203826:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203828:	557d                	li	a0,-1
    8020382a:	bfdd                	j	80203820 <sys_write+0x52>

000000008020382c <sys_close>:
{
    8020382c:	1101                	addi	sp,sp,-32
    8020382e:	ec06                	sd	ra,24(sp)
    80203830:	e822                	sd	s0,16(sp)
    80203832:	1000                	addi	s0,sp,32
    if (argfd(0, &fd, &f) < 0) return -1;
    80203834:	fe040613          	addi	a2,s0,-32
    80203838:	fec40593          	addi	a1,s0,-20
    8020383c:	4501                	li	a0,0
    8020383e:	00000097          	auipc	ra,0x0
    80203842:	caa080e7          	jalr	-854(ra) # 802034e8 <argfd>
    80203846:	57fd                	li	a5,-1
    80203848:	02054463          	bltz	a0,80203870 <sys_close+0x44>
    myproc()->ofile[fd] = 0;
    8020384c:	ffffe097          	auipc	ra,0xffffe
    80203850:	e8e080e7          	jalr	-370(ra) # 802016da <myproc>
    80203854:	fec42783          	lw	a5,-20(s0)
    80203858:	07e9                	addi	a5,a5,26
    8020385a:	078e                	slli	a5,a5,0x3
    8020385c:	953e                	add	a0,a0,a5
    8020385e:	00053023          	sd	zero,0(a0)
    fileclose(f);
    80203862:	fe043503          	ld	a0,-32(s0)
    80203866:	00002097          	auipc	ra,0x2
    8020386a:	10c080e7          	jalr	268(ra) # 80205972 <fileclose>
    return 0;
    8020386e:	4781                	li	a5,0
}
    80203870:	853e                	mv	a0,a5
    80203872:	60e2                	ld	ra,24(sp)
    80203874:	6442                	ld	s0,16(sp)
    80203876:	6105                	addi	sp,sp,32
    80203878:	8082                	ret

000000008020387a <sys_fstat>:
{
    8020387a:	1101                	addi	sp,sp,-32
    8020387c:	ec06                	sd	ra,24(sp)
    8020387e:	e822                	sd	s0,16(sp)
    80203880:	1000                	addi	s0,sp,32
    argaddr(1, &st);
    80203882:	fe040593          	addi	a1,s0,-32
    80203886:	4505                	li	a0,1
    80203888:	00000097          	auipc	ra,0x0
    8020388c:	ace080e7          	jalr	-1330(ra) # 80203356 <argaddr>
    if (argfd(0, 0, &f) < 0) return -1;
    80203890:	fe840613          	addi	a2,s0,-24
    80203894:	4581                	li	a1,0
    80203896:	4501                	li	a0,0
    80203898:	00000097          	auipc	ra,0x0
    8020389c:	c50080e7          	jalr	-944(ra) # 802034e8 <argfd>
    802038a0:	87aa                	mv	a5,a0
    802038a2:	557d                	li	a0,-1
    802038a4:	0007ca63          	bltz	a5,802038b8 <sys_fstat+0x3e>
    return filestat(f, st);
    802038a8:	fe043583          	ld	a1,-32(s0)
    802038ac:	fe843503          	ld	a0,-24(s0)
    802038b0:	00002097          	auipc	ra,0x2
    802038b4:	194080e7          	jalr	404(ra) # 80205a44 <filestat>
}
    802038b8:	60e2                	ld	ra,24(sp)
    802038ba:	6442                	ld	s0,16(sp)
    802038bc:	6105                	addi	sp,sp,32
    802038be:	8082                	ret

00000000802038c0 <sys_link>:
{
    802038c0:	7129                	addi	sp,sp,-320
    802038c2:	fe06                	sd	ra,312(sp)
    802038c4:	fa22                	sd	s0,304(sp)
    802038c6:	0280                	addi	s0,sp,320
    if (argstr(0, oldp, MAXPATH) < 0 || argstr(1, newp, MAXPATH) < 0) return -1;
    802038c8:	08000613          	li	a2,128
    802038cc:	ec040593          	addi	a1,s0,-320
    802038d0:	4501                	li	a0,0
    802038d2:	00000097          	auipc	ra,0x0
    802038d6:	b74080e7          	jalr	-1164(ra) # 80203446 <argstr>
    802038da:	57fd                	li	a5,-1
    802038dc:	0e054f63          	bltz	a0,802039da <sys_link+0x11a>
    802038e0:	08000613          	li	a2,128
    802038e4:	f4040593          	addi	a1,s0,-192
    802038e8:	4505                	li	a0,1
    802038ea:	00000097          	auipc	ra,0x0
    802038ee:	b5c080e7          	jalr	-1188(ra) # 80203446 <argstr>
    802038f2:	57fd                	li	a5,-1
    802038f4:	0e054363          	bltz	a0,802039da <sys_link+0x11a>
    802038f8:	f626                	sd	s1,296(sp)
    struct inode *ip = namei(oldp);
    802038fa:	ec040513          	addi	a0,s0,-320
    802038fe:	00002097          	auipc	ra,0x2
    80203902:	f56080e7          	jalr	-170(ra) # 80205854 <namei>
    80203906:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80203908:	cd71                	beqz	a0,802039e4 <sys_link+0x124>
    ilock(ip);
    8020390a:	00001097          	auipc	ra,0x1
    8020390e:	6b6080e7          	jalr	1718(ra) # 80204fc0 <ilock>
    if (ip->type == T_DIR) {          /* hard links to dirs make cycles */
    80203912:	0444d703          	lhu	a4,68(s1)
    80203916:	4785                	li	a5,1
    80203918:	06f70d63          	beq	a4,a5,80203992 <sys_link+0xd2>
    8020391c:	f24a                	sd	s2,288(sp)
    ip->nlink++;
    8020391e:	04a4d783          	lhu	a5,74(s1)
    80203922:	2785                	addiw	a5,a5,1
    80203924:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80203928:	8526                	mv	a0,s1
    8020392a:	00001097          	auipc	ra,0x1
    8020392e:	5ca080e7          	jalr	1482(ra) # 80204ef4 <iupdate>
    iunlock(ip);
    80203932:	8526                	mv	a0,s1
    80203934:	00001097          	auipc	ra,0x1
    80203938:	752080e7          	jalr	1874(ra) # 80205086 <iunlock>
    struct inode *dp = nameiparent(newp, name);
    8020393c:	fc040593          	addi	a1,s0,-64
    80203940:	f4040513          	addi	a0,s0,-192
    80203944:	00002097          	auipc	ra,0x2
    80203948:	f2e080e7          	jalr	-210(ra) # 80205872 <nameiparent>
    8020394c:	892a                	mv	s2,a0
    if (dp == 0) goto bad;
    8020394e:	cd39                	beqz	a0,802039ac <sys_link+0xec>
    ilock(dp);
    80203950:	00001097          	auipc	ra,0x1
    80203954:	670080e7          	jalr	1648(ra) # 80204fc0 <ilock>
    if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80203958:	00092703          	lw	a4,0(s2)
    8020395c:	409c                	lw	a5,0(s1)
    8020395e:	04f71263          	bne	a4,a5,802039a2 <sys_link+0xe2>
    80203962:	40d0                	lw	a2,4(s1)
    80203964:	fc040593          	addi	a1,s0,-64
    80203968:	854a                	mv	a0,s2
    8020396a:	00002097          	auipc	ra,0x2
    8020396e:	e30080e7          	jalr	-464(ra) # 8020579a <dirlink>
    80203972:	02054863          	bltz	a0,802039a2 <sys_link+0xe2>
    iunlockput(dp);
    80203976:	854a                	mv	a0,s2
    80203978:	00002097          	auipc	ra,0x2
    8020397c:	924080e7          	jalr	-1756(ra) # 8020529c <iunlockput>
    iput(ip);
    80203980:	8526                	mv	a0,s1
    80203982:	00001097          	auipc	ra,0x1
    80203986:	7fc080e7          	jalr	2044(ra) # 8020517e <iput>
    return 0;
    8020398a:	4781                	li	a5,0
    8020398c:	74b2                	ld	s1,296(sp)
    8020398e:	7912                	ld	s2,288(sp)
    80203990:	a0a9                	j	802039da <sys_link+0x11a>
        iunlockput(ip);
    80203992:	8526                	mv	a0,s1
    80203994:	00002097          	auipc	ra,0x2
    80203998:	908080e7          	jalr	-1784(ra) # 8020529c <iunlockput>
        return -1;
    8020399c:	57fd                	li	a5,-1
    8020399e:	74b2                	ld	s1,296(sp)
    802039a0:	a82d                	j	802039da <sys_link+0x11a>
        iunlockput(dp);
    802039a2:	854a                	mv	a0,s2
    802039a4:	00002097          	auipc	ra,0x2
    802039a8:	8f8080e7          	jalr	-1800(ra) # 8020529c <iunlockput>
    ilock(ip);
    802039ac:	8526                	mv	a0,s1
    802039ae:	00001097          	auipc	ra,0x1
    802039b2:	612080e7          	jalr	1554(ra) # 80204fc0 <ilock>
    ip->nlink--;
    802039b6:	04a4d783          	lhu	a5,74(s1)
    802039ba:	37fd                	addiw	a5,a5,-1
    802039bc:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    802039c0:	8526                	mv	a0,s1
    802039c2:	00001097          	auipc	ra,0x1
    802039c6:	532080e7          	jalr	1330(ra) # 80204ef4 <iupdate>
    iunlockput(ip);
    802039ca:	8526                	mv	a0,s1
    802039cc:	00002097          	auipc	ra,0x2
    802039d0:	8d0080e7          	jalr	-1840(ra) # 8020529c <iunlockput>
    return -1;
    802039d4:	57fd                	li	a5,-1
    802039d6:	74b2                	ld	s1,296(sp)
    802039d8:	7912                	ld	s2,288(sp)
}
    802039da:	853e                	mv	a0,a5
    802039dc:	70f2                	ld	ra,312(sp)
    802039de:	7452                	ld	s0,304(sp)
    802039e0:	6131                	addi	sp,sp,320
    802039e2:	8082                	ret
    if (ip == 0) return -1;
    802039e4:	57fd                	li	a5,-1
    802039e6:	74b2                	ld	s1,296(sp)
    802039e8:	bfcd                	j	802039da <sys_link+0x11a>

00000000802039ea <sys_unlink>:
{
    802039ea:	712d                	addi	sp,sp,-288
    802039ec:	ee06                	sd	ra,280(sp)
    802039ee:	ea22                	sd	s0,272(sp)
    802039f0:	1200                	addi	s0,sp,288
    if (argstr(0, path, MAXPATH) < 0) return -1;
    802039f2:	08000613          	li	a2,128
    802039f6:	f3040593          	addi	a1,s0,-208
    802039fa:	4501                	li	a0,0
    802039fc:	00000097          	auipc	ra,0x0
    80203a00:	a4a080e7          	jalr	-1462(ra) # 80203446 <argstr>
    80203a04:	18054d63          	bltz	a0,80203b9e <sys_unlink+0x1b4>
    80203a08:	e626                	sd	s1,264(sp)
    struct inode *dp = nameiparent(path, name);
    80203a0a:	fb040593          	addi	a1,s0,-80
    80203a0e:	f3040513          	addi	a0,s0,-208
    80203a12:	00002097          	auipc	ra,0x2
    80203a16:	e60080e7          	jalr	-416(ra) # 80205872 <nameiparent>
    80203a1a:	84aa                	mv	s1,a0
    if (dp == 0) return -1;
    80203a1c:	18050363          	beqz	a0,80203ba2 <sys_unlink+0x1b8>
    ilock(dp);
    80203a20:	00001097          	auipc	ra,0x1
    80203a24:	5a0080e7          	jalr	1440(ra) # 80204fc0 <ilock>
    if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0) goto bad;
    80203a28:	00004597          	auipc	a1,0x4
    80203a2c:	ef858593          	addi	a1,a1,-264 # 80207920 <etext+0x920>
    80203a30:	fb040513          	addi	a0,s0,-80
    80203a34:	00002097          	auipc	ra,0x2
    80203a38:	b3c080e7          	jalr	-1220(ra) # 80205570 <namecmp>
    80203a3c:	14050663          	beqz	a0,80203b88 <sys_unlink+0x19e>
    80203a40:	00004597          	auipc	a1,0x4
    80203a44:	ee858593          	addi	a1,a1,-280 # 80207928 <etext+0x928>
    80203a48:	fb040513          	addi	a0,s0,-80
    80203a4c:	00002097          	auipc	ra,0x2
    80203a50:	b24080e7          	jalr	-1244(ra) # 80205570 <namecmp>
    80203a54:	12050a63          	beqz	a0,80203b88 <sys_unlink+0x19e>
    80203a58:	e24a                	sd	s2,256(sp)
    struct inode *ip = dirlookup(dp, name, &off);
    80203a5a:	f2c40613          	addi	a2,s0,-212
    80203a5e:	fb040593          	addi	a1,s0,-80
    80203a62:	8526                	mv	a0,s1
    80203a64:	00002097          	auipc	ra,0x2
    80203a68:	b26080e7          	jalr	-1242(ra) # 8020558a <dirlookup>
    80203a6c:	892a                	mv	s2,a0
    if (ip == 0) goto bad;
    80203a6e:	10050c63          	beqz	a0,80203b86 <sys_unlink+0x19c>
    ilock(ip);                        /* lock order: parent, then child */
    80203a72:	00001097          	auipc	ra,0x1
    80203a76:	54e080e7          	jalr	1358(ra) # 80204fc0 <ilock>
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203a7a:	04a95783          	lhu	a5,74(s2)
    80203a7e:	cfa5                	beqz	a5,80203af6 <sys_unlink+0x10c>
    if (ip->type == T_DIR && !isdirempty(ip)) {
    80203a80:	04495703          	lhu	a4,68(s2)
    80203a84:	4785                	li	a5,1
    80203a86:	08f70163          	beq	a4,a5,80203b08 <sys_unlink+0x11e>
    memset(&de, 0, sizeof(de));
    80203a8a:	02000613          	li	a2,32
    80203a8e:	4581                	li	a1,0
    80203a90:	f0840513          	addi	a0,s0,-248
    80203a94:	ffffd097          	auipc	ra,0xffffd
    80203a98:	bcc080e7          	jalr	-1076(ra) # 80200660 <memset>
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203a9c:	02000713          	li	a4,32
    80203aa0:	f2c42683          	lw	a3,-212(s0)
    80203aa4:	f0840613          	addi	a2,s0,-248
    80203aa8:	4581                	li	a1,0
    80203aaa:	8526                	mv	a0,s1
    80203aac:	00002097          	auipc	ra,0x2
    80203ab0:	976080e7          	jalr	-1674(ra) # 80205422 <writei>
    80203ab4:	02000793          	li	a5,32
    80203ab8:	0af51363          	bne	a0,a5,80203b5e <sys_unlink+0x174>
    if (ip->type == T_DIR) {
    80203abc:	04495703          	lhu	a4,68(s2)
    80203ac0:	4785                	li	a5,1
    80203ac2:	0af70763          	beq	a4,a5,80203b70 <sys_unlink+0x186>
    iunlockput(dp);
    80203ac6:	8526                	mv	a0,s1
    80203ac8:	00001097          	auipc	ra,0x1
    80203acc:	7d4080e7          	jalr	2004(ra) # 8020529c <iunlockput>
    ip->nlink--;
    80203ad0:	04a95783          	lhu	a5,74(s2)
    80203ad4:	37fd                	addiw	a5,a5,-1
    80203ad6:	04f91523          	sh	a5,74(s2)
    iupdate(ip);
    80203ada:	854a                	mv	a0,s2
    80203adc:	00001097          	auipc	ra,0x1
    80203ae0:	418080e7          	jalr	1048(ra) # 80204ef4 <iupdate>
    iunlockput(ip);                   /* data freed in iput if last ref+link */
    80203ae4:	854a                	mv	a0,s2
    80203ae6:	00001097          	auipc	ra,0x1
    80203aea:	7b6080e7          	jalr	1974(ra) # 8020529c <iunlockput>
    return 0;
    80203aee:	4501                	li	a0,0
    80203af0:	64b2                	ld	s1,264(sp)
    80203af2:	6912                	ld	s2,256(sp)
    80203af4:	a04d                	j	80203b96 <sys_unlink+0x1ac>
    80203af6:	fdce                	sd	s3,248(sp)
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203af8:	00004517          	auipc	a0,0x4
    80203afc:	e3850513          	addi	a0,a0,-456 # 80207930 <etext+0x930>
    80203b00:	ffffd097          	auipc	ra,0xffffd
    80203b04:	aba080e7          	jalr	-1350(ra) # 802005ba <panic>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203b08:	04c92703          	lw	a4,76(s2)
    80203b0c:	04000793          	li	a5,64
    80203b10:	f6e7fde3          	bgeu	a5,a4,80203a8a <sys_unlink+0xa0>
    80203b14:	fdce                	sd	s3,248(sp)
    80203b16:	04000993          	li	s3,64
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203b1a:	02000713          	li	a4,32
    80203b1e:	86ce                	mv	a3,s3
    80203b20:	ee840613          	addi	a2,s0,-280
    80203b24:	4581                	li	a1,0
    80203b26:	854a                	mv	a0,s2
    80203b28:	00001097          	auipc	ra,0x1
    80203b2c:	7c6080e7          	jalr	1990(ra) # 802052ee <readi>
    80203b30:	02000793          	li	a5,32
    80203b34:	00f51d63          	bne	a0,a5,80203b4e <sys_unlink+0x164>
        if (de.inum != 0) return 0;
    80203b38:	ee842783          	lw	a5,-280(s0)
    80203b3c:	e7b5                	bnez	a5,80203ba8 <sys_unlink+0x1be>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203b3e:	0209899b          	addiw	s3,s3,32
    80203b42:	04c92783          	lw	a5,76(s2)
    80203b46:	fcf9eae3          	bltu	s3,a5,80203b1a <sys_unlink+0x130>
    80203b4a:	79ee                	ld	s3,248(sp)
    80203b4c:	bf3d                	j	80203a8a <sys_unlink+0xa0>
            panic("isdirempty: short read");
    80203b4e:	00004517          	auipc	a0,0x4
    80203b52:	dfa50513          	addi	a0,a0,-518 # 80207948 <etext+0x948>
    80203b56:	ffffd097          	auipc	ra,0xffffd
    80203b5a:	a64080e7          	jalr	-1436(ra) # 802005ba <panic>
    80203b5e:	fdce                	sd	s3,248(sp)
        panic("unlink: writei");
    80203b60:	00004517          	auipc	a0,0x4
    80203b64:	e0050513          	addi	a0,a0,-512 # 80207960 <etext+0x960>
    80203b68:	ffffd097          	auipc	ra,0xffffd
    80203b6c:	a52080e7          	jalr	-1454(ra) # 802005ba <panic>
        dp->nlink--;                  /* the child's ".." no longer counts */
    80203b70:	04a4d783          	lhu	a5,74(s1)
    80203b74:	37fd                	addiw	a5,a5,-1
    80203b76:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80203b7a:	8526                	mv	a0,s1
    80203b7c:	00001097          	auipc	ra,0x1
    80203b80:	378080e7          	jalr	888(ra) # 80204ef4 <iupdate>
    80203b84:	b789                	j	80203ac6 <sys_unlink+0xdc>
    80203b86:	6912                	ld	s2,256(sp)
    iunlockput(dp);
    80203b88:	8526                	mv	a0,s1
    80203b8a:	00001097          	auipc	ra,0x1
    80203b8e:	712080e7          	jalr	1810(ra) # 8020529c <iunlockput>
    return -1;
    80203b92:	557d                	li	a0,-1
    80203b94:	64b2                	ld	s1,264(sp)
}
    80203b96:	60f2                	ld	ra,280(sp)
    80203b98:	6452                	ld	s0,272(sp)
    80203b9a:	6115                	addi	sp,sp,288
    80203b9c:	8082                	ret
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203b9e:	557d                	li	a0,-1
    80203ba0:	bfdd                	j	80203b96 <sys_unlink+0x1ac>
    if (dp == 0) return -1;
    80203ba2:	557d                	li	a0,-1
    80203ba4:	64b2                	ld	s1,264(sp)
    80203ba6:	bfc5                	j	80203b96 <sys_unlink+0x1ac>
        iunlockput(ip);
    80203ba8:	854a                	mv	a0,s2
    80203baa:	00001097          	auipc	ra,0x1
    80203bae:	6f2080e7          	jalr	1778(ra) # 8020529c <iunlockput>
        goto bad;
    80203bb2:	6912                	ld	s2,256(sp)
    80203bb4:	79ee                	ld	s3,248(sp)
    80203bb6:	bfc9                	j	80203b88 <sys_unlink+0x19e>

0000000080203bb8 <sys_open>:

uint64 sys_open(void)
{
    80203bb8:	7131                	addi	sp,sp,-192
    80203bba:	fd06                	sd	ra,184(sp)
    80203bbc:	f922                	sd	s0,176(sp)
    80203bbe:	0180                	addi	s0,sp,192
    char path[MAXPATH];
    int omode;
    argint(1, &omode);
    80203bc0:	f4c40593          	addi	a1,s0,-180
    80203bc4:	4505                	li	a0,1
    80203bc6:	fffff097          	auipc	ra,0xfffff
    80203bca:	636080e7          	jalr	1590(ra) # 802031fc <argint>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203bce:	08000613          	li	a2,128
    80203bd2:	f5040593          	addi	a1,s0,-176
    80203bd6:	4501                	li	a0,0
    80203bd8:	00000097          	auipc	ra,0x0
    80203bdc:	86e080e7          	jalr	-1938(ra) # 80203446 <argstr>
    80203be0:	12054b63          	bltz	a0,80203d16 <sys_open+0x15e>
    80203be4:	f526                	sd	s1,168(sp)

    struct inode *ip;
    if (omode & O_CREATE) {
    80203be6:	f4c42783          	lw	a5,-180(s0)
    80203bea:	2007f793          	andi	a5,a5,512
    80203bee:	c7c5                	beqz	a5,80203c96 <sys_open+0xde>
        ip = create(path, T_FILE, 0, 0);
    80203bf0:	4681                	li	a3,0
    80203bf2:	4601                	li	a2,0
    80203bf4:	4589                	li	a1,2
    80203bf6:	f5040513          	addi	a0,s0,-176
    80203bfa:	00000097          	auipc	ra,0x0
    80203bfe:	990080e7          	jalr	-1648(ra) # 8020358a <create>
    80203c02:	84aa                	mv	s1,a0
        if (ip == 0) return -1;
    80203c04:	10050b63          	beqz	a0,80203d1a <sys_open+0x162>
        if (ip->type == T_DIR && omode != O_RDONLY) {
            iunlockput(ip);
            return -1;
        }
    }
    if (ip->type == T_DEV && (ip->major < 0 || ip->major >= NDEV)) {
    80203c08:	0444d703          	lhu	a4,68(s1)
    80203c0c:	478d                	li	a5,3
    80203c0e:	00f71763          	bne	a4,a5,80203c1c <sys_open+0x64>
    80203c12:	0464d703          	lhu	a4,70(s1)
    80203c16:	47a5                	li	a5,9
    80203c18:	0ae7eb63          	bltu	a5,a4,80203cce <sys_open+0x116>
    80203c1c:	f14a                	sd	s2,160(sp)
        iunlockput(ip);
        return -1;
    }

    struct file *f = filealloc();
    80203c1e:	00002097          	auipc	ra,0x2
    80203c22:	c98080e7          	jalr	-872(ra) # 802058b6 <filealloc>
    80203c26:	892a                	mv	s2,a0
    int fd;
    if (f == 0 || (fd = fdalloc(f)) < 0) {
    80203c28:	c169                	beqz	a0,80203cea <sys_open+0x132>
    80203c2a:	ed4e                	sd	s3,152(sp)
    80203c2c:	00000097          	auipc	ra,0x0
    80203c30:	91c080e7          	jalr	-1764(ra) # 80203548 <fdalloc>
    80203c34:	89aa                	mv	s3,a0
    80203c36:	0a054463          	bltz	a0,80203cde <sys_open+0x126>
        if (f) fileclose(f);
        iunlockput(ip);
        return -1;
    }

    if (ip->type == T_DEV) {
    80203c3a:	0444d703          	lhu	a4,68(s1)
    80203c3e:	478d                	li	a5,3
    80203c40:	0af70e63          	beq	a4,a5,80203cfc <sys_open+0x144>
        f->type  = FD_DEVICE;
        f->major = ip->major;
    } else {
        f->type = FD_INODE;
    80203c44:	4789                	li	a5,2
    80203c46:	00f92023          	sw	a5,0(s2)
        f->off  = 0;
    80203c4a:	02092023          	sw	zero,32(s2)
    }
    f->ip       = ip;
    80203c4e:	00993c23          	sd	s1,24(s2)
    f->readable = !(omode & O_WRONLY);
    80203c52:	f4c42783          	lw	a5,-180(s0)
    80203c56:	0017c713          	xori	a4,a5,1
    80203c5a:	8b05                	andi	a4,a4,1
    80203c5c:	00e90423          	sb	a4,8(s2)
    f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80203c60:	0037f713          	andi	a4,a5,3
    80203c64:	00e03733          	snez	a4,a4
    80203c68:	00e904a3          	sb	a4,9(s2)

    if ((omode & O_TRUNC) && ip->type == T_FILE)
    80203c6c:	4007f793          	andi	a5,a5,1024
    80203c70:	c791                	beqz	a5,80203c7c <sys_open+0xc4>
    80203c72:	0444d703          	lhu	a4,68(s1)
    80203c76:	4789                	li	a5,2
    80203c78:	08f70963          	beq	a4,a5,80203d0a <sys_open+0x152>
        itrunc(ip);

    iunlock(ip);
    80203c7c:	8526                	mv	a0,s1
    80203c7e:	00001097          	auipc	ra,0x1
    80203c82:	408080e7          	jalr	1032(ra) # 80205086 <iunlock>
    return fd;
    80203c86:	854e                	mv	a0,s3
    80203c88:	74aa                	ld	s1,168(sp)
    80203c8a:	790a                	ld	s2,160(sp)
    80203c8c:	69ea                	ld	s3,152(sp)
}
    80203c8e:	70ea                	ld	ra,184(sp)
    80203c90:	744a                	ld	s0,176(sp)
    80203c92:	6129                	addi	sp,sp,192
    80203c94:	8082                	ret
        if ((ip = namei(path)) == 0) return -1;
    80203c96:	f5040513          	addi	a0,s0,-176
    80203c9a:	00002097          	auipc	ra,0x2
    80203c9e:	bba080e7          	jalr	-1094(ra) # 80205854 <namei>
    80203ca2:	84aa                	mv	s1,a0
    80203ca4:	cd35                	beqz	a0,80203d20 <sys_open+0x168>
        ilock(ip);
    80203ca6:	00001097          	auipc	ra,0x1
    80203caa:	31a080e7          	jalr	794(ra) # 80204fc0 <ilock>
        if (ip->type == T_DIR && omode != O_RDONLY) {
    80203cae:	0444d703          	lhu	a4,68(s1)
    80203cb2:	4785                	li	a5,1
    80203cb4:	f4f71ae3          	bne	a4,a5,80203c08 <sys_open+0x50>
    80203cb8:	f4c42783          	lw	a5,-180(s0)
    80203cbc:	d3a5                	beqz	a5,80203c1c <sys_open+0x64>
            iunlockput(ip);
    80203cbe:	8526                	mv	a0,s1
    80203cc0:	00001097          	auipc	ra,0x1
    80203cc4:	5dc080e7          	jalr	1500(ra) # 8020529c <iunlockput>
            return -1;
    80203cc8:	557d                	li	a0,-1
    80203cca:	74aa                	ld	s1,168(sp)
    80203ccc:	b7c9                	j	80203c8e <sys_open+0xd6>
        iunlockput(ip);
    80203cce:	8526                	mv	a0,s1
    80203cd0:	00001097          	auipc	ra,0x1
    80203cd4:	5cc080e7          	jalr	1484(ra) # 8020529c <iunlockput>
        return -1;
    80203cd8:	557d                	li	a0,-1
    80203cda:	74aa                	ld	s1,168(sp)
    80203cdc:	bf4d                	j	80203c8e <sys_open+0xd6>
        if (f) fileclose(f);
    80203cde:	854a                	mv	a0,s2
    80203ce0:	00002097          	auipc	ra,0x2
    80203ce4:	c92080e7          	jalr	-878(ra) # 80205972 <fileclose>
    80203ce8:	69ea                	ld	s3,152(sp)
        iunlockput(ip);
    80203cea:	8526                	mv	a0,s1
    80203cec:	00001097          	auipc	ra,0x1
    80203cf0:	5b0080e7          	jalr	1456(ra) # 8020529c <iunlockput>
        return -1;
    80203cf4:	557d                	li	a0,-1
    80203cf6:	74aa                	ld	s1,168(sp)
    80203cf8:	790a                	ld	s2,160(sp)
    80203cfa:	bf51                	j	80203c8e <sys_open+0xd6>
        f->type  = FD_DEVICE;
    80203cfc:	00f92023          	sw	a5,0(s2)
        f->major = ip->major;
    80203d00:	0464d783          	lhu	a5,70(s1)
    80203d04:	02f91223          	sh	a5,36(s2)
    80203d08:	b799                	j	80203c4e <sys_open+0x96>
        itrunc(ip);
    80203d0a:	8526                	mv	a0,s1
    80203d0c:	00001097          	auipc	ra,0x1
    80203d10:	3c6080e7          	jalr	966(ra) # 802050d2 <itrunc>
    80203d14:	b7a5                	j	80203c7c <sys_open+0xc4>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203d16:	557d                	li	a0,-1
    80203d18:	bf9d                	j	80203c8e <sys_open+0xd6>
        if (ip == 0) return -1;
    80203d1a:	557d                	li	a0,-1
    80203d1c:	74aa                	ld	s1,168(sp)
    80203d1e:	bf85                	j	80203c8e <sys_open+0xd6>
        if ((ip = namei(path)) == 0) return -1;
    80203d20:	557d                	li	a0,-1
    80203d22:	74aa                	ld	s1,168(sp)
    80203d24:	b7ad                	j	80203c8e <sys_open+0xd6>

0000000080203d26 <sys_mkdir>:

uint64 sys_mkdir(void)
{
    80203d26:	7175                	addi	sp,sp,-144
    80203d28:	e506                	sd	ra,136(sp)
    80203d2a:	e122                	sd	s0,128(sp)
    80203d2c:	0900                	addi	s0,sp,144
    char path[MAXPATH];
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203d2e:	08000613          	li	a2,128
    80203d32:	f7040593          	addi	a1,s0,-144
    80203d36:	4501                	li	a0,0
    80203d38:	fffff097          	auipc	ra,0xfffff
    80203d3c:	70e080e7          	jalr	1806(ra) # 80203446 <argstr>
    80203d40:	57fd                	li	a5,-1
    80203d42:	02054163          	bltz	a0,80203d64 <sys_mkdir+0x3e>
    struct inode *ip = create(path, T_DIR, 0, 0);
    80203d46:	4681                	li	a3,0
    80203d48:	4601                	li	a2,0
    80203d4a:	4585                	li	a1,1
    80203d4c:	f7040513          	addi	a0,s0,-144
    80203d50:	00000097          	auipc	ra,0x0
    80203d54:	83a080e7          	jalr	-1990(ra) # 8020358a <create>
    if (ip == 0) return -1;
    80203d58:	c919                	beqz	a0,80203d6e <sys_mkdir+0x48>
    iunlockput(ip);
    80203d5a:	00001097          	auipc	ra,0x1
    80203d5e:	542080e7          	jalr	1346(ra) # 8020529c <iunlockput>
    return 0;
    80203d62:	4781                	li	a5,0
}
    80203d64:	853e                	mv	a0,a5
    80203d66:	60aa                	ld	ra,136(sp)
    80203d68:	640a                	ld	s0,128(sp)
    80203d6a:	6149                	addi	sp,sp,144
    80203d6c:	8082                	ret
    if (ip == 0) return -1;
    80203d6e:	57fd                	li	a5,-1
    80203d70:	bfd5                	j	80203d64 <sys_mkdir+0x3e>

0000000080203d72 <sys_chdir>:

uint64 sys_chdir(void)
{
    80203d72:	7135                	addi	sp,sp,-160
    80203d74:	ed06                	sd	ra,152(sp)
    80203d76:	e922                	sd	s0,144(sp)
    80203d78:	e14a                	sd	s2,128(sp)
    80203d7a:	1100                	addi	s0,sp,160
    char path[MAXPATH];
    struct proc *p = myproc();
    80203d7c:	ffffe097          	auipc	ra,0xffffe
    80203d80:	95e080e7          	jalr	-1698(ra) # 802016da <myproc>
    80203d84:	892a                	mv	s2,a0
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203d86:	08000613          	li	a2,128
    80203d8a:	f6040593          	addi	a1,s0,-160
    80203d8e:	4501                	li	a0,0
    80203d90:	fffff097          	auipc	ra,0xfffff
    80203d94:	6b6080e7          	jalr	1718(ra) # 80203446 <argstr>
    80203d98:	57fd                	li	a5,-1
    80203d9a:	04054363          	bltz	a0,80203de0 <sys_chdir+0x6e>
    80203d9e:	e526                	sd	s1,136(sp)
    struct inode *ip = namei(path);
    80203da0:	f6040513          	addi	a0,s0,-160
    80203da4:	00002097          	auipc	ra,0x2
    80203da8:	ab0080e7          	jalr	-1360(ra) # 80205854 <namei>
    80203dac:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80203dae:	c539                	beqz	a0,80203dfc <sys_chdir+0x8a>
    ilock(ip);
    80203db0:	00001097          	auipc	ra,0x1
    80203db4:	210080e7          	jalr	528(ra) # 80204fc0 <ilock>
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203db8:	0444d703          	lhu	a4,68(s1)
    80203dbc:	4785                	li	a5,1
    80203dbe:	02f71763          	bne	a4,a5,80203dec <sys_chdir+0x7a>
    iunlock(ip);
    80203dc2:	8526                	mv	a0,s1
    80203dc4:	00001097          	auipc	ra,0x1
    80203dc8:	2c2080e7          	jalr	706(ra) # 80205086 <iunlock>
    iput(p->cwd);
    80203dcc:	15093503          	ld	a0,336(s2)
    80203dd0:	00001097          	auipc	ra,0x1
    80203dd4:	3ae080e7          	jalr	942(ra) # 8020517e <iput>
    p->cwd = ip;
    80203dd8:	14993823          	sd	s1,336(s2)
    return 0;
    80203ddc:	4781                	li	a5,0
    80203dde:	64aa                	ld	s1,136(sp)
}
    80203de0:	853e                	mv	a0,a5
    80203de2:	60ea                	ld	ra,152(sp)
    80203de4:	644a                	ld	s0,144(sp)
    80203de6:	690a                	ld	s2,128(sp)
    80203de8:	610d                	addi	sp,sp,160
    80203dea:	8082                	ret
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203dec:	8526                	mv	a0,s1
    80203dee:	00001097          	auipc	ra,0x1
    80203df2:	4ae080e7          	jalr	1198(ra) # 8020529c <iunlockput>
    80203df6:	57fd                	li	a5,-1
    80203df8:	64aa                	ld	s1,136(sp)
    80203dfa:	b7dd                	j	80203de0 <sys_chdir+0x6e>
    if (ip == 0) return -1;
    80203dfc:	57fd                	li	a5,-1
    80203dfe:	64aa                	ld	s1,136(sp)
    80203e00:	b7c5                	j	80203de0 <sys_chdir+0x6e>

0000000080203e02 <sys_pipe>:

uint64 sys_pipe(void)
{
    80203e02:	7139                	addi	sp,sp,-64
    80203e04:	fc06                	sd	ra,56(sp)
    80203e06:	f822                	sd	s0,48(sp)
    80203e08:	0080                	addi	s0,sp,64
    uint64 fdarray;                   /* user pointer to int[2] */
    argaddr(0, &fdarray);
    80203e0a:	fd840593          	addi	a1,s0,-40
    80203e0e:	4501                	li	a0,0
    80203e10:	fffff097          	auipc	ra,0xfffff
    80203e14:	546080e7          	jalr	1350(ra) # 80203356 <argaddr>

    struct file *rf, *wf;
    if (pipealloc(&rf, &wf) < 0) return -1;
    80203e18:	fc840593          	addi	a1,s0,-56
    80203e1c:	fd040513          	addi	a0,s0,-48
    80203e20:	00002097          	auipc	ra,0x2
    80203e24:	e42080e7          	jalr	-446(ra) # 80205c62 <pipealloc>
    80203e28:	57fd                	li	a5,-1
    80203e2a:	0a054463          	bltz	a0,80203ed2 <sys_pipe+0xd0>
    80203e2e:	f426                	sd	s1,40(sp)

    struct proc *p = myproc();
    80203e30:	ffffe097          	auipc	ra,0xffffe
    80203e34:	8aa080e7          	jalr	-1878(ra) # 802016da <myproc>
    80203e38:	84aa                	mv	s1,a0
    int fd0 = -1, fd1 = -1;
    80203e3a:	57fd                	li	a5,-1
    80203e3c:	fcf42223          	sw	a5,-60(s0)
    80203e40:	fcf42023          	sw	a5,-64(s0)
    if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80203e44:	fd043503          	ld	a0,-48(s0)
    80203e48:	fffff097          	auipc	ra,0xfffff
    80203e4c:	700080e7          	jalr	1792(ra) # 80203548 <fdalloc>
    80203e50:	fca42223          	sw	a0,-60(s0)
    80203e54:	06054163          	bltz	a0,80203eb6 <sys_pipe+0xb4>
    80203e58:	fc843503          	ld	a0,-56(s0)
    80203e5c:	fffff097          	auipc	ra,0xfffff
    80203e60:	6ec080e7          	jalr	1772(ra) # 80203548 <fdalloc>
    80203e64:	fca42023          	sw	a0,-64(s0)
    80203e68:	02054e63          	bltz	a0,80203ea4 <sys_pipe+0xa2>
        if (fd0 >= 0) p->ofile[fd0] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80203e6c:	4691                	li	a3,4
    80203e6e:	fc440613          	addi	a2,s0,-60
    80203e72:	fd843583          	ld	a1,-40(s0)
    80203e76:	68a8                	ld	a0,80(s1)
    80203e78:	fffff097          	auipc	ra,0xfffff
    80203e7c:	036080e7          	jalr	54(ra) # 80202eae <copyout>
    80203e80:	04054e63          	bltz	a0,80203edc <sys_pipe+0xda>
        copyout(p->pagetable, fdarray + sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0) {
    80203e84:	4691                	li	a3,4
    80203e86:	fc040613          	addi	a2,s0,-64
    80203e8a:	fd843583          	ld	a1,-40(s0)
    80203e8e:	0591                	addi	a1,a1,4
    80203e90:	68a8                	ld	a0,80(s1)
    80203e92:	fffff097          	auipc	ra,0xfffff
    80203e96:	01c080e7          	jalr	28(ra) # 80202eae <copyout>
        p->ofile[fd1] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    return 0;
    80203e9a:	4781                	li	a5,0
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80203e9c:	04054063          	bltz	a0,80203edc <sys_pipe+0xda>
    80203ea0:	74a2                	ld	s1,40(sp)
    80203ea2:	a805                	j	80203ed2 <sys_pipe+0xd0>
        if (fd0 >= 0) p->ofile[fd0] = 0;
    80203ea4:	fc442783          	lw	a5,-60(s0)
    80203ea8:	0007c763          	bltz	a5,80203eb6 <sys_pipe+0xb4>
    80203eac:	07e9                	addi	a5,a5,26
    80203eae:	078e                	slli	a5,a5,0x3
    80203eb0:	97a6                	add	a5,a5,s1
    80203eb2:	0007b023          	sd	zero,0(a5)
        fileclose(rf);
    80203eb6:	fd043503          	ld	a0,-48(s0)
    80203eba:	00002097          	auipc	ra,0x2
    80203ebe:	ab8080e7          	jalr	-1352(ra) # 80205972 <fileclose>
        fileclose(wf);
    80203ec2:	fc843503          	ld	a0,-56(s0)
    80203ec6:	00002097          	auipc	ra,0x2
    80203eca:	aac080e7          	jalr	-1364(ra) # 80205972 <fileclose>
        return -1;
    80203ece:	57fd                	li	a5,-1
    80203ed0:	74a2                	ld	s1,40(sp)
}
    80203ed2:	853e                	mv	a0,a5
    80203ed4:	70e2                	ld	ra,56(sp)
    80203ed6:	7442                	ld	s0,48(sp)
    80203ed8:	6121                	addi	sp,sp,64
    80203eda:	8082                	ret
        p->ofile[fd0] = 0;
    80203edc:	fc442783          	lw	a5,-60(s0)
    80203ee0:	07e9                	addi	a5,a5,26
    80203ee2:	078e                	slli	a5,a5,0x3
    80203ee4:	97a6                	add	a5,a5,s1
    80203ee6:	0007b023          	sd	zero,0(a5)
        p->ofile[fd1] = 0;
    80203eea:	fc042783          	lw	a5,-64(s0)
    80203eee:	07e9                	addi	a5,a5,26
    80203ef0:	078e                	slli	a5,a5,0x3
    80203ef2:	94be                	add	s1,s1,a5
    80203ef4:	0004b023          	sd	zero,0(s1)
        fileclose(rf);
    80203ef8:	fd043503          	ld	a0,-48(s0)
    80203efc:	00002097          	auipc	ra,0x2
    80203f00:	a76080e7          	jalr	-1418(ra) # 80205972 <fileclose>
        fileclose(wf);
    80203f04:	fc843503          	ld	a0,-56(s0)
    80203f08:	00002097          	auipc	ra,0x2
    80203f0c:	a6a080e7          	jalr	-1430(ra) # 80205972 <fileclose>
        return -1;
    80203f10:	57fd                	li	a5,-1
    80203f12:	74a2                	ld	s1,40(sp)
    80203f14:	bf7d                	j	80203ed2 <sys_pipe+0xd0>

0000000080203f16 <sys_exec>:

uint64 sys_exec(void)
{
    80203f16:	7129                	addi	sp,sp,-320
    80203f18:	fe06                	sd	ra,312(sp)
    80203f1a:	fa22                	sd	s0,304(sp)
    80203f1c:	0280                	addi	s0,sp,320
    char path[MAXPATH];
    uint64 uargv, uarg;
    char *argv[MAXARG];

    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203f1e:	08000613          	li	a2,128
    80203f22:	f5040593          	addi	a1,s0,-176
    80203f26:	4501                	li	a0,0
    80203f28:	fffff097          	auipc	ra,0xfffff
    80203f2c:	51e080e7          	jalr	1310(ra) # 80203446 <argstr>
    80203f30:	87aa                	mv	a5,a0
    80203f32:	557d                	li	a0,-1
    80203f34:	0a07c763          	bltz	a5,80203fe2 <sys_exec+0xcc>
    80203f38:	f626                	sd	s1,296(sp)
    80203f3a:	f24a                	sd	s2,288(sp)
    80203f3c:	ee4e                	sd	s3,280(sp)
    80203f3e:	ea52                	sd	s4,272(sp)
    argaddr(1, &uargv);
    80203f40:	f4840593          	addi	a1,s0,-184
    80203f44:	4505                	li	a0,1
    80203f46:	fffff097          	auipc	ra,0xfffff
    80203f4a:	410080e7          	jalr	1040(ra) # 80203356 <argaddr>
    memset(argv, 0, sizeof(argv));
    80203f4e:	08000613          	li	a2,128
    80203f52:	4581                	li	a1,0
    80203f54:	ec040513          	addi	a0,s0,-320
    80203f58:	ffffc097          	auipc	ra,0xffffc
    80203f5c:	708080e7          	jalr	1800(ra) # 80200660 <memset>

    int ret = -1;
    for (int i = 0; ; i++) {
        if (i >= MAXARG) goto out;
    80203f60:	ec040493          	addi	s1,s0,-320
    memset(argv, 0, sizeof(argv));
    80203f64:	89a6                	mv	s3,s1
    80203f66:	4901                	li	s2,0
        if (i >= MAXARG) goto out;
    80203f68:	4a41                	li	s4,16
        if (copyin(myproc()->pagetable, (char *)&uarg,
    80203f6a:	ffffd097          	auipc	ra,0xffffd
    80203f6e:	770080e7          	jalr	1904(ra) # 802016da <myproc>
    80203f72:	00391613          	slli	a2,s2,0x3
    80203f76:	46a1                	li	a3,8
    80203f78:	f4843783          	ld	a5,-184(s0)
    80203f7c:	963e                	add	a2,a2,a5
    80203f7e:	f4040593          	addi	a1,s0,-192
    80203f82:	6928                	ld	a0,80(a0)
    80203f84:	fffff097          	auipc	ra,0xfffff
    80203f88:	01e080e7          	jalr	30(ra) # 80202fa2 <copyin>
    80203f8c:	08054163          	bltz	a0,8020400e <sys_exec+0xf8>
                   uargv + sizeof(uint64) * i, sizeof(uint64)) < 0) goto out;
        if (uarg == 0) { argv[i] = 0; break; }
    80203f90:	f4043783          	ld	a5,-192(s0)
    80203f94:	cbb9                	beqz	a5,80203fea <sys_exec+0xd4>
        argv[i] = palloc();
    80203f96:	ffffd097          	auipc	ra,0xffffd
    80203f9a:	0cc080e7          	jalr	204(ra) # 80201062 <palloc>
    80203f9e:	85aa                	mv	a1,a0
    80203fa0:	00a9b023          	sd	a0,0(s3)
        if (!argv[i]) goto out;
    80203fa4:	c53d                	beqz	a0,80204012 <sys_exec+0xfc>
        if (fetchstr(uarg, argv[i], PGSIZE) < 0) goto out;
    80203fa6:	6605                	lui	a2,0x1
    80203fa8:	f4043503          	ld	a0,-192(s0)
    80203fac:	fffff097          	auipc	ra,0xfffff
    80203fb0:	44e080e7          	jalr	1102(ra) # 802033fa <fetchstr>
    80203fb4:	06054163          	bltz	a0,80204016 <sys_exec+0x100>
        if (i >= MAXARG) goto out;
    80203fb8:	0905                	addi	s2,s2,1
    80203fba:	09a1                	addi	s3,s3,8
    80203fbc:	fb4917e3          	bne	s2,s4,80203f6a <sys_exec+0x54>
    int ret = -1;
    80203fc0:	59fd                	li	s3,-1
    }
    ret = exec(path, argv);
out:
    /* Free EVERY page we allocated, on every path - the original version of
     * this function leaked argv pages on a bad pointer. Found in the audit. */
    for (int i = 0; i < MAXARG && argv[i]; i++) pfree(argv[i]);
    80203fc2:	f4040913          	addi	s2,s0,-192
    80203fc6:	6088                	ld	a0,0(s1)
    80203fc8:	c901                	beqz	a0,80203fd8 <sys_exec+0xc2>
    80203fca:	ffffd097          	auipc	ra,0xffffd
    80203fce:	1a8080e7          	jalr	424(ra) # 80201172 <pfree>
    80203fd2:	04a1                	addi	s1,s1,8
    80203fd4:	ff2499e3          	bne	s1,s2,80203fc6 <sys_exec+0xb0>
    return ret;
    80203fd8:	854e                	mv	a0,s3
    80203fda:	74b2                	ld	s1,296(sp)
    80203fdc:	7912                	ld	s2,288(sp)
    80203fde:	69f2                	ld	s3,280(sp)
    80203fe0:	6a52                	ld	s4,272(sp)
}
    80203fe2:	70f2                	ld	ra,312(sp)
    80203fe4:	7452                	ld	s0,304(sp)
    80203fe6:	6131                	addi	sp,sp,320
    80203fe8:	8082                	ret
        if (uarg == 0) { argv[i] = 0; break; }
    80203fea:	0009079b          	sext.w	a5,s2
    80203fee:	078e                	slli	a5,a5,0x3
    80203ff0:	fd078793          	addi	a5,a5,-48
    80203ff4:	97a2                	add	a5,a5,s0
    80203ff6:	ee07b823          	sd	zero,-272(a5)
    ret = exec(path, argv);
    80203ffa:	ec040593          	addi	a1,s0,-320
    80203ffe:	f5040513          	addi	a0,s0,-176
    80204002:	00000097          	auipc	ra,0x0
    80204006:	314080e7          	jalr	788(ra) # 80204316 <exec>
    8020400a:	89aa                	mv	s3,a0
    8020400c:	bf5d                	j	80203fc2 <sys_exec+0xac>
    int ret = -1;
    8020400e:	59fd                	li	s3,-1
    80204010:	bf4d                	j	80203fc2 <sys_exec+0xac>
    80204012:	59fd                	li	s3,-1
    80204014:	b77d                	j	80203fc2 <sys_exec+0xac>
    80204016:	59fd                	li	s3,-1
    80204018:	b76d                	j	80203fc2 <sys_exec+0xac>

000000008020401a <consolewrite>:
    devsw[CONSOLE].read  = consoleread;
    devsw[CONSOLE].write = consolewrite;
}

int consolewrite(uint64 src, int n)
{
    8020401a:	7139                	addi	sp,sp,-64
    8020401c:	fc06                	sd	ra,56(sp)
    8020401e:	f822                	sd	s0,48(sp)
    80204020:	ec4e                	sd	s3,24(sp)
    80204022:	0080                	addi	s0,sp,64
    80204024:	89ae                	mv	s3,a1
    for (int i = 0; i < n; i++) {
    80204026:	04b05563          	blez	a1,80204070 <consolewrite+0x56>
    8020402a:	f426                	sd	s1,40(sp)
    8020402c:	f04a                	sd	s2,32(sp)
    8020402e:	84aa                	mv	s1,a0
    80204030:	00a58933          	add	s2,a1,a0
        char c;
        /* copyin, not a direct dereference - src is a USER pointer. */
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    80204034:	ffffd097          	auipc	ra,0xffffd
    80204038:	6a6080e7          	jalr	1702(ra) # 802016da <myproc>
    8020403c:	4685                	li	a3,1
    8020403e:	8626                	mv	a2,s1
    80204040:	fcf40593          	addi	a1,s0,-49
    80204044:	6928                	ld	a0,80(a0)
    80204046:	fffff097          	auipc	ra,0xfffff
    8020404a:	f5c080e7          	jalr	-164(ra) # 80202fa2 <copyin>
    8020404e:	00054e63          	bltz	a0,8020406a <consolewrite+0x50>
        hal_console_putc(c);
    80204052:	fcf44503          	lbu	a0,-49(s0)
    80204056:	00002097          	auipc	ra,0x2
    8020405a:	114080e7          	jalr	276(ra) # 8020616a <hal_console_putc>
    for (int i = 0; i < n; i++) {
    8020405e:	0485                	addi	s1,s1,1
    80204060:	fd249ae3          	bne	s1,s2,80204034 <consolewrite+0x1a>
    80204064:	74a2                	ld	s1,40(sp)
    80204066:	7902                	ld	s2,32(sp)
    80204068:	a021                	j	80204070 <consolewrite+0x56>
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    8020406a:	59fd                	li	s3,-1
    8020406c:	74a2                	ld	s1,40(sp)
    8020406e:	7902                	ld	s2,32(sp)
    }
    return n;
}
    80204070:	854e                	mv	a0,s3
    80204072:	70e2                	ld	ra,56(sp)
    80204074:	7442                	ld	s0,48(sp)
    80204076:	69e2                	ld	s3,24(sp)
    80204078:	6121                	addi	sp,sp,64
    8020407a:	8082                	ret

000000008020407c <consoleread>:

int consoleread(uint64 dst, int n)
{
    8020407c:	715d                	addi	sp,sp,-80
    8020407e:	e486                	sd	ra,72(sp)
    80204080:	e0a2                	sd	s0,64(sp)
    80204082:	fc26                	sd	s1,56(sp)
    80204084:	f84a                	sd	s2,48(sp)
    80204086:	f44e                	sd	s3,40(sp)
    80204088:	f052                	sd	s4,32(sp)
    8020408a:	ec56                	sd	s5,24(sp)
    8020408c:	0880                	addi	s0,sp,80
    8020408e:	8a2a                	mv	s4,a0
    80204090:	89ae                	mv	s3,a1
    int target = n;
    acquire(&cons.lock);
    80204092:	0012d517          	auipc	a0,0x12d
    80204096:	98650513          	addi	a0,a0,-1658 # 80330a18 <cons>
    8020409a:	ffffd097          	auipc	ra,0xffffd
    8020409e:	256080e7          	jalr	598(ra) # 802012f0 <acquire>
    while (n > 0) {
    802040a2:	8ace                	mv	s5,s3
        while (cons.r == cons.w) {
    802040a4:	0012d497          	auipc	s1,0x12d
    802040a8:	97448493          	addi	s1,s1,-1676 # 80330a18 <cons>
            if (myproc()->killed) { release(&cons.lock); return -1; }
            sleep(&cons.r, &cons.lock);
    802040ac:	0012d917          	auipc	s2,0x12d
    802040b0:	a0490913          	addi	s2,s2,-1532 # 80330ab0 <cons+0x98>
    while (n > 0) {
    802040b4:	09305463          	blez	s3,8020413c <consoleread+0xc0>
        while (cons.r == cons.w) {
    802040b8:	0984a783          	lw	a5,152(s1)
    802040bc:	09c4a703          	lw	a4,156(s1)
    802040c0:	02f71463          	bne	a4,a5,802040e8 <consoleread+0x6c>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    802040c4:	ffffd097          	auipc	ra,0xffffd
    802040c8:	616080e7          	jalr	1558(ra) # 802016da <myproc>
    802040cc:	551c                	lw	a5,40(a0)
    802040ce:	e3d1                	bnez	a5,80204152 <consoleread+0xd6>
            sleep(&cons.r, &cons.lock);
    802040d0:	85a6                	mv	a1,s1
    802040d2:	854a                	mv	a0,s2
    802040d4:	ffffe097          	auipc	ra,0xffffe
    802040d8:	c6a080e7          	jalr	-918(ra) # 80201d3e <sleep>
        while (cons.r == cons.w) {
    802040dc:	0984a783          	lw	a5,152(s1)
    802040e0:	09c4a703          	lw	a4,156(s1)
    802040e4:	fef700e3          	beq	a4,a5,802040c4 <consoleread+0x48>
        }
        char c = cons.buf[cons.r++ % INBUF];
    802040e8:	0012d717          	auipc	a4,0x12d
    802040ec:	93070713          	addi	a4,a4,-1744 # 80330a18 <cons>
    802040f0:	0017869b          	addiw	a3,a5,1
    802040f4:	08d72c23          	sw	a3,152(a4)
    802040f8:	07f7f793          	andi	a5,a5,127
    802040fc:	973e                	add	a4,a4,a5
    802040fe:	01874783          	lbu	a5,24(a4)
    80204102:	faf40fa3          	sb	a5,-65(s0)
        if (c == 4) break;                       /* Ctrl-D */
    80204106:	4711                	li	a4,4
    80204108:	02e78a63          	beq	a5,a4,8020413c <consoleread+0xc0>
        if (copyout(myproc()->pagetable, dst, &c, 1) < 0) break;
    8020410c:	ffffd097          	auipc	ra,0xffffd
    80204110:	5ce080e7          	jalr	1486(ra) # 802016da <myproc>
    80204114:	4685                	li	a3,1
    80204116:	fbf40613          	addi	a2,s0,-65
    8020411a:	85d2                	mv	a1,s4
    8020411c:	6928                	ld	a0,80(a0)
    8020411e:	fffff097          	auipc	ra,0xfffff
    80204122:	d90080e7          	jalr	-624(ra) # 80202eae <copyout>
    80204126:	00054b63          	bltz	a0,8020413c <consoleread+0xc0>
        dst++; n--;
    8020412a:	0a05                	addi	s4,s4,1
    8020412c:	3afd                	addiw	s5,s5,-1
        if (c == '\n') break;
    8020412e:	fbf44703          	lbu	a4,-65(s0)
    80204132:	47a9                	li	a5,10
    80204134:	00f70463          	beq	a4,a5,8020413c <consoleread+0xc0>
    while (n > 0) {
    80204138:	f80a90e3          	bnez	s5,802040b8 <consoleread+0x3c>
    }
    release(&cons.lock);
    8020413c:	0012d517          	auipc	a0,0x12d
    80204140:	8dc50513          	addi	a0,a0,-1828 # 80330a18 <cons>
    80204144:	ffffd097          	auipc	ra,0xffffd
    80204148:	260080e7          	jalr	608(ra) # 802013a4 <release>
    return target - n;
    8020414c:	4159853b          	subw	a0,s3,s5
    80204150:	a811                	j	80204164 <consoleread+0xe8>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    80204152:	0012d517          	auipc	a0,0x12d
    80204156:	8c650513          	addi	a0,a0,-1850 # 80330a18 <cons>
    8020415a:	ffffd097          	auipc	ra,0xffffd
    8020415e:	24a080e7          	jalr	586(ra) # 802013a4 <release>
    80204162:	557d                	li	a0,-1
}
    80204164:	60a6                	ld	ra,72(sp)
    80204166:	6406                	ld	s0,64(sp)
    80204168:	74e2                	ld	s1,56(sp)
    8020416a:	7942                	ld	s2,48(sp)
    8020416c:	79a2                	ld	s3,40(sp)
    8020416e:	7a02                	ld	s4,32(sp)
    80204170:	6ae2                	ld	s5,24(sp)
    80204172:	6161                	addi	sp,sp,80
    80204174:	8082                	ret

0000000080204176 <consoleinit>:
{
    80204176:	1141                	addi	sp,sp,-16
    80204178:	e406                	sd	ra,8(sp)
    8020417a:	e022                	sd	s0,0(sp)
    8020417c:	0800                	addi	s0,sp,16
    initlock(&cons.lock, "cons");
    8020417e:	00003597          	auipc	a1,0x3
    80204182:	7f258593          	addi	a1,a1,2034 # 80207970 <etext+0x970>
    80204186:	0012d517          	auipc	a0,0x12d
    8020418a:	89250513          	addi	a0,a0,-1902 # 80330a18 <cons>
    8020418e:	ffffd097          	auipc	ra,0xffffd
    80204192:	0e6080e7          	jalr	230(ra) # 80201274 <initlock>
    devsw[CONSOLE].read  = consoleread;
    80204196:	00137797          	auipc	a5,0x137
    8020419a:	aba78793          	addi	a5,a5,-1350 # 8033ac50 <devsw>
    8020419e:	00000717          	auipc	a4,0x0
    802041a2:	ede70713          	addi	a4,a4,-290 # 8020407c <consoleread>
    802041a6:	eb98                	sd	a4,16(a5)
    devsw[CONSOLE].write = consolewrite;
    802041a8:	00000717          	auipc	a4,0x0
    802041ac:	e7270713          	addi	a4,a4,-398 # 8020401a <consolewrite>
    802041b0:	ef98                	sd	a4,24(a5)
}
    802041b2:	60a2                	ld	ra,8(sp)
    802041b4:	6402                	ld	s0,0(sp)
    802041b6:	0141                	addi	sp,sp,16
    802041b8:	8082                	ret

00000000802041ba <consoleintr>:

/* Called from the trap handler when the UART raises an interrupt. */
void consoleintr(int c)
{
    802041ba:	1101                	addi	sp,sp,-32
    802041bc:	ec06                	sd	ra,24(sp)
    802041be:	e822                	sd	s0,16(sp)
    802041c0:	e426                	sd	s1,8(sp)
    802041c2:	1000                	addi	s0,sp,32
    802041c4:	84aa                	mv	s1,a0
    acquire(&cons.lock);
    802041c6:	0012d517          	auipc	a0,0x12d
    802041ca:	85250513          	addi	a0,a0,-1966 # 80330a18 <cons>
    802041ce:	ffffd097          	auipc	ra,0xffffd
    802041d2:	122080e7          	jalr	290(ra) # 802012f0 <acquire>
    switch (c) {
    802041d6:	47c1                	li	a5,16
    802041d8:	08f48463          	beq	s1,a5,80204260 <consoleintr+0xa6>
    802041dc:	07f00793          	li	a5,127
    802041e0:	0af48163          	beq	s1,a5,80204282 <consoleintr+0xc8>
    802041e4:	47a1                	li	a5,8
    802041e6:	08f48e63          	beq	s1,a5,80204282 <consoleintr+0xc8>
            cons.e--;
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
        }
        break;
    default:
        if (c != 0 && cons.e - cons.r < INBUF) {
    802041ea:	ccbd                	beqz	s1,80204268 <consoleintr+0xae>
    802041ec:	0012d717          	auipc	a4,0x12d
    802041f0:	82c70713          	addi	a4,a4,-2004 # 80330a18 <cons>
    802041f4:	0a072783          	lw	a5,160(a4)
    802041f8:	09872703          	lw	a4,152(a4)
    802041fc:	9f99                	subw	a5,a5,a4
    802041fe:	07f00713          	li	a4,127
    80204202:	06f76363          	bltu	a4,a5,80204268 <consoleintr+0xae>
            c = (c == '\r') ? '\n' : c;
    80204206:	47b5                	li	a5,13
    80204208:	0cf48f63          	beq	s1,a5,802042e6 <consoleintr+0x12c>
    8020420c:	e04a                	sd	s2,0(sp)
            hal_console_putc(c);                 /* echo */
    8020420e:	0ff4f913          	zext.b	s2,s1
    80204212:	854a                	mv	a0,s2
    80204214:	00002097          	auipc	ra,0x2
    80204218:	f56080e7          	jalr	-170(ra) # 8020616a <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    8020421c:	0012c797          	auipc	a5,0x12c
    80204220:	7fc78793          	addi	a5,a5,2044 # 80330a18 <cons>
    80204224:	0a07a703          	lw	a4,160(a5)
    80204228:	0017069b          	addiw	a3,a4,1
    8020422c:	0006861b          	sext.w	a2,a3
    80204230:	0ad7a023          	sw	a3,160(a5)
    80204234:	07f77713          	andi	a4,a4,127
    80204238:	97ba                	add	a5,a5,a4
    8020423a:	01278c23          	sb	s2,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    8020423e:	47a9                	li	a5,10
    80204240:	08f48363          	beq	s1,a5,802042c6 <consoleintr+0x10c>
    80204244:	4791                	li	a5,4
    80204246:	08f48263          	beq	s1,a5,802042ca <consoleintr+0x110>
    8020424a:	0012d797          	auipc	a5,0x12d
    8020424e:	8667a783          	lw	a5,-1946(a5) # 80330ab0 <cons+0x98>
    80204252:	9e9d                	subw	a3,a3,a5
    80204254:	08000793          	li	a5,128
    80204258:	06f68563          	beq	a3,a5,802042c2 <consoleintr+0x108>
    8020425c:	6902                	ld	s2,0(sp)
    8020425e:	a029                	j	80204268 <consoleintr+0xae>
        procdump();
    80204260:	ffffe097          	auipc	ra,0xffffe
    80204264:	f1a080e7          	jalr	-230(ra) # 8020217a <procdump>
                wakeup(&cons.r);
            }
        }
        break;
    }
    release(&cons.lock);
    80204268:	0012c517          	auipc	a0,0x12c
    8020426c:	7b050513          	addi	a0,a0,1968 # 80330a18 <cons>
    80204270:	ffffd097          	auipc	ra,0xffffd
    80204274:	134080e7          	jalr	308(ra) # 802013a4 <release>
}
    80204278:	60e2                	ld	ra,24(sp)
    8020427a:	6442                	ld	s0,16(sp)
    8020427c:	64a2                	ld	s1,8(sp)
    8020427e:	6105                	addi	sp,sp,32
    80204280:	8082                	ret
        if (cons.e != cons.w) {
    80204282:	0012c717          	auipc	a4,0x12c
    80204286:	79670713          	addi	a4,a4,1942 # 80330a18 <cons>
    8020428a:	0a072783          	lw	a5,160(a4)
    8020428e:	09c72703          	lw	a4,156(a4)
    80204292:	fcf70be3          	beq	a4,a5,80204268 <consoleintr+0xae>
            cons.e--;
    80204296:	37fd                	addiw	a5,a5,-1
    80204298:	0012d717          	auipc	a4,0x12d
    8020429c:	82f72023          	sw	a5,-2016(a4) # 80330ab8 <cons+0xa0>
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
    802042a0:	4521                	li	a0,8
    802042a2:	00002097          	auipc	ra,0x2
    802042a6:	ec8080e7          	jalr	-312(ra) # 8020616a <hal_console_putc>
    802042aa:	02000513          	li	a0,32
    802042ae:	00002097          	auipc	ra,0x2
    802042b2:	ebc080e7          	jalr	-324(ra) # 8020616a <hal_console_putc>
    802042b6:	4521                	li	a0,8
    802042b8:	00002097          	auipc	ra,0x2
    802042bc:	eb2080e7          	jalr	-334(ra) # 8020616a <hal_console_putc>
    802042c0:	b765                	j	80204268 <consoleintr+0xae>
    802042c2:	6902                	ld	s2,0(sp)
    802042c4:	a021                	j	802042cc <consoleintr+0x112>
    802042c6:	6902                	ld	s2,0(sp)
    802042c8:	a011                	j	802042cc <consoleintr+0x112>
    802042ca:	6902                	ld	s2,0(sp)
                cons.w = cons.e;
    802042cc:	0012c797          	auipc	a5,0x12c
    802042d0:	7ec7a423          	sw	a2,2024(a5) # 80330ab4 <cons+0x9c>
                wakeup(&cons.r);
    802042d4:	0012c517          	auipc	a0,0x12c
    802042d8:	7dc50513          	addi	a0,a0,2012 # 80330ab0 <cons+0x98>
    802042dc:	ffffe097          	auipc	ra,0xffffe
    802042e0:	be8080e7          	jalr	-1048(ra) # 80201ec4 <wakeup>
    802042e4:	b751                	j	80204268 <consoleintr+0xae>
            hal_console_putc(c);                 /* echo */
    802042e6:	4529                	li	a0,10
    802042e8:	00002097          	auipc	ra,0x2
    802042ec:	e82080e7          	jalr	-382(ra) # 8020616a <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    802042f0:	0012c797          	auipc	a5,0x12c
    802042f4:	72878793          	addi	a5,a5,1832 # 80330a18 <cons>
    802042f8:	0a07a703          	lw	a4,160(a5)
    802042fc:	0017069b          	addiw	a3,a4,1
    80204300:	0006861b          	sext.w	a2,a3
    80204304:	0ad7a023          	sw	a3,160(a5)
    80204308:	07f77713          	andi	a4,a4,127
    8020430c:	97ba                	add	a5,a5,a4
    8020430e:	4729                	li	a4,10
    80204310:	00e78c23          	sb	a4,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    80204314:	bf65                	j	802042cc <consoleintr+0x112>

0000000080204316 <exec>:
    }
    return 0;
}

int exec(char *path, char **argv)
{
    80204316:	7125                	addi	sp,sp,-416
    80204318:	ef06                	sd	ra,408(sp)
    8020431a:	eb22                	sd	s0,400(sp)
    8020431c:	e726                	sd	s1,392(sp)
    8020431e:	1300                	addi	s0,sp,416
    80204320:	e8a43023          	sd	a0,-384(s0)
    80204324:	e6b43c23          	sd	a1,-392(s0)
    struct inode *ip = namei(path);
    80204328:	00001097          	auipc	ra,0x1
    8020432c:	52c080e7          	jalr	1324(ra) # 80205854 <namei>
    if (ip == 0) return -1;
    80204330:	3c050963          	beqz	a0,80204702 <exec+0x3ec>
    80204334:	f2da                	sd	s6,352(sp)
    80204336:	8b2a                	mv	s6,a0
    ilock(ip);
    80204338:	00001097          	auipc	ra,0x1
    8020433c:	c88080e7          	jalr	-888(ra) # 80204fc0 <ilock>

    struct elfhdr eh;
    pagetable_t newpt = 0;
    uint64 sz = 0;

    if (readi(ip, 0, (uint64)&eh, 0, sizeof(eh)) != sizeof(eh)) goto bad;
    80204340:	04000713          	li	a4,64
    80204344:	4681                	li	a3,0
    80204346:	f5040613          	addi	a2,s0,-176
    8020434a:	4581                	li	a1,0
    8020434c:	855a                	mv	a0,s6
    8020434e:	00001097          	auipc	ra,0x1
    80204352:	fa0080e7          	jalr	-96(ra) # 802052ee <readi>
    80204356:	04000793          	li	a5,64
    8020435a:	02f51263          	bne	a0,a5,8020437e <exec+0x68>
    if (eh.magic != ELF_MAGIC) goto bad;              /* reject, do not run */
    8020435e:	f5042703          	lw	a4,-176(s0)
    80204362:	464c47b7          	lui	a5,0x464c4
    80204366:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39d3ba81>
    8020436a:	00f71a63          	bne	a4,a5,8020437e <exec+0x68>
    if (eh.phnum == 0 || eh.phnum > 16) goto bad;
    8020436e:	f8845783          	lhu	a5,-120(s0)
    80204372:	37fd                	addiw	a5,a5,-1
    80204374:	17c2                	slli	a5,a5,0x30
    80204376:	93c1                	srli	a5,a5,0x30
    80204378:	473d                	li	a4,15
    8020437a:	00f77f63          	bgeu	a4,a5,80204398 <exec+0x82>
    uvmfree(oldpt, oldsz);
    return argc;

bad:
    if (newpt) uvmfree(newpt, sz);
    if (ip) iunlockput(ip);
    8020437e:	855a                	mv	a0,s6
    80204380:	00001097          	auipc	ra,0x1
    80204384:	f1c080e7          	jalr	-228(ra) # 8020529c <iunlockput>
    return -1;
    80204388:	54fd                	li	s1,-1
    8020438a:	7b16                	ld	s6,352(sp)
}
    8020438c:	8526                	mv	a0,s1
    8020438e:	60fa                	ld	ra,408(sp)
    80204390:	645a                	ld	s0,400(sp)
    80204392:	64ba                	ld	s1,392(sp)
    80204394:	611d                	addi	sp,sp,416
    80204396:	8082                	ret
    80204398:	eae2                	sd	s8,336(sp)
    if ((newpt = uvmcreate()) == 0) goto bad;
    8020439a:	fffff097          	auipc	ra,0xfffff
    8020439e:	94c080e7          	jalr	-1716(ra) # 80202ce6 <uvmcreate>
    802043a2:	8c2a                	mv	s8,a0
    802043a4:	34050d63          	beqz	a0,802046fe <exec+0x3e8>
    802043a8:	e34a                	sd	s2,384(sp)
    802043aa:	fece                	sd	s3,376(sp)
    802043ac:	fad2                	sd	s4,368(sp)
    802043ae:	f6d6                	sd	s5,360(sp)
    802043b0:	eede                	sd	s7,344(sp)
    802043b2:	e6e6                	sd	s9,328(sp)
    802043b4:	e2ea                	sd	s10,320(sp)
    802043b6:	fe6e                	sd	s11,312(sp)
    for (int i = 0; i < eh.phnum; i++) {
    802043b8:	f8845783          	lhu	a5,-120(s0)
    802043bc:	16078563          	beqz	a5,80204526 <exec+0x210>
    802043c0:	4c81                	li	s9,0
    802043c2:	4d01                	li	s10,0
    uint64 sz = 0;
    802043c4:	e8043423          	sd	zero,-376(s0)
        if (ph.type != ELF_PROG_LOAD) continue;
    802043c8:	4d85                	li	s11,1
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    802043ca:	800007b7          	lui	a5,0x80000
    802043ce:	fff7c793          	not	a5,a5
    802043d2:	e6f43823          	sd	a5,-400(s0)
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    802043d6:	6a05                	lui	s4,0x1
    802043d8:	fffa0793          	addi	a5,s4,-1 # fff <_entry-0x801ff001>
    802043dc:	e6f43423          	sd	a5,-408(s0)
    802043e0:	a0d1                	j	802044a4 <exec+0x18e>
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    802043e2:	00c4f563          	bgeu	s1,a2,802043ec <exec+0xd6>
    802043e6:	8e05                	sub	a2,a2,s1
    802043e8:	4781                	li	a5,0
    802043ea:	a09d                	j	80204450 <exec+0x13a>
    802043ec:	4781                	li	a5,0
    802043ee:	4601                	li	a2,0
    802043f0:	a085                	j	80204450 <exec+0x13a>
            if (readi(ip, 0, (uint64)(mem + dst_off),
    802043f2:	2981                	sext.w	s3,s3
    802043f4:	874e                	mv	a4,s3
    802043f6:	e9843683          	ld	a3,-360(s0)
    802043fa:	9ebd                	addw	a3,a3,a5
    802043fc:	964a                	add	a2,a2,s2
    802043fe:	4581                	li	a1,0
    80204400:	855a                	mv	a0,s6
    80204402:	00001097          	auipc	ra,0x1
    80204406:	eec080e7          	jalr	-276(ra) # 802052ee <readi>
    8020440a:	05351f63          	bne	a0,s3,80204468 <exec+0x152>
        if (mappages(pt, va, PGSIZE, (uint64)mem, perm) != 0) {
    8020440e:	875e                	mv	a4,s7
    80204410:	86ca                	mv	a3,s2
    80204412:	8652                	mv	a2,s4
    80204414:	85a6                	mv	a1,s1
    80204416:	8562                	mv	a0,s8
    80204418:	ffffe097          	auipc	ra,0xffffe
    8020441c:	6bc080e7          	jalr	1724(ra) # 80202ad4 <mappages>
    80204420:	e931                	bnez	a0,80204474 <exec+0x15e>
    for (uint64 va = start; va < end; va += PGSIZE) {
    80204422:	94d2                	add	s1,s1,s4
    80204424:	0554fe63          	bgeu	s1,s5,80204480 <exec+0x16a>
        char *mem = palloc();
    80204428:	ffffd097          	auipc	ra,0xffffd
    8020442c:	c3a080e7          	jalr	-966(ra) # 80201062 <palloc>
    80204430:	892a                	mv	s2,a0
        if (!mem) return -1;
    80204432:	1c050063          	beqz	a0,802045f2 <exec+0x2dc>
        memset(mem, 0, PGSIZE);                    /* zero first: this IS the .bss */
    80204436:	8652                	mv	a2,s4
    80204438:	4581                	li	a1,0
    8020443a:	ffffc097          	auipc	ra,0xffffc
    8020443e:	226080e7          	jalr	550(ra) # 80200660 <memset>
        uint64 seg_off = (va > ph->vaddr) ? (va - ph->vaddr) : 0;
    80204442:	ea043603          	ld	a2,-352(s0)
    80204446:	f8967ee3          	bgeu	a2,s1,802043e2 <exec+0xcc>
    8020444a:	40c487b3          	sub	a5,s1,a2
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    8020444e:	4601                	li	a2,0
        if (seg_off < ph->filesz) {
    80204450:	eb043983          	ld	s3,-336(s0)
    80204454:	fb37fde3          	bgeu	a5,s3,8020440e <exec+0xf8>
            if (n > PGSIZE - dst_off) n = PGSIZE - dst_off;
    80204458:	40ca0733          	sub	a4,s4,a2
    8020445c:	40f989b3          	sub	s3,s3,a5
    80204460:	f93779e3          	bgeu	a4,s3,802043f2 <exec+0xdc>
    80204464:	89ba                	mv	s3,a4
    80204466:	b771                	j	802043f2 <exec+0xdc>
                pfree(mem);
    80204468:	854a                	mv	a0,s2
    8020446a:	ffffd097          	auipc	ra,0xffffd
    8020446e:	d08080e7          	jalr	-760(ra) # 80201172 <pfree>
                return -1;
    80204472:	a241                	j	802045f2 <exec+0x2dc>
            pfree(mem);
    80204474:	854a                	mv	a0,s2
    80204476:	ffffd097          	auipc	ra,0xffffd
    8020447a:	cfc080e7          	jalr	-772(ra) # 80201172 <pfree>
            return -1;
    8020447e:	aa95                	j	802045f2 <exec+0x2dc>
        if (ph.vaddr + ph.memsz > sz) sz = ph.vaddr + ph.memsz;
    80204480:	ea043783          	ld	a5,-352(s0)
    80204484:	eb843703          	ld	a4,-328(s0)
    80204488:	97ba                	add	a5,a5,a4
    8020448a:	e8843703          	ld	a4,-376(s0)
    8020448e:	00f77463          	bgeu	a4,a5,80204496 <exec+0x180>
    80204492:	e8f43423          	sd	a5,-376(s0)
    for (int i = 0; i < eh.phnum; i++) {
    80204496:	2d05                	addiw	s10,s10,1 # 1001 <_entry-0x801fefff>
    80204498:	038c8c9b          	addiw	s9,s9,56
    8020449c:	f8845783          	lhu	a5,-120(s0)
    802044a0:	08fd5563          	bge	s10,a5,8020452a <exec+0x214>
        if (readi(ip, 0, (uint64)&ph, eh.phoff + i * sizeof(ph),
    802044a4:	03800713          	li	a4,56
    802044a8:	f7043683          	ld	a3,-144(s0)
    802044ac:	019686bb          	addw	a3,a3,s9
    802044b0:	e9040613          	addi	a2,s0,-368
    802044b4:	4581                	li	a1,0
    802044b6:	855a                	mv	a0,s6
    802044b8:	00001097          	auipc	ra,0x1
    802044bc:	e36080e7          	jalr	-458(ra) # 802052ee <readi>
    802044c0:	03800793          	li	a5,56
    802044c4:	12f51763          	bne	a0,a5,802045f2 <exec+0x2dc>
        if (ph.type != ELF_PROG_LOAD) continue;
    802044c8:	e9042783          	lw	a5,-368(s0)
    802044cc:	fdb795e3          	bne	a5,s11,80204496 <exec+0x180>
        if (ph.memsz < ph.filesz) goto bad;           /* malformed */
    802044d0:	eb843a83          	ld	s5,-328(s0)
    802044d4:	eb043783          	ld	a5,-336(s0)
    802044d8:	10faed63          	bltu	s5,a5,802045f2 <exec+0x2dc>
        if (ph.vaddr + ph.memsz < ph.vaddr) goto bad; /* overflow  */
    802044dc:	ea043483          	ld	s1,-352(s0)
    802044e0:	9aa6                	add	s5,s5,s1
    802044e2:	109ae863          	bltu	s5,s1,802045f2 <exec+0x2dc>
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    802044e6:	e7043783          	ld	a5,-400(s0)
    802044ea:	1157e463          	bltu	a5,s5,802045f2 <exec+0x2dc>
    if (ph->flags & ELF_PROG_FLAG_READ)  perm |= PTE_R;
    802044ee:	e9442783          	lw	a5,-364(s0)
    802044f2:	0047f713          	andi	a4,a5,4
    802044f6:	4bc9                	li	s7,18
    802044f8:	e311                	bnez	a4,802044fc <exec+0x1e6>
    int perm = PTE_U;
    802044fa:	4bc1                	li	s7,16
    if (ph->flags & ELF_PROG_FLAG_WRITE) perm |= PTE_W;
    802044fc:	0027f713          	andi	a4,a5,2
    80204500:	c319                	beqz	a4,80204506 <exec+0x1f0>
    80204502:	004beb93          	ori	s7,s7,4
    if (ph->flags & ELF_PROG_FLAG_EXEC)  perm |= PTE_X;
    80204506:	8b85                	andi	a5,a5,1
    80204508:	0037979b          	slliw	a5,a5,0x3
    8020450c:	00fbebb3          	or	s7,s7,a5
    80204510:	2b81                	sext.w	s7,s7
    uint64 start = PGROUNDDOWN(ph->vaddr);
    80204512:	77fd                	lui	a5,0xfffff
    80204514:	8cfd                	and	s1,s1,a5
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    80204516:	e6843703          	ld	a4,-408(s0)
    8020451a:	9aba                	add	s5,s5,a4
    8020451c:	00fafab3          	and	s5,s5,a5
    for (uint64 va = start; va < end; va += PGSIZE) {
    80204520:	f154e4e3          	bltu	s1,s5,80204428 <exec+0x112>
    80204524:	bfb1                	j	80204480 <exec+0x16a>
    uint64 sz = 0;
    80204526:	e8043423          	sd	zero,-376(s0)
    iunlockput(ip);
    8020452a:	855a                	mv	a0,s6
    8020452c:	00001097          	auipc	ra,0x1
    80204530:	d70080e7          	jalr	-656(ra) # 8020529c <iunlockput>
    sz = PGROUNDUP(sz);
    80204534:	6785                	lui	a5,0x1
    80204536:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80204538:	e8843703          	ld	a4,-376(s0)
    8020453c:	97ba                	add	a5,a5,a4
    8020453e:	7dfd                	lui	s11,0xfffff
    80204540:	01b7f4b3          	and	s1,a5,s11
    80204544:	e8943423          	sd	s1,-376(s0)
    char *stack = palloc();
    80204548:	ffffd097          	auipc	ra,0xffffd
    8020454c:	b1a080e7          	jalr	-1254(ra) # 80201062 <palloc>
    80204550:	8b2a                	mv	s6,a0
    if (!stack) goto bad;
    80204552:	c145                	beqz	a0,802045f2 <exec+0x2dc>
    uint64 stackbase = guard + PGSIZE;
    80204554:	6a85                	lui	s5,0x1
    80204556:	9aa6                	add	s5,s5,s1
    memset(stack, 0, PGSIZE);
    80204558:	6605                	lui	a2,0x1
    8020455a:	4581                	li	a1,0
    8020455c:	ffffc097          	auipc	ra,0xffffc
    80204560:	104080e7          	jalr	260(ra) # 80200660 <memset>
    if (mappages(newpt, stackbase, PGSIZE, (uint64)stack,
    80204564:	4759                	li	a4,22
    80204566:	86da                	mv	a3,s6
    80204568:	6605                	lui	a2,0x1
    8020456a:	85d6                	mv	a1,s5
    8020456c:	8562                	mv	a0,s8
    8020456e:	ffffe097          	auipc	ra,0xffffe
    80204572:	566080e7          	jalr	1382(ra) # 80202ad4 <mappages>
    80204576:	84aa                	mv	s1,a0
    80204578:	e505                	bnez	a0,802045a0 <exec+0x28a>
    uint64 sp    = stackbase + PGSIZE;
    8020457a:	6789                	lui	a5,0x2
    8020457c:	e8843703          	ld	a4,-376(s0)
    80204580:	00f70d33          	add	s10,a4,a5
    struct proc *pp = myproc();
    80204584:	ffffd097          	auipc	ra,0xffffd
    80204588:	156080e7          	jalr	342(ra) # 802016da <myproc>
    8020458c:	8baa                	mv	s7,a0
    for (; argv && argv[argc]; argc++) {
    8020458e:	e7843783          	ld	a5,-392(s0)
    80204592:	c7c9                	beqz	a5,8020461c <exec+0x306>
    80204594:	893e                	mv	s2,a5
    80204596:	ec840a13          	addi	s4,s0,-312
    uint64 sp    = stackbase + PGSIZE;
    8020459a:	89ea                	mv	s3,s10
        if (argc >= MAXARG) goto bad;
    8020459c:	4cc1                	li	s9,16
    8020459e:	a821                	j	802045b6 <exec+0x2a0>
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    802045a0:	855a                	mv	a0,s6
    802045a2:	ffffd097          	auipc	ra,0xffffd
    802045a6:	bd0080e7          	jalr	-1072(ra) # 80201172 <pfree>
    ip = 0;
    802045aa:	4b01                	li	s6,0
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    802045ac:	a099                	j	802045f2 <exec+0x2dc>
        ustack[argc] = sp;
    802045ae:	013a3023          	sd	s3,0(s4)
    for (; argv && argv[argc]; argc++) {
    802045b2:	2485                	addiw	s1,s1,1
    802045b4:	0a21                	addi	s4,s4,8
    802045b6:	8b4a                	mv	s6,s2
    802045b8:	00093503          	ld	a0,0(s2)
    802045bc:	c12d                	beqz	a0,8020461e <exec+0x308>
        if (argc >= MAXARG) goto bad;
    802045be:	03948963          	beq	s1,s9,802045f0 <exec+0x2da>
        uint64 len = strlen(argv[argc]) + 1;
    802045c2:	ffffc097          	auipc	ra,0xffffc
    802045c6:	19c080e7          	jalr	412(ra) # 8020075e <strlen>
    802045ca:	0015069b          	addiw	a3,a0,1
        sp -= len;
    802045ce:	40d989b3          	sub	s3,s3,a3
        sp &= ~7UL;                                   /* keep it 8-aligned */
    802045d2:	ff89f993          	andi	s3,s3,-8
        if (sp < stackbase) goto bad;
    802045d6:	0159ed63          	bltu	s3,s5,802045f0 <exec+0x2da>
        if (copyout(newpt, sp, argv[argc], len) < 0) goto bad;
    802045da:	000b3603          	ld	a2,0(s6) # 1000 <_entry-0x801ff000>
    802045de:	85ce                	mv	a1,s3
    802045e0:	8562                	mv	a0,s8
    802045e2:	fffff097          	auipc	ra,0xfffff
    802045e6:	8cc080e7          	jalr	-1844(ra) # 80202eae <copyout>
    802045ea:	0921                	addi	s2,s2,8
    802045ec:	fc0551e3          	bgez	a0,802045ae <exec+0x298>
    if (newpt) uvmfree(newpt, sz);
    802045f0:	4b01                	li	s6,0
    802045f2:	e8843583          	ld	a1,-376(s0)
    802045f6:	8562                	mv	a0,s8
    802045f8:	ffffe097          	auipc	ra,0xffffe
    802045fc:	7ae080e7          	jalr	1966(ra) # 80202da6 <uvmfree>
    return -1;
    80204600:	54fd                	li	s1,-1
    if (ip) iunlockput(ip);
    80204602:	0e0b1463          	bnez	s6,802046ea <exec+0x3d4>
    80204606:	691a                	ld	s2,384(sp)
    80204608:	79f6                	ld	s3,376(sp)
    8020460a:	7a56                	ld	s4,368(sp)
    8020460c:	7ab6                	ld	s5,360(sp)
    8020460e:	7b16                	ld	s6,352(sp)
    80204610:	6bf6                	ld	s7,344(sp)
    80204612:	6c56                	ld	s8,336(sp)
    80204614:	6cb6                	ld	s9,328(sp)
    80204616:	6d16                	ld	s10,320(sp)
    80204618:	7df2                	ld	s11,312(sp)
    8020461a:	bb8d                	j	8020438c <exec+0x76>
    uint64 sp    = stackbase + PGSIZE;
    8020461c:	89ea                	mv	s3,s10
    ustack[argc] = 0;
    8020461e:	00349793          	slli	a5,s1,0x3
    80204622:	f9078793          	addi	a5,a5,-112 # 1f90 <_entry-0x801fe070>
    80204626:	97a2                	add	a5,a5,s0
    80204628:	f207bc23          	sd	zero,-200(a5)
    sp -= (argc + 1) * sizeof(uint64);
    8020462c:	0014869b          	addiw	a3,s1,1
    80204630:	068e                	slli	a3,a3,0x3
    80204632:	40d98933          	sub	s2,s3,a3
    sp &= ~15UL;                                      /* 16-byte ABI alignment */
    80204636:	ff097913          	andi	s2,s2,-16
    ip = 0;
    8020463a:	4b01                	li	s6,0
    if (sp < stackbase) goto bad;
    8020463c:	fb596be3          	bltu	s2,s5,802045f2 <exec+0x2dc>
    if (copyout(newpt, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) < 0) goto bad;
    80204640:	ec840613          	addi	a2,s0,-312
    80204644:	85ca                	mv	a1,s2
    80204646:	8562                	mv	a0,s8
    80204648:	fffff097          	auipc	ra,0xfffff
    8020464c:	866080e7          	jalr	-1946(ra) # 80202eae <copyout>
    80204650:	0a054b63          	bltz	a0,80204706 <exec+0x3f0>
    pagetable_t oldpt = pp->pagetable;
    80204654:	050bb983          	ld	s3,80(s7) # 1050 <_entry-0x801fefb0>
    uint64      oldsz = pp->sz;
    80204658:	048bba03          	ld	s4,72(s7)
    pp->pagetable = newpt;
    8020465c:	058bb823          	sd	s8,80(s7)
    pp->sz        = newsz;
    80204660:	05abb423          	sd	s10,72(s7)
    pp->tf->epc   = eh.entry;
    80204664:	058bb783          	ld	a5,88(s7)
    80204668:	f6843703          	ld	a4,-152(s0)
    8020466c:	ef98                	sd	a4,24(a5)
    pp->tf->sp    = sp;
    8020466e:	058bb783          	ld	a5,88(s7)
    80204672:	0327b823          	sd	s2,48(a5)
    pp->tf->a1    = sp;                               /* argv for main() */
    80204676:	058bb783          	ld	a5,88(s7)
    8020467a:	0727bc23          	sd	s2,120(a5)
    for (const char *s = path; *s; s++) if (*s == '/') last = s + 1;
    8020467e:	e8043783          	ld	a5,-384(s0)
    80204682:	0007c703          	lbu	a4,0(a5)
    80204686:	cf11                	beqz	a4,802046a2 <exec+0x38c>
    80204688:	0785                	addi	a5,a5,1
    8020468a:	02f00693          	li	a3,47
    8020468e:	a039                	j	8020469c <exec+0x386>
    80204690:	e8f43023          	sd	a5,-384(s0)
    80204694:	0785                	addi	a5,a5,1
    80204696:	fff7c703          	lbu	a4,-1(a5)
    8020469a:	c701                	beqz	a4,802046a2 <exec+0x38c>
    8020469c:	fed71ce3          	bne	a4,a3,80204694 <exec+0x37e>
    802046a0:	bfc5                	j	80204690 <exec+0x37a>
    strncpy(pp->name, last, sizeof(pp->name));
    802046a2:	4641                	li	a2,16
    802046a4:	e8043583          	ld	a1,-384(s0)
    802046a8:	158b8513          	addi	a0,s7,344
    802046ac:	ffffc097          	auipc	ra,0xffffc
    802046b0:	076080e7          	jalr	118(ra) # 80200722 <strncpy>
    w_satp(MAKE_SATP(pp->pagetable));                 /* we are running on it now */
    802046b4:	050bb783          	ld	a5,80(s7)
    802046b8:	83b1                	srli	a5,a5,0xc
    802046ba:	577d                	li	a4,-1
    802046bc:	177e                	slli	a4,a4,0x3f
    802046be:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    802046c0:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    802046c4:	12000073          	sfence.vma
    uvmfree(oldpt, oldsz);
    802046c8:	85d2                	mv	a1,s4
    802046ca:	854e                	mv	a0,s3
    802046cc:	ffffe097          	auipc	ra,0xffffe
    802046d0:	6da080e7          	jalr	1754(ra) # 80202da6 <uvmfree>
    return argc;
    802046d4:	691a                	ld	s2,384(sp)
    802046d6:	79f6                	ld	s3,376(sp)
    802046d8:	7a56                	ld	s4,368(sp)
    802046da:	7ab6                	ld	s5,360(sp)
    802046dc:	7b16                	ld	s6,352(sp)
    802046de:	6bf6                	ld	s7,344(sp)
    802046e0:	6c56                	ld	s8,336(sp)
    802046e2:	6cb6                	ld	s9,328(sp)
    802046e4:	6d16                	ld	s10,320(sp)
    802046e6:	7df2                	ld	s11,312(sp)
    802046e8:	b155                	j	8020438c <exec+0x76>
    802046ea:	691a                	ld	s2,384(sp)
    802046ec:	79f6                	ld	s3,376(sp)
    802046ee:	7a56                	ld	s4,368(sp)
    802046f0:	7ab6                	ld	s5,360(sp)
    802046f2:	6bf6                	ld	s7,344(sp)
    802046f4:	6c56                	ld	s8,336(sp)
    802046f6:	6cb6                	ld	s9,328(sp)
    802046f8:	6d16                	ld	s10,320(sp)
    802046fa:	7df2                	ld	s11,312(sp)
    802046fc:	b149                	j	8020437e <exec+0x68>
    802046fe:	6c56                	ld	s8,336(sp)
    80204700:	b9bd                	j	8020437e <exec+0x68>
    if (ip == 0) return -1;
    80204702:	54fd                	li	s1,-1
    80204704:	b161                	j	8020438c <exec+0x76>
    ip = 0;
    80204706:	4b01                	li	s6,0
    if (newpt) uvmfree(newpt, sz);
    80204708:	b5ed                	j	802045f2 <exec+0x2dc>

000000008020470a <binit>:
    struct buf buf[NBUF];
    struct buf head;          /* LRU list: head.next = most recent */
} bcache;

void binit(void)
{
    8020470a:	7179                	addi	sp,sp,-48
    8020470c:	f406                	sd	ra,40(sp)
    8020470e:	f022                	sd	s0,32(sp)
    80204710:	ec26                	sd	s1,24(sp)
    80204712:	e84a                	sd	s2,16(sp)
    80204714:	e44e                	sd	s3,8(sp)
    80204716:	e052                	sd	s4,0(sp)
    80204718:	1800                	addi	s0,sp,48
    initlock(&bcache.lock, "bcache");
    8020471a:	00003597          	auipc	a1,0x3
    8020471e:	25e58593          	addi	a1,a1,606 # 80207978 <etext+0x978>
    80204722:	0012c517          	auipc	a0,0x12c
    80204726:	39e50513          	addi	a0,a0,926 # 80330ac0 <bcache>
    8020472a:	ffffd097          	auipc	ra,0xffffd
    8020472e:	b4a080e7          	jalr	-1206(ra) # 80201274 <initlock>
    bcache.head.prev = &bcache.head;
    80204732:	00134797          	auipc	a5,0x134
    80204736:	38e78793          	addi	a5,a5,910 # 80338ac0 <bcache+0x8000>
    8020473a:	00134717          	auipc	a4,0x134
    8020473e:	5ee70713          	addi	a4,a4,1518 # 80338d28 <bcache+0x8268>
    80204742:	2ae7b823          	sd	a4,688(a5)
    bcache.head.next = &bcache.head;
    80204746:	2ae7bc23          	sd	a4,696(a5)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    8020474a:	0012c497          	auipc	s1,0x12c
    8020474e:	38e48493          	addi	s1,s1,910 # 80330ad8 <bcache+0x18>
        b->next = bcache.head.next;
    80204752:	893e                	mv	s2,a5
        b->prev = &bcache.head;
    80204754:	89ba                	mv	s3,a4
        initsleeplock(&b->lock, "buffer");
    80204756:	00003a17          	auipc	s4,0x3
    8020475a:	22aa0a13          	addi	s4,s4,554 # 80207980 <etext+0x980>
        b->next = bcache.head.next;
    8020475e:	2b893783          	ld	a5,696(s2)
    80204762:	e8bc                	sd	a5,80(s1)
        b->prev = &bcache.head;
    80204764:	0534b423          	sd	s3,72(s1)
        initsleeplock(&b->lock, "buffer");
    80204768:	85d2                	mv	a1,s4
    8020476a:	01048513          	addi	a0,s1,16
    8020476e:	ffffd097          	auipc	ra,0xffffd
    80204772:	c7e080e7          	jalr	-898(ra) # 802013ec <initsleeplock>
        bcache.head.next->prev = b;
    80204776:	2b893783          	ld	a5,696(s2)
    8020477a:	e7a4                	sd	s1,72(a5)
        bcache.head.next = b;
    8020477c:	2a993c23          	sd	s1,696(s2)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80204780:	45848493          	addi	s1,s1,1112
    80204784:	fd349de3          	bne	s1,s3,8020475e <binit+0x54>
    }
}
    80204788:	70a2                	ld	ra,40(sp)
    8020478a:	7402                	ld	s0,32(sp)
    8020478c:	64e2                	ld	s1,24(sp)
    8020478e:	6942                	ld	s2,16(sp)
    80204790:	69a2                	ld	s3,8(sp)
    80204792:	6a02                	ld	s4,0(sp)
    80204794:	6145                	addi	sp,sp,48
    80204796:	8082                	ret

0000000080204798 <bread>:
    }
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
}

struct buf *bread(uint32 dev, uint32 blockno)
{
    80204798:	7179                	addi	sp,sp,-48
    8020479a:	f406                	sd	ra,40(sp)
    8020479c:	f022                	sd	s0,32(sp)
    8020479e:	ec26                	sd	s1,24(sp)
    802047a0:	e84a                	sd	s2,16(sp)
    802047a2:	e44e                	sd	s3,8(sp)
    802047a4:	1800                	addi	s0,sp,48
    802047a6:	892a                	mv	s2,a0
    802047a8:	89ae                	mv	s3,a1
    acquire(&bcache.lock);
    802047aa:	0012c517          	auipc	a0,0x12c
    802047ae:	31650513          	addi	a0,a0,790 # 80330ac0 <bcache>
    802047b2:	ffffd097          	auipc	ra,0xffffd
    802047b6:	b3e080e7          	jalr	-1218(ra) # 802012f0 <acquire>
    for (struct buf *b = bcache.head.next; b != &bcache.head; b = b->next) {
    802047ba:	00134497          	auipc	s1,0x134
    802047be:	5be4b483          	ld	s1,1470(s1) # 80338d78 <bcache+0x82b8>
    802047c2:	00134797          	auipc	a5,0x134
    802047c6:	56678793          	addi	a5,a5,1382 # 80338d28 <bcache+0x8268>
    802047ca:	02f48f63          	beq	s1,a5,80204808 <bread+0x70>
    802047ce:	873e                	mv	a4,a5
    802047d0:	a021                	j	802047d8 <bread+0x40>
    802047d2:	68a4                	ld	s1,80(s1)
    802047d4:	02e48a63          	beq	s1,a4,80204808 <bread+0x70>
        if (b->dev == dev && b->blockno == blockno) {
    802047d8:	449c                	lw	a5,8(s1)
    802047da:	ff279ce3          	bne	a5,s2,802047d2 <bread+0x3a>
    802047de:	44dc                	lw	a5,12(s1)
    802047e0:	ff3799e3          	bne	a5,s3,802047d2 <bread+0x3a>
            b->refcnt++;
    802047e4:	40bc                	lw	a5,64(s1)
    802047e6:	2785                	addiw	a5,a5,1
    802047e8:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    802047ea:	0012c517          	auipc	a0,0x12c
    802047ee:	2d650513          	addi	a0,a0,726 # 80330ac0 <bcache>
    802047f2:	ffffd097          	auipc	ra,0xffffd
    802047f6:	bb2080e7          	jalr	-1102(ra) # 802013a4 <release>
            acquiresleep(&b->lock);
    802047fa:	01048513          	addi	a0,s1,16
    802047fe:	ffffd097          	auipc	ra,0xffffd
    80204802:	c28080e7          	jalr	-984(ra) # 80201426 <acquiresleep>
            return b;
    80204806:	a8b9                	j	80204864 <bread+0xcc>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80204808:	00134497          	auipc	s1,0x134
    8020480c:	5684b483          	ld	s1,1384(s1) # 80338d70 <bcache+0x82b0>
    80204810:	00134797          	auipc	a5,0x134
    80204814:	51878793          	addi	a5,a5,1304 # 80338d28 <bcache+0x8268>
    80204818:	00f48863          	beq	s1,a5,80204828 <bread+0x90>
    8020481c:	873e                	mv	a4,a5
        if (b->refcnt == 0) {
    8020481e:	40bc                	lw	a5,64(s1)
    80204820:	cf81                	beqz	a5,80204838 <bread+0xa0>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80204822:	64a4                	ld	s1,72(s1)
    80204824:	fee49de3          	bne	s1,a4,8020481e <bread+0x86>
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
    80204828:	00003517          	auipc	a0,0x3
    8020482c:	16050513          	addi	a0,a0,352 # 80207988 <etext+0x988>
    80204830:	ffffc097          	auipc	ra,0xffffc
    80204834:	d8a080e7          	jalr	-630(ra) # 802005ba <panic>
            b->dev = dev;
    80204838:	0124a423          	sw	s2,8(s1)
            b->blockno = blockno;
    8020483c:	0134a623          	sw	s3,12(s1)
            b->valid = 0;
    80204840:	0004a023          	sw	zero,0(s1)
            b->refcnt = 1;
    80204844:	4785                	li	a5,1
    80204846:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    80204848:	0012c517          	auipc	a0,0x12c
    8020484c:	27850513          	addi	a0,a0,632 # 80330ac0 <bcache>
    80204850:	ffffd097          	auipc	ra,0xffffd
    80204854:	b54080e7          	jalr	-1196(ra) # 802013a4 <release>
            acquiresleep(&b->lock);
    80204858:	01048513          	addi	a0,s1,16
    8020485c:	ffffd097          	auipc	ra,0xffffd
    80204860:	bca080e7          	jalr	-1078(ra) # 80201426 <acquiresleep>
    struct buf *b = bget(dev, blockno);
    if (!b->valid) {
    80204864:	409c                	lw	a5,0(s1)
    80204866:	cb89                	beqz	a5,80204878 <bread+0xe0>
        hal_block_rw(b, 0);
        b->valid = 1;
    }
    return b;
}
    80204868:	8526                	mv	a0,s1
    8020486a:	70a2                	ld	ra,40(sp)
    8020486c:	7402                	ld	s0,32(sp)
    8020486e:	64e2                	ld	s1,24(sp)
    80204870:	6942                	ld	s2,16(sp)
    80204872:	69a2                	ld	s3,8(sp)
    80204874:	6145                	addi	sp,sp,48
    80204876:	8082                	ret
        hal_block_rw(b, 0);
    80204878:	4581                	li	a1,0
    8020487a:	8526                	mv	a0,s1
    8020487c:	00002097          	auipc	ra,0x2
    80204880:	c46080e7          	jalr	-954(ra) # 802064c2 <hal_block_rw>
        b->valid = 1;
    80204884:	4785                	li	a5,1
    80204886:	c09c                	sw	a5,0(s1)
    return b;
    80204888:	b7c5                	j	80204868 <bread+0xd0>

000000008020488a <bwrite>:

/* Caller must hold b->lock (i.e. this buf came from bread). */
void bwrite(struct buf *b)
{
    8020488a:	1101                	addi	sp,sp,-32
    8020488c:	ec06                	sd	ra,24(sp)
    8020488e:	e822                	sd	s0,16(sp)
    80204890:	e426                	sd	s1,8(sp)
    80204892:	1000                	addi	s0,sp,32
    80204894:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80204896:	0541                	addi	a0,a0,16
    80204898:	ffffd097          	auipc	ra,0xffffd
    8020489c:	c28080e7          	jalr	-984(ra) # 802014c0 <holdingsleep>
    802048a0:	cd01                	beqz	a0,802048b8 <bwrite+0x2e>
    hal_block_rw(b, 1);
    802048a2:	4585                	li	a1,1
    802048a4:	8526                	mv	a0,s1
    802048a6:	00002097          	auipc	ra,0x2
    802048aa:	c1c080e7          	jalr	-996(ra) # 802064c2 <hal_block_rw>
}
    802048ae:	60e2                	ld	ra,24(sp)
    802048b0:	6442                	ld	s0,16(sp)
    802048b2:	64a2                	ld	s1,8(sp)
    802048b4:	6105                	addi	sp,sp,32
    802048b6:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    802048b8:	00003517          	auipc	a0,0x3
    802048bc:	11050513          	addi	a0,a0,272 # 802079c8 <etext+0x9c8>
    802048c0:	ffffc097          	auipc	ra,0xffffc
    802048c4:	cfa080e7          	jalr	-774(ra) # 802005ba <panic>

00000000802048c8 <brelse>:

void brelse(struct buf *b)
{
    802048c8:	1101                	addi	sp,sp,-32
    802048ca:	ec06                	sd	ra,24(sp)
    802048cc:	e822                	sd	s0,16(sp)
    802048ce:	e426                	sd	s1,8(sp)
    802048d0:	e04a                	sd	s2,0(sp)
    802048d2:	1000                	addi	s0,sp,32
    802048d4:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    802048d6:	01050913          	addi	s2,a0,16
    802048da:	854a                	mv	a0,s2
    802048dc:	ffffd097          	auipc	ra,0xffffd
    802048e0:	be4080e7          	jalr	-1052(ra) # 802014c0 <holdingsleep>
    802048e4:	c925                	beqz	a0,80204954 <brelse+0x8c>
    releasesleep(&b->lock);
    802048e6:	854a                	mv	a0,s2
    802048e8:	ffffd097          	auipc	ra,0xffffd
    802048ec:	b94080e7          	jalr	-1132(ra) # 8020147c <releasesleep>

    acquire(&bcache.lock);
    802048f0:	0012c517          	auipc	a0,0x12c
    802048f4:	1d050513          	addi	a0,a0,464 # 80330ac0 <bcache>
    802048f8:	ffffd097          	auipc	ra,0xffffd
    802048fc:	9f8080e7          	jalr	-1544(ra) # 802012f0 <acquire>
    b->refcnt--;
    80204900:	40bc                	lw	a5,64(s1)
    80204902:	37fd                	addiw	a5,a5,-1
    80204904:	0007871b          	sext.w	a4,a5
    80204908:	c0bc                	sw	a5,64(s1)
    if (b->refcnt == 0) {
    8020490a:	e71d                	bnez	a4,80204938 <brelse+0x70>
        /* Move to the front: most recently used. */
        b->next->prev = b->prev;
    8020490c:	68b8                	ld	a4,80(s1)
    8020490e:	64bc                	ld	a5,72(s1)
    80204910:	e73c                	sd	a5,72(a4)
        b->prev->next = b->next;
    80204912:	68b8                	ld	a4,80(s1)
    80204914:	ebb8                	sd	a4,80(a5)
        b->next = bcache.head.next;
    80204916:	00134797          	auipc	a5,0x134
    8020491a:	1aa78793          	addi	a5,a5,426 # 80338ac0 <bcache+0x8000>
    8020491e:	2b87b703          	ld	a4,696(a5)
    80204922:	e8b8                	sd	a4,80(s1)
        b->prev = &bcache.head;
    80204924:	00134717          	auipc	a4,0x134
    80204928:	40470713          	addi	a4,a4,1028 # 80338d28 <bcache+0x8268>
    8020492c:	e4b8                	sd	a4,72(s1)
        bcache.head.next->prev = b;
    8020492e:	2b87b703          	ld	a4,696(a5)
    80204932:	e724                	sd	s1,72(a4)
        bcache.head.next = b;
    80204934:	2a97bc23          	sd	s1,696(a5)
    }
    release(&bcache.lock);
    80204938:	0012c517          	auipc	a0,0x12c
    8020493c:	18850513          	addi	a0,a0,392 # 80330ac0 <bcache>
    80204940:	ffffd097          	auipc	ra,0xffffd
    80204944:	a64080e7          	jalr	-1436(ra) # 802013a4 <release>
}
    80204948:	60e2                	ld	ra,24(sp)
    8020494a:	6442                	ld	s0,16(sp)
    8020494c:	64a2                	ld	s1,8(sp)
    8020494e:	6902                	ld	s2,0(sp)
    80204950:	6105                	addi	sp,sp,32
    80204952:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80204954:	00003517          	auipc	a0,0x3
    80204958:	08c50513          	addi	a0,a0,140 # 802079e0 <etext+0x9e0>
    8020495c:	ffffc097          	auipc	ra,0xffffc
    80204960:	c5e080e7          	jalr	-930(ra) # 802005ba <panic>

0000000080204964 <bfree>:
    printf("luitfs: out of data blocks\n");
    return 0;
}

static void bfree(int dev, uint32 b)
{
    80204964:	1101                	addi	sp,sp,-32
    80204966:	ec06                	sd	ra,24(sp)
    80204968:	e822                	sd	s0,16(sp)
    8020496a:	e426                	sd	s1,8(sp)
    8020496c:	e04a                	sd	s2,0(sp)
    8020496e:	1000                	addi	s0,sp,32
    80204970:	84ae                	mv	s1,a1
    struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204972:	00d5d59b          	srliw	a1,a1,0xd
    80204976:	00135797          	auipc	a5,0x135
    8020497a:	8227a783          	lw	a5,-2014(a5) # 80339198 <sb+0x18>
    8020497e:	9dbd                	addw	a1,a1,a5
    80204980:	00000097          	auipc	ra,0x0
    80204984:	e18080e7          	jalr	-488(ra) # 80204798 <bread>
    uint32 bi = b % BPB;
    int m = 1 << (bi % 8);
    80204988:	0074f713          	andi	a4,s1,7
    8020498c:	4785                	li	a5,1
    8020498e:	00e797bb          	sllw	a5,a5,a4
    uint32 bi = b % BPB;
    80204992:	14ce                	slli	s1,s1,0x33
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80204994:	0364d713          	srli	a4,s1,0x36
    80204998:	00e504b3          	add	s1,a0,a4
    8020499c:	0584c683          	lbu	a3,88(s1)
    802049a0:	00d7f633          	and	a2,a5,a3
    802049a4:	ca0d                	beqz	a2,802049d6 <bfree+0x72>
    802049a6:	892a                	mv	s2,a0
    bp->data[bi / 8] &= ~m;
    802049a8:	1702                	slli	a4,a4,0x20
    802049aa:	9301                	srli	a4,a4,0x20
    802049ac:	972a                	add	a4,a4,a0
    802049ae:	fff7c793          	not	a5,a5
    802049b2:	8efd                	and	a3,a3,a5
    802049b4:	04d70c23          	sb	a3,88(a4)
    bwrite(bp);
    802049b8:	00000097          	auipc	ra,0x0
    802049bc:	ed2080e7          	jalr	-302(ra) # 8020488a <bwrite>
    brelse(bp);
    802049c0:	854a                	mv	a0,s2
    802049c2:	00000097          	auipc	ra,0x0
    802049c6:	f06080e7          	jalr	-250(ra) # 802048c8 <brelse>
}
    802049ca:	60e2                	ld	ra,24(sp)
    802049cc:	6442                	ld	s0,16(sp)
    802049ce:	64a2                	ld	s1,8(sp)
    802049d0:	6902                	ld	s2,0(sp)
    802049d2:	6105                	addi	sp,sp,32
    802049d4:	8082                	ret
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    802049d6:	00003517          	auipc	a0,0x3
    802049da:	02250513          	addi	a0,a0,34 # 802079f8 <etext+0x9f8>
    802049de:	ffffc097          	auipc	ra,0xffffc
    802049e2:	bdc080e7          	jalr	-1060(ra) # 802005ba <panic>

00000000802049e6 <balloc>:
{
    802049e6:	711d                	addi	sp,sp,-96
    802049e8:	ec86                	sd	ra,88(sp)
    802049ea:	e8a2                	sd	s0,80(sp)
    802049ec:	e4a6                	sd	s1,72(sp)
    802049ee:	1080                	addi	s0,sp,96
    for (uint32 b = 0; b < sb.size; b += BPB) {
    802049f0:	00134797          	auipc	a5,0x134
    802049f4:	7987a783          	lw	a5,1944(a5) # 80339188 <sb+0x8>
    802049f8:	10078463          	beqz	a5,80204b00 <balloc+0x11a>
    802049fc:	e0ca                	sd	s2,64(sp)
    802049fe:	fc4e                	sd	s3,56(sp)
    80204a00:	f852                	sd	s4,48(sp)
    80204a02:	f456                	sd	s5,40(sp)
    80204a04:	f05a                	sd	s6,32(sp)
    80204a06:	ec5e                	sd	s7,24(sp)
    80204a08:	e862                	sd	s8,16(sp)
    80204a0a:	e466                	sd	s9,8(sp)
    80204a0c:	8baa                	mv	s7,a0
    80204a0e:	4a81                	li	s5,0
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204a10:	00134b17          	auipc	s6,0x134
    80204a14:	770b0b13          	addi	s6,s6,1904 # 80339180 <sb>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204a18:	4c01                	li	s8,0
            int m = 1 << (bi % 8);
    80204a1a:	4985                	li	s3,1
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204a1c:	6a09                	lui	s4,0x2
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80204a1e:	6c89                	lui	s9,0x2
    80204a20:	a061                	j	80204aa8 <balloc+0xc2>
                bp->data[bi / 8] |= m;              /* claim it... */
    80204a22:	1582                	slli	a1,a1,0x20
    80204a24:	9181                	srli	a1,a1,0x20
    80204a26:	95ca                	add	a1,a1,s2
    80204a28:	8ed9                	or	a3,a3,a4
    80204a2a:	04d58c23          	sb	a3,88(a1)
                bwrite(bp);                         /* ...ON DISK, before use */
    80204a2e:	854a                	mv	a0,s2
    80204a30:	00000097          	auipc	ra,0x0
    80204a34:	e5a080e7          	jalr	-422(ra) # 8020488a <bwrite>
                brelse(bp);
    80204a38:	854a                	mv	a0,s2
    80204a3a:	00000097          	auipc	ra,0x0
    80204a3e:	e8e080e7          	jalr	-370(ra) # 802048c8 <brelse>
    struct buf *bp = bread(dev, bno);
    80204a42:	85a6                	mv	a1,s1
    80204a44:	855e                	mv	a0,s7
    80204a46:	00000097          	auipc	ra,0x0
    80204a4a:	d52080e7          	jalr	-686(ra) # 80204798 <bread>
    80204a4e:	892a                	mv	s2,a0
    memset(bp->data, 0, BSIZE);
    80204a50:	40000613          	li	a2,1024
    80204a54:	4581                	li	a1,0
    80204a56:	05850513          	addi	a0,a0,88
    80204a5a:	ffffc097          	auipc	ra,0xffffc
    80204a5e:	c06080e7          	jalr	-1018(ra) # 80200660 <memset>
    bwrite(bp);
    80204a62:	854a                	mv	a0,s2
    80204a64:	00000097          	auipc	ra,0x0
    80204a68:	e26080e7          	jalr	-474(ra) # 8020488a <bwrite>
    brelse(bp);
    80204a6c:	854a                	mv	a0,s2
    80204a6e:	00000097          	auipc	ra,0x0
    80204a72:	e5a080e7          	jalr	-422(ra) # 802048c8 <brelse>
}
    80204a76:	6906                	ld	s2,64(sp)
    80204a78:	79e2                	ld	s3,56(sp)
    80204a7a:	7a42                	ld	s4,48(sp)
    80204a7c:	7aa2                	ld	s5,40(sp)
    80204a7e:	7b02                	ld	s6,32(sp)
    80204a80:	6be2                	ld	s7,24(sp)
    80204a82:	6c42                	ld	s8,16(sp)
    80204a84:	6ca2                	ld	s9,8(sp)
}
    80204a86:	8526                	mv	a0,s1
    80204a88:	60e6                	ld	ra,88(sp)
    80204a8a:	6446                	ld	s0,80(sp)
    80204a8c:	64a6                	ld	s1,72(sp)
    80204a8e:	6125                	addi	sp,sp,96
    80204a90:	8082                	ret
        brelse(bp);
    80204a92:	854a                	mv	a0,s2
    80204a94:	00000097          	auipc	ra,0x0
    80204a98:	e34080e7          	jalr	-460(ra) # 802048c8 <brelse>
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80204a9c:	015c8abb          	addw	s5,s9,s5
    80204aa0:	008b2783          	lw	a5,8(s6)
    80204aa4:	04faf663          	bgeu	s5,a5,80204af0 <balloc+0x10a>
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204aa8:	00dad59b          	srliw	a1,s5,0xd
    80204aac:	018b2783          	lw	a5,24(s6)
    80204ab0:	9dbd                	addw	a1,a1,a5
    80204ab2:	855e                	mv	a0,s7
    80204ab4:	00000097          	auipc	ra,0x0
    80204ab8:	ce4080e7          	jalr	-796(ra) # 80204798 <bread>
    80204abc:	892a                	mv	s2,a0
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204abe:	008b2503          	lw	a0,8(s6)
    80204ac2:	84d6                	mv	s1,s5
    80204ac4:	87e2                	mv	a5,s8
    80204ac6:	fca4f6e3          	bgeu	s1,a0,80204a92 <balloc+0xac>
            int m = 1 << (bi % 8);
    80204aca:	0077f713          	andi	a4,a5,7
    80204ace:	00e9973b          	sllw	a4,s3,a4
            if ((bp->data[bi / 8] & m) == 0) {
    80204ad2:	0037d59b          	srliw	a1,a5,0x3
    80204ad6:	0037d69b          	srliw	a3,a5,0x3
    80204ada:	96ca                	add	a3,a3,s2
    80204adc:	0586c683          	lbu	a3,88(a3)
    80204ae0:	00d77633          	and	a2,a4,a3
    80204ae4:	de1d                	beqz	a2,80204a22 <balloc+0x3c>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204ae6:	2785                	addiw	a5,a5,1
    80204ae8:	2485                	addiw	s1,s1,1
    80204aea:	fd479ee3          	bne	a5,s4,80204ac6 <balloc+0xe0>
    80204aee:	b755                	j	80204a92 <balloc+0xac>
    80204af0:	6906                	ld	s2,64(sp)
    80204af2:	79e2                	ld	s3,56(sp)
    80204af4:	7a42                	ld	s4,48(sp)
    80204af6:	7aa2                	ld	s5,40(sp)
    80204af8:	7b02                	ld	s6,32(sp)
    80204afa:	6be2                	ld	s7,24(sp)
    80204afc:	6c42                	ld	s8,16(sp)
    80204afe:	6ca2                	ld	s9,8(sp)
    printf("luitfs: out of data blocks\n");
    80204b00:	00003517          	auipc	a0,0x3
    80204b04:	f1850513          	addi	a0,a0,-232 # 80207a18 <etext+0xa18>
    80204b08:	ffffc097          	auipc	ra,0xffffc
    80204b0c:	840080e7          	jalr	-1984(ra) # 80200348 <printf>
    return 0;
    80204b10:	4481                	li	s1,0
    80204b12:	bf95                	j	80204a86 <balloc+0xa0>

0000000080204b14 <bmap>:
/* ---------- block mapping ---------- */

/* Return the disk block holding byte-offset block `bn` of ip, allocating it
 * (and the indirect block) on demand. 0 = out of space. Caller holds ip->lock. */
static uint32 bmap(struct inode *ip, uint32 bn)
{
    80204b14:	7179                	addi	sp,sp,-48
    80204b16:	f406                	sd	ra,40(sp)
    80204b18:	f022                	sd	s0,32(sp)
    80204b1a:	ec26                	sd	s1,24(sp)
    80204b1c:	e84a                	sd	s2,16(sp)
    80204b1e:	e44e                	sd	s3,8(sp)
    80204b20:	1800                	addi	s0,sp,48
    80204b22:	89aa                	mv	s3,a0
    if (bn < NDIRECT) {
    80204b24:	47ad                	li	a5,11
    80204b26:	02b7e863          	bltu	a5,a1,80204b56 <bmap+0x42>
        uint32 addr = ip->addrs[bn];
    80204b2a:	02059793          	slli	a5,a1,0x20
    80204b2e:	01e7d593          	srli	a1,a5,0x1e
    80204b32:	00b504b3          	add	s1,a0,a1
    80204b36:	0504a903          	lw	s2,80(s1)
        if (addr == 0) {
    80204b3a:	08091263          	bnez	s2,80204bbe <bmap+0xaa>
            addr = balloc(ip->dev);
    80204b3e:	4108                	lw	a0,0(a0)
    80204b40:	00000097          	auipc	ra,0x0
    80204b44:	ea6080e7          	jalr	-346(ra) # 802049e6 <balloc>
    80204b48:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80204b4c:	06090963          	beqz	s2,80204bbe <bmap+0xaa>
            ip->addrs[bn] = addr;
    80204b50:	0524a823          	sw	s2,80(s1)
    80204b54:	a0ad                	j	80204bbe <bmap+0xaa>
        }
        return addr;
    }
    bn -= NDIRECT;
    80204b56:	ff45849b          	addiw	s1,a1,-12
    80204b5a:	0004871b          	sext.w	a4,s1
    if (bn < NINDIRECT) {
    80204b5e:	0ff00793          	li	a5,255
    80204b62:	08e7e863          	bltu	a5,a4,80204bf2 <bmap+0xde>
        /* Implementation note. */
        uint32 addr = ip->addrs[NDIRECT];
    80204b66:	08052903          	lw	s2,128(a0)
        if (addr == 0) {
    80204b6a:	00091f63          	bnez	s2,80204b88 <bmap+0x74>
            addr = balloc(ip->dev);
    80204b6e:	4108                	lw	a0,0(a0)
    80204b70:	00000097          	auipc	ra,0x0
    80204b74:	e76080e7          	jalr	-394(ra) # 802049e6 <balloc>
    80204b78:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80204b7c:	04090163          	beqz	s2,80204bbe <bmap+0xaa>
    80204b80:	e052                	sd	s4,0(sp)
            ip->addrs[NDIRECT] = addr;
    80204b82:	0929a023          	sw	s2,128(s3)
    80204b86:	a011                	j	80204b8a <bmap+0x76>
    80204b88:	e052                	sd	s4,0(sp)
        }
        struct buf *bp = bread(ip->dev, addr);
    80204b8a:	85ca                	mv	a1,s2
    80204b8c:	0009a503          	lw	a0,0(s3)
    80204b90:	00000097          	auipc	ra,0x0
    80204b94:	c08080e7          	jalr	-1016(ra) # 80204798 <bread>
    80204b98:	8a2a                	mv	s4,a0
        uint32 *a = (uint32 *)bp->data;
    80204b9a:	05850793          	addi	a5,a0,88
        if ((addr = a[bn]) == 0) {
    80204b9e:	02049713          	slli	a4,s1,0x20
    80204ba2:	01e75593          	srli	a1,a4,0x1e
    80204ba6:	00b784b3          	add	s1,a5,a1
    80204baa:	0004a903          	lw	s2,0(s1)
    80204bae:	02090063          	beqz	s2,80204bce <bmap+0xba>
            addr = balloc(ip->dev);
            if (addr) { a[bn] = addr; bwrite(bp); }
        }
        brelse(bp);
    80204bb2:	8552                	mv	a0,s4
    80204bb4:	00000097          	auipc	ra,0x0
    80204bb8:	d14080e7          	jalr	-748(ra) # 802048c8 <brelse>
        return addr;
    80204bbc:	6a02                	ld	s4,0(sp)
    }
    panic("bmap: block number beyond MAXFILE");
}
    80204bbe:	854a                	mv	a0,s2
    80204bc0:	70a2                	ld	ra,40(sp)
    80204bc2:	7402                	ld	s0,32(sp)
    80204bc4:	64e2                	ld	s1,24(sp)
    80204bc6:	6942                	ld	s2,16(sp)
    80204bc8:	69a2                	ld	s3,8(sp)
    80204bca:	6145                	addi	sp,sp,48
    80204bcc:	8082                	ret
            addr = balloc(ip->dev);
    80204bce:	0009a503          	lw	a0,0(s3)
    80204bd2:	00000097          	auipc	ra,0x0
    80204bd6:	e14080e7          	jalr	-492(ra) # 802049e6 <balloc>
    80204bda:	0005091b          	sext.w	s2,a0
            if (addr) { a[bn] = addr; bwrite(bp); }
    80204bde:	fc090ae3          	beqz	s2,80204bb2 <bmap+0x9e>
    80204be2:	0124a023          	sw	s2,0(s1)
    80204be6:	8552                	mv	a0,s4
    80204be8:	00000097          	auipc	ra,0x0
    80204bec:	ca2080e7          	jalr	-862(ra) # 8020488a <bwrite>
    80204bf0:	b7c9                	j	80204bb2 <bmap+0x9e>
    80204bf2:	e052                	sd	s4,0(sp)
    panic("bmap: block number beyond MAXFILE");
    80204bf4:	00003517          	auipc	a0,0x3
    80204bf8:	e4450513          	addi	a0,a0,-444 # 80207a38 <etext+0xa38>
    80204bfc:	ffffc097          	auipc	ra,0xffffc
    80204c00:	9be080e7          	jalr	-1602(ra) # 802005ba <panic>

0000000080204c04 <iget>:
{
    80204c04:	7179                	addi	sp,sp,-48
    80204c06:	f406                	sd	ra,40(sp)
    80204c08:	f022                	sd	s0,32(sp)
    80204c0a:	ec26                	sd	s1,24(sp)
    80204c0c:	e84a                	sd	s2,16(sp)
    80204c0e:	e44e                	sd	s3,8(sp)
    80204c10:	e052                	sd	s4,0(sp)
    80204c12:	1800                	addi	s0,sp,48
    80204c14:	89aa                	mv	s3,a0
    80204c16:	8a2e                	mv	s4,a1
    acquire(&icache.lock);
    80204c18:	00134517          	auipc	a0,0x134
    80204c1c:	59050513          	addi	a0,a0,1424 # 803391a8 <icache>
    80204c20:	ffffc097          	auipc	ra,0xffffc
    80204c24:	6d0080e7          	jalr	1744(ra) # 802012f0 <acquire>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204c28:	00134497          	auipc	s1,0x134
    80204c2c:	59848493          	addi	s1,s1,1432 # 803391c0 <icache+0x18>
    struct inode *empty = 0;
    80204c30:	4901                	li	s2,0
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204c32:	00136697          	auipc	a3,0x136
    80204c36:	01e68693          	addi	a3,a3,30 # 8033ac50 <devsw>
    80204c3a:	a039                	j	80204c48 <iget+0x44>
        if (empty == 0 && ip->ref == 0)
    80204c3c:	02090b63          	beqz	s2,80204c72 <iget+0x6e>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204c40:	08848493          	addi	s1,s1,136
    80204c44:	02d48a63          	beq	s1,a3,80204c78 <iget+0x74>
        if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80204c48:	449c                	lw	a5,8(s1)
    80204c4a:	fef059e3          	blez	a5,80204c3c <iget+0x38>
    80204c4e:	4098                	lw	a4,0(s1)
    80204c50:	ff3716e3          	bne	a4,s3,80204c3c <iget+0x38>
    80204c54:	40d8                	lw	a4,4(s1)
    80204c56:	ff4713e3          	bne	a4,s4,80204c3c <iget+0x38>
            ip->ref++;
    80204c5a:	2785                	addiw	a5,a5,1
    80204c5c:	c49c                	sw	a5,8(s1)
            release(&icache.lock);
    80204c5e:	00134517          	auipc	a0,0x134
    80204c62:	54a50513          	addi	a0,a0,1354 # 803391a8 <icache>
    80204c66:	ffffc097          	auipc	ra,0xffffc
    80204c6a:	73e080e7          	jalr	1854(ra) # 802013a4 <release>
            return ip;
    80204c6e:	8926                	mv	s2,s1
    80204c70:	a03d                	j	80204c9e <iget+0x9a>
        if (empty == 0 && ip->ref == 0)
    80204c72:	f7f9                	bnez	a5,80204c40 <iget+0x3c>
            empty = ip;
    80204c74:	8926                	mv	s2,s1
    80204c76:	b7e9                	j	80204c40 <iget+0x3c>
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80204c78:	02090c63          	beqz	s2,80204cb0 <iget+0xac>
    ip->dev = dev; ip->inum = inum; ip->ref = 1; ip->valid = 0;
    80204c7c:	01392023          	sw	s3,0(s2)
    80204c80:	01492223          	sw	s4,4(s2)
    80204c84:	4785                	li	a5,1
    80204c86:	00f92423          	sw	a5,8(s2)
    80204c8a:	04092023          	sw	zero,64(s2)
    release(&icache.lock);
    80204c8e:	00134517          	auipc	a0,0x134
    80204c92:	51a50513          	addi	a0,a0,1306 # 803391a8 <icache>
    80204c96:	ffffc097          	auipc	ra,0xffffc
    80204c9a:	70e080e7          	jalr	1806(ra) # 802013a4 <release>
}
    80204c9e:	854a                	mv	a0,s2
    80204ca0:	70a2                	ld	ra,40(sp)
    80204ca2:	7402                	ld	s0,32(sp)
    80204ca4:	64e2                	ld	s1,24(sp)
    80204ca6:	6942                	ld	s2,16(sp)
    80204ca8:	69a2                	ld	s3,8(sp)
    80204caa:	6a02                	ld	s4,0(sp)
    80204cac:	6145                	addi	sp,sp,48
    80204cae:	8082                	ret
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80204cb0:	00003517          	auipc	a0,0x3
    80204cb4:	db050513          	addi	a0,a0,-592 # 80207a60 <etext+0xa60>
    80204cb8:	ffffc097          	auipc	ra,0xffffc
    80204cbc:	902080e7          	jalr	-1790(ra) # 802005ba <panic>

0000000080204cc0 <fsinit>:
{
    80204cc0:	1101                	addi	sp,sp,-32
    80204cc2:	ec06                	sd	ra,24(sp)
    80204cc4:	e822                	sd	s0,16(sp)
    80204cc6:	e426                	sd	s1,8(sp)
    80204cc8:	e04a                	sd	s2,0(sp)
    80204cca:	1000                	addi	s0,sp,32
    struct buf *bp = bread(dev, 1);
    80204ccc:	4585                	li	a1,1
    80204cce:	00000097          	auipc	ra,0x0
    80204cd2:	aca080e7          	jalr	-1334(ra) # 80204798 <bread>
    80204cd6:	84aa                	mv	s1,a0
    memmove(&sb, bp->data, sizeof(sb));
    80204cd8:	00134917          	auipc	s2,0x134
    80204cdc:	4a890913          	addi	s2,s2,1192 # 80339180 <sb>
    80204ce0:	02800613          	li	a2,40
    80204ce4:	05850593          	addi	a1,a0,88
    80204ce8:	854a                	mv	a0,s2
    80204cea:	ffffc097          	auipc	ra,0xffffc
    80204cee:	992080e7          	jalr	-1646(ra) # 8020067c <memmove>
    brelse(bp);
    80204cf2:	8526                	mv	a0,s1
    80204cf4:	00000097          	auipc	ra,0x0
    80204cf8:	bd4080e7          	jalr	-1068(ra) # 802048c8 <brelse>
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80204cfc:	00092703          	lw	a4,0(s2)
    80204d00:	4c5557b7          	lui	a5,0x4c555
    80204d04:	95478793          	addi	a5,a5,-1708 # 4c554954 <_entry-0x33cab6ac>
    80204d08:	02f71e63          	bne	a4,a5,80204d44 <fsinit+0x84>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80204d0c:	00134717          	auipc	a4,0x134
    80204d10:	47872703          	lw	a4,1144(a4) # 80339184 <sb+0x4>
    80204d14:	4785                	li	a5,1
    80204d16:	02f71f63          	bne	a4,a5,80204d54 <fsinit+0x94>
    printf("luitfs: %d blocks, %d inodes, data at block %d\n",
    80204d1a:	00134797          	auipc	a5,0x134
    80204d1e:	46678793          	addi	a5,a5,1126 # 80339180 <sb>
    80204d22:	5394                	lw	a3,32(a5)
    80204d24:	47d0                	lw	a2,12(a5)
    80204d26:	478c                	lw	a1,8(a5)
    80204d28:	00003517          	auipc	a0,0x3
    80204d2c:	da850513          	addi	a0,a0,-600 # 80207ad0 <etext+0xad0>
    80204d30:	ffffb097          	auipc	ra,0xffffb
    80204d34:	618080e7          	jalr	1560(ra) # 80200348 <printf>
}
    80204d38:	60e2                	ld	ra,24(sp)
    80204d3a:	6442                	ld	s0,16(sp)
    80204d3c:	64a2                	ld	s1,8(sp)
    80204d3e:	6902                	ld	s2,0(sp)
    80204d40:	6105                	addi	sp,sp,32
    80204d42:	8082                	ret
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80204d44:	00003517          	auipc	a0,0x3
    80204d48:	d4450513          	addi	a0,a0,-700 # 80207a88 <etext+0xa88>
    80204d4c:	ffffc097          	auipc	ra,0xffffc
    80204d50:	86e080e7          	jalr	-1938(ra) # 802005ba <panic>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80204d54:	00003517          	auipc	a0,0x3
    80204d58:	d5c50513          	addi	a0,a0,-676 # 80207ab0 <etext+0xab0>
    80204d5c:	ffffc097          	auipc	ra,0xffffc
    80204d60:	85e080e7          	jalr	-1954(ra) # 802005ba <panic>

0000000080204d64 <iinit>:
{
    80204d64:	7179                	addi	sp,sp,-48
    80204d66:	f406                	sd	ra,40(sp)
    80204d68:	f022                	sd	s0,32(sp)
    80204d6a:	ec26                	sd	s1,24(sp)
    80204d6c:	e84a                	sd	s2,16(sp)
    80204d6e:	e44e                	sd	s3,8(sp)
    80204d70:	1800                	addi	s0,sp,48
    initlock(&icache.lock, "icache");
    80204d72:	00003597          	auipc	a1,0x3
    80204d76:	d8e58593          	addi	a1,a1,-626 # 80207b00 <etext+0xb00>
    80204d7a:	00134517          	auipc	a0,0x134
    80204d7e:	42e50513          	addi	a0,a0,1070 # 803391a8 <icache>
    80204d82:	ffffc097          	auipc	ra,0xffffc
    80204d86:	4f2080e7          	jalr	1266(ra) # 80201274 <initlock>
    for (int i = 0; i < NINODE; i++)
    80204d8a:	00134497          	auipc	s1,0x134
    80204d8e:	44648493          	addi	s1,s1,1094 # 803391d0 <icache+0x28>
    80204d92:	00136997          	auipc	s3,0x136
    80204d96:	ece98993          	addi	s3,s3,-306 # 8033ac60 <devsw+0x10>
        initsleeplock(&icache.inode[i].lock, "inode");
    80204d9a:	00003917          	auipc	s2,0x3
    80204d9e:	d6e90913          	addi	s2,s2,-658 # 80207b08 <etext+0xb08>
    80204da2:	85ca                	mv	a1,s2
    80204da4:	8526                	mv	a0,s1
    80204da6:	ffffc097          	auipc	ra,0xffffc
    80204daa:	646080e7          	jalr	1606(ra) # 802013ec <initsleeplock>
    for (int i = 0; i < NINODE; i++)
    80204dae:	08848493          	addi	s1,s1,136
    80204db2:	ff3498e3          	bne	s1,s3,80204da2 <iinit+0x3e>
}
    80204db6:	70a2                	ld	ra,40(sp)
    80204db8:	7402                	ld	s0,32(sp)
    80204dba:	64e2                	ld	s1,24(sp)
    80204dbc:	6942                	ld	s2,16(sp)
    80204dbe:	69a2                	ld	s3,8(sp)
    80204dc0:	6145                	addi	sp,sp,48
    80204dc2:	8082                	ret

0000000080204dc4 <ialloc>:
{
    80204dc4:	715d                	addi	sp,sp,-80
    80204dc6:	e486                	sd	ra,72(sp)
    80204dc8:	e0a2                	sd	s0,64(sp)
    80204dca:	0880                	addi	s0,sp,80
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80204dcc:	00134717          	auipc	a4,0x134
    80204dd0:	3c072703          	lw	a4,960(a4) # 8033918c <sb+0xc>
    80204dd4:	4785                	li	a5,1
    80204dd6:	06e7fe63          	bgeu	a5,a4,80204e52 <ialloc+0x8e>
    80204dda:	fc26                	sd	s1,56(sp)
    80204ddc:	f84a                	sd	s2,48(sp)
    80204dde:	f44e                	sd	s3,40(sp)
    80204de0:	f052                	sd	s4,32(sp)
    80204de2:	ec56                	sd	s5,24(sp)
    80204de4:	e85a                	sd	s6,16(sp)
    80204de6:	e45e                	sd	s7,8(sp)
    80204de8:	8a2a                	mv	s4,a0
    80204dea:	8bae                	mv	s7,a1
    80204dec:	4485                	li	s1,1
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80204dee:	00134997          	auipc	s3,0x134
    80204df2:	39298993          	addi	s3,s3,914 # 80339180 <sb>
        int m = 1 << (bi % 8);
    80204df6:	4b05                	li	s6,1
        uint32 bi = i % BPB;
    80204df8:	6a89                	lui	s5,0x2
    80204dfa:	1afd                	addi	s5,s5,-1 # 1fff <_entry-0x801fe001>
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80204dfc:	00d4d59b          	srliw	a1,s1,0xd
    80204e00:	0149a783          	lw	a5,20(s3)
    80204e04:	9dbd                	addw	a1,a1,a5
    80204e06:	8552                	mv	a0,s4
    80204e08:	00000097          	auipc	ra,0x0
    80204e0c:	990080e7          	jalr	-1648(ra) # 80204798 <bread>
    80204e10:	892a                	mv	s2,a0
        int m = 1 << (bi % 8);
    80204e12:	0074f713          	andi	a4,s1,7
    80204e16:	00eb173b          	sllw	a4,s6,a4
        uint32 bi = i % BPB;
    80204e1a:	0154f7b3          	and	a5,s1,s5
        if ((bp->data[bi / 8] & m) == 0) {
    80204e1e:	0037d61b          	srliw	a2,a5,0x3
    80204e22:	0037d79b          	srliw	a5,a5,0x3
    80204e26:	97aa                	add	a5,a5,a0
    80204e28:	0587c783          	lbu	a5,88(a5)
    80204e2c:	00f776b3          	and	a3,a4,a5
    80204e30:	ce95                	beqz	a3,80204e6c <ialloc+0xa8>
        brelse(bp);
    80204e32:	00000097          	auipc	ra,0x0
    80204e36:	a96080e7          	jalr	-1386(ra) # 802048c8 <brelse>
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80204e3a:	2485                	addiw	s1,s1,1
    80204e3c:	00c9a783          	lw	a5,12(s3)
    80204e40:	faf4eee3          	bltu	s1,a5,80204dfc <ialloc+0x38>
    80204e44:	74e2                	ld	s1,56(sp)
    80204e46:	7942                	ld	s2,48(sp)
    80204e48:	79a2                	ld	s3,40(sp)
    80204e4a:	7a02                	ld	s4,32(sp)
    80204e4c:	6ae2                	ld	s5,24(sp)
    80204e4e:	6b42                	ld	s6,16(sp)
    80204e50:	6ba2                	ld	s7,8(sp)
    printf("luitfs: out of inodes\n");
    80204e52:	00003517          	auipc	a0,0x3
    80204e56:	cbe50513          	addi	a0,a0,-834 # 80207b10 <etext+0xb10>
    80204e5a:	ffffb097          	auipc	ra,0xffffb
    80204e5e:	4ee080e7          	jalr	1262(ra) # 80200348 <printf>
    return 0;
    80204e62:	4501                	li	a0,0
}
    80204e64:	60a6                	ld	ra,72(sp)
    80204e66:	6406                	ld	s0,64(sp)
    80204e68:	6161                	addi	sp,sp,80
    80204e6a:	8082                	ret
            bp->data[bi / 8] |= m;
    80204e6c:	1602                	slli	a2,a2,0x20
    80204e6e:	9201                	srli	a2,a2,0x20
    80204e70:	962a                	add	a2,a2,a0
    80204e72:	8fd9                	or	a5,a5,a4
    80204e74:	04f60c23          	sb	a5,88(a2) # 1058 <_entry-0x801fefa8>
            bwrite(bp);
    80204e78:	00000097          	auipc	ra,0x0
    80204e7c:	a12080e7          	jalr	-1518(ra) # 8020488a <bwrite>
            brelse(bp);
    80204e80:	854a                	mv	a0,s2
    80204e82:	00000097          	auipc	ra,0x0
    80204e86:	a46080e7          	jalr	-1466(ra) # 802048c8 <brelse>
            bp = bread(dev, IBLOCK(i, sb));
    80204e8a:	0044d59b          	srliw	a1,s1,0x4
    80204e8e:	00134797          	auipc	a5,0x134
    80204e92:	30e7a783          	lw	a5,782(a5) # 8033919c <sb+0x1c>
    80204e96:	9dbd                	addw	a1,a1,a5
    80204e98:	8552                	mv	a0,s4
    80204e9a:	00000097          	auipc	ra,0x0
    80204e9e:	8fe080e7          	jalr	-1794(ra) # 80204798 <bread>
    80204ea2:	892a                	mv	s2,a0
            struct dinode *dip = (struct dinode *)bp->data + i % IPB;
    80204ea4:	05850993          	addi	s3,a0,88
    80204ea8:	00f4f793          	andi	a5,s1,15
    80204eac:	079a                	slli	a5,a5,0x6
    80204eae:	99be                	add	s3,s3,a5
            memset(dip, 0, sizeof(*dip));
    80204eb0:	04000613          	li	a2,64
    80204eb4:	4581                	li	a1,0
    80204eb6:	854e                	mv	a0,s3
    80204eb8:	ffffb097          	auipc	ra,0xffffb
    80204ebc:	7a8080e7          	jalr	1960(ra) # 80200660 <memset>
            dip->type = type;
    80204ec0:	01799023          	sh	s7,0(s3)
            bwrite(bp);
    80204ec4:	854a                	mv	a0,s2
    80204ec6:	00000097          	auipc	ra,0x0
    80204eca:	9c4080e7          	jalr	-1596(ra) # 8020488a <bwrite>
            brelse(bp);
    80204ece:	854a                	mv	a0,s2
    80204ed0:	00000097          	auipc	ra,0x0
    80204ed4:	9f8080e7          	jalr	-1544(ra) # 802048c8 <brelse>
            return iget(dev, i);
    80204ed8:	85a6                	mv	a1,s1
    80204eda:	8552                	mv	a0,s4
    80204edc:	00000097          	auipc	ra,0x0
    80204ee0:	d28080e7          	jalr	-728(ra) # 80204c04 <iget>
    80204ee4:	74e2                	ld	s1,56(sp)
    80204ee6:	7942                	ld	s2,48(sp)
    80204ee8:	79a2                	ld	s3,40(sp)
    80204eea:	7a02                	ld	s4,32(sp)
    80204eec:	6ae2                	ld	s5,24(sp)
    80204eee:	6b42                	ld	s6,16(sp)
    80204ef0:	6ba2                	ld	s7,8(sp)
    80204ef2:	bf8d                	j	80204e64 <ialloc+0xa0>

0000000080204ef4 <iupdate>:
{
    80204ef4:	1101                	addi	sp,sp,-32
    80204ef6:	ec06                	sd	ra,24(sp)
    80204ef8:	e822                	sd	s0,16(sp)
    80204efa:	e426                	sd	s1,8(sp)
    80204efc:	e04a                	sd	s2,0(sp)
    80204efe:	1000                	addi	s0,sp,32
    80204f00:	84aa                	mv	s1,a0
    struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80204f02:	415c                	lw	a5,4(a0)
    80204f04:	0047d79b          	srliw	a5,a5,0x4
    80204f08:	00134597          	auipc	a1,0x134
    80204f0c:	2945a583          	lw	a1,660(a1) # 8033919c <sb+0x1c>
    80204f10:	9dbd                	addw	a1,a1,a5
    80204f12:	4108                	lw	a0,0(a0)
    80204f14:	00000097          	auipc	ra,0x0
    80204f18:	884080e7          	jalr	-1916(ra) # 80204798 <bread>
    80204f1c:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    80204f1e:	05850793          	addi	a5,a0,88
    80204f22:	40d8                	lw	a4,4(s1)
    80204f24:	8b3d                	andi	a4,a4,15
    80204f26:	071a                	slli	a4,a4,0x6
    80204f28:	97ba                	add	a5,a5,a4
    dip->type  = ip->type;
    80204f2a:	0444d703          	lhu	a4,68(s1)
    80204f2e:	00e79023          	sh	a4,0(a5)
    dip->major = ip->major;
    80204f32:	0464d703          	lhu	a4,70(s1)
    80204f36:	00e79123          	sh	a4,2(a5)
    dip->minor = ip->minor;
    80204f3a:	0484d703          	lhu	a4,72(s1)
    80204f3e:	00e79223          	sh	a4,4(a5)
    dip->nlink = ip->nlink;
    80204f42:	04a4d703          	lhu	a4,74(s1)
    80204f46:	00e79323          	sh	a4,6(a5)
    dip->size  = ip->size;
    80204f4a:	44f8                	lw	a4,76(s1)
    80204f4c:	c798                	sw	a4,8(a5)
    memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80204f4e:	03400613          	li	a2,52
    80204f52:	05048593          	addi	a1,s1,80
    80204f56:	00c78513          	addi	a0,a5,12
    80204f5a:	ffffb097          	auipc	ra,0xffffb
    80204f5e:	722080e7          	jalr	1826(ra) # 8020067c <memmove>
    bwrite(bp);
    80204f62:	854a                	mv	a0,s2
    80204f64:	00000097          	auipc	ra,0x0
    80204f68:	926080e7          	jalr	-1754(ra) # 8020488a <bwrite>
    brelse(bp);
    80204f6c:	854a                	mv	a0,s2
    80204f6e:	00000097          	auipc	ra,0x0
    80204f72:	95a080e7          	jalr	-1702(ra) # 802048c8 <brelse>
}
    80204f76:	60e2                	ld	ra,24(sp)
    80204f78:	6442                	ld	s0,16(sp)
    80204f7a:	64a2                	ld	s1,8(sp)
    80204f7c:	6902                	ld	s2,0(sp)
    80204f7e:	6105                	addi	sp,sp,32
    80204f80:	8082                	ret

0000000080204f82 <idup>:
{
    80204f82:	1101                	addi	sp,sp,-32
    80204f84:	ec06                	sd	ra,24(sp)
    80204f86:	e822                	sd	s0,16(sp)
    80204f88:	e426                	sd	s1,8(sp)
    80204f8a:	1000                	addi	s0,sp,32
    80204f8c:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    80204f8e:	00134517          	auipc	a0,0x134
    80204f92:	21a50513          	addi	a0,a0,538 # 803391a8 <icache>
    80204f96:	ffffc097          	auipc	ra,0xffffc
    80204f9a:	35a080e7          	jalr	858(ra) # 802012f0 <acquire>
    ip->ref++;
    80204f9e:	449c                	lw	a5,8(s1)
    80204fa0:	2785                	addiw	a5,a5,1
    80204fa2:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    80204fa4:	00134517          	auipc	a0,0x134
    80204fa8:	20450513          	addi	a0,a0,516 # 803391a8 <icache>
    80204fac:	ffffc097          	auipc	ra,0xffffc
    80204fb0:	3f8080e7          	jalr	1016(ra) # 802013a4 <release>
}
    80204fb4:	8526                	mv	a0,s1
    80204fb6:	60e2                	ld	ra,24(sp)
    80204fb8:	6442                	ld	s0,16(sp)
    80204fba:	64a2                	ld	s1,8(sp)
    80204fbc:	6105                	addi	sp,sp,32
    80204fbe:	8082                	ret

0000000080204fc0 <ilock>:
{
    80204fc0:	1101                	addi	sp,sp,-32
    80204fc2:	ec06                	sd	ra,24(sp)
    80204fc4:	e822                	sd	s0,16(sp)
    80204fc6:	e426                	sd	s1,8(sp)
    80204fc8:	1000                	addi	s0,sp,32
    if (ip == 0 || ip->ref < 1) panic("ilock");
    80204fca:	c10d                	beqz	a0,80204fec <ilock+0x2c>
    80204fcc:	84aa                	mv	s1,a0
    80204fce:	451c                	lw	a5,8(a0)
    80204fd0:	00f05e63          	blez	a5,80204fec <ilock+0x2c>
    acquiresleep(&ip->lock);
    80204fd4:	0541                	addi	a0,a0,16
    80204fd6:	ffffc097          	auipc	ra,0xffffc
    80204fda:	450080e7          	jalr	1104(ra) # 80201426 <acquiresleep>
    if (!ip->valid) {
    80204fde:	40bc                	lw	a5,64(s1)
    80204fe0:	cf99                	beqz	a5,80204ffe <ilock+0x3e>
}
    80204fe2:	60e2                	ld	ra,24(sp)
    80204fe4:	6442                	ld	s0,16(sp)
    80204fe6:	64a2                	ld	s1,8(sp)
    80204fe8:	6105                	addi	sp,sp,32
    80204fea:	8082                	ret
    80204fec:	e04a                	sd	s2,0(sp)
    if (ip == 0 || ip->ref < 1) panic("ilock");
    80204fee:	00003517          	auipc	a0,0x3
    80204ff2:	b3a50513          	addi	a0,a0,-1222 # 80207b28 <etext+0xb28>
    80204ff6:	ffffb097          	auipc	ra,0xffffb
    80204ffa:	5c4080e7          	jalr	1476(ra) # 802005ba <panic>
    80204ffe:	e04a                	sd	s2,0(sp)
        struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80205000:	40dc                	lw	a5,4(s1)
    80205002:	0047d79b          	srliw	a5,a5,0x4
    80205006:	00134597          	auipc	a1,0x134
    8020500a:	1965a583          	lw	a1,406(a1) # 8033919c <sb+0x1c>
    8020500e:	9dbd                	addw	a1,a1,a5
    80205010:	4088                	lw	a0,0(s1)
    80205012:	fffff097          	auipc	ra,0xfffff
    80205016:	786080e7          	jalr	1926(ra) # 80204798 <bread>
    8020501a:	892a                	mv	s2,a0
        struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    8020501c:	05850593          	addi	a1,a0,88
    80205020:	40dc                	lw	a5,4(s1)
    80205022:	8bbd                	andi	a5,a5,15
    80205024:	079a                	slli	a5,a5,0x6
    80205026:	95be                	add	a1,a1,a5
        ip->type  = dip->type;
    80205028:	0005d783          	lhu	a5,0(a1)
    8020502c:	04f49223          	sh	a5,68(s1)
        ip->major = dip->major;
    80205030:	0025d783          	lhu	a5,2(a1)
    80205034:	04f49323          	sh	a5,70(s1)
        ip->minor = dip->minor;
    80205038:	0045d783          	lhu	a5,4(a1)
    8020503c:	04f49423          	sh	a5,72(s1)
        ip->nlink = dip->nlink;
    80205040:	0065d783          	lhu	a5,6(a1)
    80205044:	04f49523          	sh	a5,74(s1)
        ip->size  = dip->size;
    80205048:	459c                	lw	a5,8(a1)
    8020504a:	c4fc                	sw	a5,76(s1)
        memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8020504c:	03400613          	li	a2,52
    80205050:	05b1                	addi	a1,a1,12
    80205052:	05048513          	addi	a0,s1,80
    80205056:	ffffb097          	auipc	ra,0xffffb
    8020505a:	626080e7          	jalr	1574(ra) # 8020067c <memmove>
        brelse(bp);
    8020505e:	854a                	mv	a0,s2
    80205060:	00000097          	auipc	ra,0x0
    80205064:	868080e7          	jalr	-1944(ra) # 802048c8 <brelse>
        ip->valid = 1;
    80205068:	4785                	li	a5,1
    8020506a:	c0bc                	sw	a5,64(s1)
        if (ip->type == 0) panic("ilock: inode has no type (bitmap out of sync)");
    8020506c:	0444d783          	lhu	a5,68(s1)
    80205070:	c399                	beqz	a5,80205076 <ilock+0xb6>
    80205072:	6902                	ld	s2,0(sp)
    80205074:	b7bd                	j	80204fe2 <ilock+0x22>
    80205076:	00003517          	auipc	a0,0x3
    8020507a:	aba50513          	addi	a0,a0,-1350 # 80207b30 <etext+0xb30>
    8020507e:	ffffb097          	auipc	ra,0xffffb
    80205082:	53c080e7          	jalr	1340(ra) # 802005ba <panic>

0000000080205086 <iunlock>:
{
    80205086:	1101                	addi	sp,sp,-32
    80205088:	ec06                	sd	ra,24(sp)
    8020508a:	e822                	sd	s0,16(sp)
    8020508c:	e426                	sd	s1,8(sp)
    8020508e:	e04a                	sd	s2,0(sp)
    80205090:	1000                	addi	s0,sp,32
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    80205092:	c905                	beqz	a0,802050c2 <iunlock+0x3c>
    80205094:	84aa                	mv	s1,a0
    80205096:	01050913          	addi	s2,a0,16
    8020509a:	854a                	mv	a0,s2
    8020509c:	ffffc097          	auipc	ra,0xffffc
    802050a0:	424080e7          	jalr	1060(ra) # 802014c0 <holdingsleep>
    802050a4:	cd19                	beqz	a0,802050c2 <iunlock+0x3c>
    802050a6:	449c                	lw	a5,8(s1)
    802050a8:	00f05d63          	blez	a5,802050c2 <iunlock+0x3c>
    releasesleep(&ip->lock);
    802050ac:	854a                	mv	a0,s2
    802050ae:	ffffc097          	auipc	ra,0xffffc
    802050b2:	3ce080e7          	jalr	974(ra) # 8020147c <releasesleep>
}
    802050b6:	60e2                	ld	ra,24(sp)
    802050b8:	6442                	ld	s0,16(sp)
    802050ba:	64a2                	ld	s1,8(sp)
    802050bc:	6902                	ld	s2,0(sp)
    802050be:	6105                	addi	sp,sp,32
    802050c0:	8082                	ret
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    802050c2:	00003517          	auipc	a0,0x3
    802050c6:	a9e50513          	addi	a0,a0,-1378 # 80207b60 <etext+0xb60>
    802050ca:	ffffb097          	auipc	ra,0xffffb
    802050ce:	4f0080e7          	jalr	1264(ra) # 802005ba <panic>

00000000802050d2 <itrunc>:

/* Free all data blocks of ip and set size 0. Caller holds ip->lock. */
void itrunc(struct inode *ip)
{
    802050d2:	7179                	addi	sp,sp,-48
    802050d4:	f406                	sd	ra,40(sp)
    802050d6:	f022                	sd	s0,32(sp)
    802050d8:	ec26                	sd	s1,24(sp)
    802050da:	e84a                	sd	s2,16(sp)
    802050dc:	e44e                	sd	s3,8(sp)
    802050de:	1800                	addi	s0,sp,48
    802050e0:	89aa                	mv	s3,a0
    for (int i = 0; i < NDIRECT; i++) {
    802050e2:	05050493          	addi	s1,a0,80
    802050e6:	08050913          	addi	s2,a0,128
    802050ea:	a021                	j	802050f2 <itrunc+0x20>
    802050ec:	0491                	addi	s1,s1,4
    802050ee:	01248d63          	beq	s1,s2,80205108 <itrunc+0x36>
        if (ip->addrs[i]) { bfree(ip->dev, ip->addrs[i]); ip->addrs[i] = 0; }
    802050f2:	408c                	lw	a1,0(s1)
    802050f4:	dde5                	beqz	a1,802050ec <itrunc+0x1a>
    802050f6:	0009a503          	lw	a0,0(s3)
    802050fa:	00000097          	auipc	ra,0x0
    802050fe:	86a080e7          	jalr	-1942(ra) # 80204964 <bfree>
    80205102:	0004a023          	sw	zero,0(s1)
    80205106:	b7dd                	j	802050ec <itrunc+0x1a>
    }
    if (ip->addrs[NDIRECT]) {
    80205108:	0809a583          	lw	a1,128(s3)
    8020510c:	ed99                	bnez	a1,8020512a <itrunc+0x58>
            if (a[j]) bfree(ip->dev, a[j]);
        brelse(bp);
        bfree(ip->dev, ip->addrs[NDIRECT]);
        ip->addrs[NDIRECT] = 0;
    }
    ip->size = 0;
    8020510e:	0409a623          	sw	zero,76(s3)
    iupdate(ip);
    80205112:	854e                	mv	a0,s3
    80205114:	00000097          	auipc	ra,0x0
    80205118:	de0080e7          	jalr	-544(ra) # 80204ef4 <iupdate>
}
    8020511c:	70a2                	ld	ra,40(sp)
    8020511e:	7402                	ld	s0,32(sp)
    80205120:	64e2                	ld	s1,24(sp)
    80205122:	6942                	ld	s2,16(sp)
    80205124:	69a2                	ld	s3,8(sp)
    80205126:	6145                	addi	sp,sp,48
    80205128:	8082                	ret
    8020512a:	e052                	sd	s4,0(sp)
        struct buf *bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8020512c:	0009a503          	lw	a0,0(s3)
    80205130:	fffff097          	auipc	ra,0xfffff
    80205134:	668080e7          	jalr	1640(ra) # 80204798 <bread>
    80205138:	8a2a                	mv	s4,a0
        for (uint32 j = 0; j < NINDIRECT; j++)
    8020513a:	05850493          	addi	s1,a0,88
    8020513e:	45850913          	addi	s2,a0,1112
    80205142:	a021                	j	8020514a <itrunc+0x78>
    80205144:	0491                	addi	s1,s1,4
    80205146:	01248b63          	beq	s1,s2,8020515c <itrunc+0x8a>
            if (a[j]) bfree(ip->dev, a[j]);
    8020514a:	408c                	lw	a1,0(s1)
    8020514c:	dde5                	beqz	a1,80205144 <itrunc+0x72>
    8020514e:	0009a503          	lw	a0,0(s3)
    80205152:	00000097          	auipc	ra,0x0
    80205156:	812080e7          	jalr	-2030(ra) # 80204964 <bfree>
    8020515a:	b7ed                	j	80205144 <itrunc+0x72>
        brelse(bp);
    8020515c:	8552                	mv	a0,s4
    8020515e:	fffff097          	auipc	ra,0xfffff
    80205162:	76a080e7          	jalr	1898(ra) # 802048c8 <brelse>
        bfree(ip->dev, ip->addrs[NDIRECT]);
    80205166:	0809a583          	lw	a1,128(s3)
    8020516a:	0009a503          	lw	a0,0(s3)
    8020516e:	fffff097          	auipc	ra,0xfffff
    80205172:	7f6080e7          	jalr	2038(ra) # 80204964 <bfree>
        ip->addrs[NDIRECT] = 0;
    80205176:	0809a023          	sw	zero,128(s3)
    8020517a:	6a02                	ld	s4,0(sp)
    8020517c:	bf49                	j	8020510e <itrunc+0x3c>

000000008020517e <iput>:
{
    8020517e:	7179                	addi	sp,sp,-48
    80205180:	f406                	sd	ra,40(sp)
    80205182:	f022                	sd	s0,32(sp)
    80205184:	ec26                	sd	s1,24(sp)
    80205186:	1800                	addi	s0,sp,48
    80205188:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    8020518a:	00134517          	auipc	a0,0x134
    8020518e:	01e50513          	addi	a0,a0,30 # 803391a8 <icache>
    80205192:	ffffc097          	auipc	ra,0xffffc
    80205196:	15e080e7          	jalr	350(ra) # 802012f0 <acquire>
    if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    8020519a:	4498                	lw	a4,8(s1)
    8020519c:	4785                	li	a5,1
    8020519e:	00f71763          	bne	a4,a5,802051ac <iput+0x2e>
    802051a2:	40bc                	lw	a5,64(s1)
    802051a4:	c781                	beqz	a5,802051ac <iput+0x2e>
    802051a6:	04a4d783          	lhu	a5,74(s1)
    802051aa:	c38d                	beqz	a5,802051cc <iput+0x4e>
    ip->ref--;
    802051ac:	449c                	lw	a5,8(s1)
    802051ae:	37fd                	addiw	a5,a5,-1
    802051b0:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    802051b2:	00134517          	auipc	a0,0x134
    802051b6:	ff650513          	addi	a0,a0,-10 # 803391a8 <icache>
    802051ba:	ffffc097          	auipc	ra,0xffffc
    802051be:	1ea080e7          	jalr	490(ra) # 802013a4 <release>
}
    802051c2:	70a2                	ld	ra,40(sp)
    802051c4:	7402                	ld	s0,32(sp)
    802051c6:	64e2                	ld	s1,24(sp)
    802051c8:	6145                	addi	sp,sp,48
    802051ca:	8082                	ret
    802051cc:	e84a                	sd	s2,16(sp)
    802051ce:	e44e                	sd	s3,8(sp)
        acquiresleep(&ip->lock);
    802051d0:	01048993          	addi	s3,s1,16
    802051d4:	854e                	mv	a0,s3
    802051d6:	ffffc097          	auipc	ra,0xffffc
    802051da:	250080e7          	jalr	592(ra) # 80201426 <acquiresleep>
        release(&icache.lock);
    802051de:	00134517          	auipc	a0,0x134
    802051e2:	fca50513          	addi	a0,a0,-54 # 803391a8 <icache>
    802051e6:	ffffc097          	auipc	ra,0xffffc
    802051ea:	1be080e7          	jalr	446(ra) # 802013a4 <release>
        itrunc(ip);
    802051ee:	8526                	mv	a0,s1
    802051f0:	00000097          	auipc	ra,0x0
    802051f4:	ee2080e7          	jalr	-286(ra) # 802050d2 <itrunc>
        ip->type = 0;
    802051f8:	04049223          	sh	zero,68(s1)
        iupdate(ip);
    802051fc:	8526                	mv	a0,s1
    802051fe:	00000097          	auipc	ra,0x0
    80205202:	cf6080e7          	jalr	-778(ra) # 80204ef4 <iupdate>
        struct buf *bp = bread(ip->dev, IBBLOCK(ip->inum, sb));
    80205206:	40dc                	lw	a5,4(s1)
    80205208:	00d7d79b          	srliw	a5,a5,0xd
    8020520c:	00134597          	auipc	a1,0x134
    80205210:	f885a583          	lw	a1,-120(a1) # 80339194 <sb+0x14>
    80205214:	9dbd                	addw	a1,a1,a5
    80205216:	4088                	lw	a0,0(s1)
    80205218:	fffff097          	auipc	ra,0xfffff
    8020521c:	580080e7          	jalr	1408(ra) # 80204798 <bread>
    80205220:	892a                	mv	s2,a0
        uint32 bi = ip->inum % BPB;
    80205222:	40d4                	lw	a3,4(s1)
    80205224:	03369793          	slli	a5,a3,0x33
        if ((bp->data[bi / 8] & (1 << (bi % 8))) == 0)
    80205228:	0367d713          	srli	a4,a5,0x36
    8020522c:	00e507b3          	add	a5,a0,a4
    80205230:	0587c603          	lbu	a2,88(a5)
    80205234:	8a9d                	andi	a3,a3,7
    80205236:	40d657bb          	sraw	a5,a2,a3
    8020523a:	8b85                	andi	a5,a5,1
    8020523c:	cba1                	beqz	a5,8020528c <iput+0x10e>
        bp->data[bi / 8] &= ~(1 << (bi % 8));
    8020523e:	02071793          	slli	a5,a4,0x20
    80205242:	9381                	srli	a5,a5,0x20
    80205244:	97aa                	add	a5,a5,a0
    80205246:	4705                	li	a4,1
    80205248:	00d7173b          	sllw	a4,a4,a3
    8020524c:	fff74713          	not	a4,a4
    80205250:	8e79                	and	a2,a2,a4
    80205252:	04c78c23          	sb	a2,88(a5)
        bwrite(bp);
    80205256:	fffff097          	auipc	ra,0xfffff
    8020525a:	634080e7          	jalr	1588(ra) # 8020488a <bwrite>
        brelse(bp);
    8020525e:	854a                	mv	a0,s2
    80205260:	fffff097          	auipc	ra,0xfffff
    80205264:	668080e7          	jalr	1640(ra) # 802048c8 <brelse>
        ip->valid = 0;
    80205268:	0404a023          	sw	zero,64(s1)
        releasesleep(&ip->lock);
    8020526c:	854e                	mv	a0,s3
    8020526e:	ffffc097          	auipc	ra,0xffffc
    80205272:	20e080e7          	jalr	526(ra) # 8020147c <releasesleep>
        acquire(&icache.lock);
    80205276:	00134517          	auipc	a0,0x134
    8020527a:	f3250513          	addi	a0,a0,-206 # 803391a8 <icache>
    8020527e:	ffffc097          	auipc	ra,0xffffc
    80205282:	072080e7          	jalr	114(ra) # 802012f0 <acquire>
    80205286:	6942                	ld	s2,16(sp)
    80205288:	69a2                	ld	s3,8(sp)
    8020528a:	b70d                	j	802051ac <iput+0x2e>
            panic("iput: inode bitmap already clear");
    8020528c:	00003517          	auipc	a0,0x3
    80205290:	8dc50513          	addi	a0,a0,-1828 # 80207b68 <etext+0xb68>
    80205294:	ffffb097          	auipc	ra,0xffffb
    80205298:	326080e7          	jalr	806(ra) # 802005ba <panic>

000000008020529c <iunlockput>:
void iunlockput(struct inode *ip) { iunlock(ip); iput(ip); }
    8020529c:	1101                	addi	sp,sp,-32
    8020529e:	ec06                	sd	ra,24(sp)
    802052a0:	e822                	sd	s0,16(sp)
    802052a2:	e426                	sd	s1,8(sp)
    802052a4:	1000                	addi	s0,sp,32
    802052a6:	84aa                	mv	s1,a0
    802052a8:	00000097          	auipc	ra,0x0
    802052ac:	dde080e7          	jalr	-546(ra) # 80205086 <iunlock>
    802052b0:	8526                	mv	a0,s1
    802052b2:	00000097          	auipc	ra,0x0
    802052b6:	ecc080e7          	jalr	-308(ra) # 8020517e <iput>
    802052ba:	60e2                	ld	ra,24(sp)
    802052bc:	6442                	ld	s0,16(sp)
    802052be:	64a2                	ld	s1,8(sp)
    802052c0:	6105                	addi	sp,sp,32
    802052c2:	8082                	ret

00000000802052c4 <stati>:

void stati(struct inode *ip, struct stat *st)
{
    802052c4:	1141                	addi	sp,sp,-16
    802052c6:	e422                	sd	s0,8(sp)
    802052c8:	0800                	addi	s0,sp,16
    st->dev   = ip->dev;
    802052ca:	411c                	lw	a5,0(a0)
    802052cc:	c19c                	sw	a5,0(a1)
    st->ino   = ip->inum;
    802052ce:	415c                	lw	a5,4(a0)
    802052d0:	c1dc                	sw	a5,4(a1)
    st->type  = ip->type;
    802052d2:	04455783          	lhu	a5,68(a0)
    802052d6:	00f59423          	sh	a5,8(a1)
    st->nlink = ip->nlink;
    802052da:	04a55783          	lhu	a5,74(a0)
    802052de:	00f59523          	sh	a5,10(a1)
    st->size  = ip->size;
    802052e2:	04c56783          	lwu	a5,76(a0)
    802052e6:	e99c                	sd	a5,16(a1)
}
    802052e8:	6422                	ld	s0,8(sp)
    802052ea:	0141                	addi	sp,sp,16
    802052ec:	8082                	ret

00000000802052ee <readi>:

/* Read n bytes at offset off into dst (user va if user_dst, else kernel).
 * Returns bytes read, or -1. Caller holds ip->lock. */
int readi(struct inode *ip, int user_dst, uint64 dst, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return 0;
    802052ee:	457c                	lw	a5,76(a0)
    802052f0:	12d7e763          	bltu	a5,a3,8020541e <readi+0x130>
{
    802052f4:	7159                	addi	sp,sp,-112
    802052f6:	f486                	sd	ra,104(sp)
    802052f8:	f0a2                	sd	s0,96(sp)
    802052fa:	eca6                	sd	s1,88(sp)
    802052fc:	e0d2                	sd	s4,64(sp)
    802052fe:	f45e                	sd	s7,40(sp)
    80205300:	f062                	sd	s8,32(sp)
    80205302:	ec66                	sd	s9,24(sp)
    80205304:	1880                	addi	s0,sp,112
    80205306:	8c2a                	mv	s8,a0
    80205308:	8cae                	mv	s9,a1
    8020530a:	8a32                	mv	s4,a2
    8020530c:	84b6                	mv	s1,a3
    8020530e:	8bba                	mv	s7,a4
    if (off > ip->size || off + n < off) return 0;
    80205310:	9f35                	addw	a4,a4,a3
    80205312:	4501                	li	a0,0
    80205314:	0ed76c63          	bltu	a4,a3,8020540c <readi+0x11e>
    80205318:	e4ce                	sd	s3,72(sp)
    if (off + n > ip->size) n = ip->size - off;
    8020531a:	00e7f463          	bgeu	a5,a4,80205322 <readi+0x34>
    8020531e:	40d78bbb          	subw	s7,a5,a3

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205322:	0c0b8b63          	beqz	s7,802053f8 <readi+0x10a>
    80205326:	e8ca                	sd	s2,80(sp)
    80205328:	fc56                	sd	s5,56(sp)
    8020532a:	f85a                	sd	s6,48(sp)
    8020532c:	e86a                	sd	s10,16(sp)
    8020532e:	e46e                	sd	s11,8(sp)
    80205330:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80205332:	40000d13          	li	s10,1024
    80205336:	a81d                	j	8020536c <readi+0x7e>
                brelse(bp);
                tot = -1;
                break;
            }
        } else {
            memmove((void *)dst, bp->data + off % BSIZE, m);
    80205338:	05890593          	addi	a1,s2,88
    8020533c:	020a9613          	slli	a2,s5,0x20
    80205340:	9201                	srli	a2,a2,0x20
    80205342:	95da                	add	a1,a1,s6
    80205344:	8552                	mv	a0,s4
    80205346:	ffffb097          	auipc	ra,0xffffb
    8020534a:	336080e7          	jalr	822(ra) # 8020067c <memmove>
        }
        brelse(bp);
    8020534e:	854a                	mv	a0,s2
    80205350:	fffff097          	auipc	ra,0xfffff
    80205354:	578080e7          	jalr	1400(ra) # 802048c8 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205358:	013d89bb          	addw	s3,s11,s3
    8020535c:	009d84bb          	addw	s1,s11,s1
    80205360:	1d82                	slli	s11,s11,0x20
    80205362:	020ddd93          	srli	s11,s11,0x20
    80205366:	9a6e                	add	s4,s4,s11
    80205368:	0979f263          	bgeu	s3,s7,802053ec <readi+0xfe>
        uint32 addr = bmap(ip, off / BSIZE);
    8020536c:	00a4d59b          	srliw	a1,s1,0xa
    80205370:	8562                	mv	a0,s8
    80205372:	fffff097          	auipc	ra,0xfffff
    80205376:	7a2080e7          	jalr	1954(ra) # 80204b14 <bmap>
    8020537a:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;
    8020537e:	cdbd                	beqz	a1,802053fc <readi+0x10e>
        struct buf *bp = bread(ip->dev, addr);
    80205380:	000c2503          	lw	a0,0(s8)
    80205384:	fffff097          	auipc	ra,0xfffff
    80205388:	414080e7          	jalr	1044(ra) # 80204798 <bread>
    8020538c:	892a                	mv	s2,a0
        m = BSIZE - off % BSIZE;
    8020538e:	3ff4fb13          	andi	s6,s1,1023
        if (m > n - tot) m = n - tot;
    80205392:	413b87bb          	subw	a5,s7,s3
        m = BSIZE - off % BSIZE;
    80205396:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    8020539a:	8abe                	mv	s5,a5
    8020539c:	2781                	sext.w	a5,a5
    8020539e:	0007069b          	sext.w	a3,a4
    802053a2:	00f6f363          	bgeu	a3,a5,802053a8 <readi+0xba>
    802053a6:	8aba                	mv	s5,a4
    802053a8:	000a8d9b          	sext.w	s11,s5
        if (user_dst) {
    802053ac:	f80c86e3          	beqz	s9,80205338 <readi+0x4a>
            if (copyout(myproc()->pagetable, dst,
    802053b0:	ffffc097          	auipc	ra,0xffffc
    802053b4:	32a080e7          	jalr	810(ra) # 802016da <myproc>
                        (char *)bp->data + off % BSIZE, m) < 0) {
    802053b8:	05890613          	addi	a2,s2,88
            if (copyout(myproc()->pagetable, dst,
    802053bc:	020a9693          	slli	a3,s5,0x20
    802053c0:	9281                	srli	a3,a3,0x20
    802053c2:	965a                	add	a2,a2,s6
    802053c4:	85d2                	mv	a1,s4
    802053c6:	6928                	ld	a0,80(a0)
    802053c8:	ffffe097          	auipc	ra,0xffffe
    802053cc:	ae6080e7          	jalr	-1306(ra) # 80202eae <copyout>
    802053d0:	f6055fe3          	bgez	a0,8020534e <readi+0x60>
                brelse(bp);
    802053d4:	854a                	mv	a0,s2
    802053d6:	fffff097          	auipc	ra,0xfffff
    802053da:	4f2080e7          	jalr	1266(ra) # 802048c8 <brelse>
                tot = -1;
    802053de:	59fd                	li	s3,-1
                break;
    802053e0:	6946                	ld	s2,80(sp)
    802053e2:	7ae2                	ld	s5,56(sp)
    802053e4:	7b42                	ld	s6,48(sp)
    802053e6:	6d42                	ld	s10,16(sp)
    802053e8:	6da2                	ld	s11,8(sp)
    802053ea:	a831                	j	80205406 <readi+0x118>
    802053ec:	6946                	ld	s2,80(sp)
    802053ee:	7ae2                	ld	s5,56(sp)
    802053f0:	7b42                	ld	s6,48(sp)
    802053f2:	6d42                	ld	s10,16(sp)
    802053f4:	6da2                	ld	s11,8(sp)
    802053f6:	a801                	j	80205406 <readi+0x118>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    802053f8:	89de                	mv	s3,s7
    802053fa:	a031                	j	80205406 <readi+0x118>
    802053fc:	6946                	ld	s2,80(sp)
    802053fe:	7ae2                	ld	s5,56(sp)
    80205400:	7b42                	ld	s6,48(sp)
    80205402:	6d42                	ld	s10,16(sp)
    80205404:	6da2                	ld	s11,8(sp)
    }
    return tot;
    80205406:	0009851b          	sext.w	a0,s3
    8020540a:	69a6                	ld	s3,72(sp)
}
    8020540c:	70a6                	ld	ra,104(sp)
    8020540e:	7406                	ld	s0,96(sp)
    80205410:	64e6                	ld	s1,88(sp)
    80205412:	6a06                	ld	s4,64(sp)
    80205414:	7ba2                	ld	s7,40(sp)
    80205416:	7c02                	ld	s8,32(sp)
    80205418:	6ce2                	ld	s9,24(sp)
    8020541a:	6165                	addi	sp,sp,112
    8020541c:	8082                	ret
    if (off > ip->size || off + n < off) return 0;
    8020541e:	4501                	li	a0,0
}
    80205420:	8082                	ret

0000000080205422 <writei>:

/* Write n bytes at off from src. Grows the file if needed. Caller holds lock. */
int writei(struct inode *ip, int user_src, uint64 src, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return -1;
    80205422:	457c                	lw	a5,76(a0)
    80205424:	14d7e063          	bltu	a5,a3,80205564 <writei+0x142>
{
    80205428:	7159                	addi	sp,sp,-112
    8020542a:	f486                	sd	ra,104(sp)
    8020542c:	f0a2                	sd	s0,96(sp)
    8020542e:	e8ca                	sd	s2,80(sp)
    80205430:	fc56                	sd	s5,56(sp)
    80205432:	f45e                	sd	s7,40(sp)
    80205434:	f062                	sd	s8,32(sp)
    80205436:	ec66                	sd	s9,24(sp)
    80205438:	1880                	addi	s0,sp,112
    8020543a:	8baa                	mv	s7,a0
    8020543c:	8cae                	mv	s9,a1
    8020543e:	8ab2                	mv	s5,a2
    80205440:	8936                	mv	s2,a3
    80205442:	8c3a                	mv	s8,a4
    if (off > ip->size || off + n < off) return -1;
    80205444:	00e687bb          	addw	a5,a3,a4
    80205448:	12d7e063          	bltu	a5,a3,80205568 <writei+0x146>
    if (off + n > MAXFILE * BSIZE) return -1;
    8020544c:	00043737          	lui	a4,0x43
    80205450:	10f76e63          	bltu	a4,a5,8020556c <writei+0x14a>
    80205454:	e4ce                	sd	s3,72(sp)

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205456:	0e0c0f63          	beqz	s8,80205554 <writei+0x132>
    8020545a:	eca6                	sd	s1,88(sp)
    8020545c:	e0d2                	sd	s4,64(sp)
    8020545e:	f85a                	sd	s6,48(sp)
    80205460:	e86a                	sd	s10,16(sp)
    80205462:	e46e                	sd	s11,8(sp)
    80205464:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;                     /* disk full: partial write */
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80205466:	40000d13          	li	s10,1024
    8020546a:	a081                	j	802054aa <writei+0x88>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
                brelse(bp);
                break;
            }
        } else {
            memmove(bp->data + off % BSIZE, (void *)src, m);
    8020546c:	05848513          	addi	a0,s1,88
    80205470:	020a1613          	slli	a2,s4,0x20
    80205474:	9201                	srli	a2,a2,0x20
    80205476:	85d6                	mv	a1,s5
    80205478:	955a                	add	a0,a0,s6
    8020547a:	ffffb097          	auipc	ra,0xffffb
    8020547e:	202080e7          	jalr	514(ra) # 8020067c <memmove>
        }
        bwrite(bp);
    80205482:	8526                	mv	a0,s1
    80205484:	fffff097          	auipc	ra,0xfffff
    80205488:	406080e7          	jalr	1030(ra) # 8020488a <bwrite>
        brelse(bp);
    8020548c:	8526                	mv	a0,s1
    8020548e:	fffff097          	auipc	ra,0xfffff
    80205492:	43a080e7          	jalr	1082(ra) # 802048c8 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205496:	013d89bb          	addw	s3,s11,s3
    8020549a:	012d893b          	addw	s2,s11,s2
    8020549e:	1d82                	slli	s11,s11,0x20
    802054a0:	020ddd93          	srli	s11,s11,0x20
    802054a4:	9aee                	add	s5,s5,s11
    802054a6:	0789fb63          	bgeu	s3,s8,8020551c <writei+0xfa>
        uint32 addr = bmap(ip, off / BSIZE);
    802054aa:	00a9559b          	srliw	a1,s2,0xa
    802054ae:	855e                	mv	a0,s7
    802054b0:	fffff097          	auipc	ra,0xfffff
    802054b4:	664080e7          	jalr	1636(ra) # 80204b14 <bmap>
    802054b8:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;                     /* disk full: partial write */
    802054bc:	c1a5                	beqz	a1,8020551c <writei+0xfa>
        struct buf *bp = bread(ip->dev, addr);
    802054be:	000ba503          	lw	a0,0(s7)
    802054c2:	fffff097          	auipc	ra,0xfffff
    802054c6:	2d6080e7          	jalr	726(ra) # 80204798 <bread>
    802054ca:	84aa                	mv	s1,a0
        m = BSIZE - off % BSIZE;
    802054cc:	3ff97b13          	andi	s6,s2,1023
        if (m > n - tot) m = n - tot;
    802054d0:	413c07bb          	subw	a5,s8,s3
        m = BSIZE - off % BSIZE;
    802054d4:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    802054d8:	8a3e                	mv	s4,a5
    802054da:	2781                	sext.w	a5,a5
    802054dc:	0007069b          	sext.w	a3,a4
    802054e0:	00f6f363          	bgeu	a3,a5,802054e6 <writei+0xc4>
    802054e4:	8a3a                	mv	s4,a4
    802054e6:	000a0d9b          	sext.w	s11,s4
        if (user_src) {
    802054ea:	f80c81e3          	beqz	s9,8020546c <writei+0x4a>
            if (copyin(myproc()->pagetable,
    802054ee:	ffffc097          	auipc	ra,0xffffc
    802054f2:	1ec080e7          	jalr	492(ra) # 802016da <myproc>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
    802054f6:	05848593          	addi	a1,s1,88
            if (copyin(myproc()->pagetable,
    802054fa:	020a1693          	slli	a3,s4,0x20
    802054fe:	9281                	srli	a3,a3,0x20
    80205500:	8656                	mv	a2,s5
    80205502:	95da                	add	a1,a1,s6
    80205504:	6928                	ld	a0,80(a0)
    80205506:	ffffe097          	auipc	ra,0xffffe
    8020550a:	a9c080e7          	jalr	-1380(ra) # 80202fa2 <copyin>
    8020550e:	f6055ae3          	bgez	a0,80205482 <writei+0x60>
                brelse(bp);
    80205512:	8526                	mv	a0,s1
    80205514:	fffff097          	auipc	ra,0xfffff
    80205518:	3b4080e7          	jalr	948(ra) # 802048c8 <brelse>
    }
    if (off > ip->size) ip->size = off;
    8020551c:	04cba783          	lw	a5,76(s7)
    80205520:	0327fc63          	bgeu	a5,s2,80205558 <writei+0x136>
    80205524:	052ba623          	sw	s2,76(s7)
    80205528:	64e6                	ld	s1,88(sp)
    8020552a:	6a06                	ld	s4,64(sp)
    8020552c:	7b42                	ld	s6,48(sp)
    8020552e:	6d42                	ld	s10,16(sp)
    80205530:	6da2                	ld	s11,8(sp)
    iupdate(ip);                    /* size and any new addrs[] hit the disk */
    80205532:	855e                	mv	a0,s7
    80205534:	00000097          	auipc	ra,0x0
    80205538:	9c0080e7          	jalr	-1600(ra) # 80204ef4 <iupdate>
    return tot;
    8020553c:	0009851b          	sext.w	a0,s3
    80205540:	69a6                	ld	s3,72(sp)
}
    80205542:	70a6                	ld	ra,104(sp)
    80205544:	7406                	ld	s0,96(sp)
    80205546:	6946                	ld	s2,80(sp)
    80205548:	7ae2                	ld	s5,56(sp)
    8020554a:	7ba2                	ld	s7,40(sp)
    8020554c:	7c02                	ld	s8,32(sp)
    8020554e:	6ce2                	ld	s9,24(sp)
    80205550:	6165                	addi	sp,sp,112
    80205552:	8082                	ret
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205554:	89e2                	mv	s3,s8
    80205556:	bff1                	j	80205532 <writei+0x110>
    80205558:	64e6                	ld	s1,88(sp)
    8020555a:	6a06                	ld	s4,64(sp)
    8020555c:	7b42                	ld	s6,48(sp)
    8020555e:	6d42                	ld	s10,16(sp)
    80205560:	6da2                	ld	s11,8(sp)
    80205562:	bfc1                	j	80205532 <writei+0x110>
    if (off > ip->size || off + n < off) return -1;
    80205564:	557d                	li	a0,-1
}
    80205566:	8082                	ret
    if (off > ip->size || off + n < off) return -1;
    80205568:	557d                	li	a0,-1
    8020556a:	bfe1                	j	80205542 <writei+0x120>
    if (off + n > MAXFILE * BSIZE) return -1;
    8020556c:	557d                	li	a0,-1
    8020556e:	bfd1                	j	80205542 <writei+0x120>

0000000080205570 <namecmp>:

/* ---------- directories ---------- */

int namecmp(const char *s, const char *t) { return strncmp(s, t, DIRSIZ); }
    80205570:	1141                	addi	sp,sp,-16
    80205572:	e406                	sd	ra,8(sp)
    80205574:	e022                	sd	s0,0(sp)
    80205576:	0800                	addi	s0,sp,16
    80205578:	4671                	li	a2,28
    8020557a:	ffffb097          	auipc	ra,0xffffb
    8020557e:	172080e7          	jalr	370(ra) # 802006ec <strncmp>
    80205582:	60a2                	ld	ra,8(sp)
    80205584:	6402                	ld	s0,0(sp)
    80205586:	0141                	addi	sp,sp,16
    80205588:	8082                	ret

000000008020558a <dirlookup>:

/* Look up name in directory dp. Returns unlocked inode; *poff = entry offset. */
struct inode *dirlookup(struct inode *dp, char *name, uint32 *poff)
{
    8020558a:	715d                	addi	sp,sp,-80
    8020558c:	e486                	sd	ra,72(sp)
    8020558e:	e0a2                	sd	s0,64(sp)
    80205590:	fc26                	sd	s1,56(sp)
    80205592:	f84a                	sd	s2,48(sp)
    80205594:	f44e                	sd	s3,40(sp)
    80205596:	f052                	sd	s4,32(sp)
    80205598:	0880                	addi	s0,sp,80
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    8020559a:	04455703          	lhu	a4,68(a0)
    8020559e:	4785                	li	a5,1
    802055a0:	00f71a63          	bne	a4,a5,802055b4 <dirlookup+0x2a>
    802055a4:	892a                	mv	s2,a0
    802055a6:	89ae                	mv	s3,a1
    802055a8:	8a32                	mv	s4,a2

    struct dirent de;
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    802055aa:	457c                	lw	a5,76(a0)
    802055ac:	4481                	li	s1,0
        if (namecmp(name, de.name) == 0) {
            if (poff) *poff = off;
            return iget(dp->dev, de.inum);
        }
    }
    return 0;
    802055ae:	4501                	li	a0,0
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    802055b0:	eb85                	bnez	a5,802055e0 <dirlookup+0x56>
    802055b2:	a8bd                	j	80205630 <dirlookup+0xa6>
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    802055b4:	00002517          	auipc	a0,0x2
    802055b8:	5dc50513          	addi	a0,a0,1500 # 80207b90 <etext+0xb90>
    802055bc:	ffffb097          	auipc	ra,0xffffb
    802055c0:	ffe080e7          	jalr	-2(ra) # 802005ba <panic>
            panic("dirlookup: short directory read");
    802055c4:	00002517          	auipc	a0,0x2
    802055c8:	5ec50513          	addi	a0,a0,1516 # 80207bb0 <etext+0xbb0>
    802055cc:	ffffb097          	auipc	ra,0xffffb
    802055d0:	fee080e7          	jalr	-18(ra) # 802005ba <panic>
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    802055d4:	0204849b          	addiw	s1,s1,32
    802055d8:	04c92783          	lw	a5,76(s2)
    802055dc:	04f4f963          	bgeu	s1,a5,8020562e <dirlookup+0xa4>
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    802055e0:	02000713          	li	a4,32
    802055e4:	86a6                	mv	a3,s1
    802055e6:	fb040613          	addi	a2,s0,-80
    802055ea:	4581                	li	a1,0
    802055ec:	854a                	mv	a0,s2
    802055ee:	00000097          	auipc	ra,0x0
    802055f2:	d00080e7          	jalr	-768(ra) # 802052ee <readi>
    802055f6:	02000793          	li	a5,32
    802055fa:	fcf515e3          	bne	a0,a5,802055c4 <dirlookup+0x3a>
        if (de.inum == 0) continue;
    802055fe:	fb042783          	lw	a5,-80(s0)
    80205602:	dbe9                	beqz	a5,802055d4 <dirlookup+0x4a>
        if (namecmp(name, de.name) == 0) {
    80205604:	fb440593          	addi	a1,s0,-76
    80205608:	854e                	mv	a0,s3
    8020560a:	00000097          	auipc	ra,0x0
    8020560e:	f66080e7          	jalr	-154(ra) # 80205570 <namecmp>
    80205612:	f169                	bnez	a0,802055d4 <dirlookup+0x4a>
            if (poff) *poff = off;
    80205614:	000a0463          	beqz	s4,8020561c <dirlookup+0x92>
    80205618:	009a2023          	sw	s1,0(s4) # 2000 <_entry-0x801fe000>
            return iget(dp->dev, de.inum);
    8020561c:	fb042583          	lw	a1,-80(s0)
    80205620:	00092503          	lw	a0,0(s2)
    80205624:	fffff097          	auipc	ra,0xfffff
    80205628:	5e0080e7          	jalr	1504(ra) # 80204c04 <iget>
    8020562c:	a011                	j	80205630 <dirlookup+0xa6>
    return 0;
    8020562e:	4501                	li	a0,0
}
    80205630:	60a6                	ld	ra,72(sp)
    80205632:	6406                	ld	s0,64(sp)
    80205634:	74e2                	ld	s1,56(sp)
    80205636:	7942                	ld	s2,48(sp)
    80205638:	79a2                	ld	s3,40(sp)
    8020563a:	7a02                	ld	s4,32(sp)
    8020563c:	6161                	addi	sp,sp,80
    8020563e:	8082                	ret

0000000080205640 <namex>:
}

/* Walk path from / (or the cwd). If parent, stop one level early and copy the
 * final element into name. The RETURNED inode is unlocked and referenced. */
static struct inode *namex(char *path, int nameiparent_, char *name)
{
    80205640:	711d                	addi	sp,sp,-96
    80205642:	ec86                	sd	ra,88(sp)
    80205644:	e8a2                	sd	s0,80(sp)
    80205646:	e4a6                	sd	s1,72(sp)
    80205648:	e0ca                	sd	s2,64(sp)
    8020564a:	fc4e                	sd	s3,56(sp)
    8020564c:	f852                	sd	s4,48(sp)
    8020564e:	f456                	sd	s5,40(sp)
    80205650:	f05a                	sd	s6,32(sp)
    80205652:	ec5e                	sd	s7,24(sp)
    80205654:	e862                	sd	s8,16(sp)
    80205656:	e466                	sd	s9,8(sp)
    80205658:	1080                	addi	s0,sp,96
    8020565a:	84aa                	mv	s1,a0
    8020565c:	8b2e                	mv	s6,a1
    8020565e:	8ab2                	mv	s5,a2
    struct inode *ip;
    if (*path == '/')
    80205660:	00054703          	lbu	a4,0(a0)
    80205664:	02f00793          	li	a5,47
    80205668:	02f70263          	beq	a4,a5,8020568c <namex+0x4c>
        ip = iget(ROOTDEV, ROOTINO);
    else
        ip = idup(myproc()->cwd);
    8020566c:	ffffc097          	auipc	ra,0xffffc
    80205670:	06e080e7          	jalr	110(ra) # 802016da <myproc>
    80205674:	15053503          	ld	a0,336(a0)
    80205678:	00000097          	auipc	ra,0x0
    8020567c:	90a080e7          	jalr	-1782(ra) # 80204f82 <idup>
    80205680:	8a2a                	mv	s4,a0
    while (*path == '/') path++;
    80205682:	02f00913          	li	s2,47
    if (len >= DIRSIZ) {
    80205686:	4c6d                	li	s8,27

    while ((path = skipelem(path, name)) != 0) {
        ilock(ip);
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205688:	4b85                	li	s7,1
    8020568a:	a865                	j	80205742 <namex+0x102>
        ip = iget(ROOTDEV, ROOTINO);
    8020568c:	4585                	li	a1,1
    8020568e:	4501                	li	a0,0
    80205690:	fffff097          	auipc	ra,0xfffff
    80205694:	574080e7          	jalr	1396(ra) # 80204c04 <iget>
    80205698:	8a2a                	mv	s4,a0
    8020569a:	b7e5                	j	80205682 <namex+0x42>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    8020569c:	8552                	mv	a0,s4
    8020569e:	00000097          	auipc	ra,0x0
    802056a2:	bfe080e7          	jalr	-1026(ra) # 8020529c <iunlockput>
    802056a6:	4a01                	li	s4,0
        iunlockput(ip);
        ip = next;
    }
    if (nameiparent_) { iput(ip); return 0; }
    return ip;
}
    802056a8:	8552                	mv	a0,s4
    802056aa:	60e6                	ld	ra,88(sp)
    802056ac:	6446                	ld	s0,80(sp)
    802056ae:	64a6                	ld	s1,72(sp)
    802056b0:	6906                	ld	s2,64(sp)
    802056b2:	79e2                	ld	s3,56(sp)
    802056b4:	7a42                	ld	s4,48(sp)
    802056b6:	7aa2                	ld	s5,40(sp)
    802056b8:	7b02                	ld	s6,32(sp)
    802056ba:	6be2                	ld	s7,24(sp)
    802056bc:	6c42                	ld	s8,16(sp)
    802056be:	6ca2                	ld	s9,8(sp)
    802056c0:	6125                	addi	sp,sp,96
    802056c2:	8082                	ret
            iunlock(ip);                          /* stop at the parent */
    802056c4:	8552                	mv	a0,s4
    802056c6:	00000097          	auipc	ra,0x0
    802056ca:	9c0080e7          	jalr	-1600(ra) # 80205086 <iunlock>
            return ip;
    802056ce:	bfe9                	j	802056a8 <namex+0x68>
        if (next == 0) { iunlockput(ip); return 0; }
    802056d0:	8552                	mv	a0,s4
    802056d2:	00000097          	auipc	ra,0x0
    802056d6:	bca080e7          	jalr	-1078(ra) # 8020529c <iunlockput>
    802056da:	8a4e                	mv	s4,s3
    802056dc:	b7f1                	j	802056a8 <namex+0x68>
    int len = path - s;
    802056de:	40998cbb          	subw	s9,s3,s1
    if (len >= DIRSIZ) {
    802056e2:	099c5763          	bge	s8,s9,80205770 <namex+0x130>
        memmove(name, s, DIRSIZ);                 /* truncate long names */
    802056e6:	4671                	li	a2,28
    802056e8:	85a6                	mv	a1,s1
    802056ea:	8556                	mv	a0,s5
    802056ec:	ffffb097          	auipc	ra,0xffffb
    802056f0:	f90080e7          	jalr	-112(ra) # 8020067c <memmove>
    802056f4:	84ce                	mv	s1,s3
    while (*path == '/') path++;
    802056f6:	0004c783          	lbu	a5,0(s1)
    802056fa:	01279763          	bne	a5,s2,80205708 <namex+0xc8>
    802056fe:	0485                	addi	s1,s1,1
    80205700:	0004c783          	lbu	a5,0(s1)
    80205704:	ff278de3          	beq	a5,s2,802056fe <namex+0xbe>
        ilock(ip);
    80205708:	8552                	mv	a0,s4
    8020570a:	00000097          	auipc	ra,0x0
    8020570e:	8b6080e7          	jalr	-1866(ra) # 80204fc0 <ilock>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205712:	044a5783          	lhu	a5,68(s4)
    80205716:	f97793e3          	bne	a5,s7,8020569c <namex+0x5c>
        if (nameiparent_ && *path == '\0') {
    8020571a:	000b0563          	beqz	s6,80205724 <namex+0xe4>
    8020571e:	0004c783          	lbu	a5,0(s1)
    80205722:	d3cd                	beqz	a5,802056c4 <namex+0x84>
        struct inode *next = dirlookup(ip, name, 0);
    80205724:	4601                	li	a2,0
    80205726:	85d6                	mv	a1,s5
    80205728:	8552                	mv	a0,s4
    8020572a:	00000097          	auipc	ra,0x0
    8020572e:	e60080e7          	jalr	-416(ra) # 8020558a <dirlookup>
    80205732:	89aa                	mv	s3,a0
        if (next == 0) { iunlockput(ip); return 0; }
    80205734:	dd51                	beqz	a0,802056d0 <namex+0x90>
        iunlockput(ip);
    80205736:	8552                	mv	a0,s4
    80205738:	00000097          	auipc	ra,0x0
    8020573c:	b64080e7          	jalr	-1180(ra) # 8020529c <iunlockput>
        ip = next;
    80205740:	8a4e                	mv	s4,s3
    while (*path == '/') path++;
    80205742:	0004c783          	lbu	a5,0(s1)
    80205746:	01279763          	bne	a5,s2,80205754 <namex+0x114>
    8020574a:	0485                	addi	s1,s1,1
    8020574c:	0004c783          	lbu	a5,0(s1)
    80205750:	ff278de3          	beq	a5,s2,8020574a <namex+0x10a>
    if (*path == 0) return 0;
    80205754:	cb95                	beqz	a5,80205788 <namex+0x148>
    while (*path != '/' && *path != 0) path++;
    80205756:	0004c783          	lbu	a5,0(s1)
    8020575a:	89a6                	mv	s3,s1
    int len = path - s;
    8020575c:	4c81                	li	s9,0
    while (*path != '/' && *path != 0) path++;
    8020575e:	01278963          	beq	a5,s2,80205770 <namex+0x130>
    80205762:	dfb5                	beqz	a5,802056de <namex+0x9e>
    80205764:	0985                	addi	s3,s3,1
    80205766:	0009c783          	lbu	a5,0(s3)
    8020576a:	ff279ce3          	bne	a5,s2,80205762 <namex+0x122>
    8020576e:	bf85                	j	802056de <namex+0x9e>
        memmove(name, s, len);
    80205770:	8666                	mv	a2,s9
    80205772:	85a6                	mv	a1,s1
    80205774:	8556                	mv	a0,s5
    80205776:	ffffb097          	auipc	ra,0xffffb
    8020577a:	f06080e7          	jalr	-250(ra) # 8020067c <memmove>
        name[len] = 0;
    8020577e:	9cd6                	add	s9,s9,s5
    80205780:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x801fe000>
    80205784:	84ce                	mv	s1,s3
    80205786:	bf85                	j	802056f6 <namex+0xb6>
    if (nameiparent_) { iput(ip); return 0; }
    80205788:	f20b00e3          	beqz	s6,802056a8 <namex+0x68>
    8020578c:	8552                	mv	a0,s4
    8020578e:	00000097          	auipc	ra,0x0
    80205792:	9f0080e7          	jalr	-1552(ra) # 8020517e <iput>
    80205796:	4a01                	li	s4,0
    80205798:	bf01                	j	802056a8 <namex+0x68>

000000008020579a <dirlink>:
{
    8020579a:	715d                	addi	sp,sp,-80
    8020579c:	e486                	sd	ra,72(sp)
    8020579e:	e0a2                	sd	s0,64(sp)
    802057a0:	f84a                	sd	s2,48(sp)
    802057a2:	f44e                	sd	s3,40(sp)
    802057a4:	f052                	sd	s4,32(sp)
    802057a6:	0880                	addi	s0,sp,80
    802057a8:	892a                	mv	s2,a0
    802057aa:	8a2e                	mv	s4,a1
    802057ac:	89b2                	mv	s3,a2
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    802057ae:	4601                	li	a2,0
    802057b0:	00000097          	auipc	ra,0x0
    802057b4:	dda080e7          	jalr	-550(ra) # 8020558a <dirlookup>
    802057b8:	e141                	bnez	a0,80205838 <dirlink+0x9e>
    802057ba:	fc26                	sd	s1,56(sp)
    for (off = 0; off < dp->size; off += sizeof(de)) {
    802057bc:	04c92483          	lw	s1,76(s2)
    802057c0:	c895                	beqz	s1,802057f4 <dirlink+0x5a>
    802057c2:	4481                	li	s1,0
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    802057c4:	02000713          	li	a4,32
    802057c8:	86a6                	mv	a3,s1
    802057ca:	fb040613          	addi	a2,s0,-80
    802057ce:	4581                	li	a1,0
    802057d0:	854a                	mv	a0,s2
    802057d2:	00000097          	auipc	ra,0x0
    802057d6:	b1c080e7          	jalr	-1252(ra) # 802052ee <readi>
    802057da:	02000793          	li	a5,32
    802057de:	06f51363          	bne	a0,a5,80205844 <dirlink+0xaa>
        if (de.inum == 0) break;                  /* reuse a freed slot */
    802057e2:	fb042783          	lw	a5,-80(s0)
    802057e6:	c799                	beqz	a5,802057f4 <dirlink+0x5a>
    for (off = 0; off < dp->size; off += sizeof(de)) {
    802057e8:	0204849b          	addiw	s1,s1,32
    802057ec:	04c92783          	lw	a5,76(s2)
    802057f0:	fcf4eae3          	bltu	s1,a5,802057c4 <dirlink+0x2a>
    strncpy(de.name, name, DIRSIZ);
    802057f4:	4671                	li	a2,28
    802057f6:	85d2                	mv	a1,s4
    802057f8:	fb440513          	addi	a0,s0,-76
    802057fc:	ffffb097          	auipc	ra,0xffffb
    80205800:	f26080e7          	jalr	-218(ra) # 80200722 <strncpy>
    de.inum = inum;
    80205804:	fb342823          	sw	s3,-80(s0)
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205808:	02000713          	li	a4,32
    8020580c:	86a6                	mv	a3,s1
    8020580e:	fb040613          	addi	a2,s0,-80
    80205812:	4581                	li	a1,0
    80205814:	854a                	mv	a0,s2
    80205816:	00000097          	auipc	ra,0x0
    8020581a:	c0c080e7          	jalr	-1012(ra) # 80205422 <writei>
    8020581e:	1501                	addi	a0,a0,-32
    80205820:	00a03533          	snez	a0,a0
    80205824:	40a00533          	neg	a0,a0
    80205828:	74e2                	ld	s1,56(sp)
}
    8020582a:	60a6                	ld	ra,72(sp)
    8020582c:	6406                	ld	s0,64(sp)
    8020582e:	7942                	ld	s2,48(sp)
    80205830:	79a2                	ld	s3,40(sp)
    80205832:	7a02                	ld	s4,32(sp)
    80205834:	6161                	addi	sp,sp,80
    80205836:	8082                	ret
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    80205838:	00000097          	auipc	ra,0x0
    8020583c:	946080e7          	jalr	-1722(ra) # 8020517e <iput>
    80205840:	557d                	li	a0,-1
    80205842:	b7e5                	j	8020582a <dirlink+0x90>
            panic("dirlink: short directory read");
    80205844:	00002517          	auipc	a0,0x2
    80205848:	38c50513          	addi	a0,a0,908 # 80207bd0 <etext+0xbd0>
    8020584c:	ffffb097          	auipc	ra,0xffffb
    80205850:	d6e080e7          	jalr	-658(ra) # 802005ba <panic>

0000000080205854 <namei>:

struct inode *namei(char *path)
{
    80205854:	7179                	addi	sp,sp,-48
    80205856:	f406                	sd	ra,40(sp)
    80205858:	f022                	sd	s0,32(sp)
    8020585a:	1800                	addi	s0,sp,48
    char name[DIRSIZ];
    return namex(path, 0, name);
    8020585c:	fd040613          	addi	a2,s0,-48
    80205860:	4581                	li	a1,0
    80205862:	00000097          	auipc	ra,0x0
    80205866:	dde080e7          	jalr	-546(ra) # 80205640 <namex>
}
    8020586a:	70a2                	ld	ra,40(sp)
    8020586c:	7402                	ld	s0,32(sp)
    8020586e:	6145                	addi	sp,sp,48
    80205870:	8082                	ret

0000000080205872 <nameiparent>:

struct inode *nameiparent(char *path, char *name)
{
    80205872:	1141                	addi	sp,sp,-16
    80205874:	e406                	sd	ra,8(sp)
    80205876:	e022                	sd	s0,0(sp)
    80205878:	0800                	addi	s0,sp,16
    8020587a:	862e                	mv	a2,a1
    return namex(path, 1, name);
    8020587c:	4585                	li	a1,1
    8020587e:	00000097          	auipc	ra,0x0
    80205882:	dc2080e7          	jalr	-574(ra) # 80205640 <namex>
}
    80205886:	60a2                	ld	ra,8(sp)
    80205888:	6402                	ld	s0,0(sp)
    8020588a:	0141                	addi	sp,sp,16
    8020588c:	8082                	ret

000000008020588e <fileinit>:
static struct {
    struct spinlock lock;
    struct file file[NFILE];
} ftable;

void fileinit(void) { initlock(&ftable.lock, "ftable"); }
    8020588e:	1141                	addi	sp,sp,-16
    80205890:	e406                	sd	ra,8(sp)
    80205892:	e022                	sd	s0,0(sp)
    80205894:	0800                	addi	s0,sp,16
    80205896:	00002597          	auipc	a1,0x2
    8020589a:	35a58593          	addi	a1,a1,858 # 80207bf0 <etext+0xbf0>
    8020589e:	00135517          	auipc	a0,0x135
    802058a2:	45250513          	addi	a0,a0,1106 # 8033acf0 <ftable>
    802058a6:	ffffc097          	auipc	ra,0xffffc
    802058aa:	9ce080e7          	jalr	-1586(ra) # 80201274 <initlock>
    802058ae:	60a2                	ld	ra,8(sp)
    802058b0:	6402                	ld	s0,0(sp)
    802058b2:	0141                	addi	sp,sp,16
    802058b4:	8082                	ret

00000000802058b6 <filealloc>:

struct file *filealloc(void)
{
    802058b6:	1101                	addi	sp,sp,-32
    802058b8:	ec06                	sd	ra,24(sp)
    802058ba:	e822                	sd	s0,16(sp)
    802058bc:	e426                	sd	s1,8(sp)
    802058be:	1000                	addi	s0,sp,32
    acquire(&ftable.lock);
    802058c0:	00135517          	auipc	a0,0x135
    802058c4:	43050513          	addi	a0,a0,1072 # 8033acf0 <ftable>
    802058c8:	ffffc097          	auipc	ra,0xffffc
    802058cc:	a28080e7          	jalr	-1496(ra) # 802012f0 <acquire>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    802058d0:	00135497          	auipc	s1,0x135
    802058d4:	43848493          	addi	s1,s1,1080 # 8033ad08 <ftable+0x18>
    802058d8:	00136717          	auipc	a4,0x136
    802058dc:	3d070713          	addi	a4,a4,976 # 8033bca8 <ftable+0xfb8>
        if (f->ref == 0) {
    802058e0:	40dc                	lw	a5,4(s1)
    802058e2:	cf99                	beqz	a5,80205900 <filealloc+0x4a>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    802058e4:	02848493          	addi	s1,s1,40
    802058e8:	fee49ce3          	bne	s1,a4,802058e0 <filealloc+0x2a>
            f->ref = 1;
            release(&ftable.lock);
            return f;
        }
    }
    release(&ftable.lock);
    802058ec:	00135517          	auipc	a0,0x135
    802058f0:	40450513          	addi	a0,a0,1028 # 8033acf0 <ftable>
    802058f4:	ffffc097          	auipc	ra,0xffffc
    802058f8:	ab0080e7          	jalr	-1360(ra) # 802013a4 <release>
    return 0;
    802058fc:	4481                	li	s1,0
    802058fe:	a819                	j	80205914 <filealloc+0x5e>
            f->ref = 1;
    80205900:	4785                	li	a5,1
    80205902:	c0dc                	sw	a5,4(s1)
            release(&ftable.lock);
    80205904:	00135517          	auipc	a0,0x135
    80205908:	3ec50513          	addi	a0,a0,1004 # 8033acf0 <ftable>
    8020590c:	ffffc097          	auipc	ra,0xffffc
    80205910:	a98080e7          	jalr	-1384(ra) # 802013a4 <release>
}
    80205914:	8526                	mv	a0,s1
    80205916:	60e2                	ld	ra,24(sp)
    80205918:	6442                	ld	s0,16(sp)
    8020591a:	64a2                	ld	s1,8(sp)
    8020591c:	6105                	addi	sp,sp,32
    8020591e:	8082                	ret

0000000080205920 <filedup>:

struct file *filedup(struct file *f)
{
    80205920:	1101                	addi	sp,sp,-32
    80205922:	ec06                	sd	ra,24(sp)
    80205924:	e822                	sd	s0,16(sp)
    80205926:	e426                	sd	s1,8(sp)
    80205928:	1000                	addi	s0,sp,32
    8020592a:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    8020592c:	00135517          	auipc	a0,0x135
    80205930:	3c450513          	addi	a0,a0,964 # 8033acf0 <ftable>
    80205934:	ffffc097          	auipc	ra,0xffffc
    80205938:	9bc080e7          	jalr	-1604(ra) # 802012f0 <acquire>
    if (f->ref < 1) panic("filedup");
    8020593c:	40dc                	lw	a5,4(s1)
    8020593e:	02f05263          	blez	a5,80205962 <filedup+0x42>
    f->ref++;
    80205942:	2785                	addiw	a5,a5,1
    80205944:	c0dc                	sw	a5,4(s1)
    release(&ftable.lock);
    80205946:	00135517          	auipc	a0,0x135
    8020594a:	3aa50513          	addi	a0,a0,938 # 8033acf0 <ftable>
    8020594e:	ffffc097          	auipc	ra,0xffffc
    80205952:	a56080e7          	jalr	-1450(ra) # 802013a4 <release>
    return f;
}
    80205956:	8526                	mv	a0,s1
    80205958:	60e2                	ld	ra,24(sp)
    8020595a:	6442                	ld	s0,16(sp)
    8020595c:	64a2                	ld	s1,8(sp)
    8020595e:	6105                	addi	sp,sp,32
    80205960:	8082                	ret
    if (f->ref < 1) panic("filedup");
    80205962:	00002517          	auipc	a0,0x2
    80205966:	29650513          	addi	a0,a0,662 # 80207bf8 <etext+0xbf8>
    8020596a:	ffffb097          	auipc	ra,0xffffb
    8020596e:	c50080e7          	jalr	-944(ra) # 802005ba <panic>

0000000080205972 <fileclose>:

void fileclose(struct file *f)
{
    80205972:	7139                	addi	sp,sp,-64
    80205974:	fc06                	sd	ra,56(sp)
    80205976:	f822                	sd	s0,48(sp)
    80205978:	f426                	sd	s1,40(sp)
    8020597a:	0080                	addi	s0,sp,64
    8020597c:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    8020597e:	00135517          	auipc	a0,0x135
    80205982:	37250513          	addi	a0,a0,882 # 8033acf0 <ftable>
    80205986:	ffffc097          	auipc	ra,0xffffc
    8020598a:	96a080e7          	jalr	-1686(ra) # 802012f0 <acquire>
    if (f->ref < 1) panic("fileclose");
    8020598e:	40dc                	lw	a5,4(s1)
    80205990:	04f05c63          	blez	a5,802059e8 <fileclose+0x76>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80205994:	37fd                	addiw	a5,a5,-1
    80205996:	0007871b          	sext.w	a4,a5
    8020599a:	c0dc                	sw	a5,4(s1)
    8020599c:	06e04263          	bgtz	a4,80205a00 <fileclose+0x8e>
    802059a0:	f04a                	sd	s2,32(sp)
    802059a2:	ec4e                	sd	s3,24(sp)
    802059a4:	e852                	sd	s4,16(sp)
    802059a6:	e456                	sd	s5,8(sp)

    struct file ff = *f;                 /* copy, then free the slot */
    802059a8:	0004a903          	lw	s2,0(s1)
    802059ac:	0094ca83          	lbu	s5,9(s1)
    802059b0:	0104ba03          	ld	s4,16(s1)
    802059b4:	0184b983          	ld	s3,24(s1)
    f->ref = 0;
    802059b8:	0004a223          	sw	zero,4(s1)
    f->type = FD_NONE;
    802059bc:	0004a023          	sw	zero,0(s1)
    release(&ftable.lock);
    802059c0:	00135517          	auipc	a0,0x135
    802059c4:	33050513          	addi	a0,a0,816 # 8033acf0 <ftable>
    802059c8:	ffffc097          	auipc	ra,0xffffc
    802059cc:	9dc080e7          	jalr	-1572(ra) # 802013a4 <release>

    if (ff.type == FD_PIPE)
    802059d0:	4785                	li	a5,1
    802059d2:	04f90463          	beq	s2,a5,80205a1a <fileclose+0xa8>
        pipeclose(ff.pipe, ff.writable);
    else if (ff.type == FD_INODE || ff.type == FD_DEVICE)
    802059d6:	3979                	addiw	s2,s2,-2
    802059d8:	4785                	li	a5,1
    802059da:	0527fb63          	bgeu	a5,s2,80205a30 <fileclose+0xbe>
    802059de:	7902                	ld	s2,32(sp)
    802059e0:	69e2                	ld	s3,24(sp)
    802059e2:	6a42                	ld	s4,16(sp)
    802059e4:	6aa2                	ld	s5,8(sp)
    802059e6:	a02d                	j	80205a10 <fileclose+0x9e>
    802059e8:	f04a                	sd	s2,32(sp)
    802059ea:	ec4e                	sd	s3,24(sp)
    802059ec:	e852                	sd	s4,16(sp)
    802059ee:	e456                	sd	s5,8(sp)
    if (f->ref < 1) panic("fileclose");
    802059f0:	00002517          	auipc	a0,0x2
    802059f4:	21050513          	addi	a0,a0,528 # 80207c00 <etext+0xc00>
    802059f8:	ffffb097          	auipc	ra,0xffffb
    802059fc:	bc2080e7          	jalr	-1086(ra) # 802005ba <panic>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80205a00:	00135517          	auipc	a0,0x135
    80205a04:	2f050513          	addi	a0,a0,752 # 8033acf0 <ftable>
    80205a08:	ffffc097          	auipc	ra,0xffffc
    80205a0c:	99c080e7          	jalr	-1636(ra) # 802013a4 <release>
        iput(ff.ip);
}
    80205a10:	70e2                	ld	ra,56(sp)
    80205a12:	7442                	ld	s0,48(sp)
    80205a14:	74a2                	ld	s1,40(sp)
    80205a16:	6121                	addi	sp,sp,64
    80205a18:	8082                	ret
        pipeclose(ff.pipe, ff.writable);
    80205a1a:	85d6                	mv	a1,s5
    80205a1c:	8552                	mv	a0,s4
    80205a1e:	00000097          	auipc	ra,0x0
    80205a22:	324080e7          	jalr	804(ra) # 80205d42 <pipeclose>
    80205a26:	7902                	ld	s2,32(sp)
    80205a28:	69e2                	ld	s3,24(sp)
    80205a2a:	6a42                	ld	s4,16(sp)
    80205a2c:	6aa2                	ld	s5,8(sp)
    80205a2e:	b7cd                	j	80205a10 <fileclose+0x9e>
        iput(ff.ip);
    80205a30:	854e                	mv	a0,s3
    80205a32:	fffff097          	auipc	ra,0xfffff
    80205a36:	74c080e7          	jalr	1868(ra) # 8020517e <iput>
    80205a3a:	7902                	ld	s2,32(sp)
    80205a3c:	69e2                	ld	s3,24(sp)
    80205a3e:	6a42                	ld	s4,16(sp)
    80205a40:	6aa2                	ld	s5,8(sp)
    80205a42:	b7f9                	j	80205a10 <fileclose+0x9e>

0000000080205a44 <filestat>:

int filestat(struct file *f, uint64 uaddr)
{
    if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80205a44:	411c                	lw	a5,0(a0)
    80205a46:	37f9                	addiw	a5,a5,-2
    80205a48:	4705                	li	a4,1
    80205a4a:	06f76063          	bltu	a4,a5,80205aaa <filestat+0x66>
{
    80205a4e:	7139                	addi	sp,sp,-64
    80205a50:	fc06                	sd	ra,56(sp)
    80205a52:	f822                	sd	s0,48(sp)
    80205a54:	f426                	sd	s1,40(sp)
    80205a56:	f04a                	sd	s2,32(sp)
    80205a58:	0080                	addi	s0,sp,64
    80205a5a:	84aa                	mv	s1,a0
    80205a5c:	892e                	mv	s2,a1
        struct stat st;
        ilock(f->ip);
    80205a5e:	6d08                	ld	a0,24(a0)
    80205a60:	fffff097          	auipc	ra,0xfffff
    80205a64:	560080e7          	jalr	1376(ra) # 80204fc0 <ilock>
        stati(f->ip, &st);
    80205a68:	fc840593          	addi	a1,s0,-56
    80205a6c:	6c88                	ld	a0,24(s1)
    80205a6e:	00000097          	auipc	ra,0x0
    80205a72:	856080e7          	jalr	-1962(ra) # 802052c4 <stati>
        iunlock(f->ip);
    80205a76:	6c88                	ld	a0,24(s1)
    80205a78:	fffff097          	auipc	ra,0xfffff
    80205a7c:	60e080e7          	jalr	1550(ra) # 80205086 <iunlock>
        if (copyout(myproc()->pagetable, uaddr, (char *)&st, sizeof(st)) < 0)
    80205a80:	ffffc097          	auipc	ra,0xffffc
    80205a84:	c5a080e7          	jalr	-934(ra) # 802016da <myproc>
    80205a88:	46e1                	li	a3,24
    80205a8a:	fc840613          	addi	a2,s0,-56
    80205a8e:	85ca                	mv	a1,s2
    80205a90:	6928                	ld	a0,80(a0)
    80205a92:	ffffd097          	auipc	ra,0xffffd
    80205a96:	41c080e7          	jalr	1052(ra) # 80202eae <copyout>
    80205a9a:	41f5551b          	sraiw	a0,a0,0x1f
            return -1;
        return 0;
    }
    return -1;
}
    80205a9e:	70e2                	ld	ra,56(sp)
    80205aa0:	7442                	ld	s0,48(sp)
    80205aa2:	74a2                	ld	s1,40(sp)
    80205aa4:	7902                	ld	s2,32(sp)
    80205aa6:	6121                	addi	sp,sp,64
    80205aa8:	8082                	ret
    return -1;
    80205aaa:	557d                	li	a0,-1
}
    80205aac:	8082                	ret

0000000080205aae <fileread>:

int fileread(struct file *f, uint64 uaddr, int n)
{
    80205aae:	7179                	addi	sp,sp,-48
    80205ab0:	f406                	sd	ra,40(sp)
    80205ab2:	f022                	sd	s0,32(sp)
    80205ab4:	e84a                	sd	s2,16(sp)
    80205ab6:	1800                	addi	s0,sp,48
    if (f->readable == 0) return -1;
    80205ab8:	00854783          	lbu	a5,8(a0)
    80205abc:	cbcd                	beqz	a5,80205b6e <fileread+0xc0>
    80205abe:	ec26                	sd	s1,24(sp)
    80205ac0:	e44e                	sd	s3,8(sp)
    80205ac2:	84aa                	mv	s1,a0
    80205ac4:	89ae                	mv	s3,a1
    80205ac6:	8932                	mv	s2,a2

    if (f->type == FD_PIPE)
    80205ac8:	411c                	lw	a5,0(a0)
    80205aca:	4705                	li	a4,1
    80205acc:	04e78963          	beq	a5,a4,80205b1e <fileread+0x70>
        return piperead(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80205ad0:	470d                	li	a4,3
    80205ad2:	04e78f63          	beq	a5,a4,80205b30 <fileread+0x82>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
        return devsw[f->major].read(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80205ad6:	4709                	li	a4,2
    80205ad8:	08e79363          	bne	a5,a4,80205b5e <fileread+0xb0>
        ilock(f->ip);
    80205adc:	6d08                	ld	a0,24(a0)
    80205ade:	fffff097          	auipc	ra,0xfffff
    80205ae2:	4e2080e7          	jalr	1250(ra) # 80204fc0 <ilock>
        int r = readi(f->ip, 1, uaddr, f->off, n);
    80205ae6:	874a                	mv	a4,s2
    80205ae8:	5094                	lw	a3,32(s1)
    80205aea:	864e                	mv	a2,s3
    80205aec:	4585                	li	a1,1
    80205aee:	6c88                	ld	a0,24(s1)
    80205af0:	fffff097          	auipc	ra,0xfffff
    80205af4:	7fe080e7          	jalr	2046(ra) # 802052ee <readi>
    80205af8:	892a                	mv	s2,a0
        if (r > 0) f->off += r;          /* offset update under the inode lock */
    80205afa:	00a05563          	blez	a0,80205b04 <fileread+0x56>
    80205afe:	509c                	lw	a5,32(s1)
    80205b00:	9fa9                	addw	a5,a5,a0
    80205b02:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80205b04:	6c88                	ld	a0,24(s1)
    80205b06:	fffff097          	auipc	ra,0xfffff
    80205b0a:	580080e7          	jalr	1408(ra) # 80205086 <iunlock>
        return r;
    80205b0e:	64e2                	ld	s1,24(sp)
    80205b10:	69a2                	ld	s3,8(sp)
    }
    panic("fileread");
}
    80205b12:	854a                	mv	a0,s2
    80205b14:	70a2                	ld	ra,40(sp)
    80205b16:	7402                	ld	s0,32(sp)
    80205b18:	6942                	ld	s2,16(sp)
    80205b1a:	6145                	addi	sp,sp,48
    80205b1c:	8082                	ret
        return piperead(f->pipe, uaddr, n);
    80205b1e:	6908                	ld	a0,16(a0)
    80205b20:	00000097          	auipc	ra,0x0
    80205b24:	38a080e7          	jalr	906(ra) # 80205eaa <piperead>
    80205b28:	892a                	mv	s2,a0
    80205b2a:	64e2                	ld	s1,24(sp)
    80205b2c:	69a2                	ld	s3,8(sp)
    80205b2e:	b7d5                	j	80205b12 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80205b30:	02451783          	lh	a5,36(a0)
    80205b34:	03079693          	slli	a3,a5,0x30
    80205b38:	92c1                	srli	a3,a3,0x30
    80205b3a:	4725                	li	a4,9
    80205b3c:	02d76b63          	bltu	a4,a3,80205b72 <fileread+0xc4>
    80205b40:	0792                	slli	a5,a5,0x4
    80205b42:	00135717          	auipc	a4,0x135
    80205b46:	10e70713          	addi	a4,a4,270 # 8033ac50 <devsw>
    80205b4a:	97ba                	add	a5,a5,a4
    80205b4c:	639c                	ld	a5,0(a5)
    80205b4e:	c795                	beqz	a5,80205b7a <fileread+0xcc>
        return devsw[f->major].read(uaddr, n);
    80205b50:	85b2                	mv	a1,a2
    80205b52:	854e                	mv	a0,s3
    80205b54:	9782                	jalr	a5
    80205b56:	892a                	mv	s2,a0
    80205b58:	64e2                	ld	s1,24(sp)
    80205b5a:	69a2                	ld	s3,8(sp)
    80205b5c:	bf5d                	j	80205b12 <fileread+0x64>
    panic("fileread");
    80205b5e:	00002517          	auipc	a0,0x2
    80205b62:	0b250513          	addi	a0,a0,178 # 80207c10 <etext+0xc10>
    80205b66:	ffffb097          	auipc	ra,0xffffb
    80205b6a:	a54080e7          	jalr	-1452(ra) # 802005ba <panic>
    if (f->readable == 0) return -1;
    80205b6e:	597d                	li	s2,-1
    80205b70:	b74d                	j	80205b12 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80205b72:	597d                	li	s2,-1
    80205b74:	64e2                	ld	s1,24(sp)
    80205b76:	69a2                	ld	s3,8(sp)
    80205b78:	bf69                	j	80205b12 <fileread+0x64>
    80205b7a:	597d                	li	s2,-1
    80205b7c:	64e2                	ld	s1,24(sp)
    80205b7e:	69a2                	ld	s3,8(sp)
    80205b80:	bf49                	j	80205b12 <fileread+0x64>

0000000080205b82 <filewrite>:

int filewrite(struct file *f, uint64 uaddr, int n)
{
    80205b82:	7179                	addi	sp,sp,-48
    80205b84:	f406                	sd	ra,40(sp)
    80205b86:	f022                	sd	s0,32(sp)
    80205b88:	e84a                	sd	s2,16(sp)
    80205b8a:	1800                	addi	s0,sp,48
    if (f->writable == 0) return -1;
    80205b8c:	00954783          	lbu	a5,9(a0)
    80205b90:	cfdd                	beqz	a5,80205c4e <filewrite+0xcc>
    80205b92:	ec26                	sd	s1,24(sp)
    80205b94:	e44e                	sd	s3,8(sp)
    80205b96:	84aa                	mv	s1,a0
    80205b98:	892e                	mv	s2,a1
    80205b9a:	89b2                	mv	s3,a2

    if (f->type == FD_PIPE)
    80205b9c:	411c                	lw	a5,0(a0)
    80205b9e:	4705                	li	a4,1
    80205ba0:	04e78c63          	beq	a5,a4,80205bf8 <filewrite+0x76>
        return pipewrite(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80205ba4:	470d                	li	a4,3
    80205ba6:	06e78263          	beq	a5,a4,80205c0a <filewrite+0x88>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
        return devsw[f->major].write(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80205baa:	4709                	li	a4,2
    80205bac:	08e79963          	bne	a5,a4,80205c3e <filewrite+0xbc>
        ilock(f->ip);
    80205bb0:	6d08                	ld	a0,24(a0)
    80205bb2:	fffff097          	auipc	ra,0xfffff
    80205bb6:	40e080e7          	jalr	1038(ra) # 80204fc0 <ilock>
        int r = writei(f->ip, 1, uaddr, f->off, n);
    80205bba:	874e                	mv	a4,s3
    80205bbc:	5094                	lw	a3,32(s1)
    80205bbe:	864a                	mv	a2,s2
    80205bc0:	4585                	li	a1,1
    80205bc2:	6c88                	ld	a0,24(s1)
    80205bc4:	00000097          	auipc	ra,0x0
    80205bc8:	85e080e7          	jalr	-1954(ra) # 80205422 <writei>
    80205bcc:	892a                	mv	s2,a0
        if (r > 0) f->off += r;
    80205bce:	00a05563          	blez	a0,80205bd8 <filewrite+0x56>
    80205bd2:	509c                	lw	a5,32(s1)
    80205bd4:	9fa9                	addw	a5,a5,a0
    80205bd6:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80205bd8:	6c88                	ld	a0,24(s1)
    80205bda:	fffff097          	auipc	ra,0xfffff
    80205bde:	4ac080e7          	jalr	1196(ra) # 80205086 <iunlock>
        return (r == n) ? n : -1;        /* short write = disk full = error */
    80205be2:	05298b63          	beq	s3,s2,80205c38 <filewrite+0xb6>
    80205be6:	597d                	li	s2,-1
    80205be8:	64e2                	ld	s1,24(sp)
    80205bea:	69a2                	ld	s3,8(sp)
    }
    panic("filewrite");
}
    80205bec:	854a                	mv	a0,s2
    80205bee:	70a2                	ld	ra,40(sp)
    80205bf0:	7402                	ld	s0,32(sp)
    80205bf2:	6942                	ld	s2,16(sp)
    80205bf4:	6145                	addi	sp,sp,48
    80205bf6:	8082                	ret
        return pipewrite(f->pipe, uaddr, n);
    80205bf8:	6908                	ld	a0,16(a0)
    80205bfa:	00000097          	auipc	ra,0x0
    80205bfe:	1b8080e7          	jalr	440(ra) # 80205db2 <pipewrite>
    80205c02:	892a                	mv	s2,a0
    80205c04:	64e2                	ld	s1,24(sp)
    80205c06:	69a2                	ld	s3,8(sp)
    80205c08:	b7d5                	j	80205bec <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80205c0a:	02451783          	lh	a5,36(a0)
    80205c0e:	03079693          	slli	a3,a5,0x30
    80205c12:	92c1                	srli	a3,a3,0x30
    80205c14:	4725                	li	a4,9
    80205c16:	02d76e63          	bltu	a4,a3,80205c52 <filewrite+0xd0>
    80205c1a:	0792                	slli	a5,a5,0x4
    80205c1c:	00135717          	auipc	a4,0x135
    80205c20:	03470713          	addi	a4,a4,52 # 8033ac50 <devsw>
    80205c24:	97ba                	add	a5,a5,a4
    80205c26:	679c                	ld	a5,8(a5)
    80205c28:	cb8d                	beqz	a5,80205c5a <filewrite+0xd8>
        return devsw[f->major].write(uaddr, n);
    80205c2a:	85b2                	mv	a1,a2
    80205c2c:	854a                	mv	a0,s2
    80205c2e:	9782                	jalr	a5
    80205c30:	892a                	mv	s2,a0
    80205c32:	64e2                	ld	s1,24(sp)
    80205c34:	69a2                	ld	s3,8(sp)
    80205c36:	bf5d                	j	80205bec <filewrite+0x6a>
    80205c38:	64e2                	ld	s1,24(sp)
    80205c3a:	69a2                	ld	s3,8(sp)
    80205c3c:	bf45                	j	80205bec <filewrite+0x6a>
    panic("filewrite");
    80205c3e:	00002517          	auipc	a0,0x2
    80205c42:	fe250513          	addi	a0,a0,-30 # 80207c20 <etext+0xc20>
    80205c46:	ffffb097          	auipc	ra,0xffffb
    80205c4a:	974080e7          	jalr	-1676(ra) # 802005ba <panic>
    if (f->writable == 0) return -1;
    80205c4e:	597d                	li	s2,-1
    80205c50:	bf71                	j	80205bec <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80205c52:	597d                	li	s2,-1
    80205c54:	64e2                	ld	s1,24(sp)
    80205c56:	69a2                	ld	s3,8(sp)
    80205c58:	bf51                	j	80205bec <filewrite+0x6a>
    80205c5a:	597d                	li	s2,-1
    80205c5c:	64e2                	ld	s1,24(sp)
    80205c5e:	69a2                	ld	s3,8(sp)
    80205c60:	b771                	j	80205bec <filewrite+0x6a>

0000000080205c62 <pipealloc>:
    int    readopen;
    int    writeopen;
};

int pipealloc(struct file **f0, struct file **f1)
{
    80205c62:	7179                	addi	sp,sp,-48
    80205c64:	f406                	sd	ra,40(sp)
    80205c66:	f022                	sd	s0,32(sp)
    80205c68:	ec26                	sd	s1,24(sp)
    80205c6a:	e052                	sd	s4,0(sp)
    80205c6c:	1800                	addi	s0,sp,48
    80205c6e:	84aa                	mv	s1,a0
    80205c70:	8a2e                	mv	s4,a1
    struct pipe *pi = 0;
    *f0 = *f1 = 0;
    80205c72:	0005b023          	sd	zero,0(a1)
    80205c76:	00053023          	sd	zero,0(a0)

    if ((*f0 = filealloc()) == 0) goto bad;
    80205c7a:	00000097          	auipc	ra,0x0
    80205c7e:	c3c080e7          	jalr	-964(ra) # 802058b6 <filealloc>
    80205c82:	e088                	sd	a0,0(s1)
    80205c84:	cd49                	beqz	a0,80205d1e <pipealloc+0xbc>
    if ((*f1 = filealloc()) == 0) goto bad;
    80205c86:	00000097          	auipc	ra,0x0
    80205c8a:	c30080e7          	jalr	-976(ra) # 802058b6 <filealloc>
    80205c8e:	00aa3023          	sd	a0,0(s4)
    80205c92:	c141                	beqz	a0,80205d12 <pipealloc+0xb0>
    80205c94:	e84a                	sd	s2,16(sp)
    if ((pi = (struct pipe *)palloc()) == 0) goto bad;
    80205c96:	ffffb097          	auipc	ra,0xffffb
    80205c9a:	3cc080e7          	jalr	972(ra) # 80201062 <palloc>
    80205c9e:	892a                	mv	s2,a0
    80205ca0:	c13d                	beqz	a0,80205d06 <pipealloc+0xa4>
    80205ca2:	e44e                	sd	s3,8(sp)

    pi->readopen  = 1;
    80205ca4:	4985                	li	s3,1
    80205ca6:	23352023          	sw	s3,544(a0)
    pi->writeopen = 1;
    80205caa:	23352223          	sw	s3,548(a0)
    pi->nread  = 0;
    80205cae:	20052c23          	sw	zero,536(a0)
    pi->nwrite = 0;
    80205cb2:	20052e23          	sw	zero,540(a0)
    initlock(&pi->lock, "pipe");
    80205cb6:	00002597          	auipc	a1,0x2
    80205cba:	f7a58593          	addi	a1,a1,-134 # 80207c30 <etext+0xc30>
    80205cbe:	ffffb097          	auipc	ra,0xffffb
    80205cc2:	5b6080e7          	jalr	1462(ra) # 80201274 <initlock>

    (*f0)->type = FD_PIPE; (*f0)->readable = 1; (*f0)->writable = 0; (*f0)->pipe = pi;
    80205cc6:	609c                	ld	a5,0(s1)
    80205cc8:	0137a023          	sw	s3,0(a5)
    80205ccc:	609c                	ld	a5,0(s1)
    80205cce:	01378423          	sb	s3,8(a5)
    80205cd2:	609c                	ld	a5,0(s1)
    80205cd4:	000784a3          	sb	zero,9(a5)
    80205cd8:	609c                	ld	a5,0(s1)
    80205cda:	0127b823          	sd	s2,16(a5)
    (*f1)->type = FD_PIPE; (*f1)->readable = 0; (*f1)->writable = 1; (*f1)->pipe = pi;
    80205cde:	000a3783          	ld	a5,0(s4)
    80205ce2:	0137a023          	sw	s3,0(a5)
    80205ce6:	000a3783          	ld	a5,0(s4)
    80205cea:	00078423          	sb	zero,8(a5)
    80205cee:	000a3783          	ld	a5,0(s4)
    80205cf2:	013784a3          	sb	s3,9(a5)
    80205cf6:	000a3783          	ld	a5,0(s4)
    80205cfa:	0127b823          	sd	s2,16(a5)
    return 0;
    80205cfe:	4501                	li	a0,0
    80205d00:	6942                	ld	s2,16(sp)
    80205d02:	69a2                	ld	s3,8(sp)
    80205d04:	a03d                	j	80205d32 <pipealloc+0xd0>

bad:
    if (*f0) fileclose(*f0);
    80205d06:	6088                	ld	a0,0(s1)
    80205d08:	c119                	beqz	a0,80205d0e <pipealloc+0xac>
    80205d0a:	6942                	ld	s2,16(sp)
    80205d0c:	a029                	j	80205d16 <pipealloc+0xb4>
    80205d0e:	6942                	ld	s2,16(sp)
    80205d10:	a039                	j	80205d1e <pipealloc+0xbc>
    80205d12:	6088                	ld	a0,0(s1)
    80205d14:	c50d                	beqz	a0,80205d3e <pipealloc+0xdc>
    80205d16:	00000097          	auipc	ra,0x0
    80205d1a:	c5c080e7          	jalr	-932(ra) # 80205972 <fileclose>
    if (*f1) fileclose(*f1);
    80205d1e:	000a3783          	ld	a5,0(s4)
    return -1;
    80205d22:	557d                	li	a0,-1
    if (*f1) fileclose(*f1);
    80205d24:	c799                	beqz	a5,80205d32 <pipealloc+0xd0>
    80205d26:	853e                	mv	a0,a5
    80205d28:	00000097          	auipc	ra,0x0
    80205d2c:	c4a080e7          	jalr	-950(ra) # 80205972 <fileclose>
    return -1;
    80205d30:	557d                	li	a0,-1
}
    80205d32:	70a2                	ld	ra,40(sp)
    80205d34:	7402                	ld	s0,32(sp)
    80205d36:	64e2                	ld	s1,24(sp)
    80205d38:	6a02                	ld	s4,0(sp)
    80205d3a:	6145                	addi	sp,sp,48
    80205d3c:	8082                	ret
    return -1;
    80205d3e:	557d                	li	a0,-1
    80205d40:	bfcd                	j	80205d32 <pipealloc+0xd0>

0000000080205d42 <pipeclose>:

void pipeclose(struct pipe *pi, int writable)
{
    80205d42:	1101                	addi	sp,sp,-32
    80205d44:	ec06                	sd	ra,24(sp)
    80205d46:	e822                	sd	s0,16(sp)
    80205d48:	e426                	sd	s1,8(sp)
    80205d4a:	e04a                	sd	s2,0(sp)
    80205d4c:	1000                	addi	s0,sp,32
    80205d4e:	84aa                	mv	s1,a0
    80205d50:	892e                	mv	s2,a1
    acquire(&pi->lock);
    80205d52:	ffffb097          	auipc	ra,0xffffb
    80205d56:	59e080e7          	jalr	1438(ra) # 802012f0 <acquire>
    if (writable) {
    80205d5a:	02090d63          	beqz	s2,80205d94 <pipeclose+0x52>
        pi->writeopen = 0;
    80205d5e:	2204a223          	sw	zero,548(s1)
        wakeup(&pi->nread);          /* blocked readers must see EOF */
    80205d62:	21848513          	addi	a0,s1,536
    80205d66:	ffffc097          	auipc	ra,0xffffc
    80205d6a:	15e080e7          	jalr	350(ra) # 80201ec4 <wakeup>
    } else {
        pi->readopen = 0;
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    }
    if (pi->readopen == 0 && pi->writeopen == 0) {
    80205d6e:	2204b783          	ld	a5,544(s1)
    80205d72:	eb95                	bnez	a5,80205da6 <pipeclose+0x64>
        release(&pi->lock);
    80205d74:	8526                	mv	a0,s1
    80205d76:	ffffb097          	auipc	ra,0xffffb
    80205d7a:	62e080e7          	jalr	1582(ra) # 802013a4 <release>
        pfree(pi);
    80205d7e:	8526                	mv	a0,s1
    80205d80:	ffffb097          	auipc	ra,0xffffb
    80205d84:	3f2080e7          	jalr	1010(ra) # 80201172 <pfree>
    } else {
        release(&pi->lock);
    }
}
    80205d88:	60e2                	ld	ra,24(sp)
    80205d8a:	6442                	ld	s0,16(sp)
    80205d8c:	64a2                	ld	s1,8(sp)
    80205d8e:	6902                	ld	s2,0(sp)
    80205d90:	6105                	addi	sp,sp,32
    80205d92:	8082                	ret
        pi->readopen = 0;
    80205d94:	2204a023          	sw	zero,544(s1)
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    80205d98:	21c48513          	addi	a0,s1,540
    80205d9c:	ffffc097          	auipc	ra,0xffffc
    80205da0:	128080e7          	jalr	296(ra) # 80201ec4 <wakeup>
    80205da4:	b7e9                	j	80205d6e <pipeclose+0x2c>
        release(&pi->lock);
    80205da6:	8526                	mv	a0,s1
    80205da8:	ffffb097          	auipc	ra,0xffffb
    80205dac:	5fc080e7          	jalr	1532(ra) # 802013a4 <release>
}
    80205db0:	bfe1                	j	80205d88 <pipeclose+0x46>

0000000080205db2 <pipewrite>:

int pipewrite(struct pipe *pi, uint64 uaddr, int n)
{
    80205db2:	711d                	addi	sp,sp,-96
    80205db4:	ec86                	sd	ra,88(sp)
    80205db6:	e8a2                	sd	s0,80(sp)
    80205db8:	e4a6                	sd	s1,72(sp)
    80205dba:	e0ca                	sd	s2,64(sp)
    80205dbc:	fc4e                	sd	s3,56(sp)
    80205dbe:	f852                	sd	s4,48(sp)
    80205dc0:	f456                	sd	s5,40(sp)
    80205dc2:	1080                	addi	s0,sp,96
    80205dc4:	84aa                	mv	s1,a0
    80205dc6:	8aae                	mv	s5,a1
    80205dc8:	8a32                	mv	s4,a2
    struct proc *pr = myproc();
    80205dca:	ffffc097          	auipc	ra,0xffffc
    80205dce:	910080e7          	jalr	-1776(ra) # 802016da <myproc>
    80205dd2:	89aa                	mv	s3,a0
    int i = 0;

    acquire(&pi->lock);
    80205dd4:	8526                	mv	a0,s1
    80205dd6:	ffffb097          	auipc	ra,0xffffb
    80205dda:	51a080e7          	jalr	1306(ra) # 802012f0 <acquire>
    while (i < n) {
    80205dde:	0d405163          	blez	s4,80205ea0 <pipewrite+0xee>
    80205de2:	f05a                	sd	s6,32(sp)
    80205de4:	ec5e                	sd	s7,24(sp)
    int i = 0;
    80205de6:	4901                	li	s2,0
        if (pi->readopen == 0 || pr->killed) {
            release(&pi->lock);
            return -1;
        }
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
            wakeup(&pi->nread);
    80205de8:	21848b93          	addi	s7,s1,536
            sleep(&pi->nwrite, &pi->lock);
    80205dec:	21c48b13          	addi	s6,s1,540
    80205df0:	a081                	j	80205e30 <pipewrite+0x7e>
            release(&pi->lock);
    80205df2:	8526                	mv	a0,s1
    80205df4:	ffffb097          	auipc	ra,0xffffb
    80205df8:	5b0080e7          	jalr	1456(ra) # 802013a4 <release>
            return -1;
    80205dfc:	597d                	li	s2,-1
    80205dfe:	7b02                	ld	s6,32(sp)
    80205e00:	6be2                	ld	s7,24(sp)
        }
    }
    wakeup(&pi->nread);
    release(&pi->lock);
    return i;
}
    80205e02:	854a                	mv	a0,s2
    80205e04:	60e6                	ld	ra,88(sp)
    80205e06:	6446                	ld	s0,80(sp)
    80205e08:	64a6                	ld	s1,72(sp)
    80205e0a:	6906                	ld	s2,64(sp)
    80205e0c:	79e2                	ld	s3,56(sp)
    80205e0e:	7a42                	ld	s4,48(sp)
    80205e10:	7aa2                	ld	s5,40(sp)
    80205e12:	6125                	addi	sp,sp,96
    80205e14:	8082                	ret
            wakeup(&pi->nread);
    80205e16:	855e                	mv	a0,s7
    80205e18:	ffffc097          	auipc	ra,0xffffc
    80205e1c:	0ac080e7          	jalr	172(ra) # 80201ec4 <wakeup>
            sleep(&pi->nwrite, &pi->lock);
    80205e20:	85a6                	mv	a1,s1
    80205e22:	855a                	mv	a0,s6
    80205e24:	ffffc097          	auipc	ra,0xffffc
    80205e28:	f1a080e7          	jalr	-230(ra) # 80201d3e <sleep>
    while (i < n) {
    80205e2c:	05495c63          	bge	s2,s4,80205e84 <pipewrite+0xd2>
        if (pi->readopen == 0 || pr->killed) {
    80205e30:	2204a783          	lw	a5,544(s1)
    80205e34:	dfdd                	beqz	a5,80205df2 <pipewrite+0x40>
    80205e36:	0289a783          	lw	a5,40(s3)
    80205e3a:	ffc5                	bnez	a5,80205df2 <pipewrite+0x40>
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
    80205e3c:	2184a783          	lw	a5,536(s1)
    80205e40:	21c4a703          	lw	a4,540(s1)
    80205e44:	2007879b          	addiw	a5,a5,512
    80205e48:	fcf707e3          	beq	a4,a5,80205e16 <pipewrite+0x64>
            if (copyin(pr->pagetable, &ch, uaddr + i, 1) < 0) break;
    80205e4c:	4685                	li	a3,1
    80205e4e:	01590633          	add	a2,s2,s5
    80205e52:	faf40593          	addi	a1,s0,-81
    80205e56:	0509b503          	ld	a0,80(s3)
    80205e5a:	ffffd097          	auipc	ra,0xffffd
    80205e5e:	148080e7          	jalr	328(ra) # 80202fa2 <copyin>
    80205e62:	04054163          	bltz	a0,80205ea4 <pipewrite+0xf2>
            pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80205e66:	21c4a783          	lw	a5,540(s1)
    80205e6a:	0017871b          	addiw	a4,a5,1
    80205e6e:	20e4ae23          	sw	a4,540(s1)
    80205e72:	1ff7f793          	andi	a5,a5,511
    80205e76:	97a6                	add	a5,a5,s1
    80205e78:	faf44703          	lbu	a4,-81(s0)
    80205e7c:	00e78c23          	sb	a4,24(a5)
            i++;
    80205e80:	2905                	addiw	s2,s2,1
    80205e82:	b76d                	j	80205e2c <pipewrite+0x7a>
    80205e84:	7b02                	ld	s6,32(sp)
    80205e86:	6be2                	ld	s7,24(sp)
    wakeup(&pi->nread);
    80205e88:	21848513          	addi	a0,s1,536
    80205e8c:	ffffc097          	auipc	ra,0xffffc
    80205e90:	038080e7          	jalr	56(ra) # 80201ec4 <wakeup>
    release(&pi->lock);
    80205e94:	8526                	mv	a0,s1
    80205e96:	ffffb097          	auipc	ra,0xffffb
    80205e9a:	50e080e7          	jalr	1294(ra) # 802013a4 <release>
    return i;
    80205e9e:	b795                	j	80205e02 <pipewrite+0x50>
    int i = 0;
    80205ea0:	4901                	li	s2,0
    80205ea2:	b7dd                	j	80205e88 <pipewrite+0xd6>
    80205ea4:	7b02                	ld	s6,32(sp)
    80205ea6:	6be2                	ld	s7,24(sp)
    80205ea8:	b7c5                	j	80205e88 <pipewrite+0xd6>

0000000080205eaa <piperead>:

int piperead(struct pipe *pi, uint64 uaddr, int n)
{
    80205eaa:	715d                	addi	sp,sp,-80
    80205eac:	e486                	sd	ra,72(sp)
    80205eae:	e0a2                	sd	s0,64(sp)
    80205eb0:	fc26                	sd	s1,56(sp)
    80205eb2:	f84a                	sd	s2,48(sp)
    80205eb4:	f44e                	sd	s3,40(sp)
    80205eb6:	f052                	sd	s4,32(sp)
    80205eb8:	ec56                	sd	s5,24(sp)
    80205eba:	0880                	addi	s0,sp,80
    80205ebc:	84aa                	mv	s1,a0
    80205ebe:	892e                	mv	s2,a1
    80205ec0:	8ab2                	mv	s5,a2
    struct proc *pr = myproc();
    80205ec2:	ffffc097          	auipc	ra,0xffffc
    80205ec6:	818080e7          	jalr	-2024(ra) # 802016da <myproc>
    80205eca:	8a2a                	mv	s4,a0

    acquire(&pi->lock);
    80205ecc:	8526                	mv	a0,s1
    80205ece:	ffffb097          	auipc	ra,0xffffb
    80205ed2:	422080e7          	jalr	1058(ra) # 802012f0 <acquire>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205ed6:	2184a703          	lw	a4,536(s1)
    80205eda:	21c4a783          	lw	a5,540(s1)
        if (pr->killed) { release(&pi->lock); return -1; }
        sleep(&pi->nread, &pi->lock);
    80205ede:	21848993          	addi	s3,s1,536
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205ee2:	02f71463          	bne	a4,a5,80205f0a <piperead+0x60>
    80205ee6:	2244a783          	lw	a5,548(s1)
    80205eea:	c385                	beqz	a5,80205f0a <piperead+0x60>
        if (pr->killed) { release(&pi->lock); return -1; }
    80205eec:	028a2783          	lw	a5,40(s4)
    80205ef0:	e7d9                	bnez	a5,80205f7e <piperead+0xd4>
        sleep(&pi->nread, &pi->lock);
    80205ef2:	85a6                	mv	a1,s1
    80205ef4:	854e                	mv	a0,s3
    80205ef6:	ffffc097          	auipc	ra,0xffffc
    80205efa:	e48080e7          	jalr	-440(ra) # 80201d3e <sleep>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205efe:	2184a703          	lw	a4,536(s1)
    80205f02:	21c4a783          	lw	a5,540(s1)
    80205f06:	fef700e3          	beq	a4,a5,80205ee6 <piperead+0x3c>
    }
    int i;
    for (i = 0; i < n; i++) {
    80205f0a:	4981                	li	s3,0
    80205f0c:	05505463          	blez	s5,80205f54 <piperead+0xaa>
        if (pi->nread == pi->nwrite) break;             /* drained */
    80205f10:	2184a783          	lw	a5,536(s1)
    80205f14:	21c4a703          	lw	a4,540(s1)
    80205f18:	02f70e63          	beq	a4,a5,80205f54 <piperead+0xaa>
        char ch = pi->data[pi->nread++ % PIPESIZE];
    80205f1c:	0017871b          	addiw	a4,a5,1
    80205f20:	20e4ac23          	sw	a4,536(s1)
    80205f24:	1ff7f793          	andi	a5,a5,511
    80205f28:	97a6                	add	a5,a5,s1
    80205f2a:	0187c783          	lbu	a5,24(a5)
    80205f2e:	faf40fa3          	sb	a5,-65(s0)
        if (copyout(pr->pagetable, uaddr + i, &ch, 1) < 0) break;
    80205f32:	4685                	li	a3,1
    80205f34:	fbf40613          	addi	a2,s0,-65
    80205f38:	85ca                	mv	a1,s2
    80205f3a:	050a3503          	ld	a0,80(s4)
    80205f3e:	ffffd097          	auipc	ra,0xffffd
    80205f42:	f70080e7          	jalr	-144(ra) # 80202eae <copyout>
    80205f46:	00054763          	bltz	a0,80205f54 <piperead+0xaa>
    for (i = 0; i < n; i++) {
    80205f4a:	2985                	addiw	s3,s3,1
    80205f4c:	0905                	addi	s2,s2,1
    80205f4e:	fd3a91e3          	bne	s5,s3,80205f10 <piperead+0x66>
    80205f52:	89d6                	mv	s3,s5
    }
    wakeup(&pi->nwrite);
    80205f54:	21c48513          	addi	a0,s1,540
    80205f58:	ffffc097          	auipc	ra,0xffffc
    80205f5c:	f6c080e7          	jalr	-148(ra) # 80201ec4 <wakeup>
    release(&pi->lock);
    80205f60:	8526                	mv	a0,s1
    80205f62:	ffffb097          	auipc	ra,0xffffb
    80205f66:	442080e7          	jalr	1090(ra) # 802013a4 <release>
    return i;                                           /* 0 here = EOF */
}
    80205f6a:	854e                	mv	a0,s3
    80205f6c:	60a6                	ld	ra,72(sp)
    80205f6e:	6406                	ld	s0,64(sp)
    80205f70:	74e2                	ld	s1,56(sp)
    80205f72:	7942                	ld	s2,48(sp)
    80205f74:	79a2                	ld	s3,40(sp)
    80205f76:	7a02                	ld	s4,32(sp)
    80205f78:	6ae2                	ld	s5,24(sp)
    80205f7a:	6161                	addi	sp,sp,80
    80205f7c:	8082                	ret
        if (pr->killed) { release(&pi->lock); return -1; }
    80205f7e:	8526                	mv	a0,s1
    80205f80:	ffffb097          	auipc	ra,0xffffb
    80205f84:	424080e7          	jalr	1060(ra) # 802013a4 <release>
    80205f88:	59fd                	li	s3,-1
    80205f8a:	b7c5                	j	80205f6a <piperead+0xc0>

0000000080205f8c <hal_intc_init>:
#define PLIC_PRIORITY(irq)   (plic + (irq) * 4)
#define PLIC_SENABLE(h)      (plic + 0x2080 + (h) * 0x100)
#define PLIC_STHRESHOLD(h)   (plic + 0x201000 + (h) * 0x2000)
#define PLIC_SCLAIM(h)       (plic + 0x201004 + (h) * 0x2000)

void hal_intc_init(uint64 plic_base) { plic = plic_base; }
    80205f8c:	1141                	addi	sp,sp,-16
    80205f8e:	e422                	sd	s0,8(sp)
    80205f90:	0800                	addi	s0,sp,16
    80205f92:	00139797          	auipc	a5,0x139
    80205f96:	08a7bb23          	sd	a0,150(a5) # 8033f028 <plic>
    80205f9a:	6422                	ld	s0,8(sp)
    80205f9c:	0141                	addi	sp,sp,16
    80205f9e:	8082                	ret

0000000080205fa0 <hal_intc_enable>:

void hal_intc_enable(int irq)
{
    80205fa0:	1141                	addi	sp,sp,-16
    80205fa2:	e422                	sd	s0,8(sp)
    80205fa4:	0800                	addi	s0,sp,16
    if (!plic) return;
    80205fa6:	00139797          	auipc	a5,0x139
    80205faa:	0827b783          	ld	a5,130(a5) # 8033f028 <plic>
    80205fae:	c791                	beqz	a5,80205fba <hal_intc_enable+0x1a>
    *(volatile uint32 *)PLIC_PRIORITY(irq) = 1;   /* priority 0 = never fire */
    80205fb0:	0025151b          	slliw	a0,a0,0x2
    80205fb4:	953e                	add	a0,a0,a5
    80205fb6:	4785                	li	a5,1
    80205fb8:	c11c                	sw	a5,0(a0)
}
    80205fba:	6422                	ld	s0,8(sp)
    80205fbc:	0141                	addi	sp,sp,16
    80205fbe:	8082                	ret

0000000080205fc0 <hal_intc_hart_init>:

void hal_intc_hart_init(int hart)
{
    80205fc0:	1141                	addi	sp,sp,-16
    80205fc2:	e422                	sd	s0,8(sp)
    80205fc4:	0800                	addi	s0,sp,16
    if (!plic) return;
    80205fc6:	00139797          	auipc	a5,0x139
    80205fca:	0627b783          	ld	a5,98(a5) # 8033f028 <plic>
    80205fce:	cb89                	beqz	a5,80205fe0 <hal_intc_hart_init+0x20>
    *(volatile uint32 *)PLIC_STHRESHOLD(hart) = 0; /* accept any priority > 0 */
    80205fd0:	00d5151b          	slliw	a0,a0,0xd
    80205fd4:	00201737          	lui	a4,0x201
    80205fd8:	97ba                	add	a5,a5,a4
    80205fda:	953e                	add	a0,a0,a5
    80205fdc:	00052023          	sw	zero,0(a0)
}
    80205fe0:	6422                	ld	s0,8(sp)
    80205fe2:	0141                	addi	sp,sp,16
    80205fe4:	8082                	ret

0000000080205fe6 <hal_intc_enable_hart>:

/* Enable irq for this hart (must be called after hal_intc_enable). */
void hal_intc_enable_hart(int hart, int irq)
{
    80205fe6:	1141                	addi	sp,sp,-16
    80205fe8:	e422                	sd	s0,8(sp)
    80205fea:	0800                	addi	s0,sp,16
    if (!plic) return;
    80205fec:	00139797          	auipc	a5,0x139
    80205ff0:	03c7b783          	ld	a5,60(a5) # 8033f028 <plic>
    80205ff4:	cb85                	beqz	a5,80206024 <hal_intc_enable_hart+0x3e>
    volatile uint32 *en = (volatile uint32 *)PLIC_SENABLE(hart);
    80205ff6:	0085151b          	slliw	a0,a0,0x8
    80205ffa:	6709                	lui	a4,0x2
    80205ffc:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    80206000:	97ba                	add	a5,a5,a4
    80206002:	953e                	add	a0,a0,a5
    en[irq / 32] |= (1u << (irq % 32));
    80206004:	41f5d79b          	sraiw	a5,a1,0x1f
    80206008:	01b7d79b          	srliw	a5,a5,0x1b
    8020600c:	9fad                	addw	a5,a5,a1
    8020600e:	4057d79b          	sraiw	a5,a5,0x5
    80206012:	078a                	slli	a5,a5,0x2
    80206014:	953e                	add	a0,a0,a5
    80206016:	411c                	lw	a5,0(a0)
    80206018:	4705                	li	a4,1
    8020601a:	00b7173b          	sllw	a4,a4,a1
    8020601e:	8fd9                	or	a5,a5,a4
    80206020:	2781                	sext.w	a5,a5
    80206022:	c11c                	sw	a5,0(a0)
}
    80206024:	6422                	ld	s0,8(sp)
    80206026:	0141                	addi	sp,sp,16
    80206028:	8082                	ret

000000008020602a <hal_intc_claim>:

int hal_intc_claim(void)
{
    8020602a:	1141                	addi	sp,sp,-16
    8020602c:	e422                	sd	s0,8(sp)
    8020602e:	0800                	addi	s0,sp,16
    if (!plic) return 0;
    80206030:	00139797          	auipc	a5,0x139
    80206034:	ff87b783          	ld	a5,-8(a5) # 8033f028 <plic>
    80206038:	4501                	li	a0,0
    8020603a:	e781                	bnez	a5,80206042 <hal_intc_claim+0x18>
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
}
    8020603c:	6422                	ld	s0,8(sp)
    8020603e:	0141                	addi	sp,sp,16
    80206040:	8082                	ret
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    80206042:	8712                	mv	a4,tp
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
    80206044:	00d7171b          	slliw	a4,a4,0xd
    80206048:	002016b7          	lui	a3,0x201
    8020604c:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    8020604e:	97b6                	add	a5,a5,a3
    80206050:	97ba                	add	a5,a5,a4
    80206052:	4388                	lw	a0,0(a5)
    80206054:	b7e5                	j	8020603c <hal_intc_claim+0x12>

0000000080206056 <hal_intc_complete>:

void hal_intc_complete(int irq)
{
    80206056:	1141                	addi	sp,sp,-16
    80206058:	e422                	sd	s0,8(sp)
    8020605a:	0800                	addi	s0,sp,16
    if (!plic) return;
    8020605c:	00139797          	auipc	a5,0x139
    80206060:	fcc7b783          	ld	a5,-52(a5) # 8033f028 <plic>
    80206064:	e781                	bnez	a5,8020606c <hal_intc_complete+0x16>
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
}
    80206066:	6422                	ld	s0,8(sp)
    80206068:	0141                	addi	sp,sp,16
    8020606a:	8082                	ret
    8020606c:	8712                	mv	a4,tp
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
    8020606e:	00d7171b          	slliw	a4,a4,0xd
    80206072:	002016b7          	lui	a3,0x201
    80206076:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    80206078:	97b6                	add	a5,a5,a3
    8020607a:	97ba                	add	a5,a5,a4
    8020607c:	2501                	sext.w	a0,a0
    8020607e:	c388                	sw	a0,0(a5)
    80206080:	b7dd                	j	80206066 <hal_intc_complete+0x10>

0000000080206082 <hal_hart_id>:

int hal_hart_id(void) { return (int)r_tp(); }
    80206082:	1141                	addi	sp,sp,-16
    80206084:	e422                	sd	s0,8(sp)
    80206086:	0800                	addi	s0,sp,16
    80206088:	8512                	mv	a0,tp
    8020608a:	2501                	sext.w	a0,a0
    8020608c:	6422                	ld	s0,8(sp)
    8020608e:	0141                	addi	sp,sp,16
    80206090:	8082                	ret

0000000080206092 <plic_dbg>:

int plic_dbg(int which)
{
    80206092:	1141                	addi	sp,sp,-16
    80206094:	e422                	sd	s0,8(sp)
    80206096:	0800                	addi	s0,sp,16
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    80206098:	cd09                	beqz	a0,802060b2 <plic_dbg+0x20>
    return *(volatile uint32 *)PLIC_SENABLE(0);
    8020609a:	6709                	lui	a4,0x2
    8020609c:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    802060a0:	00139797          	auipc	a5,0x139
    802060a4:	f887b783          	ld	a5,-120(a5) # 8033f028 <plic>
    802060a8:	97ba                	add	a5,a5,a4
    802060aa:	4388                	lw	a0,0(a5)
}
    802060ac:	6422                	ld	s0,8(sp)
    802060ae:	0141                	addi	sp,sp,16
    802060b0:	8082                	ret
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    802060b2:	00139797          	auipc	a5,0x139
    802060b6:	f767b783          	ld	a5,-138(a5) # 8033f028 <plic>
    802060ba:	5788                	lw	a0,40(a5)
    802060bc:	bfc5                	j	802060ac <plic_dbg+0x1a>

00000000802060be <hal_time_read>:
#include "hal.h"
#include "riscv.h"
#include "defs.h"

void    hal_timer_init(void)          { hal_timer_next(1000000); }
uint64  hal_time_read(void)           { return r_time(); }
    802060be:	1141                	addi	sp,sp,-16
    802060c0:	e422                	sd	s0,8(sp)
    802060c2:	0800                	addi	s0,sp,16
static inline uint64 r_time(void){ uint64 x; asm volatile("rdtime %0":"=r"(x)); return x; }
    802060c4:	c0102573          	rdtime	a0
    802060c8:	6422                	ld	s0,8(sp)
    802060ca:	0141                	addi	sp,sp,16
    802060cc:	8082                	ret

00000000802060ce <hal_timer_set>:
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    802060ce:	1141                	addi	sp,sp,-16
    802060d0:	e406                	sd	ra,8(sp)
    802060d2:	e022                	sd	s0,0(sp)
    802060d4:	0800                	addi	s0,sp,16
    802060d6:	ffffa097          	auipc	ra,0xffffa
    802060da:	6e6080e7          	jalr	1766(ra) # 802007bc <sbi_set_timer>
    802060de:	60a2                	ld	ra,8(sp)
    802060e0:	6402                	ld	s0,0(sp)
    802060e2:	0141                	addi	sp,sp,16
    802060e4:	8082                	ret

00000000802060e6 <hal_timer_ack>:
void    hal_timer_ack(void)           { /* SBI: next set_timer clears STIP */ }
    802060e6:	1141                	addi	sp,sp,-16
    802060e8:	e422                	sd	s0,8(sp)
    802060ea:	0800                	addi	s0,sp,16
    802060ec:	6422                	ld	s0,8(sp)
    802060ee:	0141                	addi	sp,sp,16
    802060f0:	8082                	ret

00000000802060f2 <hal_timer_next>:
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    802060f2:	1141                	addi	sp,sp,-16
    802060f4:	e406                	sd	ra,8(sp)
    802060f6:	e022                	sd	s0,0(sp)
    802060f8:	0800                	addi	s0,sp,16
    802060fa:	c01027f3          	rdtime	a5
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    802060fe:	953e                	add	a0,a0,a5
    80206100:	ffffa097          	auipc	ra,0xffffa
    80206104:	6bc080e7          	jalr	1724(ra) # 802007bc <sbi_set_timer>
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    80206108:	60a2                	ld	ra,8(sp)
    8020610a:	6402                	ld	s0,0(sp)
    8020610c:	0141                	addi	sp,sp,16
    8020610e:	8082                	ret

0000000080206110 <hal_timer_init>:
void    hal_timer_init(void)          { hal_timer_next(1000000); }
    80206110:	1141                	addi	sp,sp,-16
    80206112:	e406                	sd	ra,8(sp)
    80206114:	e022                	sd	s0,0(sp)
    80206116:	0800                	addi	s0,sp,16
    80206118:	000f4537          	lui	a0,0xf4
    8020611c:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    80206120:	00000097          	auipc	ra,0x0
    80206124:	fd2080e7          	jalr	-46(ra) # 802060f2 <hal_timer_next>
    80206128:	60a2                	ld	ra,8(sp)
    8020612a:	6402                	ld	s0,0(sp)
    8020612c:	0141                	addi	sp,sp,16
    8020612e:	8082                	ret

0000000080206130 <hal_console_init>:
#define LSR 5   /* line status              */
#define LSR_RX_READY  (1 << 0)
#define LSR_TX_IDLE   (1 << 5)

void hal_console_init(uint64 uart_base)
{
    80206130:	1141                	addi	sp,sp,-16
    80206132:	e422                	sd	s0,8(sp)
    80206134:	0800                	addi	s0,sp,16
    uart = (volatile uint8 *)uart_base;
    80206136:	00139797          	auipc	a5,0x139
    8020613a:	eea7bd23          	sd	a0,-262(a5) # 8033f030 <uart>
    uart[IER] = 0x00;              /* interrupts off while we configure */
    8020613e:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x80;              /* DLAB=1: divisor latch visible     */
    80206142:	f8000793          	li	a5,-128
    80206146:	00f501a3          	sb	a5,3(a0)
    uart[0]   = 0x03;              /* divisor low: 38.4K                */
    8020614a:	478d                	li	a5,3
    8020614c:	00f50023          	sb	a5,0(a0)
    uart[1]   = 0x00;              /* divisor high                      */
    80206150:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x03;              /* DLAB=0, 8 bits, no parity, 1 stop */
    80206154:	00f501a3          	sb	a5,3(a0)
    uart[FCR] = 0x07;              /* enable + clear FIFOs              */
    80206158:	479d                	li	a5,7
    8020615a:	00f50123          	sb	a5,2(a0)
    uart[IER] = 0x01;              /* receive interrupts on             */
    8020615e:	4785                	li	a5,1
    80206160:	00f500a3          	sb	a5,1(a0)
}
    80206164:	6422                	ld	s0,8(sp)
    80206166:	0141                	addi	sp,sp,16
    80206168:	8082                	ret

000000008020616a <hal_console_putc>:

void hal_console_putc(char c)
{
    8020616a:	1141                	addi	sp,sp,-16
    8020616c:	e422                	sd	s0,8(sp)
    8020616e:	0800                	addi	s0,sp,16
    if (!uart) { return; }
    80206170:	00139717          	auipc	a4,0x139
    80206174:	ec073703          	ld	a4,-320(a4) # 8033f030 <uart>
    80206178:	cb01                	beqz	a4,80206188 <hal_console_putc+0x1e>
    while ((uart[LSR] & LSR_TX_IDLE) == 0)   /* wait for the holding reg */
    8020617a:	00574783          	lbu	a5,5(a4)
    8020617e:	0207f793          	andi	a5,a5,32
    80206182:	dfe5                	beqz	a5,8020617a <hal_console_putc+0x10>
        ;
    uart[THR] = c;
    80206184:	00a70023          	sb	a0,0(a4)
}
    80206188:	6422                	ld	s0,8(sp)
    8020618a:	0141                	addi	sp,sp,16
    8020618c:	8082                	ret

000000008020618e <hal_console_getc>:

int hal_console_getc(void)
{
    8020618e:	1141                	addi	sp,sp,-16
    80206190:	e422                	sd	s0,8(sp)
    80206192:	0800                	addi	s0,sp,16
    if (!uart) return -1;
    80206194:	00139717          	auipc	a4,0x139
    80206198:	e9c73703          	ld	a4,-356(a4) # 8033f030 <uart>
    8020619c:	cb11                	beqz	a4,802061b0 <hal_console_getc+0x22>
    if (uart[LSR] & LSR_RX_READY)
    8020619e:	00574783          	lbu	a5,5(a4)
    802061a2:	8b85                	andi	a5,a5,1
    802061a4:	cb81                	beqz	a5,802061b4 <hal_console_getc+0x26>
        return uart[RHR];
    802061a6:	00074503          	lbu	a0,0(a4)
    return -1;
}
    802061aa:	6422                	ld	s0,8(sp)
    802061ac:	0141                	addi	sp,sp,16
    802061ae:	8082                	ret
    if (!uart) return -1;
    802061b0:	557d                	li	a0,-1
    802061b2:	bfe5                	j	802061aa <hal_console_getc+0x1c>
    return -1;
    802061b4:	557d                	li	a0,-1
    802061b6:	bfd5                	j	802061aa <hal_console_getc+0x1c>

00000000802061b8 <free_desc>:
    for (int i = 0; i < VNUM; i++)
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    return -1;
}
static void free_desc(int i)
{
    802061b8:	1141                	addi	sp,sp,-16
    802061ba:	e406                	sd	ra,8(sp)
    802061bc:	e022                	sd	s0,0(sp)
    802061be:	0800                	addi	s0,sp,16
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    802061c0:	479d                	li	a5,7
    802061c2:	04a7c663          	blt	a5,a0,8020620e <free_desc+0x56>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    802061c6:	00136797          	auipc	a5,0x136
    802061ca:	e3a78793          	addi	a5,a5,-454 # 8033c000 <vdisk>
    802061ce:	97aa                	add	a5,a5,a0
    802061d0:	0287c783          	lbu	a5,40(a5)
    802061d4:	e7a9                	bnez	a5,8020621e <free_desc+0x66>
    vdisk.desc[i] = (struct virtq_desc){0};
    802061d6:	00136797          	auipc	a5,0x136
    802061da:	e2a78793          	addi	a5,a5,-470 # 8033c000 <vdisk>
    802061de:	6b98                	ld	a4,16(a5)
    802061e0:	00451693          	slli	a3,a0,0x4
    802061e4:	9736                	add	a4,a4,a3
    802061e6:	00073023          	sd	zero,0(a4)
    802061ea:	00073423          	sd	zero,8(a4)
    vdisk.free[i] = 1;
    802061ee:	97aa                	add	a5,a5,a0
    802061f0:	4705                	li	a4,1
    802061f2:	02e78423          	sb	a4,40(a5)
    wakeup(&vdisk.free[0]);
    802061f6:	00136517          	auipc	a0,0x136
    802061fa:	e3250513          	addi	a0,a0,-462 # 8033c028 <vdisk+0x28>
    802061fe:	ffffc097          	auipc	ra,0xffffc
    80206202:	cc6080e7          	jalr	-826(ra) # 80201ec4 <wakeup>
}
    80206206:	60a2                	ld	ra,8(sp)
    80206208:	6402                	ld	s0,0(sp)
    8020620a:	0141                	addi	sp,sp,16
    8020620c:	8082                	ret
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    8020620e:	00002517          	auipc	a0,0x2
    80206212:	a2a50513          	addi	a0,a0,-1494 # 80207c38 <etext+0xc38>
    80206216:	ffffa097          	auipc	ra,0xffffa
    8020621a:	3a4080e7          	jalr	932(ra) # 802005ba <panic>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    8020621e:	00002517          	auipc	a0,0x2
    80206222:	a3a50513          	addi	a0,a0,-1478 # 80207c58 <etext+0xc58>
    80206226:	ffffa097          	auipc	ra,0xffffa
    8020622a:	394080e7          	jalr	916(ra) # 802005ba <panic>

000000008020622e <hal_block_irq>:
int hal_block_irq(void) { return vdisk.base ? vdisk.irq : 0; }
    8020622e:	1141                	addi	sp,sp,-16
    80206230:	e422                	sd	s0,8(sp)
    80206232:	0800                	addi	s0,sp,16
    80206234:	00136797          	auipc	a5,0x136
    80206238:	dcc7b783          	ld	a5,-564(a5) # 8033c000 <vdisk>
    8020623c:	4501                	li	a0,0
    8020623e:	c789                	beqz	a5,80206248 <hal_block_irq+0x1a>
    80206240:	00136517          	auipc	a0,0x136
    80206244:	dc852503          	lw	a0,-568(a0) # 8033c008 <vdisk+0x8>
    80206248:	6422                	ld	s0,8(sp)
    8020624a:	0141                	addi	sp,sp,16
    8020624c:	8082                	ret

000000008020624e <hal_block_init>:
{
    8020624e:	7139                	addi	sp,sp,-64
    80206250:	fc06                	sd	ra,56(sp)
    80206252:	f822                	sd	s0,48(sp)
    80206254:	f426                	sd	s1,40(sp)
    80206256:	0080                	addi	s0,sp,64
    initlock(&vdisk.lock, "virtio_blk");
    80206258:	00002597          	auipc	a1,0x2
    8020625c:	a2058593          	addi	a1,a1,-1504 # 80207c78 <etext+0xc78>
    80206260:	00136517          	auipc	a0,0x136
    80206264:	ed850513          	addi	a0,a0,-296 # 8033c138 <vdisk+0x138>
    80206268:	ffffb097          	auipc	ra,0xffffb
    8020626c:	00c080e7          	jalr	12(ra) # 80201274 <initlock>
    for (int i = 0; i < fdt.nvirtio; i++) {
    80206270:	00023797          	auipc	a5,0x23
    80206274:	e307a783          	lw	a5,-464(a5) # 802290a0 <fdt+0x88>
    80206278:	08f05c63          	blez	a5,80206310 <hal_block_init+0xc2>
    8020627c:	f04a                	sd	s2,32(sp)
    8020627e:	ec4e                	sd	s3,24(sp)
    80206280:	e852                	sd	s4,16(sp)
    80206282:	e456                	sd	s5,8(sp)
    80206284:	e05a                	sd	s6,0(sp)
    80206286:	00023917          	auipc	s2,0x23
    8020628a:	d9290913          	addi	s2,s2,-622 # 80229018 <fdt>
    8020628e:	4481                	li	s1,0
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    80206290:	747279b7          	lui	s3,0x74727
    80206294:	97698993          	addi	s3,s3,-1674 # 74726976 <_entry-0xbad968a>
    80206298:	4a89                	li	s5,2
    8020629a:	4b05                	li	s6,1
    for (int i = 0; i < fdt.nvirtio; i++) {
    8020629c:	8a4a                	mv	s4,s2
    8020629e:	a039                	j	802062ac <hal_block_init+0x5e>
    802062a0:	2485                	addiw	s1,s1,1
    802062a2:	0921                	addi	s2,s2,8
    802062a4:	088a2783          	lw	a5,136(s4)
    802062a8:	04f4df63          	bge	s1,a5,80206306 <hal_block_init+0xb8>
        uint64 va = mmio_alias(fdt.virtio_base[i]);
    802062ac:	02893503          	ld	a0,40(s2)
    802062b0:	ffffc097          	auipc	ra,0xffffc
    802062b4:	72c080e7          	jalr	1836(ra) # 802029dc <mmio_alias>
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    802062b8:	411c                	lw	a5,0(a0)
    802062ba:	2781                	sext.w	a5,a5
    802062bc:	ff3792e3          	bne	a5,s3,802062a0 <hal_block_init+0x52>
    802062c0:	451c                	lw	a5,8(a0)
    802062c2:	2781                	sext.w	a5,a5
    802062c4:	fd579ee3          	bne	a5,s5,802062a0 <hal_block_init+0x52>
    802062c8:	415c                	lw	a5,4(a0)
    802062ca:	2781                	sext.w	a5,a5
    802062cc:	01678663          	beq	a5,s6,802062d8 <hal_block_init+0x8a>
    802062d0:	415c                	lw	a5,4(a0)
    802062d2:	2781                	sext.w	a5,a5
    802062d4:	fd5796e3          	bne	a5,s5,802062a0 <hal_block_init+0x52>
            vdisk.base    = va;
    802062d8:	00136717          	auipc	a4,0x136
    802062dc:	d2870713          	addi	a4,a4,-728 # 8033c000 <vdisk>
    802062e0:	e308                	sd	a0,0(a4)
            vdisk.irq     = fdt.virtio_irq[i];
    802062e2:	01848793          	addi	a5,s1,24
    802062e6:	078a                	slli	a5,a5,0x2
    802062e8:	00023697          	auipc	a3,0x23
    802062ec:	d3068693          	addi	a3,a3,-720 # 80229018 <fdt>
    802062f0:	97b6                	add	a5,a5,a3
    802062f2:	479c                	lw	a5,8(a5)
    802062f4:	c71c                	sw	a5,8(a4)
            vdisk.version = *vers;
    802062f6:	415c                	lw	a5,4(a0)
    802062f8:	c75c                	sw	a5,12(a4)
            break;
    802062fa:	7902                	ld	s2,32(sp)
    802062fc:	69e2                	ld	s3,24(sp)
    802062fe:	6a42                	ld	s4,16(sp)
    80206300:	6aa2                	ld	s5,8(sp)
    80206302:	6b02                	ld	s6,0(sp)
    80206304:	a031                	j	80206310 <hal_block_init+0xc2>
    80206306:	7902                	ld	s2,32(sp)
    80206308:	69e2                	ld	s3,24(sp)
    8020630a:	6a42                	ld	s4,16(sp)
    8020630c:	6aa2                	ld	s5,8(sp)
    8020630e:	6b02                	ld	s6,0(sp)
    if (!vdisk.base) return -1;                   /* no disk on this board */
    80206310:	00136797          	auipc	a5,0x136
    80206314:	cf07b783          	ld	a5,-784(a5) # 8033c000 <vdisk>
    80206318:	1a078363          	beqz	a5,802064be <hal_block_init+0x270>
    *R(VIRTIO_MMIO_STATUS) = 0;
    8020631c:	0607a823          	sw	zero,112(a5)
    *R(VIRTIO_MMIO_STATUS) = status;
    80206320:	00136797          	auipc	a5,0x136
    80206324:	ce078793          	addi	a5,a5,-800 # 8033c000 <vdisk>
    80206328:	6398                	ld	a4,0(a5)
    8020632a:	4685                	li	a3,1
    8020632c:	db34                	sw	a3,112(a4)
    *R(VIRTIO_MMIO_STATUS) = status;
    8020632e:	6398                	ld	a4,0(a5)
    80206330:	468d                	li	a3,3
    80206332:	db34                	sw	a3,112(a4)
    uint32 feats = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80206334:	6390                	ld	a2,0(a5)
    80206336:	4a18                	lw	a4,16(a2)
    feats &= ~(1u << VIRTIO_RING_F_EVENT_IDX);
    80206338:	c7ffe6b7          	lui	a3,0xc7ffe
    8020633c:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <uart+0xffffffff47cbf72f>
    80206340:	8f75                	and	a4,a4,a3
    *R(VIRTIO_MMIO_DRIVER_FEATURES) = feats;
    80206342:	d218                	sw	a4,32(a2)
    if (vdisk.version == 2) {
    80206344:	47d8                	lw	a4,12(a5)
    80206346:	4789                	li	a5,2
    status |= VIRTIO_CONFIG_S_DRIVER;
    80206348:	448d                	li	s1,3
    if (vdisk.version == 2) {
    8020634a:	0ef70563          	beq	a4,a5,80206434 <hal_block_init+0x1e6>
    *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8020634e:	00136797          	auipc	a5,0x136
    80206352:	cb278793          	addi	a5,a5,-846 # 8033c000 <vdisk>
    80206356:	6398                	ld	a4,0(a5)
    80206358:	02072823          	sw	zero,48(a4)
    uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8020635c:	6398                	ld	a4,0(a5)
    8020635e:	5b5c                	lw	a5,52(a4)
    80206360:	2781                	sext.w	a5,a5
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206362:	10078263          	beqz	a5,80206466 <hal_block_init+0x218>
    if (max < VNUM) panic("virtio_blk: queue too short");
    80206366:	469d                	li	a3,7
    80206368:	10f6fc63          	bgeu	a3,a5,80206480 <hal_block_init+0x232>
    *R(VIRTIO_MMIO_QUEUE_NUM) = VNUM;
    8020636c:	47a1                	li	a5,8
    8020636e:	df1c                	sw	a5,56(a4)
    memset(pages, 0, sizeof(pages));
    80206370:	6609                	lui	a2,0x2
    80206372:	4581                	li	a1,0
    80206374:	00137517          	auipc	a0,0x137
    80206378:	c8c50513          	addi	a0,a0,-884 # 8033d000 <pages.0>
    8020637c:	ffffa097          	auipc	ra,0xffffa
    80206380:	2e4080e7          	jalr	740(ra) # 80200660 <memset>
    vdisk.desc  = (struct virtq_desc *)pages;
    80206384:	00136797          	auipc	a5,0x136
    80206388:	c7c78793          	addi	a5,a5,-900 # 8033c000 <vdisk>
    8020638c:	00137717          	auipc	a4,0x137
    80206390:	c7470713          	addi	a4,a4,-908 # 8033d000 <pages.0>
    80206394:	eb98                	sd	a4,16(a5)
    vdisk.avail = (struct virtq_avail *)(pages + VNUM * sizeof(struct virtq_desc));
    80206396:	00137717          	auipc	a4,0x137
    8020639a:	cea70713          	addi	a4,a4,-790 # 8033d080 <pages.0+0x80>
    8020639e:	ef98                	sd	a4,24(a5)
    vdisk.used  = (struct virtq_used *)(pages + PGSIZE);
    802063a0:	00138717          	auipc	a4,0x138
    802063a4:	c6070713          	addi	a4,a4,-928 # 8033e000 <pages.0+0x1000>
    802063a8:	f398                	sd	a4,32(a5)
    if (vdisk.version == 1) {
    802063aa:	47d8                	lw	a4,12(a5)
    802063ac:	4785                	li	a5,1
    802063ae:	0ef70663          	beq	a4,a5,8020649a <hal_block_init+0x24c>
        *R(VIRTIO_MMIO_QUEUE_DESC_LOW)   = (uint64)vdisk.desc;
    802063b2:	00136797          	auipc	a5,0x136
    802063b6:	c4e78793          	addi	a5,a5,-946 # 8033c000 <vdisk>
    802063ba:	6398                	ld	a4,0(a5)
    802063bc:	00137697          	auipc	a3,0x137
    802063c0:	c4468693          	addi	a3,a3,-956 # 8033d000 <pages.0>
    802063c4:	08d72023          	sw	a3,128(a4)
        *R(VIRTIO_MMIO_QUEUE_DESC_HIGH)  = (uint64)vdisk.desc >> 32;
    802063c8:	6398                	ld	a4,0(a5)
    802063ca:	4bd4                	lw	a3,20(a5)
    802063cc:	08d72223          	sw	a3,132(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_LOW)  = (uint64)vdisk.avail;
    802063d0:	6398                	ld	a4,0(a5)
    802063d2:	4f94                	lw	a3,24(a5)
    802063d4:	08d72823          	sw	a3,144(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)vdisk.avail >> 32;
    802063d8:	6398                	ld	a4,0(a5)
    802063da:	4fd4                	lw	a3,28(a5)
    802063dc:	08d72a23          	sw	a3,148(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_LOW)  = (uint64)vdisk.used;
    802063e0:	6398                	ld	a4,0(a5)
    802063e2:	5394                	lw	a3,32(a5)
    802063e4:	0ad72023          	sw	a3,160(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)vdisk.used >> 32;
    802063e8:	6398                	ld	a4,0(a5)
    802063ea:	53d4                	lw	a3,36(a5)
    802063ec:	0ad72223          	sw	a3,164(a4)
        *R(VIRTIO_MMIO_QUEUE_READY) = 1;
    802063f0:	639c                	ld	a5,0(a5)
    802063f2:	4705                	li	a4,1
    802063f4:	c3f8                	sw	a4,68(a5)
    for (int i = 0; i < VNUM; i++) vdisk.free[i] = 1;
    802063f6:	00136797          	auipc	a5,0x136
    802063fa:	c0a78793          	addi	a5,a5,-1014 # 8033c000 <vdisk>
    802063fe:	4705                	li	a4,1
    80206400:	02e78423          	sb	a4,40(a5)
    80206404:	02e784a3          	sb	a4,41(a5)
    80206408:	02e78523          	sb	a4,42(a5)
    8020640c:	02e785a3          	sb	a4,43(a5)
    80206410:	02e78623          	sb	a4,44(a5)
    80206414:	02e786a3          	sb	a4,45(a5)
    80206418:	02e78723          	sb	a4,46(a5)
    8020641c:	02e787a3          	sb	a4,47(a5)
    status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80206420:	0044e493          	ori	s1,s1,4
    *R(VIRTIO_MMIO_STATUS) = status;
    80206424:	639c                	ld	a5,0(a5)
    80206426:	dba4                	sw	s1,112(a5)
    return 0;
    80206428:	4501                	li	a0,0
}
    8020642a:	70e2                	ld	ra,56(sp)
    8020642c:	7442                	ld	s0,48(sp)
    8020642e:	74a2                	ld	s1,40(sp)
    80206430:	6121                	addi	sp,sp,64
    80206432:	8082                	ret
        *R(VIRTIO_MMIO_STATUS) = status;
    80206434:	00136797          	auipc	a5,0x136
    80206438:	bcc78793          	addi	a5,a5,-1076 # 8033c000 <vdisk>
    8020643c:	6398                	ld	a4,0(a5)
    8020643e:	46ad                	li	a3,11
    80206440:	db34                	sw	a3,112(a4)
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80206442:	639c                	ld	a5,0(a5)
    80206444:	5bbc                	lw	a5,112(a5)
    80206446:	8ba1                	andi	a5,a5,8
        status |= VIRTIO_CONFIG_S_FEATURES_OK;
    80206448:	44ad                	li	s1,11
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    8020644a:	f391                	bnez	a5,8020634e <hal_block_init+0x100>
    8020644c:	f04a                	sd	s2,32(sp)
    8020644e:	ec4e                	sd	s3,24(sp)
    80206450:	e852                	sd	s4,16(sp)
    80206452:	e456                	sd	s5,8(sp)
    80206454:	e05a                	sd	s6,0(sp)
            panic("virtio_blk: device rejected our feature set");
    80206456:	00002517          	auipc	a0,0x2
    8020645a:	83250513          	addi	a0,a0,-1998 # 80207c88 <etext+0xc88>
    8020645e:	ffffa097          	auipc	ra,0xffffa
    80206462:	15c080e7          	jalr	348(ra) # 802005ba <panic>
    80206466:	f04a                	sd	s2,32(sp)
    80206468:	ec4e                	sd	s3,24(sp)
    8020646a:	e852                	sd	s4,16(sp)
    8020646c:	e456                	sd	s5,8(sp)
    8020646e:	e05a                	sd	s6,0(sp)
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206470:	00002517          	auipc	a0,0x2
    80206474:	84850513          	addi	a0,a0,-1976 # 80207cb8 <etext+0xcb8>
    80206478:	ffffa097          	auipc	ra,0xffffa
    8020647c:	142080e7          	jalr	322(ra) # 802005ba <panic>
    80206480:	f04a                	sd	s2,32(sp)
    80206482:	ec4e                	sd	s3,24(sp)
    80206484:	e852                	sd	s4,16(sp)
    80206486:	e456                	sd	s5,8(sp)
    80206488:	e05a                	sd	s6,0(sp)
    if (max < VNUM) panic("virtio_blk: queue too short");
    8020648a:	00002517          	auipc	a0,0x2
    8020648e:	85650513          	addi	a0,a0,-1962 # 80207ce0 <etext+0xce0>
    80206492:	ffffa097          	auipc	ra,0xffffa
    80206496:	128080e7          	jalr	296(ra) # 802005ba <panic>
        *R(VIRTIO_MMIO_GUEST_PAGE_SIZE) = PGSIZE;
    8020649a:	00136797          	auipc	a5,0x136
    8020649e:	b6678793          	addi	a5,a5,-1178 # 8033c000 <vdisk>
    802064a2:	6394                	ld	a3,0(a5)
    802064a4:	6705                	lui	a4,0x1
    802064a6:	d698                	sw	a4,40(a3)
        *R(VIRTIO_MMIO_QUEUE_ALIGN)     = PGSIZE;
    802064a8:	6394                	ld	a3,0(a5)
    802064aa:	ded8                	sw	a4,60(a3)
        *R(VIRTIO_MMIO_QUEUE_PFN)       = ((uint64)pages) >> 12;
    802064ac:	6398                	ld	a4,0(a5)
    802064ae:	00137797          	auipc	a5,0x137
    802064b2:	b5278793          	addi	a5,a5,-1198 # 8033d000 <pages.0>
    802064b6:	83b1                	srli	a5,a5,0xc
    802064b8:	2781                	sext.w	a5,a5
    802064ba:	c33c                	sw	a5,64(a4)
    802064bc:	bf2d                	j	802063f6 <hal_block_init+0x1a8>
    if (!vdisk.base) return -1;                   /* no disk on this board */
    802064be:	557d                	li	a0,-1
    802064c0:	b7ad                	j	8020642a <hal_block_init+0x1dc>

00000000802064c2 <hal_block_rw>:
    }
    return 0;
}

void hal_block_rw(struct buf *b, int write)
{
    802064c2:	7159                	addi	sp,sp,-112
    802064c4:	f486                	sd	ra,104(sp)
    802064c6:	f0a2                	sd	s0,96(sp)
    802064c8:	eca6                	sd	s1,88(sp)
    802064ca:	e8ca                	sd	s2,80(sp)
    802064cc:	e4ce                	sd	s3,72(sp)
    802064ce:	e0d2                	sd	s4,64(sp)
    802064d0:	fc56                	sd	s5,56(sp)
    802064d2:	f85a                	sd	s6,48(sp)
    802064d4:	f45e                	sd	s7,40(sp)
    802064d6:	f062                	sd	s8,32(sp)
    802064d8:	ec66                	sd	s9,24(sp)
    802064da:	1880                	addi	s0,sp,112
    802064dc:	8a2a                	mv	s4,a0
    802064de:	8cae                	mv	s9,a1
    /* LuitFS blocks are 1024 bytes = two 512-byte disk sectors. */
    uint64 sector = b->blockno * (BSIZE / 512);
    802064e0:	00c52c03          	lw	s8,12(a0)
    802064e4:	001c1c1b          	slliw	s8,s8,0x1
    802064e8:	1c02                	slli	s8,s8,0x20
    802064ea:	020c5c13          	srli	s8,s8,0x20

    acquire(&vdisk.lock);
    802064ee:	00136517          	auipc	a0,0x136
    802064f2:	c4a50513          	addi	a0,a0,-950 # 8033c138 <vdisk+0x138>
    802064f6:	ffffb097          	auipc	ra,0xffffb
    802064fa:	dfa080e7          	jalr	-518(ra) # 802012f0 <acquire>
    for (int i = 0; i < 3; i++) {
    802064fe:	4981                	li	s3,0
    for (int i = 0; i < VNUM; i++)
    80206500:	44a1                	li	s1,8
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206502:	00136b17          	auipc	s6,0x136
    80206506:	afeb0b13          	addi	s6,s6,-1282 # 8033c000 <vdisk>
    for (int i = 0; i < 3; i++) {
    8020650a:	4a8d                	li	s5,3

    int idx[3];
    while (alloc3_desc(idx) != 0)
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    8020650c:	00136b97          	auipc	s7,0x136
    80206510:	c2cb8b93          	addi	s7,s7,-980 # 8033c138 <vdisk+0x138>
    while (alloc3_desc(idx) != 0)
    80206514:	a0ad                	j	8020657e <hal_block_rw+0xbc>
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206516:	00fb0733          	add	a4,s6,a5
    8020651a:	02070423          	sb	zero,40(a4) # 1028 <_entry-0x801fefd8>
        idx[i] = alloc_desc();
    8020651e:	c19c                	sw	a5,0(a1)
        if (idx[i] < 0) {
    80206520:	0207c563          	bltz	a5,8020654a <hal_block_rw+0x88>
    for (int i = 0; i < 3; i++) {
    80206524:	2905                	addiw	s2,s2,1
    80206526:	0611                	addi	a2,a2,4 # 2004 <_entry-0x801fdffc>
    80206528:	05590f63          	beq	s2,s5,80206586 <hal_block_rw+0xc4>
        idx[i] = alloc_desc();
    8020652c:	85b2                	mv	a1,a2
    for (int i = 0; i < VNUM; i++)
    8020652e:	00136717          	auipc	a4,0x136
    80206532:	ad270713          	addi	a4,a4,-1326 # 8033c000 <vdisk>
    80206536:	87ce                	mv	a5,s3
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206538:	02874683          	lbu	a3,40(a4)
    8020653c:	fee9                	bnez	a3,80206516 <hal_block_rw+0x54>
    for (int i = 0; i < VNUM; i++)
    8020653e:	2785                	addiw	a5,a5,1
    80206540:	0705                	addi	a4,a4,1
    80206542:	fe979be3          	bne	a5,s1,80206538 <hal_block_rw+0x76>
        idx[i] = alloc_desc();
    80206546:	57fd                	li	a5,-1
    80206548:	c19c                	sw	a5,0(a1)
            for (int j = 0; j < i; j++) free_desc(idx[j]);
    8020654a:	03205163          	blez	s2,8020656c <hal_block_rw+0xaa>
    8020654e:	f9042503          	lw	a0,-112(s0)
    80206552:	00000097          	auipc	ra,0x0
    80206556:	c66080e7          	jalr	-922(ra) # 802061b8 <free_desc>
    8020655a:	4785                	li	a5,1
    8020655c:	0127d863          	bge	a5,s2,8020656c <hal_block_rw+0xaa>
    80206560:	f9442503          	lw	a0,-108(s0)
    80206564:	00000097          	auipc	ra,0x0
    80206568:	c54080e7          	jalr	-940(ra) # 802061b8 <free_desc>
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    8020656c:	85de                	mv	a1,s7
    8020656e:	00136517          	auipc	a0,0x136
    80206572:	aba50513          	addi	a0,a0,-1350 # 8033c028 <vdisk+0x28>
    80206576:	ffffb097          	auipc	ra,0xffffb
    8020657a:	7c8080e7          	jalr	1992(ra) # 80201d3e <sleep>
    for (int i = 0; i < 3; i++) {
    8020657e:	f9040613          	addi	a2,s0,-112
    80206582:	894e                	mv	s2,s3
    80206584:	b765                	j	8020652c <hal_block_rw+0x6a>

    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80206586:	f9042683          	lw	a3,-112(s0)
    8020658a:	00268793          	addi	a5,a3,2
    8020658e:	0796                	slli	a5,a5,0x5
    req->type     = write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN;
    80206590:	00136597          	auipc	a1,0x136
    80206594:	a7058593          	addi	a1,a1,-1424 # 8033c000 <vdisk>
    80206598:	00569713          	slli	a4,a3,0x5
    8020659c:	972e                	add	a4,a4,a1
    8020659e:	01903633          	snez	a2,s9
    802065a2:	c330                	sw	a2,64(a4)
    req->reserved = 0;
    802065a4:	04072223          	sw	zero,68(a4)
    req->sector   = sector;
    802065a8:	05873423          	sd	s8,72(a4)

    vdisk.desc[idx[0]] = (struct virtq_desc){
    802065ac:	00469613          	slli	a2,a3,0x4
    802065b0:	6998                	ld	a4,16(a1)
    802065b2:	9732                	add	a4,a4,a2
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    802065b4:	f9442603          	lw	a2,-108(s0)
    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    802065b8:	00f58533          	add	a0,a1,a5
    vdisk.desc[idx[0]] = (struct virtq_desc){
    802065bc:	e308                	sd	a0,0(a4)
    802065be:	4541                	li	a0,16
    802065c0:	c708                	sw	a0,8(a4)
    802065c2:	4505                	li	a0,1
    802065c4:	00a71623          	sh	a0,12(a4)
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    802065c8:	00c71723          	sh	a2,14(a4)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    802065cc:	0612                	slli	a2,a2,0x4
    802065ce:	6998                	ld	a4,16(a1)
    802065d0:	9732                	add	a4,a4,a2
        (uint64)b->data, BSIZE,
    802065d2:	058a0513          	addi	a0,s4,88
        (uint16)((write ? 0 : VRING_DESC_F_WRITE) | VRING_DESC_F_NEXT),
    802065d6:	460d                	li	a2,3
    802065d8:	000c8363          	beqz	s9,802065de <hal_block_rw+0x11c>
    802065dc:	4605                	li	a2,1
        (uint16)idx[2] };
    802065de:	f9842583          	lw	a1,-104(s0)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    802065e2:	e308                	sd	a0,0(a4)
    802065e4:	40000513          	li	a0,1024
    802065e8:	c708                	sw	a0,8(a4)
    802065ea:	00c71623          	sh	a2,12(a4)
        (uint16)idx[2] };
    802065ee:	00b71723          	sh	a1,14(a4)
    vdisk.info[idx[0]].status = 0xff;             /* device overwrites on success */
    802065f2:	00136717          	auipc	a4,0x136
    802065f6:	a0e70713          	addi	a4,a4,-1522 # 8033c000 <vdisk>
    802065fa:	00268613          	addi	a2,a3,2
    802065fe:	0616                	slli	a2,a2,0x5
    80206600:	963a                	add	a2,a2,a4
    80206602:	557d                	li	a0,-1
    80206604:	00a60823          	sb	a0,16(a2)
    vdisk.desc[idx[2]] = (struct virtq_desc){
    80206608:	0592                	slli	a1,a1,0x4
    8020660a:	6b10                	ld	a2,16(a4)
    8020660c:	962e                	add	a2,a2,a1
        (uint64)&vdisk.info[idx[0]].status, 1, VRING_DESC_F_WRITE, 0 };
    8020660e:	07c1                	addi	a5,a5,16
    80206610:	97ba                	add	a5,a5,a4
    vdisk.desc[idx[2]] = (struct virtq_desc){
    80206612:	e21c                	sd	a5,0(a2)
    80206614:	4585                	li	a1,1
    80206616:	c60c                	sw	a1,8(a2)
    80206618:	4789                	li	a5,2
    8020661a:	00f61623          	sh	a5,12(a2)
    8020661e:	00061723          	sh	zero,14(a2)

    b->disk = 1;                                  /* I2: device owns b->data */
    80206622:	00ba2223          	sw	a1,4(s4)
    vdisk.info[idx[0]].b = b;                     /* I3 */
    80206626:	00569793          	slli	a5,a3,0x5
    8020662a:	97ba                	add	a5,a5,a4
    8020662c:	0347bc23          	sd	s4,56(a5)

    vdisk.avail->ring[vdisk.avail->idx % VNUM] = idx[0];
    80206630:	6f10                	ld	a2,24(a4)
    80206632:	00265783          	lhu	a5,2(a2)
    80206636:	8b9d                	andi	a5,a5,7
    80206638:	0786                	slli	a5,a5,0x1
    8020663a:	963e                	add	a2,a2,a5
    8020663c:	00d61223          	sh	a3,4(a2)
    __sync_synchronize();          /* ring entry visible BEFORE idx bump */
    80206640:	0ff0000f          	fence
    vdisk.avail->idx += 1;
    80206644:	6f14                	ld	a3,24(a4)
    80206646:	0026d783          	lhu	a5,2(a3)
    8020664a:	2785                	addiw	a5,a5,1
    8020664c:	00f69123          	sh	a5,2(a3)
    __sync_synchronize();          /* idx visible BEFORE the doorbell    */
    80206650:	0ff0000f          	fence
    *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0;
    80206654:	631c                	ld	a5,0(a4)
    80206656:	0407a823          	sw	zero,80(a5)

    while (b->disk == 1)
    8020665a:	004a2783          	lw	a5,4(s4)
    8020665e:	02b79163          	bne	a5,a1,80206680 <hal_block_rw+0x1be>
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    80206662:	00136917          	auipc	s2,0x136
    80206666:	ad690913          	addi	s2,s2,-1322 # 8033c138 <vdisk+0x138>
    while (b->disk == 1)
    8020666a:	4485                	li	s1,1
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    8020666c:	85ca                	mv	a1,s2
    8020666e:	8552                	mv	a0,s4
    80206670:	ffffb097          	auipc	ra,0xffffb
    80206674:	6ce080e7          	jalr	1742(ra) # 80201d3e <sleep>
    while (b->disk == 1)
    80206678:	004a2783          	lw	a5,4(s4)
    8020667c:	fe9788e3          	beq	a5,s1,8020666c <hal_block_rw+0x1aa>

    vdisk.info[idx[0]].b = 0;
    80206680:	f9042503          	lw	a0,-112(s0)
    80206684:	00551713          	slli	a4,a0,0x5
    80206688:	00136797          	auipc	a5,0x136
    8020668c:	97878793          	addi	a5,a5,-1672 # 8033c000 <vdisk>
    80206690:	97ba                	add	a5,a5,a4
    80206692:	0207bc23          	sd	zero,56(a5)
    free_desc(idx[0]); free_desc(idx[1]); free_desc(idx[2]);
    80206696:	00000097          	auipc	ra,0x0
    8020669a:	b22080e7          	jalr	-1246(ra) # 802061b8 <free_desc>
    8020669e:	f9442503          	lw	a0,-108(s0)
    802066a2:	00000097          	auipc	ra,0x0
    802066a6:	b16080e7          	jalr	-1258(ra) # 802061b8 <free_desc>
    802066aa:	f9842503          	lw	a0,-104(s0)
    802066ae:	00000097          	auipc	ra,0x0
    802066b2:	b0a080e7          	jalr	-1270(ra) # 802061b8 <free_desc>

    release(&vdisk.lock);
    802066b6:	00136517          	auipc	a0,0x136
    802066ba:	a8250513          	addi	a0,a0,-1406 # 8033c138 <vdisk+0x138>
    802066be:	ffffb097          	auipc	ra,0xffffb
    802066c2:	ce6080e7          	jalr	-794(ra) # 802013a4 <release>
}
    802066c6:	70a6                	ld	ra,104(sp)
    802066c8:	7406                	ld	s0,96(sp)
    802066ca:	64e6                	ld	s1,88(sp)
    802066cc:	6946                	ld	s2,80(sp)
    802066ce:	69a6                	ld	s3,72(sp)
    802066d0:	6a06                	ld	s4,64(sp)
    802066d2:	7ae2                	ld	s5,56(sp)
    802066d4:	7b42                	ld	s6,48(sp)
    802066d6:	7ba2                	ld	s7,40(sp)
    802066d8:	7c02                	ld	s8,32(sp)
    802066da:	6ce2                	ld	s9,24(sp)
    802066dc:	6165                	addi	sp,sp,112
    802066de:	8082                	ret

00000000802066e0 <hal_block_intr>:

void hal_block_intr(void)
{
    802066e0:	1101                	addi	sp,sp,-32
    802066e2:	ec06                	sd	ra,24(sp)
    802066e4:	e822                	sd	s0,16(sp)
    802066e6:	e426                	sd	s1,8(sp)
    802066e8:	1000                	addi	s0,sp,32
    acquire(&vdisk.lock);
    802066ea:	00136497          	auipc	s1,0x136
    802066ee:	91648493          	addi	s1,s1,-1770 # 8033c000 <vdisk>
    802066f2:	00136517          	auipc	a0,0x136
    802066f6:	a4650513          	addi	a0,a0,-1466 # 8033c138 <vdisk+0x138>
    802066fa:	ffffb097          	auipc	ra,0xffffb
    802066fe:	bf6080e7          	jalr	-1034(ra) # 802012f0 <acquire>

    /* Ack FIRST: a completion that lands after this read re-raises the
     * interrupt instead of being lost. */
    *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80206702:	6098                	ld	a4,0(s1)
    80206704:	533c                	lw	a5,96(a4)
    80206706:	8b8d                	andi	a5,a5,3
    80206708:	d37c                	sw	a5,100(a4)
    __sync_synchronize();
    8020670a:	0ff0000f          	fence

    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    8020670e:	709c                	ld	a5,32(s1)
    80206710:	0304d703          	lhu	a4,48(s1)
    80206714:	0027d783          	lhu	a5,2(a5)
    80206718:	04f70e63          	beq	a4,a5,80206774 <hal_block_intr+0x94>
    8020671c:	e04a                	sd	s2,0(sp)

        if (vdisk.info[id].status != 0)
            panic("virtio_blk: request failed (status byte nonzero)");

        struct buf *b = vdisk.info[id].b;
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    8020671e:	4905                	li	s2,1
        __sync_synchronize();
    80206720:	0ff0000f          	fence
        int id = vdisk.used->ring[vdisk.used_idx % VNUM].id;
    80206724:	7098                	ld	a4,32(s1)
    80206726:	0304d783          	lhu	a5,48(s1)
    8020672a:	8b9d                	andi	a5,a5,7
    8020672c:	078e                	slli	a5,a5,0x3
    8020672e:	97ba                	add	a5,a5,a4
    80206730:	43dc                	lw	a5,4(a5)
        if (vdisk.info[id].status != 0)
    80206732:	00278713          	addi	a4,a5,2
    80206736:	0716                	slli	a4,a4,0x5
    80206738:	9726                	add	a4,a4,s1
    8020673a:	01074703          	lbu	a4,16(a4)
    8020673e:	eb21                	bnez	a4,8020678e <hal_block_intr+0xae>
        struct buf *b = vdisk.info[id].b;
    80206740:	0796                	slli	a5,a5,0x5
    80206742:	97a6                	add	a5,a5,s1
    80206744:	7f88                	ld	a0,56(a5)
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    80206746:	cd21                	beqz	a0,8020679e <hal_block_intr+0xbe>
    80206748:	415c                	lw	a5,4(a0)
    8020674a:	05279a63          	bne	a5,s2,8020679e <hal_block_intr+0xbe>
        b->disk = 0;                              /* I2: hart owns data again */
    8020674e:	00052223          	sw	zero,4(a0)
        wakeup(b);
    80206752:	ffffb097          	auipc	ra,0xffffb
    80206756:	772080e7          	jalr	1906(ra) # 80201ec4 <wakeup>

        vdisk.used_idx += 1;
    8020675a:	0304d783          	lhu	a5,48(s1)
    8020675e:	2785                	addiw	a5,a5,1
    80206760:	17c2                	slli	a5,a5,0x30
    80206762:	93c1                	srli	a5,a5,0x30
    80206764:	02f49823          	sh	a5,48(s1)
    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    80206768:	7098                	ld	a4,32(s1)
    8020676a:	00275703          	lhu	a4,2(a4)
    8020676e:	faf719e3          	bne	a4,a5,80206720 <hal_block_intr+0x40>
    80206772:	6902                	ld	s2,0(sp)
    }
    release(&vdisk.lock);
    80206774:	00136517          	auipc	a0,0x136
    80206778:	9c450513          	addi	a0,a0,-1596 # 8033c138 <vdisk+0x138>
    8020677c:	ffffb097          	auipc	ra,0xffffb
    80206780:	c28080e7          	jalr	-984(ra) # 802013a4 <release>
}
    80206784:	60e2                	ld	ra,24(sp)
    80206786:	6442                	ld	s0,16(sp)
    80206788:	64a2                	ld	s1,8(sp)
    8020678a:	6105                	addi	sp,sp,32
    8020678c:	8082                	ret
            panic("virtio_blk: request failed (status byte nonzero)");
    8020678e:	00001517          	auipc	a0,0x1
    80206792:	57250513          	addi	a0,a0,1394 # 80207d00 <etext+0xd00>
    80206796:	ffffa097          	auipc	ra,0xffffa
    8020679a:	e24080e7          	jalr	-476(ra) # 802005ba <panic>
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    8020679e:	00001517          	auipc	a0,0x1
    802067a2:	59a50513          	addi	a0,a0,1434 # 80207d38 <etext+0xd38>
    802067a6:	ffffa097          	auipc	ra,0xffffa
    802067aa:	e14080e7          	jalr	-492(ra) # 802005ba <panic>
