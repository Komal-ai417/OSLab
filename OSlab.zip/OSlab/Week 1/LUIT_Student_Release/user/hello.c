#include "ulib.h"

int
main(int argc, char *argv[])
{
    printf("hello from Karyampudi Komal, roll 240101041\n");
    exit(0);
}
