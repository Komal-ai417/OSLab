user/usitest.o: user/usitest.c user/ulib.h user/../kernel/stat.h \
 user/../kernel/fcntl.h user/../kernel/pstat.h user/../kernel/usysinfo.h
