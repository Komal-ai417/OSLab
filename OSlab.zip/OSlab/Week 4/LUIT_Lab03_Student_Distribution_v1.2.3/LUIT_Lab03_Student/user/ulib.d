user/ulib.o: user/ulib.c \
 /usr/lib/gcc/riscv64-unknown-elf/13.2.0/include/stdarg.h user/ulib.h \
 user/../kernel/stat.h user/../kernel/fcntl.h user/../kernel/pstat.h \
 user/../kernel/usysinfo.h
