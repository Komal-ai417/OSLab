user/usiexec.o: user/usiexec.c user/ulib.h user/../kernel/stat.h \
 user/../kernel/fcntl.h user/../kernel/pstat.h user/../kernel/usysinfo.h
