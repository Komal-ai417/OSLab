
kernel.elf:     file format elf64-littleriscv


Disassembly of section .text:

0000000080200000 <_entry>:
# L1/L2 - first instructions. OpenSBI enters here in S-mode.
# a0 = hartid, a1 = physical address of the FDT blob. Both must survive to start().
.section .text.entry
.globl _entry
_entry:
        la      t0, boot_stacks
    80200000:	00009297          	auipc	t0,0x9
    80200004:	00028293          	mv	t0,t0
        li      t1, 16384
    80200008:	6311                	lui	t1,0x4
        addi    t2, a0, 1
    8020000a:	00150393          	addi	t2,a0,1
        mul     t1, t1, t2
    8020000e:	02730333          	mul	t1,t1,t2
        add     sp, t0, t1      # sp = boot_stacks + (hartid+1)*16384
    80200012:	00628133          	add	sp,t0,t1
        mv      tp, a0          # tp = hartid, for mycpu()
    80200016:	822a                	mv	tp,a0
        call    start
    80200018:	00000097          	auipc	ra,0x0
    8020001c:	00e080e7          	jalr	14(ra) # 80200026 <start>

0000000080200020 <spin>:
spin:   wfi
    80200020:	10500073          	wfi
        j       spin
    80200024:	bff5                	j	80200020 <spin>

0000000080200026 <start>:
    printf("hart %d: online\n", hal_hart_id());
    scheduler();            /* never returns */
}

void start(uint64 hartid, uint64 fdt_pa)
{
    80200026:	7139                	addi	sp,sp,-64
    80200028:	fc06                	sd	ra,56(sp)
    8020002a:	f822                	sd	s0,48(sp)
    8020002c:	f04a                	sd	s2,32(sp)
    8020002e:	0080                	addi	s0,sp,64
    80200030:	892a                	mv	s2,a0
    /* The firmware chooses the initial payload hart.  Do not assume it is 0.
     * Atomic election also keeps this correct on firmware that releases more
     * than one hart into the payload concurrently. */
    int am_boot_hart = __sync_bool_compare_and_swap(&boot_hart, -1, (int)hartid);
    80200032:	00008717          	auipc	a4,0x8
    80200036:	fce70713          	addi	a4,a4,-50 # 80208000 <boot_hart>
    8020003a:	56fd                	li	a3,-1
    8020003c:	0f50000f          	fence	iorw,ow
    80200040:	140727af          	lr.w.aq	a5,(a4)
    80200044:	00d79563          	bne	a5,a3,8020004e <start+0x28>
    80200048:	1ca7262f          	sc.w.aq	a2,a0,(a4)
    8020004c:	fa75                	bnez	a2,80200040 <start+0x1a>
    8020004e:	2785                	addiw	a5,a5,1

    if (am_boot_hart) {
    80200050:	1c079a63          	bnez	a5,80200224 <start+0x1fe>
    80200054:	f426                	sd	s1,40(sp)
    80200056:	ec4e                	sd	s3,24(sp)
    80200058:	e852                	sd	s4,16(sp)
    8020005a:	852e                	mv	a0,a1
        /* --- boot hart (whichever hart OpenSBI selected) --- */

        /* BEFORE anything else, ask the firmware what hardware we have.
         * Until fdt_init() runs we know nothing about this board - and we do
         * not pretend to. Use SBI's console for the very first messages. */
        fdt_init(fdt_pa);
    8020005c:	00001097          	auipc	ra,0x1
    80200060:	896080e7          	jalr	-1898(ra) # 802008f2 <fdt_init>

        /* Report what we discovered BEFORE we trust it - these lines go out over
         * the SBI console, so they are visible even if the UART base is wrong. */
        printf("\n");
    80200064:	00007517          	auipc	a0,0x7
    80200068:	f9c50513          	addi	a0,a0,-100 # 80207000 <etext>
    8020006c:	00000097          	auipc	ra,0x0
    80200070:	314080e7          	jalr	788(ra) # 80200380 <printf>
        printf("=========================================\n");
    80200074:	00007517          	auipc	a0,0x7
    80200078:	f9450513          	addi	a0,a0,-108 # 80207008 <etext+0x8>
    8020007c:	00000097          	auipc	ra,0x0
    80200080:	304080e7          	jalr	772(ra) # 80200380 <printf>
        printf("  BrahmaputraOS / kernel Luit\n");
    80200084:	00007517          	auipc	a0,0x7
    80200088:	fb450513          	addi	a0,a0,-76 # 80207038 <etext+0x38>
    8020008c:	00000097          	auipc	ra,0x0
    80200090:	2f4080e7          	jalr	756(ra) # 80200380 <printf>
        printf("  IIT Guwahati - CS3106L\n");
    80200094:	00007517          	auipc	a0,0x7
    80200098:	fc450513          	addi	a0,a0,-60 # 80207058 <etext+0x58>
    8020009c:	00000097          	auipc	ra,0x0
    802000a0:	2e4080e7          	jalr	740(ra) # 80200380 <printf>
        printf("=========================================\n");
    802000a4:	00007517          	auipc	a0,0x7
    802000a8:	f6450513          	addi	a0,a0,-156 # 80207008 <etext+0x8>
    802000ac:	00000097          	auipc	ra,0x0
    802000b0:	2d4080e7          	jalr	724(ra) # 80200380 <printf>
        printf("fdt   : blob at %p (%d bytes)\n", fdt.blob, fdt.blob_size);
    802000b4:	00029497          	auipc	s1,0x29
    802000b8:	f6448493          	addi	s1,s1,-156 # 80229018 <fdt>
    802000bc:	6490                	ld	a2,8(s1)
    802000be:	608c                	ld	a1,0(s1)
    802000c0:	00007517          	auipc	a0,0x7
    802000c4:	fb850513          	addi	a0,a0,-72 # 80207078 <etext+0x78>
    802000c8:	00000097          	auipc	ra,0x0
    802000cc:	2b8080e7          	jalr	696(ra) # 80200380 <printf>
        printf("uart  : %p  (discovered, not hardcoded)\n", fdt.uart_base);
    802000d0:	688c                	ld	a1,16(s1)
    802000d2:	00007517          	auipc	a0,0x7
    802000d6:	fc650513          	addi	a0,a0,-58 # 80207098 <etext+0x98>
    802000da:	00000097          	auipc	ra,0x0
    802000de:	2a6080e7          	jalr	678(ra) # 80200380 <printf>
        printf("plic  : %p\n", fdt.plic_base);
    802000e2:	6c8c                	ld	a1,24(s1)
    802000e4:	00007517          	auipc	a0,0x7
    802000e8:	fe450513          	addi	a0,a0,-28 # 802070c8 <etext+0xc8>
    802000ec:	00000097          	auipc	ra,0x0
    802000f0:	294080e7          	jalr	660(ra) # 80200380 <printf>
        printf("memory: %p + %d MiB\n", fdt.mem_base, fdt.mem_size >> 20);
    802000f4:	6cd0                	ld	a2,152(s1)
    802000f6:	8251                	srli	a2,a2,0x14
    802000f8:	68cc                	ld	a1,144(s1)
    802000fa:	00007517          	auipc	a0,0x7
    802000fe:	fde50513          	addi	a0,a0,-34 # 802070d8 <etext+0xd8>
    80200102:	00000097          	auipc	ra,0x0
    80200106:	27e080e7          	jalr	638(ra) # 80200380 <printf>
        printf("harts : %d\n", fdt.ncpu);
    8020010a:	0a04a583          	lw	a1,160(s1)
    8020010e:	00007517          	auipc	a0,0x7
    80200112:	fe250513          	addi	a0,a0,-30 # 802070f0 <etext+0xf0>
    80200116:	00000097          	auipc	ra,0x0
    8020011a:	26a080e7          	jalr	618(ra) # 80200380 <printf>

        /* Now switch to our own UART driver. */
        hal_console_init(fdt.uart_base);
    8020011e:	6888                	ld	a0,16(s1)
    80200120:	00006097          	auipc	ra,0x6
    80200124:	73c080e7          	jalr	1852(ra) # 8020685c <hal_console_init>
        hal_intc_init(fdt.plic_base);
    80200128:	6c88                	ld	a0,24(s1)
    8020012a:	00006097          	auipc	ra,0x6
    8020012e:	58e080e7          	jalr	1422(ra) # 802066b8 <hal_intc_init>
        console_ready = 1;
    80200132:	0014a997          	auipc	s3,0x14a
    80200136:	ed298993          	addi	s3,s3,-302 # 8034a004 <console_ready>
    8020013a:	4a05                	li	s4,1
    8020013c:	0149a023          	sw	s4,0(s3)

        palloc_init();
    80200140:	00001097          	auipc	ra,0x1
    80200144:	e3e080e7          	jalr	-450(ra) # 80200f7e <palloc_init>
        printfinit();       /* locked printf, now that we have locks + memory */
    80200148:	00000097          	auipc	ra,0x0
    8020014c:	478080e7          	jalr	1144(ra) # 802005c0 <printfinit>
        procinit();
    80200150:	00001097          	auipc	ra,0x1
    80200154:	6be080e7          	jalr	1726(ra) # 8020180e <procinit>
        trace_init();       /* completed Lab 2 dependency */
    80200158:	00004097          	auipc	ra,0x4
    8020015c:	03e080e7          	jalr	62(ra) # 80204196 <trace_init>
        kvminit();
    80200160:	00003097          	auipc	ra,0x3
    80200164:	b1c080e7          	jalr	-1252(ra) # 80202c7c <kvminit>
        kvminithart();      /* paging ON for this hart */
    80200168:	00003097          	auipc	ra,0x3
    8020016c:	c26080e7          	jalr	-986(ra) # 80202d8e <kvminithart>

        /* MMIO is now behind the page table at its high alias - re-point the
         * drivers at the virtual addresses. This is why the HAL takes a base
         * address as an argument instead of hardcoding one. */
        console_ready = 0;                    /* SBI console while we re-point */
    80200170:	0009a023          	sw	zero,0(s3)
        hal_console_init(mmio_alias(fdt.uart_base));
    80200174:	6888                	ld	a0,16(s1)
    80200176:	00003097          	auipc	ra,0x3
    8020017a:	936080e7          	jalr	-1738(ra) # 80202aac <mmio_alias>
    8020017e:	00006097          	auipc	ra,0x6
    80200182:	6de080e7          	jalr	1758(ra) # 8020685c <hal_console_init>
        console_ready = 1;
    80200186:	0149a023          	sw	s4,0(s3)
        hal_intc_init(mmio_alias(fdt.plic_base));
    8020018a:	6c88                	ld	a0,24(s1)
    8020018c:	00003097          	auipc	ra,0x3
    80200190:	920080e7          	jalr	-1760(ra) # 80202aac <mmio_alias>
    80200194:	00006097          	auipc	ra,0x6
    80200198:	524080e7          	jalr	1316(ra) # 802066b8 <hal_intc_init>

        consoleinit();      /* console device (major CONSOLE)         */
    8020019c:	00004097          	auipc	ra,0x4
    802001a0:	6f2080e7          	jalr	1778(ra) # 8020488e <consoleinit>
        binit();            /* buffer cache                           */
    802001a4:	00005097          	auipc	ra,0x5
    802001a8:	c92080e7          	jalr	-878(ra) # 80204e36 <binit>
        iinit();            /* inode cache                            */
    802001ac:	00005097          	auipc	ra,0x5
    802001b0:	2e4080e7          	jalr	740(ra) # 80205490 <iinit>
        fileinit();         /* system-wide open-file table            */
    802001b4:	00006097          	auipc	ra,0x6
    802001b8:	e06080e7          	jalr	-506(ra) # 80205fba <fileinit>
        if (hal_block_init() < 0)
    802001bc:	00006097          	auipc	ra,0x6
    802001c0:	7be080e7          	jalr	1982(ra) # 8020697a <hal_block_init>
    802001c4:	0a054663          	bltz	a0,80200270 <start+0x24a>
    802001c8:	e456                	sd	s5,8(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
        trapinit_hart();    /* traps, timer, PLIC (incl. the disk irq) */
    802001ca:	00002097          	auipc	ra,0x2
    802001ce:	2f2080e7          	jalr	754(ra) # 802024bc <trapinit_hart>
        userinit();         /* the first user process                 */
    802001d2:	00001097          	auipc	ra,0x1
    802001d6:	6d4080e7          	jalr	1748(ra) # 802018a6 <userinit>

        printf("hart %d: online\n", (int)hartid);
    802001da:	2901                	sext.w	s2,s2
    802001dc:	85ca                	mv	a1,s2
    802001de:	00007517          	auipc	a0,0x7
    802001e2:	f6a50513          	addi	a0,a0,-150 # 80207148 <etext+0x148>
    802001e6:	00000097          	auipc	ra,0x0
    802001ea:	19a080e7          	jalr	410(ra) # 80200380 <printf>
        __sync_synchronize();
    802001ee:	0ff0000f          	fence
        started = 1;
    802001f2:	4785                	li	a5,1
    802001f4:	0014a717          	auipc	a4,0x14a
    802001f8:	e0f72623          	sw	a5,-500(a4) # 8034a000 <started>

        /* L9: SMP. Start every OTHER hart the device tree told us about.
         * QEMU virt exposes contiguous hart IDs 0..ncpu-1, but the initial
         * OpenSBI payload hart is not guaranteed to be hart 0. */
        for (int i = 0; i < fdt.ncpu; i++) {
    802001fc:	00029797          	auipc	a5,0x29
    80200200:	ebc7a783          	lw	a5,-324(a5) # 802290b8 <fdt+0xa0>
    80200204:	0af05b63          	blez	a5,802002ba <start+0x294>
    80200208:	4481                	li	s1,0
            if (i == (int)hartid)
                continue;
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    8020020a:	00000a17          	auipc	s4,0x0
    8020020e:	df6a0a13          	addi	s4,s4,-522 # 80200000 <_entry>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    80200212:	00007a97          	auipc	s5,0x7
    80200216:	f4ea8a93          	addi	s5,s5,-178 # 80207160 <etext+0x160>
        for (int i = 0; i < fdt.ncpu; i++) {
    8020021a:	00029997          	auipc	s3,0x29
    8020021e:	dfe98993          	addi	s3,s3,-514 # 80229018 <fdt>
    80200222:	a0bd                	j	80200290 <start+0x26a>
    80200224:	f426                	sd	s1,40(sp)
    80200226:	ec4e                	sd	s3,24(sp)
    80200228:	e852                	sd	s4,16(sp)
    8020022a:	e456                	sd	s5,8(sp)
        }

        scheduler();
    } else {
        /* --- secondary harts --- */
        while (started == 0)
    8020022c:	0014a717          	auipc	a4,0x14a
    80200230:	dd470713          	addi	a4,a4,-556 # 8034a000 <started>
    80200234:	431c                	lw	a5,0(a4)
    80200236:	2781                	sext.w	a5,a5
    80200238:	dff5                	beqz	a5,80200234 <start+0x20e>
            ;
        __sync_synchronize();
    8020023a:	0ff0000f          	fence
    kvminithart();          /* same kernel page table */
    8020023e:	00003097          	auipc	ra,0x3
    80200242:	b50080e7          	jalr	-1200(ra) # 80202d8e <kvminithart>
    trapinit_hart();        /* own stvec, own timer, own PLIC context */
    80200246:	00002097          	auipc	ra,0x2
    8020024a:	276080e7          	jalr	630(ra) # 802024bc <trapinit_hart>
    printf("hart %d: online\n", hal_hart_id());
    8020024e:	00006097          	auipc	ra,0x6
    80200252:	560080e7          	jalr	1376(ra) # 802067ae <hal_hart_id>
    80200256:	85aa                	mv	a1,a0
    80200258:	00007517          	auipc	a0,0x7
    8020025c:	ef050513          	addi	a0,a0,-272 # 80207148 <etext+0x148>
    80200260:	00000097          	auipc	ra,0x0
    80200264:	120080e7          	jalr	288(ra) # 80200380 <printf>
    scheduler();            /* never returns */
    80200268:	00002097          	auipc	ra,0x2
    8020026c:	98e080e7          	jalr	-1650(ra) # 80201bf6 <scheduler>
    80200270:	e456                	sd	s5,8(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
    80200272:	00007517          	auipc	a0,0x7
    80200276:	e8e50513          	addi	a0,a0,-370 # 80207100 <etext+0x100>
    8020027a:	00000097          	auipc	ra,0x0
    8020027e:	378080e7          	jalr	888(ra) # 802005f2 <panic>
        for (int i = 0; i < fdt.ncpu; i++) {
    80200282:	0485                	addi	s1,s1,1
    80200284:	0a09a703          	lw	a4,160(s3)
    80200288:	0004879b          	sext.w	a5,s1
    8020028c:	02e7d763          	bge	a5,a4,802002ba <start+0x294>
            if (i == (int)hartid)
    80200290:	0004879b          	sext.w	a5,s1
    80200294:	fef907e3          	beq	s2,a5,80200282 <start+0x25c>
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    80200298:	4601                	li	a2,0
    8020029a:	85d2                	mv	a1,s4
    8020029c:	8526                	mv	a0,s1
    8020029e:	00000097          	auipc	ra,0x0
    802002a2:	574080e7          	jalr	1396(ra) # 80200812 <sbi_hart_start>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    802002a6:	dd71                	beqz	a0,80200282 <start+0x25c>
    802002a8:	862a                	mv	a2,a0
    802002aa:	0004859b          	sext.w	a1,s1
    802002ae:	8556                	mv	a0,s5
    802002b0:	00000097          	auipc	ra,0x0
    802002b4:	0d0080e7          	jalr	208(ra) # 80200380 <printf>
    802002b8:	b7e9                	j	80200282 <start+0x25c>
        scheduler();
    802002ba:	00002097          	auipc	ra,0x2
    802002be:	93c080e7          	jalr	-1732(ra) # 80201bf6 <scheduler>

00000000802002c2 <putc>:

/* Before the UART driver exists (i.e. before the device tree has told us where
 * the UART is), fall back to OpenSBI's console. This is why a panic inside
 * fdt_init() is still visible - a silent early panic is a nightmare to debug. */
int console_ready = 0;
static void putc(char c) { if (console_ready) hal_console_putc(c); else sbi_putchar(c); }
    802002c2:	1141                	addi	sp,sp,-16
    802002c4:	e406                	sd	ra,8(sp)
    802002c6:	e022                	sd	s0,0(sp)
    802002c8:	0800                	addi	s0,sp,16
    802002ca:	0014a797          	auipc	a5,0x14a
    802002ce:	d3a7a783          	lw	a5,-710(a5) # 8034a004 <console_ready>
    802002d2:	cb89                	beqz	a5,802002e4 <putc+0x22>
    802002d4:	00006097          	auipc	ra,0x6
    802002d8:	5c2080e7          	jalr	1474(ra) # 80206896 <hal_console_putc>
    802002dc:	60a2                	ld	ra,8(sp)
    802002de:	6402                	ld	s0,0(sp)
    802002e0:	0141                	addi	sp,sp,16
    802002e2:	8082                	ret
    802002e4:	00000097          	auipc	ra,0x0
    802002e8:	4dc080e7          	jalr	1244(ra) # 802007c0 <sbi_putchar>
    802002ec:	bfc5                	j	802002dc <putc+0x1a>

00000000802002ee <printint>:

static void printint(long long xx, int base, int sign)
{
    802002ee:	7139                	addi	sp,sp,-64
    802002f0:	fc06                	sd	ra,56(sp)
    802002f2:	f822                	sd	s0,48(sp)
    802002f4:	0080                	addi	s0,sp,64
    char buf[24];
    int i = 0;
    unsigned long long x;

    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    802002f6:	c219                	beqz	a2,802002fc <printint+0xe>
    802002f8:	08054163          	bltz	a0,8020037a <printint+0x8c>
    802002fc:	4601                	li	a2,0
    802002fe:	fc840693          	addi	a3,s0,-56
    80200302:	4781                	li	a5,0
    do { buf[i++] = digits[x % base]; } while ((x /= base) != 0);
    80200304:	00008817          	auipc	a6,0x8
    80200308:	aac80813          	addi	a6,a6,-1364 # 80207db0 <digits>
    8020030c:	88be                	mv	a7,a5
    8020030e:	2785                	addiw	a5,a5,1
    80200310:	02b57733          	remu	a4,a0,a1
    80200314:	9742                	add	a4,a4,a6
    80200316:	00074703          	lbu	a4,0(a4)
    8020031a:	00e68023          	sb	a4,0(a3)
    8020031e:	872a                	mv	a4,a0
    80200320:	02b55533          	divu	a0,a0,a1
    80200324:	0685                	addi	a3,a3,1
    80200326:	feb773e3          	bgeu	a4,a1,8020030c <printint+0x1e>
    if (sign) buf[i++] = '-';
    8020032a:	ca09                	beqz	a2,8020033c <printint+0x4e>
    8020032c:	1781                	addi	a5,a5,-32
    8020032e:	97a2                	add	a5,a5,s0
    80200330:	02d00713          	li	a4,45
    80200334:	fee78423          	sb	a4,-24(a5)
    80200338:	0028879b          	addiw	a5,a7,2
    while (--i >= 0) putc(buf[i]);
    8020033c:	02f05b63          	blez	a5,80200372 <printint+0x84>
    80200340:	f426                	sd	s1,40(sp)
    80200342:	f04a                	sd	s2,32(sp)
    80200344:	fc840713          	addi	a4,s0,-56
    80200348:	00f704b3          	add	s1,a4,a5
    8020034c:	fff70913          	addi	s2,a4,-1
    80200350:	993e                	add	s2,s2,a5
    80200352:	37fd                	addiw	a5,a5,-1
    80200354:	1782                	slli	a5,a5,0x20
    80200356:	9381                	srli	a5,a5,0x20
    80200358:	40f90933          	sub	s2,s2,a5
    8020035c:	fff4c503          	lbu	a0,-1(s1)
    80200360:	00000097          	auipc	ra,0x0
    80200364:	f62080e7          	jalr	-158(ra) # 802002c2 <putc>
    80200368:	14fd                	addi	s1,s1,-1
    8020036a:	ff2499e3          	bne	s1,s2,8020035c <printint+0x6e>
    8020036e:	74a2                	ld	s1,40(sp)
    80200370:	7902                	ld	s2,32(sp)
}
    80200372:	70e2                	ld	ra,56(sp)
    80200374:	7442                	ld	s0,48(sp)
    80200376:	6121                	addi	sp,sp,64
    80200378:	8082                	ret
    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    8020037a:	40a00533          	neg	a0,a0
    8020037e:	b741                	j	802002fe <printint+0x10>

0000000080200380 <printf>:
    for (int i = 0; i < 16; i++, x <<= 4)
        putc(digits[x >> 60]);
}

void printf(const char *fmt, ...)
{
    80200380:	7171                	addi	sp,sp,-176
    80200382:	f486                	sd	ra,104(sp)
    80200384:	f0a2                	sd	s0,96(sp)
    80200386:	e0d2                	sd	s4,64(sp)
    80200388:	f062                	sd	s8,32(sp)
    8020038a:	1880                	addi	s0,sp,112
    8020038c:	8a2a                	mv	s4,a0
    8020038e:	e40c                	sd	a1,8(s0)
    80200390:	e810                	sd	a2,16(s0)
    80200392:	ec14                	sd	a3,24(s0)
    80200394:	f018                	sd	a4,32(s0)
    80200396:	f41c                	sd	a5,40(s0)
    80200398:	03043823          	sd	a6,48(s0)
    8020039c:	03143c23          	sd	a7,56(s0)
    va_list ap;
    int locking = pr_locking;
    802003a0:	0014ac17          	auipc	s8,0x14a
    802003a4:	c68c2c03          	lw	s8,-920(s8) # 8034a008 <pr_locking>
    if (locking) acquire(&pr_lock);
    802003a8:	020c1863          	bnez	s8,802003d8 <printf+0x58>

    va_start(ap, fmt);
    802003ac:	00840793          	addi	a5,s0,8
    802003b0:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003b4:	00054503          	lbu	a0,0(a0)
    802003b8:	1e050063          	beqz	a0,80200598 <printf+0x218>
    802003bc:	eca6                	sd	s1,88(sp)
    802003be:	e8ca                	sd	s2,80(sp)
    802003c0:	fc56                	sd	s5,56(sp)
    802003c2:	f85a                	sd	s6,48(sp)
    802003c4:	f45e                	sd	s7,40(sp)
    802003c6:	4481                	li	s1,0
        char c = fmt[i];
        if (c != '%') { putc(c); continue; }
    802003c8:	02500a93          	li	s5,37
        c = fmt[++i];
        if (!c) break;
        switch (c) {
    802003cc:	4b55                	li	s6,21
    802003ce:	00008b97          	auipc	s7,0x8
    802003d2:	98ab8b93          	addi	s7,s7,-1654 # 80207d58 <etext+0xd58>
    802003d6:	a825                	j	8020040e <printf+0x8e>
    if (locking) acquire(&pr_lock);
    802003d8:	00029517          	auipc	a0,0x29
    802003dc:	c2850513          	addi	a0,a0,-984 # 80229000 <pr_lock>
    802003e0:	00001097          	auipc	ra,0x1
    802003e4:	f48080e7          	jalr	-184(ra) # 80201328 <acquire>
    va_start(ap, fmt);
    802003e8:	00840793          	addi	a5,s0,8
    802003ec:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003f0:	000a4503          	lbu	a0,0(s4)
    802003f4:	f561                	bnez	a0,802003bc <printf+0x3c>
    802003f6:	aa65                	j	802005ae <printf+0x22e>
        if (c != '%') { putc(c); continue; }
    802003f8:	00000097          	auipc	ra,0x0
    802003fc:	eca080e7          	jalr	-310(ra) # 802002c2 <putc>
    for (int i = 0; fmt[i]; i++) {
    80200400:	2485                	addiw	s1,s1,1
    80200402:	009a07b3          	add	a5,s4,s1
    80200406:	0007c503          	lbu	a0,0(a5)
    8020040a:	18050063          	beqz	a0,8020058a <printf+0x20a>
        if (c != '%') { putc(c); continue; }
    8020040e:	ff5515e3          	bne	a0,s5,802003f8 <printf+0x78>
        c = fmt[++i];
    80200412:	2485                	addiw	s1,s1,1
    80200414:	009a07b3          	add	a5,s4,s1
    80200418:	0007c903          	lbu	s2,0(a5)
        if (!c) break;
    8020041c:	16090763          	beqz	s2,8020058a <printf+0x20a>
        switch (c) {
    80200420:	15590263          	beq	s2,s5,80200564 <printf+0x1e4>
    80200424:	f9d9079b          	addiw	a5,s2,-99
    80200428:	0ff7f793          	zext.b	a5,a5
    8020042c:	14fb6363          	bltu	s6,a5,80200572 <printf+0x1f2>
    80200430:	f9d9079b          	addiw	a5,s2,-99
    80200434:	0ff7f713          	zext.b	a4,a5
    80200438:	12eb6d63          	bltu	s6,a4,80200572 <printf+0x1f2>
    8020043c:	00271793          	slli	a5,a4,0x2
    80200440:	97de                	add	a5,a5,s7
    80200442:	439c                	lw	a5,0(a5)
    80200444:	97de                	add	a5,a5,s7
    80200446:	8782                	jr	a5
        case 'd': printint(va_arg(ap, int), 10, 1); break;
    80200448:	f9843783          	ld	a5,-104(s0)
    8020044c:	00878713          	addi	a4,a5,8
    80200450:	f8e43c23          	sd	a4,-104(s0)
    80200454:	4605                	li	a2,1
    80200456:	45a9                	li	a1,10
    80200458:	4388                	lw	a0,0(a5)
    8020045a:	00000097          	auipc	ra,0x0
    8020045e:	e94080e7          	jalr	-364(ra) # 802002ee <printint>
    80200462:	bf79                	j	80200400 <printf+0x80>
        case 'l': printint(va_arg(ap, uint64), 10, 0); break;
    80200464:	f9843783          	ld	a5,-104(s0)
    80200468:	00878713          	addi	a4,a5,8
    8020046c:	f8e43c23          	sd	a4,-104(s0)
    80200470:	4601                	li	a2,0
    80200472:	45a9                	li	a1,10
    80200474:	6388                	ld	a0,0(a5)
    80200476:	00000097          	auipc	ra,0x0
    8020047a:	e78080e7          	jalr	-392(ra) # 802002ee <printint>
    8020047e:	b749                	j	80200400 <printf+0x80>
        case 'u': printint(va_arg(ap, uint64), 10, 0); break;
    80200480:	f9843783          	ld	a5,-104(s0)
    80200484:	00878713          	addi	a4,a5,8
    80200488:	f8e43c23          	sd	a4,-104(s0)
    8020048c:	4601                	li	a2,0
    8020048e:	45a9                	li	a1,10
    80200490:	6388                	ld	a0,0(a5)
    80200492:	00000097          	auipc	ra,0x0
    80200496:	e5c080e7          	jalr	-420(ra) # 802002ee <printint>
    8020049a:	b79d                	j	80200400 <printf+0x80>
        case 'x': printint(va_arg(ap, uint64), 16, 0); break;
    8020049c:	f9843783          	ld	a5,-104(s0)
    802004a0:	00878713          	addi	a4,a5,8
    802004a4:	f8e43c23          	sd	a4,-104(s0)
    802004a8:	4601                	li	a2,0
    802004aa:	45c1                	li	a1,16
    802004ac:	6388                	ld	a0,0(a5)
    802004ae:	00000097          	auipc	ra,0x0
    802004b2:	e40080e7          	jalr	-448(ra) # 802002ee <printint>
    802004b6:	b7a9                	j	80200400 <printf+0x80>
    802004b8:	e4ce                	sd	s3,72(sp)
    802004ba:	ec66                	sd	s9,24(sp)
        case 'p': printptr(va_arg(ap, uint64)); break;
    802004bc:	f9843783          	ld	a5,-104(s0)
    802004c0:	00878713          	addi	a4,a5,8
    802004c4:	f8e43c23          	sd	a4,-104(s0)
    802004c8:	0007b983          	ld	s3,0(a5)
    putc('0'); putc('x');
    802004cc:	03000513          	li	a0,48
    802004d0:	00000097          	auipc	ra,0x0
    802004d4:	df2080e7          	jalr	-526(ra) # 802002c2 <putc>
    802004d8:	07800513          	li	a0,120
    802004dc:	00000097          	auipc	ra,0x0
    802004e0:	de6080e7          	jalr	-538(ra) # 802002c2 <putc>
    802004e4:	4941                	li	s2,16
        putc(digits[x >> 60]);
    802004e6:	00008c97          	auipc	s9,0x8
    802004ea:	8cac8c93          	addi	s9,s9,-1846 # 80207db0 <digits>
    802004ee:	03c9d793          	srli	a5,s3,0x3c
    802004f2:	97e6                	add	a5,a5,s9
    802004f4:	0007c503          	lbu	a0,0(a5)
    802004f8:	00000097          	auipc	ra,0x0
    802004fc:	dca080e7          	jalr	-566(ra) # 802002c2 <putc>
    for (int i = 0; i < 16; i++, x <<= 4)
    80200500:	0992                	slli	s3,s3,0x4
    80200502:	397d                	addiw	s2,s2,-1
    80200504:	fe0915e3          	bnez	s2,802004ee <printf+0x16e>
    80200508:	69a6                	ld	s3,72(sp)
    8020050a:	6ce2                	ld	s9,24(sp)
    8020050c:	bdd5                	j	80200400 <printf+0x80>
        case 'c': putc((char)va_arg(ap, int)); break;
    8020050e:	f9843783          	ld	a5,-104(s0)
    80200512:	00878713          	addi	a4,a5,8
    80200516:	f8e43c23          	sd	a4,-104(s0)
    8020051a:	0007c503          	lbu	a0,0(a5)
    8020051e:	00000097          	auipc	ra,0x0
    80200522:	da4080e7          	jalr	-604(ra) # 802002c2 <putc>
    80200526:	bde9                	j	80200400 <printf+0x80>
        case 's': {
            const char *s = va_arg(ap, const char *);
    80200528:	f9843783          	ld	a5,-104(s0)
    8020052c:	00878713          	addi	a4,a5,8
    80200530:	f8e43c23          	sd	a4,-104(s0)
    80200534:	0007b903          	ld	s2,0(a5)
            if (!s) s = "(null)";
    80200538:	00090f63          	beqz	s2,80200556 <printf+0x1d6>
            while (*s) putc(*s++);
    8020053c:	00094503          	lbu	a0,0(s2)
    80200540:	ec0500e3          	beqz	a0,80200400 <printf+0x80>
    80200544:	0905                	addi	s2,s2,1
    80200546:	00000097          	auipc	ra,0x0
    8020054a:	d7c080e7          	jalr	-644(ra) # 802002c2 <putc>
    8020054e:	00094503          	lbu	a0,0(s2)
    80200552:	f96d                	bnez	a0,80200544 <printf+0x1c4>
    80200554:	b575                	j	80200400 <printf+0x80>
            if (!s) s = "(null)";
    80200556:	00007917          	auipc	s2,0x7
    8020055a:	c3290913          	addi	s2,s2,-974 # 80207188 <etext+0x188>
            while (*s) putc(*s++);
    8020055e:	02800513          	li	a0,40
    80200562:	b7cd                	j	80200544 <printf+0x1c4>
            break;
        }
        case '%': putc('%'); break;
    80200564:	02500513          	li	a0,37
    80200568:	00000097          	auipc	ra,0x0
    8020056c:	d5a080e7          	jalr	-678(ra) # 802002c2 <putc>
    80200570:	bd41                	j	80200400 <printf+0x80>
        default:  putc('%'); putc(c); break;
    80200572:	02500513          	li	a0,37
    80200576:	00000097          	auipc	ra,0x0
    8020057a:	d4c080e7          	jalr	-692(ra) # 802002c2 <putc>
    8020057e:	854a                	mv	a0,s2
    80200580:	00000097          	auipc	ra,0x0
    80200584:	d42080e7          	jalr	-702(ra) # 802002c2 <putc>
    80200588:	bda5                	j	80200400 <printf+0x80>
        }
    }
    va_end(ap);
    if (locking) release(&pr_lock);
    8020058a:	000c1d63          	bnez	s8,802005a4 <printf+0x224>
    8020058e:	64e6                	ld	s1,88(sp)
    80200590:	6946                	ld	s2,80(sp)
    80200592:	7ae2                	ld	s5,56(sp)
    80200594:	7b42                	ld	s6,48(sp)
    80200596:	7ba2                	ld	s7,40(sp)
}
    80200598:	70a6                	ld	ra,104(sp)
    8020059a:	7406                	ld	s0,96(sp)
    8020059c:	6a06                	ld	s4,64(sp)
    8020059e:	7c02                	ld	s8,32(sp)
    802005a0:	614d                	addi	sp,sp,176
    802005a2:	8082                	ret
    802005a4:	64e6                	ld	s1,88(sp)
    802005a6:	6946                	ld	s2,80(sp)
    802005a8:	7ae2                	ld	s5,56(sp)
    802005aa:	7b42                	ld	s6,48(sp)
    802005ac:	7ba2                	ld	s7,40(sp)
    if (locking) release(&pr_lock);
    802005ae:	00029517          	auipc	a0,0x29
    802005b2:	a5250513          	addi	a0,a0,-1454 # 80229000 <pr_lock>
    802005b6:	00001097          	auipc	ra,0x1
    802005ba:	e26080e7          	jalr	-474(ra) # 802013dc <release>
}
    802005be:	bfe9                	j	80200598 <printf+0x218>

00000000802005c0 <printfinit>:

void printfinit(void) { initlock(&pr_lock, "pr"); pr_locking = 1; }
    802005c0:	1141                	addi	sp,sp,-16
    802005c2:	e406                	sd	ra,8(sp)
    802005c4:	e022                	sd	s0,0(sp)
    802005c6:	0800                	addi	s0,sp,16
    802005c8:	00007597          	auipc	a1,0x7
    802005cc:	bc858593          	addi	a1,a1,-1080 # 80207190 <etext+0x190>
    802005d0:	00029517          	auipc	a0,0x29
    802005d4:	a3050513          	addi	a0,a0,-1488 # 80229000 <pr_lock>
    802005d8:	00001097          	auipc	ra,0x1
    802005dc:	cd4080e7          	jalr	-812(ra) # 802012ac <initlock>
    802005e0:	4785                	li	a5,1
    802005e2:	0014a717          	auipc	a4,0x14a
    802005e6:	a2f72323          	sw	a5,-1498(a4) # 8034a008 <pr_locking>
    802005ea:	60a2                	ld	ra,8(sp)
    802005ec:	6402                	ld	s0,0(sp)
    802005ee:	0141                	addi	sp,sp,16
    802005f0:	8082                	ret

00000000802005f2 <panic>:

void panic(const char *s)
{
    802005f2:	1101                	addi	sp,sp,-32
    802005f4:	ec06                	sd	ra,24(sp)
    802005f6:	e822                	sd	s0,16(sp)
    802005f8:	e426                	sd	s1,8(sp)
    802005fa:	1000                	addi	s0,sp,32
    802005fc:	84aa                	mv	s1,a0
    pr_locking = 0;                       /* never deadlock inside a panic */
    802005fe:	0014a797          	auipc	a5,0x14a
    80200602:	a007a523          	sw	zero,-1526(a5) # 8034a008 <pr_locking>
    printf("\n=== KERNEL PANIC (hart %d) ===\n", hal_hart_id());
    80200606:	00006097          	auipc	ra,0x6
    8020060a:	1a8080e7          	jalr	424(ra) # 802067ae <hal_hart_id>
    8020060e:	85aa                	mv	a1,a0
    80200610:	00007517          	auipc	a0,0x7
    80200614:	b8850513          	addi	a0,a0,-1144 # 80207198 <etext+0x198>
    80200618:	00000097          	auipc	ra,0x0
    8020061c:	d68080e7          	jalr	-664(ra) # 80200380 <printf>
    printf("  %s\n", s);
    80200620:	85a6                	mv	a1,s1
    80200622:	00007517          	auipc	a0,0x7
    80200626:	b9e50513          	addi	a0,a0,-1122 # 802071c0 <etext+0x1c0>
    8020062a:	00000097          	auipc	ra,0x0
    8020062e:	d56080e7          	jalr	-682(ra) # 80200380 <printf>
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80200632:	141025f3          	csrr	a1,sepc
    printf("  sepc   = %p\n", r_sepc());
    80200636:	00007517          	auipc	a0,0x7
    8020063a:	b9250513          	addi	a0,a0,-1134 # 802071c8 <etext+0x1c8>
    8020063e:	00000097          	auipc	ra,0x0
    80200642:	d42080e7          	jalr	-702(ra) # 80200380 <printf>
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80200646:	142025f3          	csrr	a1,scause
    printf("  scause = %p\n", r_scause());
    8020064a:	00007517          	auipc	a0,0x7
    8020064e:	b8e50513          	addi	a0,a0,-1138 # 802071d8 <etext+0x1d8>
    80200652:	00000097          	auipc	ra,0x0
    80200656:	d2e080e7          	jalr	-722(ra) # 80200380 <printf>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    8020065a:	143025f3          	csrr	a1,stval
    printf("  stval  = %p\n", r_stval());
    8020065e:	00007517          	auipc	a0,0x7
    80200662:	b8a50513          	addi	a0,a0,-1142 # 802071e8 <etext+0x1e8>
    80200666:	00000097          	auipc	ra,0x0
    8020066a:	d1a080e7          	jalr	-742(ra) # 80200380 <printf>
static inline void   w_sscratch(uint64 x){ asm volatile("csrw sscratch, %0"::"r"(x)); }
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    8020066e:	180025f3          	csrr	a1,satp
    printf("  satp   = %p\n", r_satp());
    80200672:	00007517          	auipc	a0,0x7
    80200676:	b8650513          	addi	a0,a0,-1146 # 802071f8 <etext+0x1f8>
    8020067a:	00000097          	auipc	ra,0x0
    8020067e:	d06080e7          	jalr	-762(ra) # 80200380 <printf>
    printf("=============================\n");
    80200682:	00007517          	auipc	a0,0x7
    80200686:	b8650513          	addi	a0,a0,-1146 # 80207208 <etext+0x208>
    8020068a:	00000097          	auipc	ra,0x0
    8020068e:	cf6080e7          	jalr	-778(ra) # 80200380 <printf>
    for (;;) asm volatile("wfi");
    80200692:	10500073          	wfi
    80200696:	bff5                	j	80200692 <panic+0xa0>

0000000080200698 <memset>:
#include "types.h"
#include "defs.h"
void *memset(void *dst, int c, usize n){ char *d=dst; while(n--) *d++=(char)c; return dst; }
    80200698:	1141                	addi	sp,sp,-16
    8020069a:	e422                	sd	s0,8(sp)
    8020069c:	0800                	addi	s0,sp,16
    8020069e:	ca01                	beqz	a2,802006ae <memset+0x16>
    802006a0:	962a                	add	a2,a2,a0
    802006a2:	87aa                	mv	a5,a0
    802006a4:	0785                	addi	a5,a5,1
    802006a6:	feb78fa3          	sb	a1,-1(a5)
    802006aa:	fef61de3          	bne	a2,a5,802006a4 <memset+0xc>
    802006ae:	6422                	ld	s0,8(sp)
    802006b0:	0141                	addi	sp,sp,16
    802006b2:	8082                	ret

00000000802006b4 <memmove>:
void *memmove(void *dst, const void *src, usize n){
    802006b4:	1141                	addi	sp,sp,-16
    802006b6:	e422                	sd	s0,8(sp)
    802006b8:	0800                	addi	s0,sp,16
    char *d=dst; const char *s=src;
    if (d < s) { while(n--) *d++ = *s++; }
    802006ba:	02b57063          	bgeu	a0,a1,802006da <memmove+0x26>
    802006be:	ca19                	beqz	a2,802006d4 <memmove+0x20>
    802006c0:	962a                	add	a2,a2,a0
    char *d=dst; const char *s=src;
    802006c2:	87aa                	mv	a5,a0
    if (d < s) { while(n--) *d++ = *s++; }
    802006c4:	0585                	addi	a1,a1,1
    802006c6:	0785                	addi	a5,a5,1
    802006c8:	fff5c703          	lbu	a4,-1(a1)
    802006cc:	fee78fa3          	sb	a4,-1(a5)
    802006d0:	fef61ae3          	bne	a2,a5,802006c4 <memmove+0x10>
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    return dst;
}
    802006d4:	6422                	ld	s0,8(sp)
    802006d6:	0141                	addi	sp,sp,16
    802006d8:	8082                	ret
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    802006da:	00c507b3          	add	a5,a0,a2
    802006de:	95b2                	add	a1,a1,a2
    802006e0:	da75                	beqz	a2,802006d4 <memmove+0x20>
    802006e2:	15fd                	addi	a1,a1,-1
    802006e4:	17fd                	addi	a5,a5,-1
    802006e6:	0005c703          	lbu	a4,0(a1)
    802006ea:	00e78023          	sb	a4,0(a5)
    802006ee:	fef51ae3          	bne	a0,a5,802006e2 <memmove+0x2e>
    802006f2:	b7cd                	j	802006d4 <memmove+0x20>

00000000802006f4 <memcmp>:
int memcmp(const void *a, const void *b, usize n){
    802006f4:	1141                	addi	sp,sp,-16
    802006f6:	e422                	sd	s0,8(sp)
    802006f8:	0800                	addi	s0,sp,16
    const uint8 *x=a,*y=b;
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    802006fa:	c21d                	beqz	a2,80200720 <memcmp+0x2c>
    802006fc:	962a                	add	a2,a2,a0
    802006fe:	00054783          	lbu	a5,0(a0)
    80200702:	0005c703          	lbu	a4,0(a1)
    80200706:	00e79863          	bne	a5,a4,80200716 <memcmp+0x22>
    8020070a:	0505                	addi	a0,a0,1
    8020070c:	0585                	addi	a1,a1,1
    8020070e:	fea618e3          	bne	a2,a0,802006fe <memcmp+0xa>
    return 0;
    80200712:	4501                	li	a0,0
    80200714:	a019                	j	8020071a <memcmp+0x26>
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    80200716:	40e7853b          	subw	a0,a5,a4
}
    8020071a:	6422                	ld	s0,8(sp)
    8020071c:	0141                	addi	sp,sp,16
    8020071e:	8082                	ret
    return 0;
    80200720:	4501                	li	a0,0
    80200722:	bfe5                	j	8020071a <memcmp+0x26>

0000000080200724 <strncmp>:
int strncmp(const char *a, const char *b, usize n){
    80200724:	1141                	addi	sp,sp,-16
    80200726:	e422                	sd	s0,8(sp)
    80200728:	0800                	addi	s0,sp,16
    while(n > 0 && *a && *a == *b){ a++; b++; n--; }
    8020072a:	ce11                	beqz	a2,80200746 <strncmp+0x22>
    8020072c:	00054783          	lbu	a5,0(a0)
    80200730:	cf89                	beqz	a5,8020074a <strncmp+0x26>
    80200732:	0005c703          	lbu	a4,0(a1)
    80200736:	00f71a63          	bne	a4,a5,8020074a <strncmp+0x26>
    8020073a:	0505                	addi	a0,a0,1
    8020073c:	0585                	addi	a1,a1,1
    8020073e:	167d                	addi	a2,a2,-1
    80200740:	f675                	bnez	a2,8020072c <strncmp+0x8>
    if(n == 0) return 0;
    80200742:	4501                	li	a0,0
    80200744:	a801                	j	80200754 <strncmp+0x30>
    80200746:	4501                	li	a0,0
    80200748:	a031                	j	80200754 <strncmp+0x30>
    return (uint8)*a - (uint8)*b;
    8020074a:	00054503          	lbu	a0,0(a0)
    8020074e:	0005c783          	lbu	a5,0(a1)
    80200752:	9d1d                	subw	a0,a0,a5
}
    80200754:	6422                	ld	s0,8(sp)
    80200756:	0141                	addi	sp,sp,16
    80200758:	8082                	ret

000000008020075a <strncpy>:
char *strncpy(char *d, const char *s, int n){
    8020075a:	1141                	addi	sp,sp,-16
    8020075c:	e422                	sd	s0,8(sp)
    8020075e:	0800                	addi	s0,sp,16
    char *r=d;
    while(n-- > 0 && (*d++ = *s++) != 0) ;
    80200760:	87aa                	mv	a5,a0
    80200762:	86b2                	mv	a3,a2
    80200764:	367d                	addiw	a2,a2,-1
    80200766:	02d05563          	blez	a3,80200790 <strncpy+0x36>
    8020076a:	0785                	addi	a5,a5,1
    8020076c:	0005c703          	lbu	a4,0(a1)
    80200770:	fee78fa3          	sb	a4,-1(a5)
    80200774:	0585                	addi	a1,a1,1
    80200776:	f775                	bnez	a4,80200762 <strncpy+0x8>
    while(n-- > 0) *d++ = 0;
    80200778:	873e                	mv	a4,a5
    8020077a:	9fb5                	addw	a5,a5,a3
    8020077c:	37fd                	addiw	a5,a5,-1
    8020077e:	00c05963          	blez	a2,80200790 <strncpy+0x36>
    80200782:	0705                	addi	a4,a4,1
    80200784:	fe070fa3          	sb	zero,-1(a4)
    80200788:	40e786bb          	subw	a3,a5,a4
    8020078c:	fed04be3          	bgtz	a3,80200782 <strncpy+0x28>
    return r;
}
    80200790:	6422                	ld	s0,8(sp)
    80200792:	0141                	addi	sp,sp,16
    80200794:	8082                	ret

0000000080200796 <strlen>:
int strlen(const char *s){ int n=0; while(s[n]) n++; return n; }
    80200796:	1141                	addi	sp,sp,-16
    80200798:	e422                	sd	s0,8(sp)
    8020079a:	0800                	addi	s0,sp,16
    8020079c:	00054783          	lbu	a5,0(a0)
    802007a0:	cf91                	beqz	a5,802007bc <strlen+0x26>
    802007a2:	0505                	addi	a0,a0,1
    802007a4:	87aa                	mv	a5,a0
    802007a6:	86be                	mv	a3,a5
    802007a8:	0785                	addi	a5,a5,1
    802007aa:	fff7c703          	lbu	a4,-1(a5)
    802007ae:	ff65                	bnez	a4,802007a6 <strlen+0x10>
    802007b0:	40a6853b          	subw	a0,a3,a0
    802007b4:	2505                	addiw	a0,a0,1
    802007b6:	6422                	ld	s0,8(sp)
    802007b8:	0141                	addi	sp,sp,16
    802007ba:	8082                	ret
    802007bc:	4501                	li	a0,0
    802007be:	bfe5                	j	802007b6 <strlen+0x20>

00000000802007c0 <sbi_putchar>:
 * NOTE: the LEGACY console extension (EID 0x01) is deprecated and is disabled
 * in recent OpenSBI. Use DBCN (Debug Console, EID 0x4442434E) and fall back to
 * legacy only if DBCN is unavailable. Students hit this: an early sbi_putchar
 * that silently does nothing makes a boot panic invisible. */
void sbi_putchar(int c)
{
    802007c0:	1141                	addi	sp,sp,-16
    802007c2:	e422                	sd	s0,8(sp)
    802007c4:	0800                	addi	s0,sp,16
    802007c6:	87aa                	mv	a5,a0
    unsigned char ch = (unsigned char)c;
    /* DBCN console_write_byte = EID 0x4442434E, FID 2 */
    struct sbiret r = sbi_call(0x4442434E, 2, ch, 0, 0);
    802007c8:	0ff57513          	zext.b	a0,a0
    register long r_a1 asm("a1") = a1;
    802007cc:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    802007ce:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    802007d0:	4809                	li	a6,2
    register long r_a7 asm("a7") = eid;
    802007d2:	444248b7          	lui	a7,0x44424
    802007d6:	34e88893          	addi	a7,a7,846 # 4442434e <_entry-0x3bddbcb2>
    asm volatile ("ecall"
    802007da:	00000073          	ecall
    if (r.error != 0)
    802007de:	e501                	bnez	a0,802007e6 <sbi_putchar+0x26>
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
}
    802007e0:	6422                	ld	s0,8(sp)
    802007e2:	0141                	addi	sp,sp,16
    802007e4:	8082                	ret
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
    802007e6:	853e                	mv	a0,a5
    register long r_a1 asm("a1") = a1;
    802007e8:	4581                	li	a1,0
    register long r_a6 asm("a6") = fid;
    802007ea:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    802007ec:	4885                	li	a7,1
    asm volatile ("ecall"
    802007ee:	00000073          	ecall
}
    802007f2:	b7fd                	j	802007e0 <sbi_putchar+0x20>

00000000802007f4 <sbi_set_timer>:

/* TIME extension: set the next timer interrupt (absolute time). */
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    802007f4:	1141                	addi	sp,sp,-16
    802007f6:	e422                	sd	s0,8(sp)
    802007f8:	0800                	addi	s0,sp,16
    register long r_a1 asm("a1") = a1;
    802007fa:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    802007fc:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    802007fe:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    80200800:	544958b7          	lui	a7,0x54495
    80200804:	d4588893          	addi	a7,a7,-699 # 54494d45 <_entry-0x2bd6b2bb>
    asm volatile ("ecall"
    80200808:	00000073          	ecall
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    8020080c:	6422                	ld	s0,8(sp)
    8020080e:	0141                	addi	sp,sp,16
    80200810:	8082                	ret

0000000080200812 <sbi_hart_start>:

/* HSM extension: start a secondary hart at `addr` (L9, SMP). */
long sbi_hart_start(uint64 hartid, uint64 addr, uint64 opaque)
{
    80200812:	1141                	addi	sp,sp,-16
    80200814:	e422                	sd	s0,8(sp)
    80200816:	0800                	addi	s0,sp,16
    register long r_a6 asm("a6") = fid;
    80200818:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    8020081a:	004858b7          	lui	a7,0x485
    8020081e:	34d88893          	addi	a7,a7,845 # 48534d <_entry-0x7fd7acb3>
    asm volatile ("ecall"
    80200822:	00000073          	ecall
    return sbi_call(0x48534D, 0, hartid, addr, opaque).error;
}
    80200826:	6422                	ld	s0,8(sp)
    80200828:	0141                	addi	sp,sp,16
    8020082a:	8082                	ret

000000008020082c <be32>:
    uint32 off_mem_rsvmap, version, last_comp_version;
    uint32 boot_cpuid_phys, size_dt_strings, size_dt_struct;
};

/* The FDT is big-endian; RISC-V is little-endian. Swap on every read. */
static uint32 be32(uint32 x) {
    8020082c:	1141                	addi	sp,sp,-16
    8020082e:	e422                	sd	s0,8(sp)
    80200830:	0800                	addi	s0,sp,16
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    80200832:	0185179b          	slliw	a5,a0,0x18
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    80200836:	0185571b          	srliw	a4,a0,0x18
    8020083a:	8fd9                	or	a5,a5,a4
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    8020083c:	0085171b          	slliw	a4,a0,0x8
    80200840:	00ff06b7          	lui	a3,0xff0
    80200844:	8f75                	and	a4,a4,a3
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    80200846:	8fd9                	or	a5,a5,a4
    80200848:	0085551b          	srliw	a0,a0,0x8
    8020084c:	6741                	lui	a4,0x10
    8020084e:	f0070713          	addi	a4,a4,-256 # ff00 <_entry-0x801f0100>
    80200852:	8d79                	and	a0,a0,a4
    80200854:	8d5d                	or	a0,a0,a5
}
    80200856:	2501                	sext.w	a0,a0
    80200858:	6422                	ld	s0,8(sp)
    8020085a:	0141                	addi	sp,sp,16
    8020085c:	8082                	ret

000000008020085e <streq>:
#define MAXDEPTH 16

struct fdt_info fdt;                 /* what we discovered about this board */
static const char *strings;          /* strings block base */

static int streq(const char *a, const char *b) {
    8020085e:	1141                	addi	sp,sp,-16
    80200860:	e422                	sd	s0,8(sp)
    80200862:	0800                	addi	s0,sp,16
    while (*a && *a == *b) { a++; b++; }
    80200864:	00054783          	lbu	a5,0(a0)
    80200868:	cb91                	beqz	a5,8020087c <streq+0x1e>
    8020086a:	0005c703          	lbu	a4,0(a1)
    8020086e:	00f71763          	bne	a4,a5,8020087c <streq+0x1e>
    80200872:	0505                	addi	a0,a0,1
    80200874:	0585                	addi	a1,a1,1
    80200876:	00054783          	lbu	a5,0(a0)
    8020087a:	fbe5                	bnez	a5,8020086a <streq+0xc>
    return *a == *b;
    8020087c:	0005c503          	lbu	a0,0(a1)
    80200880:	8d1d                	sub	a0,a0,a5
}
    80200882:	00153513          	seqz	a0,a0
    80200886:	6422                	ld	s0,8(sp)
    80200888:	0141                	addi	sp,sp,16
    8020088a:	8082                	ret

000000008020088c <strlist_has>:
/* does `list` (a NUL-separated string list of length len) contain `want`? */
static int strlist_has(const char *list, int len, const char *want) {
    int i = 0;
    while (i < len) {
    8020088c:	04b05f63          	blez	a1,802008ea <strlist_has+0x5e>
static int strlist_has(const char *list, int len, const char *want) {
    80200890:	7139                	addi	sp,sp,-64
    80200892:	fc06                	sd	ra,56(sp)
    80200894:	f822                	sd	s0,48(sp)
    80200896:	f426                	sd	s1,40(sp)
    80200898:	f04a                	sd	s2,32(sp)
    8020089a:	ec4e                	sd	s3,24(sp)
    8020089c:	e852                	sd	s4,16(sp)
    8020089e:	e456                	sd	s5,8(sp)
    802008a0:	0080                	addi	s0,sp,64
    802008a2:	8a2a                	mv	s4,a0
    802008a4:	89ae                	mv	s3,a1
    802008a6:	8ab2                	mv	s5,a2
    int i = 0;
    802008a8:	4481                	li	s1,0
    802008aa:	a021                	j	802008b2 <strlist_has+0x26>
        if (streq(&list[i], want)) return 1;
        while (i < len && list[i]) i++;
        i++;
    802008ac:	2485                	addiw	s1,s1,1
    while (i < len) {
    802008ae:	0334d563          	bge	s1,s3,802008d8 <strlist_has+0x4c>
        if (streq(&list[i], want)) return 1;
    802008b2:	009a0933          	add	s2,s4,s1
    802008b6:	85d6                	mv	a1,s5
    802008b8:	854a                	mv	a0,s2
    802008ba:	00000097          	auipc	ra,0x0
    802008be:	fa4080e7          	jalr	-92(ra) # 8020085e <streq>
    802008c2:	e515                	bnez	a0,802008ee <strlist_has+0x62>
        while (i < len && list[i]) i++;
    802008c4:	ff34d4e3          	bge	s1,s3,802008ac <strlist_has+0x20>
    802008c8:	87ca                	mv	a5,s2
    802008ca:	0007c703          	lbu	a4,0(a5)
    802008ce:	df79                	beqz	a4,802008ac <strlist_has+0x20>
    802008d0:	2485                	addiw	s1,s1,1
    802008d2:	0785                	addi	a5,a5,1
    802008d4:	fe999be3          	bne	s3,s1,802008ca <strlist_has+0x3e>
    }
    return 0;
}
    802008d8:	70e2                	ld	ra,56(sp)
    802008da:	7442                	ld	s0,48(sp)
    802008dc:	74a2                	ld	s1,40(sp)
    802008de:	7902                	ld	s2,32(sp)
    802008e0:	69e2                	ld	s3,24(sp)
    802008e2:	6a42                	ld	s4,16(sp)
    802008e4:	6aa2                	ld	s5,8(sp)
    802008e6:	6121                	addi	sp,sp,64
    802008e8:	8082                	ret
    return 0;
    802008ea:	4501                	li	a0,0
}
    802008ec:	8082                	ret
        if (streq(&list[i], want)) return 1;
    802008ee:	4505                	li	a0,1
    802008f0:	b7e5                	j	802008d8 <strlist_has+0x4c>

00000000802008f2 <fdt_init>:
 *
 * Also: a node's `reg` is decoded with its PARENT's #address-cells/#size-cells,
 * not its own. We keep a small stack of them.
 */
void fdt_init(uint64 fdt_pa)
{
    802008f2:	712d                	addi	sp,sp,-288
    802008f4:	ee06                	sd	ra,280(sp)
    802008f6:	ea22                	sd	s0,272(sp)
    802008f8:	fdce                	sd	s3,248(sp)
    802008fa:	1200                	addi	s0,sp,288
    802008fc:	89aa                	mv	s3,a0
    struct fdt_header *h = (struct fdt_header *)fdt_pa;

    if (be32(h->magic) != FDT_MAGIC)
    802008fe:	4108                	lw	a0,0(a0)
    80200900:	00000097          	auipc	ra,0x0
    80200904:	f2c080e7          	jalr	-212(ra) # 8020082c <be32>
    80200908:	2501                	sext.w	a0,a0
    8020090a:	d00e07b7          	lui	a5,0xd00e0
    8020090e:	eed78793          	addi	a5,a5,-275 # ffffffffd00dfeed <uart+0xffffffff4fd95ebd>
    80200912:	0cf51263          	bne	a0,a5,802009d6 <fdt_init+0xe4>
    80200916:	e626                	sd	s1,264(sp)
    80200918:	e24a                	sd	s2,256(sp)
    8020091a:	f9d2                	sd	s4,240(sp)
    8020091c:	f5d6                	sd	s5,232(sp)
    8020091e:	f1da                	sd	s6,224(sp)
    80200920:	edde                	sd	s7,216(sp)
    80200922:	e9e2                	sd	s8,208(sp)
    80200924:	e1ea                	sd	s10,192(sp)
        panic("fdt: bad magic - is a1 really the device tree?");

    strings = (const char *)(fdt_pa + be32(h->off_dt_strings));
    80200926:	00c9a503          	lw	a0,12(s3)
    8020092a:	00000097          	auipc	ra,0x0
    8020092e:	f02080e7          	jalr	-254(ra) # 8020082c <be32>
    80200932:	02051b13          	slli	s6,a0,0x20
    80200936:	020b5b13          	srli	s6,s6,0x20
    8020093a:	9b4e                	add	s6,s6,s3
    const uint32 *p = (const uint32 *)(fdt_pa + be32(h->off_dt_struct));
    8020093c:	0089a503          	lw	a0,8(s3)
    80200940:	00000097          	auipc	ra,0x0
    80200944:	eec080e7          	jalr	-276(ra) # 8020082c <be32>
    80200948:	02051493          	slli	s1,a0,0x20
    8020094c:	9081                	srli	s1,s1,0x20
    8020094e:	94ce                	add	s1,s1,s3

    fdt.blob = fdt_pa;
    80200950:	00028917          	auipc	s2,0x28
    80200954:	6c890913          	addi	s2,s2,1736 # 80229018 <fdt>
    80200958:	01393023          	sd	s3,0(s2)
    fdt.blob_size = be32(h->totalsize);
    8020095c:	0049a503          	lw	a0,4(s3)
    80200960:	00000097          	auipc	ra,0x0
    80200964:	ecc080e7          	jalr	-308(ra) # 8020082c <be32>
    80200968:	1502                	slli	a0,a0,0x20
    8020096a:	9101                	srli	a0,a0,0x20
    8020096c:	00a93423          	sd	a0,8(s2)
    fdt.ncpu = 0;
    80200970:	0a092023          	sw	zero,160(s2)
    fdt.uart_base = 0; fdt.plic_base = 0; fdt.uart_irq = 0;
    80200974:	00093823          	sd	zero,16(s2)
    80200978:	00093c23          	sd	zero,24(s2)
    8020097c:	02092023          	sw	zero,32(s2)
    fdt.nvirtio = 0;
    80200980:	08092423          	sw	zero,136(s2)
    fdt.mem_base = 0;  fdt.mem_size = 0;
    80200984:	08093823          	sd	zero,144(s2)
    80200988:	08093c23          	sd	zero,152(s2)

    /* #address-cells / #size-cells, one slot per depth. Defaults per spec. */
    int ac[MAXDEPTH], sc[MAXDEPTH];
    ac[0] = 2; sc[0] = 2;
    8020098c:	4789                	li	a5,2
    8020098e:	f4f42823          	sw	a5,-176(s0)
    80200992:	f0f42823          	sw	a5,-240(s0)

    /* properties buffered for the node we are currently inside */
    int    kind = PEND_NONE;
    int    have_reg = 0;
    uint64 reg_base = 0, reg_size = 0;
    int    have_irq = 0, irq = 0;
    80200996:	ee043423          	sd	zero,-280(s0)
    8020099a:	ee043823          	sd	zero,-272(s0)
    uint64 reg_base = 0, reg_size = 0;
    8020099e:	f0043023          	sd	zero,-256(s0)
    802009a2:	f0043423          	sd	zero,-248(s0)
    int    have_reg = 0;
    802009a6:	4d01                	li	s10,0
    int    kind = PEND_NONE;
    802009a8:	4c01                	li	s8,0
    int cpus_depth = -1;
    802009aa:	5bfd                	li	s7,-1
    int depth = 0;
    802009ac:	4981                	li	s3,0
    802009ae:	4aa5                	li	s5,9
    802009b0:	00007917          	auipc	s2,0x7
    802009b4:	41490913          	addi	s2,s2,1044 # 80207dc4 <digits+0x14>

    for (;;) {
        uint32 tok = be32(*p++);
    802009b8:	00448a13          	addi	s4,s1,4
    802009bc:	4088                	lw	a0,0(s1)
    802009be:	00000097          	auipc	ra,0x0
    802009c2:	e6e080e7          	jalr	-402(ra) # 8020082c <be32>
    802009c6:	2501                	sext.w	a0,a0

        if (tok == FDT_END) break;
    802009c8:	4eaaee63          	bltu	s5,a0,80200ec4 <fdt_init+0x5d2>
    802009cc:	050a                	slli	a0,a0,0x2
    802009ce:	954a                	add	a0,a0,s2
    802009d0:	411c                	lw	a5,0(a0)
    802009d2:	97ca                	add	a5,a5,s2
    802009d4:	8782                	jr	a5
    802009d6:	e626                	sd	s1,264(sp)
    802009d8:	e24a                	sd	s2,256(sp)
    802009da:	f9d2                	sd	s4,240(sp)
    802009dc:	f5d6                	sd	s5,232(sp)
    802009de:	f1da                	sd	s6,224(sp)
    802009e0:	edde                	sd	s7,216(sp)
    802009e2:	e9e2                	sd	s8,208(sp)
    802009e4:	e5e6                	sd	s9,200(sp)
    802009e6:	e1ea                	sd	s10,192(sp)
    802009e8:	fd6e                	sd	s11,184(sp)
        panic("fdt: bad magic - is a1 really the device tree?");
    802009ea:	00007517          	auipc	a0,0x7
    802009ee:	84650513          	addi	a0,a0,-1978 # 80207230 <etext+0x230>
    802009f2:	00000097          	auipc	ra,0x0
    802009f6:	c00080e7          	jalr	-1024(ra) # 802005f2 <panic>
        uint32 tok = be32(*p++);
    802009fa:	84d2                	mv	s1,s4
    802009fc:	bf75                	j	802009b8 <fdt_init+0xc6>
        if (tok == FDT_BEGIN_NODE) {
            const char *name = (const char *)p;
            int len = 0; while (name[len]) len++;
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */

            depth++;
    802009fe:	89e2                	mv	s3,s8
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
            sc[depth] = sc[depth - 1];

            /* start a fresh property buffer for this node */
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
            have_irq = 0; irq = 0;
    80200a00:	ee043423          	sd	zero,-280(s0)
    80200a04:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200a08:	f0043023          	sd	zero,-256(s0)
    80200a0c:	f0043423          	sd	zero,-248(s0)
    80200a10:	4d01                	li	s10,0
    80200a12:	4c01                	li	s8,0
    80200a14:	b755                	j	802009b8 <fdt_init+0xc6>
        if (tok == FDT_PROP) {
            uint32 len     = be32(*p++);
            uint32 nameoff = be32(*p++);
            const char *pname = &strings[nameoff];
            const uint32 *val = p;
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a16:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
                else if (strlist_has(c, len, "riscv,plic0") ||
                         strlist_has(c, len, "sifive,plic-1.0.0"))
                    kind = PEND_PLIC;
                else if (strlist_has(c, len, "virtio,mmio"))
                    kind = PEND_VIRTIO;
    80200a1a:	4c0d                	li	s8,3
    80200a1c:	6cae                	ld	s9,200(sp)
    80200a1e:	7dea                	ld	s11,184(sp)
    80200a20:	bf61                	j	802009b8 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a22:	ef843483          	ld	s1,-264(s0)
            } else if (streq(pname, "device_type")) {
                if (strlist_has((const char *)val, len, "memory"))
                    kind = PEND_MEM;
    80200a26:	4c11                	li	s8,4
    80200a28:	6cae                	ld	s9,200(sp)
    80200a2a:	7dea                	ld	s11,184(sp)
    80200a2c:	b771                	j	802009b8 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a2e:	ef843483          	ld	s1,-264(s0)
    80200a32:	6cae                	ld	s9,200(sp)
    80200a34:	7dea                	ld	s11,184(sp)
    80200a36:	b749                	j	802009b8 <fdt_init+0xc6>
    80200a38:	ef843483          	ld	s1,-264(s0)
    80200a3c:	6cae                	ld	s9,200(sp)
    80200a3e:	7dea                	ld	s11,184(sp)
    80200a40:	bfa5                	j	802009b8 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200a42:	0044c783          	lbu	a5,4(s1)
    80200a46:	c7d9                	beqz	a5,80200ad4 <fdt_init+0x1e2>
    80200a48:	0495                	addi	s1,s1,5
    80200a4a:	87a6                	mv	a5,s1
    80200a4c:	86be                	mv	a3,a5
    80200a4e:	0785                	addi	a5,a5,1
    80200a50:	fff7c703          	lbu	a4,-1(a5)
    80200a54:	ff65                	bnez	a4,80200a4c <fdt_init+0x15a>
    80200a56:	9e85                	subw	a3,a3,s1
    80200a58:	2685                	addiw	a3,a3,1 # ff0001 <_entry-0x7f20ffff>
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */
    80200a5a:	2691                	addiw	a3,a3,4
    80200a5c:	41f6d49b          	sraiw	s1,a3,0x1f
    80200a60:	01e4d49b          	srliw	s1,s1,0x1e
    80200a64:	9cb5                	addw	s1,s1,a3
    80200a66:	4024d49b          	sraiw	s1,s1,0x2
    80200a6a:	048a                	slli	s1,s1,0x2
    80200a6c:	94d2                	add	s1,s1,s4
            depth++;
    80200a6e:	00198c1b          	addiw	s8,s3,1
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200a72:	47bd                	li	a5,15
    80200a74:	0787c263          	blt	a5,s8,80200ad8 <fdt_init+0x1e6>
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
    80200a78:	00299713          	slli	a4,s3,0x2
    80200a7c:	f9070793          	addi	a5,a4,-112
    80200a80:	00878733          	add	a4,a5,s0
    80200a84:	fc072683          	lw	a3,-64(a4)
    80200a88:	002c1793          	slli	a5,s8,0x2
    80200a8c:	f9078793          	addi	a5,a5,-112
    80200a90:	97a2                	add	a5,a5,s0
    80200a92:	fcd7a023          	sw	a3,-64(a5)
            sc[depth] = sc[depth - 1];
    80200a96:	f8072703          	lw	a4,-128(a4)
    80200a9a:	f8e7a023          	sw	a4,-128(a5)
            if (streq(name, "cpus")) cpus_depth = depth;
    80200a9e:	00006597          	auipc	a1,0x6
    80200aa2:	7da58593          	addi	a1,a1,2010 # 80207278 <etext+0x278>
    80200aa6:	8552                	mv	a0,s4
    80200aa8:	00000097          	auipc	ra,0x0
    80200aac:	db6080e7          	jalr	-586(ra) # 8020085e <streq>
    80200ab0:	c111                	beqz	a0,80200ab4 <fdt_init+0x1c2>
    80200ab2:	8be2                	mv	s7,s8
            if (cpus_depth > 0 && depth == cpus_depth + 1 && startswith(name, "cpu@"))
    80200ab4:	f57055e3          	blez	s7,802009fe <fdt_init+0x10c>
    80200ab8:	03798a63          	beq	s3,s7,80200aec <fdt_init+0x1fa>
            depth++;
    80200abc:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200abe:	ee043423          	sd	zero,-280(s0)
    80200ac2:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200ac6:	f0043023          	sd	zero,-256(s0)
    80200aca:	f0043423          	sd	zero,-248(s0)
    80200ace:	4d01                	li	s10,0
    80200ad0:	4c01                	li	s8,0
    80200ad2:	b5dd                	j	802009b8 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200ad4:	4681                	li	a3,0
    80200ad6:	b751                	j	80200a5a <fdt_init+0x168>
    80200ad8:	e5e6                	sd	s9,200(sp)
    80200ada:	fd6e                	sd	s11,184(sp)
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200adc:	00006517          	auipc	a0,0x6
    80200ae0:	78450513          	addi	a0,a0,1924 # 80207260 <etext+0x260>
    80200ae4:	00000097          	auipc	ra,0x0
    80200ae8:	b0e080e7          	jalr	-1266(ra) # 802005f2 <panic>
    80200aec:	00006797          	auipc	a5,0x6
    80200af0:	73c78793          	addi	a5,a5,1852 # 80207228 <etext+0x228>
    while (*pre) { if (*s++ != *pre++) return 0; }
    80200af4:	0007c703          	lbu	a4,0(a5)
    80200af8:	44070e63          	beqz	a4,80200f54 <fdt_init+0x662>
    80200afc:	0a05                	addi	s4,s4,1
    80200afe:	0785                	addi	a5,a5,1
    80200b00:	fffa4683          	lbu	a3,-1(s4)
    80200b04:	fee688e3          	beq	a3,a4,80200af4 <fdt_init+0x202>
            depth++;
    80200b08:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200b0a:	ee043423          	sd	zero,-280(s0)
    80200b0e:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200b12:	f0043023          	sd	zero,-256(s0)
    80200b16:	f0043423          	sd	zero,-248(s0)
    80200b1a:	4d01                	li	s10,0
    80200b1c:	4c01                	li	s8,0
    80200b1e:	bd69                	j	802009b8 <fdt_init+0xc6>
            if (have_reg && kind != PEND_NONE) {
    80200b20:	040d0863          	beqz	s10,80200b70 <fdt_init+0x27e>
    80200b24:	040c0663          	beqz	s8,80200b70 <fdt_init+0x27e>
                switch (kind) {
    80200b28:	478d                	li	a5,3
    80200b2a:	06fc0f63          	beq	s8,a5,80200ba8 <fdt_init+0x2b6>
    80200b2e:	0387c463          	blt	a5,s8,80200b56 <fdt_init+0x264>
    80200b32:	4785                	li	a5,1
    80200b34:	04fc0563          	beq	s8,a5,80200b7e <fdt_init+0x28c>
    80200b38:	4789                	li	a5,2
    80200b3a:	02fc1b63          	bne	s8,a5,80200b70 <fdt_init+0x27e>
                case PEND_PLIC:   if (!fdt.plic_base) fdt.plic_base = reg_base; break;
    80200b3e:	00028797          	auipc	a5,0x28
    80200b42:	4f27b783          	ld	a5,1266(a5) # 80229030 <fdt+0x18>
    80200b46:	e78d                	bnez	a5,80200b70 <fdt_init+0x27e>
    80200b48:	f0843703          	ld	a4,-248(s0)
    80200b4c:	00028797          	auipc	a5,0x28
    80200b50:	4ee7b223          	sd	a4,1252(a5) # 80229030 <fdt+0x18>
    80200b54:	a831                	j	80200b70 <fdt_init+0x27e>
                switch (kind) {
    80200b56:	4791                	li	a5,4
    80200b58:	00fc1c63          	bne	s8,a5,80200b70 <fdt_init+0x27e>
                case PEND_MEM:    fdt.mem_base = reg_base; fdt.mem_size = reg_size; break;
    80200b5c:	00028797          	auipc	a5,0x28
    80200b60:	4bc78793          	addi	a5,a5,1212 # 80229018 <fdt>
    80200b64:	f0843703          	ld	a4,-248(s0)
    80200b68:	ebd8                	sd	a4,144(a5)
    80200b6a:	f0043703          	ld	a4,-256(s0)
    80200b6e:	efd8                	sd	a4,152(a5)
            if (depth == cpus_depth) cpus_depth = -1;
    80200b70:	09798163          	beq	s3,s7,80200bf2 <fdt_init+0x300>
            depth--;
    80200b74:	39fd                	addiw	s3,s3,-1
        uint32 tok = be32(*p++);
    80200b76:	84d2                	mv	s1,s4
            kind = PEND_NONE; have_reg = 0;
    80200b78:	4d01                	li	s10,0
    80200b7a:	4c01                	li	s8,0
            continue;
    80200b7c:	bd35                	j	802009b8 <fdt_init+0xc6>
                    if (!fdt.uart_base) {
    80200b7e:	00028797          	auipc	a5,0x28
    80200b82:	4aa7b783          	ld	a5,1194(a5) # 80229028 <fdt+0x10>
    80200b86:	f7ed                	bnez	a5,80200b70 <fdt_init+0x27e>
                        fdt.uart_base = reg_base;
    80200b88:	f0843703          	ld	a4,-248(s0)
    80200b8c:	00028797          	auipc	a5,0x28
    80200b90:	48e7be23          	sd	a4,1180(a5) # 80229028 <fdt+0x10>
                        if (have_irq) fdt.uart_irq = irq;
    80200b94:	ef043783          	ld	a5,-272(s0)
    80200b98:	dfe1                	beqz	a5,80200b70 <fdt_init+0x27e>
    80200b9a:	ee843703          	ld	a4,-280(s0)
    80200b9e:	00028797          	auipc	a5,0x28
    80200ba2:	48e7ad23          	sw	a4,1178(a5) # 80229038 <fdt+0x20>
    80200ba6:	b7e9                	j	80200b70 <fdt_init+0x27e>
                    if (fdt.nvirtio < FDT_MAX_VIRTIO) {
    80200ba8:	00028797          	auipc	a5,0x28
    80200bac:	4f87a783          	lw	a5,1272(a5) # 802290a0 <fdt+0x88>
    80200bb0:	471d                	li	a4,7
    80200bb2:	faf74fe3          	blt	a4,a5,80200b70 <fdt_init+0x27e>
                        fdt.virtio_base[fdt.nvirtio] = reg_base;
    80200bb6:	00478693          	addi	a3,a5,4
    80200bba:	068e                	slli	a3,a3,0x3
    80200bbc:	00028717          	auipc	a4,0x28
    80200bc0:	45c70713          	addi	a4,a4,1116 # 80229018 <fdt>
    80200bc4:	9736                	add	a4,a4,a3
    80200bc6:	f0843683          	ld	a3,-248(s0)
    80200bca:	e714                	sd	a3,8(a4)
                        fdt.virtio_irq[fdt.nvirtio]  = have_irq ? irq : 0;
    80200bcc:	ef043703          	ld	a4,-272(s0)
    80200bd0:	863a                	mv	a2,a4
    80200bd2:	c319                	beqz	a4,80200bd8 <fdt_init+0x2e6>
    80200bd4:	ee843603          	ld	a2,-280(s0)
    80200bd8:	00028697          	auipc	a3,0x28
    80200bdc:	44068693          	addi	a3,a3,1088 # 80229018 <fdt>
    80200be0:	01878713          	addi	a4,a5,24
    80200be4:	070a                	slli	a4,a4,0x2
    80200be6:	9736                	add	a4,a4,a3
    80200be8:	c710                	sw	a2,8(a4)
                        fdt.nvirtio++;
    80200bea:	2785                	addiw	a5,a5,1
    80200bec:	08f6a423          	sw	a5,136(a3)
    80200bf0:	b741                	j	80200b70 <fdt_init+0x27e>
            if (depth == cpus_depth) cpus_depth = -1;
    80200bf2:	5bfd                	li	s7,-1
    80200bf4:	b741                	j	80200b74 <fdt_init+0x282>
    80200bf6:	e5e6                	sd	s9,200(sp)
    80200bf8:	fd6e                	sd	s11,184(sp)
            uint32 len     = be32(*p++);
    80200bfa:	40c8                	lw	a0,4(s1)
    80200bfc:	00000097          	auipc	ra,0x0
    80200c00:	c30080e7          	jalr	-976(ra) # 8020082c <be32>
    80200c04:	00050c9b          	sext.w	s9,a0
            uint32 nameoff = be32(*p++);
    80200c08:	00c48d93          	addi	s11,s1,12
    80200c0c:	4488                	lw	a0,8(s1)
    80200c0e:	00000097          	auipc	ra,0x0
    80200c12:	c1e080e7          	jalr	-994(ra) # 8020082c <be32>
            const char *pname = &strings[nameoff];
    80200c16:	02051a13          	slli	s4,a0,0x20
    80200c1a:	020a5a13          	srli	s4,s4,0x20
    80200c1e:	9a5a                	add	s4,s4,s6
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c20:	003c879b          	addiw	a5,s9,3
    80200c24:	0027d79b          	srliw	a5,a5,0x2
    80200c28:	078a                	slli	a5,a5,0x2
    80200c2a:	97ee                	add	a5,a5,s11
    80200c2c:	eef43c23          	sd	a5,-264(s0)
            if (streq(pname, "#address-cells")) {
    80200c30:	00006597          	auipc	a1,0x6
    80200c34:	65058593          	addi	a1,a1,1616 # 80207280 <etext+0x280>
    80200c38:	8552                	mv	a0,s4
    80200c3a:	00000097          	auipc	ra,0x0
    80200c3e:	c24080e7          	jalr	-988(ra) # 8020085e <streq>
    80200c42:	c11d                	beqz	a0,80200c68 <fdt_init+0x376>
                ac[depth] = be32(val[0]);
    80200c44:	44c8                	lw	a0,12(s1)
    80200c46:	00000097          	auipc	ra,0x0
    80200c4a:	be6080e7          	jalr	-1050(ra) # 8020082c <be32>
    80200c4e:	00299793          	slli	a5,s3,0x2
    80200c52:	f9078713          	addi	a4,a5,-112
    80200c56:	008707b3          	add	a5,a4,s0
    80200c5a:	fca7a023          	sw	a0,-64(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c5e:	ef843483          	ld	s1,-264(s0)
    80200c62:	6cae                	ld	s9,200(sp)
    80200c64:	7dea                	ld	s11,184(sp)
    80200c66:	bb89                	j	802009b8 <fdt_init+0xc6>
            } else if (streq(pname, "#size-cells")) {
    80200c68:	00006597          	auipc	a1,0x6
    80200c6c:	62858593          	addi	a1,a1,1576 # 80207290 <etext+0x290>
    80200c70:	8552                	mv	a0,s4
    80200c72:	00000097          	auipc	ra,0x0
    80200c76:	bec080e7          	jalr	-1044(ra) # 8020085e <streq>
    80200c7a:	c115                	beqz	a0,80200c9e <fdt_init+0x3ac>
                sc[depth] = be32(val[0]);
    80200c7c:	44c8                	lw	a0,12(s1)
    80200c7e:	00000097          	auipc	ra,0x0
    80200c82:	bae080e7          	jalr	-1106(ra) # 8020082c <be32>
    80200c86:	00299793          	slli	a5,s3,0x2
    80200c8a:	f9078793          	addi	a5,a5,-112
    80200c8e:	97a2                	add	a5,a5,s0
    80200c90:	f8a7a023          	sw	a0,-128(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c94:	ef843483          	ld	s1,-264(s0)
    80200c98:	6cae                	ld	s9,200(sp)
    80200c9a:	7dea                	ld	s11,184(sp)
    80200c9c:	bb31                	j	802009b8 <fdt_init+0xc6>
            } else if (streq(pname, "compatible")) {
    80200c9e:	00006597          	auipc	a1,0x6
    80200ca2:	60258593          	addi	a1,a1,1538 # 802072a0 <etext+0x2a0>
    80200ca6:	8552                	mv	a0,s4
    80200ca8:	00000097          	auipc	ra,0x0
    80200cac:	bb6080e7          	jalr	-1098(ra) # 8020085e <streq>
    80200cb0:	c55d                	beqz	a0,80200d5e <fdt_init+0x46c>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200cb2:	2c81                	sext.w	s9,s9
    80200cb4:	00006617          	auipc	a2,0x6
    80200cb8:	5fc60613          	addi	a2,a2,1532 # 802072b0 <etext+0x2b0>
    80200cbc:	85e6                	mv	a1,s9
    80200cbe:	856e                	mv	a0,s11
    80200cc0:	00000097          	auipc	ra,0x0
    80200cc4:	bcc080e7          	jalr	-1076(ra) # 8020088c <strlist_has>
    80200cc8:	c519                	beqz	a0,80200cd6 <fdt_init+0x3e4>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cca:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cce:	4c05                	li	s8,1
    80200cd0:	6cae                	ld	s9,200(sp)
    80200cd2:	7dea                	ld	s11,184(sp)
    80200cd4:	b1d5                	j	802009b8 <fdt_init+0xc6>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200cd6:	00006617          	auipc	a2,0x6
    80200cda:	5ea60613          	addi	a2,a2,1514 # 802072c0 <etext+0x2c0>
    80200cde:	85e6                	mv	a1,s9
    80200ce0:	856e                	mv	a0,s11
    80200ce2:	00000097          	auipc	ra,0x0
    80200ce6:	baa080e7          	jalr	-1110(ra) # 8020088c <strlist_has>
    80200cea:	c519                	beqz	a0,80200cf8 <fdt_init+0x406>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cec:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cf0:	4c05                	li	s8,1
    80200cf2:	6cae                	ld	s9,200(sp)
    80200cf4:	7dea                	ld	s11,184(sp)
    80200cf6:	b1c9                	j	802009b8 <fdt_init+0xc6>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200cf8:	00006617          	auipc	a2,0x6
    80200cfc:	5d060613          	addi	a2,a2,1488 # 802072c8 <etext+0x2c8>
    80200d00:	85e6                	mv	a1,s9
    80200d02:	856e                	mv	a0,s11
    80200d04:	00000097          	auipc	ra,0x0
    80200d08:	b88080e7          	jalr	-1144(ra) # 8020088c <strlist_has>
    80200d0c:	c519                	beqz	a0,80200d1a <fdt_init+0x428>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d0e:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d12:	4c09                	li	s8,2
    80200d14:	6cae                	ld	s9,200(sp)
    80200d16:	7dea                	ld	s11,184(sp)
    80200d18:	b145                	j	802009b8 <fdt_init+0xc6>
                         strlist_has(c, len, "sifive,plic-1.0.0"))
    80200d1a:	00006617          	auipc	a2,0x6
    80200d1e:	5be60613          	addi	a2,a2,1470 # 802072d8 <etext+0x2d8>
    80200d22:	85e6                	mv	a1,s9
    80200d24:	856e                	mv	a0,s11
    80200d26:	00000097          	auipc	ra,0x0
    80200d2a:	b66080e7          	jalr	-1178(ra) # 8020088c <strlist_has>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200d2e:	c519                	beqz	a0,80200d3c <fdt_init+0x44a>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d30:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d34:	4c09                	li	s8,2
    80200d36:	6cae                	ld	s9,200(sp)
    80200d38:	7dea                	ld	s11,184(sp)
    80200d3a:	b9bd                	j	802009b8 <fdt_init+0xc6>
                else if (strlist_has(c, len, "virtio,mmio"))
    80200d3c:	00006617          	auipc	a2,0x6
    80200d40:	5b460613          	addi	a2,a2,1460 # 802072f0 <etext+0x2f0>
    80200d44:	85e6                	mv	a1,s9
    80200d46:	856e                	mv	a0,s11
    80200d48:	00000097          	auipc	ra,0x0
    80200d4c:	b44080e7          	jalr	-1212(ra) # 8020088c <strlist_has>
    80200d50:	cc0513e3          	bnez	a0,80200a16 <fdt_init+0x124>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d54:	ef843483          	ld	s1,-264(s0)
    80200d58:	6cae                	ld	s9,200(sp)
    80200d5a:	7dea                	ld	s11,184(sp)
    80200d5c:	b9b1                	j	802009b8 <fdt_init+0xc6>
            } else if (streq(pname, "device_type")) {
    80200d5e:	00006597          	auipc	a1,0x6
    80200d62:	5a258593          	addi	a1,a1,1442 # 80207300 <etext+0x300>
    80200d66:	8552                	mv	a0,s4
    80200d68:	00000097          	auipc	ra,0x0
    80200d6c:	af6080e7          	jalr	-1290(ra) # 8020085e <streq>
    80200d70:	c115                	beqz	a0,80200d94 <fdt_init+0x4a2>
                if (strlist_has((const char *)val, len, "memory"))
    80200d72:	00006617          	auipc	a2,0x6
    80200d76:	59e60613          	addi	a2,a2,1438 # 80207310 <etext+0x310>
    80200d7a:	85e6                	mv	a1,s9
    80200d7c:	856e                	mv	a0,s11
    80200d7e:	00000097          	auipc	ra,0x0
    80200d82:	b0e080e7          	jalr	-1266(ra) # 8020088c <strlist_has>
    80200d86:	c8051ee3          	bnez	a0,80200a22 <fdt_init+0x130>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d8a:	ef843483          	ld	s1,-264(s0)
    80200d8e:	6cae                	ld	s9,200(sp)
    80200d90:	7dea                	ld	s11,184(sp)
    80200d92:	b11d                	j	802009b8 <fdt_init+0xc6>
            } else if (streq(pname, "interrupts")) {
    80200d94:	00006597          	auipc	a1,0x6
    80200d98:	58458593          	addi	a1,a1,1412 # 80207318 <etext+0x318>
    80200d9c:	8552                	mv	a0,s4
    80200d9e:	00000097          	auipc	ra,0x0
    80200da2:	ac0080e7          	jalr	-1344(ra) # 8020085e <streq>
    80200da6:	c50d                	beqz	a0,80200dd0 <fdt_init+0x4de>
                /* First cell = PLIC source number (qemu virt uses plain
                 * one-cell specifiers for uart and virtio). */
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200da8:	478d                	li	a5,3
    80200daa:	c997f2e3          	bgeu	a5,s9,80200a2e <fdt_init+0x13c>
    80200dae:	44c8                	lw	a0,12(s1)
    80200db0:	00000097          	auipc	ra,0x0
    80200db4:	a7c080e7          	jalr	-1412(ra) # 8020082c <be32>
    80200db8:	0005079b          	sext.w	a5,a0
    80200dbc:	eef43423          	sd	a5,-280(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200dc0:	ef843483          	ld	s1,-264(s0)
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200dc4:	4785                	li	a5,1
    80200dc6:	eef43823          	sd	a5,-272(s0)
    80200dca:	6cae                	ld	s9,200(sp)
    80200dcc:	7dea                	ld	s11,184(sp)
    80200dce:	b6ed                	j	802009b8 <fdt_init+0xc6>
            } else if (streq(pname, "reg")) {
    80200dd0:	00006597          	auipc	a1,0x6
    80200dd4:	55858593          	addi	a1,a1,1368 # 80207328 <etext+0x328>
    80200dd8:	8552                	mv	a0,s4
    80200dda:	00000097          	auipc	ra,0x0
    80200dde:	a84080e7          	jalr	-1404(ra) # 8020085e <streq>
    80200de2:	c4050be3          	beqz	a0,80200a38 <fdt_init+0x146>
                /* Decode with the PARENT's cell counts. */
                int pac = ac[depth - 1];
    80200de6:	fff9879b          	addiw	a5,s3,-1
    80200dea:	078a                	slli	a5,a5,0x2
    80200dec:	f9078793          	addi	a5,a5,-112
    80200df0:	97a2                	add	a5,a5,s0
    80200df2:	fc07aa03          	lw	s4,-64(a5)
                int psc = sc[depth - 1];
    80200df6:	f807ad03          	lw	s10,-128(a5)
                if (pac == 2)      reg_base = be64(val);
    80200dfa:	4789                	li	a5,2
    80200dfc:	02fa0563          	beq	s4,a5,80200e26 <fdt_init+0x534>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e00:	4785                	li	a5,1
                else               reg_base = 0;
    80200e02:	f0043423          	sd	zero,-248(s0)
                else if (pac == 1) reg_base = be32(val[0]);
    80200e06:	04fa0563          	beq	s4,a5,80200e50 <fdt_init+0x55e>

                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e0a:	4789                	li	a5,2
    80200e0c:	04fd0d63          	beq	s10,a5,80200e66 <fdt_init+0x574>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200e10:	4785                	li	a5,1
    80200e12:	08fd0763          	beq	s10,a5,80200ea0 <fdt_init+0x5ae>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e16:	ef843483          	ld	s1,-264(s0)
                else               reg_size = 0;
    80200e1a:	f0043023          	sd	zero,-256(s0)
                have_reg = 1;
    80200e1e:	4d05                	li	s10,1
    80200e20:	6cae                	ld	s9,200(sp)
    80200e22:	7dea                	ld	s11,184(sp)
    80200e24:	be51                	j	802009b8 <fdt_init+0xc6>
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e26:	44c8                	lw	a0,12(s1)
    80200e28:	00000097          	auipc	ra,0x0
    80200e2c:	a04080e7          	jalr	-1532(ra) # 8020082c <be32>
    80200e30:	00050c9b          	sext.w	s9,a0
    80200e34:	4888                	lw	a0,16(s1)
    80200e36:	00000097          	auipc	ra,0x0
    80200e3a:	9f6080e7          	jalr	-1546(ra) # 8020082c <be32>
    80200e3e:	1c82                	slli	s9,s9,0x20
    80200e40:	02051793          	slli	a5,a0,0x20
    80200e44:	9381                	srli	a5,a5,0x20
    80200e46:	00fce7b3          	or	a5,s9,a5
    80200e4a:	f0f43423          	sd	a5,-248(s0)
    80200e4e:	bf75                	j	80200e0a <fdt_init+0x518>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e50:	44c8                	lw	a0,12(s1)
    80200e52:	00000097          	auipc	ra,0x0
    80200e56:	9da080e7          	jalr	-1574(ra) # 8020082c <be32>
    80200e5a:	02051793          	slli	a5,a0,0x20
    80200e5e:	9381                	srli	a5,a5,0x20
    80200e60:	f0f43423          	sd	a5,-248(s0)
    80200e64:	b75d                	j	80200e0a <fdt_init+0x518>
                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e66:	002a1493          	slli	s1,s4,0x2
    80200e6a:	94ee                	add	s1,s1,s11
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e6c:	4088                	lw	a0,0(s1)
    80200e6e:	00000097          	auipc	ra,0x0
    80200e72:	9be080e7          	jalr	-1602(ra) # 8020082c <be32>
    80200e76:	00050a1b          	sext.w	s4,a0
    80200e7a:	40c8                	lw	a0,4(s1)
    80200e7c:	00000097          	auipc	ra,0x0
    80200e80:	9b0080e7          	jalr	-1616(ra) # 8020082c <be32>
    80200e84:	1a02                	slli	s4,s4,0x20
    80200e86:	02051793          	slli	a5,a0,0x20
    80200e8a:	9381                	srli	a5,a5,0x20
    80200e8c:	00fa67b3          	or	a5,s4,a5
    80200e90:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e94:	ef843483          	ld	s1,-264(s0)
                have_reg = 1;
    80200e98:	4d05                	li	s10,1
    80200e9a:	6cae                	ld	s9,200(sp)
    80200e9c:	7dea                	ld	s11,184(sp)
    80200e9e:	be29                	j	802009b8 <fdt_init+0xc6>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200ea0:	0a0a                	slli	s4,s4,0x2
    80200ea2:	9dd2                	add	s11,s11,s4
    80200ea4:	000da503          	lw	a0,0(s11)
    80200ea8:	00000097          	auipc	ra,0x0
    80200eac:	984080e7          	jalr	-1660(ra) # 8020082c <be32>
    80200eb0:	02051793          	slli	a5,a0,0x20
    80200eb4:	9381                	srli	a5,a5,0x20
    80200eb6:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200eba:	ef843483          	ld	s1,-264(s0)
    80200ebe:	6cae                	ld	s9,200(sp)
    80200ec0:	7dea                	ld	s11,184(sp)
    80200ec2:	bcdd                	j	802009b8 <fdt_init+0xc6>
    80200ec4:	e5e6                	sd	s9,200(sp)
    80200ec6:	fd6e                	sd	s11,184(sp)
            }
            continue;
        }
        panic("fdt: unknown token in structure block");
    80200ec8:	00006517          	auipc	a0,0x6
    80200ecc:	46850513          	addi	a0,a0,1128 # 80207330 <etext+0x330>
    80200ed0:	fffff097          	auipc	ra,0xfffff
    80200ed4:	722080e7          	jalr	1826(ra) # 802005f2 <panic>
    }

    if (fdt.ncpu == 0) fdt.ncpu = 1;
    80200ed8:	00028797          	auipc	a5,0x28
    80200edc:	1e07a783          	lw	a5,480(a5) # 802290b8 <fdt+0xa0>
    80200ee0:	ef8d                	bnez	a5,80200f1a <fdt_init+0x628>
    80200ee2:	4785                	li	a5,1
    80200ee4:	00028717          	auipc	a4,0x28
    80200ee8:	1cf72a23          	sw	a5,468(a4) # 802290b8 <fdt+0xa0>
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200eec:	00028797          	auipc	a5,0x28
    80200ef0:	13c7b783          	ld	a5,316(a5) # 80229028 <fdt+0x10>
    80200ef4:	cf85                	beqz	a5,80200f2c <fdt_init+0x63a>
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200ef6:	00028797          	auipc	a5,0x28
    80200efa:	1ba7b783          	ld	a5,442(a5) # 802290b0 <fdt+0x98>
    80200efe:	c3a9                	beqz	a5,80200f40 <fdt_init+0x64e>
    80200f00:	64b2                	ld	s1,264(sp)
    80200f02:	6912                	ld	s2,256(sp)
    80200f04:	7a4e                	ld	s4,240(sp)
    80200f06:	7aae                	ld	s5,232(sp)
    80200f08:	7b0e                	ld	s6,224(sp)
    80200f0a:	6bee                	ld	s7,216(sp)
    80200f0c:	6c4e                	ld	s8,208(sp)
    80200f0e:	6d0e                	ld	s10,192(sp)
}
    80200f10:	60f2                	ld	ra,280(sp)
    80200f12:	6452                	ld	s0,272(sp)
    80200f14:	79ee                	ld	s3,248(sp)
    80200f16:	6115                	addi	sp,sp,288
    80200f18:	8082                	ret
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    80200f1a:	4721                	li	a4,8
    80200f1c:	fcf758e3          	bge	a4,a5,80200eec <fdt_init+0x5fa>
    80200f20:	47a1                	li	a5,8
    80200f22:	00028717          	auipc	a4,0x28
    80200f26:	18f72b23          	sw	a5,406(a4) # 802290b8 <fdt+0xa0>
    80200f2a:	b7c9                	j	80200eec <fdt_init+0x5fa>
    80200f2c:	e5e6                	sd	s9,200(sp)
    80200f2e:	fd6e                	sd	s11,184(sp)
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200f30:	00006517          	auipc	a0,0x6
    80200f34:	42850513          	addi	a0,a0,1064 # 80207358 <etext+0x358>
    80200f38:	fffff097          	auipc	ra,0xfffff
    80200f3c:	6ba080e7          	jalr	1722(ra) # 802005f2 <panic>
    80200f40:	e5e6                	sd	s9,200(sp)
    80200f42:	fd6e                	sd	s11,184(sp)
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f44:	00006517          	auipc	a0,0x6
    80200f48:	43c50513          	addi	a0,a0,1084 # 80207380 <etext+0x380>
    80200f4c:	fffff097          	auipc	ra,0xfffff
    80200f50:	6a6080e7          	jalr	1702(ra) # 802005f2 <panic>
                fdt.ncpu++;
    80200f54:	00028717          	auipc	a4,0x28
    80200f58:	0c470713          	addi	a4,a4,196 # 80229018 <fdt>
    80200f5c:	0a072783          	lw	a5,160(a4)
    80200f60:	2785                	addiw	a5,a5,1
    80200f62:	0af72023          	sw	a5,160(a4)
            depth++;
    80200f66:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200f68:	ee043423          	sd	zero,-280(s0)
    80200f6c:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200f70:	f0043023          	sd	zero,-256(s0)
    80200f74:	f0043423          	sd	zero,-248(s0)
    80200f78:	4d01                	li	s10,0
    80200f7a:	4c01                	li	s8,0
    80200f7c:	bc35                	j	802009b8 <fdt_init+0xc6>

0000000080200f7e <palloc_init>:
} kmem;

#define PA2IDX(pa) (((uint64)(pa) - kmem.base) >> PGSHIFT)

void palloc_init(void)
{
    80200f7e:	715d                	addi	sp,sp,-80
    80200f80:	e486                	sd	ra,72(sp)
    80200f82:	e0a2                	sd	s0,64(sp)
    80200f84:	fc26                	sd	s1,56(sp)
    80200f86:	f84a                	sd	s2,48(sp)
    80200f88:	f44e                	sd	s3,40(sp)
    80200f8a:	f052                	sd	s4,32(sp)
    80200f8c:	ec56                	sd	s5,24(sp)
    80200f8e:	e85a                	sd	s6,16(sp)
    80200f90:	e45e                	sd	s7,8(sp)
    80200f92:	e062                	sd	s8,0(sp)
    80200f94:	0880                	addi	s0,sp,80
    initlock(&kmem.lock, "kmem");
    80200f96:	00028b97          	auipc	s7,0x28
    80200f9a:	12ab8b93          	addi	s7,s7,298 # 802290c0 <kmem>
    80200f9e:	00006597          	auipc	a1,0x6
    80200fa2:	3fa58593          	addi	a1,a1,1018 # 80207398 <etext+0x398>
    80200fa6:	855e                	mv	a0,s7
    80200fa8:	00000097          	auipc	ra,0x0
    80200fac:	304080e7          	jalr	772(ra) # 802012ac <initlock>

    uint64 mem_start = fdt.mem_base;
    80200fb0:	00028717          	auipc	a4,0x28
    80200fb4:	06870713          	addi	a4,a4,104 # 80229018 <fdt>
    80200fb8:	09073a83          	ld	s5,144(a4)
    uint64 mem_end   = fdt.mem_base + fdt.mem_size;
    80200fbc:	09873a03          	ld	s4,152(a4)
    80200fc0:	9a56                	add	s4,s4,s5
     * TOP of RAM (on qemu virt, ~0x87e00000). If you "reserve" it by pushing
     * free_start past it, you throw away almost all your memory and end up with
     * a kernel that has 1 MiB and cannot say why. Do NOT skip PAST the blob -
     * skip OVER its pages, and keep everything else.
     */
    uint64 free_start = PGROUNDUP((uint64)kernel_end);
    80200fc2:	6c05                	lui	s8,0x1
    80200fc4:	fffc0693          	addi	a3,s8,-1 # fff <_entry-0x801ff001>
    80200fc8:	77fd                	lui	a5,0xfffff
    80200fca:	0014a617          	auipc	a2,0x14a
    80200fce:	03560613          	addi	a2,a2,53 # 8034afff <uart+0xfcf>
    80200fd2:	00f674b3          	and	s1,a2,a5
    uint64 fdt_lo = PGROUNDDOWN(fdt.blob);
    80200fd6:	00073903          	ld	s2,0(a4)
    80200fda:	00f979b3          	and	s3,s2,a5
    uint64 fdt_hi = PGROUNDUP(fdt.blob + fdt.blob_size);
    80200fde:	6718                	ld	a4,8(a4)
    80200fe0:	993a                	add	s2,s2,a4
    80200fe2:	9936                	add	s2,s2,a3
    80200fe4:	00f97933          	and	s2,s2,a5

    uint64 npages = (mem_end - free_start) >> PGSHIFT;
    80200fe8:	409a0b33          	sub	s6,s4,s1
    80200fec:	00cb5b13          	srli	s6,s6,0xc

    /* One refcount byte per page (L11, copy-on-write). Carve it out of the
     * front of free memory - which is below the FDT, so this is safe. */
    uint64 refbytes = PGROUNDUP(npages);
    80200ff0:	9b36                	add	s6,s6,a3
    80200ff2:	00fb7b33          	and	s6,s6,a5
    kmem.refcnt = (uint8 *)free_start;
    80200ff6:	029bbc23          	sd	s1,56(s7)
    memset(kmem.refcnt, 0, refbytes);
    80200ffa:	865a                	mv	a2,s6
    80200ffc:	4581                	li	a1,0
    80200ffe:	8526                	mv	a0,s1
    80201000:	fffff097          	auipc	ra,0xfffff
    80201004:	698080e7          	jalr	1688(ra) # 80200698 <memset>
    free_start += refbytes;
    80201008:	01648633          	add	a2,s1,s6

    kmem.base = free_start;
    8020100c:	02cbb023          	sd	a2,32(s7)
    kmem.top  = mem_end;
    80201010:	034bb423          	sd	s4,40(s7)
    kmem.freelist = 0;
    80201014:	000bbc23          	sd	zero,24(s7)
    kmem.nfree = 0;
    80201018:	020ba823          	sw	zero,48(s7)

    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    8020101c:	9c32                	add	s8,s8,a2
    8020101e:	058a6063          	bltu	s4,s8,8020105e <palloc_init+0xe0>
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
            continue;                       /* never hand this page out    */
        struct run *r = (struct run *)p;
        kmem.refcnt[PA2IDX(p)] = 0;
    80201022:	87de                	mv	a5,s7
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201024:	6505                	lui	a0,0x1
    80201026:	6589                	lui	a1,0x2
    80201028:	a035                	j	80201054 <palloc_init+0xd6>
        kmem.refcnt[PA2IDX(p)] = 0;
    8020102a:	7398                	ld	a4,32(a5)
    8020102c:	40e60733          	sub	a4,a2,a4
    80201030:	8331                	srli	a4,a4,0xc
    80201032:	7f94                	ld	a3,56(a5)
    80201034:	9736                	add	a4,a4,a3
    80201036:	00070023          	sb	zero,0(a4)
        r->next = kmem.freelist;
    8020103a:	6f98                	ld	a4,24(a5)
    8020103c:	e218                	sd	a4,0(a2)
        kmem.freelist = r;
    8020103e:	ef90                	sd	a2,24(a5)
        kmem.nfree++;
    80201040:	5b98                	lw	a4,48(a5)
    80201042:	2705                	addiw	a4,a4,1
    80201044:	db98                	sw	a4,48(a5)
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201046:	00a606b3          	add	a3,a2,a0
    8020104a:	962e                	add	a2,a2,a1
    8020104c:	7798                	ld	a4,40(a5)
    8020104e:	00c76863          	bltu	a4,a2,8020105e <palloc_init+0xe0>
    80201052:	8636                	mv	a2,a3
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
    80201054:	fd366be3          	bltu	a2,s3,8020102a <palloc_init+0xac>
    80201058:	fd2679e3          	bgeu	a2,s2,8020102a <palloc_init+0xac>
    8020105c:	b7ed                	j	80201046 <palloc_init+0xc8>
    }
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    8020105e:	00028697          	auipc	a3,0x28
    80201062:	0926a683          	lw	a3,146(a3) # 802290f0 <kmem+0x30>
           mem_start, mem_end, kmem.nfree, (kmem.nfree * PGSIZE) >> 20);
    80201066:	00c6971b          	slliw	a4,a3,0xc
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    8020106a:	4147571b          	sraiw	a4,a4,0x14
    8020106e:	8652                	mv	a2,s4
    80201070:	85d6                	mv	a1,s5
    80201072:	00006517          	auipc	a0,0x6
    80201076:	32e50513          	addi	a0,a0,814 # 802073a0 <etext+0x3a0>
    8020107a:	fffff097          	auipc	ra,0xfffff
    8020107e:	306080e7          	jalr	774(ra) # 80200380 <printf>
}
    80201082:	60a6                	ld	ra,72(sp)
    80201084:	6406                	ld	s0,64(sp)
    80201086:	74e2                	ld	s1,56(sp)
    80201088:	7942                	ld	s2,48(sp)
    8020108a:	79a2                	ld	s3,40(sp)
    8020108c:	7a02                	ld	s4,32(sp)
    8020108e:	6ae2                	ld	s5,24(sp)
    80201090:	6b42                	ld	s6,16(sp)
    80201092:	6ba2                	ld	s7,8(sp)
    80201094:	6c02                	ld	s8,0(sp)
    80201096:	6161                	addi	sp,sp,80
    80201098:	8082                	ret

000000008020109a <palloc>:

void *palloc(void)
{
    8020109a:	1101                	addi	sp,sp,-32
    8020109c:	ec06                	sd	ra,24(sp)
    8020109e:	e822                	sd	s0,16(sp)
    802010a0:	e426                	sd	s1,8(sp)
    802010a2:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    802010a4:	00028497          	auipc	s1,0x28
    802010a8:	01c48493          	addi	s1,s1,28 # 802290c0 <kmem>
    802010ac:	8526                	mv	a0,s1
    802010ae:	00000097          	auipc	ra,0x0
    802010b2:	27a080e7          	jalr	634(ra) # 80201328 <acquire>
    struct run *r = kmem.freelist;
    802010b6:	6c84                	ld	s1,24(s1)
    if (r) {
    802010b8:	c4a1                	beqz	s1,80201100 <palloc+0x66>
        kmem.freelist = r->next;
    802010ba:	609c                	ld	a5,0(s1)
    802010bc:	00028517          	auipc	a0,0x28
    802010c0:	00450513          	addi	a0,a0,4 # 802290c0 <kmem>
    802010c4:	ed1c                	sd	a5,24(a0)
        kmem.nfree--;
    802010c6:	591c                	lw	a5,48(a0)
    802010c8:	37fd                	addiw	a5,a5,-1 # ffffffffffffefff <uart+0xffffffff7fcb4fcf>
    802010ca:	d91c                	sw	a5,48(a0)
        kmem.refcnt[PA2IDX(r)] = 1;
    802010cc:	711c                	ld	a5,32(a0)
    802010ce:	40f487b3          	sub	a5,s1,a5
    802010d2:	83b1                	srli	a5,a5,0xc
    802010d4:	7d18                	ld	a4,56(a0)
    802010d6:	97ba                	add	a5,a5,a4
    802010d8:	4705                	li	a4,1
    802010da:	00e78023          	sb	a4,0(a5)
    }
    release(&kmem.lock);
    802010de:	00000097          	auipc	ra,0x0
    802010e2:	2fe080e7          	jalr	766(ra) # 802013dc <release>

    if (r)
        memset((void *)r, 5, PGSIZE);   /* poison: catch use-before-init */
    802010e6:	6605                	lui	a2,0x1
    802010e8:	4595                	li	a1,5
    802010ea:	8526                	mv	a0,s1
    802010ec:	fffff097          	auipc	ra,0xfffff
    802010f0:	5ac080e7          	jalr	1452(ra) # 80200698 <memset>
    return (void *)r;
}
    802010f4:	8526                	mv	a0,s1
    802010f6:	60e2                	ld	ra,24(sp)
    802010f8:	6442                	ld	s0,16(sp)
    802010fa:	64a2                	ld	s1,8(sp)
    802010fc:	6105                	addi	sp,sp,32
    802010fe:	8082                	ret
    release(&kmem.lock);
    80201100:	00028517          	auipc	a0,0x28
    80201104:	fc050513          	addi	a0,a0,-64 # 802290c0 <kmem>
    80201108:	00000097          	auipc	ra,0x0
    8020110c:	2d4080e7          	jalr	724(ra) # 802013dc <release>
    if (r)
    80201110:	b7d5                	j	802010f4 <palloc+0x5a>

0000000080201112 <palloc_ref_inc>:

void palloc_ref_inc(void *pa)
{
    80201112:	1101                	addi	sp,sp,-32
    80201114:	ec06                	sd	ra,24(sp)
    80201116:	e822                	sd	s0,16(sp)
    80201118:	e426                	sd	s1,8(sp)
    8020111a:	e04a                	sd	s2,0(sp)
    8020111c:	1000                	addi	s0,sp,32
    8020111e:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    80201120:	00028917          	auipc	s2,0x28
    80201124:	fa090913          	addi	s2,s2,-96 # 802290c0 <kmem>
    80201128:	854a                	mv	a0,s2
    8020112a:	00000097          	auipc	ra,0x0
    8020112e:	1fe080e7          	jalr	510(ra) # 80201328 <acquire>
    kmem.refcnt[PA2IDX(pa)]++;
    80201132:	02093783          	ld	a5,32(s2)
    80201136:	8c9d                	sub	s1,s1,a5
    80201138:	80b1                	srli	s1,s1,0xc
    8020113a:	03893783          	ld	a5,56(s2)
    8020113e:	97a6                	add	a5,a5,s1
    80201140:	0007c703          	lbu	a4,0(a5)
    80201144:	2705                	addiw	a4,a4,1
    80201146:	00e78023          	sb	a4,0(a5)
    release(&kmem.lock);
    8020114a:	854a                	mv	a0,s2
    8020114c:	00000097          	auipc	ra,0x0
    80201150:	290080e7          	jalr	656(ra) # 802013dc <release>
}
    80201154:	60e2                	ld	ra,24(sp)
    80201156:	6442                	ld	s0,16(sp)
    80201158:	64a2                	ld	s1,8(sp)
    8020115a:	6902                	ld	s2,0(sp)
    8020115c:	6105                	addi	sp,sp,32
    8020115e:	8082                	ret

0000000080201160 <palloc_ref_get>:

int palloc_ref_get(void *pa)
{
    80201160:	1101                	addi	sp,sp,-32
    80201162:	ec06                	sd	ra,24(sp)
    80201164:	e822                	sd	s0,16(sp)
    80201166:	e426                	sd	s1,8(sp)
    80201168:	e04a                	sd	s2,0(sp)
    8020116a:	1000                	addi	s0,sp,32
    8020116c:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    8020116e:	00028917          	auipc	s2,0x28
    80201172:	f5290913          	addi	s2,s2,-174 # 802290c0 <kmem>
    80201176:	854a                	mv	a0,s2
    80201178:	00000097          	auipc	ra,0x0
    8020117c:	1b0080e7          	jalr	432(ra) # 80201328 <acquire>
    int n = kmem.refcnt[PA2IDX(pa)];
    80201180:	02093783          	ld	a5,32(s2)
    80201184:	8c9d                	sub	s1,s1,a5
    80201186:	80b1                	srli	s1,s1,0xc
    80201188:	03893783          	ld	a5,56(s2)
    8020118c:	97a6                	add	a5,a5,s1
    8020118e:	0007c483          	lbu	s1,0(a5)
    release(&kmem.lock);
    80201192:	854a                	mv	a0,s2
    80201194:	00000097          	auipc	ra,0x0
    80201198:	248080e7          	jalr	584(ra) # 802013dc <release>
    return n;
}
    8020119c:	8526                	mv	a0,s1
    8020119e:	60e2                	ld	ra,24(sp)
    802011a0:	6442                	ld	s0,16(sp)
    802011a2:	64a2                	ld	s1,8(sp)
    802011a4:	6902                	ld	s2,0(sp)
    802011a6:	6105                	addi	sp,sp,32
    802011a8:	8082                	ret

00000000802011aa <pfree>:

void pfree(void *pa)
{
    802011aa:	1101                	addi	sp,sp,-32
    802011ac:	ec06                	sd	ra,24(sp)
    802011ae:	e822                	sd	s0,16(sp)
    802011b0:	e426                	sd	s1,8(sp)
    802011b2:	e04a                	sd	s2,0(sp)
    802011b4:	1000                	addi	s0,sp,32
    if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < kmem.base || (uint64)pa >= kmem.top)
    802011b6:	03451713          	slli	a4,a0,0x34
    802011ba:	e359                	bnez	a4,80201240 <pfree+0x96>
    802011bc:	84aa                	mv	s1,a0
    802011be:	00028717          	auipc	a4,0x28
    802011c2:	f2273703          	ld	a4,-222(a4) # 802290e0 <kmem+0x20>
    802011c6:	06e56d63          	bltu	a0,a4,80201240 <pfree+0x96>
    802011ca:	00028717          	auipc	a4,0x28
    802011ce:	f1e73703          	ld	a4,-226(a4) # 802290e8 <kmem+0x28>
    802011d2:	06e57763          	bgeu	a0,a4,80201240 <pfree+0x96>
        panic("pfree: bad pointer");

    acquire(&kmem.lock);
    802011d6:	00028917          	auipc	s2,0x28
    802011da:	eea90913          	addi	s2,s2,-278 # 802290c0 <kmem>
    802011de:	854a                	mv	a0,s2
    802011e0:	00000097          	auipc	ra,0x0
    802011e4:	148080e7          	jalr	328(ra) # 80201328 <acquire>
    uint64 i = PA2IDX(pa);
    802011e8:	02093783          	ld	a5,32(s2)
    802011ec:	40f487b3          	sub	a5,s1,a5
    802011f0:	83b1                	srli	a5,a5,0xc
    if (kmem.refcnt[i] < 1)
    802011f2:	03893703          	ld	a4,56(s2)
    802011f6:	973e                	add	a4,a4,a5
    802011f8:	00074783          	lbu	a5,0(a4)
    802011fc:	cbb1                	beqz	a5,80201250 <pfree+0xa6>
        panic("pfree: double free / refcount underflow");

    if (--kmem.refcnt[i] > 0) {          /* still shared (COW) - not really free */
    802011fe:	37fd                	addiw	a5,a5,-1
    80201200:	0ff7f793          	zext.b	a5,a5
    80201204:	00f70023          	sb	a5,0(a4)
    80201208:	efa1                	bnez	a5,80201260 <pfree+0xb6>
        release(&kmem.lock);
        return;
    }
    memset(pa, 1, PGSIZE);               /* poison: catch use-after-free */
    8020120a:	6605                	lui	a2,0x1
    8020120c:	4585                	li	a1,1
    8020120e:	8526                	mv	a0,s1
    80201210:	fffff097          	auipc	ra,0xfffff
    80201214:	488080e7          	jalr	1160(ra) # 80200698 <memset>
    struct run *r = (struct run *)pa;
    r->next = kmem.freelist;
    80201218:	00028517          	auipc	a0,0x28
    8020121c:	ea850513          	addi	a0,a0,-344 # 802290c0 <kmem>
    80201220:	6d1c                	ld	a5,24(a0)
    80201222:	e09c                	sd	a5,0(s1)
    kmem.freelist = r;
    80201224:	ed04                	sd	s1,24(a0)
    kmem.nfree++;
    80201226:	591c                	lw	a5,48(a0)
    80201228:	2785                	addiw	a5,a5,1
    8020122a:	d91c                	sw	a5,48(a0)
    release(&kmem.lock);
    8020122c:	00000097          	auipc	ra,0x0
    80201230:	1b0080e7          	jalr	432(ra) # 802013dc <release>
}
    80201234:	60e2                	ld	ra,24(sp)
    80201236:	6442                	ld	s0,16(sp)
    80201238:	64a2                	ld	s1,8(sp)
    8020123a:	6902                	ld	s2,0(sp)
    8020123c:	6105                	addi	sp,sp,32
    8020123e:	8082                	ret
        panic("pfree: bad pointer");
    80201240:	00006517          	auipc	a0,0x6
    80201244:	19850513          	addi	a0,a0,408 # 802073d8 <etext+0x3d8>
    80201248:	fffff097          	auipc	ra,0xfffff
    8020124c:	3aa080e7          	jalr	938(ra) # 802005f2 <panic>
        panic("pfree: double free / refcount underflow");
    80201250:	00006517          	auipc	a0,0x6
    80201254:	1a050513          	addi	a0,a0,416 # 802073f0 <etext+0x3f0>
    80201258:	fffff097          	auipc	ra,0xfffff
    8020125c:	39a080e7          	jalr	922(ra) # 802005f2 <panic>
        release(&kmem.lock);
    80201260:	00028517          	auipc	a0,0x28
    80201264:	e6050513          	addi	a0,a0,-416 # 802290c0 <kmem>
    80201268:	00000097          	auipc	ra,0x0
    8020126c:	174080e7          	jalr	372(ra) # 802013dc <release>
        return;
    80201270:	b7d1                	j	80201234 <pfree+0x8a>

0000000080201272 <palloc_free_count>:

int palloc_free_count(void)
{
    80201272:	1101                	addi	sp,sp,-32
    80201274:	ec06                	sd	ra,24(sp)
    80201276:	e822                	sd	s0,16(sp)
    80201278:	e426                	sd	s1,8(sp)
    8020127a:	e04a                	sd	s2,0(sp)
    8020127c:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    8020127e:	00028497          	auipc	s1,0x28
    80201282:	e4248493          	addi	s1,s1,-446 # 802290c0 <kmem>
    80201286:	8526                	mv	a0,s1
    80201288:	00000097          	auipc	ra,0x0
    8020128c:	0a0080e7          	jalr	160(ra) # 80201328 <acquire>
    int n = kmem.nfree;
    80201290:	0304a903          	lw	s2,48(s1)
    release(&kmem.lock);
    80201294:	8526                	mv	a0,s1
    80201296:	00000097          	auipc	ra,0x0
    8020129a:	146080e7          	jalr	326(ra) # 802013dc <release>
    return n;
}
    8020129e:	854a                	mv	a0,s2
    802012a0:	60e2                	ld	ra,24(sp)
    802012a2:	6442                	ld	s0,16(sp)
    802012a4:	64a2                	ld	s1,8(sp)
    802012a6:	6902                	ld	s2,0(sp)
    802012a8:	6105                	addi	sp,sp,32
    802012aa:	8082                	ret

00000000802012ac <initlock>:
#include "types.h"
#include "defs.h"
#include "hal.h"

void initlock(struct spinlock *lk, const char *name)
{
    802012ac:	1141                	addi	sp,sp,-16
    802012ae:	e422                	sd	s0,8(sp)
    802012b0:	0800                	addi	s0,sp,16
    lk->name = name; lk->locked = 0; lk->cpu = -1;
    802012b2:	e50c                	sd	a1,8(a0)
    802012b4:	00052023          	sw	zero,0(a0)
    802012b8:	57fd                	li	a5,-1
    802012ba:	c91c                	sw	a5,16(a0)
}
    802012bc:	6422                	ld	s0,8(sp)
    802012be:	0141                	addi	sp,sp,16
    802012c0:	8082                	ret

00000000802012c2 <holding>:
    pop_off();
}

int holding(struct spinlock *lk)
{
    return lk->locked && lk->cpu == hal_hart_id();
    802012c2:	411c                	lw	a5,0(a0)
    802012c4:	e399                	bnez	a5,802012ca <holding+0x8>
    802012c6:	4501                	li	a0,0
}
    802012c8:	8082                	ret
{
    802012ca:	1101                	addi	sp,sp,-32
    802012cc:	ec06                	sd	ra,24(sp)
    802012ce:	e822                	sd	s0,16(sp)
    802012d0:	e426                	sd	s1,8(sp)
    802012d2:	1000                	addi	s0,sp,32
    return lk->locked && lk->cpu == hal_hart_id();
    802012d4:	4904                	lw	s1,16(a0)
    802012d6:	00005097          	auipc	ra,0x5
    802012da:	4d8080e7          	jalr	1240(ra) # 802067ae <hal_hart_id>
    802012de:	40a48533          	sub	a0,s1,a0
    802012e2:	00153513          	seqz	a0,a0
}
    802012e6:	60e2                	ld	ra,24(sp)
    802012e8:	6442                	ld	s0,16(sp)
    802012ea:	64a2                	ld	s1,8(sp)
    802012ec:	6105                	addi	sp,sp,32
    802012ee:	8082                	ret

00000000802012f0 <push_off>:

void push_off(void)
{
    802012f0:	1101                	addi	sp,sp,-32
    802012f2:	ec06                	sd	ra,24(sp)
    802012f4:	e822                	sd	s0,16(sp)
    802012f6:	e426                	sd	s1,8(sp)
    802012f8:	1000                	addi	s0,sp,32
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802012fa:	100024f3          	csrr	s1,sstatus
    802012fe:	100027f3          	csrr	a5,sstatus
#define SIE_SSIE (1L << 1)
#define SIE_STIE (1L << 5)       /* timer  */
#define SIE_SEIE (1L << 9)       /* external */

static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    80201302:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201304:	10079073          	csrw	sstatus,a5
    int old = intr_get();
    intr_off();
    struct cpu *c = mycpu();
    80201308:	00000097          	auipc	ra,0x0
    8020130c:	43a080e7          	jalr	1082(ra) # 80201742 <mycpu>
    if (c->noff == 0) c->intena = old;   /* remember the ORIGINAL state */
    80201310:	5d3c                	lw	a5,120(a0)
    80201312:	e781                	bnez	a5,8020131a <push_off+0x2a>
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201314:	8085                	srli	s1,s1,0x1
    80201316:	8885                	andi	s1,s1,1
    80201318:	dd64                	sw	s1,124(a0)
    c->noff++;
    8020131a:	2785                	addiw	a5,a5,1
    8020131c:	dd3c                	sw	a5,120(a0)
}
    8020131e:	60e2                	ld	ra,24(sp)
    80201320:	6442                	ld	s0,16(sp)
    80201322:	64a2                	ld	s1,8(sp)
    80201324:	6105                	addi	sp,sp,32
    80201326:	8082                	ret

0000000080201328 <acquire>:
{
    80201328:	1101                	addi	sp,sp,-32
    8020132a:	ec06                	sd	ra,24(sp)
    8020132c:	e822                	sd	s0,16(sp)
    8020132e:	e426                	sd	s1,8(sp)
    80201330:	1000                	addi	s0,sp,32
    80201332:	84aa                	mv	s1,a0
    push_off();
    80201334:	00000097          	auipc	ra,0x0
    80201338:	fbc080e7          	jalr	-68(ra) # 802012f0 <push_off>
    if (holding(lk)) panic("acquire: already holding this lock");
    8020133c:	8526                	mv	a0,s1
    8020133e:	00000097          	auipc	ra,0x0
    80201342:	f84080e7          	jalr	-124(ra) # 802012c2 <holding>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80201346:	4705                	li	a4,1
    if (holding(lk)) panic("acquire: already holding this lock");
    80201348:	e115                	bnez	a0,8020136c <acquire+0x44>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    8020134a:	87ba                	mv	a5,a4
    8020134c:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80201350:	2781                	sext.w	a5,a5
    80201352:	ffe5                	bnez	a5,8020134a <acquire+0x22>
    __sync_synchronize();          /* fence: nothing below moves above this */
    80201354:	0ff0000f          	fence
    lk->cpu = hal_hart_id();
    80201358:	00005097          	auipc	ra,0x5
    8020135c:	456080e7          	jalr	1110(ra) # 802067ae <hal_hart_id>
    80201360:	c888                	sw	a0,16(s1)
}
    80201362:	60e2                	ld	ra,24(sp)
    80201364:	6442                	ld	s0,16(sp)
    80201366:	64a2                	ld	s1,8(sp)
    80201368:	6105                	addi	sp,sp,32
    8020136a:	8082                	ret
    if (holding(lk)) panic("acquire: already holding this lock");
    8020136c:	00006517          	auipc	a0,0x6
    80201370:	0ac50513          	addi	a0,a0,172 # 80207418 <etext+0x418>
    80201374:	fffff097          	auipc	ra,0xfffff
    80201378:	27e080e7          	jalr	638(ra) # 802005f2 <panic>

000000008020137c <pop_off>:

void pop_off(void)
{
    8020137c:	1141                	addi	sp,sp,-16
    8020137e:	e406                	sd	ra,8(sp)
    80201380:	e022                	sd	s0,0(sp)
    80201382:	0800                	addi	s0,sp,16
    struct cpu *c = mycpu();
    80201384:	00000097          	auipc	ra,0x0
    80201388:	3be080e7          	jalr	958(ra) # 80201742 <mycpu>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020138c:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201390:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("pop_off: interrupts already on");
    80201392:	e78d                	bnez	a5,802013bc <pop_off+0x40>
    if (c->noff < 1) panic("pop_off: unbalanced");
    80201394:	5d3c                	lw	a5,120(a0)
    80201396:	02f05b63          	blez	a5,802013cc <pop_off+0x50>
    c->noff--;
    8020139a:	37fd                	addiw	a5,a5,-1
    8020139c:	0007871b          	sext.w	a4,a5
    802013a0:	dd3c                	sw	a5,120(a0)
    if (c->noff == 0 && c->intena) intr_on();
    802013a2:	eb09                	bnez	a4,802013b4 <pop_off+0x38>
    802013a4:	5d7c                	lw	a5,124(a0)
    802013a6:	c799                	beqz	a5,802013b4 <pop_off+0x38>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802013a8:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    802013ac:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802013b0:	10079073          	csrw	sstatus,a5
}
    802013b4:	60a2                	ld	ra,8(sp)
    802013b6:	6402                	ld	s0,0(sp)
    802013b8:	0141                	addi	sp,sp,16
    802013ba:	8082                	ret
    if (intr_get()) panic("pop_off: interrupts already on");
    802013bc:	00006517          	auipc	a0,0x6
    802013c0:	08450513          	addi	a0,a0,132 # 80207440 <etext+0x440>
    802013c4:	fffff097          	auipc	ra,0xfffff
    802013c8:	22e080e7          	jalr	558(ra) # 802005f2 <panic>
    if (c->noff < 1) panic("pop_off: unbalanced");
    802013cc:	00006517          	auipc	a0,0x6
    802013d0:	09450513          	addi	a0,a0,148 # 80207460 <etext+0x460>
    802013d4:	fffff097          	auipc	ra,0xfffff
    802013d8:	21e080e7          	jalr	542(ra) # 802005f2 <panic>

00000000802013dc <release>:
{
    802013dc:	1101                	addi	sp,sp,-32
    802013de:	ec06                	sd	ra,24(sp)
    802013e0:	e822                	sd	s0,16(sp)
    802013e2:	e426                	sd	s1,8(sp)
    802013e4:	1000                	addi	s0,sp,32
    802013e6:	84aa                	mv	s1,a0
    if (!holding(lk)) panic("release: not holding this lock");
    802013e8:	00000097          	auipc	ra,0x0
    802013ec:	eda080e7          	jalr	-294(ra) # 802012c2 <holding>
    802013f0:	c115                	beqz	a0,80201414 <release+0x38>
    lk->cpu = -1;
    802013f2:	57fd                	li	a5,-1
    802013f4:	c89c                	sw	a5,16(s1)
    __sync_synchronize();          /* fence: nothing above moves below this */
    802013f6:	0ff0000f          	fence
    __sync_lock_release(&lk->locked);
    802013fa:	0f50000f          	fence	iorw,ow
    802013fe:	0804a02f          	amoswap.w	zero,zero,(s1)
    pop_off();
    80201402:	00000097          	auipc	ra,0x0
    80201406:	f7a080e7          	jalr	-134(ra) # 8020137c <pop_off>
}
    8020140a:	60e2                	ld	ra,24(sp)
    8020140c:	6442                	ld	s0,16(sp)
    8020140e:	64a2                	ld	s1,8(sp)
    80201410:	6105                	addi	sp,sp,32
    80201412:	8082                	ret
    if (!holding(lk)) panic("release: not holding this lock");
    80201414:	00006517          	auipc	a0,0x6
    80201418:	06450513          	addi	a0,a0,100 # 80207478 <etext+0x478>
    8020141c:	fffff097          	auipc	ra,0xfffff
    80201420:	1d6080e7          	jalr	470(ra) # 802005f2 <panic>

0000000080201424 <initsleeplock>:
 */
#include "types.h"
#include "defs.h"

void initsleeplock(struct sleeplock *lk, const char *name)
{
    80201424:	1101                	addi	sp,sp,-32
    80201426:	ec06                	sd	ra,24(sp)
    80201428:	e822                	sd	s0,16(sp)
    8020142a:	e426                	sd	s1,8(sp)
    8020142c:	e04a                	sd	s2,0(sp)
    8020142e:	1000                	addi	s0,sp,32
    80201430:	84aa                	mv	s1,a0
    80201432:	892e                	mv	s2,a1
    initlock(&lk->lk, "sleep lock");
    80201434:	00006597          	auipc	a1,0x6
    80201438:	06458593          	addi	a1,a1,100 # 80207498 <etext+0x498>
    8020143c:	0521                	addi	a0,a0,8
    8020143e:	00000097          	auipc	ra,0x0
    80201442:	e6e080e7          	jalr	-402(ra) # 802012ac <initlock>
    lk->name = name;
    80201446:	0324b023          	sd	s2,32(s1)
    lk->locked = 0;
    8020144a:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    8020144e:	0204a423          	sw	zero,40(s1)
}
    80201452:	60e2                	ld	ra,24(sp)
    80201454:	6442                	ld	s0,16(sp)
    80201456:	64a2                	ld	s1,8(sp)
    80201458:	6902                	ld	s2,0(sp)
    8020145a:	6105                	addi	sp,sp,32
    8020145c:	8082                	ret

000000008020145e <acquiresleep>:

void acquiresleep(struct sleeplock *lk)
{
    8020145e:	1101                	addi	sp,sp,-32
    80201460:	ec06                	sd	ra,24(sp)
    80201462:	e822                	sd	s0,16(sp)
    80201464:	e426                	sd	s1,8(sp)
    80201466:	e04a                	sd	s2,0(sp)
    80201468:	1000                	addi	s0,sp,32
    8020146a:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    8020146c:	00850913          	addi	s2,a0,8
    80201470:	854a                	mv	a0,s2
    80201472:	00000097          	auipc	ra,0x0
    80201476:	eb6080e7          	jalr	-330(ra) # 80201328 <acquire>
    while (lk->locked)
    8020147a:	409c                	lw	a5,0(s1)
    8020147c:	cb89                	beqz	a5,8020148e <acquiresleep+0x30>
        sleep(lk, &lk->lk);       /* releases lk->lk while asleep */
    8020147e:	85ca                	mv	a1,s2
    80201480:	8526                	mv	a0,s1
    80201482:	00001097          	auipc	ra,0x1
    80201486:	98a080e7          	jalr	-1654(ra) # 80201e0c <sleep>
    while (lk->locked)
    8020148a:	409c                	lw	a5,0(s1)
    8020148c:	fbed                	bnez	a5,8020147e <acquiresleep+0x20>
    lk->locked = 1;
    8020148e:	4785                	li	a5,1
    80201490:	c09c                	sw	a5,0(s1)
    lk->pid = myproc()->pid;
    80201492:	00000097          	auipc	ra,0x0
    80201496:	2d4080e7          	jalr	724(ra) # 80201766 <myproc>
    8020149a:	591c                	lw	a5,48(a0)
    8020149c:	d49c                	sw	a5,40(s1)
    release(&lk->lk);
    8020149e:	854a                	mv	a0,s2
    802014a0:	00000097          	auipc	ra,0x0
    802014a4:	f3c080e7          	jalr	-196(ra) # 802013dc <release>
}
    802014a8:	60e2                	ld	ra,24(sp)
    802014aa:	6442                	ld	s0,16(sp)
    802014ac:	64a2                	ld	s1,8(sp)
    802014ae:	6902                	ld	s2,0(sp)
    802014b0:	6105                	addi	sp,sp,32
    802014b2:	8082                	ret

00000000802014b4 <releasesleep>:

void releasesleep(struct sleeplock *lk)
{
    802014b4:	1101                	addi	sp,sp,-32
    802014b6:	ec06                	sd	ra,24(sp)
    802014b8:	e822                	sd	s0,16(sp)
    802014ba:	e426                	sd	s1,8(sp)
    802014bc:	e04a                	sd	s2,0(sp)
    802014be:	1000                	addi	s0,sp,32
    802014c0:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    802014c2:	00850913          	addi	s2,a0,8
    802014c6:	854a                	mv	a0,s2
    802014c8:	00000097          	auipc	ra,0x0
    802014cc:	e60080e7          	jalr	-416(ra) # 80201328 <acquire>
    lk->locked = 0;
    802014d0:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    802014d4:	0204a423          	sw	zero,40(s1)
    wakeup(lk);
    802014d8:	8526                	mv	a0,s1
    802014da:	00001097          	auipc	ra,0x1
    802014de:	ab8080e7          	jalr	-1352(ra) # 80201f92 <wakeup>
    release(&lk->lk);
    802014e2:	854a                	mv	a0,s2
    802014e4:	00000097          	auipc	ra,0x0
    802014e8:	ef8080e7          	jalr	-264(ra) # 802013dc <release>
}
    802014ec:	60e2                	ld	ra,24(sp)
    802014ee:	6442                	ld	s0,16(sp)
    802014f0:	64a2                	ld	s1,8(sp)
    802014f2:	6902                	ld	s2,0(sp)
    802014f4:	6105                	addi	sp,sp,32
    802014f6:	8082                	ret

00000000802014f8 <holdingsleep>:

int holdingsleep(struct sleeplock *lk)
{
    802014f8:	7179                	addi	sp,sp,-48
    802014fa:	f406                	sd	ra,40(sp)
    802014fc:	f022                	sd	s0,32(sp)
    802014fe:	ec26                	sd	s1,24(sp)
    80201500:	e84a                	sd	s2,16(sp)
    80201502:	1800                	addi	s0,sp,48
    80201504:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201506:	00850913          	addi	s2,a0,8
    8020150a:	854a                	mv	a0,s2
    8020150c:	00000097          	auipc	ra,0x0
    80201510:	e1c080e7          	jalr	-484(ra) # 80201328 <acquire>
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201514:	409c                	lw	a5,0(s1)
    80201516:	ef91                	bnez	a5,80201532 <holdingsleep+0x3a>
    80201518:	4481                	li	s1,0
    release(&lk->lk);
    8020151a:	854a                	mv	a0,s2
    8020151c:	00000097          	auipc	ra,0x0
    80201520:	ec0080e7          	jalr	-320(ra) # 802013dc <release>
    return r;
}
    80201524:	8526                	mv	a0,s1
    80201526:	70a2                	ld	ra,40(sp)
    80201528:	7402                	ld	s0,32(sp)
    8020152a:	64e2                	ld	s1,24(sp)
    8020152c:	6942                	ld	s2,16(sp)
    8020152e:	6145                	addi	sp,sp,48
    80201530:	8082                	ret
    80201532:	e44e                	sd	s3,8(sp)
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201534:	0284a983          	lw	s3,40(s1)
    80201538:	00000097          	auipc	ra,0x0
    8020153c:	22e080e7          	jalr	558(ra) # 80201766 <myproc>
    80201540:	5904                	lw	s1,48(a0)
    80201542:	413484b3          	sub	s1,s1,s3
    80201546:	0014b493          	seqz	s1,s1
    8020154a:	69a2                	ld	s3,8(sp)
    8020154c:	b7f9                	j	8020151a <holdingsleep+0x22>

000000008020154e <freeproc>:
        p->kstack = 0;
    }
}

static void freeproc(struct proc *p)
{
    8020154e:	1101                	addi	sp,sp,-32
    80201550:	ec06                	sd	ra,24(sp)
    80201552:	e822                	sd	s0,16(sp)
    80201554:	e426                	sd	s1,8(sp)
    80201556:	1000                	addi	s0,sp,32
    80201558:	84aa                	mv	s1,a0
    /* USYSINFO_VA is above p->sz; its backing page must be removed first. */
    usysinfo_free(p);
    8020155a:	00003097          	auipc	ra,0x3
    8020155e:	0da080e7          	jalr	218(ra) # 80204634 <usysinfo_free>
    if (p->tf) pfree((void *)p->tf);
    80201562:	6ca8                	ld	a0,88(s1)
    80201564:	c509                	beqz	a0,8020156e <freeproc+0x20>
    80201566:	00000097          	auipc	ra,0x0
    8020156a:	c44080e7          	jalr	-956(ra) # 802011aa <pfree>
    p->tf = 0;
    8020156e:	0404bc23          	sd	zero,88(s1)
    if (p->pagetable) uvmfree(p->pagetable, p->sz);
    80201572:	68a8                	ld	a0,80(s1)
    80201574:	c511                	beqz	a0,80201580 <freeproc+0x32>
    80201576:	64ac                	ld	a1,72(s1)
    80201578:	00002097          	auipc	ra,0x2
    8020157c:	8fe080e7          	jalr	-1794(ra) # 80202e76 <uvmfree>
    p->pagetable = 0;
    80201580:	0404b823          	sd	zero,80(s1)
    p->kstack = 0;              /* statically allocated - nothing to free */
    80201584:	0404b023          	sd	zero,64(s1)
    p->sz = 0; p->pid = 0; p->parent = 0;
    80201588:	0404b423          	sd	zero,72(s1)
    8020158c:	0204a823          	sw	zero,48(s1)
    80201590:	0204bc23          	sd	zero,56(s1)
    p->name[0] = 0; p->chan = 0; p->killed = 0; p->xstate = 0;
    80201594:	14048c23          	sb	zero,344(s1)
    80201598:	0204b023          	sd	zero,32(s1)
    8020159c:	0204a423          	sw	zero,40(s1)
    802015a0:	0204a623          	sw	zero,44(s1)
    p->trace_filter = 0;
    802015a4:	1604b423          	sd	zero,360(s1)
    p->syscall_count = 0; p->ctxsw_count = 0; p->state_gen = 0;
    802015a8:	1604bc23          	sd	zero,376(s1)
    802015ac:	1804b023          	sd	zero,384(s1)
    802015b0:	1804a423          	sw	zero,392(s1)
    p->state = UNUSED;
    802015b4:	0004ac23          	sw	zero,24(s1)
}
    802015b8:	60e2                	ld	ra,24(sp)
    802015ba:	6442                	ld	s0,16(sp)
    802015bc:	64a2                	ld	s1,8(sp)
    802015be:	6105                	addi	sp,sp,32
    802015c0:	8082                	ret

00000000802015c2 <allocproc>:
    }
    usertrapret();
}

static struct proc *allocproc(void)
{
    802015c2:	7179                	addi	sp,sp,-48
    802015c4:	f406                	sd	ra,40(sp)
    802015c6:	f022                	sd	s0,32(sp)
    802015c8:	ec26                	sd	s1,24(sp)
    802015ca:	e84a                	sd	s2,16(sp)
    802015cc:	1800                	addi	s0,sp,48
    struct proc *p;
    for (p = proc; p < &proc[NPROC]; p++) {
    802015ce:	0012a497          	auipc	s1,0x12a
    802015d2:	a3248493          	addi	s1,s1,-1486 # 8032b000 <proc>
    802015d6:	00130917          	auipc	s2,0x130
    802015da:	e2a90913          	addi	s2,s2,-470 # 80331400 <tickslock>
        acquire(&p->lock);
    802015de:	8526                	mv	a0,s1
    802015e0:	00000097          	auipc	ra,0x0
    802015e4:	d48080e7          	jalr	-696(ra) # 80201328 <acquire>
        if (p->state == UNUSED) goto found;
    802015e8:	4c9c                	lw	a5,24(s1)
    802015ea:	cf81                	beqz	a5,80201602 <allocproc+0x40>
        release(&p->lock);
    802015ec:	8526                	mv	a0,s1
    802015ee:	00000097          	auipc	ra,0x0
    802015f2:	dee080e7          	jalr	-530(ra) # 802013dc <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    802015f6:	19048493          	addi	s1,s1,400
    802015fa:	ff2492e3          	bne	s1,s2,802015de <allocproc+0x1c>
    }
    return 0;
    802015fe:	4481                	li	s1,0
    80201600:	a0dd                	j	802016e6 <allocproc+0x124>
    80201602:	e44e                	sd	s3,8(sp)
    acquire(&pid_lock);
    80201604:	00029997          	auipc	s3,0x29
    80201608:	9fc98993          	addi	s3,s3,-1540 # 8022a000 <pid_lock>
    8020160c:	854e                	mv	a0,s3
    8020160e:	00000097          	auipc	ra,0x0
    80201612:	d1a080e7          	jalr	-742(ra) # 80201328 <acquire>
    int pid = nextpid++;
    80201616:	00007797          	auipc	a5,0x7
    8020161a:	9f278793          	addi	a5,a5,-1550 # 80208008 <nextpid>
    8020161e:	0007a903          	lw	s2,0(a5)
    80201622:	0019071b          	addiw	a4,s2,1
    80201626:	c398                	sw	a4,0(a5)
    release(&pid_lock);
    80201628:	854e                	mv	a0,s3
    8020162a:	00000097          	auipc	ra,0x0
    8020162e:	db2080e7          	jalr	-590(ra) # 802013dc <release>

found:
    p->pid    = allocpid();
    80201632:	0324a823          	sw	s2,48(s1)
    p->state  = USED;
    80201636:	4785                	li	a5,1
    80201638:	cc9c                	sw	a5,24(s1)
    p->killed = 0;
    8020163a:	0204a423          	sw	zero,40(s1)
    p->xstate = 0;
    8020163e:	0204a623          	sw	zero,44(s1)
    p->chan   = 0;
    80201642:	0204b023          	sd	zero,32(s1)
    p->trace_filter = 0;
    80201646:	1604b423          	sd	zero,360(s1)
    p->usysinfo = 0;
    8020164a:	1604b823          	sd	zero,368(s1)
    p->syscall_count = 0;
    8020164e:	1604bc23          	sd	zero,376(s1)
    p->ctxsw_count = 0;
    80201652:	1804b023          	sd	zero,384(s1)
    p->state_gen = 0;
    80201656:	1804a423          	sw	zero,392(s1)

    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    8020165a:	00000097          	auipc	ra,0x0
    8020165e:	a40080e7          	jalr	-1472(ra) # 8020109a <palloc>
    80201662:	892a                	mv	s2,a0
    80201664:	eca8                	sd	a0,88(s1)
    80201666:	c559                	beqz	a0,802016f4 <allocproc+0x132>

    /* Contiguous, statically reserved. See the note at the top of this file. */
    p->kstack = (uint64)kstacks[p - proc];
    80201668:	0012a797          	auipc	a5,0x12a
    8020166c:	99878793          	addi	a5,a5,-1640 # 8032b000 <proc>
    80201670:	40f487b3          	sub	a5,s1,a5
    80201674:	4047d713          	srai	a4,a5,0x4
    80201678:	ff8f67b7          	lui	a5,0xff8f6
    8020167c:	c2978793          	addi	a5,a5,-983 # ffffffffff8f5c29 <uart+0xffffffff7f5abbf9>
    80201680:	07be                	slli	a5,a5,0xf
    80201682:	ae178793          	addi	a5,a5,-1311
    80201686:	07b2                	slli	a5,a5,0xc
    80201688:	47b78793          	addi	a5,a5,1147
    8020168c:	07b6                	slli	a5,a5,0xd
    8020168e:	c2978793          	addi	a5,a5,-983
    80201692:	02f707b3          	mul	a5,a4,a5
    80201696:	07ba                	slli	a5,a5,0xe
    80201698:	0002a717          	auipc	a4,0x2a
    8020169c:	96870713          	addi	a4,a4,-1688 # 8022b000 <kstacks>
    802016a0:	97ba                	add	a5,a5,a4
    802016a2:	e0bc                	sd	a5,64(s1)

    p->pagetable = uvmcreate();
    802016a4:	00001097          	auipc	ra,0x1
    802016a8:	712080e7          	jalr	1810(ra) # 80202db6 <uvmcreate>
    802016ac:	892a                	mv	s2,a0
    802016ae:	e8a8                	sd	a0,80(s1)
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    802016b0:	cd39                	beqz	a0,8020170e <allocproc+0x14c>
    if (usysinfo_setup(p) < 0) { freeproc(p); release(&p->lock); return 0; }
    802016b2:	8526                	mv	a0,s1
    802016b4:	00003097          	auipc	ra,0x3
    802016b8:	f16080e7          	jalr	-234(ra) # 802045ca <usysinfo_setup>
    802016bc:	06054663          	bltz	a0,80201728 <allocproc+0x166>

    memset(&p->context, 0, sizeof(p->context));
    802016c0:	07000613          	li	a2,112
    802016c4:	4581                	li	a1,0
    802016c6:	06048513          	addi	a0,s1,96
    802016ca:	fffff097          	auipc	ra,0xfffff
    802016ce:	fce080e7          	jalr	-50(ra) # 80200698 <memset>
    p->context.ra = (uint64)forkret;
    802016d2:	00000797          	auipc	a5,0x0
    802016d6:	0d078793          	addi	a5,a5,208 # 802017a2 <forkret>
    802016da:	f0bc                	sd	a5,96(s1)
    p->context.sp = p->kstack + KSTACK_SIZE;
    802016dc:	60bc                	ld	a5,64(s1)
    802016de:	6711                	lui	a4,0x4
    802016e0:	97ba                	add	a5,a5,a4
    802016e2:	f4bc                	sd	a5,104(s1)
    802016e4:	69a2                	ld	s3,8(sp)
    return p;
}
    802016e6:	8526                	mv	a0,s1
    802016e8:	70a2                	ld	ra,40(sp)
    802016ea:	7402                	ld	s0,32(sp)
    802016ec:	64e2                	ld	s1,24(sp)
    802016ee:	6942                	ld	s2,16(sp)
    802016f0:	6145                	addi	sp,sp,48
    802016f2:	8082                	ret
    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    802016f4:	8526                	mv	a0,s1
    802016f6:	00000097          	auipc	ra,0x0
    802016fa:	e58080e7          	jalr	-424(ra) # 8020154e <freeproc>
    802016fe:	8526                	mv	a0,s1
    80201700:	00000097          	auipc	ra,0x0
    80201704:	cdc080e7          	jalr	-804(ra) # 802013dc <release>
    80201708:	84ca                	mv	s1,s2
    8020170a:	69a2                	ld	s3,8(sp)
    8020170c:	bfe9                	j	802016e6 <allocproc+0x124>
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    8020170e:	8526                	mv	a0,s1
    80201710:	00000097          	auipc	ra,0x0
    80201714:	e3e080e7          	jalr	-450(ra) # 8020154e <freeproc>
    80201718:	8526                	mv	a0,s1
    8020171a:	00000097          	auipc	ra,0x0
    8020171e:	cc2080e7          	jalr	-830(ra) # 802013dc <release>
    80201722:	84ca                	mv	s1,s2
    80201724:	69a2                	ld	s3,8(sp)
    80201726:	b7c1                	j	802016e6 <allocproc+0x124>
    if (usysinfo_setup(p) < 0) { freeproc(p); release(&p->lock); return 0; }
    80201728:	8526                	mv	a0,s1
    8020172a:	00000097          	auipc	ra,0x0
    8020172e:	e24080e7          	jalr	-476(ra) # 8020154e <freeproc>
    80201732:	8526                	mv	a0,s1
    80201734:	00000097          	auipc	ra,0x0
    80201738:	ca8080e7          	jalr	-856(ra) # 802013dc <release>
    8020173c:	4481                	li	s1,0
    8020173e:	69a2                	ld	s3,8(sp)
    80201740:	b75d                	j	802016e6 <allocproc+0x124>

0000000080201742 <mycpu>:
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201742:	1141                	addi	sp,sp,-16
    80201744:	e406                	sd	ra,8(sp)
    80201746:	e022                	sd	s0,0(sp)
    80201748:	0800                	addi	s0,sp,16
    8020174a:	00005097          	auipc	ra,0x5
    8020174e:	064080e7          	jalr	100(ra) # 802067ae <hal_hart_id>
    80201752:	051e                	slli	a0,a0,0x7
    80201754:	00029797          	auipc	a5,0x29
    80201758:	8c478793          	addi	a5,a5,-1852 # 8022a018 <cpus>
    8020175c:	953e                	add	a0,a0,a5
    8020175e:	60a2                	ld	ra,8(sp)
    80201760:	6402                	ld	s0,0(sp)
    80201762:	0141                	addi	sp,sp,16
    80201764:	8082                	ret

0000000080201766 <myproc>:
{
    80201766:	1101                	addi	sp,sp,-32
    80201768:	ec06                	sd	ra,24(sp)
    8020176a:	e822                	sd	s0,16(sp)
    8020176c:	e426                	sd	s1,8(sp)
    8020176e:	1000                	addi	s0,sp,32
    push_off();
    80201770:	00000097          	auipc	ra,0x0
    80201774:	b80080e7          	jalr	-1152(ra) # 802012f0 <push_off>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201778:	00005097          	auipc	ra,0x5
    8020177c:	036080e7          	jalr	54(ra) # 802067ae <hal_hart_id>
    struct proc *p = mycpu()->proc;
    80201780:	051e                	slli	a0,a0,0x7
    80201782:	00029797          	auipc	a5,0x29
    80201786:	87e78793          	addi	a5,a5,-1922 # 8022a000 <pid_lock>
    8020178a:	97aa                	add	a5,a5,a0
    8020178c:	6f84                	ld	s1,24(a5)
    pop_off();
    8020178e:	00000097          	auipc	ra,0x0
    80201792:	bee080e7          	jalr	-1042(ra) # 8020137c <pop_off>
}
    80201796:	8526                	mv	a0,s1
    80201798:	60e2                	ld	ra,24(sp)
    8020179a:	6442                	ld	s0,16(sp)
    8020179c:	64a2                	ld	s1,8(sp)
    8020179e:	6105                	addi	sp,sp,32
    802017a0:	8082                	ret

00000000802017a2 <forkret>:
{
    802017a2:	1101                	addi	sp,sp,-32
    802017a4:	ec06                	sd	ra,24(sp)
    802017a6:	e822                	sd	s0,16(sp)
    802017a8:	1000                	addi	s0,sp,32
    release(&myproc()->lock);
    802017aa:	00000097          	auipc	ra,0x0
    802017ae:	fbc080e7          	jalr	-68(ra) # 80201766 <myproc>
    802017b2:	00000097          	auipc	ra,0x0
    802017b6:	c2a080e7          	jalr	-982(ra) # 802013dc <release>
    if (first) {
    802017ba:	00007797          	auipc	a5,0x7
    802017be:	84a7a783          	lw	a5,-1974(a5) # 80208004 <first.1>
    802017c2:	eb89                	bnez	a5,802017d4 <forkret+0x32>
    usertrapret();
    802017c4:	00001097          	auipc	ra,0x1
    802017c8:	e6e080e7          	jalr	-402(ra) # 80202632 <usertrapret>
}
    802017cc:	60e2                	ld	ra,24(sp)
    802017ce:	6442                	ld	s0,16(sp)
    802017d0:	6105                	addi	sp,sp,32
    802017d2:	8082                	ret
    802017d4:	e426                	sd	s1,8(sp)
        first = 0;
    802017d6:	00007797          	auipc	a5,0x7
    802017da:	8207a723          	sw	zero,-2002(a5) # 80208004 <first.1>
        fsinit(ROOTDEV);
    802017de:	4501                	li	a0,0
    802017e0:	00004097          	auipc	ra,0x4
    802017e4:	c0c080e7          	jalr	-1012(ra) # 802053ec <fsinit>
        myproc()->cwd = namei("/");
    802017e8:	00000097          	auipc	ra,0x0
    802017ec:	f7e080e7          	jalr	-130(ra) # 80201766 <myproc>
    802017f0:	84aa                	mv	s1,a0
    802017f2:	00006517          	auipc	a0,0x6
    802017f6:	cb650513          	addi	a0,a0,-842 # 802074a8 <etext+0x4a8>
    802017fa:	00004097          	auipc	ra,0x4
    802017fe:	786080e7          	jalr	1926(ra) # 80205f80 <namei>
    80201802:	14a4b823          	sd	a0,336(s1)
        __sync_synchronize();
    80201806:	0ff0000f          	fence
    8020180a:	64a2                	ld	s1,8(sp)
    8020180c:	bf65                	j	802017c4 <forkret+0x22>

000000008020180e <procinit>:
{
    8020180e:	7179                	addi	sp,sp,-48
    80201810:	f406                	sd	ra,40(sp)
    80201812:	f022                	sd	s0,32(sp)
    80201814:	ec26                	sd	s1,24(sp)
    80201816:	e84a                	sd	s2,16(sp)
    80201818:	e44e                	sd	s3,8(sp)
    8020181a:	1800                	addi	s0,sp,48
    initlock(&pid_lock,  "nextpid");
    8020181c:	00006597          	auipc	a1,0x6
    80201820:	c9458593          	addi	a1,a1,-876 # 802074b0 <etext+0x4b0>
    80201824:	00028517          	auipc	a0,0x28
    80201828:	7dc50513          	addi	a0,a0,2012 # 8022a000 <pid_lock>
    8020182c:	00000097          	auipc	ra,0x0
    80201830:	a80080e7          	jalr	-1408(ra) # 802012ac <initlock>
    initlock(&wait_lock, "wait_lock");
    80201834:	00006597          	auipc	a1,0x6
    80201838:	c8458593          	addi	a1,a1,-892 # 802074b8 <etext+0x4b8>
    8020183c:	00029517          	auipc	a0,0x29
    80201840:	bdc50513          	addi	a0,a0,-1060 # 8022a418 <wait_lock>
    80201844:	00000097          	auipc	ra,0x0
    80201848:	a68080e7          	jalr	-1432(ra) # 802012ac <initlock>
    initlock(&tickslock, "time");
    8020184c:	00006597          	auipc	a1,0x6
    80201850:	c7c58593          	addi	a1,a1,-900 # 802074c8 <etext+0x4c8>
    80201854:	00130517          	auipc	a0,0x130
    80201858:	bac50513          	addi	a0,a0,-1108 # 80331400 <tickslock>
    8020185c:	00000097          	auipc	ra,0x0
    80201860:	a50080e7          	jalr	-1456(ra) # 802012ac <initlock>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201864:	00129497          	auipc	s1,0x129
    80201868:	79c48493          	addi	s1,s1,1948 # 8032b000 <proc>
        initlock(&p->lock, "proc");
    8020186c:	00006997          	auipc	s3,0x6
    80201870:	c6498993          	addi	s3,s3,-924 # 802074d0 <etext+0x4d0>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201874:	00130917          	auipc	s2,0x130
    80201878:	b8c90913          	addi	s2,s2,-1140 # 80331400 <tickslock>
        initlock(&p->lock, "proc");
    8020187c:	85ce                	mv	a1,s3
    8020187e:	8526                	mv	a0,s1
    80201880:	00000097          	auipc	ra,0x0
    80201884:	a2c080e7          	jalr	-1492(ra) # 802012ac <initlock>
        p->state  = UNUSED;
    80201888:	0004ac23          	sw	zero,24(s1)
        p->kstack = 0;
    8020188c:	0404b023          	sd	zero,64(s1)
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201890:	19048493          	addi	s1,s1,400
    80201894:	ff2494e3          	bne	s1,s2,8020187c <procinit+0x6e>
}
    80201898:	70a2                	ld	ra,40(sp)
    8020189a:	7402                	ld	s0,32(sp)
    8020189c:	64e2                	ld	s1,24(sp)
    8020189e:	6942                	ld	s2,16(sp)
    802018a0:	69a2                	ld	s3,8(sp)
    802018a2:	6145                	addi	sp,sp,48
    802018a4:	8082                	ret

00000000802018a6 <userinit>:

/* --- the very first user process, built by hand --- */
extern char _binary_user_initcode_start[], _binary_user_initcode_end[];

void userinit(void)
{
    802018a6:	7179                	addi	sp,sp,-48
    802018a8:	f406                	sd	ra,40(sp)
    802018aa:	f022                	sd	s0,32(sp)
    802018ac:	ec26                	sd	s1,24(sp)
    802018ae:	e84a                	sd	s2,16(sp)
    802018b0:	e44e                	sd	s3,8(sp)
    802018b2:	1800                	addi	s0,sp,48
    struct proc *p = allocproc();
    802018b4:	00000097          	auipc	ra,0x0
    802018b8:	d0e080e7          	jalr	-754(ra) # 802015c2 <allocproc>
    if (!p) panic("userinit: allocproc failed");
    802018bc:	c569                	beqz	a0,80201986 <userinit+0xe0>
    802018be:	84aa                	mv	s1,a0
    initproc = p;
    802018c0:	00148797          	auipc	a5,0x148
    802018c4:	74a7b823          	sd	a0,1872(a5) # 8034a010 <initproc>

    uint64 sz = (uint64)(_binary_user_initcode_end - _binary_user_initcode_start);
    802018c8:	00006997          	auipc	s3,0x6
    802018cc:	6b898993          	addi	s3,s3,1720 # 80207f80 <_binary_user_initcode_end>
    802018d0:	00006797          	auipc	a5,0x6
    802018d4:	67878793          	addi	a5,a5,1656 # 80207f48 <_binary_user_initcode_start>
    802018d8:	40f989b3          	sub	s3,s3,a5
    if (sz > PGSIZE) panic("userinit: initcode too big");
    802018dc:	6785                	lui	a5,0x1
    802018de:	0b37ec63          	bltu	a5,s3,80201996 <userinit+0xf0>

    char *mem = palloc();
    802018e2:	fffff097          	auipc	ra,0xfffff
    802018e6:	7b8080e7          	jalr	1976(ra) # 8020109a <palloc>
    802018ea:	892a                	mv	s2,a0
    memset(mem, 0, PGSIZE);
    802018ec:	6605                	lui	a2,0x1
    802018ee:	4581                	li	a1,0
    802018f0:	fffff097          	auipc	ra,0xfffff
    802018f4:	da8080e7          	jalr	-600(ra) # 80200698 <memset>
    memmove(mem, _binary_user_initcode_start, sz);
    802018f8:	864e                	mv	a2,s3
    802018fa:	00006597          	auipc	a1,0x6
    802018fe:	64e58593          	addi	a1,a1,1614 # 80207f48 <_binary_user_initcode_start>
    80201902:	854a                	mv	a0,s2
    80201904:	fffff097          	auipc	ra,0xfffff
    80201908:	db0080e7          	jalr	-592(ra) # 802006b4 <memmove>
    mappages(p->pagetable, 0, PGSIZE, (uint64)mem, PTE_R | PTE_W | PTE_X | PTE_U);
    8020190c:	4779                	li	a4,30
    8020190e:	86ca                	mv	a3,s2
    80201910:	6605                	lui	a2,0x1
    80201912:	4581                	li	a1,0
    80201914:	68a8                	ld	a0,80(s1)
    80201916:	00001097          	auipc	ra,0x1
    8020191a:	28e080e7          	jalr	654(ra) # 80202ba4 <mappages>

    char *stack = palloc();
    8020191e:	fffff097          	auipc	ra,0xfffff
    80201922:	77c080e7          	jalr	1916(ra) # 8020109a <palloc>
    80201926:	892a                	mv	s2,a0
    memset(stack, 0, PGSIZE);
    80201928:	6605                	lui	a2,0x1
    8020192a:	4581                	li	a1,0
    8020192c:	fffff097          	auipc	ra,0xfffff
    80201930:	d6c080e7          	jalr	-660(ra) # 80200698 <memset>
    mappages(p->pagetable, PGSIZE, PGSIZE, (uint64)stack, PTE_R | PTE_W | PTE_U);
    80201934:	4759                	li	a4,22
    80201936:	86ca                	mv	a3,s2
    80201938:	6605                	lui	a2,0x1
    8020193a:	6585                	lui	a1,0x1
    8020193c:	68a8                	ld	a0,80(s1)
    8020193e:	00001097          	auipc	ra,0x1
    80201942:	266080e7          	jalr	614(ra) # 80202ba4 <mappages>

    p->sz       = 2 * PGSIZE;
    80201946:	6789                	lui	a5,0x2
    80201948:	e4bc                	sd	a5,72(s1)
    p->tf->epc  = 0;                    /* start at the first byte of initcode */
    8020194a:	6cb8                	ld	a4,88(s1)
    8020194c:	00073c23          	sd	zero,24(a4) # 4018 <_entry-0x801fbfe8>
    p->tf->sp   = 2 * PGSIZE;           /* stack grows down from the top       */
    80201950:	6cb8                	ld	a4,88(s1)
    80201952:	fb1c                	sd	a5,48(a4)
    strncpy(p->name, "initcode", sizeof(p->name));
    80201954:	4641                	li	a2,16
    80201956:	00006597          	auipc	a1,0x6
    8020195a:	bc258593          	addi	a1,a1,-1086 # 80207518 <etext+0x518>
    8020195e:	15848513          	addi	a0,s1,344
    80201962:	fffff097          	auipc	ra,0xfffff
    80201966:	df8080e7          	jalr	-520(ra) # 8020075a <strncpy>
    /* p->cwd is set by forkret once the filesystem is initialized. */
    p->state    = RUNNABLE;
    8020196a:	478d                	li	a5,3
    8020196c:	cc9c                	sw	a5,24(s1)
    release(&p->lock);
    8020196e:	8526                	mv	a0,s1
    80201970:	00000097          	auipc	ra,0x0
    80201974:	a6c080e7          	jalr	-1428(ra) # 802013dc <release>
}
    80201978:	70a2                	ld	ra,40(sp)
    8020197a:	7402                	ld	s0,32(sp)
    8020197c:	64e2                	ld	s1,24(sp)
    8020197e:	6942                	ld	s2,16(sp)
    80201980:	69a2                	ld	s3,8(sp)
    80201982:	6145                	addi	sp,sp,48
    80201984:	8082                	ret
    if (!p) panic("userinit: allocproc failed");
    80201986:	00006517          	auipc	a0,0x6
    8020198a:	b5250513          	addi	a0,a0,-1198 # 802074d8 <etext+0x4d8>
    8020198e:	fffff097          	auipc	ra,0xfffff
    80201992:	c64080e7          	jalr	-924(ra) # 802005f2 <panic>
    if (sz > PGSIZE) panic("userinit: initcode too big");
    80201996:	00006517          	auipc	a0,0x6
    8020199a:	b6250513          	addi	a0,a0,-1182 # 802074f8 <etext+0x4f8>
    8020199e:	fffff097          	auipc	ra,0xfffff
    802019a2:	c54080e7          	jalr	-940(ra) # 802005f2 <panic>

00000000802019a6 <growproc>:

int growproc(int n)
{
    802019a6:	7139                	addi	sp,sp,-64
    802019a8:	fc06                	sd	ra,56(sp)
    802019aa:	f822                	sd	s0,48(sp)
    802019ac:	ec4e                	sd	s3,24(sp)
    802019ae:	e456                	sd	s5,8(sp)
    802019b0:	e05a                	sd	s6,0(sp)
    802019b2:	0080                	addi	s0,sp,64
    802019b4:	8aaa                	mv	s5,a0
    struct proc *p = myproc();
    802019b6:	00000097          	auipc	ra,0x0
    802019ba:	db0080e7          	jalr	-592(ra) # 80201766 <myproc>
    802019be:	89aa                	mv	s3,a0
    uint64 sz = p->sz;
    802019c0:	04853b03          	ld	s6,72(a0)

    if (n > 0) {
    802019c4:	07505e63          	blez	s5,80201a40 <growproc+0x9a>
    802019c8:	e852                	sd	s4,16(sp)
        uint64 newsz = sz + (uint64)n;
    802019ca:	016a8a33          	add	s4,s5,s6
        /* Lab 3 reserves the top user page for USYSINFO. Do not let sbrk()
         * grow the ordinary process image into that fixed mapping. */
        if (newsz < sz || newsz > USYSINFO_VA)
    802019ce:	0d6a6263          	bltu	s4,s6,80201a92 <growproc+0xec>
    802019d2:	7ffff7b7          	lui	a5,0x7ffff
    802019d6:	0d47e163          	bltu	a5,s4,80201a98 <growproc+0xf2>
    802019da:	f04a                	sd	s2,32(sp)
            return -1;
        for (uint64 a = PGROUNDUP(sz); a < newsz; a += PGSIZE) {
    802019dc:	6905                	lui	s2,0x1
    802019de:	197d                	addi	s2,s2,-1 # fff <_entry-0x801ff001>
    802019e0:	995a                	add	s2,s2,s6
    802019e2:	77fd                	lui	a5,0xfffff
    802019e4:	00f97933          	and	s2,s2,a5
    802019e8:	0b497263          	bgeu	s2,s4,80201a8c <growproc+0xe6>
    802019ec:	f426                	sd	s1,40(sp)
            char *mem = palloc();
    802019ee:	fffff097          	auipc	ra,0xfffff
    802019f2:	6ac080e7          	jalr	1708(ra) # 8020109a <palloc>
    802019f6:	84aa                	mv	s1,a0
            if (!mem) return -1;
    802019f8:	c15d                	beqz	a0,80201a9e <growproc+0xf8>
            memset(mem, 0, PGSIZE);
    802019fa:	6605                	lui	a2,0x1
    802019fc:	4581                	li	a1,0
    802019fe:	fffff097          	auipc	ra,0xfffff
    80201a02:	c9a080e7          	jalr	-870(ra) # 80200698 <memset>
            if (mappages(p->pagetable, a, PGSIZE, (uint64)mem,
    80201a06:	4759                	li	a4,22
    80201a08:	86a6                	mv	a3,s1
    80201a0a:	6605                	lui	a2,0x1
    80201a0c:	85ca                	mv	a1,s2
    80201a0e:	0509b503          	ld	a0,80(s3)
    80201a12:	00001097          	auipc	ra,0x1
    80201a16:	192080e7          	jalr	402(ra) # 80202ba4 <mappages>
    80201a1a:	e909                	bnez	a0,80201a2c <growproc+0x86>
        for (uint64 a = PGROUNDUP(sz); a < newsz; a += PGSIZE) {
    80201a1c:	6785                	lui	a5,0x1
    80201a1e:	993e                	add	s2,s2,a5
    80201a20:	fd4967e3          	bltu	s2,s4,802019ee <growproc+0x48>
    80201a24:	74a2                	ld	s1,40(sp)
    80201a26:	7902                	ld	s2,32(sp)
    80201a28:	6a42                	ld	s4,16(sp)
    80201a2a:	a829                	j	80201a44 <growproc+0x9e>
                         PTE_R | PTE_W | PTE_U) != 0) {
                pfree(mem);
    80201a2c:	8526                	mv	a0,s1
    80201a2e:	fffff097          	auipc	ra,0xfffff
    80201a32:	77c080e7          	jalr	1916(ra) # 802011aa <pfree>
                return -1;
    80201a36:	557d                	li	a0,-1
    80201a38:	74a2                	ld	s1,40(sp)
    80201a3a:	7902                	ld	s2,32(sp)
    80201a3c:	6a42                	ld	s4,16(sp)
    80201a3e:	a039                	j	80201a4c <growproc+0xa6>
            }
        }
    } else if (n < 0) {
    80201a40:	000acd63          	bltz	s5,80201a5a <growproc+0xb4>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
        sz = newsz;
        p->sz = sz;
        return 0;
    }
    p->sz = sz + n;
    80201a44:	9ada                	add	s5,s5,s6
    80201a46:	0559b423          	sd	s5,72(s3)
    return 0;
    80201a4a:	4501                	li	a0,0
}
    80201a4c:	70e2                	ld	ra,56(sp)
    80201a4e:	7442                	ld	s0,48(sp)
    80201a50:	69e2                	ld	s3,24(sp)
    80201a52:	6aa2                	ld	s5,8(sp)
    80201a54:	6b02                	ld	s6,0(sp)
    80201a56:	6121                	addi	sp,sp,64
    80201a58:	8082                	ret
        uint64 newsz = sz + n;
    80201a5a:	9ada                	add	s5,s5,s6
        if (PGROUNDUP(newsz) < PGROUNDUP(sz))
    80201a5c:	6785                	lui	a5,0x1
    80201a5e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80201a60:	00fa85b3          	add	a1,s5,a5
    80201a64:	777d                	lui	a4,0xfffff
    80201a66:	8df9                	and	a1,a1,a4
    80201a68:	97da                	add	a5,a5,s6
    80201a6a:	8ff9                	and	a5,a5,a4
    80201a6c:	00f5e663          	bltu	a1,a5,80201a78 <growproc+0xd2>
        p->sz = sz;
    80201a70:	0559b423          	sd	s5,72(s3)
        return 0;
    80201a74:	4501                	li	a0,0
    80201a76:	bfd9                	j	80201a4c <growproc+0xa6>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
    80201a78:	8f8d                	sub	a5,a5,a1
            uvmunmap(p->pagetable, PGROUNDUP(newsz),
    80201a7a:	4685                	li	a3,1
    80201a7c:	00c7d613          	srli	a2,a5,0xc
    80201a80:	6928                	ld	a0,80(a0)
    80201a82:	00001097          	auipc	ra,0x1
    80201a86:	380080e7          	jalr	896(ra) # 80202e02 <uvmunmap>
    80201a8a:	b7dd                	j	80201a70 <growproc+0xca>
    80201a8c:	7902                	ld	s2,32(sp)
    80201a8e:	6a42                	ld	s4,16(sp)
    80201a90:	bf55                	j	80201a44 <growproc+0x9e>
            return -1;
    80201a92:	557d                	li	a0,-1
    80201a94:	6a42                	ld	s4,16(sp)
    80201a96:	bf5d                	j	80201a4c <growproc+0xa6>
    80201a98:	557d                	li	a0,-1
    80201a9a:	6a42                	ld	s4,16(sp)
    80201a9c:	bf45                	j	80201a4c <growproc+0xa6>
            if (!mem) return -1;
    80201a9e:	557d                	li	a0,-1
    80201aa0:	74a2                	ld	s1,40(sp)
    80201aa2:	7902                	ld	s2,32(sp)
    80201aa4:	6a42                	ld	s4,16(sp)
    80201aa6:	b75d                	j	80201a4c <growproc+0xa6>

0000000080201aa8 <fork>:

int fork(void)
{
    80201aa8:	7139                	addi	sp,sp,-64
    80201aaa:	fc06                	sd	ra,56(sp)
    80201aac:	f822                	sd	s0,48(sp)
    80201aae:	f04a                	sd	s2,32(sp)
    80201ab0:	e456                	sd	s5,8(sp)
    80201ab2:	0080                	addi	s0,sp,64
    struct proc *parent = myproc();
    80201ab4:	00000097          	auipc	ra,0x0
    80201ab8:	cb2080e7          	jalr	-846(ra) # 80201766 <myproc>
    80201abc:	8aaa                	mv	s5,a0
    struct proc *np = allocproc();
    80201abe:	00000097          	auipc	ra,0x0
    80201ac2:	b04080e7          	jalr	-1276(ra) # 802015c2 <allocproc>
    if (!np) return -1;
    80201ac6:	12050663          	beqz	a0,80201bf2 <fork+0x14a>
    80201aca:	ec4e                	sd	s3,24(sp)
    80201acc:	89aa                	mv	s3,a0

    /* EAGER COPY: every user page is duplicated, right now. Simple, correct,
     * and O(memory) even for fork+exec - which is why Lab 5 replaces this
     * with copy-on-write. Do not bring COW forward; the graders diff it. */
    if (uvmcopy(parent->pagetable, np->pagetable, parent->sz) < 0) {
    80201ace:	048ab603          	ld	a2,72(s5)
    80201ad2:	692c                	ld	a1,80(a0)
    80201ad4:	050ab503          	ld	a0,80(s5)
    80201ad8:	00001097          	auipc	ra,0x1
    80201adc:	3da080e7          	jalr	986(ra) # 80202eb2 <uvmcopy>
    80201ae0:	04054a63          	bltz	a0,80201b34 <fork+0x8c>
    80201ae4:	f426                	sd	s1,40(sp)
    80201ae6:	e852                	sd	s4,16(sp)
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = parent->sz;
    80201ae8:	048ab783          	ld	a5,72(s5)
    80201aec:	04f9b423          	sd	a5,72(s3)
    *(np->tf) = *(parent->tf);
    80201af0:	058ab683          	ld	a3,88(s5)
    80201af4:	87b6                	mv	a5,a3
    80201af6:	0589b703          	ld	a4,88(s3)
    80201afa:	12068693          	addi	a3,a3,288
    80201afe:	0007b803          	ld	a6,0(a5)
    80201b02:	6788                	ld	a0,8(a5)
    80201b04:	6b8c                	ld	a1,16(a5)
    80201b06:	6f90                	ld	a2,24(a5)
    80201b08:	01073023          	sd	a6,0(a4) # fffffffffffff000 <uart+0xffffffff7fcb4fd0>
    80201b0c:	e708                	sd	a0,8(a4)
    80201b0e:	eb0c                	sd	a1,16(a4)
    80201b10:	ef10                	sd	a2,24(a4)
    80201b12:	02078793          	addi	a5,a5,32
    80201b16:	02070713          	addi	a4,a4,32
    80201b1a:	fed792e3          	bne	a5,a3,80201afe <fork+0x56>
    np->tf->a0 = 0;                 /* the child sees fork() return 0 */
    80201b1e:	0589b783          	ld	a5,88(s3)
    80201b22:	0607b823          	sd	zero,112(a5)

    /* The child INHERITS the parent's open files and cwd - this is what makes
     * `cmd > file` work: the shell redirects, then forks, and the child keeps
     * the redirected descriptor. Same struct file, same offset. */
    for (int i = 0; i < NOFILE; i++)
    80201b26:	0d0a8493          	addi	s1,s5,208
    80201b2a:	0d098913          	addi	s2,s3,208
    80201b2e:	150a8a13          	addi	s4,s5,336
    80201b32:	a015                	j	80201b56 <fork+0xae>
        freeproc(np);
    80201b34:	854e                	mv	a0,s3
    80201b36:	00000097          	auipc	ra,0x0
    80201b3a:	a18080e7          	jalr	-1512(ra) # 8020154e <freeproc>
        release(&np->lock);
    80201b3e:	854e                	mv	a0,s3
    80201b40:	00000097          	auipc	ra,0x0
    80201b44:	89c080e7          	jalr	-1892(ra) # 802013dc <release>
        return -1;
    80201b48:	597d                	li	s2,-1
    80201b4a:	69e2                	ld	s3,24(sp)
    80201b4c:	a861                	j	80201be4 <fork+0x13c>
    for (int i = 0; i < NOFILE; i++)
    80201b4e:	04a1                	addi	s1,s1,8
    80201b50:	0921                	addi	s2,s2,8
    80201b52:	01448b63          	beq	s1,s4,80201b68 <fork+0xc0>
        if (parent->ofile[i])
    80201b56:	6088                	ld	a0,0(s1)
    80201b58:	d97d                	beqz	a0,80201b4e <fork+0xa6>
            np->ofile[i] = filedup(parent->ofile[i]);
    80201b5a:	00004097          	auipc	ra,0x4
    80201b5e:	4f2080e7          	jalr	1266(ra) # 8020604c <filedup>
    80201b62:	00a93023          	sd	a0,0(s2)
    80201b66:	b7e5                	j	80201b4e <fork+0xa6>
    np->cwd = idup(parent->cwd);
    80201b68:	150ab503          	ld	a0,336(s5)
    80201b6c:	00004097          	auipc	ra,0x4
    80201b70:	b42080e7          	jalr	-1214(ra) # 802056ae <idup>
    80201b74:	14a9b823          	sd	a0,336(s3)

    strncpy(np->name, parent->name, sizeof(np->name));
    80201b78:	4641                	li	a2,16
    80201b7a:	158a8593          	addi	a1,s5,344
    80201b7e:	15898513          	addi	a0,s3,344
    80201b82:	fffff097          	auipc	ra,0xfffff
    80201b86:	bd8080e7          	jalr	-1064(ra) # 8020075a <strncpy>
    trace_fork(parent, np);          /* completed Lab 2 semantics */
    80201b8a:	85ce                	mv	a1,s3
    80201b8c:	8556                	mv	a0,s5
    80201b8e:	00003097          	auipc	ra,0x3
    80201b92:	a28080e7          	jalr	-1496(ra) # 802045b6 <trace_fork>
    int pid = np->pid;
    80201b96:	0309a903          	lw	s2,48(s3)
    release(&np->lock);
    80201b9a:	854e                	mv	a0,s3
    80201b9c:	00000097          	auipc	ra,0x0
    80201ba0:	840080e7          	jalr	-1984(ra) # 802013dc <release>

    acquire(&wait_lock);
    80201ba4:	00029497          	auipc	s1,0x29
    80201ba8:	87448493          	addi	s1,s1,-1932 # 8022a418 <wait_lock>
    80201bac:	8526                	mv	a0,s1
    80201bae:	fffff097          	auipc	ra,0xfffff
    80201bb2:	77a080e7          	jalr	1914(ra) # 80201328 <acquire>
    np->parent = parent;
    80201bb6:	0359bc23          	sd	s5,56(s3)
    release(&wait_lock);
    80201bba:	8526                	mv	a0,s1
    80201bbc:	00000097          	auipc	ra,0x0
    80201bc0:	820080e7          	jalr	-2016(ra) # 802013dc <release>

    acquire(&np->lock);
    80201bc4:	854e                	mv	a0,s3
    80201bc6:	fffff097          	auipc	ra,0xfffff
    80201bca:	762080e7          	jalr	1890(ra) # 80201328 <acquire>
    np->state = RUNNABLE;
    80201bce:	478d                	li	a5,3
    80201bd0:	00f9ac23          	sw	a5,24(s3)
    release(&np->lock);
    80201bd4:	854e                	mv	a0,s3
    80201bd6:	00000097          	auipc	ra,0x0
    80201bda:	806080e7          	jalr	-2042(ra) # 802013dc <release>
    return pid;
    80201bde:	74a2                	ld	s1,40(sp)
    80201be0:	69e2                	ld	s3,24(sp)
    80201be2:	6a42                	ld	s4,16(sp)
}
    80201be4:	854a                	mv	a0,s2
    80201be6:	70e2                	ld	ra,56(sp)
    80201be8:	7442                	ld	s0,48(sp)
    80201bea:	7902                	ld	s2,32(sp)
    80201bec:	6aa2                	ld	s5,8(sp)
    80201bee:	6121                	addi	sp,sp,64
    80201bf0:	8082                	ret
    if (!np) return -1;
    80201bf2:	597d                	li	s2,-1
    80201bf4:	bfc5                	j	80201be4 <fork+0x13c>

0000000080201bf6 <scheduler>:
    }
}

/* --- the scheduler: one instance per hart (L9) --- */
void scheduler(void)
{
    80201bf6:	715d                	addi	sp,sp,-80
    80201bf8:	e486                	sd	ra,72(sp)
    80201bfa:	e0a2                	sd	s0,64(sp)
    80201bfc:	fc26                	sd	s1,56(sp)
    80201bfe:	f84a                	sd	s2,48(sp)
    80201c00:	f44e                	sd	s3,40(sp)
    80201c02:	f052                	sd	s4,32(sp)
    80201c04:	ec56                	sd	s5,24(sp)
    80201c06:	e85a                	sd	s6,16(sp)
    80201c08:	e45e                	sd	s7,8(sp)
    80201c0a:	0880                	addi	s0,sp,80
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201c0c:	00005097          	auipc	ra,0x5
    80201c10:	ba2080e7          	jalr	-1118(ra) # 802067ae <hal_hart_id>
    struct cpu *c = mycpu();
    c->proc = 0;
    80201c14:	00751b13          	slli	s6,a0,0x7
    80201c18:	00028717          	auipc	a4,0x28
    80201c1c:	3e870713          	addi	a4,a4,1000 # 8022a000 <pid_lock>
    80201c20:	975a                	add	a4,a4,s6
    80201c22:	00073c23          	sd	zero,24(a4)
                /* Lab 3 publication point: both counters advance together. */
                p->ctxsw_count++;
                p->state_gen++;
                usysinfo_update(p);

                swtch(&c->context, &p->context);
    80201c26:	00028717          	auipc	a4,0x28
    80201c2a:	3fa70713          	addi	a4,a4,1018 # 8022a020 <cpus+0x8>
    80201c2e:	9b3a                	add	s6,s6,a4
                c->proc  = p;
    80201c30:	00751793          	slli	a5,a0,0x7
    80201c34:	00028a97          	auipc	s5,0x28
    80201c38:	3cca8a93          	addi	s5,s5,972 # 8022a000 <pid_lock>
    80201c3c:	9abe                	add	s5,s5,a5
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201c3e:	5a7d                	li	s4,-1
    80201c40:	1a7e                	slli	s4,s4,0x3f

                w_satp(MAKE_SATP(kernel_pagetable));
    80201c42:	00148b97          	auipc	s7,0x148
    80201c46:	3deb8b93          	addi	s7,s7,990 # 8034a020 <kernel_pagetable>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201c4a:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80201c4e:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201c52:	10079073          	csrw	sstatus,a5
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201c56:	00129497          	auipc	s1,0x129
    80201c5a:	3aa48493          	addi	s1,s1,938 # 8032b000 <proc>
            if (p->state == RUNNABLE) {
    80201c5e:	498d                	li	s3,3
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201c60:	0012f917          	auipc	s2,0x12f
    80201c64:	7a090913          	addi	s2,s2,1952 # 80331400 <tickslock>
    80201c68:	a811                	j	80201c7c <scheduler+0x86>
                sfence_vma();
                c->proc = 0;
            }
            release(&p->lock);
    80201c6a:	8526                	mv	a0,s1
    80201c6c:	fffff097          	auipc	ra,0xfffff
    80201c70:	770080e7          	jalr	1904(ra) # 802013dc <release>
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201c74:	19048493          	addi	s1,s1,400
    80201c78:	fd2489e3          	beq	s1,s2,80201c4a <scheduler+0x54>
            acquire(&p->lock);
    80201c7c:	8526                	mv	a0,s1
    80201c7e:	fffff097          	auipc	ra,0xfffff
    80201c82:	6aa080e7          	jalr	1706(ra) # 80201328 <acquire>
            if (p->state == RUNNABLE) {
    80201c86:	4c9c                	lw	a5,24(s1)
    80201c88:	ff3791e3          	bne	a5,s3,80201c6a <scheduler+0x74>
                p->state = RUNNING;
    80201c8c:	4791                	li	a5,4
    80201c8e:	cc9c                	sw	a5,24(s1)
                c->proc  = p;
    80201c90:	009abc23          	sd	s1,24(s5)
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201c94:	68bc                	ld	a5,80(s1)
    80201c96:	83b1                	srli	a5,a5,0xc
    80201c98:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201c9c:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201ca0:	12000073          	sfence.vma
                p->ctxsw_count++;
    80201ca4:	1804b783          	ld	a5,384(s1)
    80201ca8:	0785                	addi	a5,a5,1
    80201caa:	18f4b023          	sd	a5,384(s1)
                p->state_gen++;
    80201cae:	1884a783          	lw	a5,392(s1)
    80201cb2:	2785                	addiw	a5,a5,1
    80201cb4:	18f4a423          	sw	a5,392(s1)
                usysinfo_update(p);
    80201cb8:	8526                	mv	a0,s1
    80201cba:	00003097          	auipc	ra,0x3
    80201cbe:	9e6080e7          	jalr	-1562(ra) # 802046a0 <usysinfo_update>
                swtch(&c->context, &p->context);
    80201cc2:	06048593          	addi	a1,s1,96
    80201cc6:	855a                	mv	a0,s6
    80201cc8:	00000097          	auipc	ra,0x0
    80201ccc:	5fe080e7          	jalr	1534(ra) # 802022c6 <swtch>
                w_satp(MAKE_SATP(kernel_pagetable));
    80201cd0:	000bb783          	ld	a5,0(s7)
    80201cd4:	83b1                	srli	a5,a5,0xc
    80201cd6:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201cda:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201cde:	12000073          	sfence.vma
                c->proc = 0;
    80201ce2:	000abc23          	sd	zero,24(s5)
    80201ce6:	b751                	j	80201c6a <scheduler+0x74>

0000000080201ce8 <sched>:
    }
}

/* Switch to the scheduler. Must hold p->lock and have changed p->state. */
void sched(void)
{
    80201ce8:	7179                	addi	sp,sp,-48
    80201cea:	f406                	sd	ra,40(sp)
    80201cec:	f022                	sd	s0,32(sp)
    80201cee:	ec26                	sd	s1,24(sp)
    80201cf0:	e84a                	sd	s2,16(sp)
    80201cf2:	e44e                	sd	s3,8(sp)
    80201cf4:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    80201cf6:	00000097          	auipc	ra,0x0
    80201cfa:	a70080e7          	jalr	-1424(ra) # 80201766 <myproc>
    80201cfe:	84aa                	mv	s1,a0
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201d00:	fffff097          	auipc	ra,0xfffff
    80201d04:	5c2080e7          	jalr	1474(ra) # 802012c2 <holding>
    80201d08:	c541                	beqz	a0,80201d90 <sched+0xa8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201d0a:	00005097          	auipc	ra,0x5
    80201d0e:	aa4080e7          	jalr	-1372(ra) # 802067ae <hal_hart_id>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201d12:	051e                	slli	a0,a0,0x7
    80201d14:	00028797          	auipc	a5,0x28
    80201d18:	2ec78793          	addi	a5,a5,748 # 8022a000 <pid_lock>
    80201d1c:	97aa                	add	a5,a5,a0
    80201d1e:	0907a703          	lw	a4,144(a5)
    80201d22:	4785                	li	a5,1
    80201d24:	06f71e63          	bne	a4,a5,80201da0 <sched+0xb8>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201d28:	4c98                	lw	a4,24(s1)
    80201d2a:	4791                	li	a5,4
    80201d2c:	08f70263          	beq	a4,a5,80201db0 <sched+0xc8>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201d30:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201d34:	8b89                	andi	a5,a5,2
    if (intr_get())           panic("sched: interrupts are on");
    80201d36:	e7c9                	bnez	a5,80201dc0 <sched+0xd8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201d38:	00005097          	auipc	ra,0x5
    80201d3c:	a76080e7          	jalr	-1418(ra) # 802067ae <hal_hart_id>

    int intena = mycpu()->intena;
    80201d40:	00028917          	auipc	s2,0x28
    80201d44:	2c090913          	addi	s2,s2,704 # 8022a000 <pid_lock>
    80201d48:	00751793          	slli	a5,a0,0x7
    80201d4c:	97ca                	add	a5,a5,s2
    80201d4e:	0947a983          	lw	s3,148(a5)
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201d52:	00005097          	auipc	ra,0x5
    80201d56:	a5c080e7          	jalr	-1444(ra) # 802067ae <hal_hart_id>
    swtch(&p->context, &mycpu()->context);
    80201d5a:	051e                	slli	a0,a0,0x7
    80201d5c:	00028597          	auipc	a1,0x28
    80201d60:	2c458593          	addi	a1,a1,708 # 8022a020 <cpus+0x8>
    80201d64:	95aa                	add	a1,a1,a0
    80201d66:	06048513          	addi	a0,s1,96
    80201d6a:	00000097          	auipc	ra,0x0
    80201d6e:	55c080e7          	jalr	1372(ra) # 802022c6 <swtch>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201d72:	00005097          	auipc	ra,0x5
    80201d76:	a3c080e7          	jalr	-1476(ra) # 802067ae <hal_hart_id>
    mycpu()->intena = intena;
    80201d7a:	051e                	slli	a0,a0,0x7
    80201d7c:	992a                	add	s2,s2,a0
    80201d7e:	09392a23          	sw	s3,148(s2)
}
    80201d82:	70a2                	ld	ra,40(sp)
    80201d84:	7402                	ld	s0,32(sp)
    80201d86:	64e2                	ld	s1,24(sp)
    80201d88:	6942                	ld	s2,16(sp)
    80201d8a:	69a2                	ld	s3,8(sp)
    80201d8c:	6145                	addi	sp,sp,48
    80201d8e:	8082                	ret
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201d90:	00005517          	auipc	a0,0x5
    80201d94:	79850513          	addi	a0,a0,1944 # 80207528 <etext+0x528>
    80201d98:	fffff097          	auipc	ra,0xfffff
    80201d9c:	85a080e7          	jalr	-1958(ra) # 802005f2 <panic>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201da0:	00005517          	auipc	a0,0x5
    80201da4:	7a850513          	addi	a0,a0,1960 # 80207548 <etext+0x548>
    80201da8:	fffff097          	auipc	ra,0xfffff
    80201dac:	84a080e7          	jalr	-1974(ra) # 802005f2 <panic>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201db0:	00005517          	auipc	a0,0x5
    80201db4:	7b850513          	addi	a0,a0,1976 # 80207568 <etext+0x568>
    80201db8:	fffff097          	auipc	ra,0xfffff
    80201dbc:	83a080e7          	jalr	-1990(ra) # 802005f2 <panic>
    if (intr_get())           panic("sched: interrupts are on");
    80201dc0:	00005517          	auipc	a0,0x5
    80201dc4:	7c850513          	addi	a0,a0,1992 # 80207588 <etext+0x588>
    80201dc8:	fffff097          	auipc	ra,0xfffff
    80201dcc:	82a080e7          	jalr	-2006(ra) # 802005f2 <panic>

0000000080201dd0 <yield>:

void yield(void)
{
    80201dd0:	1101                	addi	sp,sp,-32
    80201dd2:	ec06                	sd	ra,24(sp)
    80201dd4:	e822                	sd	s0,16(sp)
    80201dd6:	e426                	sd	s1,8(sp)
    80201dd8:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    80201dda:	00000097          	auipc	ra,0x0
    80201dde:	98c080e7          	jalr	-1652(ra) # 80201766 <myproc>
    80201de2:	84aa                	mv	s1,a0
    acquire(&p->lock);
    80201de4:	fffff097          	auipc	ra,0xfffff
    80201de8:	544080e7          	jalr	1348(ra) # 80201328 <acquire>
    p->state = RUNNABLE;
    80201dec:	478d                	li	a5,3
    80201dee:	cc9c                	sw	a5,24(s1)
    sched();
    80201df0:	00000097          	auipc	ra,0x0
    80201df4:	ef8080e7          	jalr	-264(ra) # 80201ce8 <sched>
    release(&p->lock);
    80201df8:	8526                	mv	a0,s1
    80201dfa:	fffff097          	auipc	ra,0xfffff
    80201dfe:	5e2080e7          	jalr	1506(ra) # 802013dc <release>
}
    80201e02:	60e2                	ld	ra,24(sp)
    80201e04:	6442                	ld	s0,16(sp)
    80201e06:	64a2                	ld	s1,8(sp)
    80201e08:	6105                	addi	sp,sp,32
    80201e0a:	8082                	ret

0000000080201e0c <sleep>:

void sleep(void *chan, struct spinlock *lk)
{
    80201e0c:	7179                	addi	sp,sp,-48
    80201e0e:	f406                	sd	ra,40(sp)
    80201e10:	f022                	sd	s0,32(sp)
    80201e12:	ec26                	sd	s1,24(sp)
    80201e14:	e84a                	sd	s2,16(sp)
    80201e16:	e44e                	sd	s3,8(sp)
    80201e18:	1800                	addi	s0,sp,48
    80201e1a:	89aa                	mv	s3,a0
    80201e1c:	892e                	mv	s2,a1
    struct proc *p = myproc();
    80201e1e:	00000097          	auipc	ra,0x0
    80201e22:	948080e7          	jalr	-1720(ra) # 80201766 <myproc>
    80201e26:	84aa                	mv	s1,a0

    /* Acquire p->lock BEFORE releasing lk. If we did it the other way round, a
     * wakeup could slip in between and be lost - the classic missed-wakeup race. */
    acquire(&p->lock);
    80201e28:	fffff097          	auipc	ra,0xfffff
    80201e2c:	500080e7          	jalr	1280(ra) # 80201328 <acquire>
    release(lk);
    80201e30:	854a                	mv	a0,s2
    80201e32:	fffff097          	auipc	ra,0xfffff
    80201e36:	5aa080e7          	jalr	1450(ra) # 802013dc <release>

    p->chan  = chan;
    80201e3a:	0334b023          	sd	s3,32(s1)
    p->state = SLEEPING;
    80201e3e:	4789                	li	a5,2
    80201e40:	cc9c                	sw	a5,24(s1)
    sched();
    80201e42:	00000097          	auipc	ra,0x0
    80201e46:	ea6080e7          	jalr	-346(ra) # 80201ce8 <sched>

    p->chan = 0;
    80201e4a:	0204b023          	sd	zero,32(s1)
    release(&p->lock);
    80201e4e:	8526                	mv	a0,s1
    80201e50:	fffff097          	auipc	ra,0xfffff
    80201e54:	58c080e7          	jalr	1420(ra) # 802013dc <release>
    acquire(lk);
    80201e58:	854a                	mv	a0,s2
    80201e5a:	fffff097          	auipc	ra,0xfffff
    80201e5e:	4ce080e7          	jalr	1230(ra) # 80201328 <acquire>
}
    80201e62:	70a2                	ld	ra,40(sp)
    80201e64:	7402                	ld	s0,32(sp)
    80201e66:	64e2                	ld	s1,24(sp)
    80201e68:	6942                	ld	s2,16(sp)
    80201e6a:	69a2                	ld	s3,8(sp)
    80201e6c:	6145                	addi	sp,sp,48
    80201e6e:	8082                	ret

0000000080201e70 <wait>:
{
    80201e70:	715d                	addi	sp,sp,-80
    80201e72:	e486                	sd	ra,72(sp)
    80201e74:	e0a2                	sd	s0,64(sp)
    80201e76:	fc26                	sd	s1,56(sp)
    80201e78:	f84a                	sd	s2,48(sp)
    80201e7a:	f44e                	sd	s3,40(sp)
    80201e7c:	f052                	sd	s4,32(sp)
    80201e7e:	ec56                	sd	s5,24(sp)
    80201e80:	e85a                	sd	s6,16(sp)
    80201e82:	e45e                	sd	s7,8(sp)
    80201e84:	0880                	addi	s0,sp,80
    80201e86:	8b2a                	mv	s6,a0
    struct proc *p = myproc();
    80201e88:	00000097          	auipc	ra,0x0
    80201e8c:	8de080e7          	jalr	-1826(ra) # 80201766 <myproc>
    80201e90:	892a                	mv	s2,a0
    acquire(&wait_lock);
    80201e92:	00028517          	auipc	a0,0x28
    80201e96:	58650513          	addi	a0,a0,1414 # 8022a418 <wait_lock>
    80201e9a:	fffff097          	auipc	ra,0xfffff
    80201e9e:	48e080e7          	jalr	1166(ra) # 80201328 <acquire>
        int havekids = 0;
    80201ea2:	4b81                	li	s7,0
            if (pp->state == ZOMBIE) {
    80201ea4:	4a15                	li	s4,5
            havekids = 1;
    80201ea6:	4a85                	li	s5,1
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201ea8:	0012f997          	auipc	s3,0x12f
    80201eac:	55898993          	addi	s3,s3,1368 # 80331400 <tickslock>
    80201eb0:	00129497          	auipc	s1,0x129
    80201eb4:	15048493          	addi	s1,s1,336 # 8032b000 <proc>
        int havekids = 0;
    80201eb8:	875e                	mv	a4,s7
    80201eba:	a051                	j	80201f3e <wait+0xce>
                int pid = pp->pid;
    80201ebc:	0304a983          	lw	s3,48(s1)
                if (addr && copyout(p->pagetable, addr,
    80201ec0:	000b0e63          	beqz	s6,80201edc <wait+0x6c>
    80201ec4:	4691                	li	a3,4
    80201ec6:	02c48613          	addi	a2,s1,44
    80201eca:	85da                	mv	a1,s6
    80201ecc:	05093503          	ld	a0,80(s2)
    80201ed0:	00001097          	auipc	ra,0x1
    80201ed4:	0ae080e7          	jalr	174(ra) # 80202f7e <copyout>
    80201ed8:	04054063          	bltz	a0,80201f18 <wait+0xa8>
                freeproc(pp);
    80201edc:	8526                	mv	a0,s1
    80201ede:	fffff097          	auipc	ra,0xfffff
    80201ee2:	670080e7          	jalr	1648(ra) # 8020154e <freeproc>
                release(&pp->lock);
    80201ee6:	8526                	mv	a0,s1
    80201ee8:	fffff097          	auipc	ra,0xfffff
    80201eec:	4f4080e7          	jalr	1268(ra) # 802013dc <release>
                release(&wait_lock);
    80201ef0:	00028517          	auipc	a0,0x28
    80201ef4:	52850513          	addi	a0,a0,1320 # 8022a418 <wait_lock>
    80201ef8:	fffff097          	auipc	ra,0xfffff
    80201efc:	4e4080e7          	jalr	1252(ra) # 802013dc <release>
}
    80201f00:	854e                	mv	a0,s3
    80201f02:	60a6                	ld	ra,72(sp)
    80201f04:	6406                	ld	s0,64(sp)
    80201f06:	74e2                	ld	s1,56(sp)
    80201f08:	7942                	ld	s2,48(sp)
    80201f0a:	79a2                	ld	s3,40(sp)
    80201f0c:	7a02                	ld	s4,32(sp)
    80201f0e:	6ae2                	ld	s5,24(sp)
    80201f10:	6b42                	ld	s6,16(sp)
    80201f12:	6ba2                	ld	s7,8(sp)
    80201f14:	6161                	addi	sp,sp,80
    80201f16:	8082                	ret
                    release(&pp->lock);
    80201f18:	8526                	mv	a0,s1
    80201f1a:	fffff097          	auipc	ra,0xfffff
    80201f1e:	4c2080e7          	jalr	1218(ra) # 802013dc <release>
                    release(&wait_lock);
    80201f22:	00028517          	auipc	a0,0x28
    80201f26:	4f650513          	addi	a0,a0,1270 # 8022a418 <wait_lock>
    80201f2a:	fffff097          	auipc	ra,0xfffff
    80201f2e:	4b2080e7          	jalr	1202(ra) # 802013dc <release>
                    return -1;
    80201f32:	59fd                	li	s3,-1
    80201f34:	b7f1                	j	80201f00 <wait+0x90>
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201f36:	19048493          	addi	s1,s1,400
    80201f3a:	03348463          	beq	s1,s3,80201f62 <wait+0xf2>
            if (pp->parent != p) continue;
    80201f3e:	7c9c                	ld	a5,56(s1)
    80201f40:	ff279be3          	bne	a5,s2,80201f36 <wait+0xc6>
            acquire(&pp->lock);
    80201f44:	8526                	mv	a0,s1
    80201f46:	fffff097          	auipc	ra,0xfffff
    80201f4a:	3e2080e7          	jalr	994(ra) # 80201328 <acquire>
            if (pp->state == ZOMBIE) {
    80201f4e:	4c9c                	lw	a5,24(s1)
    80201f50:	f74786e3          	beq	a5,s4,80201ebc <wait+0x4c>
            release(&pp->lock);
    80201f54:	8526                	mv	a0,s1
    80201f56:	fffff097          	auipc	ra,0xfffff
    80201f5a:	486080e7          	jalr	1158(ra) # 802013dc <release>
            havekids = 1;
    80201f5e:	8756                	mv	a4,s5
    80201f60:	bfd9                	j	80201f36 <wait+0xc6>
        if (!havekids || p->killed) {
    80201f62:	cf11                	beqz	a4,80201f7e <wait+0x10e>
    80201f64:	02892783          	lw	a5,40(s2)
    80201f68:	eb99                	bnez	a5,80201f7e <wait+0x10e>
        sleep(p, &wait_lock);
    80201f6a:	00028597          	auipc	a1,0x28
    80201f6e:	4ae58593          	addi	a1,a1,1198 # 8022a418 <wait_lock>
    80201f72:	854a                	mv	a0,s2
    80201f74:	00000097          	auipc	ra,0x0
    80201f78:	e98080e7          	jalr	-360(ra) # 80201e0c <sleep>
    for (;;) {
    80201f7c:	bf15                	j	80201eb0 <wait+0x40>
            release(&wait_lock);
    80201f7e:	00028517          	auipc	a0,0x28
    80201f82:	49a50513          	addi	a0,a0,1178 # 8022a418 <wait_lock>
    80201f86:	fffff097          	auipc	ra,0xfffff
    80201f8a:	456080e7          	jalr	1110(ra) # 802013dc <release>
            return -1;
    80201f8e:	59fd                	li	s3,-1
    80201f90:	bf85                	j	80201f00 <wait+0x90>

0000000080201f92 <wakeup>:

void wakeup(void *chan)
{
    80201f92:	7139                	addi	sp,sp,-64
    80201f94:	fc06                	sd	ra,56(sp)
    80201f96:	f822                	sd	s0,48(sp)
    80201f98:	f426                	sd	s1,40(sp)
    80201f9a:	f04a                	sd	s2,32(sp)
    80201f9c:	ec4e                	sd	s3,24(sp)
    80201f9e:	e852                	sd	s4,16(sp)
    80201fa0:	e456                	sd	s5,8(sp)
    80201fa2:	0080                	addi	s0,sp,64
    80201fa4:	8a2a                	mv	s4,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201fa6:	00129497          	auipc	s1,0x129
    80201faa:	05a48493          	addi	s1,s1,90 # 8032b000 <proc>
        if (p != myproc()) {
            acquire(&p->lock);
            if (p->state == SLEEPING && p->chan == chan)
    80201fae:	4989                	li	s3,2
                p->state = RUNNABLE;
    80201fb0:	4a8d                	li	s5,3
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201fb2:	0012f917          	auipc	s2,0x12f
    80201fb6:	44e90913          	addi	s2,s2,1102 # 80331400 <tickslock>
    80201fba:	a811                	j	80201fce <wakeup+0x3c>
            release(&p->lock);
    80201fbc:	8526                	mv	a0,s1
    80201fbe:	fffff097          	auipc	ra,0xfffff
    80201fc2:	41e080e7          	jalr	1054(ra) # 802013dc <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201fc6:	19048493          	addi	s1,s1,400
    80201fca:	03248663          	beq	s1,s2,80201ff6 <wakeup+0x64>
        if (p != myproc()) {
    80201fce:	fffff097          	auipc	ra,0xfffff
    80201fd2:	798080e7          	jalr	1944(ra) # 80201766 <myproc>
    80201fd6:	fea488e3          	beq	s1,a0,80201fc6 <wakeup+0x34>
            acquire(&p->lock);
    80201fda:	8526                	mv	a0,s1
    80201fdc:	fffff097          	auipc	ra,0xfffff
    80201fe0:	34c080e7          	jalr	844(ra) # 80201328 <acquire>
            if (p->state == SLEEPING && p->chan == chan)
    80201fe4:	4c9c                	lw	a5,24(s1)
    80201fe6:	fd379be3          	bne	a5,s3,80201fbc <wakeup+0x2a>
    80201fea:	709c                	ld	a5,32(s1)
    80201fec:	fd4798e3          	bne	a5,s4,80201fbc <wakeup+0x2a>
                p->state = RUNNABLE;
    80201ff0:	0154ac23          	sw	s5,24(s1)
    80201ff4:	b7e1                	j	80201fbc <wakeup+0x2a>
        }
    }
}
    80201ff6:	70e2                	ld	ra,56(sp)
    80201ff8:	7442                	ld	s0,48(sp)
    80201ffa:	74a2                	ld	s1,40(sp)
    80201ffc:	7902                	ld	s2,32(sp)
    80201ffe:	69e2                	ld	s3,24(sp)
    80202000:	6a42                	ld	s4,16(sp)
    80202002:	6aa2                	ld	s5,8(sp)
    80202004:	6121                	addi	sp,sp,64
    80202006:	8082                	ret

0000000080202008 <exit>:
{
    80202008:	7139                	addi	sp,sp,-64
    8020200a:	fc06                	sd	ra,56(sp)
    8020200c:	f822                	sd	s0,48(sp)
    8020200e:	f426                	sd	s1,40(sp)
    80202010:	f04a                	sd	s2,32(sp)
    80202012:	ec4e                	sd	s3,24(sp)
    80202014:	e456                	sd	s5,8(sp)
    80202016:	0080                	addi	s0,sp,64
    80202018:	8aaa                	mv	s5,a0
    struct proc *p = myproc();
    8020201a:	fffff097          	auipc	ra,0xfffff
    8020201e:	74c080e7          	jalr	1868(ra) # 80201766 <myproc>
    80202022:	892a                	mv	s2,a0
    if (p == initproc) panic("init exiting");
    80202024:	00148797          	auipc	a5,0x148
    80202028:	fec7b783          	ld	a5,-20(a5) # 8034a010 <initproc>
    8020202c:	0d050493          	addi	s1,a0,208
    80202030:	15050993          	addi	s3,a0,336
    80202034:	00a78463          	beq	a5,a0,8020203c <exit+0x34>
    80202038:	e852                	sd	s4,16(sp)
    8020203a:	a01d                	j	80202060 <exit+0x58>
    8020203c:	e852                	sd	s4,16(sp)
    8020203e:	00005517          	auipc	a0,0x5
    80202042:	56a50513          	addi	a0,a0,1386 # 802075a8 <etext+0x5a8>
    80202046:	ffffe097          	auipc	ra,0xffffe
    8020204a:	5ac080e7          	jalr	1452(ra) # 802005f2 <panic>
            fileclose(p->ofile[fd]);
    8020204e:	00004097          	auipc	ra,0x4
    80202052:	050080e7          	jalr	80(ra) # 8020609e <fileclose>
            p->ofile[fd] = 0;
    80202056:	0004b023          	sd	zero,0(s1)
    for (int fd = 0; fd < NOFILE; fd++) {
    8020205a:	04a1                	addi	s1,s1,8
    8020205c:	01348563          	beq	s1,s3,80202066 <exit+0x5e>
        if (p->ofile[fd]) {
    80202060:	6088                	ld	a0,0(s1)
    80202062:	f575                	bnez	a0,8020204e <exit+0x46>
    80202064:	bfdd                	j	8020205a <exit+0x52>
    iput(p->cwd);
    80202066:	15093503          	ld	a0,336(s2)
    8020206a:	00004097          	auipc	ra,0x4
    8020206e:	840080e7          	jalr	-1984(ra) # 802058aa <iput>
    p->cwd = 0;
    80202072:	14093823          	sd	zero,336(s2)
    acquire(&wait_lock);
    80202076:	00028517          	auipc	a0,0x28
    8020207a:	3a250513          	addi	a0,a0,930 # 8022a418 <wait_lock>
    8020207e:	fffff097          	auipc	ra,0xfffff
    80202082:	2aa080e7          	jalr	682(ra) # 80201328 <acquire>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202086:	00129497          	auipc	s1,0x129
    8020208a:	f7a48493          	addi	s1,s1,-134 # 8032b000 <proc>
            pp->parent = initproc;
    8020208e:	00148a17          	auipc	s4,0x148
    80202092:	f82a0a13          	addi	s4,s4,-126 # 8034a010 <initproc>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202096:	0012f997          	auipc	s3,0x12f
    8020209a:	36a98993          	addi	s3,s3,874 # 80331400 <tickslock>
    8020209e:	a821                	j	802020b6 <exit+0xae>
            pp->parent = initproc;
    802020a0:	000a3503          	ld	a0,0(s4)
    802020a4:	fc88                	sd	a0,56(s1)
            wakeup(initproc);
    802020a6:	00000097          	auipc	ra,0x0
    802020aa:	eec080e7          	jalr	-276(ra) # 80201f92 <wakeup>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    802020ae:	19048493          	addi	s1,s1,400
    802020b2:	01348663          	beq	s1,s3,802020be <exit+0xb6>
        if (pp->parent == p) {
    802020b6:	7c9c                	ld	a5,56(s1)
    802020b8:	fef91be3          	bne	s2,a5,802020ae <exit+0xa6>
    802020bc:	b7d5                	j	802020a0 <exit+0x98>
    wakeup(p->parent);
    802020be:	03893503          	ld	a0,56(s2)
    802020c2:	00000097          	auipc	ra,0x0
    802020c6:	ed0080e7          	jalr	-304(ra) # 80201f92 <wakeup>
    acquire(&p->lock);
    802020ca:	854a                	mv	a0,s2
    802020cc:	fffff097          	auipc	ra,0xfffff
    802020d0:	25c080e7          	jalr	604(ra) # 80201328 <acquire>
    p->xstate = status;
    802020d4:	03592623          	sw	s5,44(s2)
    p->state  = ZOMBIE;
    802020d8:	4795                	li	a5,5
    802020da:	00f92c23          	sw	a5,24(s2)
    release(&wait_lock);
    802020de:	00028517          	auipc	a0,0x28
    802020e2:	33a50513          	addi	a0,a0,826 # 8022a418 <wait_lock>
    802020e6:	fffff097          	auipc	ra,0xfffff
    802020ea:	2f6080e7          	jalr	758(ra) # 802013dc <release>
    sched();                        /* never returns */
    802020ee:	00000097          	auipc	ra,0x0
    802020f2:	bfa080e7          	jalr	-1030(ra) # 80201ce8 <sched>
    panic("zombie exit");
    802020f6:	00005517          	auipc	a0,0x5
    802020fa:	4c250513          	addi	a0,a0,1218 # 802075b8 <etext+0x5b8>
    802020fe:	ffffe097          	auipc	ra,0xffffe
    80202102:	4f4080e7          	jalr	1268(ra) # 802005f2 <panic>

0000000080202106 <kill>:

int kill(int pid)
{
    80202106:	7179                	addi	sp,sp,-48
    80202108:	f406                	sd	ra,40(sp)
    8020210a:	f022                	sd	s0,32(sp)
    8020210c:	ec26                	sd	s1,24(sp)
    8020210e:	e84a                	sd	s2,16(sp)
    80202110:	e44e                	sd	s3,8(sp)
    80202112:	1800                	addi	s0,sp,48
    80202114:	892a                	mv	s2,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202116:	00129497          	auipc	s1,0x129
    8020211a:	eea48493          	addi	s1,s1,-278 # 8032b000 <proc>
    8020211e:	0012f997          	auipc	s3,0x12f
    80202122:	2e298993          	addi	s3,s3,738 # 80331400 <tickslock>
        acquire(&p->lock);
    80202126:	8526                	mv	a0,s1
    80202128:	fffff097          	auipc	ra,0xfffff
    8020212c:	200080e7          	jalr	512(ra) # 80201328 <acquire>
        if (p->pid == pid) {
    80202130:	589c                	lw	a5,48(s1)
    80202132:	01278d63          	beq	a5,s2,8020214c <kill+0x46>
            p->killed = 1;
            if (p->state == SLEEPING) p->state = RUNNABLE;
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    80202136:	8526                	mv	a0,s1
    80202138:	fffff097          	auipc	ra,0xfffff
    8020213c:	2a4080e7          	jalr	676(ra) # 802013dc <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202140:	19048493          	addi	s1,s1,400
    80202144:	ff3491e3          	bne	s1,s3,80202126 <kill+0x20>
    }
    return -1;
    80202148:	557d                	li	a0,-1
    8020214a:	a829                	j	80202164 <kill+0x5e>
            p->killed = 1;
    8020214c:	4785                	li	a5,1
    8020214e:	d49c                	sw	a5,40(s1)
            if (p->state == SLEEPING) p->state = RUNNABLE;
    80202150:	4c98                	lw	a4,24(s1)
    80202152:	4789                	li	a5,2
    80202154:	00f70f63          	beq	a4,a5,80202172 <kill+0x6c>
            release(&p->lock);
    80202158:	8526                	mv	a0,s1
    8020215a:	fffff097          	auipc	ra,0xfffff
    8020215e:	282080e7          	jalr	642(ra) # 802013dc <release>
            return 0;
    80202162:	4501                	li	a0,0
}
    80202164:	70a2                	ld	ra,40(sp)
    80202166:	7402                	ld	s0,32(sp)
    80202168:	64e2                	ld	s1,24(sp)
    8020216a:	6942                	ld	s2,16(sp)
    8020216c:	69a2                	ld	s3,8(sp)
    8020216e:	6145                	addi	sp,sp,48
    80202170:	8082                	ret
            if (p->state == SLEEPING) p->state = RUNNABLE;
    80202172:	478d                	li	a5,3
    80202174:	cc9c                	sw	a5,24(s1)
    80202176:	b7cd                	j	80202158 <kill+0x52>

0000000080202178 <procstat>:

/* Copy up to max process records to user space; returns the count. Backs the
 * procstat() syscall and the `ps` utility. Reads are racy-by-design (a
 * snapshot, not a transaction) but each slot is read under its own lock. */
int procstat(uint64 uaddr, int max)
{
    80202178:	711d                	addi	sp,sp,-96
    8020217a:	ec86                	sd	ra,88(sp)
    8020217c:	e8a2                	sd	s0,80(sp)
    8020217e:	e0ca                	sd	s2,64(sp)
    80202180:	1080                	addi	s0,sp,96
    struct pstat ps;
    int n = 0;
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    80202182:	0ab05663          	blez	a1,8020222e <procstat+0xb6>
    80202186:	e4a6                	sd	s1,72(sp)
    80202188:	fc4e                	sd	s3,56(sp)
    8020218a:	f852                	sd	s4,48(sp)
    8020218c:	f456                	sd	s5,40(sp)
    8020218e:	8aaa                	mv	s5,a0
    80202190:	89ae                	mv	s3,a1
    80202192:	00129497          	auipc	s1,0x129
    80202196:	e6e48493          	addi	s1,s1,-402 # 8032b000 <proc>
    int n = 0;
    8020219a:	4901                	li	s2,0
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    8020219c:	0012fa17          	auipc	s4,0x12f
    802021a0:	264a0a13          	addi	s4,s4,612 # 80331400 <tickslock>
    802021a4:	a821                	j	802021bc <procstat+0x44>
        acquire(&p->lock);
        if (p->state == UNUSED) { release(&p->lock); continue; }
    802021a6:	8526                	mv	a0,s1
    802021a8:	fffff097          	auipc	ra,0xfffff
    802021ac:	234080e7          	jalr	564(ra) # 802013dc <release>
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802021b0:	19048493          	addi	s1,s1,400
    802021b4:	09448563          	beq	s1,s4,8020223e <procstat+0xc6>
    802021b8:	07395163          	bge	s2,s3,8020221a <procstat+0xa2>
        acquire(&p->lock);
    802021bc:	8526                	mv	a0,s1
    802021be:	fffff097          	auipc	ra,0xfffff
    802021c2:	16a080e7          	jalr	362(ra) # 80201328 <acquire>
        if (p->state == UNUSED) { release(&p->lock); continue; }
    802021c6:	4c9c                	lw	a5,24(s1)
    802021c8:	dff9                	beqz	a5,802021a6 <procstat+0x2e>
        ps.pid   = p->pid;
    802021ca:	5898                	lw	a4,48(s1)
    802021cc:	fae42423          	sw	a4,-88(s0)
        ps.state = p->state;
    802021d0:	faf42623          	sw	a5,-84(s0)
        memmove(ps.name, p->name, sizeof(ps.name));
    802021d4:	4641                	li	a2,16
    802021d6:	15848593          	addi	a1,s1,344
    802021da:	fb040513          	addi	a0,s0,-80
    802021de:	ffffe097          	auipc	ra,0xffffe
    802021e2:	4d6080e7          	jalr	1238(ra) # 802006b4 <memmove>
        release(&p->lock);
    802021e6:	8526                	mv	a0,s1
    802021e8:	fffff097          	auipc	ra,0xfffff
    802021ec:	1f4080e7          	jalr	500(ra) # 802013dc <release>
        if (copyout(myproc()->pagetable, uaddr + n * sizeof(ps),
    802021f0:	fffff097          	auipc	ra,0xfffff
    802021f4:	576080e7          	jalr	1398(ra) # 80201766 <myproc>
    802021f8:	00191593          	slli	a1,s2,0x1
    802021fc:	95ca                	add	a1,a1,s2
    802021fe:	058e                	slli	a1,a1,0x3
    80202200:	46e1                	li	a3,24
    80202202:	fa840613          	addi	a2,s0,-88
    80202206:	95d6                	add	a1,a1,s5
    80202208:	6928                	ld	a0,80(a0)
    8020220a:	00001097          	auipc	ra,0x1
    8020220e:	d74080e7          	jalr	-652(ra) # 80202f7e <copyout>
    80202212:	02054063          	bltz	a0,80202232 <procstat+0xba>
                    (char *)&ps, sizeof(ps)) < 0)
            return -1;
        n++;
    80202216:	2905                	addiw	s2,s2,1
    80202218:	bf61                	j	802021b0 <procstat+0x38>
    8020221a:	64a6                	ld	s1,72(sp)
    8020221c:	79e2                	ld	s3,56(sp)
    8020221e:	7a42                	ld	s4,48(sp)
    80202220:	7aa2                	ld	s5,40(sp)
    }
    return n;
}
    80202222:	854a                	mv	a0,s2
    80202224:	60e6                	ld	ra,88(sp)
    80202226:	6446                	ld	s0,80(sp)
    80202228:	6906                	ld	s2,64(sp)
    8020222a:	6125                	addi	sp,sp,96
    8020222c:	8082                	ret
    return n;
    8020222e:	4901                	li	s2,0
    80202230:	bfcd                	j	80202222 <procstat+0xaa>
            return -1;
    80202232:	597d                	li	s2,-1
    80202234:	64a6                	ld	s1,72(sp)
    80202236:	79e2                	ld	s3,56(sp)
    80202238:	7a42                	ld	s4,48(sp)
    8020223a:	7aa2                	ld	s5,40(sp)
    8020223c:	b7dd                	j	80202222 <procstat+0xaa>
    8020223e:	64a6                	ld	s1,72(sp)
    80202240:	79e2                	ld	s3,56(sp)
    80202242:	7a42                	ld	s4,48(sp)
    80202244:	7aa2                	ld	s5,40(sp)
    80202246:	bff1                	j	80202222 <procstat+0xaa>

0000000080202248 <procdump>:

void procdump(void)
{
    80202248:	7179                	addi	sp,sp,-48
    8020224a:	f406                	sd	ra,40(sp)
    8020224c:	f022                	sd	s0,32(sp)
    8020224e:	ec26                	sd	s1,24(sp)
    80202250:	e84a                	sd	s2,16(sp)
    80202252:	e44e                	sd	s3,8(sp)
    80202254:	e052                	sd	s4,0(sp)
    80202256:	1800                	addi	s0,sp,48
    static const char *st[] = {
        [UNUSED]"unused", [USED]"used", [SLEEPING]"sleep",
        [RUNNABLE]"runble", [RUNNING]"run", [ZOMBIE]"zombie"
    };
    printf("\n--- process table ---\n");
    80202258:	00005517          	auipc	a0,0x5
    8020225c:	37050513          	addi	a0,a0,880 # 802075c8 <etext+0x5c8>
    80202260:	ffffe097          	auipc	ra,0xffffe
    80202264:	120080e7          	jalr	288(ra) # 80200380 <printf>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202268:	00129497          	auipc	s1,0x129
    8020226c:	ef048493          	addi	s1,s1,-272 # 8032b158 <proc+0x158>
    80202270:	0012f917          	auipc	s2,0x12f
    80202274:	2e890913          	addi	s2,s2,744 # 80331558 <rings+0x140>
        if (p->state == UNUSED) continue;
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    80202278:	00006a17          	auipc	s4,0x6
    8020227c:	b78a0a13          	addi	s4,s4,-1160 # 80207df0 <st.0>
    80202280:	00005997          	auipc	s3,0x5
    80202284:	36098993          	addi	s3,s3,864 # 802075e0 <etext+0x5e0>
    80202288:	a029                	j	80202292 <procdump+0x4a>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020228a:	19048493          	addi	s1,s1,400
    8020228e:	03248463          	beq	s1,s2,802022b6 <procdump+0x6e>
        if (p->state == UNUSED) continue;
    80202292:	ec04a783          	lw	a5,-320(s1)
    80202296:	dbf5                	beqz	a5,8020228a <procdump+0x42>
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    80202298:	02079713          	slli	a4,a5,0x20
    8020229c:	01d75793          	srli	a5,a4,0x1d
    802022a0:	97d2                	add	a5,a5,s4
    802022a2:	86a6                	mv	a3,s1
    802022a4:	6390                	ld	a2,0(a5)
    802022a6:	ed84a583          	lw	a1,-296(s1)
    802022aa:	854e                	mv	a0,s3
    802022ac:	ffffe097          	auipc	ra,0xffffe
    802022b0:	0d4080e7          	jalr	212(ra) # 80200380 <printf>
    802022b4:	bfd9                	j	8020228a <procdump+0x42>
    }
}
    802022b6:	70a2                	ld	ra,40(sp)
    802022b8:	7402                	ld	s0,32(sp)
    802022ba:	64e2                	ld	s1,24(sp)
    802022bc:	6942                	ld	s2,16(sp)
    802022be:	69a2                	ld	s3,8(sp)
    802022c0:	6a02                	ld	s4,0(sp)
    802022c2:	6145                	addi	sp,sp,48
    802022c4:	8082                	ret

00000000802022c6 <swtch>:
# L7 - context switch. Only the CALLEE-SAVED registers need saving: the C
# calling convention says the caller already spilled anything else it cared about.
# Nine loads, nine stores, one ret - and a process wakes up years later, unaware.
        .globl swtch
swtch:
        sd ra,  0(a0)
    802022c6:	00153023          	sd	ra,0(a0)
        sd sp,  8(a0)
    802022ca:	00253423          	sd	sp,8(a0)
        sd s0,  16(a0)
    802022ce:	e900                	sd	s0,16(a0)
        sd s1,  24(a0)
    802022d0:	ed04                	sd	s1,24(a0)
        sd s2,  32(a0)
    802022d2:	03253023          	sd	s2,32(a0)
        sd s3,  40(a0)
    802022d6:	03353423          	sd	s3,40(a0)
        sd s4,  48(a0)
    802022da:	03453823          	sd	s4,48(a0)
        sd s5,  56(a0)
    802022de:	03553c23          	sd	s5,56(a0)
        sd s6,  64(a0)
    802022e2:	05653023          	sd	s6,64(a0)
        sd s7,  72(a0)
    802022e6:	05753423          	sd	s7,72(a0)
        sd s8,  80(a0)
    802022ea:	05853823          	sd	s8,80(a0)
        sd s9,  88(a0)
    802022ee:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    802022f2:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    802022f6:	07b53423          	sd	s11,104(a0)

        ld ra,  0(a1)
    802022fa:	0005b083          	ld	ra,0(a1)
        ld sp,  8(a1)
    802022fe:	0085b103          	ld	sp,8(a1)
        ld s0,  16(a1)
    80202302:	6980                	ld	s0,16(a1)
        ld s1,  24(a1)
    80202304:	6d84                	ld	s1,24(a1)
        ld s2,  32(a1)
    80202306:	0205b903          	ld	s2,32(a1)
        ld s3,  40(a1)
    8020230a:	0285b983          	ld	s3,40(a1)
        ld s4,  48(a1)
    8020230e:	0305ba03          	ld	s4,48(a1)
        ld s5,  56(a1)
    80202312:	0385ba83          	ld	s5,56(a1)
        ld s6,  64(a1)
    80202316:	0405bb03          	ld	s6,64(a1)
        ld s7,  72(a1)
    8020231a:	0485bb83          	ld	s7,72(a1)
        ld s8,  80(a1)
    8020231e:	0505bc03          	ld	s8,80(a1)
        ld s9,  88(a1)
    80202322:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80202326:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8020232a:	0685bd83          	ld	s11,104(a1)
        ret
    8020232e:	8082                	ret

0000000080202330 <cause_str>:
    }
    return 0;
}

static const char *cause_str(uint64 c)
{
    80202330:	1141                	addi	sp,sp,-16
    80202332:	e422                	sd	s0,8(sp)
    80202334:	0800                	addi	s0,sp,16
    switch (c) {
    80202336:	47bd                	li	a5,15
    80202338:	06a7ea63          	bltu	a5,a0,802023ac <cause_str+0x7c>
    8020233c:	050a                	slli	a0,a0,0x2
    8020233e:	00006717          	auipc	a4,0x6
    80202342:	ae270713          	addi	a4,a4,-1310 # 80207e20 <st.0+0x30>
    80202346:	953a                	add	a0,a0,a4
    80202348:	411c                	lw	a5,0(a0)
    8020234a:	97ba                	add	a5,a5,a4
    8020234c:	8782                	jr	a5
    case 0:  return "instruction address misaligned";
    8020234e:	00005517          	auipc	a0,0x5
    80202352:	2d250513          	addi	a0,a0,722 # 80207620 <etext+0x620>
    80202356:	a029                	j	80202360 <cause_str+0x30>
    case 1:  return "instruction access fault";
    case 2:  return "illegal instruction";
    80202358:	00005517          	auipc	a0,0x5
    8020235c:	30850513          	addi	a0,a0,776 # 80207660 <etext+0x660>
    case 12: return "instruction page fault";
    case 13: return "load page fault";
    case 15: return "store page fault";
    default: return "unknown";
    }
}
    80202360:	6422                	ld	s0,8(sp)
    80202362:	0141                	addi	sp,sp,16
    80202364:	8082                	ret
    case 3:  return "breakpoint";
    80202366:	00005517          	auipc	a0,0x5
    8020236a:	31250513          	addi	a0,a0,786 # 80207678 <etext+0x678>
    8020236e:	bfcd                	j	80202360 <cause_str+0x30>
    case 5:  return "load access fault";
    80202370:	00005517          	auipc	a0,0x5
    80202374:	31850513          	addi	a0,a0,792 # 80207688 <etext+0x688>
    80202378:	b7e5                	j	80202360 <cause_str+0x30>
    case 7:  return "store access fault";
    8020237a:	00005517          	auipc	a0,0x5
    8020237e:	32650513          	addi	a0,a0,806 # 802076a0 <etext+0x6a0>
    80202382:	bff9                	j	80202360 <cause_str+0x30>
    case 8:  return "ecall from user";
    80202384:	00005517          	auipc	a0,0x5
    80202388:	33450513          	addi	a0,a0,820 # 802076b8 <etext+0x6b8>
    8020238c:	bfd1                	j	80202360 <cause_str+0x30>
    case 12: return "instruction page fault";
    8020238e:	00005517          	auipc	a0,0x5
    80202392:	33a50513          	addi	a0,a0,826 # 802076c8 <etext+0x6c8>
    80202396:	b7e9                	j	80202360 <cause_str+0x30>
    case 13: return "load page fault";
    80202398:	00005517          	auipc	a0,0x5
    8020239c:	34850513          	addi	a0,a0,840 # 802076e0 <etext+0x6e0>
    802023a0:	b7c1                	j	80202360 <cause_str+0x30>
    case 15: return "store page fault";
    802023a2:	00005517          	auipc	a0,0x5
    802023a6:	34e50513          	addi	a0,a0,846 # 802076f0 <etext+0x6f0>
    802023aa:	bf5d                	j	80202360 <cause_str+0x30>
    default: return "unknown";
    802023ac:	00005517          	auipc	a0,0x5
    802023b0:	35c50513          	addi	a0,a0,860 # 80207708 <etext+0x708>
    802023b4:	b775                	j	80202360 <cause_str+0x30>
    switch (c) {
    802023b6:	00005517          	auipc	a0,0x5
    802023ba:	28a50513          	addi	a0,a0,650 # 80207640 <etext+0x640>
    802023be:	b74d                	j	80202360 <cause_str+0x30>

00000000802023c0 <devintr>:
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    802023c0:	142027f3          	csrr	a5,scause
    if (!(scause & 0x8000000000000000UL)) return 0;   /* top bit = interrupt */
    802023c4:	4501                	li	a0,0
    802023c6:	0e07da63          	bgez	a5,802024ba <devintr+0xfa>
{
    802023ca:	1101                	addi	sp,sp,-32
    802023cc:	ec06                	sd	ra,24(sp)
    802023ce:	e822                	sd	s0,16(sp)
    802023d0:	1000                	addi	s0,sp,32
    uint64 code = scause & 0xff;
    802023d2:	0ff7f793          	zext.b	a5,a5
    if (code == 9) {                     /* supervisor external -> PLIC */
    802023d6:	4725                	li	a4,9
    802023d8:	00e78a63          	beq	a5,a4,802023ec <devintr+0x2c>
    if (code == 5) {
    802023dc:	4715                	li	a4,5
    return 0;
    802023de:	4501                	li	a0,0
    if (code == 5) {
    802023e0:	08e78263          	beq	a5,a4,80202464 <devintr+0xa4>
}
    802023e4:	60e2                	ld	ra,24(sp)
    802023e6:	6442                	ld	s0,16(sp)
    802023e8:	6105                	addi	sp,sp,32
    802023ea:	8082                	ret
    802023ec:	e426                	sd	s1,8(sp)
        int irq = hal_intc_claim();
    802023ee:	00004097          	auipc	ra,0x4
    802023f2:	368080e7          	jalr	872(ra) # 80206756 <hal_intc_claim>
    802023f6:	84aa                	mv	s1,a0
        if (irq == fdt.uart_irq) {
    802023f8:	00027797          	auipc	a5,0x27
    802023fc:	c407a783          	lw	a5,-960(a5) # 80229038 <fdt+0x20>
    80202400:	00a78663          	beq	a5,a0,8020240c <devintr+0x4c>
        return 1;
    80202404:	4505                	li	a0,1
        } else if (irq && irq == hal_block_irq()) {
    80202406:	e09d                	bnez	s1,8020242c <devintr+0x6c>
    80202408:	64a2                	ld	s1,8(sp)
    8020240a:	bfe9                	j	802023e4 <devintr+0x24>
            int c = hal_console_getc();
    8020240c:	00004097          	auipc	ra,0x4
    80202410:	4ae080e7          	jalr	1198(ra) # 802068ba <hal_console_getc>
            if (c != -1) consoleintr(c);
    80202414:	57fd                	li	a5,-1
    80202416:	00f51663          	bne	a0,a5,80202422 <devintr+0x62>
        return 1;
    8020241a:	4505                	li	a0,1
        if (irq) hal_intc_complete(irq);
    8020241c:	e49d                	bnez	s1,8020244a <devintr+0x8a>
    8020241e:	64a2                	ld	s1,8(sp)
    80202420:	b7d1                	j	802023e4 <devintr+0x24>
            if (c != -1) consoleintr(c);
    80202422:	00002097          	auipc	ra,0x2
    80202426:	4b0080e7          	jalr	1200(ra) # 802048d2 <consoleintr>
    8020242a:	bfc5                	j	8020241a <devintr+0x5a>
        } else if (irq && irq == hal_block_irq()) {
    8020242c:	00004097          	auipc	ra,0x4
    80202430:	52e080e7          	jalr	1326(ra) # 8020695a <hal_block_irq>
    80202434:	02950363          	beq	a0,s1,8020245a <devintr+0x9a>
            printf("devintr: unexpected PLIC irq %d\n", irq);
    80202438:	85a6                	mv	a1,s1
    8020243a:	00005517          	auipc	a0,0x5
    8020243e:	2d650513          	addi	a0,a0,726 # 80207710 <etext+0x710>
    80202442:	ffffe097          	auipc	ra,0xffffe
    80202446:	f3e080e7          	jalr	-194(ra) # 80200380 <printf>
        if (irq) hal_intc_complete(irq);
    8020244a:	8526                	mv	a0,s1
    8020244c:	00004097          	auipc	ra,0x4
    80202450:	336080e7          	jalr	822(ra) # 80206782 <hal_intc_complete>
        return 1;
    80202454:	4505                	li	a0,1
    80202456:	64a2                	ld	s1,8(sp)
    80202458:	b771                	j	802023e4 <devintr+0x24>
            hal_block_intr();
    8020245a:	00005097          	auipc	ra,0x5
    8020245e:	9b2080e7          	jalr	-1614(ra) # 80206e0c <hal_block_intr>
    80202462:	b7e5                	j	8020244a <devintr+0x8a>
        if (hal_hart_id() == 0) {        /* only hart 0 keeps the clock */
    80202464:	00004097          	auipc	ra,0x4
    80202468:	34a080e7          	jalr	842(ra) # 802067ae <hal_hart_id>
    8020246c:	c919                	beqz	a0,80202482 <devintr+0xc2>
        hal_timer_next(1000000);
    8020246e:	000f4537          	lui	a0,0xf4
    80202472:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    80202476:	00004097          	auipc	ra,0x4
    8020247a:	3a8080e7          	jalr	936(ra) # 8020681e <hal_timer_next>
        return 2;
    8020247e:	4509                	li	a0,2
    80202480:	b795                	j	802023e4 <devintr+0x24>
    80202482:	e426                	sd	s1,8(sp)
            acquire(&tickslock);
    80202484:	0012f497          	auipc	s1,0x12f
    80202488:	f7c48493          	addi	s1,s1,-132 # 80331400 <tickslock>
    8020248c:	8526                	mv	a0,s1
    8020248e:	fffff097          	auipc	ra,0xfffff
    80202492:	e9a080e7          	jalr	-358(ra) # 80201328 <acquire>
            ticks++;
    80202496:	00148517          	auipc	a0,0x148
    8020249a:	b8250513          	addi	a0,a0,-1150 # 8034a018 <ticks>
    8020249e:	611c                	ld	a5,0(a0)
    802024a0:	0785                	addi	a5,a5,1
    802024a2:	e11c                	sd	a5,0(a0)
            wakeup(&ticks);
    802024a4:	00000097          	auipc	ra,0x0
    802024a8:	aee080e7          	jalr	-1298(ra) # 80201f92 <wakeup>
            release(&tickslock);
    802024ac:	8526                	mv	a0,s1
    802024ae:	fffff097          	auipc	ra,0xfffff
    802024b2:	f2e080e7          	jalr	-210(ra) # 802013dc <release>
    802024b6:	64a2                	ld	s1,8(sp)
    802024b8:	bf5d                	j	8020246e <devintr+0xae>
}
    802024ba:	8082                	ret

00000000802024bc <trapinit_hart>:
{
    802024bc:	1101                	addi	sp,sp,-32
    802024be:	ec06                	sd	ra,24(sp)
    802024c0:	e822                	sd	s0,16(sp)
    802024c2:	e426                	sd	s1,8(sp)
    802024c4:	1000                	addi	s0,sp,32
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    802024c6:	00000797          	auipc	a5,0x0
    802024ca:	32a78793          	addi	a5,a5,810 # 802027f0 <kernelvec>
    802024ce:	10579073          	csrw	stvec,a5
    hal_intc_enable(fdt.uart_irq);              /* priority 1; 0 = never fires */
    802024d2:	00027497          	auipc	s1,0x27
    802024d6:	b4648493          	addi	s1,s1,-1210 # 80229018 <fdt>
    802024da:	5088                	lw	a0,32(s1)
    802024dc:	00004097          	auipc	ra,0x4
    802024e0:	1f0080e7          	jalr	496(ra) # 802066cc <hal_intc_enable>
    hal_intc_hart_init(hal_hart_id());
    802024e4:	00004097          	auipc	ra,0x4
    802024e8:	2ca080e7          	jalr	714(ra) # 802067ae <hal_hart_id>
    802024ec:	00004097          	auipc	ra,0x4
    802024f0:	200080e7          	jalr	512(ra) # 802066ec <hal_intc_hart_init>
    hal_intc_enable_hart(hal_hart_id(), fdt.uart_irq);
    802024f4:	00004097          	auipc	ra,0x4
    802024f8:	2ba080e7          	jalr	698(ra) # 802067ae <hal_hart_id>
    802024fc:	508c                	lw	a1,32(s1)
    802024fe:	00004097          	auipc	ra,0x4
    80202502:	214080e7          	jalr	532(ra) # 80206712 <hal_intc_enable_hart>
    if (hal_block_irq()) {
    80202506:	00004097          	auipc	ra,0x4
    8020250a:	454080e7          	jalr	1108(ra) # 8020695a <hal_block_irq>
    8020250e:	e915                	bnez	a0,80202542 <trapinit_hart+0x86>
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
    80202510:	104027f3          	csrr	a5,sie
    w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80202514:	2227e793          	ori	a5,a5,546
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
    80202518:	10479073          	csrw	sie,a5
    hal_timer_next(1000000);
    8020251c:	000f4537          	lui	a0,0xf4
    80202520:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    80202524:	00004097          	auipc	ra,0x4
    80202528:	2fa080e7          	jalr	762(ra) # 8020681e <hal_timer_next>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020252c:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202530:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202534:	10079073          	csrw	sstatus,a5
}
    80202538:	60e2                	ld	ra,24(sp)
    8020253a:	6442                	ld	s0,16(sp)
    8020253c:	64a2                	ld	s1,8(sp)
    8020253e:	6105                	addi	sp,sp,32
    80202540:	8082                	ret
        hal_intc_enable(hal_block_irq());
    80202542:	00004097          	auipc	ra,0x4
    80202546:	418080e7          	jalr	1048(ra) # 8020695a <hal_block_irq>
    8020254a:	00004097          	auipc	ra,0x4
    8020254e:	182080e7          	jalr	386(ra) # 802066cc <hal_intc_enable>
        hal_intc_enable_hart(hal_hart_id(), hal_block_irq());
    80202552:	00004097          	auipc	ra,0x4
    80202556:	25c080e7          	jalr	604(ra) # 802067ae <hal_hart_id>
    8020255a:	84aa                	mv	s1,a0
    8020255c:	00004097          	auipc	ra,0x4
    80202560:	3fe080e7          	jalr	1022(ra) # 8020695a <hal_block_irq>
    80202564:	85aa                	mv	a1,a0
    80202566:	8526                	mv	a0,s1
    80202568:	00004097          	auipc	ra,0x4
    8020256c:	1aa080e7          	jalr	426(ra) # 80206712 <hal_intc_enable_hart>
    80202570:	b745                	j	80202510 <trapinit_hart+0x54>

0000000080202572 <kerneltrap>:

/* Trap while already in the kernel. */
void kerneltrap(void)
{
    80202572:	7179                	addi	sp,sp,-48
    80202574:	f406                	sd	ra,40(sp)
    80202576:	f022                	sd	s0,32(sp)
    80202578:	ec26                	sd	s1,24(sp)
    8020257a:	e84a                	sd	s2,16(sp)
    8020257c:	e44e                	sd	s3,8(sp)
    8020257e:	1800                	addi	s0,sp,48
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80202580:	14102973          	csrr	s2,sepc
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202584:	100024f3          	csrr	s1,sstatus
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80202588:	142029f3          	csrr	s3,scause
    uint64 sepc     = r_sepc();
    uint64 sstatus  = r_sstatus();
    uint64 scause   = r_scause();

    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    8020258c:	1004f793          	andi	a5,s1,256
    80202590:	cb85                	beqz	a5,802025c0 <kerneltrap+0x4e>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202592:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80202596:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    80202598:	ef85                	bnez	a5,802025d0 <kerneltrap+0x5e>

    int which = devintr();
    8020259a:	00000097          	auipc	ra,0x0
    8020259e:	e26080e7          	jalr	-474(ra) # 802023c0 <devintr>
    if (which == 0) {
    802025a2:	cd1d                	beqz	a0,802025e0 <kerneltrap+0x6e>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
        panic("kernel exception");
    }
    /* Timer: give up the CPU, but only if we are running a process. */
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    802025a4:	4789                	li	a5,2
    802025a6:	06f50463          	beq	a0,a5,8020260e <kerneltrap+0x9c>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    802025aa:	14191073          	csrw	sepc,s2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802025ae:	10049073          	csrw	sstatus,s1
        yield();

    /* yield() may have run other code; restore what sret needs. */
    w_sepc(sepc);
    w_sstatus(sstatus);
}
    802025b2:	70a2                	ld	ra,40(sp)
    802025b4:	7402                	ld	s0,32(sp)
    802025b6:	64e2                	ld	s1,24(sp)
    802025b8:	6942                	ld	s2,16(sp)
    802025ba:	69a2                	ld	s3,8(sp)
    802025bc:	6145                	addi	sp,sp,48
    802025be:	8082                	ret
    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    802025c0:	00005517          	auipc	a0,0x5
    802025c4:	17850513          	addi	a0,a0,376 # 80207738 <etext+0x738>
    802025c8:	ffffe097          	auipc	ra,0xffffe
    802025cc:	02a080e7          	jalr	42(ra) # 802005f2 <panic>
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    802025d0:	00005517          	auipc	a0,0x5
    802025d4:	18850513          	addi	a0,a0,392 # 80207758 <etext+0x758>
    802025d8:	ffffe097          	auipc	ra,0xffffe
    802025dc:	01a080e7          	jalr	26(ra) # 802005f2 <panic>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
    802025e0:	0ff9f513          	zext.b	a0,s3
    802025e4:	00000097          	auipc	ra,0x0
    802025e8:	d4c080e7          	jalr	-692(ra) # 80202330 <cause_str>
    802025ec:	85aa                	mv	a1,a0
    802025ee:	00005517          	auipc	a0,0x5
    802025f2:	19250513          	addi	a0,a0,402 # 80207780 <etext+0x780>
    802025f6:	ffffe097          	auipc	ra,0xffffe
    802025fa:	d8a080e7          	jalr	-630(ra) # 80200380 <printf>
        panic("kernel exception");
    802025fe:	00005517          	auipc	a0,0x5
    80202602:	19a50513          	addi	a0,a0,410 # 80207798 <etext+0x798>
    80202606:	ffffe097          	auipc	ra,0xffffe
    8020260a:	fec080e7          	jalr	-20(ra) # 802005f2 <panic>
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    8020260e:	fffff097          	auipc	ra,0xfffff
    80202612:	158080e7          	jalr	344(ra) # 80201766 <myproc>
    80202616:	d951                	beqz	a0,802025aa <kerneltrap+0x38>
    80202618:	fffff097          	auipc	ra,0xfffff
    8020261c:	14e080e7          	jalr	334(ra) # 80201766 <myproc>
    80202620:	4d18                	lw	a4,24(a0)
    80202622:	4791                	li	a5,4
    80202624:	f8f713e3          	bne	a4,a5,802025aa <kerneltrap+0x38>
        yield();
    80202628:	fffff097          	auipc	ra,0xfffff
    8020262c:	7a8080e7          	jalr	1960(ra) # 80201dd0 <yield>
    80202630:	bfad                	j	802025aa <kerneltrap+0x38>

0000000080202632 <usertrapret>:
    if (p->killed) exit(-1);
    usertrapret();
}

void usertrapret(void)
{
    80202632:	1141                	addi	sp,sp,-16
    80202634:	e406                	sd	ra,8(sp)
    80202636:	e022                	sd	s0,0(sp)
    80202638:	0800                	addi	s0,sp,16
    struct proc *p = myproc();
    8020263a:	fffff097          	auipc	ra,0xfffff
    8020263e:	12c080e7          	jalr	300(ra) # 80201766 <myproc>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202642:	100027f3          	csrr	a5,sstatus
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    80202646:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202648:	10079073          	csrw	sstatus,a5
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    8020264c:	00000797          	auipc	a5,0x0
    80202650:	20478793          	addi	a5,a5,516 # 80202850 <uservec>
    80202654:	10579073          	csrw	stvec,a5

    intr_off();                       /* no interrupts between stvec and sret */
    w_stvec((uint64)uservec);

    p->tf->kernel_satp   = r_satp();
    80202658:	6d3c                	ld	a5,88(a0)
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    8020265a:	18002773          	csrr	a4,satp
    8020265e:	e398                	sd	a4,0(a5)
    p->tf->kernel_sp     = p->kstack + 4 * PGSIZE;   /* top of the kernel stack */
    80202660:	6d38                	ld	a4,88(a0)
    80202662:	613c                	ld	a5,64(a0)
    80202664:	6691                	lui	a3,0x4
    80202666:	97b6                	add	a5,a5,a3
    80202668:	e71c                	sd	a5,8(a4)
    p->tf->kernel_trap   = (uint64)usertrap;
    8020266a:	6d3c                	ld	a5,88(a0)
    8020266c:	00000717          	auipc	a4,0x0
    80202670:	03870713          	addi	a4,a4,56 # 802026a4 <usertrap>
    80202674:	eb98                	sd	a4,16(a5)
    p->tf->kernel_hartid = r_tp();
    80202676:	6d3c                	ld	a5,88(a0)
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    80202678:	8712                	mv	a4,tp
    8020267a:	f398                	sd	a4,32(a5)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020267c:	100027f3          	csrr	a5,sstatus

    uint64 x = r_sstatus();
    x &= ~SSTATUS_SPP;                /* SPP=0 -> sret drops us to U-mode */
    80202680:	eff7f793          	andi	a5,a5,-257
    x |= SSTATUS_SPIE;                /* re-enable interrupts in user mode */
    80202684:	0207e793          	ori	a5,a5,32
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202688:	10079073          	csrw	sstatus,a5
    w_sstatus(x);
    w_sepc(p->tf->epc);
    8020268c:	6d28                	ld	a0,88(a0)
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    8020268e:	6d1c                	ld	a5,24(a0)
    80202690:	14179073          	csrw	sepc,a5

    userret(p->tf);
    80202694:	00000097          	auipc	ra,0x0
    80202698:	248080e7          	jalr	584(ra) # 802028dc <userret>
}
    8020269c:	60a2                	ld	ra,8(sp)
    8020269e:	6402                	ld	s0,0(sp)
    802026a0:	0141                	addi	sp,sp,16
    802026a2:	8082                	ret

00000000802026a4 <usertrap>:
{
    802026a4:	7179                	addi	sp,sp,-48
    802026a6:	f406                	sd	ra,40(sp)
    802026a8:	f022                	sd	s0,32(sp)
    802026aa:	1800                	addi	s0,sp,48
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802026ac:	100027f3          	csrr	a5,sstatus
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    802026b0:	1007f793          	andi	a5,a5,256
    802026b4:	efa9                	bnez	a5,8020270e <usertrap+0x6a>
    802026b6:	ec26                	sd	s1,24(sp)
    802026b8:	e84a                	sd	s2,16(sp)
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    802026ba:	00000797          	auipc	a5,0x0
    802026be:	13678793          	addi	a5,a5,310 # 802027f0 <kernelvec>
    802026c2:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    802026c6:	fffff097          	auipc	ra,0xfffff
    802026ca:	0a0080e7          	jalr	160(ra) # 80201766 <myproc>
    802026ce:	84aa                	mv	s1,a0
    p->tf->epc = r_sepc();
    802026d0:	6d3c                	ld	a5,88(a0)
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    802026d2:	14102773          	csrr	a4,sepc
    802026d6:	ef98                	sd	a4,24(a5)
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    802026d8:	14202973          	csrr	s2,scause
    if (scause == 8) {               /* ecall: a system call */
    802026dc:	47a1                	li	a5,8
    802026de:	04f90463          	beq	s2,a5,80202726 <usertrap+0x82>
    } else if (scause == 15 || scause == 13) {   /* store / load page fault */
    802026e2:	ffd97793          	andi	a5,s2,-3
    802026e6:	4735                	li	a4,13
    802026e8:	08e78263          	beq	a5,a4,8020276c <usertrap+0xc8>
        int which = devintr();
    802026ec:	00000097          	auipc	ra,0x0
    802026f0:	cd4080e7          	jalr	-812(ra) # 802023c0 <devintr>
        if (which == 0) {
    802026f4:	c95d                	beqz	a0,802027aa <usertrap+0x106>
        if (which == 2 && p->state == RUNNING) yield();
    802026f6:	4789                	li	a5,2
    802026f8:	04f51763          	bne	a0,a5,80202746 <usertrap+0xa2>
    802026fc:	4c98                	lw	a4,24(s1)
    802026fe:	4791                	li	a5,4
    80202700:	04f71363          	bne	a4,a5,80202746 <usertrap+0xa2>
    80202704:	fffff097          	auipc	ra,0xfffff
    80202708:	6cc080e7          	jalr	1740(ra) # 80201dd0 <yield>
    8020270c:	a82d                	j	80202746 <usertrap+0xa2>
    8020270e:	ec26                	sd	s1,24(sp)
    80202710:	e84a                	sd	s2,16(sp)
    80202712:	e44e                	sd	s3,8(sp)
    80202714:	e052                	sd	s4,0(sp)
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    80202716:	00005517          	auipc	a0,0x5
    8020271a:	09a50513          	addi	a0,a0,154 # 802077b0 <etext+0x7b0>
    8020271e:	ffffe097          	auipc	ra,0xffffe
    80202722:	ed4080e7          	jalr	-300(ra) # 802005f2 <panic>
        if (p->killed) exit(-1);
    80202726:	551c                	lw	a5,40(a0)
    80202728:	eb9d                	bnez	a5,8020275e <usertrap+0xba>
        p->tf->epc += 4;             /* return AFTER the ecall, not onto it */
    8020272a:	6d38                	ld	a4,88(a0)
    8020272c:	6f1c                	ld	a5,24(a4)
    8020272e:	0791                	addi	a5,a5,4
    80202730:	ef1c                	sd	a5,24(a4)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202732:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202736:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    8020273a:	10079073          	csrw	sstatus,a5
        syscall();
    8020273e:	00001097          	auipc	ra,0x1
    80202742:	e88080e7          	jalr	-376(ra) # 802035c6 <syscall>
    if (p->killed) exit(-1);
    80202746:	549c                	lw	a5,40(s1)
    80202748:	ebd9                	bnez	a5,802027de <usertrap+0x13a>
    usertrapret();
    8020274a:	00000097          	auipc	ra,0x0
    8020274e:	ee8080e7          	jalr	-280(ra) # 80202632 <usertrapret>
    80202752:	64e2                	ld	s1,24(sp)
    80202754:	6942                	ld	s2,16(sp)
}
    80202756:	70a2                	ld	ra,40(sp)
    80202758:	7402                	ld	s0,32(sp)
    8020275a:	6145                	addi	sp,sp,48
    8020275c:	8082                	ret
    8020275e:	e44e                	sd	s3,8(sp)
    80202760:	e052                	sd	s4,0(sp)
        if (p->killed) exit(-1);
    80202762:	557d                	li	a0,-1
    80202764:	00000097          	auipc	ra,0x0
    80202768:	8a4080e7          	jalr	-1884(ra) # 80202008 <exit>
    8020276c:	e44e                	sd	s3,8(sp)
    8020276e:	e052                	sd	s4,0(sp)
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80202770:	14302a73          	csrr	s4,stval
        printf("usertrap: pid %d %s at va %p (sepc %p) - killing\n",
    80202774:	03052983          	lw	s3,48(a0)
    80202778:	854a                	mv	a0,s2
    8020277a:	00000097          	auipc	ra,0x0
    8020277e:	bb6080e7          	jalr	-1098(ra) # 80202330 <cause_str>
    80202782:	862a                	mv	a2,a0
    80202784:	6cbc                	ld	a5,88(s1)
    80202786:	6f98                	ld	a4,24(a5)
    80202788:	86d2                	mv	a3,s4
    8020278a:	85ce                	mv	a1,s3
    8020278c:	00005517          	auipc	a0,0x5
    80202790:	04450513          	addi	a0,a0,68 # 802077d0 <etext+0x7d0>
    80202794:	ffffe097          	auipc	ra,0xffffe
    80202798:	bec080e7          	jalr	-1044(ra) # 80200380 <printf>
        p->killed = 1;
    8020279c:	4785                	li	a5,1
    8020279e:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    802027a0:	557d                	li	a0,-1
    802027a2:	00000097          	auipc	ra,0x0
    802027a6:	866080e7          	jalr	-1946(ra) # 80202008 <exit>
    802027aa:	e44e                	sd	s3,8(sp)
            printf("usertrap: pid %d unexpected %s (scause %p, stval %p) - killing\n",
    802027ac:	0304a983          	lw	s3,48(s1)
    802027b0:	0ff97513          	zext.b	a0,s2
    802027b4:	00000097          	auipc	ra,0x0
    802027b8:	b7c080e7          	jalr	-1156(ra) # 80202330 <cause_str>
    802027bc:	862a                	mv	a2,a0
    802027be:	14302773          	csrr	a4,stval
    802027c2:	86ca                	mv	a3,s2
    802027c4:	85ce                	mv	a1,s3
    802027c6:	00005517          	auipc	a0,0x5
    802027ca:	04250513          	addi	a0,a0,66 # 80207808 <etext+0x808>
    802027ce:	ffffe097          	auipc	ra,0xffffe
    802027d2:	bb2080e7          	jalr	-1102(ra) # 80200380 <printf>
            p->killed = 1;
    802027d6:	4785                	li	a5,1
    802027d8:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    802027da:	e052                	sd	s4,0(sp)
    802027dc:	b7d1                	j	802027a0 <usertrap+0xfc>
    802027de:	e44e                	sd	s3,8(sp)
    802027e0:	e052                	sd	s4,0(sp)
    802027e2:	bf7d                	j	802027a0 <usertrap+0xfc>
	...

00000000802027f0 <kernelvec>:
        .globl kernelvec
        .align 4
kernelvec:
        # We were already in the kernel: our sp is a valid kernel stack.
        # Save every caller-saved register - kerneltrap() is C and may clobber them.
        addi    sp, sp, -256
    802027f0:	7111                	addi	sp,sp,-256
        sd      ra, 0(sp)
    802027f2:	e006                	sd	ra,0(sp)
        sd      sp, 8(sp)
    802027f4:	e40a                	sd	sp,8(sp)
        sd      gp, 16(sp)
    802027f6:	e80e                	sd	gp,16(sp)
        sd      tp, 24(sp)
    802027f8:	ec12                	sd	tp,24(sp)
        sd      t0, 32(sp)
    802027fa:	f016                	sd	t0,32(sp)
        sd      t1, 40(sp)
    802027fc:	f41a                	sd	t1,40(sp)
        sd      t2, 48(sp)
    802027fe:	f81e                	sd	t2,48(sp)
        sd      a0, 72(sp)
    80202800:	e4aa                	sd	a0,72(sp)
        sd      a1, 80(sp)
    80202802:	e8ae                	sd	a1,80(sp)
        sd      a2, 88(sp)
    80202804:	ecb2                	sd	a2,88(sp)
        sd      a3, 96(sp)
    80202806:	f0b6                	sd	a3,96(sp)
        sd      a4, 104(sp)
    80202808:	f4ba                	sd	a4,104(sp)
        sd      a5, 112(sp)
    8020280a:	f8be                	sd	a5,112(sp)
        sd      a6, 120(sp)
    8020280c:	fcc2                	sd	a6,120(sp)
        sd      a7, 128(sp)
    8020280e:	e146                	sd	a7,128(sp)
        sd      t3, 216(sp)
    80202810:	edf2                	sd	t3,216(sp)
        sd      t4, 224(sp)
    80202812:	f1f6                	sd	t4,224(sp)
        sd      t5, 232(sp)
    80202814:	f5fa                	sd	t5,232(sp)
        sd      t6, 240(sp)
    80202816:	f9fe                	sd	t6,240(sp)

        call    kerneltrap
    80202818:	00000097          	auipc	ra,0x0
    8020281c:	d5a080e7          	jalr	-678(ra) # 80202572 <kerneltrap>

        ld      ra, 0(sp)
    80202820:	6082                	ld	ra,0(sp)
        ld      gp, 16(sp)
    80202822:	61c2                	ld	gp,16(sp)
        # NOT tp - kerneltrap may have moved us to another hart's scheduler.
        ld      t0, 32(sp)
    80202824:	7282                	ld	t0,32(sp)
        ld      t1, 40(sp)
    80202826:	7322                	ld	t1,40(sp)
        ld      t2, 48(sp)
    80202828:	73c2                	ld	t2,48(sp)
        ld      a0, 72(sp)
    8020282a:	6526                	ld	a0,72(sp)
        ld      a1, 80(sp)
    8020282c:	65c6                	ld	a1,80(sp)
        ld      a2, 88(sp)
    8020282e:	6666                	ld	a2,88(sp)
        ld      a3, 96(sp)
    80202830:	7686                	ld	a3,96(sp)
        ld      a4, 104(sp)
    80202832:	7726                	ld	a4,104(sp)
        ld      a5, 112(sp)
    80202834:	77c6                	ld	a5,112(sp)
        ld      a6, 120(sp)
    80202836:	7866                	ld	a6,120(sp)
        ld      a7, 128(sp)
    80202838:	688a                	ld	a7,128(sp)
        ld      t3, 216(sp)
    8020283a:	6e6e                	ld	t3,216(sp)
        ld      t4, 224(sp)
    8020283c:	7e8e                	ld	t4,224(sp)
        ld      t5, 232(sp)
    8020283e:	7f2e                	ld	t5,232(sp)
        ld      t6, 240(sp)
    80202840:	7fce                	ld	t6,240(sp)
        addi    sp, sp, 256
    80202842:	6111                	addi	sp,sp,256
        # sepc/sstatus were saved+restored by kerneltrap() in C.
        sret
    80202844:	10200073          	sret
    80202848:	00000013          	nop
    8020284c:	00000013          	nop

0000000080202850 <uservec>:
        .globl uservec
        .globl userret
        .globl usertrap
        .align 4
uservec:
        csrrw   a0, sscratch, a0        # a0 = &tf ; sscratch = user's a0
    80202850:	14051573          	csrrw	a0,sscratch,a0

        sd ra,  40(a0)
    80202854:	02153423          	sd	ra,40(a0)
        sd sp,  48(a0)
    80202858:	02253823          	sd	sp,48(a0)
        sd gp,  56(a0)
    8020285c:	02353c23          	sd	gp,56(a0)
        sd tp,  64(a0)
    80202860:	04453023          	sd	tp,64(a0)
        sd t0,  72(a0)
    80202864:	04553423          	sd	t0,72(a0)
        sd t1,  80(a0)
    80202868:	04653823          	sd	t1,80(a0)
        sd t2,  88(a0)
    8020286c:	04753c23          	sd	t2,88(a0)
        sd s0,  96(a0)
    80202870:	f120                	sd	s0,96(a0)
        sd s1,  104(a0)
    80202872:	f524                	sd	s1,104(a0)
        sd a1,  120(a0)
    80202874:	fd2c                	sd	a1,120(a0)
        sd a2,  128(a0)
    80202876:	e150                	sd	a2,128(a0)
        sd a3,  136(a0)
    80202878:	e554                	sd	a3,136(a0)
        sd a4,  144(a0)
    8020287a:	e958                	sd	a4,144(a0)
        sd a5,  152(a0)
    8020287c:	ed5c                	sd	a5,152(a0)
        sd a6,  160(a0)
    8020287e:	0b053023          	sd	a6,160(a0)
        sd a7,  168(a0)
    80202882:	0b153423          	sd	a7,168(a0)
        sd s2,  176(a0)
    80202886:	0b253823          	sd	s2,176(a0)
        sd s3,  184(a0)
    8020288a:	0b353c23          	sd	s3,184(a0)
        sd s4,  192(a0)
    8020288e:	0d453023          	sd	s4,192(a0)
        sd s5,  200(a0)
    80202892:	0d553423          	sd	s5,200(a0)
        sd s6,  208(a0)
    80202896:	0d653823          	sd	s6,208(a0)
        sd s7,  216(a0)
    8020289a:	0d753c23          	sd	s7,216(a0)
        sd s8,  224(a0)
    8020289e:	0f853023          	sd	s8,224(a0)
        sd s9,  232(a0)
    802028a2:	0f953423          	sd	s9,232(a0)
        sd s10, 240(a0)
    802028a6:	0fa53823          	sd	s10,240(a0)
        sd s11, 248(a0)
    802028aa:	0fb53c23          	sd	s11,248(a0)
        sd t3,  256(a0)
    802028ae:	11c53023          	sd	t3,256(a0)
        sd t4,  264(a0)
    802028b2:	11d53423          	sd	t4,264(a0)
        sd t5,  272(a0)
    802028b6:	11e53823          	sd	t5,272(a0)
        sd t6,  280(a0)
    802028ba:	11f53c23          	sd	t6,280(a0)

        csrr    t0, sscratch            # t0 = user's original a0
    802028be:	140022f3          	csrr	t0,sscratch
        sd      t0, 112(a0)             # tf->a0
    802028c2:	06553823          	sd	t0,112(a0)

        csrr    t1, sepc
    802028c6:	14102373          	csrr	t1,sepc
        sd      t1, 24(a0)              # tf->epc = where user was
    802028ca:	00653c23          	sd	t1,24(a0)

        ld      tp, 32(a0)              # restore our hartid into tp
    802028ce:	02053203          	ld	tp,32(a0)
        ld      sp, 8(a0)               # switch to the kernel stack
    802028d2:	00853103          	ld	sp,8(a0)
        ld      t1, 16(a0)              # tf->kernel_trap = &usertrap
    802028d6:	01053303          	ld	t1,16(a0)
        jr      t1
    802028da:	8302                	jr	t1

00000000802028dc <userret>:

# void userret(struct trapframe *tf)  -- a0 = tf
userret:
        csrw    sscratch, a0            # so the next uservec can find it
    802028dc:	14051073          	csrw	sscratch,a0

        ld t0,  24(a0)
    802028e0:	01853283          	ld	t0,24(a0)
        csrw    sepc, t0                # return to where the user left off
    802028e4:	14129073          	csrw	sepc,t0

        ld ra,  40(a0)
    802028e8:	02853083          	ld	ra,40(a0)
        ld sp,  48(a0)
    802028ec:	03053103          	ld	sp,48(a0)
        ld gp,  56(a0)
    802028f0:	03853183          	ld	gp,56(a0)
        ld tp,  64(a0)
    802028f4:	04053203          	ld	tp,64(a0)
        ld t0,  72(a0)
    802028f8:	04853283          	ld	t0,72(a0)
        ld t1,  80(a0)
    802028fc:	05053303          	ld	t1,80(a0)
        ld t2,  88(a0)
    80202900:	05853383          	ld	t2,88(a0)
        ld s0,  96(a0)
    80202904:	7120                	ld	s0,96(a0)
        ld s1,  104(a0)
    80202906:	7524                	ld	s1,104(a0)
        ld a1,  120(a0)
    80202908:	7d2c                	ld	a1,120(a0)
        ld a2,  128(a0)
    8020290a:	6150                	ld	a2,128(a0)
        ld a3,  136(a0)
    8020290c:	6554                	ld	a3,136(a0)
        ld a4,  144(a0)
    8020290e:	6958                	ld	a4,144(a0)
        ld a5,  152(a0)
    80202910:	6d5c                	ld	a5,152(a0)
        ld a6,  160(a0)
    80202912:	0a053803          	ld	a6,160(a0)
        ld a7,  168(a0)
    80202916:	0a853883          	ld	a7,168(a0)
        ld s2,  176(a0)
    8020291a:	0b053903          	ld	s2,176(a0)
        ld s3,  184(a0)
    8020291e:	0b853983          	ld	s3,184(a0)
        ld s4,  192(a0)
    80202922:	0c053a03          	ld	s4,192(a0)
        ld s5,  200(a0)
    80202926:	0c853a83          	ld	s5,200(a0)
        ld s6,  208(a0)
    8020292a:	0d053b03          	ld	s6,208(a0)
        ld s7,  216(a0)
    8020292e:	0d853b83          	ld	s7,216(a0)
        ld s8,  224(a0)
    80202932:	0e053c03          	ld	s8,224(a0)
        ld s9,  232(a0)
    80202936:	0e853c83          	ld	s9,232(a0)
        ld s10, 240(a0)
    8020293a:	0f053d03          	ld	s10,240(a0)
        ld s11, 248(a0)
    8020293e:	0f853d83          	ld	s11,248(a0)
        ld t3,  256(a0)
    80202942:	10053e03          	ld	t3,256(a0)
        ld t4,  264(a0)
    80202946:	10853e83          	ld	t4,264(a0)
        ld t5,  272(a0)
    8020294a:	11053f03          	ld	t5,272(a0)
        ld t6,  280(a0)
    8020294e:	11853f83          	ld	t6,280(a0)

        ld a0,  112(a0)                 # finally, the user's a0 (syscall retval)
    80202952:	7928                	ld	a0,112(a0)
        sret
    80202954:	10200073          	sret
    80202958:	00000013          	nop
    8020295c:	00000013          	nop

0000000080202960 <freewalk_user>:
}

/* Free ONLY the user half of the tree (indices 0..1). Kernel entries are
 * borrowed, not owned - freeing them would take down every other process. */
static void freewalk_user(pagetable_t pt, int level)
{
    80202960:	7139                	addi	sp,sp,-64
    80202962:	fc06                	sd	ra,56(sp)
    80202964:	f822                	sd	s0,48(sp)
    80202966:	f426                	sd	s1,40(sp)
    80202968:	f04a                	sd	s2,32(sp)
    8020296a:	ec4e                	sd	s3,24(sp)
    8020296c:	e852                	sd	s4,16(sp)
    8020296e:	e456                	sd	s5,8(sp)
    80202970:	0080                	addi	s0,sp,64
    80202972:	89aa                	mv	s3,a0
    80202974:	8a2e                	mv	s4,a1
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    80202976:	4789                	li	a5,2
    80202978:	20000913          	li	s2,512
    8020297c:	02f58c63          	beq	a1,a5,802029b4 <freewalk_user+0x54>
    for (int i = 0; i < limit; i++) {
    80202980:	84ce                	mv	s1,s3
    80202982:	090e                	slli	s2,s2,0x3
    80202984:	994e                	add	s2,s2,s3
        pte_t pte = pt[i];
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80202986:	4a85                	li	s5,1
        pte_t pte = pt[i];
    80202988:	609c                	ld	a5,0(s1)
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8020298a:	00f7f713          	andi	a4,a5,15
    8020298e:	03570563          	beq	a4,s5,802029b8 <freewalk_user+0x58>
    for (int i = 0; i < limit; i++) {
    80202992:	04a1                	addi	s1,s1,8
    80202994:	ff249ae3          	bne	s1,s2,80202988 <freewalk_user+0x28>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
            pt[i] = 0;
        }
    }
    pfree((void *)pt);
    80202998:	854e                	mv	a0,s3
    8020299a:	fffff097          	auipc	ra,0xfffff
    8020299e:	810080e7          	jalr	-2032(ra) # 802011aa <pfree>
}
    802029a2:	70e2                	ld	ra,56(sp)
    802029a4:	7442                	ld	s0,48(sp)
    802029a6:	74a2                	ld	s1,40(sp)
    802029a8:	7902                	ld	s2,32(sp)
    802029aa:	69e2                	ld	s3,24(sp)
    802029ac:	6a42                	ld	s4,16(sp)
    802029ae:	6aa2                	ld	s5,8(sp)
    802029b0:	6121                	addi	sp,sp,64
    802029b2:	8082                	ret
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    802029b4:	892e                	mv	s2,a1
    802029b6:	b7e9                	j	80202980 <freewalk_user+0x20>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
    802029b8:	83a9                	srli	a5,a5,0xa
    802029ba:	fffa059b          	addiw	a1,s4,-1
    802029be:	00c79513          	slli	a0,a5,0xc
    802029c2:	00000097          	auipc	ra,0x0
    802029c6:	f9e080e7          	jalr	-98(ra) # 80202960 <freewalk_user>
            pt[i] = 0;
    802029ca:	0004b023          	sd	zero,0(s1)
    802029ce:	b7d1                	j	80202992 <freewalk_user+0x32>

00000000802029d0 <vmprint_lvl>:
    return got_null ? 0 : -1;
}

/* Debug aid you will use all semester, and in Viva #2. */
static void vmprint_lvl(pagetable_t pt, int level)
{
    802029d0:	711d                	addi	sp,sp,-96
    802029d2:	ec86                	sd	ra,88(sp)
    802029d4:	e8a2                	sd	s0,80(sp)
    802029d6:	e4a6                	sd	s1,72(sp)
    802029d8:	e0ca                	sd	s2,64(sp)
    802029da:	fc4e                	sd	s3,56(sp)
    802029dc:	f852                	sd	s4,48(sp)
    802029de:	f456                	sd	s5,40(sp)
    802029e0:	f05a                	sd	s6,32(sp)
    802029e2:	ec5e                	sd	s7,24(sp)
    802029e4:	e862                	sd	s8,16(sp)
    802029e6:	e466                	sd	s9,8(sp)
    802029e8:	e06a                	sd	s10,0(sp)
    802029ea:	1080                	addi	s0,sp,96
    802029ec:	892e                	mv	s2,a1
    for (int i = 0; i < 512; i++) {
    802029ee:	8b2a                	mv	s6,a0
    802029f0:	4a01                	li	s4,0
        pte_t pte = pt[i];
        if (!(pte & PTE_V)) continue;
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    802029f2:	4b89                	li	s7,2
        for (int d = 2; d >= level; d--) printf(" ..");
    802029f4:	00005a97          	auipc	s5,0x5
    802029f8:	e54a8a93          	addi	s5,s5,-428 # 80207848 <etext+0x848>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    802029fc:	00005c97          	auipc	s9,0x5
    80202a00:	e54c8c93          	addi	s9,s9,-428 # 80207850 <etext+0x850>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202a04:	4d05                	li	s10,1
    for (int i = 0; i < 512; i++) {
    80202a06:	20000c13          	li	s8,512
    80202a0a:	a089                	j	80202a4c <vmprint_lvl+0x7c>
        for (int d = 2; d >= level; d--) printf(" ..");
    80202a0c:	84de                	mv	s1,s7
    80202a0e:	052bca63          	blt	s7,s2,80202a62 <vmprint_lvl+0x92>
    80202a12:	8556                	mv	a0,s5
    80202a14:	ffffe097          	auipc	ra,0xffffe
    80202a18:	96c080e7          	jalr	-1684(ra) # 80200380 <printf>
    80202a1c:	34fd                	addiw	s1,s1,-1
    80202a1e:	ff24dae3          	bge	s1,s2,80202a12 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202a22:	00a9d493          	srli	s1,s3,0xa
    80202a26:	04b2                	slli	s1,s1,0xc
    80202a28:	86a6                	mv	a3,s1
    80202a2a:	864e                	mv	a2,s3
    80202a2c:	85d2                	mv	a1,s4
    80202a2e:	8566                	mv	a0,s9
    80202a30:	ffffe097          	auipc	ra,0xffffe
    80202a34:	950080e7          	jalr	-1712(ra) # 80200380 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202a38:	00e9f993          	andi	s3,s3,14
    80202a3c:	00099463          	bnez	s3,80202a44 <vmprint_lvl+0x74>
    80202a40:	05204063          	bgtz	s2,80202a80 <vmprint_lvl+0xb0>
    for (int i = 0; i < 512; i++) {
    80202a44:	2a05                	addiw	s4,s4,1
    80202a46:	0b21                	addi	s6,s6,8
    80202a48:	058a0463          	beq	s4,s8,80202a90 <vmprint_lvl+0xc0>
        pte_t pte = pt[i];
    80202a4c:	000b3983          	ld	s3,0(s6)
        if (!(pte & PTE_V)) continue;
    80202a50:	0019f793          	andi	a5,s3,1
    80202a54:	dbe5                	beqz	a5,80202a44 <vmprint_lvl+0x74>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202a56:	fb791be3          	bne	s2,s7,80202a0c <vmprint_lvl+0x3c>
    80202a5a:	ff4d45e3          	blt	s10,s4,80202a44 <vmprint_lvl+0x74>
    80202a5e:	84ca                	mv	s1,s2
    80202a60:	bf4d                	j	80202a12 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202a62:	00a9d493          	srli	s1,s3,0xa
    80202a66:	04b2                	slli	s1,s1,0xc
    80202a68:	86a6                	mv	a3,s1
    80202a6a:	864e                	mv	a2,s3
    80202a6c:	85d2                	mv	a1,s4
    80202a6e:	8566                	mv	a0,s9
    80202a70:	ffffe097          	auipc	ra,0xffffe
    80202a74:	910080e7          	jalr	-1776(ra) # 80200380 <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202a78:	00e9f993          	andi	s3,s3,14
    80202a7c:	fc0994e3          	bnez	s3,80202a44 <vmprint_lvl+0x74>
            vmprint_lvl((pagetable_t)PTE2PA(pte), level - 1);
    80202a80:	fff9059b          	addiw	a1,s2,-1
    80202a84:	8526                	mv	a0,s1
    80202a86:	00000097          	auipc	ra,0x0
    80202a8a:	f4a080e7          	jalr	-182(ra) # 802029d0 <vmprint_lvl>
    80202a8e:	bf5d                	j	80202a44 <vmprint_lvl+0x74>
    }
}
    80202a90:	60e6                	ld	ra,88(sp)
    80202a92:	6446                	ld	s0,80(sp)
    80202a94:	64a6                	ld	s1,72(sp)
    80202a96:	6906                	ld	s2,64(sp)
    80202a98:	79e2                	ld	s3,56(sp)
    80202a9a:	7a42                	ld	s4,48(sp)
    80202a9c:	7aa2                	ld	s5,40(sp)
    80202a9e:	7b02                	ld	s6,32(sp)
    80202aa0:	6be2                	ld	s7,24(sp)
    80202aa2:	6c42                	ld	s8,16(sp)
    80202aa4:	6ca2                	ld	s9,8(sp)
    80202aa6:	6d02                	ld	s10,0(sp)
    80202aa8:	6125                	addi	sp,sp,96
    80202aaa:	8082                	ret

0000000080202aac <mmio_alias>:
uint64 mmio_alias(uint64 pa) { return MMIO_VA(pa); }
    80202aac:	1141                	addi	sp,sp,-16
    80202aae:	e422                	sd	s0,8(sp)
    80202ab0:	0800                	addi	s0,sp,16
    80202ab2:	4785                	li	a5,1
    80202ab4:	1782                	slli	a5,a5,0x20
    80202ab6:	953e                	add	a0,a0,a5
    80202ab8:	6422                	ld	s0,8(sp)
    80202aba:	0141                	addi	sp,sp,16
    80202abc:	8082                	ret

0000000080202abe <walk>:
{
    80202abe:	7139                	addi	sp,sp,-64
    80202ac0:	fc06                	sd	ra,56(sp)
    80202ac2:	f822                	sd	s0,48(sp)
    80202ac4:	f426                	sd	s1,40(sp)
    80202ac6:	f04a                	sd	s2,32(sp)
    80202ac8:	ec4e                	sd	s3,24(sp)
    80202aca:	e852                	sd	s4,16(sp)
    80202acc:	e456                	sd	s5,8(sp)
    80202ace:	e05a                	sd	s6,0(sp)
    80202ad0:	0080                	addi	s0,sp,64
    80202ad2:	84aa                	mv	s1,a0
    80202ad4:	89ae                	mv	s3,a1
    80202ad6:	8ab2                	mv	s5,a2
    if (va >= MAXVA) panic("walk: va out of range");
    80202ad8:	57fd                	li	a5,-1
    80202ada:	83e9                	srli	a5,a5,0x1a
    80202adc:	4a79                	li	s4,30
    for (int level = 2; level > 0; level--) {
    80202ade:	4b31                	li	s6,12
    if (va >= MAXVA) panic("walk: va out of range");
    80202ae0:	04b7f263          	bgeu	a5,a1,80202b24 <walk+0x66>
    80202ae4:	00005517          	auipc	a0,0x5
    80202ae8:	d8450513          	addi	a0,a0,-636 # 80207868 <etext+0x868>
    80202aec:	ffffe097          	auipc	ra,0xffffe
    80202af0:	b06080e7          	jalr	-1274(ra) # 802005f2 <panic>
            if (!alloc) return 0;
    80202af4:	060a8663          	beqz	s5,80202b60 <walk+0xa2>
            pt = (pagetable_t)palloc();
    80202af8:	ffffe097          	auipc	ra,0xffffe
    80202afc:	5a2080e7          	jalr	1442(ra) # 8020109a <palloc>
    80202b00:	84aa                	mv	s1,a0
            if (!pt) return 0;
    80202b02:	c529                	beqz	a0,80202b4c <walk+0x8e>
            memset(pt, 0, PGSIZE);
    80202b04:	6605                	lui	a2,0x1
    80202b06:	4581                	li	a1,0
    80202b08:	ffffe097          	auipc	ra,0xffffe
    80202b0c:	b90080e7          	jalr	-1136(ra) # 80200698 <memset>
            *pte = PA2PTE(pt) | PTE_V;
    80202b10:	00c4d793          	srli	a5,s1,0xc
    80202b14:	07aa                	slli	a5,a5,0xa
    80202b16:	0017e793          	ori	a5,a5,1
    80202b1a:	00f93023          	sd	a5,0(s2)
    for (int level = 2; level > 0; level--) {
    80202b1e:	3a5d                	addiw	s4,s4,-9
    80202b20:	036a0063          	beq	s4,s6,80202b40 <walk+0x82>
        pte_t *pte = &pt[PX(level, va)];
    80202b24:	0149d933          	srl	s2,s3,s4
    80202b28:	1ff97913          	andi	s2,s2,511
    80202b2c:	090e                	slli	s2,s2,0x3
    80202b2e:	9926                	add	s2,s2,s1
        if (*pte & PTE_V) {
    80202b30:	00093483          	ld	s1,0(s2)
    80202b34:	0014f793          	andi	a5,s1,1
    80202b38:	dfd5                	beqz	a5,80202af4 <walk+0x36>
            pt = (pagetable_t)PTE2PA(*pte);
    80202b3a:	80a9                	srli	s1,s1,0xa
    80202b3c:	04b2                	slli	s1,s1,0xc
    80202b3e:	b7c5                	j	80202b1e <walk+0x60>
    return &pt[PX(0, va)];
    80202b40:	00c9d513          	srli	a0,s3,0xc
    80202b44:	1ff57513          	andi	a0,a0,511
    80202b48:	050e                	slli	a0,a0,0x3
    80202b4a:	9526                	add	a0,a0,s1
}
    80202b4c:	70e2                	ld	ra,56(sp)
    80202b4e:	7442                	ld	s0,48(sp)
    80202b50:	74a2                	ld	s1,40(sp)
    80202b52:	7902                	ld	s2,32(sp)
    80202b54:	69e2                	ld	s3,24(sp)
    80202b56:	6a42                	ld	s4,16(sp)
    80202b58:	6aa2                	ld	s5,8(sp)
    80202b5a:	6b02                	ld	s6,0(sp)
    80202b5c:	6121                	addi	sp,sp,64
    80202b5e:	8082                	ret
            if (!alloc) return 0;
    80202b60:	4501                	li	a0,0
    80202b62:	b7ed                	j	80202b4c <walk+0x8e>

0000000080202b64 <walkaddr>:
    if (va >= MAXVA) return 0;
    80202b64:	57fd                	li	a5,-1
    80202b66:	83e9                	srli	a5,a5,0x1a
    80202b68:	00b7f463          	bgeu	a5,a1,80202b70 <walkaddr+0xc>
    80202b6c:	4501                	li	a0,0
}
    80202b6e:	8082                	ret
{
    80202b70:	1141                	addi	sp,sp,-16
    80202b72:	e406                	sd	ra,8(sp)
    80202b74:	e022                	sd	s0,0(sp)
    80202b76:	0800                	addi	s0,sp,16
    pte_t *pte = walk(pt, va, 0);
    80202b78:	4601                	li	a2,0
    80202b7a:	00000097          	auipc	ra,0x0
    80202b7e:	f44080e7          	jalr	-188(ra) # 80202abe <walk>
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202b82:	cd19                	beqz	a0,80202ba0 <walkaddr+0x3c>
    80202b84:	611c                	ld	a5,0(a0)
    80202b86:	0117f693          	andi	a3,a5,17
    80202b8a:	4745                	li	a4,17
    80202b8c:	4501                	li	a0,0
    80202b8e:	00e69563          	bne	a3,a4,80202b98 <walkaddr+0x34>
    return PTE2PA(*pte);
    80202b92:	83a9                	srli	a5,a5,0xa
    80202b94:	00c79513          	slli	a0,a5,0xc
}
    80202b98:	60a2                	ld	ra,8(sp)
    80202b9a:	6402                	ld	s0,0(sp)
    80202b9c:	0141                	addi	sp,sp,16
    80202b9e:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202ba0:	4501                	li	a0,0
    80202ba2:	bfdd                	j	80202b98 <walkaddr+0x34>

0000000080202ba4 <mappages>:
{
    80202ba4:	715d                	addi	sp,sp,-80
    80202ba6:	e486                	sd	ra,72(sp)
    80202ba8:	e0a2                	sd	s0,64(sp)
    80202baa:	fc26                	sd	s1,56(sp)
    80202bac:	f84a                	sd	s2,48(sp)
    80202bae:	f44e                	sd	s3,40(sp)
    80202bb0:	f052                	sd	s4,32(sp)
    80202bb2:	ec56                	sd	s5,24(sp)
    80202bb4:	e85a                	sd	s6,16(sp)
    80202bb6:	e45e                	sd	s7,8(sp)
    80202bb8:	0880                	addi	s0,sp,80
    if (size == 0) panic("mappages: zero size");
    80202bba:	c639                	beqz	a2,80202c08 <mappages+0x64>
    80202bbc:	8aaa                	mv	s5,a0
    80202bbe:	8b3a                	mv	s6,a4
    uint64 a    = PGROUNDDOWN(va);
    80202bc0:	777d                	lui	a4,0xfffff
    80202bc2:	00e5f7b3          	and	a5,a1,a4
    uint64 last = PGROUNDDOWN(va + size - 1);
    80202bc6:	fff58993          	addi	s3,a1,-1
    80202bca:	99b2                	add	s3,s3,a2
    80202bcc:	00e9f9b3          	and	s3,s3,a4
    uint64 a    = PGROUNDDOWN(va);
    80202bd0:	893e                	mv	s2,a5
    80202bd2:	40f68a33          	sub	s4,a3,a5
        a  += PGSIZE;
    80202bd6:	6b85                	lui	s7,0x1
    80202bd8:	014904b3          	add	s1,s2,s4
        pte_t *pte = walk(pt, a, 1);
    80202bdc:	4605                	li	a2,1
    80202bde:	85ca                	mv	a1,s2
    80202be0:	8556                	mv	a0,s5
    80202be2:	00000097          	auipc	ra,0x0
    80202be6:	edc080e7          	jalr	-292(ra) # 80202abe <walk>
        if (!pte) return -1;
    80202bea:	cd1d                	beqz	a0,80202c28 <mappages+0x84>
        if (*pte & PTE_V) panic("mappages: remap");
    80202bec:	611c                	ld	a5,0(a0)
    80202bee:	8b85                	andi	a5,a5,1
    80202bf0:	e785                	bnez	a5,80202c18 <mappages+0x74>
        *pte = PA2PTE(pa) | perm | PTE_V;
    80202bf2:	80b1                	srli	s1,s1,0xc
    80202bf4:	04aa                	slli	s1,s1,0xa
    80202bf6:	0164e4b3          	or	s1,s1,s6
    80202bfa:	0014e493          	ori	s1,s1,1
    80202bfe:	e104                	sd	s1,0(a0)
        if (a == last) break;
    80202c00:	05390063          	beq	s2,s3,80202c40 <mappages+0x9c>
        a  += PGSIZE;
    80202c04:	995e                	add	s2,s2,s7
    for (;;) {
    80202c06:	bfc9                	j	80202bd8 <mappages+0x34>
    if (size == 0) panic("mappages: zero size");
    80202c08:	00005517          	auipc	a0,0x5
    80202c0c:	c7850513          	addi	a0,a0,-904 # 80207880 <etext+0x880>
    80202c10:	ffffe097          	auipc	ra,0xffffe
    80202c14:	9e2080e7          	jalr	-1566(ra) # 802005f2 <panic>
        if (*pte & PTE_V) panic("mappages: remap");
    80202c18:	00005517          	auipc	a0,0x5
    80202c1c:	c8050513          	addi	a0,a0,-896 # 80207898 <etext+0x898>
    80202c20:	ffffe097          	auipc	ra,0xffffe
    80202c24:	9d2080e7          	jalr	-1582(ra) # 802005f2 <panic>
        if (!pte) return -1;
    80202c28:	557d                	li	a0,-1
}
    80202c2a:	60a6                	ld	ra,72(sp)
    80202c2c:	6406                	ld	s0,64(sp)
    80202c2e:	74e2                	ld	s1,56(sp)
    80202c30:	7942                	ld	s2,48(sp)
    80202c32:	79a2                	ld	s3,40(sp)
    80202c34:	7a02                	ld	s4,32(sp)
    80202c36:	6ae2                	ld	s5,24(sp)
    80202c38:	6b42                	ld	s6,16(sp)
    80202c3a:	6ba2                	ld	s7,8(sp)
    80202c3c:	6161                	addi	sp,sp,80
    80202c3e:	8082                	ret
    return 0;
    80202c40:	4501                	li	a0,0
    80202c42:	b7e5                	j	80202c2a <mappages+0x86>

0000000080202c44 <kvmmap>:
{
    80202c44:	1141                	addi	sp,sp,-16
    80202c46:	e406                	sd	ra,8(sp)
    80202c48:	e022                	sd	s0,0(sp)
    80202c4a:	0800                	addi	s0,sp,16
    80202c4c:	8736                	mv	a4,a3
    if (mappages(kernel_pagetable, va, sz, pa, perm) != 0)
    80202c4e:	86ae                	mv	a3,a1
    80202c50:	85aa                	mv	a1,a0
    80202c52:	00147517          	auipc	a0,0x147
    80202c56:	3ce53503          	ld	a0,974(a0) # 8034a020 <kernel_pagetable>
    80202c5a:	00000097          	auipc	ra,0x0
    80202c5e:	f4a080e7          	jalr	-182(ra) # 80202ba4 <mappages>
    80202c62:	e509                	bnez	a0,80202c6c <kvmmap+0x28>
}
    80202c64:	60a2                	ld	ra,8(sp)
    80202c66:	6402                	ld	s0,0(sp)
    80202c68:	0141                	addi	sp,sp,16
    80202c6a:	8082                	ret
        panic("kvmmap");
    80202c6c:	00005517          	auipc	a0,0x5
    80202c70:	c3c50513          	addi	a0,a0,-964 # 802078a8 <etext+0x8a8>
    80202c74:	ffffe097          	auipc	ra,0xffffe
    80202c78:	97e080e7          	jalr	-1666(ra) # 802005f2 <panic>

0000000080202c7c <kvminit>:
{
    80202c7c:	7179                	addi	sp,sp,-48
    80202c7e:	f406                	sd	ra,40(sp)
    80202c80:	f022                	sd	s0,32(sp)
    80202c82:	ec26                	sd	s1,24(sp)
    80202c84:	e84a                	sd	s2,16(sp)
    80202c86:	1800                	addi	s0,sp,48
    kernel_pagetable = (pagetable_t)palloc();
    80202c88:	ffffe097          	auipc	ra,0xffffe
    80202c8c:	412080e7          	jalr	1042(ra) # 8020109a <palloc>
    80202c90:	00147717          	auipc	a4,0x147
    80202c94:	38a73823          	sd	a0,912(a4) # 8034a020 <kernel_pagetable>
    memset(kernel_pagetable, 0, PGSIZE);
    80202c98:	6605                	lui	a2,0x1
    80202c9a:	4581                	li	a1,0
    80202c9c:	ffffe097          	auipc	ra,0xffffe
    80202ca0:	9fc080e7          	jalr	-1540(ra) # 80200698 <memset>
    kvmmap(MMIO_VA(fdt.uart_base), fdt.uart_base, PGSIZE, PTE_R | PTE_W);
    80202ca4:	00026497          	auipc	s1,0x26
    80202ca8:	37448493          	addi	s1,s1,884 # 80229018 <fdt>
    80202cac:	688c                	ld	a1,16(s1)
    80202cae:	4505                	li	a0,1
    80202cb0:	1502                	slli	a0,a0,0x20
    80202cb2:	4699                	li	a3,6
    80202cb4:	6605                	lui	a2,0x1
    80202cb6:	952e                	add	a0,a0,a1
    80202cb8:	00000097          	auipc	ra,0x0
    80202cbc:	f8c080e7          	jalr	-116(ra) # 80202c44 <kvmmap>
    if (fdt.plic_base)
    80202cc0:	6c8c                	ld	a1,24(s1)
    80202cc2:	e1d5                	bnez	a1,80202d66 <kvminit+0xea>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202cc4:	00026797          	auipc	a5,0x26
    80202cc8:	3dc7a783          	lw	a5,988(a5) # 802290a0 <fdt+0x88>
    80202ccc:	02f05e63          	blez	a5,80202d08 <kvminit+0x8c>
    80202cd0:	e44e                	sd	s3,8(sp)
    80202cd2:	e052                	sd	s4,0(sp)
    80202cd4:	00026917          	auipc	s2,0x26
    80202cd8:	34490913          	addi	s2,s2,836 # 80229018 <fdt>
    80202cdc:	4481                	li	s1,0
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202cde:	4985                	li	s3,1
    80202ce0:	1982                	slli	s3,s3,0x20
    for (int i = 0; i < fdt.nvirtio; i++)
    80202ce2:	8a4a                	mv	s4,s2
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202ce4:	02893583          	ld	a1,40(s2)
    80202ce8:	4699                	li	a3,6
    80202cea:	6605                	lui	a2,0x1
    80202cec:	01358533          	add	a0,a1,s3
    80202cf0:	00000097          	auipc	ra,0x0
    80202cf4:	f54080e7          	jalr	-172(ra) # 80202c44 <kvmmap>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202cf8:	2485                	addiw	s1,s1,1
    80202cfa:	0921                	addi	s2,s2,8
    80202cfc:	088a2783          	lw	a5,136(s4)
    80202d00:	fef4c2e3          	blt	s1,a5,80202ce4 <kvminit+0x68>
    80202d04:	69a2                	ld	s3,8(sp)
    80202d06:	6a02                	ld	s4,0(sp)
    kvmmap(ktext, ktext, (uint64)etext - ktext, PTE_R | PTE_X);
    80202d08:	00004497          	auipc	s1,0x4
    80202d0c:	2f848493          	addi	s1,s1,760 # 80207000 <etext>
    80202d10:	bff00613          	li	a2,-1025
    80202d14:	0656                	slli	a2,a2,0x15
    80202d16:	46a9                	li	a3,10
    80202d18:	9626                	add	a2,a2,s1
    80202d1a:	40100593          	li	a1,1025
    80202d1e:	05d6                	slli	a1,a1,0x15
    80202d20:	852e                	mv	a0,a1
    80202d22:	00000097          	auipc	ra,0x0
    80202d26:	f22080e7          	jalr	-222(ra) # 80202c44 <kvmmap>
    uint64 mem_end = fdt.mem_base + fdt.mem_size;
    80202d2a:	00026917          	auipc	s2,0x26
    80202d2e:	2ee90913          	addi	s2,s2,750 # 80229018 <fdt>
    80202d32:	09093603          	ld	a2,144(s2)
    80202d36:	09893783          	ld	a5,152(s2)
    80202d3a:	963e                	add	a2,a2,a5
    kvmmap((uint64)etext, (uint64)etext, mem_end - (uint64)etext, PTE_R | PTE_W);
    80202d3c:	4699                	li	a3,6
    80202d3e:	8e05                	sub	a2,a2,s1
    80202d40:	85a6                	mv	a1,s1
    80202d42:	8526                	mv	a0,s1
    80202d44:	00000097          	auipc	ra,0x0
    80202d48:	f00080e7          	jalr	-256(ra) # 80202c44 <kvmmap>
    if (fdt.mem_base < ktext)
    80202d4c:	09093503          	ld	a0,144(s2)
    80202d50:	40100793          	li	a5,1025
    80202d54:	07d6                	slli	a5,a5,0x15
    80202d56:	02f56363          	bltu	a0,a5,80202d7c <kvminit+0x100>
}
    80202d5a:	70a2                	ld	ra,40(sp)
    80202d5c:	7402                	ld	s0,32(sp)
    80202d5e:	64e2                	ld	s1,24(sp)
    80202d60:	6942                	ld	s2,16(sp)
    80202d62:	6145                	addi	sp,sp,48
    80202d64:	8082                	ret
        kvmmap(MMIO_VA(fdt.plic_base), fdt.plic_base, 0x400000, PTE_R | PTE_W);
    80202d66:	4505                	li	a0,1
    80202d68:	1502                	slli	a0,a0,0x20
    80202d6a:	4699                	li	a3,6
    80202d6c:	00400637          	lui	a2,0x400
    80202d70:	952e                	add	a0,a0,a1
    80202d72:	00000097          	auipc	ra,0x0
    80202d76:	ed2080e7          	jalr	-302(ra) # 80202c44 <kvmmap>
    80202d7a:	b7a9                	j	80202cc4 <kvminit+0x48>
        kvmmap(fdt.mem_base, fdt.mem_base, ktext - fdt.mem_base, PTE_R | PTE_W);
    80202d7c:	4699                	li	a3,6
    80202d7e:	40a78633          	sub	a2,a5,a0
    80202d82:	85aa                	mv	a1,a0
    80202d84:	00000097          	auipc	ra,0x0
    80202d88:	ec0080e7          	jalr	-320(ra) # 80202c44 <kvmmap>
}
    80202d8c:	b7f9                	j	80202d5a <kvminit+0xde>

0000000080202d8e <kvminithart>:
{
    80202d8e:	1141                	addi	sp,sp,-16
    80202d90:	e422                	sd	s0,8(sp)
    80202d92:	0800                	addi	s0,sp,16
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202d94:	12000073          	sfence.vma
    w_satp(MAKE_SATP(kernel_pagetable));
    80202d98:	00147797          	auipc	a5,0x147
    80202d9c:	2887b783          	ld	a5,648(a5) # 8034a020 <kernel_pagetable>
    80202da0:	83b1                	srli	a5,a5,0xc
    80202da2:	577d                	li	a4,-1
    80202da4:	177e                	slli	a4,a4,0x3f
    80202da6:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80202da8:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202dac:	12000073          	sfence.vma
}
    80202db0:	6422                	ld	s0,8(sp)
    80202db2:	0141                	addi	sp,sp,16
    80202db4:	8082                	ret

0000000080202db6 <uvmcreate>:
{
    80202db6:	1101                	addi	sp,sp,-32
    80202db8:	ec06                	sd	ra,24(sp)
    80202dba:	e822                	sd	s0,16(sp)
    80202dbc:	e426                	sd	s1,8(sp)
    80202dbe:	1000                	addi	s0,sp,32
    pagetable_t pt = (pagetable_t)palloc();
    80202dc0:	ffffe097          	auipc	ra,0xffffe
    80202dc4:	2da080e7          	jalr	730(ra) # 8020109a <palloc>
    80202dc8:	84aa                	mv	s1,a0
    if (!pt) return 0;
    80202dca:	c515                	beqz	a0,80202df6 <uvmcreate+0x40>
    memset(pt, 0, PGSIZE);
    80202dcc:	6605                	lui	a2,0x1
    80202dce:	4581                	li	a1,0
    80202dd0:	ffffe097          	auipc	ra,0xffffe
    80202dd4:	8c8080e7          	jalr	-1848(ra) # 80200698 <memset>
    80202dd8:	47c1                	li	a5,16
        pt[i] = kernel_pagetable[i];
    80202dda:	00147597          	auipc	a1,0x147
    80202dde:	24658593          	addi	a1,a1,582 # 8034a020 <kernel_pagetable>
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202de2:	6605                	lui	a2,0x1
        pt[i] = kernel_pagetable[i];
    80202de4:	6198                	ld	a4,0(a1)
    80202de6:	973e                	add	a4,a4,a5
    80202de8:	6314                	ld	a3,0(a4)
    80202dea:	00f48733          	add	a4,s1,a5
    80202dee:	e314                	sd	a3,0(a4)
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202df0:	07a1                	addi	a5,a5,8
    80202df2:	fec799e3          	bne	a5,a2,80202de4 <uvmcreate+0x2e>
}
    80202df6:	8526                	mv	a0,s1
    80202df8:	60e2                	ld	ra,24(sp)
    80202dfa:	6442                	ld	s0,16(sp)
    80202dfc:	64a2                	ld	s1,8(sp)
    80202dfe:	6105                	addi	sp,sp,32
    80202e00:	8082                	ret

0000000080202e02 <uvmunmap>:
{
    80202e02:	7139                	addi	sp,sp,-64
    80202e04:	fc06                	sd	ra,56(sp)
    80202e06:	f822                	sd	s0,48(sp)
    80202e08:	ec4e                	sd	s3,24(sp)
    80202e0a:	0080                	addi	s0,sp,64
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202e0c:	0632                	slli	a2,a2,0xc
    80202e0e:	00b609b3          	add	s3,a2,a1
    80202e12:	0535fd63          	bgeu	a1,s3,80202e6c <uvmunmap+0x6a>
    80202e16:	f426                	sd	s1,40(sp)
    80202e18:	f04a                	sd	s2,32(sp)
    80202e1a:	e852                	sd	s4,16(sp)
    80202e1c:	e456                	sd	s5,8(sp)
    80202e1e:	e05a                	sd	s6,0(sp)
    80202e20:	8a2a                	mv	s4,a0
    80202e22:	892e                	mv	s2,a1
    80202e24:	8ab6                	mv	s5,a3
    80202e26:	6b05                	lui	s6,0x1
    80202e28:	a031                	j	80202e34 <uvmunmap+0x32>
        *pte = 0;
    80202e2a:	0004b023          	sd	zero,0(s1)
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202e2e:	995a                	add	s2,s2,s6
    80202e30:	03397963          	bgeu	s2,s3,80202e62 <uvmunmap+0x60>
        pte_t *pte = walk(pt, a, 0);
    80202e34:	4601                	li	a2,0
    80202e36:	85ca                	mv	a1,s2
    80202e38:	8552                	mv	a0,s4
    80202e3a:	00000097          	auipc	ra,0x0
    80202e3e:	c84080e7          	jalr	-892(ra) # 80202abe <walk>
    80202e42:	84aa                	mv	s1,a0
        if (!pte || !(*pte & PTE_V)) continue;     /* lazily-allocated: fine */
    80202e44:	d56d                	beqz	a0,80202e2e <uvmunmap+0x2c>
    80202e46:	611c                	ld	a5,0(a0)
    80202e48:	0017f713          	andi	a4,a5,1
    80202e4c:	d36d                	beqz	a4,80202e2e <uvmunmap+0x2c>
        if (do_free) pfree((void *)PTE2PA(*pte));
    80202e4e:	fc0a8ee3          	beqz	s5,80202e2a <uvmunmap+0x28>
    80202e52:	83a9                	srli	a5,a5,0xa
    80202e54:	00c79513          	slli	a0,a5,0xc
    80202e58:	ffffe097          	auipc	ra,0xffffe
    80202e5c:	352080e7          	jalr	850(ra) # 802011aa <pfree>
    80202e60:	b7e9                	j	80202e2a <uvmunmap+0x28>
    80202e62:	74a2                	ld	s1,40(sp)
    80202e64:	7902                	ld	s2,32(sp)
    80202e66:	6a42                	ld	s4,16(sp)
    80202e68:	6aa2                	ld	s5,8(sp)
    80202e6a:	6b02                	ld	s6,0(sp)
}
    80202e6c:	70e2                	ld	ra,56(sp)
    80202e6e:	7442                	ld	s0,48(sp)
    80202e70:	69e2                	ld	s3,24(sp)
    80202e72:	6121                	addi	sp,sp,64
    80202e74:	8082                	ret

0000000080202e76 <uvmfree>:
{
    80202e76:	1101                	addi	sp,sp,-32
    80202e78:	ec06                	sd	ra,24(sp)
    80202e7a:	e822                	sd	s0,16(sp)
    80202e7c:	e426                	sd	s1,8(sp)
    80202e7e:	1000                	addi	s0,sp,32
    80202e80:	84aa                	mv	s1,a0
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202e82:	ed81                	bnez	a1,80202e9a <uvmfree+0x24>
    freewalk_user(pt, 2);
    80202e84:	4589                	li	a1,2
    80202e86:	8526                	mv	a0,s1
    80202e88:	00000097          	auipc	ra,0x0
    80202e8c:	ad8080e7          	jalr	-1320(ra) # 80202960 <freewalk_user>
}
    80202e90:	60e2                	ld	ra,24(sp)
    80202e92:	6442                	ld	s0,16(sp)
    80202e94:	64a2                	ld	s1,8(sp)
    80202e96:	6105                	addi	sp,sp,32
    80202e98:	8082                	ret
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202e9a:	6785                	lui	a5,0x1
    80202e9c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80202e9e:	95be                	add	a1,a1,a5
    80202ea0:	4685                	li	a3,1
    80202ea2:	00c5d613          	srli	a2,a1,0xc
    80202ea6:	4581                	li	a1,0
    80202ea8:	00000097          	auipc	ra,0x0
    80202eac:	f5a080e7          	jalr	-166(ra) # 80202e02 <uvmunmap>
    80202eb0:	bfd1                	j	80202e84 <uvmfree+0xe>

0000000080202eb2 <uvmcopy>:
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202eb2:	c661                	beqz	a2,80202f7a <uvmcopy+0xc8>
{
    80202eb4:	715d                	addi	sp,sp,-80
    80202eb6:	e486                	sd	ra,72(sp)
    80202eb8:	e0a2                	sd	s0,64(sp)
    80202eba:	fc26                	sd	s1,56(sp)
    80202ebc:	f84a                	sd	s2,48(sp)
    80202ebe:	f44e                	sd	s3,40(sp)
    80202ec0:	f052                	sd	s4,32(sp)
    80202ec2:	ec56                	sd	s5,24(sp)
    80202ec4:	e85a                	sd	s6,16(sp)
    80202ec6:	e45e                	sd	s7,8(sp)
    80202ec8:	0880                	addi	s0,sp,80
    80202eca:	8aaa                	mv	s5,a0
    80202ecc:	8b2e                	mv	s6,a1
    80202ece:	8a32                	mv	s4,a2
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202ed0:	4481                	li	s1,0
    80202ed2:	a005                	j	80202ef2 <uvmcopy+0x40>
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202ed4:	4685                	li	a3,1
    80202ed6:	00c4d613          	srli	a2,s1,0xc
    80202eda:	4581                	li	a1,0
    80202edc:	855a                	mv	a0,s6
    80202ede:	00000097          	auipc	ra,0x0
    80202ee2:	f24080e7          	jalr	-220(ra) # 80202e02 <uvmunmap>
    80202ee6:	557d                	li	a0,-1
    80202ee8:	a8b5                	j	80202f64 <uvmcopy+0xb2>
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202eea:	6785                	lui	a5,0x1
    80202eec:	94be                	add	s1,s1,a5
    80202eee:	0744fa63          	bgeu	s1,s4,80202f62 <uvmcopy+0xb0>
        pte_t *pte = walk(old, i, 0);
    80202ef2:	4601                	li	a2,0
    80202ef4:	85a6                	mv	a1,s1
    80202ef6:	8556                	mv	a0,s5
    80202ef8:	00000097          	auipc	ra,0x0
    80202efc:	bc6080e7          	jalr	-1082(ra) # 80202abe <walk>
        if (!pte || !(*pte & PTE_V)) continue;
    80202f00:	d56d                	beqz	a0,80202eea <uvmcopy+0x38>
    80202f02:	6118                	ld	a4,0(a0)
    80202f04:	00177793          	andi	a5,a4,1
    80202f08:	d3ed                	beqz	a5,80202eea <uvmcopy+0x38>
        uint64 pa    = PTE2PA(*pte);
    80202f0a:	00a75593          	srli	a1,a4,0xa
    80202f0e:	00c59b93          	slli	s7,a1,0xc
        uint64 flags = PTE_FLAGS(*pte);
    80202f12:	3ff77913          	andi	s2,a4,1023
        char *mem = palloc();
    80202f16:	ffffe097          	auipc	ra,0xffffe
    80202f1a:	184080e7          	jalr	388(ra) # 8020109a <palloc>
    80202f1e:	89aa                	mv	s3,a0
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202f20:	d955                	beqz	a0,80202ed4 <uvmcopy+0x22>
        memmove(mem, (void *)pa, PGSIZE);
    80202f22:	6605                	lui	a2,0x1
    80202f24:	85de                	mv	a1,s7
    80202f26:	ffffd097          	auipc	ra,0xffffd
    80202f2a:	78e080e7          	jalr	1934(ra) # 802006b4 <memmove>
        if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    80202f2e:	874a                	mv	a4,s2
    80202f30:	86ce                	mv	a3,s3
    80202f32:	6605                	lui	a2,0x1
    80202f34:	85a6                	mv	a1,s1
    80202f36:	855a                	mv	a0,s6
    80202f38:	00000097          	auipc	ra,0x0
    80202f3c:	c6c080e7          	jalr	-916(ra) # 80202ba4 <mappages>
    80202f40:	d54d                	beqz	a0,80202eea <uvmcopy+0x38>
            pfree(mem);
    80202f42:	854e                	mv	a0,s3
    80202f44:	ffffe097          	auipc	ra,0xffffe
    80202f48:	266080e7          	jalr	614(ra) # 802011aa <pfree>
            uvmunmap(new, 0, i / PGSIZE, 1);
    80202f4c:	4685                	li	a3,1
    80202f4e:	00c4d613          	srli	a2,s1,0xc
    80202f52:	4581                	li	a1,0
    80202f54:	855a                	mv	a0,s6
    80202f56:	00000097          	auipc	ra,0x0
    80202f5a:	eac080e7          	jalr	-340(ra) # 80202e02 <uvmunmap>
            return -1;
    80202f5e:	557d                	li	a0,-1
    80202f60:	a011                	j	80202f64 <uvmcopy+0xb2>
    return 0;
    80202f62:	4501                	li	a0,0
}
    80202f64:	60a6                	ld	ra,72(sp)
    80202f66:	6406                	ld	s0,64(sp)
    80202f68:	74e2                	ld	s1,56(sp)
    80202f6a:	7942                	ld	s2,48(sp)
    80202f6c:	79a2                	ld	s3,40(sp)
    80202f6e:	7a02                	ld	s4,32(sp)
    80202f70:	6ae2                	ld	s5,24(sp)
    80202f72:	6b42                	ld	s6,16(sp)
    80202f74:	6ba2                	ld	s7,8(sp)
    80202f76:	6161                	addi	sp,sp,80
    80202f78:	8082                	ret
    return 0;
    80202f7a:	4501                	li	a0,0
}
    80202f7c:	8082                	ret

0000000080202f7e <copyout>:
    while (len > 0) {
    80202f7e:	c2d5                	beqz	a3,80203022 <copyout+0xa4>
{
    80202f80:	711d                	addi	sp,sp,-96
    80202f82:	ec86                	sd	ra,88(sp)
    80202f84:	e8a2                	sd	s0,80(sp)
    80202f86:	e4a6                	sd	s1,72(sp)
    80202f88:	fc4e                	sd	s3,56(sp)
    80202f8a:	f456                	sd	s5,40(sp)
    80202f8c:	f05a                	sd	s6,32(sp)
    80202f8e:	ec5e                	sd	s7,24(sp)
    80202f90:	1080                	addi	s0,sp,96
    80202f92:	8baa                	mv	s7,a0
    80202f94:	8aae                	mv	s5,a1
    80202f96:	8b32                	mv	s6,a2
    80202f98:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(dstva);
    80202f9a:	74fd                	lui	s1,0xfffff
    80202f9c:	8ced                	and	s1,s1,a1
        if (va0 >= USER_TOP) return -1;
    80202f9e:	800007b7          	lui	a5,0x80000
    80202fa2:	fff7c793          	not	a5,a5
    80202fa6:	0897e063          	bltu	a5,s1,80203026 <copyout+0xa8>
    80202faa:	e0ca                	sd	s2,64(sp)
    80202fac:	f852                	sd	s4,48(sp)
    80202fae:	e862                	sd	s8,16(sp)
    80202fb0:	e466                	sd	s9,8(sp)
    80202fb2:	e06a                	sd	s10,0(sp)
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202fb4:	4cc5                	li	s9,17
    80202fb6:	6d05                	lui	s10,0x1
        if (va0 >= USER_TOP) return -1;
    80202fb8:	8c3e                	mv	s8,a5
    80202fba:	a02d                	j	80202fe4 <copyout+0x66>
        uint64 pa0 = PTE2PA(*pte);
    80202fbc:	83a9                	srli	a5,a5,0xa
    80202fbe:	07b2                	slli	a5,a5,0xc
        memmove((void *)(pa0 + (dstva - va0)), src, n);
    80202fc0:	409a8533          	sub	a0,s5,s1
    80202fc4:	864a                	mv	a2,s2
    80202fc6:	85da                	mv	a1,s6
    80202fc8:	953e                	add	a0,a0,a5
    80202fca:	ffffd097          	auipc	ra,0xffffd
    80202fce:	6ea080e7          	jalr	1770(ra) # 802006b4 <memmove>
        len -= n; src += n; dstva = va0 + PGSIZE;
    80202fd2:	412989b3          	sub	s3,s3,s2
    80202fd6:	9b4a                	add	s6,s6,s2
    while (len > 0) {
    80202fd8:	02098e63          	beqz	s3,80203014 <copyout+0x96>
        if (va0 >= USER_TOP) return -1;
    80202fdc:	054c6763          	bltu	s8,s4,8020302a <copyout+0xac>
    80202fe0:	84d2                	mv	s1,s4
    80202fe2:	8ad2                	mv	s5,s4
        pte_t *pte = walk(pt, va0, 0);
    80202fe4:	4601                	li	a2,0
    80202fe6:	85a6                	mv	a1,s1
    80202fe8:	855e                	mv	a0,s7
    80202fea:	00000097          	auipc	ra,0x0
    80202fee:	ad4080e7          	jalr	-1324(ra) # 80202abe <walk>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202ff2:	c139                	beqz	a0,80203038 <copyout+0xba>
    80202ff4:	611c                	ld	a5,0(a0)
    80202ff6:	0117f713          	andi	a4,a5,17
    80202ffa:	05971e63          	bne	a4,s9,80203056 <copyout+0xd8>
        if (!(*pte & PTE_W)) return -1;   /* read-only page: refuse.
    80202ffe:	0047f713          	andi	a4,a5,4
    80203002:	c32d                	beqz	a4,80203064 <copyout+0xe6>
        uint64 n = PGSIZE - (dstva - va0);
    80203004:	01a48a33          	add	s4,s1,s10
    80203008:	415a0933          	sub	s2,s4,s5
        if (n > len) n = len;
    8020300c:	fb29f8e3          	bgeu	s3,s2,80202fbc <copyout+0x3e>
    80203010:	894e                	mv	s2,s3
    80203012:	b76d                	j	80202fbc <copyout+0x3e>
    return 0;
    80203014:	4501                	li	a0,0
    80203016:	6906                	ld	s2,64(sp)
    80203018:	7a42                	ld	s4,48(sp)
    8020301a:	6c42                	ld	s8,16(sp)
    8020301c:	6ca2                	ld	s9,8(sp)
    8020301e:	6d02                	ld	s10,0(sp)
    80203020:	a015                	j	80203044 <copyout+0xc6>
    80203022:	4501                	li	a0,0
}
    80203024:	8082                	ret
        if (va0 >= USER_TOP) return -1;
    80203026:	557d                	li	a0,-1
    80203028:	a831                	j	80203044 <copyout+0xc6>
    8020302a:	557d                	li	a0,-1
    8020302c:	6906                	ld	s2,64(sp)
    8020302e:	7a42                	ld	s4,48(sp)
    80203030:	6c42                	ld	s8,16(sp)
    80203032:	6ca2                	ld	s9,8(sp)
    80203034:	6d02                	ld	s10,0(sp)
    80203036:	a039                	j	80203044 <copyout+0xc6>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203038:	557d                	li	a0,-1
    8020303a:	6906                	ld	s2,64(sp)
    8020303c:	7a42                	ld	s4,48(sp)
    8020303e:	6c42                	ld	s8,16(sp)
    80203040:	6ca2                	ld	s9,8(sp)
    80203042:	6d02                	ld	s10,0(sp)
}
    80203044:	60e6                	ld	ra,88(sp)
    80203046:	6446                	ld	s0,80(sp)
    80203048:	64a6                	ld	s1,72(sp)
    8020304a:	79e2                	ld	s3,56(sp)
    8020304c:	7aa2                	ld	s5,40(sp)
    8020304e:	7b02                	ld	s6,32(sp)
    80203050:	6be2                	ld	s7,24(sp)
    80203052:	6125                	addi	sp,sp,96
    80203054:	8082                	ret
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203056:	557d                	li	a0,-1
    80203058:	6906                	ld	s2,64(sp)
    8020305a:	7a42                	ld	s4,48(sp)
    8020305c:	6c42                	ld	s8,16(sp)
    8020305e:	6ca2                	ld	s9,8(sp)
    80203060:	6d02                	ld	s10,0(sp)
    80203062:	b7cd                	j	80203044 <copyout+0xc6>
        if (!(*pte & PTE_W)) return -1;   /* read-only page: refuse.
    80203064:	557d                	li	a0,-1
    80203066:	6906                	ld	s2,64(sp)
    80203068:	7a42                	ld	s4,48(sp)
    8020306a:	6c42                	ld	s8,16(sp)
    8020306c:	6ca2                	ld	s9,8(sp)
    8020306e:	6d02                	ld	s10,0(sp)
    80203070:	bfd1                	j	80203044 <copyout+0xc6>

0000000080203072 <copyin>:
    while (len > 0) {
    80203072:	c6bd                	beqz	a3,802030e0 <copyin+0x6e>
{
    80203074:	715d                	addi	sp,sp,-80
    80203076:	e486                	sd	ra,72(sp)
    80203078:	e0a2                	sd	s0,64(sp)
    8020307a:	fc26                	sd	s1,56(sp)
    8020307c:	f84a                	sd	s2,48(sp)
    8020307e:	f44e                	sd	s3,40(sp)
    80203080:	f052                	sd	s4,32(sp)
    80203082:	ec56                	sd	s5,24(sp)
    80203084:	e85a                	sd	s6,16(sp)
    80203086:	e45e                	sd	s7,8(sp)
    80203088:	e062                	sd	s8,0(sp)
    8020308a:	0880                	addi	s0,sp,80
    8020308c:	8b2a                	mv	s6,a0
    8020308e:	8a2e                	mv	s4,a1
    80203090:	8c32                	mv	s8,a2
    80203092:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    80203094:	7bfd                	lui	s7,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    80203096:	6a85                	lui	s5,0x1
    80203098:	a015                	j	802030bc <copyin+0x4a>
        memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8020309a:	018505b3          	add	a1,a0,s8
    8020309e:	8626                	mv	a2,s1
    802030a0:	412585b3          	sub	a1,a1,s2
    802030a4:	8552                	mv	a0,s4
    802030a6:	ffffd097          	auipc	ra,0xffffd
    802030aa:	60e080e7          	jalr	1550(ra) # 802006b4 <memmove>
        len -= n; dst += n; srcva = va0 + PGSIZE;
    802030ae:	409989b3          	sub	s3,s3,s1
    802030b2:	9a26                	add	s4,s4,s1
    802030b4:	01590c33          	add	s8,s2,s5
    while (len > 0) {
    802030b8:	02098263          	beqz	s3,802030dc <copyin+0x6a>
        uint64 va0 = PGROUNDDOWN(srcva);
    802030bc:	017c7933          	and	s2,s8,s7
        uint64 pa0 = walkaddr(pt, va0);
    802030c0:	85ca                	mv	a1,s2
    802030c2:	855a                	mv	a0,s6
    802030c4:	00000097          	auipc	ra,0x0
    802030c8:	aa0080e7          	jalr	-1376(ra) # 80202b64 <walkaddr>
        if (pa0 == 0) return -1;
    802030cc:	cd01                	beqz	a0,802030e4 <copyin+0x72>
        uint64 n = PGSIZE - (srcva - va0);
    802030ce:	418904b3          	sub	s1,s2,s8
    802030d2:	94d6                	add	s1,s1,s5
        if (n > len) n = len;
    802030d4:	fc99f3e3          	bgeu	s3,s1,8020309a <copyin+0x28>
    802030d8:	84ce                	mv	s1,s3
    802030da:	b7c1                	j	8020309a <copyin+0x28>
    return 0;
    802030dc:	4501                	li	a0,0
    802030de:	a021                	j	802030e6 <copyin+0x74>
    802030e0:	4501                	li	a0,0
}
    802030e2:	8082                	ret
        if (pa0 == 0) return -1;
    802030e4:	557d                	li	a0,-1
}
    802030e6:	60a6                	ld	ra,72(sp)
    802030e8:	6406                	ld	s0,64(sp)
    802030ea:	74e2                	ld	s1,56(sp)
    802030ec:	7942                	ld	s2,48(sp)
    802030ee:	79a2                	ld	s3,40(sp)
    802030f0:	7a02                	ld	s4,32(sp)
    802030f2:	6ae2                	ld	s5,24(sp)
    802030f4:	6b42                	ld	s6,16(sp)
    802030f6:	6ba2                	ld	s7,8(sp)
    802030f8:	6c02                	ld	s8,0(sp)
    802030fa:	6161                	addi	sp,sp,80
    802030fc:	8082                	ret

00000000802030fe <copyinstr>:
    while (got_null == 0 && max > 0) {
    802030fe:	c6cd                	beqz	a3,802031a8 <copyinstr+0xaa>
{
    80203100:	715d                	addi	sp,sp,-80
    80203102:	e486                	sd	ra,72(sp)
    80203104:	e0a2                	sd	s0,64(sp)
    80203106:	fc26                	sd	s1,56(sp)
    80203108:	f84a                	sd	s2,48(sp)
    8020310a:	f44e                	sd	s3,40(sp)
    8020310c:	f052                	sd	s4,32(sp)
    8020310e:	ec56                	sd	s5,24(sp)
    80203110:	e85a                	sd	s6,16(sp)
    80203112:	e45e                	sd	s7,8(sp)
    80203114:	0880                	addi	s0,sp,80
    80203116:	8a2a                	mv	s4,a0
    80203118:	8b2e                	mv	s6,a1
    8020311a:	8bb2                	mv	s7,a2
    8020311c:	8936                	mv	s2,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    8020311e:	7afd                	lui	s5,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    80203120:	6985                	lui	s3,0x1
    80203122:	a811                	j	80203136 <copyinstr+0x38>
    80203124:	01258733          	add	a4,a1,s2
            dst++; p++; n--; max--;
    80203128:	40f70933          	sub	s2,a4,a5
        srcva = va0 + PGSIZE;
    8020312c:	01348bb3          	add	s7,s1,s3
    while (got_null == 0 && max > 0) {
    80203130:	06e78463          	beq	a5,a4,80203198 <copyinstr+0x9a>
{
    80203134:	8b3e                	mv	s6,a5
        uint64 va0 = PGROUNDDOWN(srcva);
    80203136:	015bf4b3          	and	s1,s7,s5
        uint64 pa0 = walkaddr(pt, va0);
    8020313a:	85a6                	mv	a1,s1
    8020313c:	8552                	mv	a0,s4
    8020313e:	00000097          	auipc	ra,0x0
    80203142:	a26080e7          	jalr	-1498(ra) # 80202b64 <walkaddr>
        if (pa0 == 0) return -1;
    80203146:	c939                	beqz	a0,8020319c <copyinstr+0x9e>
        uint64 n = PGSIZE - (srcva - va0);
    80203148:	417486b3          	sub	a3,s1,s7
    8020314c:	96ce                	add	a3,a3,s3
        if (n > max) n = max;
    8020314e:	00d97363          	bgeu	s2,a3,80203154 <copyinstr+0x56>
    80203152:	86ca                	mv	a3,s2
        char *p = (char *)(pa0 + (srcva - va0));
    80203154:	955e                	add	a0,a0,s7
    80203156:	8d05                	sub	a0,a0,s1
        while (n > 0) {
    80203158:	c6a1                	beqz	a3,802031a0 <copyinstr+0xa2>
    8020315a:	87da                	mv	a5,s6
    8020315c:	85da                	mv	a1,s6
            *dst = *p;
    8020315e:	41650633          	sub	a2,a0,s6
        while (n > 0) {
    80203162:	96da                	add	a3,a3,s6
            *dst = *p;
    80203164:	00c78733          	add	a4,a5,a2
    80203168:	00074703          	lbu	a4,0(a4)
    8020316c:	00e78023          	sb	a4,0(a5) # ffffffff80000000 <uart+0xfffffffeffcb5fd0>
            if (*p == '\0') { got_null = 1; break; }
    80203170:	c709                	beqz	a4,8020317a <copyinstr+0x7c>
            dst++; p++; n--; max--;
    80203172:	0785                	addi	a5,a5,1
        while (n > 0) {
    80203174:	fef698e3          	bne	a3,a5,80203164 <copyinstr+0x66>
    80203178:	b775                	j	80203124 <copyinstr+0x26>
    8020317a:	4785                	li	a5,1
    return got_null ? 0 : -1;
    8020317c:	37fd                	addiw	a5,a5,-1
    8020317e:	0007851b          	sext.w	a0,a5
}
    80203182:	60a6                	ld	ra,72(sp)
    80203184:	6406                	ld	s0,64(sp)
    80203186:	74e2                	ld	s1,56(sp)
    80203188:	7942                	ld	s2,48(sp)
    8020318a:	79a2                	ld	s3,40(sp)
    8020318c:	7a02                	ld	s4,32(sp)
    8020318e:	6ae2                	ld	s5,24(sp)
    80203190:	6b42                	ld	s6,16(sp)
    80203192:	6ba2                	ld	s7,8(sp)
    80203194:	6161                	addi	sp,sp,80
    80203196:	8082                	ret
    80203198:	4781                	li	a5,0
    8020319a:	b7cd                	j	8020317c <copyinstr+0x7e>
        if (pa0 == 0) return -1;
    8020319c:	557d                	li	a0,-1
    8020319e:	b7d5                	j	80203182 <copyinstr+0x84>
        srcva = va0 + PGSIZE;
    802031a0:	6b85                	lui	s7,0x1
    802031a2:	9ba6                	add	s7,s7,s1
    802031a4:	87da                	mv	a5,s6
    802031a6:	b779                	j	80203134 <copyinstr+0x36>
    int got_null = 0;
    802031a8:	4781                	li	a5,0
    return got_null ? 0 : -1;
    802031aa:	37fd                	addiw	a5,a5,-1
    802031ac:	0007851b          	sext.w	a0,a5
}
    802031b0:	8082                	ret

00000000802031b2 <vmprint>:
void vmprint(pagetable_t pt)
{
    802031b2:	1101                	addi	sp,sp,-32
    802031b4:	ec06                	sd	ra,24(sp)
    802031b6:	e822                	sd	s0,16(sp)
    802031b8:	e426                	sd	s1,8(sp)
    802031ba:	1000                	addi	s0,sp,32
    802031bc:	84aa                	mv	s1,a0
    printf("page table %p (user half)\n", pt);
    802031be:	85aa                	mv	a1,a0
    802031c0:	00004517          	auipc	a0,0x4
    802031c4:	6f050513          	addi	a0,a0,1776 # 802078b0 <etext+0x8b0>
    802031c8:	ffffd097          	auipc	ra,0xffffd
    802031cc:	1b8080e7          	jalr	440(ra) # 80200380 <printf>
    vmprint_lvl(pt, 2);
    802031d0:	4589                	li	a1,2
    802031d2:	8526                	mv	a0,s1
    802031d4:	fffff097          	auipc	ra,0xfffff
    802031d8:	7fc080e7          	jalr	2044(ra) # 802029d0 <vmprint_lvl>
}
    802031dc:	60e2                	ld	ra,24(sp)
    802031de:	6442                	ld	s0,16(sp)
    802031e0:	64a2                	ld	s1,8(sp)
    802031e2:	6105                	addi	sp,sp,32
    802031e4:	8082                	ret

00000000802031e6 <sys_getpid>:
    int n; argint(0, &n);
    exit(n);
    return 0;
}

uint64 sys_getpid(void) { return myproc()->pid; }
    802031e6:	1141                	addi	sp,sp,-16
    802031e8:	e406                	sd	ra,8(sp)
    802031ea:	e022                	sd	s0,0(sp)
    802031ec:	0800                	addi	s0,sp,16
    802031ee:	ffffe097          	auipc	ra,0xffffe
    802031f2:	578080e7          	jalr	1400(ra) # 80201766 <myproc>
    802031f6:	5908                	lw	a0,48(a0)
    802031f8:	60a2                	ld	ra,8(sp)
    802031fa:	6402                	ld	s0,0(sp)
    802031fc:	0141                	addi	sp,sp,16
    802031fe:	8082                	ret

0000000080203200 <argraw>:
{
    80203200:	1101                	addi	sp,sp,-32
    80203202:	ec06                	sd	ra,24(sp)
    80203204:	e822                	sd	s0,16(sp)
    80203206:	e426                	sd	s1,8(sp)
    80203208:	1000                	addi	s0,sp,32
    8020320a:	84aa                	mv	s1,a0
    struct trapframe *tf = myproc()->tf;
    8020320c:	ffffe097          	auipc	ra,0xffffe
    80203210:	55a080e7          	jalr	1370(ra) # 80201766 <myproc>
    80203214:	6d34                	ld	a3,88(a0)
    switch (n) {
    80203216:	4795                	li	a5,5
    80203218:	0297eb63          	bltu	a5,s1,8020324e <argraw+0x4e>
    8020321c:	048a                	slli	s1,s1,0x2
    8020321e:	00005717          	auipc	a4,0x5
    80203222:	c4270713          	addi	a4,a4,-958 # 80207e60 <st.0+0x70>
    80203226:	94ba                	add	s1,s1,a4
    80203228:	409c                	lw	a5,0(s1)
    8020322a:	97ba                	add	a5,a5,a4
    8020322c:	8782                	jr	a5
    case 0: return tf->a0;
    8020322e:	7aa8                	ld	a0,112(a3)
}
    80203230:	60e2                	ld	ra,24(sp)
    80203232:	6442                	ld	s0,16(sp)
    80203234:	64a2                	ld	s1,8(sp)
    80203236:	6105                	addi	sp,sp,32
    80203238:	8082                	ret
    case 1: return tf->a1;
    8020323a:	7ea8                	ld	a0,120(a3)
    8020323c:	bfd5                	j	80203230 <argraw+0x30>
    case 2: return tf->a2;
    8020323e:	62c8                	ld	a0,128(a3)
    80203240:	bfc5                	j	80203230 <argraw+0x30>
    case 3: return tf->a3;
    80203242:	66c8                	ld	a0,136(a3)
    80203244:	b7f5                	j	80203230 <argraw+0x30>
    case 4: return tf->a4;
    80203246:	6ac8                	ld	a0,144(a3)
    80203248:	b7e5                	j	80203230 <argraw+0x30>
    case 5: return tf->a5;
    8020324a:	6ec8                	ld	a0,152(a3)
    8020324c:	b7d5                	j	80203230 <argraw+0x30>
    panic("argraw: bad arg index");
    8020324e:	00004517          	auipc	a0,0x4
    80203252:	68250513          	addi	a0,a0,1666 # 802078d0 <etext+0x8d0>
    80203256:	ffffd097          	auipc	ra,0xffffd
    8020325a:	39c080e7          	jalr	924(ra) # 802005f2 <panic>

000000008020325e <sys_fork>:

uint64 sys_fork(void)   { return fork(); }
    8020325e:	1141                	addi	sp,sp,-16
    80203260:	e406                	sd	ra,8(sp)
    80203262:	e022                	sd	s0,0(sp)
    80203264:	0800                	addi	s0,sp,16
    80203266:	fffff097          	auipc	ra,0xfffff
    8020326a:	842080e7          	jalr	-1982(ra) # 80201aa8 <fork>
    8020326e:	60a2                	ld	ra,8(sp)
    80203270:	6402                	ld	s0,0(sp)
    80203272:	0141                	addi	sp,sp,16
    80203274:	8082                	ret

0000000080203276 <sys_uptime>:
    int pid; argint(0, &pid);
    return kill(pid);
}

uint64 sys_uptime(void)
{
    80203276:	1101                	addi	sp,sp,-32
    80203278:	ec06                	sd	ra,24(sp)
    8020327a:	e822                	sd	s0,16(sp)
    8020327c:	e426                	sd	s1,8(sp)
    8020327e:	1000                	addi	s0,sp,32
    acquire(&tickslock);
    80203280:	0012e517          	auipc	a0,0x12e
    80203284:	18050513          	addi	a0,a0,384 # 80331400 <tickslock>
    80203288:	ffffe097          	auipc	ra,0xffffe
    8020328c:	0a0080e7          	jalr	160(ra) # 80201328 <acquire>
    uint64 t = ticks;
    80203290:	00147497          	auipc	s1,0x147
    80203294:	d884b483          	ld	s1,-632(s1) # 8034a018 <ticks>
    release(&tickslock);
    80203298:	0012e517          	auipc	a0,0x12e
    8020329c:	16850513          	addi	a0,a0,360 # 80331400 <tickslock>
    802032a0:	ffffe097          	auipc	ra,0xffffe
    802032a4:	13c080e7          	jalr	316(ra) # 802013dc <release>
    return t;
}
    802032a8:	8526                	mv	a0,s1
    802032aa:	60e2                	ld	ra,24(sp)
    802032ac:	6442                	ld	s0,16(sp)
    802032ae:	64a2                	ld	s1,8(sp)
    802032b0:	6105                	addi	sp,sp,32
    802032b2:	8082                	ret

00000000802032b4 <sys_freepages>:

/* Luit extras: test hooks and observability (used by meminfo and ps). */
uint64 sys_freepages(void) { return palloc_free_count(); }
    802032b4:	1141                	addi	sp,sp,-16
    802032b6:	e406                	sd	ra,8(sp)
    802032b8:	e022                	sd	s0,0(sp)
    802032ba:	0800                	addi	s0,sp,16
    802032bc:	ffffe097          	auipc	ra,0xffffe
    802032c0:	fb6080e7          	jalr	-74(ra) # 80201272 <palloc_free_count>
    802032c4:	60a2                	ld	ra,8(sp)
    802032c6:	6402                	ld	s0,0(sp)
    802032c8:	0141                	addi	sp,sp,16
    802032ca:	8082                	ret

00000000802032cc <argint>:
int argint(int n, int *ip)     { *ip = (int)argraw(n); return 0; }
    802032cc:	1101                	addi	sp,sp,-32
    802032ce:	ec06                	sd	ra,24(sp)
    802032d0:	e822                	sd	s0,16(sp)
    802032d2:	e426                	sd	s1,8(sp)
    802032d4:	1000                	addi	s0,sp,32
    802032d6:	84ae                	mv	s1,a1
    802032d8:	00000097          	auipc	ra,0x0
    802032dc:	f28080e7          	jalr	-216(ra) # 80203200 <argraw>
    802032e0:	c088                	sw	a0,0(s1)
    802032e2:	4501                	li	a0,0
    802032e4:	60e2                	ld	ra,24(sp)
    802032e6:	6442                	ld	s0,16(sp)
    802032e8:	64a2                	ld	s1,8(sp)
    802032ea:	6105                	addi	sp,sp,32
    802032ec:	8082                	ret

00000000802032ee <sys_exit>:
{
    802032ee:	1101                	addi	sp,sp,-32
    802032f0:	ec06                	sd	ra,24(sp)
    802032f2:	e822                	sd	s0,16(sp)
    802032f4:	1000                	addi	s0,sp,32
    int n; argint(0, &n);
    802032f6:	fec40593          	addi	a1,s0,-20
    802032fa:	4501                	li	a0,0
    802032fc:	00000097          	auipc	ra,0x0
    80203300:	fd0080e7          	jalr	-48(ra) # 802032cc <argint>
    exit(n);
    80203304:	fec42503          	lw	a0,-20(s0)
    80203308:	fffff097          	auipc	ra,0xfffff
    8020330c:	d00080e7          	jalr	-768(ra) # 80202008 <exit>

0000000080203310 <sys_sbrk>:
{
    80203310:	7179                	addi	sp,sp,-48
    80203312:	f406                	sd	ra,40(sp)
    80203314:	f022                	sd	s0,32(sp)
    80203316:	ec26                	sd	s1,24(sp)
    80203318:	1800                	addi	s0,sp,48
    int n; argint(0, &n);
    8020331a:	fdc40593          	addi	a1,s0,-36
    8020331e:	4501                	li	a0,0
    80203320:	00000097          	auipc	ra,0x0
    80203324:	fac080e7          	jalr	-84(ra) # 802032cc <argint>
    uint64 addr = myproc()->sz;
    80203328:	ffffe097          	auipc	ra,0xffffe
    8020332c:	43e080e7          	jalr	1086(ra) # 80201766 <myproc>
    80203330:	6524                	ld	s1,72(a0)
    if (growproc(n) < 0) return -1;
    80203332:	fdc42503          	lw	a0,-36(s0)
    80203336:	ffffe097          	auipc	ra,0xffffe
    8020333a:	670080e7          	jalr	1648(ra) # 802019a6 <growproc>
    8020333e:	00054863          	bltz	a0,8020334e <sys_sbrk+0x3e>
}
    80203342:	8526                	mv	a0,s1
    80203344:	70a2                	ld	ra,40(sp)
    80203346:	7402                	ld	s0,32(sp)
    80203348:	64e2                	ld	s1,24(sp)
    8020334a:	6145                	addi	sp,sp,48
    8020334c:	8082                	ret
    if (growproc(n) < 0) return -1;
    8020334e:	54fd                	li	s1,-1
    80203350:	bfcd                	j	80203342 <sys_sbrk+0x32>

0000000080203352 <sys_sleep>:
{
    80203352:	7139                	addi	sp,sp,-64
    80203354:	fc06                	sd	ra,56(sp)
    80203356:	f822                	sd	s0,48(sp)
    80203358:	f04a                	sd	s2,32(sp)
    8020335a:	ec4e                	sd	s3,24(sp)
    8020335c:	0080                	addi	s0,sp,64
    int n; argint(0, &n);
    8020335e:	fcc40593          	addi	a1,s0,-52
    80203362:	4501                	li	a0,0
    80203364:	00000097          	auipc	ra,0x0
    80203368:	f68080e7          	jalr	-152(ra) # 802032cc <argint>
    acquire(&tickslock);
    8020336c:	0012e517          	auipc	a0,0x12e
    80203370:	09450513          	addi	a0,a0,148 # 80331400 <tickslock>
    80203374:	ffffe097          	auipc	ra,0xffffe
    80203378:	fb4080e7          	jalr	-76(ra) # 80201328 <acquire>
    uint64 t0 = ticks;
    8020337c:	00147997          	auipc	s3,0x147
    80203380:	c9c9b983          	ld	s3,-868(s3) # 8034a018 <ticks>
    while (ticks - t0 < (uint64)n) {
    80203384:	fcc42903          	lw	s2,-52(s0)
    80203388:	02090f63          	beqz	s2,802033c6 <sys_sleep+0x74>
    8020338c:	f426                	sd	s1,40(sp)
    8020338e:	e852                	sd	s4,16(sp)
        sleep(&ticks, &tickslock);
    80203390:	0012ea17          	auipc	s4,0x12e
    80203394:	070a0a13          	addi	s4,s4,112 # 80331400 <tickslock>
    80203398:	00147497          	auipc	s1,0x147
    8020339c:	c8048493          	addi	s1,s1,-896 # 8034a018 <ticks>
        if (myproc()->killed) { release(&tickslock); return -1; }
    802033a0:	ffffe097          	auipc	ra,0xffffe
    802033a4:	3c6080e7          	jalr	966(ra) # 80201766 <myproc>
    802033a8:	551c                	lw	a5,40(a0)
    802033aa:	ef8d                	bnez	a5,802033e4 <sys_sleep+0x92>
        sleep(&ticks, &tickslock);
    802033ac:	85d2                	mv	a1,s4
    802033ae:	8526                	mv	a0,s1
    802033b0:	fffff097          	auipc	ra,0xfffff
    802033b4:	a5c080e7          	jalr	-1444(ra) # 80201e0c <sleep>
    while (ticks - t0 < (uint64)n) {
    802033b8:	609c                	ld	a5,0(s1)
    802033ba:	413787b3          	sub	a5,a5,s3
    802033be:	ff27e1e3          	bltu	a5,s2,802033a0 <sys_sleep+0x4e>
    802033c2:	74a2                	ld	s1,40(sp)
    802033c4:	6a42                	ld	s4,16(sp)
    release(&tickslock);
    802033c6:	0012e517          	auipc	a0,0x12e
    802033ca:	03a50513          	addi	a0,a0,58 # 80331400 <tickslock>
    802033ce:	ffffe097          	auipc	ra,0xffffe
    802033d2:	00e080e7          	jalr	14(ra) # 802013dc <release>
    return 0;
    802033d6:	4501                	li	a0,0
}
    802033d8:	70e2                	ld	ra,56(sp)
    802033da:	7442                	ld	s0,48(sp)
    802033dc:	7902                	ld	s2,32(sp)
    802033de:	69e2                	ld	s3,24(sp)
    802033e0:	6121                	addi	sp,sp,64
    802033e2:	8082                	ret
        if (myproc()->killed) { release(&tickslock); return -1; }
    802033e4:	0012e517          	auipc	a0,0x12e
    802033e8:	01c50513          	addi	a0,a0,28 # 80331400 <tickslock>
    802033ec:	ffffe097          	auipc	ra,0xffffe
    802033f0:	ff0080e7          	jalr	-16(ra) # 802013dc <release>
    802033f4:	557d                	li	a0,-1
    802033f6:	74a2                	ld	s1,40(sp)
    802033f8:	6a42                	ld	s4,16(sp)
    802033fa:	bff9                	j	802033d8 <sys_sleep+0x86>

00000000802033fc <sys_kill>:
{
    802033fc:	1101                	addi	sp,sp,-32
    802033fe:	ec06                	sd	ra,24(sp)
    80203400:	e822                	sd	s0,16(sp)
    80203402:	1000                	addi	s0,sp,32
    int pid; argint(0, &pid);
    80203404:	fec40593          	addi	a1,s0,-20
    80203408:	4501                	li	a0,0
    8020340a:	00000097          	auipc	ra,0x0
    8020340e:	ec2080e7          	jalr	-318(ra) # 802032cc <argint>
    return kill(pid);
    80203412:	fec42503          	lw	a0,-20(s0)
    80203416:	fffff097          	auipc	ra,0xfffff
    8020341a:	cf0080e7          	jalr	-784(ra) # 80202106 <kill>
}
    8020341e:	60e2                	ld	ra,24(sp)
    80203420:	6442                	ld	s0,16(sp)
    80203422:	6105                	addi	sp,sp,32
    80203424:	8082                	ret

0000000080203426 <argaddr>:
int argaddr(int n, uint64 *ap) { *ap = argraw(n); return 0; }
    80203426:	1101                	addi	sp,sp,-32
    80203428:	ec06                	sd	ra,24(sp)
    8020342a:	e822                	sd	s0,16(sp)
    8020342c:	e426                	sd	s1,8(sp)
    8020342e:	1000                	addi	s0,sp,32
    80203430:	84ae                	mv	s1,a1
    80203432:	00000097          	auipc	ra,0x0
    80203436:	dce080e7          	jalr	-562(ra) # 80203200 <argraw>
    8020343a:	e088                	sd	a0,0(s1)
    8020343c:	4501                	li	a0,0
    8020343e:	60e2                	ld	ra,24(sp)
    80203440:	6442                	ld	s0,16(sp)
    80203442:	64a2                	ld	s1,8(sp)
    80203444:	6105                	addi	sp,sp,32
    80203446:	8082                	ret

0000000080203448 <sys_wait>:
{
    80203448:	1101                	addi	sp,sp,-32
    8020344a:	ec06                	sd	ra,24(sp)
    8020344c:	e822                	sd	s0,16(sp)
    8020344e:	1000                	addi	s0,sp,32
    uint64 p; argaddr(0, &p);
    80203450:	fe840593          	addi	a1,s0,-24
    80203454:	4501                	li	a0,0
    80203456:	00000097          	auipc	ra,0x0
    8020345a:	fd0080e7          	jalr	-48(ra) # 80203426 <argaddr>
    return wait(p);
    8020345e:	fe843503          	ld	a0,-24(s0)
    80203462:	fffff097          	auipc	ra,0xfffff
    80203466:	a0e080e7          	jalr	-1522(ra) # 80201e70 <wait>
}
    8020346a:	60e2                	ld	ra,24(sp)
    8020346c:	6442                	ld	s0,16(sp)
    8020346e:	6105                	addi	sp,sp,32
    80203470:	8082                	ret

0000000080203472 <sys_procstat>:

uint64 sys_procstat(void)
{
    80203472:	1101                	addi	sp,sp,-32
    80203474:	ec06                	sd	ra,24(sp)
    80203476:	e822                	sd	s0,16(sp)
    80203478:	1000                	addi	s0,sp,32
    uint64 uaddr;
    int max;
    argaddr(0, &uaddr);
    8020347a:	fe840593          	addi	a1,s0,-24
    8020347e:	4501                	li	a0,0
    80203480:	00000097          	auipc	ra,0x0
    80203484:	fa6080e7          	jalr	-90(ra) # 80203426 <argaddr>
    argint(1, &max);
    80203488:	fe440593          	addi	a1,s0,-28
    8020348c:	4505                	li	a0,1
    8020348e:	00000097          	auipc	ra,0x0
    80203492:	e3e080e7          	jalr	-450(ra) # 802032cc <argint>
    if (max <= 0) return -1;
    80203496:	fe442783          	lw	a5,-28(s0)
    8020349a:	02f05663          	blez	a5,802034c6 <sys_procstat+0x54>
    if (max > NPROC) max = NPROC;
    8020349e:	04000713          	li	a4,64
    802034a2:	00f75663          	bge	a4,a5,802034ae <sys_procstat+0x3c>
    802034a6:	04000793          	li	a5,64
    802034aa:	fef42223          	sw	a5,-28(s0)
    return procstat(uaddr, max);
    802034ae:	fe442583          	lw	a1,-28(s0)
    802034b2:	fe843503          	ld	a0,-24(s0)
    802034b6:	fffff097          	auipc	ra,0xfffff
    802034ba:	cc2080e7          	jalr	-830(ra) # 80202178 <procstat>
}
    802034be:	60e2                	ld	ra,24(sp)
    802034c0:	6442                	ld	s0,16(sp)
    802034c2:	6105                	addi	sp,sp,32
    802034c4:	8082                	ret
    if (max <= 0) return -1;
    802034c6:	557d                	li	a0,-1
    802034c8:	bfdd                	j	802034be <sys_procstat+0x4c>

00000000802034ca <sys_tracectl>:

/* Completed Lab 2 tracing syscalls. */
uint64 sys_tracectl(void)
{
    802034ca:	1101                	addi	sp,sp,-32
    802034cc:	ec06                	sd	ra,24(sp)
    802034ce:	e822                	sd	s0,16(sp)
    802034d0:	1000                	addi	s0,sp,32
    int action; uint64 filter;
    argint(0, &action); argaddr(1, &filter);
    802034d2:	fec40593          	addi	a1,s0,-20
    802034d6:	4501                	li	a0,0
    802034d8:	00000097          	auipc	ra,0x0
    802034dc:	df4080e7          	jalr	-524(ra) # 802032cc <argint>
    802034e0:	fe040593          	addi	a1,s0,-32
    802034e4:	4505                	li	a0,1
    802034e6:	00000097          	auipc	ra,0x0
    802034ea:	f40080e7          	jalr	-192(ra) # 80203426 <argaddr>
    return trace_ctl(action, filter);
    802034ee:	fe043583          	ld	a1,-32(s0)
    802034f2:	fec42503          	lw	a0,-20(s0)
    802034f6:	00001097          	auipc	ra,0x1
    802034fa:	e46080e7          	jalr	-442(ra) # 8020433c <trace_ctl>
}
    802034fe:	60e2                	ld	ra,24(sp)
    80203500:	6442                	ld	s0,16(sp)
    80203502:	6105                	addi	sp,sp,32
    80203504:	8082                	ret

0000000080203506 <sys_traceread>:
uint64 sys_traceread(void)
{
    80203506:	1101                	addi	sp,sp,-32
    80203508:	ec06                	sd	ra,24(sp)
    8020350a:	e822                	sd	s0,16(sp)
    8020350c:	1000                	addi	s0,sp,32
    uint64 buf; int max;
    argaddr(0, &buf); argint(1, &max);
    8020350e:	fe840593          	addi	a1,s0,-24
    80203512:	4501                	li	a0,0
    80203514:	00000097          	auipc	ra,0x0
    80203518:	f12080e7          	jalr	-238(ra) # 80203426 <argaddr>
    8020351c:	fe440593          	addi	a1,s0,-28
    80203520:	4505                	li	a0,1
    80203522:	00000097          	auipc	ra,0x0
    80203526:	daa080e7          	jalr	-598(ra) # 802032cc <argint>
    return trace_read(buf, max);
    8020352a:	fe442583          	lw	a1,-28(s0)
    8020352e:	fe843503          	ld	a0,-24(s0)
    80203532:	00001097          	auipc	ra,0x1
    80203536:	e50080e7          	jalr	-432(ra) # 80204382 <trace_read>
}
    8020353a:	60e2                	ld	ra,24(sp)
    8020353c:	6442                	ld	s0,16(sp)
    8020353e:	6105                	addi	sp,sp,32
    80203540:	8082                	ret

0000000080203542 <fetchstr>:
{
    80203542:	7179                	addi	sp,sp,-48
    80203544:	f406                	sd	ra,40(sp)
    80203546:	f022                	sd	s0,32(sp)
    80203548:	ec26                	sd	s1,24(sp)
    8020354a:	e84a                	sd	s2,16(sp)
    8020354c:	e44e                	sd	s3,8(sp)
    8020354e:	1800                	addi	s0,sp,48
    80203550:	892a                	mv	s2,a0
    80203552:	84ae                	mv	s1,a1
    80203554:	89b2                	mv	s3,a2
    struct proc *p = myproc();
    80203556:	ffffe097          	auipc	ra,0xffffe
    8020355a:	210080e7          	jalr	528(ra) # 80201766 <myproc>
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    8020355e:	86ce                	mv	a3,s3
    80203560:	864a                	mv	a2,s2
    80203562:	85a6                	mv	a1,s1
    80203564:	6928                	ld	a0,80(a0)
    80203566:	00000097          	auipc	ra,0x0
    8020356a:	b98080e7          	jalr	-1128(ra) # 802030fe <copyinstr>
    8020356e:	00054e63          	bltz	a0,8020358a <fetchstr+0x48>
    return strlen(buf);
    80203572:	8526                	mv	a0,s1
    80203574:	ffffd097          	auipc	ra,0xffffd
    80203578:	222080e7          	jalr	546(ra) # 80200796 <strlen>
}
    8020357c:	70a2                	ld	ra,40(sp)
    8020357e:	7402                	ld	s0,32(sp)
    80203580:	64e2                	ld	s1,24(sp)
    80203582:	6942                	ld	s2,16(sp)
    80203584:	69a2                	ld	s3,8(sp)
    80203586:	6145                	addi	sp,sp,48
    80203588:	8082                	ret
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    8020358a:	557d                	li	a0,-1
    8020358c:	bfc5                	j	8020357c <fetchstr+0x3a>

000000008020358e <argstr>:
{
    8020358e:	7179                	addi	sp,sp,-48
    80203590:	f406                	sd	ra,40(sp)
    80203592:	f022                	sd	s0,32(sp)
    80203594:	ec26                	sd	s1,24(sp)
    80203596:	e84a                	sd	s2,16(sp)
    80203598:	1800                	addi	s0,sp,48
    8020359a:	84ae                	mv	s1,a1
    8020359c:	8932                	mv	s2,a2
    argaddr(n, &addr);
    8020359e:	fd840593          	addi	a1,s0,-40
    802035a2:	00000097          	auipc	ra,0x0
    802035a6:	e84080e7          	jalr	-380(ra) # 80203426 <argaddr>
    return fetchstr(addr, buf, max);
    802035aa:	864a                	mv	a2,s2
    802035ac:	85a6                	mv	a1,s1
    802035ae:	fd843503          	ld	a0,-40(s0)
    802035b2:	00000097          	auipc	ra,0x0
    802035b6:	f90080e7          	jalr	-112(ra) # 80203542 <fetchstr>
}
    802035ba:	70a2                	ld	ra,40(sp)
    802035bc:	7402                	ld	s0,32(sp)
    802035be:	64e2                	ld	s1,24(sp)
    802035c0:	6942                	ld	s2,16(sp)
    802035c2:	6145                	addi	sp,sp,48
    802035c4:	8082                	ret

00000000802035c6 <syscall>:
/* ---- dispatch ---- */

#include "syscalltab.h"     /* GENERATED: syscalls[] and syscall_names[] */

void syscall(void)
{
    802035c6:	7179                	addi	sp,sp,-48
    802035c8:	f406                	sd	ra,40(sp)
    802035ca:	f022                	sd	s0,32(sp)
    802035cc:	ec26                	sd	s1,24(sp)
    802035ce:	e84a                	sd	s2,16(sp)
    802035d0:	e44e                	sd	s3,8(sp)
    802035d2:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    802035d4:	ffffe097          	auipc	ra,0xffffe
    802035d8:	192080e7          	jalr	402(ra) # 80201766 <myproc>
    802035dc:	84aa                	mv	s1,a0
    uint64 num = p->tf->a7;
    802035de:	05853983          	ld	s3,88(a0)
    802035e2:	0a89b903          	ld	s2,168(s3)

    /* Validate the number BEFORE indexing the table. A bad syscall number is a
     * hostile input, not a bug - return an error and stay alive.
     * Lab 2 (trace) hooks in HERE: this is the one point every call crosses. */
    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    802035e6:	fff90713          	addi	a4,s2,-1
    802035ea:	47e1                	li	a5,24
    802035ec:	04e7e663          	bltu	a5,a4,80203638 <syscall+0x72>
    802035f0:	00391713          	slli	a4,s2,0x3
    802035f4:	00005797          	auipc	a5,0x5
    802035f8:	88478793          	addi	a5,a5,-1916 # 80207e78 <syscalls>
    802035fc:	97ba                	add	a5,a5,a4
    802035fe:	639c                	ld	a5,0(a5)
    80203600:	cf85                	beqz	a5,80203638 <syscall+0x72>
    80203602:	e052                	sd	s4,0(sp)
        uint64 arg0 = p->tf->a0;
    80203604:	0709ba03          	ld	s4,112(s3)
        p->tf->a0 = syscalls[num]();
    80203608:	9782                	jalr	a5
    8020360a:	06a9b823          	sd	a0,112(s3)
        trace_record((int)num, (long)p->tf->a0, arg0);
    8020360e:	6cbc                	ld	a5,88(s1)
    80203610:	8652                	mv	a2,s4
    80203612:	7bac                	ld	a1,112(a5)
    80203614:	0009051b          	sext.w	a0,s2
    80203618:	00001097          	auipc	ra,0x1
    8020361c:	be6080e7          	jalr	-1050(ra) # 802041fe <trace_record>
        p->syscall_count++;
    80203620:	1784b783          	ld	a5,376(s1)
    80203624:	0785                	addi	a5,a5,1
    80203626:	16f4bc23          	sd	a5,376(s1)
        usysinfo_update(p);
    8020362a:	8526                	mv	a0,s1
    8020362c:	00001097          	auipc	ra,0x1
    80203630:	074080e7          	jalr	116(ra) # 802046a0 <usysinfo_update>
    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    80203634:	6a02                	ld	s4,0(sp)
    80203636:	a005                	j	80203656 <syscall+0x90>
    } else {
        printf("pid %d (%s): unknown syscall %d\n", p->pid, p->name, num);
    80203638:	86ca                	mv	a3,s2
    8020363a:	15848613          	addi	a2,s1,344
    8020363e:	588c                	lw	a1,48(s1)
    80203640:	00004517          	auipc	a0,0x4
    80203644:	2a850513          	addi	a0,a0,680 # 802078e8 <etext+0x8e8>
    80203648:	ffffd097          	auipc	ra,0xffffd
    8020364c:	d38080e7          	jalr	-712(ra) # 80200380 <printf>
        p->tf->a0 = -1;
    80203650:	6cbc                	ld	a5,88(s1)
    80203652:	577d                	li	a4,-1
    80203654:	fbb8                	sd	a4,112(a5)
    }
    (void)syscall_name;      /* used by Lab 2; referenced here to stay warning-clean */
}
    80203656:	70a2                	ld	ra,40(sp)
    80203658:	7402                	ld	s0,32(sp)
    8020365a:	64e2                	ld	s1,24(sp)
    8020365c:	6942                	ld	s2,16(sp)
    8020365e:	69a2                	ld	s3,8(sp)
    80203660:	6145                	addi	sp,sp,48
    80203662:	8082                	ret

0000000080203664 <argfd>:
#include "defs.h"
#include "fcntl.h"

/* Fetch the n'th arg as a file descriptor; return the struct file too. */
static int argfd(int n, int *pfd, struct file **pf)
{
    80203664:	7179                	addi	sp,sp,-48
    80203666:	f406                	sd	ra,40(sp)
    80203668:	f022                	sd	s0,32(sp)
    8020366a:	ec26                	sd	s1,24(sp)
    8020366c:	e84a                	sd	s2,16(sp)
    8020366e:	1800                	addi	s0,sp,48
    80203670:	892e                	mv	s2,a1
    80203672:	84b2                	mv	s1,a2
    int fd;
    argint(n, &fd);
    80203674:	fdc40593          	addi	a1,s0,-36
    80203678:	00000097          	auipc	ra,0x0
    8020367c:	c54080e7          	jalr	-940(ra) # 802032cc <argint>
    if (fd < 0 || fd >= NOFILE) return -1;
    80203680:	fdc42703          	lw	a4,-36(s0)
    80203684:	47bd                	li	a5,15
    80203686:	02e7eb63          	bltu	a5,a4,802036bc <argfd+0x58>
    struct file *f = myproc()->ofile[fd];
    8020368a:	ffffe097          	auipc	ra,0xffffe
    8020368e:	0dc080e7          	jalr	220(ra) # 80201766 <myproc>
    80203692:	fdc42703          	lw	a4,-36(s0)
    80203696:	01a70793          	addi	a5,a4,26
    8020369a:	078e                	slli	a5,a5,0x3
    8020369c:	953e                	add	a0,a0,a5
    8020369e:	611c                	ld	a5,0(a0)
    if (f == 0) return -1;
    802036a0:	c385                	beqz	a5,802036c0 <argfd+0x5c>
    if (pfd) *pfd = fd;
    802036a2:	00090463          	beqz	s2,802036aa <argfd+0x46>
    802036a6:	00e92023          	sw	a4,0(s2)
    if (pf)  *pf  = f;
    return 0;
    802036aa:	4501                	li	a0,0
    if (pf)  *pf  = f;
    802036ac:	c091                	beqz	s1,802036b0 <argfd+0x4c>
    802036ae:	e09c                	sd	a5,0(s1)
}
    802036b0:	70a2                	ld	ra,40(sp)
    802036b2:	7402                	ld	s0,32(sp)
    802036b4:	64e2                	ld	s1,24(sp)
    802036b6:	6942                	ld	s2,16(sp)
    802036b8:	6145                	addi	sp,sp,48
    802036ba:	8082                	ret
    if (fd < 0 || fd >= NOFILE) return -1;
    802036bc:	557d                	li	a0,-1
    802036be:	bfcd                	j	802036b0 <argfd+0x4c>
    if (f == 0) return -1;
    802036c0:	557d                	li	a0,-1
    802036c2:	b7fd                	j	802036b0 <argfd+0x4c>

00000000802036c4 <fdalloc>:

/* Install f in the first free slot of the fd table. */
static int fdalloc(struct file *f)
{
    802036c4:	1101                	addi	sp,sp,-32
    802036c6:	ec06                	sd	ra,24(sp)
    802036c8:	e822                	sd	s0,16(sp)
    802036ca:	e426                	sd	s1,8(sp)
    802036cc:	1000                	addi	s0,sp,32
    802036ce:	84aa                	mv	s1,a0
    struct proc *p = myproc();
    802036d0:	ffffe097          	auipc	ra,0xffffe
    802036d4:	096080e7          	jalr	150(ra) # 80201766 <myproc>
    802036d8:	862a                	mv	a2,a0
    for (int fd = 0; fd < NOFILE; fd++) {
    802036da:	0d050793          	addi	a5,a0,208
    802036de:	4501                	li	a0,0
    802036e0:	46c1                	li	a3,16
        if (p->ofile[fd] == 0) {
    802036e2:	6398                	ld	a4,0(a5)
    802036e4:	cb19                	beqz	a4,802036fa <fdalloc+0x36>
    for (int fd = 0; fd < NOFILE; fd++) {
    802036e6:	2505                	addiw	a0,a0,1
    802036e8:	07a1                	addi	a5,a5,8
    802036ea:	fed51ce3          	bne	a0,a3,802036e2 <fdalloc+0x1e>
            p->ofile[fd] = f;
            return fd;
        }
    }
    return -1;
    802036ee:	557d                	li	a0,-1
}
    802036f0:	60e2                	ld	ra,24(sp)
    802036f2:	6442                	ld	s0,16(sp)
    802036f4:	64a2                	ld	s1,8(sp)
    802036f6:	6105                	addi	sp,sp,32
    802036f8:	8082                	ret
            p->ofile[fd] = f;
    802036fa:	01a50793          	addi	a5,a0,26
    802036fe:	078e                	slli	a5,a5,0x3
    80203700:	963e                	add	a2,a2,a5
    80203702:	e204                	sd	s1,0(a2)
            return fd;
    80203704:	b7f5                	j	802036f0 <fdalloc+0x2c>

0000000080203706 <create>:
}

/* Create path as type. Returns LOCKED inode, or 0. Handles the T_DIR case
 * (".", "..", parent nlink) and open(O_CREATE) racing an existing file. */
static struct inode *create(char *path, uint16 type, uint16 major, uint16 minor)
{
    80203706:	711d                	addi	sp,sp,-96
    80203708:	ec86                	sd	ra,88(sp)
    8020370a:	e8a2                	sd	s0,80(sp)
    8020370c:	e4a6                	sd	s1,72(sp)
    8020370e:	e0ca                	sd	s2,64(sp)
    80203710:	fc4e                	sd	s3,56(sp)
    80203712:	f456                	sd	s5,40(sp)
    80203714:	f05a                	sd	s6,32(sp)
    80203716:	1080                	addi	s0,sp,96
    80203718:	8b2e                	mv	s6,a1
    8020371a:	89b2                	mv	s3,a2
    8020371c:	8936                	mv	s2,a3
    char name[DIRSIZ];
    struct inode *dp = nameiparent(path, name);
    8020371e:	fa040593          	addi	a1,s0,-96
    80203722:	00003097          	auipc	ra,0x3
    80203726:	87c080e7          	jalr	-1924(ra) # 80205f9e <nameiparent>
    8020372a:	84aa                	mv	s1,a0
    if (dp == 0) return 0;
    8020372c:	16050263          	beqz	a0,80203890 <create+0x18a>
    ilock(dp);
    80203730:	00002097          	auipc	ra,0x2
    80203734:	fbc080e7          	jalr	-68(ra) # 802056ec <ilock>

    struct inode *ip = dirlookup(dp, name, 0);
    80203738:	4601                	li	a2,0
    8020373a:	fa040593          	addi	a1,s0,-96
    8020373e:	8526                	mv	a0,s1
    80203740:	00002097          	auipc	ra,0x2
    80203744:	576080e7          	jalr	1398(ra) # 80205cb6 <dirlookup>
    80203748:	8aaa                	mv	s5,a0
    if (ip != 0) {
    8020374a:	c929                	beqz	a0,8020379c <create+0x96>
        iunlockput(dp);
    8020374c:	8526                	mv	a0,s1
    8020374e:	00002097          	auipc	ra,0x2
    80203752:	27a080e7          	jalr	634(ra) # 802059c8 <iunlockput>
        ilock(ip);
    80203756:	8556                	mv	a0,s5
    80203758:	00002097          	auipc	ra,0x2
    8020375c:	f94080e7          	jalr	-108(ra) # 802056ec <ilock>
        if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEV))
    80203760:	000b059b          	sext.w	a1,s6
    80203764:	4789                	li	a5,2
    80203766:	02f59463          	bne	a1,a5,8020378e <create+0x88>
    8020376a:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <uart+0xffffffff7fcb5014>
    8020376e:	37f9                	addiw	a5,a5,-2
    80203770:	17c2                	slli	a5,a5,0x30
    80203772:	93c1                	srli	a5,a5,0x30
    80203774:	4705                	li	a4,1
    80203776:	00f76c63          	bltu	a4,a5,8020378e <create+0x88>
    ip->nlink = 0;
    iupdate(ip);
    iunlockput(ip);
    iunlockput(dp);
    return 0;
}
    8020377a:	8556                	mv	a0,s5
    8020377c:	60e6                	ld	ra,88(sp)
    8020377e:	6446                	ld	s0,80(sp)
    80203780:	64a6                	ld	s1,72(sp)
    80203782:	6906                	ld	s2,64(sp)
    80203784:	79e2                	ld	s3,56(sp)
    80203786:	7aa2                	ld	s5,40(sp)
    80203788:	7b02                	ld	s6,32(sp)
    8020378a:	6125                	addi	sp,sp,96
    8020378c:	8082                	ret
        iunlockput(ip);
    8020378e:	8556                	mv	a0,s5
    80203790:	00002097          	auipc	ra,0x2
    80203794:	238080e7          	jalr	568(ra) # 802059c8 <iunlockput>
        return 0;
    80203798:	4a81                	li	s5,0
    8020379a:	b7c5                	j	8020377a <create+0x74>
    8020379c:	f852                	sd	s4,48(sp)
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    8020379e:	85da                	mv	a1,s6
    802037a0:	4088                	lw	a0,0(s1)
    802037a2:	00002097          	auipc	ra,0x2
    802037a6:	d4e080e7          	jalr	-690(ra) # 802054f0 <ialloc>
    802037aa:	8a2a                	mv	s4,a0
    802037ac:	c921                	beqz	a0,802037fc <create+0xf6>
    ilock(ip);
    802037ae:	00002097          	auipc	ra,0x2
    802037b2:	f3e080e7          	jalr	-194(ra) # 802056ec <ilock>
    ip->major = major;
    802037b6:	053a1323          	sh	s3,70(s4)
    ip->minor = minor;
    802037ba:	052a1423          	sh	s2,72(s4)
    ip->nlink = 1;
    802037be:	4905                	li	s2,1
    802037c0:	052a1523          	sh	s2,74(s4)
    iupdate(ip);
    802037c4:	8552                	mv	a0,s4
    802037c6:	00002097          	auipc	ra,0x2
    802037ca:	e5a080e7          	jalr	-422(ra) # 80205620 <iupdate>
    if (type == T_DIR) {
    802037ce:	000b059b          	sext.w	a1,s6
    802037d2:	03258d63          	beq	a1,s2,8020380c <create+0x106>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    802037d6:	004a2603          	lw	a2,4(s4)
    802037da:	fa040593          	addi	a1,s0,-96
    802037de:	8526                	mv	a0,s1
    802037e0:	00002097          	auipc	ra,0x2
    802037e4:	6e6080e7          	jalr	1766(ra) # 80205ec6 <dirlink>
    802037e8:	08054163          	bltz	a0,8020386a <create+0x164>
    iunlockput(dp);
    802037ec:	8526                	mv	a0,s1
    802037ee:	00002097          	auipc	ra,0x2
    802037f2:	1da080e7          	jalr	474(ra) # 802059c8 <iunlockput>
    return ip;
    802037f6:	8ad2                	mv	s5,s4
    802037f8:	7a42                	ld	s4,48(sp)
    802037fa:	b741                	j	8020377a <create+0x74>
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    802037fc:	8526                	mv	a0,s1
    802037fe:	00002097          	auipc	ra,0x2
    80203802:	1ca080e7          	jalr	458(ra) # 802059c8 <iunlockput>
    80203806:	8ad2                	mv	s5,s4
    80203808:	7a42                	ld	s4,48(sp)
    8020380a:	bf85                	j	8020377a <create+0x74>
        if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    8020380c:	004a2603          	lw	a2,4(s4)
    80203810:	00004597          	auipc	a1,0x4
    80203814:	10058593          	addi	a1,a1,256 # 80207910 <etext+0x910>
    80203818:	8552                	mv	a0,s4
    8020381a:	00002097          	auipc	ra,0x2
    8020381e:	6ac080e7          	jalr	1708(ra) # 80205ec6 <dirlink>
    80203822:	04054463          	bltz	a0,8020386a <create+0x164>
    80203826:	40d0                	lw	a2,4(s1)
    80203828:	00004597          	auipc	a1,0x4
    8020382c:	0f058593          	addi	a1,a1,240 # 80207918 <etext+0x918>
    80203830:	8552                	mv	a0,s4
    80203832:	00002097          	auipc	ra,0x2
    80203836:	694080e7          	jalr	1684(ra) # 80205ec6 <dirlink>
    8020383a:	02054863          	bltz	a0,8020386a <create+0x164>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    8020383e:	004a2603          	lw	a2,4(s4)
    80203842:	fa040593          	addi	a1,s0,-96
    80203846:	8526                	mv	a0,s1
    80203848:	00002097          	auipc	ra,0x2
    8020384c:	67e080e7          	jalr	1662(ra) # 80205ec6 <dirlink>
    80203850:	00054d63          	bltz	a0,8020386a <create+0x164>
        dp->nlink++;
    80203854:	04a4d783          	lhu	a5,74(s1)
    80203858:	2785                	addiw	a5,a5,1
    8020385a:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    8020385e:	8526                	mv	a0,s1
    80203860:	00002097          	auipc	ra,0x2
    80203864:	dc0080e7          	jalr	-576(ra) # 80205620 <iupdate>
    80203868:	b751                	j	802037ec <create+0xe6>
    ip->nlink = 0;
    8020386a:	040a1523          	sh	zero,74(s4)
    iupdate(ip);
    8020386e:	8552                	mv	a0,s4
    80203870:	00002097          	auipc	ra,0x2
    80203874:	db0080e7          	jalr	-592(ra) # 80205620 <iupdate>
    iunlockput(ip);
    80203878:	8552                	mv	a0,s4
    8020387a:	00002097          	auipc	ra,0x2
    8020387e:	14e080e7          	jalr	334(ra) # 802059c8 <iunlockput>
    iunlockput(dp);
    80203882:	8526                	mv	a0,s1
    80203884:	00002097          	auipc	ra,0x2
    80203888:	144080e7          	jalr	324(ra) # 802059c8 <iunlockput>
    return 0;
    8020388c:	7a42                	ld	s4,48(sp)
    8020388e:	b5f5                	j	8020377a <create+0x74>
    if (dp == 0) return 0;
    80203890:	8aaa                	mv	s5,a0
    80203892:	b5e5                	j	8020377a <create+0x74>

0000000080203894 <sys_dup>:
{
    80203894:	7179                	addi	sp,sp,-48
    80203896:	f406                	sd	ra,40(sp)
    80203898:	f022                	sd	s0,32(sp)
    8020389a:	1800                	addi	s0,sp,48
    if (argfd(0, 0, &f) < 0) return -1;
    8020389c:	fd840613          	addi	a2,s0,-40
    802038a0:	4581                	li	a1,0
    802038a2:	4501                	li	a0,0
    802038a4:	00000097          	auipc	ra,0x0
    802038a8:	dc0080e7          	jalr	-576(ra) # 80203664 <argfd>
    802038ac:	57fd                	li	a5,-1
    802038ae:	02054763          	bltz	a0,802038dc <sys_dup+0x48>
    802038b2:	ec26                	sd	s1,24(sp)
    802038b4:	e84a                	sd	s2,16(sp)
    int fd = fdalloc(f);
    802038b6:	fd843903          	ld	s2,-40(s0)
    802038ba:	854a                	mv	a0,s2
    802038bc:	00000097          	auipc	ra,0x0
    802038c0:	e08080e7          	jalr	-504(ra) # 802036c4 <fdalloc>
    802038c4:	84aa                	mv	s1,a0
    if (fd < 0) return -1;
    802038c6:	57fd                	li	a5,-1
    802038c8:	00054f63          	bltz	a0,802038e6 <sys_dup+0x52>
    filedup(f);
    802038cc:	854a                	mv	a0,s2
    802038ce:	00002097          	auipc	ra,0x2
    802038d2:	77e080e7          	jalr	1918(ra) # 8020604c <filedup>
    return fd;
    802038d6:	87a6                	mv	a5,s1
    802038d8:	64e2                	ld	s1,24(sp)
    802038da:	6942                	ld	s2,16(sp)
}
    802038dc:	853e                	mv	a0,a5
    802038de:	70a2                	ld	ra,40(sp)
    802038e0:	7402                	ld	s0,32(sp)
    802038e2:	6145                	addi	sp,sp,48
    802038e4:	8082                	ret
    802038e6:	64e2                	ld	s1,24(sp)
    802038e8:	6942                	ld	s2,16(sp)
    802038ea:	bfcd                	j	802038dc <sys_dup+0x48>

00000000802038ec <sys_read>:
{
    802038ec:	7179                	addi	sp,sp,-48
    802038ee:	f406                	sd	ra,40(sp)
    802038f0:	f022                	sd	s0,32(sp)
    802038f2:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    802038f4:	fd840593          	addi	a1,s0,-40
    802038f8:	4505                	li	a0,1
    802038fa:	00000097          	auipc	ra,0x0
    802038fe:	b2c080e7          	jalr	-1236(ra) # 80203426 <argaddr>
    argint(2, &n);
    80203902:	fe440593          	addi	a1,s0,-28
    80203906:	4509                	li	a0,2
    80203908:	00000097          	auipc	ra,0x0
    8020390c:	9c4080e7          	jalr	-1596(ra) # 802032cc <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203910:	fe840613          	addi	a2,s0,-24
    80203914:	4581                	li	a1,0
    80203916:	4501                	li	a0,0
    80203918:	00000097          	auipc	ra,0x0
    8020391c:	d4c080e7          	jalr	-692(ra) # 80203664 <argfd>
    80203920:	02054363          	bltz	a0,80203946 <sys_read+0x5a>
    80203924:	fe442603          	lw	a2,-28(s0)
    80203928:	557d                	li	a0,-1
    8020392a:	00064a63          	bltz	a2,8020393e <sys_read+0x52>
    return fileread(f, p, n);
    8020392e:	fd843583          	ld	a1,-40(s0)
    80203932:	fe843503          	ld	a0,-24(s0)
    80203936:	00003097          	auipc	ra,0x3
    8020393a:	8a4080e7          	jalr	-1884(ra) # 802061da <fileread>
}
    8020393e:	70a2                	ld	ra,40(sp)
    80203940:	7402                	ld	s0,32(sp)
    80203942:	6145                	addi	sp,sp,48
    80203944:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203946:	557d                	li	a0,-1
    80203948:	bfdd                	j	8020393e <sys_read+0x52>

000000008020394a <sys_write>:
{
    8020394a:	7179                	addi	sp,sp,-48
    8020394c:	f406                	sd	ra,40(sp)
    8020394e:	f022                	sd	s0,32(sp)
    80203950:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    80203952:	fd840593          	addi	a1,s0,-40
    80203956:	4505                	li	a0,1
    80203958:	00000097          	auipc	ra,0x0
    8020395c:	ace080e7          	jalr	-1330(ra) # 80203426 <argaddr>
    argint(2, &n);
    80203960:	fe440593          	addi	a1,s0,-28
    80203964:	4509                	li	a0,2
    80203966:	00000097          	auipc	ra,0x0
    8020396a:	966080e7          	jalr	-1690(ra) # 802032cc <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    8020396e:	fe840613          	addi	a2,s0,-24
    80203972:	4581                	li	a1,0
    80203974:	4501                	li	a0,0
    80203976:	00000097          	auipc	ra,0x0
    8020397a:	cee080e7          	jalr	-786(ra) # 80203664 <argfd>
    8020397e:	02054363          	bltz	a0,802039a4 <sys_write+0x5a>
    80203982:	fe442603          	lw	a2,-28(s0)
    80203986:	557d                	li	a0,-1
    80203988:	00064a63          	bltz	a2,8020399c <sys_write+0x52>
    return filewrite(f, p, n);
    8020398c:	fd843583          	ld	a1,-40(s0)
    80203990:	fe843503          	ld	a0,-24(s0)
    80203994:	00003097          	auipc	ra,0x3
    80203998:	91a080e7          	jalr	-1766(ra) # 802062ae <filewrite>
}
    8020399c:	70a2                	ld	ra,40(sp)
    8020399e:	7402                	ld	s0,32(sp)
    802039a0:	6145                	addi	sp,sp,48
    802039a2:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    802039a4:	557d                	li	a0,-1
    802039a6:	bfdd                	j	8020399c <sys_write+0x52>

00000000802039a8 <sys_close>:
{
    802039a8:	1101                	addi	sp,sp,-32
    802039aa:	ec06                	sd	ra,24(sp)
    802039ac:	e822                	sd	s0,16(sp)
    802039ae:	1000                	addi	s0,sp,32
    if (argfd(0, &fd, &f) < 0) return -1;
    802039b0:	fe040613          	addi	a2,s0,-32
    802039b4:	fec40593          	addi	a1,s0,-20
    802039b8:	4501                	li	a0,0
    802039ba:	00000097          	auipc	ra,0x0
    802039be:	caa080e7          	jalr	-854(ra) # 80203664 <argfd>
    802039c2:	57fd                	li	a5,-1
    802039c4:	02054463          	bltz	a0,802039ec <sys_close+0x44>
    myproc()->ofile[fd] = 0;
    802039c8:	ffffe097          	auipc	ra,0xffffe
    802039cc:	d9e080e7          	jalr	-610(ra) # 80201766 <myproc>
    802039d0:	fec42783          	lw	a5,-20(s0)
    802039d4:	07e9                	addi	a5,a5,26
    802039d6:	078e                	slli	a5,a5,0x3
    802039d8:	953e                	add	a0,a0,a5
    802039da:	00053023          	sd	zero,0(a0)
    fileclose(f);
    802039de:	fe043503          	ld	a0,-32(s0)
    802039e2:	00002097          	auipc	ra,0x2
    802039e6:	6bc080e7          	jalr	1724(ra) # 8020609e <fileclose>
    return 0;
    802039ea:	4781                	li	a5,0
}
    802039ec:	853e                	mv	a0,a5
    802039ee:	60e2                	ld	ra,24(sp)
    802039f0:	6442                	ld	s0,16(sp)
    802039f2:	6105                	addi	sp,sp,32
    802039f4:	8082                	ret

00000000802039f6 <sys_fstat>:
{
    802039f6:	1101                	addi	sp,sp,-32
    802039f8:	ec06                	sd	ra,24(sp)
    802039fa:	e822                	sd	s0,16(sp)
    802039fc:	1000                	addi	s0,sp,32
    argaddr(1, &st);
    802039fe:	fe040593          	addi	a1,s0,-32
    80203a02:	4505                	li	a0,1
    80203a04:	00000097          	auipc	ra,0x0
    80203a08:	a22080e7          	jalr	-1502(ra) # 80203426 <argaddr>
    if (argfd(0, 0, &f) < 0) return -1;
    80203a0c:	fe840613          	addi	a2,s0,-24
    80203a10:	4581                	li	a1,0
    80203a12:	4501                	li	a0,0
    80203a14:	00000097          	auipc	ra,0x0
    80203a18:	c50080e7          	jalr	-944(ra) # 80203664 <argfd>
    80203a1c:	87aa                	mv	a5,a0
    80203a1e:	557d                	li	a0,-1
    80203a20:	0007ca63          	bltz	a5,80203a34 <sys_fstat+0x3e>
    return filestat(f, st);
    80203a24:	fe043583          	ld	a1,-32(s0)
    80203a28:	fe843503          	ld	a0,-24(s0)
    80203a2c:	00002097          	auipc	ra,0x2
    80203a30:	744080e7          	jalr	1860(ra) # 80206170 <filestat>
}
    80203a34:	60e2                	ld	ra,24(sp)
    80203a36:	6442                	ld	s0,16(sp)
    80203a38:	6105                	addi	sp,sp,32
    80203a3a:	8082                	ret

0000000080203a3c <sys_link>:
{
    80203a3c:	7129                	addi	sp,sp,-320
    80203a3e:	fe06                	sd	ra,312(sp)
    80203a40:	fa22                	sd	s0,304(sp)
    80203a42:	0280                	addi	s0,sp,320
    if (argstr(0, oldp, MAXPATH) < 0 || argstr(1, newp, MAXPATH) < 0) return -1;
    80203a44:	08000613          	li	a2,128
    80203a48:	ec040593          	addi	a1,s0,-320
    80203a4c:	4501                	li	a0,0
    80203a4e:	00000097          	auipc	ra,0x0
    80203a52:	b40080e7          	jalr	-1216(ra) # 8020358e <argstr>
    80203a56:	57fd                	li	a5,-1
    80203a58:	0e054f63          	bltz	a0,80203b56 <sys_link+0x11a>
    80203a5c:	08000613          	li	a2,128
    80203a60:	f4040593          	addi	a1,s0,-192
    80203a64:	4505                	li	a0,1
    80203a66:	00000097          	auipc	ra,0x0
    80203a6a:	b28080e7          	jalr	-1240(ra) # 8020358e <argstr>
    80203a6e:	57fd                	li	a5,-1
    80203a70:	0e054363          	bltz	a0,80203b56 <sys_link+0x11a>
    80203a74:	f626                	sd	s1,296(sp)
    struct inode *ip = namei(oldp);
    80203a76:	ec040513          	addi	a0,s0,-320
    80203a7a:	00002097          	auipc	ra,0x2
    80203a7e:	506080e7          	jalr	1286(ra) # 80205f80 <namei>
    80203a82:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80203a84:	cd71                	beqz	a0,80203b60 <sys_link+0x124>
    ilock(ip);
    80203a86:	00002097          	auipc	ra,0x2
    80203a8a:	c66080e7          	jalr	-922(ra) # 802056ec <ilock>
    if (ip->type == T_DIR) {          /* hard links to dirs make cycles */
    80203a8e:	0444d703          	lhu	a4,68(s1)
    80203a92:	4785                	li	a5,1
    80203a94:	06f70d63          	beq	a4,a5,80203b0e <sys_link+0xd2>
    80203a98:	f24a                	sd	s2,288(sp)
    ip->nlink++;
    80203a9a:	04a4d783          	lhu	a5,74(s1)
    80203a9e:	2785                	addiw	a5,a5,1
    80203aa0:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80203aa4:	8526                	mv	a0,s1
    80203aa6:	00002097          	auipc	ra,0x2
    80203aaa:	b7a080e7          	jalr	-1158(ra) # 80205620 <iupdate>
    iunlock(ip);
    80203aae:	8526                	mv	a0,s1
    80203ab0:	00002097          	auipc	ra,0x2
    80203ab4:	d02080e7          	jalr	-766(ra) # 802057b2 <iunlock>
    struct inode *dp = nameiparent(newp, name);
    80203ab8:	fc040593          	addi	a1,s0,-64
    80203abc:	f4040513          	addi	a0,s0,-192
    80203ac0:	00002097          	auipc	ra,0x2
    80203ac4:	4de080e7          	jalr	1246(ra) # 80205f9e <nameiparent>
    80203ac8:	892a                	mv	s2,a0
    if (dp == 0) goto bad;
    80203aca:	cd39                	beqz	a0,80203b28 <sys_link+0xec>
    ilock(dp);
    80203acc:	00002097          	auipc	ra,0x2
    80203ad0:	c20080e7          	jalr	-992(ra) # 802056ec <ilock>
    if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80203ad4:	00092703          	lw	a4,0(s2)
    80203ad8:	409c                	lw	a5,0(s1)
    80203ada:	04f71263          	bne	a4,a5,80203b1e <sys_link+0xe2>
    80203ade:	40d0                	lw	a2,4(s1)
    80203ae0:	fc040593          	addi	a1,s0,-64
    80203ae4:	854a                	mv	a0,s2
    80203ae6:	00002097          	auipc	ra,0x2
    80203aea:	3e0080e7          	jalr	992(ra) # 80205ec6 <dirlink>
    80203aee:	02054863          	bltz	a0,80203b1e <sys_link+0xe2>
    iunlockput(dp);
    80203af2:	854a                	mv	a0,s2
    80203af4:	00002097          	auipc	ra,0x2
    80203af8:	ed4080e7          	jalr	-300(ra) # 802059c8 <iunlockput>
    iput(ip);
    80203afc:	8526                	mv	a0,s1
    80203afe:	00002097          	auipc	ra,0x2
    80203b02:	dac080e7          	jalr	-596(ra) # 802058aa <iput>
    return 0;
    80203b06:	4781                	li	a5,0
    80203b08:	74b2                	ld	s1,296(sp)
    80203b0a:	7912                	ld	s2,288(sp)
    80203b0c:	a0a9                	j	80203b56 <sys_link+0x11a>
        iunlockput(ip);
    80203b0e:	8526                	mv	a0,s1
    80203b10:	00002097          	auipc	ra,0x2
    80203b14:	eb8080e7          	jalr	-328(ra) # 802059c8 <iunlockput>
        return -1;
    80203b18:	57fd                	li	a5,-1
    80203b1a:	74b2                	ld	s1,296(sp)
    80203b1c:	a82d                	j	80203b56 <sys_link+0x11a>
        iunlockput(dp);
    80203b1e:	854a                	mv	a0,s2
    80203b20:	00002097          	auipc	ra,0x2
    80203b24:	ea8080e7          	jalr	-344(ra) # 802059c8 <iunlockput>
    ilock(ip);
    80203b28:	8526                	mv	a0,s1
    80203b2a:	00002097          	auipc	ra,0x2
    80203b2e:	bc2080e7          	jalr	-1086(ra) # 802056ec <ilock>
    ip->nlink--;
    80203b32:	04a4d783          	lhu	a5,74(s1)
    80203b36:	37fd                	addiw	a5,a5,-1
    80203b38:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80203b3c:	8526                	mv	a0,s1
    80203b3e:	00002097          	auipc	ra,0x2
    80203b42:	ae2080e7          	jalr	-1310(ra) # 80205620 <iupdate>
    iunlockput(ip);
    80203b46:	8526                	mv	a0,s1
    80203b48:	00002097          	auipc	ra,0x2
    80203b4c:	e80080e7          	jalr	-384(ra) # 802059c8 <iunlockput>
    return -1;
    80203b50:	57fd                	li	a5,-1
    80203b52:	74b2                	ld	s1,296(sp)
    80203b54:	7912                	ld	s2,288(sp)
}
    80203b56:	853e                	mv	a0,a5
    80203b58:	70f2                	ld	ra,312(sp)
    80203b5a:	7452                	ld	s0,304(sp)
    80203b5c:	6131                	addi	sp,sp,320
    80203b5e:	8082                	ret
    if (ip == 0) return -1;
    80203b60:	57fd                	li	a5,-1
    80203b62:	74b2                	ld	s1,296(sp)
    80203b64:	bfcd                	j	80203b56 <sys_link+0x11a>

0000000080203b66 <sys_unlink>:
{
    80203b66:	712d                	addi	sp,sp,-288
    80203b68:	ee06                	sd	ra,280(sp)
    80203b6a:	ea22                	sd	s0,272(sp)
    80203b6c:	1200                	addi	s0,sp,288
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203b6e:	08000613          	li	a2,128
    80203b72:	f3040593          	addi	a1,s0,-208
    80203b76:	4501                	li	a0,0
    80203b78:	00000097          	auipc	ra,0x0
    80203b7c:	a16080e7          	jalr	-1514(ra) # 8020358e <argstr>
    80203b80:	18054d63          	bltz	a0,80203d1a <sys_unlink+0x1b4>
    80203b84:	e626                	sd	s1,264(sp)
    struct inode *dp = nameiparent(path, name);
    80203b86:	fb040593          	addi	a1,s0,-80
    80203b8a:	f3040513          	addi	a0,s0,-208
    80203b8e:	00002097          	auipc	ra,0x2
    80203b92:	410080e7          	jalr	1040(ra) # 80205f9e <nameiparent>
    80203b96:	84aa                	mv	s1,a0
    if (dp == 0) return -1;
    80203b98:	18050363          	beqz	a0,80203d1e <sys_unlink+0x1b8>
    ilock(dp);
    80203b9c:	00002097          	auipc	ra,0x2
    80203ba0:	b50080e7          	jalr	-1200(ra) # 802056ec <ilock>
    if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0) goto bad;
    80203ba4:	00004597          	auipc	a1,0x4
    80203ba8:	d6c58593          	addi	a1,a1,-660 # 80207910 <etext+0x910>
    80203bac:	fb040513          	addi	a0,s0,-80
    80203bb0:	00002097          	auipc	ra,0x2
    80203bb4:	0ec080e7          	jalr	236(ra) # 80205c9c <namecmp>
    80203bb8:	14050663          	beqz	a0,80203d04 <sys_unlink+0x19e>
    80203bbc:	00004597          	auipc	a1,0x4
    80203bc0:	d5c58593          	addi	a1,a1,-676 # 80207918 <etext+0x918>
    80203bc4:	fb040513          	addi	a0,s0,-80
    80203bc8:	00002097          	auipc	ra,0x2
    80203bcc:	0d4080e7          	jalr	212(ra) # 80205c9c <namecmp>
    80203bd0:	12050a63          	beqz	a0,80203d04 <sys_unlink+0x19e>
    80203bd4:	e24a                	sd	s2,256(sp)
    struct inode *ip = dirlookup(dp, name, &off);
    80203bd6:	f2c40613          	addi	a2,s0,-212
    80203bda:	fb040593          	addi	a1,s0,-80
    80203bde:	8526                	mv	a0,s1
    80203be0:	00002097          	auipc	ra,0x2
    80203be4:	0d6080e7          	jalr	214(ra) # 80205cb6 <dirlookup>
    80203be8:	892a                	mv	s2,a0
    if (ip == 0) goto bad;
    80203bea:	10050c63          	beqz	a0,80203d02 <sys_unlink+0x19c>
    ilock(ip);                        /* lock order: parent, then child */
    80203bee:	00002097          	auipc	ra,0x2
    80203bf2:	afe080e7          	jalr	-1282(ra) # 802056ec <ilock>
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203bf6:	04a95783          	lhu	a5,74(s2)
    80203bfa:	cfa5                	beqz	a5,80203c72 <sys_unlink+0x10c>
    if (ip->type == T_DIR && !isdirempty(ip)) {
    80203bfc:	04495703          	lhu	a4,68(s2)
    80203c00:	4785                	li	a5,1
    80203c02:	08f70163          	beq	a4,a5,80203c84 <sys_unlink+0x11e>
    memset(&de, 0, sizeof(de));
    80203c06:	02000613          	li	a2,32
    80203c0a:	4581                	li	a1,0
    80203c0c:	f0840513          	addi	a0,s0,-248
    80203c10:	ffffd097          	auipc	ra,0xffffd
    80203c14:	a88080e7          	jalr	-1400(ra) # 80200698 <memset>
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203c18:	02000713          	li	a4,32
    80203c1c:	f2c42683          	lw	a3,-212(s0)
    80203c20:	f0840613          	addi	a2,s0,-248
    80203c24:	4581                	li	a1,0
    80203c26:	8526                	mv	a0,s1
    80203c28:	00002097          	auipc	ra,0x2
    80203c2c:	f26080e7          	jalr	-218(ra) # 80205b4e <writei>
    80203c30:	02000793          	li	a5,32
    80203c34:	0af51363          	bne	a0,a5,80203cda <sys_unlink+0x174>
    if (ip->type == T_DIR) {
    80203c38:	04495703          	lhu	a4,68(s2)
    80203c3c:	4785                	li	a5,1
    80203c3e:	0af70763          	beq	a4,a5,80203cec <sys_unlink+0x186>
    iunlockput(dp);
    80203c42:	8526                	mv	a0,s1
    80203c44:	00002097          	auipc	ra,0x2
    80203c48:	d84080e7          	jalr	-636(ra) # 802059c8 <iunlockput>
    ip->nlink--;
    80203c4c:	04a95783          	lhu	a5,74(s2)
    80203c50:	37fd                	addiw	a5,a5,-1
    80203c52:	04f91523          	sh	a5,74(s2)
    iupdate(ip);
    80203c56:	854a                	mv	a0,s2
    80203c58:	00002097          	auipc	ra,0x2
    80203c5c:	9c8080e7          	jalr	-1592(ra) # 80205620 <iupdate>
    iunlockput(ip);                   /* data freed in iput if last ref+link */
    80203c60:	854a                	mv	a0,s2
    80203c62:	00002097          	auipc	ra,0x2
    80203c66:	d66080e7          	jalr	-666(ra) # 802059c8 <iunlockput>
    return 0;
    80203c6a:	4501                	li	a0,0
    80203c6c:	64b2                	ld	s1,264(sp)
    80203c6e:	6912                	ld	s2,256(sp)
    80203c70:	a04d                	j	80203d12 <sys_unlink+0x1ac>
    80203c72:	fdce                	sd	s3,248(sp)
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203c74:	00004517          	auipc	a0,0x4
    80203c78:	cac50513          	addi	a0,a0,-852 # 80207920 <etext+0x920>
    80203c7c:	ffffd097          	auipc	ra,0xffffd
    80203c80:	976080e7          	jalr	-1674(ra) # 802005f2 <panic>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203c84:	04c92703          	lw	a4,76(s2)
    80203c88:	04000793          	li	a5,64
    80203c8c:	f6e7fde3          	bgeu	a5,a4,80203c06 <sys_unlink+0xa0>
    80203c90:	fdce                	sd	s3,248(sp)
    80203c92:	04000993          	li	s3,64
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203c96:	02000713          	li	a4,32
    80203c9a:	86ce                	mv	a3,s3
    80203c9c:	ee840613          	addi	a2,s0,-280
    80203ca0:	4581                	li	a1,0
    80203ca2:	854a                	mv	a0,s2
    80203ca4:	00002097          	auipc	ra,0x2
    80203ca8:	d76080e7          	jalr	-650(ra) # 80205a1a <readi>
    80203cac:	02000793          	li	a5,32
    80203cb0:	00f51d63          	bne	a0,a5,80203cca <sys_unlink+0x164>
        if (de.inum != 0) return 0;
    80203cb4:	ee842783          	lw	a5,-280(s0)
    80203cb8:	e7b5                	bnez	a5,80203d24 <sys_unlink+0x1be>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203cba:	0209899b          	addiw	s3,s3,32
    80203cbe:	04c92783          	lw	a5,76(s2)
    80203cc2:	fcf9eae3          	bltu	s3,a5,80203c96 <sys_unlink+0x130>
    80203cc6:	79ee                	ld	s3,248(sp)
    80203cc8:	bf3d                	j	80203c06 <sys_unlink+0xa0>
            panic("isdirempty: short read");
    80203cca:	00004517          	auipc	a0,0x4
    80203cce:	c6e50513          	addi	a0,a0,-914 # 80207938 <etext+0x938>
    80203cd2:	ffffd097          	auipc	ra,0xffffd
    80203cd6:	920080e7          	jalr	-1760(ra) # 802005f2 <panic>
    80203cda:	fdce                	sd	s3,248(sp)
        panic("unlink: writei");
    80203cdc:	00004517          	auipc	a0,0x4
    80203ce0:	c7450513          	addi	a0,a0,-908 # 80207950 <etext+0x950>
    80203ce4:	ffffd097          	auipc	ra,0xffffd
    80203ce8:	90e080e7          	jalr	-1778(ra) # 802005f2 <panic>
        dp->nlink--;                  /* the child's ".." no longer counts */
    80203cec:	04a4d783          	lhu	a5,74(s1)
    80203cf0:	37fd                	addiw	a5,a5,-1
    80203cf2:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80203cf6:	8526                	mv	a0,s1
    80203cf8:	00002097          	auipc	ra,0x2
    80203cfc:	928080e7          	jalr	-1752(ra) # 80205620 <iupdate>
    80203d00:	b789                	j	80203c42 <sys_unlink+0xdc>
    80203d02:	6912                	ld	s2,256(sp)
    iunlockput(dp);
    80203d04:	8526                	mv	a0,s1
    80203d06:	00002097          	auipc	ra,0x2
    80203d0a:	cc2080e7          	jalr	-830(ra) # 802059c8 <iunlockput>
    return -1;
    80203d0e:	557d                	li	a0,-1
    80203d10:	64b2                	ld	s1,264(sp)
}
    80203d12:	60f2                	ld	ra,280(sp)
    80203d14:	6452                	ld	s0,272(sp)
    80203d16:	6115                	addi	sp,sp,288
    80203d18:	8082                	ret
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203d1a:	557d                	li	a0,-1
    80203d1c:	bfdd                	j	80203d12 <sys_unlink+0x1ac>
    if (dp == 0) return -1;
    80203d1e:	557d                	li	a0,-1
    80203d20:	64b2                	ld	s1,264(sp)
    80203d22:	bfc5                	j	80203d12 <sys_unlink+0x1ac>
        iunlockput(ip);
    80203d24:	854a                	mv	a0,s2
    80203d26:	00002097          	auipc	ra,0x2
    80203d2a:	ca2080e7          	jalr	-862(ra) # 802059c8 <iunlockput>
        goto bad;
    80203d2e:	6912                	ld	s2,256(sp)
    80203d30:	79ee                	ld	s3,248(sp)
    80203d32:	bfc9                	j	80203d04 <sys_unlink+0x19e>

0000000080203d34 <sys_open>:

uint64 sys_open(void)
{
    80203d34:	7131                	addi	sp,sp,-192
    80203d36:	fd06                	sd	ra,184(sp)
    80203d38:	f922                	sd	s0,176(sp)
    80203d3a:	0180                	addi	s0,sp,192
    char path[MAXPATH];
    int omode;
    argint(1, &omode);
    80203d3c:	f4c40593          	addi	a1,s0,-180
    80203d40:	4505                	li	a0,1
    80203d42:	fffff097          	auipc	ra,0xfffff
    80203d46:	58a080e7          	jalr	1418(ra) # 802032cc <argint>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203d4a:	08000613          	li	a2,128
    80203d4e:	f5040593          	addi	a1,s0,-176
    80203d52:	4501                	li	a0,0
    80203d54:	00000097          	auipc	ra,0x0
    80203d58:	83a080e7          	jalr	-1990(ra) # 8020358e <argstr>
    80203d5c:	12054b63          	bltz	a0,80203e92 <sys_open+0x15e>
    80203d60:	f526                	sd	s1,168(sp)

    struct inode *ip;
    if (omode & O_CREATE) {
    80203d62:	f4c42783          	lw	a5,-180(s0)
    80203d66:	2007f793          	andi	a5,a5,512
    80203d6a:	c7c5                	beqz	a5,80203e12 <sys_open+0xde>
        ip = create(path, T_FILE, 0, 0);
    80203d6c:	4681                	li	a3,0
    80203d6e:	4601                	li	a2,0
    80203d70:	4589                	li	a1,2
    80203d72:	f5040513          	addi	a0,s0,-176
    80203d76:	00000097          	auipc	ra,0x0
    80203d7a:	990080e7          	jalr	-1648(ra) # 80203706 <create>
    80203d7e:	84aa                	mv	s1,a0
        if (ip == 0) return -1;
    80203d80:	10050b63          	beqz	a0,80203e96 <sys_open+0x162>
        if (ip->type == T_DIR && omode != O_RDONLY) {
            iunlockput(ip);
            return -1;
        }
    }
    if (ip->type == T_DEV && (ip->major < 0 || ip->major >= NDEV)) {
    80203d84:	0444d703          	lhu	a4,68(s1)
    80203d88:	478d                	li	a5,3
    80203d8a:	00f71763          	bne	a4,a5,80203d98 <sys_open+0x64>
    80203d8e:	0464d703          	lhu	a4,70(s1)
    80203d92:	47a5                	li	a5,9
    80203d94:	0ae7eb63          	bltu	a5,a4,80203e4a <sys_open+0x116>
    80203d98:	f14a                	sd	s2,160(sp)
        iunlockput(ip);
        return -1;
    }

    struct file *f = filealloc();
    80203d9a:	00002097          	auipc	ra,0x2
    80203d9e:	248080e7          	jalr	584(ra) # 80205fe2 <filealloc>
    80203da2:	892a                	mv	s2,a0
    int fd;
    if (f == 0 || (fd = fdalloc(f)) < 0) {
    80203da4:	c169                	beqz	a0,80203e66 <sys_open+0x132>
    80203da6:	ed4e                	sd	s3,152(sp)
    80203da8:	00000097          	auipc	ra,0x0
    80203dac:	91c080e7          	jalr	-1764(ra) # 802036c4 <fdalloc>
    80203db0:	89aa                	mv	s3,a0
    80203db2:	0a054463          	bltz	a0,80203e5a <sys_open+0x126>
        if (f) fileclose(f);
        iunlockput(ip);
        return -1;
    }

    if (ip->type == T_DEV) {
    80203db6:	0444d703          	lhu	a4,68(s1)
    80203dba:	478d                	li	a5,3
    80203dbc:	0af70e63          	beq	a4,a5,80203e78 <sys_open+0x144>
        f->type  = FD_DEVICE;
        f->major = ip->major;
    } else {
        f->type = FD_INODE;
    80203dc0:	4789                	li	a5,2
    80203dc2:	00f92023          	sw	a5,0(s2)
        f->off  = 0;
    80203dc6:	02092023          	sw	zero,32(s2)
    }
    f->ip       = ip;
    80203dca:	00993c23          	sd	s1,24(s2)
    f->readable = !(omode & O_WRONLY);
    80203dce:	f4c42783          	lw	a5,-180(s0)
    80203dd2:	0017c713          	xori	a4,a5,1
    80203dd6:	8b05                	andi	a4,a4,1
    80203dd8:	00e90423          	sb	a4,8(s2)
    f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80203ddc:	0037f713          	andi	a4,a5,3
    80203de0:	00e03733          	snez	a4,a4
    80203de4:	00e904a3          	sb	a4,9(s2)

    if ((omode & O_TRUNC) && ip->type == T_FILE)
    80203de8:	4007f793          	andi	a5,a5,1024
    80203dec:	c791                	beqz	a5,80203df8 <sys_open+0xc4>
    80203dee:	0444d703          	lhu	a4,68(s1)
    80203df2:	4789                	li	a5,2
    80203df4:	08f70963          	beq	a4,a5,80203e86 <sys_open+0x152>
        itrunc(ip);

    iunlock(ip);
    80203df8:	8526                	mv	a0,s1
    80203dfa:	00002097          	auipc	ra,0x2
    80203dfe:	9b8080e7          	jalr	-1608(ra) # 802057b2 <iunlock>
    return fd;
    80203e02:	854e                	mv	a0,s3
    80203e04:	74aa                	ld	s1,168(sp)
    80203e06:	790a                	ld	s2,160(sp)
    80203e08:	69ea                	ld	s3,152(sp)
}
    80203e0a:	70ea                	ld	ra,184(sp)
    80203e0c:	744a                	ld	s0,176(sp)
    80203e0e:	6129                	addi	sp,sp,192
    80203e10:	8082                	ret
        if ((ip = namei(path)) == 0) return -1;
    80203e12:	f5040513          	addi	a0,s0,-176
    80203e16:	00002097          	auipc	ra,0x2
    80203e1a:	16a080e7          	jalr	362(ra) # 80205f80 <namei>
    80203e1e:	84aa                	mv	s1,a0
    80203e20:	cd35                	beqz	a0,80203e9c <sys_open+0x168>
        ilock(ip);
    80203e22:	00002097          	auipc	ra,0x2
    80203e26:	8ca080e7          	jalr	-1846(ra) # 802056ec <ilock>
        if (ip->type == T_DIR && omode != O_RDONLY) {
    80203e2a:	0444d703          	lhu	a4,68(s1)
    80203e2e:	4785                	li	a5,1
    80203e30:	f4f71ae3          	bne	a4,a5,80203d84 <sys_open+0x50>
    80203e34:	f4c42783          	lw	a5,-180(s0)
    80203e38:	d3a5                	beqz	a5,80203d98 <sys_open+0x64>
            iunlockput(ip);
    80203e3a:	8526                	mv	a0,s1
    80203e3c:	00002097          	auipc	ra,0x2
    80203e40:	b8c080e7          	jalr	-1140(ra) # 802059c8 <iunlockput>
            return -1;
    80203e44:	557d                	li	a0,-1
    80203e46:	74aa                	ld	s1,168(sp)
    80203e48:	b7c9                	j	80203e0a <sys_open+0xd6>
        iunlockput(ip);
    80203e4a:	8526                	mv	a0,s1
    80203e4c:	00002097          	auipc	ra,0x2
    80203e50:	b7c080e7          	jalr	-1156(ra) # 802059c8 <iunlockput>
        return -1;
    80203e54:	557d                	li	a0,-1
    80203e56:	74aa                	ld	s1,168(sp)
    80203e58:	bf4d                	j	80203e0a <sys_open+0xd6>
        if (f) fileclose(f);
    80203e5a:	854a                	mv	a0,s2
    80203e5c:	00002097          	auipc	ra,0x2
    80203e60:	242080e7          	jalr	578(ra) # 8020609e <fileclose>
    80203e64:	69ea                	ld	s3,152(sp)
        iunlockput(ip);
    80203e66:	8526                	mv	a0,s1
    80203e68:	00002097          	auipc	ra,0x2
    80203e6c:	b60080e7          	jalr	-1184(ra) # 802059c8 <iunlockput>
        return -1;
    80203e70:	557d                	li	a0,-1
    80203e72:	74aa                	ld	s1,168(sp)
    80203e74:	790a                	ld	s2,160(sp)
    80203e76:	bf51                	j	80203e0a <sys_open+0xd6>
        f->type  = FD_DEVICE;
    80203e78:	00f92023          	sw	a5,0(s2)
        f->major = ip->major;
    80203e7c:	0464d783          	lhu	a5,70(s1)
    80203e80:	02f91223          	sh	a5,36(s2)
    80203e84:	b799                	j	80203dca <sys_open+0x96>
        itrunc(ip);
    80203e86:	8526                	mv	a0,s1
    80203e88:	00002097          	auipc	ra,0x2
    80203e8c:	976080e7          	jalr	-1674(ra) # 802057fe <itrunc>
    80203e90:	b7a5                	j	80203df8 <sys_open+0xc4>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203e92:	557d                	li	a0,-1
    80203e94:	bf9d                	j	80203e0a <sys_open+0xd6>
        if (ip == 0) return -1;
    80203e96:	557d                	li	a0,-1
    80203e98:	74aa                	ld	s1,168(sp)
    80203e9a:	bf85                	j	80203e0a <sys_open+0xd6>
        if ((ip = namei(path)) == 0) return -1;
    80203e9c:	557d                	li	a0,-1
    80203e9e:	74aa                	ld	s1,168(sp)
    80203ea0:	b7ad                	j	80203e0a <sys_open+0xd6>

0000000080203ea2 <sys_mkdir>:

uint64 sys_mkdir(void)
{
    80203ea2:	7175                	addi	sp,sp,-144
    80203ea4:	e506                	sd	ra,136(sp)
    80203ea6:	e122                	sd	s0,128(sp)
    80203ea8:	0900                	addi	s0,sp,144
    char path[MAXPATH];
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203eaa:	08000613          	li	a2,128
    80203eae:	f7040593          	addi	a1,s0,-144
    80203eb2:	4501                	li	a0,0
    80203eb4:	fffff097          	auipc	ra,0xfffff
    80203eb8:	6da080e7          	jalr	1754(ra) # 8020358e <argstr>
    80203ebc:	57fd                	li	a5,-1
    80203ebe:	02054163          	bltz	a0,80203ee0 <sys_mkdir+0x3e>
    struct inode *ip = create(path, T_DIR, 0, 0);
    80203ec2:	4681                	li	a3,0
    80203ec4:	4601                	li	a2,0
    80203ec6:	4585                	li	a1,1
    80203ec8:	f7040513          	addi	a0,s0,-144
    80203ecc:	00000097          	auipc	ra,0x0
    80203ed0:	83a080e7          	jalr	-1990(ra) # 80203706 <create>
    if (ip == 0) return -1;
    80203ed4:	c919                	beqz	a0,80203eea <sys_mkdir+0x48>
    iunlockput(ip);
    80203ed6:	00002097          	auipc	ra,0x2
    80203eda:	af2080e7          	jalr	-1294(ra) # 802059c8 <iunlockput>
    return 0;
    80203ede:	4781                	li	a5,0
}
    80203ee0:	853e                	mv	a0,a5
    80203ee2:	60aa                	ld	ra,136(sp)
    80203ee4:	640a                	ld	s0,128(sp)
    80203ee6:	6149                	addi	sp,sp,144
    80203ee8:	8082                	ret
    if (ip == 0) return -1;
    80203eea:	57fd                	li	a5,-1
    80203eec:	bfd5                	j	80203ee0 <sys_mkdir+0x3e>

0000000080203eee <sys_chdir>:

uint64 sys_chdir(void)
{
    80203eee:	7135                	addi	sp,sp,-160
    80203ef0:	ed06                	sd	ra,152(sp)
    80203ef2:	e922                	sd	s0,144(sp)
    80203ef4:	e14a                	sd	s2,128(sp)
    80203ef6:	1100                	addi	s0,sp,160
    char path[MAXPATH];
    struct proc *p = myproc();
    80203ef8:	ffffe097          	auipc	ra,0xffffe
    80203efc:	86e080e7          	jalr	-1938(ra) # 80201766 <myproc>
    80203f00:	892a                	mv	s2,a0
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203f02:	08000613          	li	a2,128
    80203f06:	f6040593          	addi	a1,s0,-160
    80203f0a:	4501                	li	a0,0
    80203f0c:	fffff097          	auipc	ra,0xfffff
    80203f10:	682080e7          	jalr	1666(ra) # 8020358e <argstr>
    80203f14:	57fd                	li	a5,-1
    80203f16:	04054363          	bltz	a0,80203f5c <sys_chdir+0x6e>
    80203f1a:	e526                	sd	s1,136(sp)
    struct inode *ip = namei(path);
    80203f1c:	f6040513          	addi	a0,s0,-160
    80203f20:	00002097          	auipc	ra,0x2
    80203f24:	060080e7          	jalr	96(ra) # 80205f80 <namei>
    80203f28:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80203f2a:	c539                	beqz	a0,80203f78 <sys_chdir+0x8a>
    ilock(ip);
    80203f2c:	00001097          	auipc	ra,0x1
    80203f30:	7c0080e7          	jalr	1984(ra) # 802056ec <ilock>
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203f34:	0444d703          	lhu	a4,68(s1)
    80203f38:	4785                	li	a5,1
    80203f3a:	02f71763          	bne	a4,a5,80203f68 <sys_chdir+0x7a>
    iunlock(ip);
    80203f3e:	8526                	mv	a0,s1
    80203f40:	00002097          	auipc	ra,0x2
    80203f44:	872080e7          	jalr	-1934(ra) # 802057b2 <iunlock>
    iput(p->cwd);
    80203f48:	15093503          	ld	a0,336(s2)
    80203f4c:	00002097          	auipc	ra,0x2
    80203f50:	95e080e7          	jalr	-1698(ra) # 802058aa <iput>
    p->cwd = ip;
    80203f54:	14993823          	sd	s1,336(s2)
    return 0;
    80203f58:	4781                	li	a5,0
    80203f5a:	64aa                	ld	s1,136(sp)
}
    80203f5c:	853e                	mv	a0,a5
    80203f5e:	60ea                	ld	ra,152(sp)
    80203f60:	644a                	ld	s0,144(sp)
    80203f62:	690a                	ld	s2,128(sp)
    80203f64:	610d                	addi	sp,sp,160
    80203f66:	8082                	ret
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203f68:	8526                	mv	a0,s1
    80203f6a:	00002097          	auipc	ra,0x2
    80203f6e:	a5e080e7          	jalr	-1442(ra) # 802059c8 <iunlockput>
    80203f72:	57fd                	li	a5,-1
    80203f74:	64aa                	ld	s1,136(sp)
    80203f76:	b7dd                	j	80203f5c <sys_chdir+0x6e>
    if (ip == 0) return -1;
    80203f78:	57fd                	li	a5,-1
    80203f7a:	64aa                	ld	s1,136(sp)
    80203f7c:	b7c5                	j	80203f5c <sys_chdir+0x6e>

0000000080203f7e <sys_pipe>:

uint64 sys_pipe(void)
{
    80203f7e:	7139                	addi	sp,sp,-64
    80203f80:	fc06                	sd	ra,56(sp)
    80203f82:	f822                	sd	s0,48(sp)
    80203f84:	0080                	addi	s0,sp,64
    uint64 fdarray;                   /* user pointer to int[2] */
    argaddr(0, &fdarray);
    80203f86:	fd840593          	addi	a1,s0,-40
    80203f8a:	4501                	li	a0,0
    80203f8c:	fffff097          	auipc	ra,0xfffff
    80203f90:	49a080e7          	jalr	1178(ra) # 80203426 <argaddr>

    struct file *rf, *wf;
    if (pipealloc(&rf, &wf) < 0) return -1;
    80203f94:	fc840593          	addi	a1,s0,-56
    80203f98:	fd040513          	addi	a0,s0,-48
    80203f9c:	00002097          	auipc	ra,0x2
    80203fa0:	3f2080e7          	jalr	1010(ra) # 8020638e <pipealloc>
    80203fa4:	57fd                	li	a5,-1
    80203fa6:	0a054463          	bltz	a0,8020404e <sys_pipe+0xd0>
    80203faa:	f426                	sd	s1,40(sp)

    struct proc *p = myproc();
    80203fac:	ffffd097          	auipc	ra,0xffffd
    80203fb0:	7ba080e7          	jalr	1978(ra) # 80201766 <myproc>
    80203fb4:	84aa                	mv	s1,a0
    int fd0 = -1, fd1 = -1;
    80203fb6:	57fd                	li	a5,-1
    80203fb8:	fcf42223          	sw	a5,-60(s0)
    80203fbc:	fcf42023          	sw	a5,-64(s0)
    if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80203fc0:	fd043503          	ld	a0,-48(s0)
    80203fc4:	fffff097          	auipc	ra,0xfffff
    80203fc8:	700080e7          	jalr	1792(ra) # 802036c4 <fdalloc>
    80203fcc:	fca42223          	sw	a0,-60(s0)
    80203fd0:	06054163          	bltz	a0,80204032 <sys_pipe+0xb4>
    80203fd4:	fc843503          	ld	a0,-56(s0)
    80203fd8:	fffff097          	auipc	ra,0xfffff
    80203fdc:	6ec080e7          	jalr	1772(ra) # 802036c4 <fdalloc>
    80203fe0:	fca42023          	sw	a0,-64(s0)
    80203fe4:	02054e63          	bltz	a0,80204020 <sys_pipe+0xa2>
        if (fd0 >= 0) p->ofile[fd0] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80203fe8:	4691                	li	a3,4
    80203fea:	fc440613          	addi	a2,s0,-60
    80203fee:	fd843583          	ld	a1,-40(s0)
    80203ff2:	68a8                	ld	a0,80(s1)
    80203ff4:	fffff097          	auipc	ra,0xfffff
    80203ff8:	f8a080e7          	jalr	-118(ra) # 80202f7e <copyout>
    80203ffc:	04054e63          	bltz	a0,80204058 <sys_pipe+0xda>
        copyout(p->pagetable, fdarray + sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0) {
    80204000:	4691                	li	a3,4
    80204002:	fc040613          	addi	a2,s0,-64
    80204006:	fd843583          	ld	a1,-40(s0)
    8020400a:	0591                	addi	a1,a1,4
    8020400c:	68a8                	ld	a0,80(s1)
    8020400e:	fffff097          	auipc	ra,0xfffff
    80204012:	f70080e7          	jalr	-144(ra) # 80202f7e <copyout>
        p->ofile[fd1] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    return 0;
    80204016:	4781                	li	a5,0
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80204018:	04054063          	bltz	a0,80204058 <sys_pipe+0xda>
    8020401c:	74a2                	ld	s1,40(sp)
    8020401e:	a805                	j	8020404e <sys_pipe+0xd0>
        if (fd0 >= 0) p->ofile[fd0] = 0;
    80204020:	fc442783          	lw	a5,-60(s0)
    80204024:	0007c763          	bltz	a5,80204032 <sys_pipe+0xb4>
    80204028:	07e9                	addi	a5,a5,26
    8020402a:	078e                	slli	a5,a5,0x3
    8020402c:	97a6                	add	a5,a5,s1
    8020402e:	0007b023          	sd	zero,0(a5)
        fileclose(rf);
    80204032:	fd043503          	ld	a0,-48(s0)
    80204036:	00002097          	auipc	ra,0x2
    8020403a:	068080e7          	jalr	104(ra) # 8020609e <fileclose>
        fileclose(wf);
    8020403e:	fc843503          	ld	a0,-56(s0)
    80204042:	00002097          	auipc	ra,0x2
    80204046:	05c080e7          	jalr	92(ra) # 8020609e <fileclose>
        return -1;
    8020404a:	57fd                	li	a5,-1
    8020404c:	74a2                	ld	s1,40(sp)
}
    8020404e:	853e                	mv	a0,a5
    80204050:	70e2                	ld	ra,56(sp)
    80204052:	7442                	ld	s0,48(sp)
    80204054:	6121                	addi	sp,sp,64
    80204056:	8082                	ret
        p->ofile[fd0] = 0;
    80204058:	fc442783          	lw	a5,-60(s0)
    8020405c:	07e9                	addi	a5,a5,26
    8020405e:	078e                	slli	a5,a5,0x3
    80204060:	97a6                	add	a5,a5,s1
    80204062:	0007b023          	sd	zero,0(a5)
        p->ofile[fd1] = 0;
    80204066:	fc042783          	lw	a5,-64(s0)
    8020406a:	07e9                	addi	a5,a5,26
    8020406c:	078e                	slli	a5,a5,0x3
    8020406e:	94be                	add	s1,s1,a5
    80204070:	0004b023          	sd	zero,0(s1)
        fileclose(rf);
    80204074:	fd043503          	ld	a0,-48(s0)
    80204078:	00002097          	auipc	ra,0x2
    8020407c:	026080e7          	jalr	38(ra) # 8020609e <fileclose>
        fileclose(wf);
    80204080:	fc843503          	ld	a0,-56(s0)
    80204084:	00002097          	auipc	ra,0x2
    80204088:	01a080e7          	jalr	26(ra) # 8020609e <fileclose>
        return -1;
    8020408c:	57fd                	li	a5,-1
    8020408e:	74a2                	ld	s1,40(sp)
    80204090:	bf7d                	j	8020404e <sys_pipe+0xd0>

0000000080204092 <sys_exec>:

uint64 sys_exec(void)
{
    80204092:	7129                	addi	sp,sp,-320
    80204094:	fe06                	sd	ra,312(sp)
    80204096:	fa22                	sd	s0,304(sp)
    80204098:	0280                	addi	s0,sp,320
    char path[MAXPATH];
    uint64 uargv, uarg;
    char *argv[MAXARG];

    if (argstr(0, path, MAXPATH) < 0) return -1;
    8020409a:	08000613          	li	a2,128
    8020409e:	f5040593          	addi	a1,s0,-176
    802040a2:	4501                	li	a0,0
    802040a4:	fffff097          	auipc	ra,0xfffff
    802040a8:	4ea080e7          	jalr	1258(ra) # 8020358e <argstr>
    802040ac:	87aa                	mv	a5,a0
    802040ae:	557d                	li	a0,-1
    802040b0:	0a07c763          	bltz	a5,8020415e <sys_exec+0xcc>
    802040b4:	f626                	sd	s1,296(sp)
    802040b6:	f24a                	sd	s2,288(sp)
    802040b8:	ee4e                	sd	s3,280(sp)
    802040ba:	ea52                	sd	s4,272(sp)
    argaddr(1, &uargv);
    802040bc:	f4840593          	addi	a1,s0,-184
    802040c0:	4505                	li	a0,1
    802040c2:	fffff097          	auipc	ra,0xfffff
    802040c6:	364080e7          	jalr	868(ra) # 80203426 <argaddr>
    memset(argv, 0, sizeof(argv));
    802040ca:	08000613          	li	a2,128
    802040ce:	4581                	li	a1,0
    802040d0:	ec040513          	addi	a0,s0,-320
    802040d4:	ffffc097          	auipc	ra,0xffffc
    802040d8:	5c4080e7          	jalr	1476(ra) # 80200698 <memset>

    int ret = -1;
    for (int i = 0; ; i++) {
        if (i >= MAXARG) goto out;
    802040dc:	ec040493          	addi	s1,s0,-320
    memset(argv, 0, sizeof(argv));
    802040e0:	89a6                	mv	s3,s1
    802040e2:	4901                	li	s2,0
        if (i >= MAXARG) goto out;
    802040e4:	4a41                	li	s4,16
        if (copyin(myproc()->pagetable, (char *)&uarg,
    802040e6:	ffffd097          	auipc	ra,0xffffd
    802040ea:	680080e7          	jalr	1664(ra) # 80201766 <myproc>
    802040ee:	00391613          	slli	a2,s2,0x3
    802040f2:	46a1                	li	a3,8
    802040f4:	f4843783          	ld	a5,-184(s0)
    802040f8:	963e                	add	a2,a2,a5
    802040fa:	f4040593          	addi	a1,s0,-192
    802040fe:	6928                	ld	a0,80(a0)
    80204100:	fffff097          	auipc	ra,0xfffff
    80204104:	f72080e7          	jalr	-142(ra) # 80203072 <copyin>
    80204108:	08054163          	bltz	a0,8020418a <sys_exec+0xf8>
                   uargv + sizeof(uint64) * i, sizeof(uint64)) < 0) goto out;
        if (uarg == 0) { argv[i] = 0; break; }
    8020410c:	f4043783          	ld	a5,-192(s0)
    80204110:	cbb9                	beqz	a5,80204166 <sys_exec+0xd4>
        argv[i] = palloc();
    80204112:	ffffd097          	auipc	ra,0xffffd
    80204116:	f88080e7          	jalr	-120(ra) # 8020109a <palloc>
    8020411a:	85aa                	mv	a1,a0
    8020411c:	00a9b023          	sd	a0,0(s3)
        if (!argv[i]) goto out;
    80204120:	c53d                	beqz	a0,8020418e <sys_exec+0xfc>
        if (fetchstr(uarg, argv[i], PGSIZE) < 0) goto out;
    80204122:	6605                	lui	a2,0x1
    80204124:	f4043503          	ld	a0,-192(s0)
    80204128:	fffff097          	auipc	ra,0xfffff
    8020412c:	41a080e7          	jalr	1050(ra) # 80203542 <fetchstr>
    80204130:	06054163          	bltz	a0,80204192 <sys_exec+0x100>
        if (i >= MAXARG) goto out;
    80204134:	0905                	addi	s2,s2,1
    80204136:	09a1                	addi	s3,s3,8
    80204138:	fb4917e3          	bne	s2,s4,802040e6 <sys_exec+0x54>
    int ret = -1;
    8020413c:	59fd                	li	s3,-1
    }
    ret = exec(path, argv);
out:
    /* Free EVERY page we allocated, on every path - the original version of
     * this function leaked argv pages on a bad pointer. Found in the audit. */
    for (int i = 0; i < MAXARG && argv[i]; i++) pfree(argv[i]);
    8020413e:	f4040913          	addi	s2,s0,-192
    80204142:	6088                	ld	a0,0(s1)
    80204144:	c901                	beqz	a0,80204154 <sys_exec+0xc2>
    80204146:	ffffd097          	auipc	ra,0xffffd
    8020414a:	064080e7          	jalr	100(ra) # 802011aa <pfree>
    8020414e:	04a1                	addi	s1,s1,8
    80204150:	ff2499e3          	bne	s1,s2,80204142 <sys_exec+0xb0>
    return ret;
    80204154:	854e                	mv	a0,s3
    80204156:	74b2                	ld	s1,296(sp)
    80204158:	7912                	ld	s2,288(sp)
    8020415a:	69f2                	ld	s3,280(sp)
    8020415c:	6a52                	ld	s4,272(sp)
}
    8020415e:	70f2                	ld	ra,312(sp)
    80204160:	7452                	ld	s0,304(sp)
    80204162:	6131                	addi	sp,sp,320
    80204164:	8082                	ret
        if (uarg == 0) { argv[i] = 0; break; }
    80204166:	0009079b          	sext.w	a5,s2
    8020416a:	078e                	slli	a5,a5,0x3
    8020416c:	fd078793          	addi	a5,a5,-48
    80204170:	97a2                	add	a5,a5,s0
    80204172:	ee07b823          	sd	zero,-272(a5)
    ret = exec(path, argv);
    80204176:	ec040593          	addi	a1,s0,-320
    8020417a:	f5040513          	addi	a0,s0,-176
    8020417e:	00001097          	auipc	ra,0x1
    80204182:	8b0080e7          	jalr	-1872(ra) # 80204a2e <exec>
    80204186:	89aa                	mv	s3,a0
    80204188:	bf5d                	j	8020413e <sys_exec+0xac>
    int ret = -1;
    8020418a:	59fd                	li	s3,-1
    8020418c:	bf4d                	j	8020413e <sys_exec+0xac>
    8020418e:	59fd                	li	s3,-1
    80204190:	b77d                	j	8020413e <sys_exec+0xac>
    80204192:	59fd                	li	s3,-1
    80204194:	b76d                	j	8020413e <sys_exec+0xac>

0000000080204196 <trace_init>:
    uint32 head, count, dropped;
};
static struct trace_ring rings[NCPU];

void trace_init(void)
{
    80204196:	7139                	addi	sp,sp,-64
    80204198:	fc06                	sd	ra,56(sp)
    8020419a:	f822                	sd	s0,48(sp)
    8020419c:	f426                	sd	s1,40(sp)
    8020419e:	f04a                	sd	s2,32(sp)
    802041a0:	ec4e                	sd	s3,24(sp)
    802041a2:	e852                	sd	s4,16(sp)
    802041a4:	e456                	sd	s5,8(sp)
    802041a6:	0080                	addi	s0,sp,64
    for (int i = 0; i < NCPU; i++) {
    802041a8:	0012e497          	auipc	s1,0x12e
    802041ac:	68848493          	addi	s1,s1,1672 # 80332830 <rings+0x1418>
    802041b0:	00138a97          	auipc	s5,0x138
    802041b4:	7c0a8a93          	addi	s5,s5,1984 # 8033c970 <bcache+0x1370>
        initlock(&rings[i].lock, "trace");
    802041b8:	79fd                	lui	s3,0xfffff
    802041ba:	be898993          	addi	s3,s3,-1048 # ffffffffffffebe8 <uart+0xffffffff7fcb4bb8>
    802041be:	00003a17          	auipc	s4,0x3
    802041c2:	7a2a0a13          	addi	s4,s4,1954 # 80207960 <etext+0x960>
    for (int i = 0; i < NCPU; i++) {
    802041c6:	6905                	lui	s2,0x1
    802041c8:	42890913          	addi	s2,s2,1064 # 1428 <_entry-0x801febd8>
        initlock(&rings[i].lock, "trace");
    802041cc:	85d2                	mv	a1,s4
    802041ce:	01348533          	add	a0,s1,s3
    802041d2:	ffffd097          	auipc	ra,0xffffd
    802041d6:	0da080e7          	jalr	218(ra) # 802012ac <initlock>
        rings[i].head = rings[i].count = rings[i].dropped = 0;
    802041da:	0004a423          	sw	zero,8(s1)
    802041de:	0004a223          	sw	zero,4(s1)
    802041e2:	0004a023          	sw	zero,0(s1)
    for (int i = 0; i < NCPU; i++) {
    802041e6:	94ca                	add	s1,s1,s2
    802041e8:	ff5492e3          	bne	s1,s5,802041cc <trace_init+0x36>
    }
}
    802041ec:	70e2                	ld	ra,56(sp)
    802041ee:	7442                	ld	s0,48(sp)
    802041f0:	74a2                	ld	s1,40(sp)
    802041f2:	7902                	ld	s2,32(sp)
    802041f4:	69e2                	ld	s3,24(sp)
    802041f6:	6a42                	ld	s4,16(sp)
    802041f8:	6aa2                	ld	s5,8(sp)
    802041fa:	6121                	addi	sp,sp,64
    802041fc:	8082                	ret

00000000802041fe <trace_record>:

void trace_record(int num, long ret, uint64 arg0)
{
    802041fe:	7139                	addi	sp,sp,-64
    80204200:	fc06                	sd	ra,56(sp)
    80204202:	f822                	sd	s0,48(sp)
    80204204:	f04a                	sd	s2,32(sp)
    80204206:	ec4e                	sd	s3,24(sp)
    80204208:	e852                	sd	s4,16(sp)
    8020420a:	0080                	addi	s0,sp,64
    8020420c:	892a                	mv	s2,a0
    8020420e:	8a2e                	mv	s4,a1
    80204210:	89b2                	mv	s3,a2
    struct proc *p = myproc();
    80204212:	ffffd097          	auipc	ra,0xffffd
    80204216:	554080e7          	jalr	1364(ra) # 80201766 <myproc>
    if (p == 0 || p->trace_filter == 0) return;
    8020421a:	cd65                	beqz	a0,80204312 <trace_record+0x114>
    8020421c:	f426                	sd	s1,40(sp)
    8020421e:	84aa                	mv	s1,a0
    80204220:	16853783          	ld	a5,360(a0)
    80204224:	10078663          	beqz	a5,80204330 <trace_record+0x132>
    if (!(p->trace_filter & (1UL << 63)) &&
    80204228:	0007ca63          	bltz	a5,8020423c <trace_record+0x3e>
    8020422c:	03e00713          	li	a4,62
    80204230:	11274263          	blt	a4,s2,80204334 <trace_record+0x136>
        (num >= 63 || !(p->trace_filter & (1UL << num)))) return;
    80204234:	0127d7b3          	srl	a5,a5,s2
    80204238:	8b85                	andi	a5,a5,1
    8020423a:	cffd                	beqz	a5,80204338 <trace_record+0x13a>
    8020423c:	e456                	sd	s5,8(sp)
    8020423e:	e05a                	sd	s6,0(sp)

    int h = hal_hart_id();
    80204240:	00002097          	auipc	ra,0x2
    80204244:	56e080e7          	jalr	1390(ra) # 802067ae <hal_hart_id>
    80204248:	8b2a                	mv	s6,a0
    struct trace_ring *r = &rings[h];
    acquire(&r->lock);
    8020424a:	6a85                	lui	s5,0x1
    8020424c:	428a8a93          	addi	s5,s5,1064 # 1428 <_entry-0x801febd8>
    80204250:	03550ab3          	mul	s5,a0,s5
    80204254:	0012d797          	auipc	a5,0x12d
    80204258:	1c478793          	addi	a5,a5,452 # 80331418 <rings>
    8020425c:	9abe                	add	s5,s5,a5
    8020425e:	8556                	mv	a0,s5
    80204260:	ffffd097          	auipc	ra,0xffffd
    80204264:	0c8080e7          	jalr	200(ra) # 80201328 <acquire>
    if (r->count == NTRACE) {
    80204268:	6785                	lui	a5,0x1
    8020426a:	97d6                	add	a5,a5,s5
    8020426c:	41c7a803          	lw	a6,1052(a5) # 141c <_entry-0x801febe4>
    80204270:	08000793          	li	a5,128
    80204274:	0af80663          	beq	a6,a5,80204320 <trace_record+0x122>
        r->dropped++;
    } else {
        struct trace_event *e = &r->ev[r->head];
    80204278:	0012d697          	auipc	a3,0x12d
    8020427c:	1a068693          	addi	a3,a3,416 # 80331418 <rings>
    80204280:	6705                	lui	a4,0x1
    80204282:	42870713          	addi	a4,a4,1064 # 1428 <_entry-0x801febd8>
    80204286:	02eb0733          	mul	a4,s6,a4
    8020428a:	00e687b3          	add	a5,a3,a4
    8020428e:	6885                	lui	a7,0x1
    80204290:	98be                	add	a7,a7,a5
    80204292:	4188a503          	lw	a0,1048(a7) # 1418 <_entry-0x801febe8>
        e->pid = p->pid; e->hart = h; e->num = num;
    80204296:	0304a303          	lw	t1,48(s1)
    8020429a:	02051613          	slli	a2,a0,0x20
    8020429e:	9201                	srli	a2,a2,0x20
    802042a0:	00261793          	slli	a5,a2,0x2
    802042a4:	00c785b3          	add	a1,a5,a2
    802042a8:	058e                	slli	a1,a1,0x3
    802042aa:	95ba                	add	a1,a1,a4
    802042ac:	95b6                	add	a1,a1,a3
    802042ae:	0065ac23          	sw	t1,24(a1)
    802042b2:	00c785b3          	add	a1,a5,a2
    802042b6:	058e                	slli	a1,a1,0x3
    802042b8:	95ba                	add	a1,a1,a4
    802042ba:	95b6                	add	a1,a1,a3
    802042bc:	0165ae23          	sw	s6,28(a1)
    802042c0:	00c785b3          	add	a1,a5,a2
    802042c4:	058e                	slli	a1,a1,0x3
    802042c6:	95ba                	add	a1,a1,a4
    802042c8:	95b6                	add	a1,a1,a3
    802042ca:	0325a023          	sw	s2,32(a1)
        e->ret = ret; e->ts = r_time(); e->arg0 = arg0;
    802042ce:	00c785b3          	add	a1,a5,a2
    802042d2:	058e                	slli	a1,a1,0x3
    802042d4:	95ba                	add	a1,a1,a4
    802042d6:	95b6                	add	a1,a1,a3
    802042d8:	0345b423          	sd	s4,40(a1)
static inline uint64 r_time(void){ uint64 x; asm volatile("rdtime %0":"=r"(x)); return x; }
    802042dc:	c0102373          	rdtime	t1
    802042e0:	00c785b3          	add	a1,a5,a2
    802042e4:	058e                	slli	a1,a1,0x3
    802042e6:	95ba                	add	a1,a1,a4
    802042e8:	95b6                	add	a1,a1,a3
    802042ea:	0265b823          	sd	t1,48(a1)
    802042ee:	0335bc23          	sd	s3,56(a1)
        r->head = (r->head + 1) % NTRACE;
    802042f2:	2505                	addiw	a0,a0,1
    802042f4:	07f57513          	andi	a0,a0,127
    802042f8:	40a8ac23          	sw	a0,1048(a7)
        r->count++;
    802042fc:	2805                	addiw	a6,a6,1
    802042fe:	4108ae23          	sw	a6,1052(a7)
    }
    release(&r->lock);
    80204302:	8556                	mv	a0,s5
    80204304:	ffffd097          	auipc	ra,0xffffd
    80204308:	0d8080e7          	jalr	216(ra) # 802013dc <release>
    8020430c:	74a2                	ld	s1,40(sp)
    8020430e:	6aa2                	ld	s5,8(sp)
    80204310:	6b02                	ld	s6,0(sp)
}
    80204312:	70e2                	ld	ra,56(sp)
    80204314:	7442                	ld	s0,48(sp)
    80204316:	7902                	ld	s2,32(sp)
    80204318:	69e2                	ld	s3,24(sp)
    8020431a:	6a42                	ld	s4,16(sp)
    8020431c:	6121                	addi	sp,sp,64
    8020431e:	8082                	ret
        r->dropped++;
    80204320:	6785                	lui	a5,0x1
    80204322:	97d6                	add	a5,a5,s5
    80204324:	4207a703          	lw	a4,1056(a5) # 1420 <_entry-0x801febe0>
    80204328:	2705                	addiw	a4,a4,1
    8020432a:	42e7a023          	sw	a4,1056(a5)
    8020432e:	bfd1                	j	80204302 <trace_record+0x104>
    80204330:	74a2                	ld	s1,40(sp)
    80204332:	b7c5                	j	80204312 <trace_record+0x114>
    80204334:	74a2                	ld	s1,40(sp)
    80204336:	bff1                	j	80204312 <trace_record+0x114>
    80204338:	74a2                	ld	s1,40(sp)
    8020433a:	bfe1                	j	80204312 <trace_record+0x114>

000000008020433c <trace_ctl>:

int trace_ctl(int action, uint64 filter)
{
    8020433c:	1101                	addi	sp,sp,-32
    8020433e:	ec06                	sd	ra,24(sp)
    80204340:	e822                	sd	s0,16(sp)
    80204342:	e426                	sd	s1,8(sp)
    80204344:	e04a                	sd	s2,0(sp)
    80204346:	1000                	addi	s0,sp,32
    80204348:	84aa                	mv	s1,a0
    8020434a:	892e                	mv	s2,a1
    struct proc *p = myproc();
    8020434c:	ffffd097          	auipc	ra,0xffffd
    80204350:	41a080e7          	jalr	1050(ra) # 80201766 <myproc>
    if (action == TRACE_DISABLE) { p->trace_filter = 0; return 0; }
    80204354:	c08d                	beqz	s1,80204376 <trace_ctl+0x3a>
    if (action == TRACE_ENABLE) {
    80204356:	4785                	li	a5,1
    80204358:	02f49363          	bne	s1,a5,8020437e <trace_ctl+0x42>
        p->trace_filter = filter ? filter : (1UL << 63);
    8020435c:	00091463          	bnez	s2,80204364 <trace_ctl+0x28>
    80204360:	597d                	li	s2,-1
    80204362:	197e                	slli	s2,s2,0x3f
    80204364:	17253423          	sd	s2,360(a0)
        return 0;
    80204368:	4501                	li	a0,0
    }
    return -1;
}
    8020436a:	60e2                	ld	ra,24(sp)
    8020436c:	6442                	ld	s0,16(sp)
    8020436e:	64a2                	ld	s1,8(sp)
    80204370:	6902                	ld	s2,0(sp)
    80204372:	6105                	addi	sp,sp,32
    80204374:	8082                	ret
    if (action == TRACE_DISABLE) { p->trace_filter = 0; return 0; }
    80204376:	16053423          	sd	zero,360(a0)
    8020437a:	8526                	mv	a0,s1
    8020437c:	b7fd                	j	8020436a <trace_ctl+0x2e>
    return -1;
    8020437e:	557d                	li	a0,-1
    80204380:	b7ed                	j	8020436a <trace_ctl+0x2e>

0000000080204382 <trace_read>:

int trace_read(uint64 ubuf, int max)
{
    80204382:	7131                	addi	sp,sp,-192
    80204384:	fd06                	sd	ra,184(sp)
    80204386:	f922                	sd	s0,176(sp)
    80204388:	ed4e                	sd	s3,152(sp)
    8020438a:	0180                	addi	s0,sp,192
    8020438c:	f4a43823          	sd	a0,-176(s0)
    if (max <= 0) return -1;
    80204390:	20b05663          	blez	a1,8020459c <trace_read+0x21a>
    80204394:	f526                	sd	s1,168(sp)
    80204396:	f14a                	sd	s2,160(sp)
    80204398:	e952                	sd	s4,144(sp)
    8020439a:	e556                	sd	s5,136(sp)
    8020439c:	e15a                	sd	s6,128(sp)
    8020439e:	fcde                	sd	s7,120(sp)
    802043a0:	f8e2                	sd	s8,112(sp)
    802043a2:	f4e6                	sd	s9,104(sp)
    802043a4:	f0ea                	sd	s10,96(sp)
    802043a6:	ecee                	sd	s11,88(sp)
    802043a8:	8b2e                	mv	s6,a1
    struct proc *p = myproc();
    802043aa:	ffffd097          	auipc	ra,0xffffd
    802043ae:	3bc080e7          	jalr	956(ra) # 80201766 <myproc>
    802043b2:	8baa                	mv	s7,a0
    int total = 0;
    for (int h = 0; h < NCPU && total < max; h++) {
    802043b4:	0012ed17          	auipc	s10,0x12e
    802043b8:	47cd0d13          	addi	s10,s10,1148 # 80332830 <rings+0x1418>
    802043bc:	f4043c23          	sd	zero,-168(s0)
    int total = 0;
    802043c0:	4981                	li	s3,0
        struct trace_ring *r = &rings[h];
        acquire(&r->lock);
    802043c2:	77fd                	lui	a5,0xfffff
    802043c4:	be878793          	addi	a5,a5,-1048 # ffffffffffffebe8 <uart+0xffffffff7fcb4bb8>
    802043c8:	f4f43423          	sd	a5,-184(s0)
        uint32 tail = (r->head + NTRACE - r->count) % NTRACE;
        while (r->count > 0 && total < max) {
            struct trace_event e = r->ev[tail];
    802043cc:	0012dc97          	auipc	s9,0x12d
    802043d0:	04cc8c93          	addi	s9,s9,76 # 80331418 <rings>
    802043d4:	6d85                	lui	s11,0x1
    802043d6:	428d8d93          	addi	s11,s11,1064 # 1428 <_entry-0x801febd8>
        acquire(&r->lock);
    802043da:	f4843783          	ld	a5,-184(s0)
    802043de:	00fd0a33          	add	s4,s10,a5
    802043e2:	8552                	mv	a0,s4
    802043e4:	ffffd097          	auipc	ra,0xffffd
    802043e8:	f44080e7          	jalr	-188(ra) # 80201328 <acquire>
        uint32 tail = (r->head + NTRACE - r->count) % NTRACE;
    802043ec:	8aea                	mv	s5,s10
    802043ee:	004d2783          	lw	a5,4(s10)
    802043f2:	000d2483          	lw	s1,0(s10)
    802043f6:	9c9d                	subw	s1,s1,a5
    802043f8:	07f4f493          	andi	s1,s1,127
        while (r->count > 0 && total < max) {
    802043fc:	10078563          	beqz	a5,80204506 <trace_read+0x184>
    80204400:	0969da63          	bge	s3,s6,80204494 <trace_read+0x112>
    80204404:	00299913          	slli	s2,s3,0x2
    80204408:	994e                	add	s2,s2,s3
    8020440a:	090e                	slli	s2,s2,0x3
    8020440c:	f5043783          	ld	a5,-176(s0)
    80204410:	993e                	add	s2,s2,a5
            struct trace_event e = r->ev[tail];
    80204412:	f5843783          	ld	a5,-168(s0)
    80204416:	03b78c33          	mul	s8,a5,s11
    8020441a:	00249793          	slli	a5,s1,0x2
    8020441e:	97a6                	add	a5,a5,s1
    80204420:	078e                	slli	a5,a5,0x3
    80204422:	97e2                	add	a5,a5,s8
    80204424:	97e6                	add	a5,a5,s9
    80204426:	6f8c                	ld	a1,24(a5)
    80204428:	7390                	ld	a2,32(a5)
    8020442a:	7794                	ld	a3,40(a5)
    8020442c:	7b98                	ld	a4,48(a5)
    8020442e:	7f9c                	ld	a5,56(a5)
    80204430:	f6b43423          	sd	a1,-152(s0)
    80204434:	f6c43823          	sd	a2,-144(s0)
    80204438:	f6d43c23          	sd	a3,-136(s0)
    8020443c:	f8e43023          	sd	a4,-128(s0)
    80204440:	f8f43423          	sd	a5,-120(s0)
            release(&r->lock);
    80204444:	8552                	mv	a0,s4
    80204446:	ffffd097          	auipc	ra,0xffffd
    8020444a:	f96080e7          	jalr	-106(ra) # 802013dc <release>
            if (copyout(p->pagetable, ubuf + total * sizeof(e), (char *)&e, sizeof(e)) < 0)
    8020444e:	02800693          	li	a3,40
    80204452:	f6840613          	addi	a2,s0,-152
    80204456:	85ca                	mv	a1,s2
    80204458:	050bb503          	ld	a0,80(s7) # 1050 <_entry-0x801fefb0>
    8020445c:	fffff097          	auipc	ra,0xfffff
    80204460:	b22080e7          	jalr	-1246(ra) # 80202f7e <copyout>
    80204464:	06054363          	bltz	a0,802044ca <trace_read+0x148>
                return total > 0 ? total : -1;
            acquire(&r->lock);
    80204468:	8552                	mv	a0,s4
    8020446a:	ffffd097          	auipc	ra,0xffffd
    8020446e:	ebe080e7          	jalr	-322(ra) # 80201328 <acquire>
            tail = (tail + 1) % NTRACE;
    80204472:	2485                	addiw	s1,s1,1
    80204474:	07f4f493          	andi	s1,s1,127
            r->count--; total++;
    80204478:	004aa783          	lw	a5,4(s5)
    8020447c:	37fd                	addiw	a5,a5,-1
    8020447e:	0007871b          	sext.w	a4,a5
    80204482:	00faa223          	sw	a5,4(s5)
    80204486:	2985                	addiw	s3,s3,1
        while (r->count > 0 && total < max) {
    80204488:	cf3d                	beqz	a4,80204506 <trace_read+0x184>
    8020448a:	02890913          	addi	s2,s2,40
    8020448e:	f93b16e3          	bne	s6,s3,8020441a <trace_read+0x98>
    80204492:	89da                	mv	s3,s6
            if (copyout(p->pagetable, ubuf + total * sizeof(d), (char *)&d, sizeof(d)) < 0)
                return total > 0 ? total : -1;
            total++;
            continue;
        }
        release(&r->lock);
    80204494:	8552                	mv	a0,s4
    80204496:	ffffd097          	auipc	ra,0xffffd
    8020449a:	f46080e7          	jalr	-186(ra) # 802013dc <release>
    for (int h = 0; h < NCPU && total < max; h++) {
    8020449e:	f5843783          	ld	a5,-168(s0)
    802044a2:	2785                	addiw	a5,a5,1
    802044a4:	f4f43c23          	sd	a5,-168(s0)
    802044a8:	4721                	li	a4,8
    802044aa:	0ee78b63          	beq	a5,a4,802045a0 <trace_read+0x21e>
    802044ae:	9d6e                	add	s10,s10,s11
    802044b0:	f369c5e3          	blt	s3,s6,802043da <trace_read+0x58>
    802044b4:	74aa                	ld	s1,168(sp)
    802044b6:	790a                	ld	s2,160(sp)
    802044b8:	6a4a                	ld	s4,144(sp)
    802044ba:	6aaa                	ld	s5,136(sp)
    802044bc:	6b0a                	ld	s6,128(sp)
    802044be:	7be6                	ld	s7,120(sp)
    802044c0:	7c46                	ld	s8,112(sp)
    802044c2:	7ca6                	ld	s9,104(sp)
    802044c4:	7d06                	ld	s10,96(sp)
    802044c6:	6de6                	ld	s11,88(sp)
    802044c8:	a829                	j	802044e2 <trace_read+0x160>
                return total > 0 ? total : -1;
    802044ca:	03305263          	blez	s3,802044ee <trace_read+0x16c>
    802044ce:	74aa                	ld	s1,168(sp)
    802044d0:	790a                	ld	s2,160(sp)
    802044d2:	6a4a                	ld	s4,144(sp)
    802044d4:	6aaa                	ld	s5,136(sp)
    802044d6:	6b0a                	ld	s6,128(sp)
    802044d8:	7be6                	ld	s7,120(sp)
    802044da:	7c46                	ld	s8,112(sp)
    802044dc:	7ca6                	ld	s9,104(sp)
    802044de:	7d06                	ld	s10,96(sp)
    802044e0:	6de6                	ld	s11,88(sp)
    }
    return total;
}
    802044e2:	854e                	mv	a0,s3
    802044e4:	70ea                	ld	ra,184(sp)
    802044e6:	744a                	ld	s0,176(sp)
    802044e8:	69ea                	ld	s3,152(sp)
    802044ea:	6129                	addi	sp,sp,192
    802044ec:	8082                	ret
                return total > 0 ? total : -1;
    802044ee:	59fd                	li	s3,-1
    802044f0:	74aa                	ld	s1,168(sp)
    802044f2:	790a                	ld	s2,160(sp)
    802044f4:	6a4a                	ld	s4,144(sp)
    802044f6:	6aaa                	ld	s5,136(sp)
    802044f8:	6b0a                	ld	s6,128(sp)
    802044fa:	7be6                	ld	s7,120(sp)
    802044fc:	7c46                	ld	s8,112(sp)
    802044fe:	7ca6                	ld	s9,104(sp)
    80204500:	7d06                	ld	s10,96(sp)
    80204502:	6de6                	ld	s11,88(sp)
    80204504:	bff9                	j	802044e2 <trace_read+0x160>
        if (r->dropped > 0 && total < max) {
    80204506:	008aa783          	lw	a5,8(s5)
    8020450a:	d7c9                	beqz	a5,80204494 <trace_read+0x112>
    8020450c:	f969d4e3          	bge	s3,s6,80204494 <trace_read+0x112>
            d.pid = -1; d.hart = h; d.num = -1; d.ret = 0; d.ts = 0; d.arg0 = r->dropped;
    80204510:	577d                	li	a4,-1
    80204512:	f6e42423          	sw	a4,-152(s0)
    80204516:	f5843683          	ld	a3,-168(s0)
    8020451a:	f6d42623          	sw	a3,-148(s0)
    8020451e:	f6e42823          	sw	a4,-144(s0)
    80204522:	f6043c23          	sd	zero,-136(s0)
    80204526:	f8043023          	sd	zero,-128(s0)
    8020452a:	1782                	slli	a5,a5,0x20
    8020452c:	9381                	srli	a5,a5,0x20
    8020452e:	f8f43423          	sd	a5,-120(s0)
            r->dropped = 0;
    80204532:	000aa423          	sw	zero,8(s5)
            release(&r->lock);
    80204536:	8552                	mv	a0,s4
    80204538:	ffffd097          	auipc	ra,0xffffd
    8020453c:	ea4080e7          	jalr	-348(ra) # 802013dc <release>
            if (copyout(p->pagetable, ubuf + total * sizeof(d), (char *)&d, sizeof(d)) < 0)
    80204540:	00299593          	slli	a1,s3,0x2
    80204544:	95ce                	add	a1,a1,s3
    80204546:	058e                	slli	a1,a1,0x3
    80204548:	02800693          	li	a3,40
    8020454c:	f6840613          	addi	a2,s0,-152
    80204550:	f5043783          	ld	a5,-176(s0)
    80204554:	95be                	add	a1,a1,a5
    80204556:	050bb503          	ld	a0,80(s7)
    8020455a:	fffff097          	auipc	ra,0xfffff
    8020455e:	a24080e7          	jalr	-1500(ra) # 80202f7e <copyout>
    80204562:	00054463          	bltz	a0,8020456a <trace_read+0x1e8>
            total++;
    80204566:	2985                	addiw	s3,s3,1
            continue;
    80204568:	bf1d                	j	8020449e <trace_read+0x11c>
                return total > 0 ? total : -1;
    8020456a:	01305d63          	blez	s3,80204584 <trace_read+0x202>
    8020456e:	74aa                	ld	s1,168(sp)
    80204570:	790a                	ld	s2,160(sp)
    80204572:	6a4a                	ld	s4,144(sp)
    80204574:	6aaa                	ld	s5,136(sp)
    80204576:	6b0a                	ld	s6,128(sp)
    80204578:	7be6                	ld	s7,120(sp)
    8020457a:	7c46                	ld	s8,112(sp)
    8020457c:	7ca6                	ld	s9,104(sp)
    8020457e:	7d06                	ld	s10,96(sp)
    80204580:	6de6                	ld	s11,88(sp)
    80204582:	b785                	j	802044e2 <trace_read+0x160>
    80204584:	59fd                	li	s3,-1
    80204586:	74aa                	ld	s1,168(sp)
    80204588:	790a                	ld	s2,160(sp)
    8020458a:	6a4a                	ld	s4,144(sp)
    8020458c:	6aaa                	ld	s5,136(sp)
    8020458e:	6b0a                	ld	s6,128(sp)
    80204590:	7be6                	ld	s7,120(sp)
    80204592:	7c46                	ld	s8,112(sp)
    80204594:	7ca6                	ld	s9,104(sp)
    80204596:	7d06                	ld	s10,96(sp)
    80204598:	6de6                	ld	s11,88(sp)
    8020459a:	b7a1                	j	802044e2 <trace_read+0x160>
    if (max <= 0) return -1;
    8020459c:	59fd                	li	s3,-1
    8020459e:	b791                	j	802044e2 <trace_read+0x160>
    802045a0:	74aa                	ld	s1,168(sp)
    802045a2:	790a                	ld	s2,160(sp)
    802045a4:	6a4a                	ld	s4,144(sp)
    802045a6:	6aaa                	ld	s5,136(sp)
    802045a8:	6b0a                	ld	s6,128(sp)
    802045aa:	7be6                	ld	s7,120(sp)
    802045ac:	7c46                	ld	s8,112(sp)
    802045ae:	7ca6                	ld	s9,104(sp)
    802045b0:	7d06                	ld	s10,96(sp)
    802045b2:	6de6                	ld	s11,88(sp)
    802045b4:	b73d                	j	802044e2 <trace_read+0x160>

00000000802045b6 <trace_fork>:

void trace_fork(struct proc *parent, struct proc *child)
{
    802045b6:	1141                	addi	sp,sp,-16
    802045b8:	e422                	sd	s0,8(sp)
    802045ba:	0800                	addi	s0,sp,16
    child->trace_filter = parent->trace_filter;
    802045bc:	16853783          	ld	a5,360(a0)
    802045c0:	16f5b423          	sd	a5,360(a1)
}
    802045c4:	6422                	ld	s0,8(sp)
    802045c6:	0141                	addi	sp,sp,16
    802045c8:	8082                	ret

00000000802045ca <usysinfo_setup>:
extern uint64 ticks;

/* PROVIDED: one physical page per process, user-readable but not user-writable. */
int
usysinfo_setup(struct proc *p)
{
    802045ca:	1101                	addi	sp,sp,-32
    802045cc:	ec06                	sd	ra,24(sp)
    802045ce:	e822                	sd	s0,16(sp)
    802045d0:	e04a                	sd	s2,0(sp)
    802045d2:	1000                	addi	s0,sp,32
    802045d4:	892a                	mv	s2,a0
    char *mem = palloc();
    802045d6:	ffffd097          	auipc	ra,0xffffd
    802045da:	ac4080e7          	jalr	-1340(ra) # 8020109a <palloc>
    if (mem == 0)
    802045de:	c929                	beqz	a0,80204630 <usysinfo_setup+0x66>
    802045e0:	e426                	sd	s1,8(sp)
    802045e2:	84aa                	mv	s1,a0
        return -1;
    memset(mem, 0, PGSIZE);
    802045e4:	6605                	lui	a2,0x1
    802045e6:	4581                	li	a1,0
    802045e8:	ffffc097          	auipc	ra,0xffffc
    802045ec:	0b0080e7          	jalr	176(ra) # 80200698 <memset>

    struct usysinfo *u = (struct usysinfo *)mem;
    u->version = USYSINFO_VERSION;
    802045f0:	4785                	li	a5,1
    802045f2:	c09c                	sw	a5,0(s1)
    u->seq = 0;
    802045f4:	0004a223          	sw	zero,4(s1)

    if (mappages(p->pagetable, USYSINFO_VA, PGSIZE, (uint64)mem,
    802045f8:	4749                	li	a4,18
    802045fa:	86a6                	mv	a3,s1
    802045fc:	6605                	lui	a2,0x1
    802045fe:	7ffff5b7          	lui	a1,0x7ffff
    80204602:	05093503          	ld	a0,80(s2)
    80204606:	ffffe097          	auipc	ra,0xffffe
    8020460a:	59e080e7          	jalr	1438(ra) # 80202ba4 <mappages>
    8020460e:	e909                	bnez	a0,80204620 <usysinfo_setup+0x56>
                 PTE_R | PTE_U) != 0) {
        pfree(mem);
        return -1;
    }
    p->usysinfo = u;
    80204610:	16993823          	sd	s1,368(s2)
    return 0;
    80204614:	64a2                	ld	s1,8(sp)
}
    80204616:	60e2                	ld	ra,24(sp)
    80204618:	6442                	ld	s0,16(sp)
    8020461a:	6902                	ld	s2,0(sp)
    8020461c:	6105                	addi	sp,sp,32
    8020461e:	8082                	ret
        pfree(mem);
    80204620:	8526                	mv	a0,s1
    80204622:	ffffd097          	auipc	ra,0xffffd
    80204626:	b88080e7          	jalr	-1144(ra) # 802011aa <pfree>
        return -1;
    8020462a:	557d                	li	a0,-1
    8020462c:	64a2                	ld	s1,8(sp)
    8020462e:	b7e5                	j	80204616 <usysinfo_setup+0x4c>
        return -1;
    80204630:	557d                	li	a0,-1
    80204632:	b7d5                	j	80204616 <usysinfo_setup+0x4c>

0000000080204634 <usysinfo_free>:
/* PROVIDED: USYSINFO_VA lies above p->sz, so ordinary uvmfree() will not
 * free the backing leaf page. Remove it explicitly before freeing the tree. */
void
usysinfo_free(struct proc *p)
{
    if (p->usysinfo) {
    80204634:	17053783          	ld	a5,368(a0)
    80204638:	cb85                	beqz	a5,80204668 <usysinfo_free+0x34>
{
    8020463a:	1101                	addi	sp,sp,-32
    8020463c:	ec06                	sd	ra,24(sp)
    8020463e:	e822                	sd	s0,16(sp)
    80204640:	e426                	sd	s1,8(sp)
    80204642:	1000                	addi	s0,sp,32
    80204644:	84aa                	mv	s1,a0
        if (p->pagetable)
    80204646:	6928                	ld	a0,80(a0)
    80204648:	c909                	beqz	a0,8020465a <usysinfo_free+0x26>
            uvmunmap(p->pagetable, USYSINFO_VA, 1, 1);
    8020464a:	4685                	li	a3,1
    8020464c:	4605                	li	a2,1
    8020464e:	7ffff5b7          	lui	a1,0x7ffff
    80204652:	ffffe097          	auipc	ra,0xffffe
    80204656:	7b0080e7          	jalr	1968(ra) # 80202e02 <uvmunmap>
        p->usysinfo = 0;
    8020465a:	1604b823          	sd	zero,368(s1)
    }
}
    8020465e:	60e2                	ld	ra,24(sp)
    80204660:	6442                	ld	s0,16(sp)
    80204662:	64a2                	ld	s1,8(sp)
    80204664:	6105                	addi	sp,sp,32
    80204666:	8082                	ret
    80204668:	8082                	ret

000000008020466a <usysinfo_remap>:
/* PROVIDED: exec() builds a fresh process page table. Re-map the same
 * per-process information page into the new address space before commit. */
int
usysinfo_remap(struct proc *p, pagetable_t newpt)
{
    if (p->usysinfo == 0)
    8020466a:	17053683          	ld	a3,368(a0)
    8020466e:	c69d                	beqz	a3,8020469c <usysinfo_remap+0x32>
{
    80204670:	1141                	addi	sp,sp,-16
    80204672:	e406                	sd	ra,8(sp)
    80204674:	e022                	sd	s0,0(sp)
    80204676:	0800                	addi	s0,sp,16
    80204678:	87ae                	mv	a5,a1
        return 0;
    if (mappages(newpt, USYSINFO_VA, PGSIZE, (uint64)p->usysinfo,
    8020467a:	4749                	li	a4,18
    8020467c:	6605                	lui	a2,0x1
    8020467e:	7ffff5b7          	lui	a1,0x7ffff
    80204682:	853e                	mv	a0,a5
    80204684:	ffffe097          	auipc	ra,0xffffe
    80204688:	520080e7          	jalr	1312(ra) # 80202ba4 <mappages>
    8020468c:	00a03533          	snez	a0,a0
    80204690:	40a00533          	neg	a0,a0
                 PTE_R | PTE_U) != 0)
        return -1;
    return 0;
}
    80204694:	60a2                	ld	ra,8(sp)
    80204696:	6402                	ld	s0,0(sp)
    80204698:	0141                	addi	sp,sp,16
    8020469a:	8082                	ret
        return 0;
    8020469c:	4501                	li	a0,0
}
    8020469e:	8082                	ret

00000000802046a0 <usysinfo_update>:
     *   6. Use __sync_synchronize() again before finishing.
     *   7. Make seq even.
     *
     * Do not change USYSINFO_VERSION. Keep your K1 code between these markers.
     */
    if (p->usysinfo == 0)
    802046a0:	17053783          	ld	a5,368(a0)
    802046a4:	c7d1                	beqz	a5,80204730 <usysinfo_update+0x90>
{
    802046a6:	1101                	addi	sp,sp,-32
    802046a8:	ec06                	sd	ra,24(sp)
    802046aa:	e822                	sd	s0,16(sp)
    802046ac:	e426                	sd	s1,8(sp)
    802046ae:	e04a                	sd	s2,0(sp)
    802046b0:	1000                	addi	s0,sp,32
    802046b2:	84aa                	mv	s1,a0
        return;
    push_off();
    802046b4:	ffffd097          	auipc	ra,0xffffd
    802046b8:	c3c080e7          	jalr	-964(ra) # 802012f0 <push_off>
    p->usysinfo->seq += 1;
    802046bc:	1704b703          	ld	a4,368(s1)
    802046c0:	435c                	lw	a5,4(a4)
    802046c2:	2785                	addiw	a5,a5,1
    802046c4:	c35c                	sw	a5,4(a4)
    __sync_synchronize();
    802046c6:	0ff0000f          	fence
    p->usysinfo->pid = p->pid;
    802046ca:	1704b783          	ld	a5,368(s1)
    802046ce:	5898                	lw	a4,48(s1)
    802046d0:	c798                	sw	a4,8(a5)
    p->usysinfo->hart = hal_hart_id();
    802046d2:	1704b903          	ld	s2,368(s1)
    802046d6:	00002097          	auipc	ra,0x2
    802046da:	0d8080e7          	jalr	216(ra) # 802067ae <hal_hart_id>
    802046de:	00a92623          	sw	a0,12(s2)
    p->usysinfo->ticks = ticks;
    802046e2:	1704b783          	ld	a5,368(s1)
    802046e6:	00146717          	auipc	a4,0x146
    802046ea:	93273703          	ld	a4,-1742(a4) # 8034a018 <ticks>
    802046ee:	eb98                	sd	a4,16(a5)
    p->usysinfo->syscall_count = p->syscall_count;
    802046f0:	1704b783          	ld	a5,368(s1)
    802046f4:	1784b703          	ld	a4,376(s1)
    802046f8:	ef98                	sd	a4,24(a5)
    p->usysinfo->ctxsw_count = p->ctxsw_count;
    802046fa:	1704b783          	ld	a5,368(s1)
    802046fe:	1804b703          	ld	a4,384(s1)
    80204702:	f398                	sd	a4,32(a5)
    p->usysinfo->state_gen = p->state_gen;
    80204704:	1704b783          	ld	a5,368(s1)
    80204708:	1884a703          	lw	a4,392(s1)
    8020470c:	d798                	sw	a4,40(a5)
    __sync_synchronize();
    8020470e:	0ff0000f          	fence
    p->usysinfo->seq += 1;
    80204712:	1704b703          	ld	a4,368(s1)
    80204716:	435c                	lw	a5,4(a4)
    80204718:	2785                	addiw	a5,a5,1
    8020471a:	c35c                	sw	a5,4(a4)
    pop_off();
    8020471c:	ffffd097          	auipc	ra,0xffffd
    80204720:	c60080e7          	jalr	-928(ra) # 8020137c <pop_off>
    /* TODO-END K1 */
}
    80204724:	60e2                	ld	ra,24(sp)
    80204726:	6442                	ld	s0,16(sp)
    80204728:	64a2                	ld	s1,8(sp)
    8020472a:	6902                	ld	s2,0(sp)
    8020472c:	6105                	addi	sp,sp,32
    8020472e:	8082                	ret
    80204730:	8082                	ret

0000000080204732 <consolewrite>:
    devsw[CONSOLE].read  = consoleread;
    devsw[CONSOLE].write = consolewrite;
}

int consolewrite(uint64 src, int n)
{
    80204732:	7139                	addi	sp,sp,-64
    80204734:	fc06                	sd	ra,56(sp)
    80204736:	f822                	sd	s0,48(sp)
    80204738:	ec4e                	sd	s3,24(sp)
    8020473a:	0080                	addi	s0,sp,64
    8020473c:	89ae                	mv	s3,a1
    for (int i = 0; i < n; i++) {
    8020473e:	04b05563          	blez	a1,80204788 <consolewrite+0x56>
    80204742:	f426                	sd	s1,40(sp)
    80204744:	f04a                	sd	s2,32(sp)
    80204746:	84aa                	mv	s1,a0
    80204748:	00a58933          	add	s2,a1,a0
        char c;
        /* copyin, not a direct dereference - src is a USER pointer. */
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    8020474c:	ffffd097          	auipc	ra,0xffffd
    80204750:	01a080e7          	jalr	26(ra) # 80201766 <myproc>
    80204754:	4685                	li	a3,1
    80204756:	8626                	mv	a2,s1
    80204758:	fcf40593          	addi	a1,s0,-49
    8020475c:	6928                	ld	a0,80(a0)
    8020475e:	fffff097          	auipc	ra,0xfffff
    80204762:	914080e7          	jalr	-1772(ra) # 80203072 <copyin>
    80204766:	00054e63          	bltz	a0,80204782 <consolewrite+0x50>
        hal_console_putc(c);
    8020476a:	fcf44503          	lbu	a0,-49(s0)
    8020476e:	00002097          	auipc	ra,0x2
    80204772:	128080e7          	jalr	296(ra) # 80206896 <hal_console_putc>
    for (int i = 0; i < n; i++) {
    80204776:	0485                	addi	s1,s1,1
    80204778:	fd249ae3          	bne	s1,s2,8020474c <consolewrite+0x1a>
    8020477c:	74a2                	ld	s1,40(sp)
    8020477e:	7902                	ld	s2,32(sp)
    80204780:	a021                	j	80204788 <consolewrite+0x56>
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    80204782:	59fd                	li	s3,-1
    80204784:	74a2                	ld	s1,40(sp)
    80204786:	7902                	ld	s2,32(sp)
    }
    return n;
}
    80204788:	854e                	mv	a0,s3
    8020478a:	70e2                	ld	ra,56(sp)
    8020478c:	7442                	ld	s0,48(sp)
    8020478e:	69e2                	ld	s3,24(sp)
    80204790:	6121                	addi	sp,sp,64
    80204792:	8082                	ret

0000000080204794 <consoleread>:

int consoleread(uint64 dst, int n)
{
    80204794:	715d                	addi	sp,sp,-80
    80204796:	e486                	sd	ra,72(sp)
    80204798:	e0a2                	sd	s0,64(sp)
    8020479a:	fc26                	sd	s1,56(sp)
    8020479c:	f84a                	sd	s2,48(sp)
    8020479e:	f44e                	sd	s3,40(sp)
    802047a0:	f052                	sd	s4,32(sp)
    802047a2:	ec56                	sd	s5,24(sp)
    802047a4:	0880                	addi	s0,sp,80
    802047a6:	8a2a                	mv	s4,a0
    802047a8:	89ae                	mv	s3,a1
    int target = n;
    acquire(&cons.lock);
    802047aa:	00137517          	auipc	a0,0x137
    802047ae:	dae50513          	addi	a0,a0,-594 # 8033b558 <cons>
    802047b2:	ffffd097          	auipc	ra,0xffffd
    802047b6:	b76080e7          	jalr	-1162(ra) # 80201328 <acquire>
    while (n > 0) {
    802047ba:	8ace                	mv	s5,s3
        while (cons.r == cons.w) {
    802047bc:	00137497          	auipc	s1,0x137
    802047c0:	d9c48493          	addi	s1,s1,-612 # 8033b558 <cons>
            if (myproc()->killed) { release(&cons.lock); return -1; }
            sleep(&cons.r, &cons.lock);
    802047c4:	00137917          	auipc	s2,0x137
    802047c8:	e2c90913          	addi	s2,s2,-468 # 8033b5f0 <cons+0x98>
    while (n > 0) {
    802047cc:	09305463          	blez	s3,80204854 <consoleread+0xc0>
        while (cons.r == cons.w) {
    802047d0:	0984a783          	lw	a5,152(s1)
    802047d4:	09c4a703          	lw	a4,156(s1)
    802047d8:	02f71463          	bne	a4,a5,80204800 <consoleread+0x6c>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    802047dc:	ffffd097          	auipc	ra,0xffffd
    802047e0:	f8a080e7          	jalr	-118(ra) # 80201766 <myproc>
    802047e4:	551c                	lw	a5,40(a0)
    802047e6:	e3d1                	bnez	a5,8020486a <consoleread+0xd6>
            sleep(&cons.r, &cons.lock);
    802047e8:	85a6                	mv	a1,s1
    802047ea:	854a                	mv	a0,s2
    802047ec:	ffffd097          	auipc	ra,0xffffd
    802047f0:	620080e7          	jalr	1568(ra) # 80201e0c <sleep>
        while (cons.r == cons.w) {
    802047f4:	0984a783          	lw	a5,152(s1)
    802047f8:	09c4a703          	lw	a4,156(s1)
    802047fc:	fef700e3          	beq	a4,a5,802047dc <consoleread+0x48>
        }
        char c = cons.buf[cons.r++ % INBUF];
    80204800:	00137717          	auipc	a4,0x137
    80204804:	d5870713          	addi	a4,a4,-680 # 8033b558 <cons>
    80204808:	0017869b          	addiw	a3,a5,1
    8020480c:	08d72c23          	sw	a3,152(a4)
    80204810:	07f7f793          	andi	a5,a5,127
    80204814:	973e                	add	a4,a4,a5
    80204816:	01874783          	lbu	a5,24(a4)
    8020481a:	faf40fa3          	sb	a5,-65(s0)
        if (c == 4) break;                       /* Ctrl-D */
    8020481e:	4711                	li	a4,4
    80204820:	02e78a63          	beq	a5,a4,80204854 <consoleread+0xc0>
        if (copyout(myproc()->pagetable, dst, &c, 1) < 0) break;
    80204824:	ffffd097          	auipc	ra,0xffffd
    80204828:	f42080e7          	jalr	-190(ra) # 80201766 <myproc>
    8020482c:	4685                	li	a3,1
    8020482e:	fbf40613          	addi	a2,s0,-65
    80204832:	85d2                	mv	a1,s4
    80204834:	6928                	ld	a0,80(a0)
    80204836:	ffffe097          	auipc	ra,0xffffe
    8020483a:	748080e7          	jalr	1864(ra) # 80202f7e <copyout>
    8020483e:	00054b63          	bltz	a0,80204854 <consoleread+0xc0>
        dst++; n--;
    80204842:	0a05                	addi	s4,s4,1
    80204844:	3afd                	addiw	s5,s5,-1
        if (c == '\n') break;
    80204846:	fbf44703          	lbu	a4,-65(s0)
    8020484a:	47a9                	li	a5,10
    8020484c:	00f70463          	beq	a4,a5,80204854 <consoleread+0xc0>
    while (n > 0) {
    80204850:	f80a90e3          	bnez	s5,802047d0 <consoleread+0x3c>
    }
    release(&cons.lock);
    80204854:	00137517          	auipc	a0,0x137
    80204858:	d0450513          	addi	a0,a0,-764 # 8033b558 <cons>
    8020485c:	ffffd097          	auipc	ra,0xffffd
    80204860:	b80080e7          	jalr	-1152(ra) # 802013dc <release>
    return target - n;
    80204864:	4159853b          	subw	a0,s3,s5
    80204868:	a811                	j	8020487c <consoleread+0xe8>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    8020486a:	00137517          	auipc	a0,0x137
    8020486e:	cee50513          	addi	a0,a0,-786 # 8033b558 <cons>
    80204872:	ffffd097          	auipc	ra,0xffffd
    80204876:	b6a080e7          	jalr	-1174(ra) # 802013dc <release>
    8020487a:	557d                	li	a0,-1
}
    8020487c:	60a6                	ld	ra,72(sp)
    8020487e:	6406                	ld	s0,64(sp)
    80204880:	74e2                	ld	s1,56(sp)
    80204882:	7942                	ld	s2,48(sp)
    80204884:	79a2                	ld	s3,40(sp)
    80204886:	7a02                	ld	s4,32(sp)
    80204888:	6ae2                	ld	s5,24(sp)
    8020488a:	6161                	addi	sp,sp,80
    8020488c:	8082                	ret

000000008020488e <consoleinit>:
{
    8020488e:	1141                	addi	sp,sp,-16
    80204890:	e406                	sd	ra,8(sp)
    80204892:	e022                	sd	s0,0(sp)
    80204894:	0800                	addi	s0,sp,16
    initlock(&cons.lock, "cons");
    80204896:	00003597          	auipc	a1,0x3
    8020489a:	0d258593          	addi	a1,a1,210 # 80207968 <etext+0x968>
    8020489e:	00137517          	auipc	a0,0x137
    802048a2:	cba50513          	addi	a0,a0,-838 # 8033b558 <cons>
    802048a6:	ffffd097          	auipc	ra,0xffffd
    802048aa:	a06080e7          	jalr	-1530(ra) # 802012ac <initlock>
    devsw[CONSOLE].read  = consoleread;
    802048ae:	00141797          	auipc	a5,0x141
    802048b2:	ee278793          	addi	a5,a5,-286 # 80345790 <devsw>
    802048b6:	00000717          	auipc	a4,0x0
    802048ba:	ede70713          	addi	a4,a4,-290 # 80204794 <consoleread>
    802048be:	eb98                	sd	a4,16(a5)
    devsw[CONSOLE].write = consolewrite;
    802048c0:	00000717          	auipc	a4,0x0
    802048c4:	e7270713          	addi	a4,a4,-398 # 80204732 <consolewrite>
    802048c8:	ef98                	sd	a4,24(a5)
}
    802048ca:	60a2                	ld	ra,8(sp)
    802048cc:	6402                	ld	s0,0(sp)
    802048ce:	0141                	addi	sp,sp,16
    802048d0:	8082                	ret

00000000802048d2 <consoleintr>:

/* Called from the trap handler when the UART raises an interrupt. */
void consoleintr(int c)
{
    802048d2:	1101                	addi	sp,sp,-32
    802048d4:	ec06                	sd	ra,24(sp)
    802048d6:	e822                	sd	s0,16(sp)
    802048d8:	e426                	sd	s1,8(sp)
    802048da:	1000                	addi	s0,sp,32
    802048dc:	84aa                	mv	s1,a0
    acquire(&cons.lock);
    802048de:	00137517          	auipc	a0,0x137
    802048e2:	c7a50513          	addi	a0,a0,-902 # 8033b558 <cons>
    802048e6:	ffffd097          	auipc	ra,0xffffd
    802048ea:	a42080e7          	jalr	-1470(ra) # 80201328 <acquire>
    switch (c) {
    802048ee:	47c1                	li	a5,16
    802048f0:	08f48463          	beq	s1,a5,80204978 <consoleintr+0xa6>
    802048f4:	07f00793          	li	a5,127
    802048f8:	0af48163          	beq	s1,a5,8020499a <consoleintr+0xc8>
    802048fc:	47a1                	li	a5,8
    802048fe:	08f48e63          	beq	s1,a5,8020499a <consoleintr+0xc8>
            cons.e--;
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
        }
        break;
    default:
        if (c != 0 && cons.e - cons.r < INBUF) {
    80204902:	ccbd                	beqz	s1,80204980 <consoleintr+0xae>
    80204904:	00137717          	auipc	a4,0x137
    80204908:	c5470713          	addi	a4,a4,-940 # 8033b558 <cons>
    8020490c:	0a072783          	lw	a5,160(a4)
    80204910:	09872703          	lw	a4,152(a4)
    80204914:	9f99                	subw	a5,a5,a4
    80204916:	07f00713          	li	a4,127
    8020491a:	06f76363          	bltu	a4,a5,80204980 <consoleintr+0xae>
            c = (c == '\r') ? '\n' : c;
    8020491e:	47b5                	li	a5,13
    80204920:	0cf48f63          	beq	s1,a5,802049fe <consoleintr+0x12c>
    80204924:	e04a                	sd	s2,0(sp)
            hal_console_putc(c);                 /* echo */
    80204926:	0ff4f913          	zext.b	s2,s1
    8020492a:	854a                	mv	a0,s2
    8020492c:	00002097          	auipc	ra,0x2
    80204930:	f6a080e7          	jalr	-150(ra) # 80206896 <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    80204934:	00137797          	auipc	a5,0x137
    80204938:	c2478793          	addi	a5,a5,-988 # 8033b558 <cons>
    8020493c:	0a07a703          	lw	a4,160(a5)
    80204940:	0017069b          	addiw	a3,a4,1
    80204944:	0006861b          	sext.w	a2,a3
    80204948:	0ad7a023          	sw	a3,160(a5)
    8020494c:	07f77713          	andi	a4,a4,127
    80204950:	97ba                	add	a5,a5,a4
    80204952:	01278c23          	sb	s2,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    80204956:	47a9                	li	a5,10
    80204958:	08f48363          	beq	s1,a5,802049de <consoleintr+0x10c>
    8020495c:	4791                	li	a5,4
    8020495e:	08f48263          	beq	s1,a5,802049e2 <consoleintr+0x110>
    80204962:	00137797          	auipc	a5,0x137
    80204966:	c8e7a783          	lw	a5,-882(a5) # 8033b5f0 <cons+0x98>
    8020496a:	9e9d                	subw	a3,a3,a5
    8020496c:	08000793          	li	a5,128
    80204970:	06f68563          	beq	a3,a5,802049da <consoleintr+0x108>
    80204974:	6902                	ld	s2,0(sp)
    80204976:	a029                	j	80204980 <consoleintr+0xae>
        procdump();
    80204978:	ffffe097          	auipc	ra,0xffffe
    8020497c:	8d0080e7          	jalr	-1840(ra) # 80202248 <procdump>
                wakeup(&cons.r);
            }
        }
        break;
    }
    release(&cons.lock);
    80204980:	00137517          	auipc	a0,0x137
    80204984:	bd850513          	addi	a0,a0,-1064 # 8033b558 <cons>
    80204988:	ffffd097          	auipc	ra,0xffffd
    8020498c:	a54080e7          	jalr	-1452(ra) # 802013dc <release>
}
    80204990:	60e2                	ld	ra,24(sp)
    80204992:	6442                	ld	s0,16(sp)
    80204994:	64a2                	ld	s1,8(sp)
    80204996:	6105                	addi	sp,sp,32
    80204998:	8082                	ret
        if (cons.e != cons.w) {
    8020499a:	00137717          	auipc	a4,0x137
    8020499e:	bbe70713          	addi	a4,a4,-1090 # 8033b558 <cons>
    802049a2:	0a072783          	lw	a5,160(a4)
    802049a6:	09c72703          	lw	a4,156(a4)
    802049aa:	fcf70be3          	beq	a4,a5,80204980 <consoleintr+0xae>
            cons.e--;
    802049ae:	37fd                	addiw	a5,a5,-1
    802049b0:	00137717          	auipc	a4,0x137
    802049b4:	c4f72423          	sw	a5,-952(a4) # 8033b5f8 <cons+0xa0>
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
    802049b8:	4521                	li	a0,8
    802049ba:	00002097          	auipc	ra,0x2
    802049be:	edc080e7          	jalr	-292(ra) # 80206896 <hal_console_putc>
    802049c2:	02000513          	li	a0,32
    802049c6:	00002097          	auipc	ra,0x2
    802049ca:	ed0080e7          	jalr	-304(ra) # 80206896 <hal_console_putc>
    802049ce:	4521                	li	a0,8
    802049d0:	00002097          	auipc	ra,0x2
    802049d4:	ec6080e7          	jalr	-314(ra) # 80206896 <hal_console_putc>
    802049d8:	b765                	j	80204980 <consoleintr+0xae>
    802049da:	6902                	ld	s2,0(sp)
    802049dc:	a021                	j	802049e4 <consoleintr+0x112>
    802049de:	6902                	ld	s2,0(sp)
    802049e0:	a011                	j	802049e4 <consoleintr+0x112>
    802049e2:	6902                	ld	s2,0(sp)
                cons.w = cons.e;
    802049e4:	00137797          	auipc	a5,0x137
    802049e8:	c0c7a823          	sw	a2,-1008(a5) # 8033b5f4 <cons+0x9c>
                wakeup(&cons.r);
    802049ec:	00137517          	auipc	a0,0x137
    802049f0:	c0450513          	addi	a0,a0,-1020 # 8033b5f0 <cons+0x98>
    802049f4:	ffffd097          	auipc	ra,0xffffd
    802049f8:	59e080e7          	jalr	1438(ra) # 80201f92 <wakeup>
    802049fc:	b751                	j	80204980 <consoleintr+0xae>
            hal_console_putc(c);                 /* echo */
    802049fe:	4529                	li	a0,10
    80204a00:	00002097          	auipc	ra,0x2
    80204a04:	e96080e7          	jalr	-362(ra) # 80206896 <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    80204a08:	00137797          	auipc	a5,0x137
    80204a0c:	b5078793          	addi	a5,a5,-1200 # 8033b558 <cons>
    80204a10:	0a07a703          	lw	a4,160(a5)
    80204a14:	0017069b          	addiw	a3,a4,1
    80204a18:	0006861b          	sext.w	a2,a3
    80204a1c:	0ad7a023          	sw	a3,160(a5)
    80204a20:	07f77713          	andi	a4,a4,127
    80204a24:	97ba                	add	a5,a5,a4
    80204a26:	4729                	li	a4,10
    80204a28:	00e78c23          	sb	a4,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    80204a2c:	bf65                	j	802049e4 <consoleintr+0x112>

0000000080204a2e <exec>:
    }
    return 0;
}

int exec(char *path, char **argv)
{
    80204a2e:	7125                	addi	sp,sp,-416
    80204a30:	ef06                	sd	ra,408(sp)
    80204a32:	eb22                	sd	s0,400(sp)
    80204a34:	e726                	sd	s1,392(sp)
    80204a36:	1300                	addi	s0,sp,416
    80204a38:	e8a43023          	sd	a0,-384(s0)
    80204a3c:	e6b43c23          	sd	a1,-392(s0)
    struct inode *ip = namei(path);
    80204a40:	00001097          	auipc	ra,0x1
    80204a44:	540080e7          	jalr	1344(ra) # 80205f80 <namei>
    if (ip == 0) return -1;
    80204a48:	3e050163          	beqz	a0,80204e2a <exec+0x3fc>
    80204a4c:	f2da                	sd	s6,352(sp)
    80204a4e:	8b2a                	mv	s6,a0
    ilock(ip);
    80204a50:	00001097          	auipc	ra,0x1
    80204a54:	c9c080e7          	jalr	-868(ra) # 802056ec <ilock>

    struct elfhdr eh;
    pagetable_t newpt = 0;
    uint64 sz = 0;

    if (readi(ip, 0, (uint64)&eh, 0, sizeof(eh)) != sizeof(eh)) goto bad;
    80204a58:	04000713          	li	a4,64
    80204a5c:	4681                	li	a3,0
    80204a5e:	f5040613          	addi	a2,s0,-176
    80204a62:	4581                	li	a1,0
    80204a64:	855a                	mv	a0,s6
    80204a66:	00001097          	auipc	ra,0x1
    80204a6a:	fb4080e7          	jalr	-76(ra) # 80205a1a <readi>
    80204a6e:	04000793          	li	a5,64
    80204a72:	02f51263          	bne	a0,a5,80204a96 <exec+0x68>
    if (eh.magic != ELF_MAGIC) goto bad;              /* reject, do not run */
    80204a76:	f5042703          	lw	a4,-176(s0)
    80204a7a:	464c47b7          	lui	a5,0x464c4
    80204a7e:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39d3ba81>
    80204a82:	00f71a63          	bne	a4,a5,80204a96 <exec+0x68>
    if (eh.phnum == 0 || eh.phnum > 16) goto bad;
    80204a86:	f8845783          	lhu	a5,-120(s0)
    80204a8a:	37fd                	addiw	a5,a5,-1
    80204a8c:	17c2                	slli	a5,a5,0x30
    80204a8e:	93c1                	srli	a5,a5,0x30
    80204a90:	473d                	li	a4,15
    80204a92:	00f77f63          	bgeu	a4,a5,80204ab0 <exec+0x82>
    uvmfree(oldpt, oldsz);
    return argc;

bad:
    if (newpt) uvmfree(newpt, sz);
    if (ip) iunlockput(ip);
    80204a96:	855a                	mv	a0,s6
    80204a98:	00001097          	auipc	ra,0x1
    80204a9c:	f30080e7          	jalr	-208(ra) # 802059c8 <iunlockput>
    return -1;
    80204aa0:	54fd                	li	s1,-1
    80204aa2:	7b16                	ld	s6,352(sp)
}
    80204aa4:	8526                	mv	a0,s1
    80204aa6:	60fa                	ld	ra,408(sp)
    80204aa8:	645a                	ld	s0,400(sp)
    80204aaa:	64ba                	ld	s1,392(sp)
    80204aac:	611d                	addi	sp,sp,416
    80204aae:	8082                	ret
    80204ab0:	eae2                	sd	s8,336(sp)
    if ((newpt = uvmcreate()) == 0) goto bad;
    80204ab2:	ffffe097          	auipc	ra,0xffffe
    80204ab6:	304080e7          	jalr	772(ra) # 80202db6 <uvmcreate>
    80204aba:	8c2a                	mv	s8,a0
    80204abc:	36050563          	beqz	a0,80204e26 <exec+0x3f8>
    80204ac0:	e34a                	sd	s2,384(sp)
    80204ac2:	fece                	sd	s3,376(sp)
    80204ac4:	fad2                	sd	s4,368(sp)
    80204ac6:	f6d6                	sd	s5,360(sp)
    80204ac8:	eede                	sd	s7,344(sp)
    80204aca:	e6e6                	sd	s9,328(sp)
    80204acc:	e2ea                	sd	s10,320(sp)
    80204ace:	fe6e                	sd	s11,312(sp)
    for (int i = 0; i < eh.phnum; i++) {
    80204ad0:	f8845783          	lhu	a5,-120(s0)
    80204ad4:	16078563          	beqz	a5,80204c3e <exec+0x210>
    80204ad8:	4c81                	li	s9,0
    80204ada:	4d01                	li	s10,0
    uint64 sz = 0;
    80204adc:	e8043423          	sd	zero,-376(s0)
        if (ph.type != ELF_PROG_LOAD) continue;
    80204ae0:	4d85                	li	s11,1
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    80204ae2:	800007b7          	lui	a5,0x80000
    80204ae6:	fff7c793          	not	a5,a5
    80204aea:	e6f43823          	sd	a5,-400(s0)
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    80204aee:	6a05                	lui	s4,0x1
    80204af0:	fffa0793          	addi	a5,s4,-1 # fff <_entry-0x801ff001>
    80204af4:	e6f43423          	sd	a5,-408(s0)
    80204af8:	a0d1                	j	80204bbc <exec+0x18e>
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    80204afa:	00c4f563          	bgeu	s1,a2,80204b04 <exec+0xd6>
    80204afe:	8e05                	sub	a2,a2,s1
    80204b00:	4781                	li	a5,0
    80204b02:	a09d                	j	80204b68 <exec+0x13a>
    80204b04:	4781                	li	a5,0
    80204b06:	4601                	li	a2,0
    80204b08:	a085                	j	80204b68 <exec+0x13a>
            if (readi(ip, 0, (uint64)(mem + dst_off),
    80204b0a:	2981                	sext.w	s3,s3
    80204b0c:	874e                	mv	a4,s3
    80204b0e:	e9843683          	ld	a3,-360(s0)
    80204b12:	9ebd                	addw	a3,a3,a5
    80204b14:	964a                	add	a2,a2,s2
    80204b16:	4581                	li	a1,0
    80204b18:	855a                	mv	a0,s6
    80204b1a:	00001097          	auipc	ra,0x1
    80204b1e:	f00080e7          	jalr	-256(ra) # 80205a1a <readi>
    80204b22:	05351f63          	bne	a0,s3,80204b80 <exec+0x152>
        if (mappages(pt, va, PGSIZE, (uint64)mem, perm) != 0) {
    80204b26:	875e                	mv	a4,s7
    80204b28:	86ca                	mv	a3,s2
    80204b2a:	8652                	mv	a2,s4
    80204b2c:	85a6                	mv	a1,s1
    80204b2e:	8562                	mv	a0,s8
    80204b30:	ffffe097          	auipc	ra,0xffffe
    80204b34:	074080e7          	jalr	116(ra) # 80202ba4 <mappages>
    80204b38:	e931                	bnez	a0,80204b8c <exec+0x15e>
    for (uint64 va = start; va < end; va += PGSIZE) {
    80204b3a:	94d2                	add	s1,s1,s4
    80204b3c:	0554fe63          	bgeu	s1,s5,80204b98 <exec+0x16a>
        char *mem = palloc();
    80204b40:	ffffc097          	auipc	ra,0xffffc
    80204b44:	55a080e7          	jalr	1370(ra) # 8020109a <palloc>
    80204b48:	892a                	mv	s2,a0
        if (!mem) return -1;
    80204b4a:	1c050063          	beqz	a0,80204d0a <exec+0x2dc>
        memset(mem, 0, PGSIZE);                    /* zero first: this IS the .bss */
    80204b4e:	8652                	mv	a2,s4
    80204b50:	4581                	li	a1,0
    80204b52:	ffffc097          	auipc	ra,0xffffc
    80204b56:	b46080e7          	jalr	-1210(ra) # 80200698 <memset>
        uint64 seg_off = (va > ph->vaddr) ? (va - ph->vaddr) : 0;
    80204b5a:	ea043603          	ld	a2,-352(s0)
    80204b5e:	f8967ee3          	bgeu	a2,s1,80204afa <exec+0xcc>
    80204b62:	40c487b3          	sub	a5,s1,a2
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    80204b66:	4601                	li	a2,0
        if (seg_off < ph->filesz) {
    80204b68:	eb043983          	ld	s3,-336(s0)
    80204b6c:	fb37fde3          	bgeu	a5,s3,80204b26 <exec+0xf8>
            if (n > PGSIZE - dst_off) n = PGSIZE - dst_off;
    80204b70:	40ca0733          	sub	a4,s4,a2
    80204b74:	40f989b3          	sub	s3,s3,a5
    80204b78:	f93779e3          	bgeu	a4,s3,80204b0a <exec+0xdc>
    80204b7c:	89ba                	mv	s3,a4
    80204b7e:	b771                	j	80204b0a <exec+0xdc>
                pfree(mem);
    80204b80:	854a                	mv	a0,s2
    80204b82:	ffffc097          	auipc	ra,0xffffc
    80204b86:	628080e7          	jalr	1576(ra) # 802011aa <pfree>
                return -1;
    80204b8a:	a241                	j	80204d0a <exec+0x2dc>
            pfree(mem);
    80204b8c:	854a                	mv	a0,s2
    80204b8e:	ffffc097          	auipc	ra,0xffffc
    80204b92:	61c080e7          	jalr	1564(ra) # 802011aa <pfree>
            return -1;
    80204b96:	aa95                	j	80204d0a <exec+0x2dc>
        if (ph.vaddr + ph.memsz > sz) sz = ph.vaddr + ph.memsz;
    80204b98:	ea043783          	ld	a5,-352(s0)
    80204b9c:	eb843703          	ld	a4,-328(s0)
    80204ba0:	97ba                	add	a5,a5,a4
    80204ba2:	e8843703          	ld	a4,-376(s0)
    80204ba6:	00f77463          	bgeu	a4,a5,80204bae <exec+0x180>
    80204baa:	e8f43423          	sd	a5,-376(s0)
    for (int i = 0; i < eh.phnum; i++) {
    80204bae:	2d05                	addiw	s10,s10,1
    80204bb0:	038c8c9b          	addiw	s9,s9,56
    80204bb4:	f8845783          	lhu	a5,-120(s0)
    80204bb8:	08fd5563          	bge	s10,a5,80204c42 <exec+0x214>
        if (readi(ip, 0, (uint64)&ph, eh.phoff + i * sizeof(ph),
    80204bbc:	03800713          	li	a4,56
    80204bc0:	f7043683          	ld	a3,-144(s0)
    80204bc4:	019686bb          	addw	a3,a3,s9
    80204bc8:	e9040613          	addi	a2,s0,-368
    80204bcc:	4581                	li	a1,0
    80204bce:	855a                	mv	a0,s6
    80204bd0:	00001097          	auipc	ra,0x1
    80204bd4:	e4a080e7          	jalr	-438(ra) # 80205a1a <readi>
    80204bd8:	03800793          	li	a5,56
    80204bdc:	12f51763          	bne	a0,a5,80204d0a <exec+0x2dc>
        if (ph.type != ELF_PROG_LOAD) continue;
    80204be0:	e9042783          	lw	a5,-368(s0)
    80204be4:	fdb795e3          	bne	a5,s11,80204bae <exec+0x180>
        if (ph.memsz < ph.filesz) goto bad;           /* malformed */
    80204be8:	eb843a83          	ld	s5,-328(s0)
    80204bec:	eb043783          	ld	a5,-336(s0)
    80204bf0:	10faed63          	bltu	s5,a5,80204d0a <exec+0x2dc>
        if (ph.vaddr + ph.memsz < ph.vaddr) goto bad; /* overflow  */
    80204bf4:	ea043483          	ld	s1,-352(s0)
    80204bf8:	9aa6                	add	s5,s5,s1
    80204bfa:	109ae863          	bltu	s5,s1,80204d0a <exec+0x2dc>
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    80204bfe:	e7043783          	ld	a5,-400(s0)
    80204c02:	1157e463          	bltu	a5,s5,80204d0a <exec+0x2dc>
    if (ph->flags & ELF_PROG_FLAG_READ)  perm |= PTE_R;
    80204c06:	e9442783          	lw	a5,-364(s0)
    80204c0a:	0047f713          	andi	a4,a5,4
    80204c0e:	4bc9                	li	s7,18
    80204c10:	e311                	bnez	a4,80204c14 <exec+0x1e6>
    int perm = PTE_U;
    80204c12:	4bc1                	li	s7,16
    if (ph->flags & ELF_PROG_FLAG_WRITE) perm |= PTE_W;
    80204c14:	0027f713          	andi	a4,a5,2
    80204c18:	c319                	beqz	a4,80204c1e <exec+0x1f0>
    80204c1a:	004beb93          	ori	s7,s7,4
    if (ph->flags & ELF_PROG_FLAG_EXEC)  perm |= PTE_X;
    80204c1e:	8b85                	andi	a5,a5,1
    80204c20:	0037979b          	slliw	a5,a5,0x3
    80204c24:	00fbebb3          	or	s7,s7,a5
    80204c28:	2b81                	sext.w	s7,s7
    uint64 start = PGROUNDDOWN(ph->vaddr);
    80204c2a:	77fd                	lui	a5,0xfffff
    80204c2c:	8cfd                	and	s1,s1,a5
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    80204c2e:	e6843703          	ld	a4,-408(s0)
    80204c32:	9aba                	add	s5,s5,a4
    80204c34:	00fafab3          	and	s5,s5,a5
    for (uint64 va = start; va < end; va += PGSIZE) {
    80204c38:	f154e4e3          	bltu	s1,s5,80204b40 <exec+0x112>
    80204c3c:	bfb1                	j	80204b98 <exec+0x16a>
    uint64 sz = 0;
    80204c3e:	e8043423          	sd	zero,-376(s0)
    iunlockput(ip);
    80204c42:	855a                	mv	a0,s6
    80204c44:	00001097          	auipc	ra,0x1
    80204c48:	d84080e7          	jalr	-636(ra) # 802059c8 <iunlockput>
    sz = PGROUNDUP(sz);
    80204c4c:	6785                	lui	a5,0x1
    80204c4e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80204c50:	e8843703          	ld	a4,-376(s0)
    80204c54:	97ba                	add	a5,a5,a4
    80204c56:	7dfd                	lui	s11,0xfffff
    80204c58:	01b7f4b3          	and	s1,a5,s11
    80204c5c:	e8943423          	sd	s1,-376(s0)
    char *stack = palloc();
    80204c60:	ffffc097          	auipc	ra,0xffffc
    80204c64:	43a080e7          	jalr	1082(ra) # 8020109a <palloc>
    80204c68:	8b2a                	mv	s6,a0
    if (!stack) goto bad;
    80204c6a:	c145                	beqz	a0,80204d0a <exec+0x2dc>
    uint64 stackbase = guard + PGSIZE;
    80204c6c:	6a85                	lui	s5,0x1
    80204c6e:	9aa6                	add	s5,s5,s1
    memset(stack, 0, PGSIZE);
    80204c70:	6605                	lui	a2,0x1
    80204c72:	4581                	li	a1,0
    80204c74:	ffffc097          	auipc	ra,0xffffc
    80204c78:	a24080e7          	jalr	-1500(ra) # 80200698 <memset>
    if (mappages(newpt, stackbase, PGSIZE, (uint64)stack,
    80204c7c:	4759                	li	a4,22
    80204c7e:	86da                	mv	a3,s6
    80204c80:	6605                	lui	a2,0x1
    80204c82:	85d6                	mv	a1,s5
    80204c84:	8562                	mv	a0,s8
    80204c86:	ffffe097          	auipc	ra,0xffffe
    80204c8a:	f1e080e7          	jalr	-226(ra) # 80202ba4 <mappages>
    80204c8e:	84aa                	mv	s1,a0
    80204c90:	e505                	bnez	a0,80204cb8 <exec+0x28a>
    uint64 sp    = stackbase + PGSIZE;
    80204c92:	6789                	lui	a5,0x2
    80204c94:	e8843703          	ld	a4,-376(s0)
    80204c98:	00f70d33          	add	s10,a4,a5
    struct proc *pp = myproc();
    80204c9c:	ffffd097          	auipc	ra,0xffffd
    80204ca0:	aca080e7          	jalr	-1334(ra) # 80201766 <myproc>
    80204ca4:	8baa                	mv	s7,a0
    for (; argv && argv[argc]; argc++) {
    80204ca6:	e7843783          	ld	a5,-392(s0)
    80204caa:	c7c9                	beqz	a5,80204d34 <exec+0x306>
    80204cac:	893e                	mv	s2,a5
    80204cae:	ec840a13          	addi	s4,s0,-312
    uint64 sp    = stackbase + PGSIZE;
    80204cb2:	89ea                	mv	s3,s10
        if (argc >= MAXARG) goto bad;
    80204cb4:	4cc1                	li	s9,16
    80204cb6:	a821                	j	80204cce <exec+0x2a0>
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    80204cb8:	855a                	mv	a0,s6
    80204cba:	ffffc097          	auipc	ra,0xffffc
    80204cbe:	4f0080e7          	jalr	1264(ra) # 802011aa <pfree>
    ip = 0;
    80204cc2:	4b01                	li	s6,0
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    80204cc4:	a099                	j	80204d0a <exec+0x2dc>
        ustack[argc] = sp;
    80204cc6:	013a3023          	sd	s3,0(s4)
    for (; argv && argv[argc]; argc++) {
    80204cca:	2485                	addiw	s1,s1,1
    80204ccc:	0a21                	addi	s4,s4,8
    80204cce:	8b4a                	mv	s6,s2
    80204cd0:	00093503          	ld	a0,0(s2)
    80204cd4:	c12d                	beqz	a0,80204d36 <exec+0x308>
        if (argc >= MAXARG) goto bad;
    80204cd6:	03948963          	beq	s1,s9,80204d08 <exec+0x2da>
        uint64 len = strlen(argv[argc]) + 1;
    80204cda:	ffffc097          	auipc	ra,0xffffc
    80204cde:	abc080e7          	jalr	-1348(ra) # 80200796 <strlen>
    80204ce2:	0015069b          	addiw	a3,a0,1
        sp -= len;
    80204ce6:	40d989b3          	sub	s3,s3,a3
        sp &= ~7UL;                                   /* keep it 8-aligned */
    80204cea:	ff89f993          	andi	s3,s3,-8
        if (sp < stackbase) goto bad;
    80204cee:	0159ed63          	bltu	s3,s5,80204d08 <exec+0x2da>
        if (copyout(newpt, sp, argv[argc], len) < 0) goto bad;
    80204cf2:	000b3603          	ld	a2,0(s6) # 1000 <_entry-0x801ff000>
    80204cf6:	85ce                	mv	a1,s3
    80204cf8:	8562                	mv	a0,s8
    80204cfa:	ffffe097          	auipc	ra,0xffffe
    80204cfe:	284080e7          	jalr	644(ra) # 80202f7e <copyout>
    80204d02:	0921                	addi	s2,s2,8
    80204d04:	fc0551e3          	bgez	a0,80204cc6 <exec+0x298>
    if (newpt) uvmfree(newpt, sz);
    80204d08:	4b01                	li	s6,0
    80204d0a:	e8843583          	ld	a1,-376(s0)
    80204d0e:	8562                	mv	a0,s8
    80204d10:	ffffe097          	auipc	ra,0xffffe
    80204d14:	166080e7          	jalr	358(ra) # 80202e76 <uvmfree>
    return -1;
    80204d18:	54fd                	li	s1,-1
    if (ip) iunlockput(ip);
    80204d1a:	0e0b1c63          	bnez	s6,80204e12 <exec+0x3e4>
    80204d1e:	691a                	ld	s2,384(sp)
    80204d20:	79f6                	ld	s3,376(sp)
    80204d22:	7a56                	ld	s4,368(sp)
    80204d24:	7ab6                	ld	s5,360(sp)
    80204d26:	7b16                	ld	s6,352(sp)
    80204d28:	6bf6                	ld	s7,344(sp)
    80204d2a:	6c56                	ld	s8,336(sp)
    80204d2c:	6cb6                	ld	s9,328(sp)
    80204d2e:	6d16                	ld	s10,320(sp)
    80204d30:	7df2                	ld	s11,312(sp)
    80204d32:	bb8d                	j	80204aa4 <exec+0x76>
    uint64 sp    = stackbase + PGSIZE;
    80204d34:	89ea                	mv	s3,s10
    ustack[argc] = 0;
    80204d36:	00349793          	slli	a5,s1,0x3
    80204d3a:	f9078793          	addi	a5,a5,-112 # 1f90 <_entry-0x801fe070>
    80204d3e:	97a2                	add	a5,a5,s0
    80204d40:	f207bc23          	sd	zero,-200(a5)
    sp -= (argc + 1) * sizeof(uint64);
    80204d44:	0014869b          	addiw	a3,s1,1
    80204d48:	068e                	slli	a3,a3,0x3
    80204d4a:	40d98933          	sub	s2,s3,a3
    sp &= ~15UL;                                      /* 16-byte ABI alignment */
    80204d4e:	ff097913          	andi	s2,s2,-16
    ip = 0;
    80204d52:	4b01                	li	s6,0
    if (sp < stackbase) goto bad;
    80204d54:	fb596be3          	bltu	s2,s5,80204d0a <exec+0x2dc>
    if (copyout(newpt, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) < 0) goto bad;
    80204d58:	ec840613          	addi	a2,s0,-312
    80204d5c:	85ca                	mv	a1,s2
    80204d5e:	8562                	mv	a0,s8
    80204d60:	ffffe097          	auipc	ra,0xffffe
    80204d64:	21e080e7          	jalr	542(ra) # 80202f7e <copyout>
    80204d68:	0c054363          	bltz	a0,80204e2e <exec+0x400>
    pagetable_t oldpt = pp->pagetable;
    80204d6c:	050bb983          	ld	s3,80(s7)
    uint64      oldsz = pp->sz;
    80204d70:	048bba03          	ld	s4,72(s7)
    if (usysinfo_remap(pp, newpt) < 0) goto bad;
    80204d74:	85e2                	mv	a1,s8
    80204d76:	855e                	mv	a0,s7
    80204d78:	00000097          	auipc	ra,0x0
    80204d7c:	8f2080e7          	jalr	-1806(ra) # 8020466a <usysinfo_remap>
    80204d80:	0a054963          	bltz	a0,80204e32 <exec+0x404>
    pp->pagetable = newpt;
    80204d84:	058bb823          	sd	s8,80(s7)
    pp->sz        = newsz;
    80204d88:	05abb423          	sd	s10,72(s7)
    pp->tf->epc   = eh.entry;
    80204d8c:	058bb783          	ld	a5,88(s7)
    80204d90:	f6843703          	ld	a4,-152(s0)
    80204d94:	ef98                	sd	a4,24(a5)
    pp->tf->sp    = sp;
    80204d96:	058bb783          	ld	a5,88(s7)
    80204d9a:	0327b823          	sd	s2,48(a5)
    pp->tf->a1    = sp;                               /* argv for main() */
    80204d9e:	058bb783          	ld	a5,88(s7)
    80204da2:	0727bc23          	sd	s2,120(a5)
    for (const char *s = path; *s; s++) if (*s == '/') last = s + 1;
    80204da6:	e8043783          	ld	a5,-384(s0)
    80204daa:	0007c703          	lbu	a4,0(a5)
    80204dae:	cf11                	beqz	a4,80204dca <exec+0x39c>
    80204db0:	0785                	addi	a5,a5,1
    80204db2:	02f00693          	li	a3,47
    80204db6:	a029                	j	80204dc0 <exec+0x392>
    80204db8:	0785                	addi	a5,a5,1
    80204dba:	fff7c703          	lbu	a4,-1(a5)
    80204dbe:	c711                	beqz	a4,80204dca <exec+0x39c>
    80204dc0:	fed71ce3          	bne	a4,a3,80204db8 <exec+0x38a>
    80204dc4:	e8f43023          	sd	a5,-384(s0)
    80204dc8:	bfc5                	j	80204db8 <exec+0x38a>
    strncpy(pp->name, last, sizeof(pp->name));
    80204dca:	4641                	li	a2,16
    80204dcc:	e8043583          	ld	a1,-384(s0)
    80204dd0:	158b8513          	addi	a0,s7,344
    80204dd4:	ffffc097          	auipc	ra,0xffffc
    80204dd8:	986080e7          	jalr	-1658(ra) # 8020075a <strncpy>
    w_satp(MAKE_SATP(pp->pagetable));                 /* we are running on it now */
    80204ddc:	050bb783          	ld	a5,80(s7)
    80204de0:	83b1                	srli	a5,a5,0xc
    80204de2:	577d                	li	a4,-1
    80204de4:	177e                	slli	a4,a4,0x3f
    80204de6:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80204de8:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80204dec:	12000073          	sfence.vma
    uvmfree(oldpt, oldsz);
    80204df0:	85d2                	mv	a1,s4
    80204df2:	854e                	mv	a0,s3
    80204df4:	ffffe097          	auipc	ra,0xffffe
    80204df8:	082080e7          	jalr	130(ra) # 80202e76 <uvmfree>
    return argc;
    80204dfc:	691a                	ld	s2,384(sp)
    80204dfe:	79f6                	ld	s3,376(sp)
    80204e00:	7a56                	ld	s4,368(sp)
    80204e02:	7ab6                	ld	s5,360(sp)
    80204e04:	7b16                	ld	s6,352(sp)
    80204e06:	6bf6                	ld	s7,344(sp)
    80204e08:	6c56                	ld	s8,336(sp)
    80204e0a:	6cb6                	ld	s9,328(sp)
    80204e0c:	6d16                	ld	s10,320(sp)
    80204e0e:	7df2                	ld	s11,312(sp)
    80204e10:	b951                	j	80204aa4 <exec+0x76>
    80204e12:	691a                	ld	s2,384(sp)
    80204e14:	79f6                	ld	s3,376(sp)
    80204e16:	7a56                	ld	s4,368(sp)
    80204e18:	7ab6                	ld	s5,360(sp)
    80204e1a:	6bf6                	ld	s7,344(sp)
    80204e1c:	6c56                	ld	s8,336(sp)
    80204e1e:	6cb6                	ld	s9,328(sp)
    80204e20:	6d16                	ld	s10,320(sp)
    80204e22:	7df2                	ld	s11,312(sp)
    80204e24:	b98d                	j	80204a96 <exec+0x68>
    80204e26:	6c56                	ld	s8,336(sp)
    80204e28:	b1bd                	j	80204a96 <exec+0x68>
    if (ip == 0) return -1;
    80204e2a:	54fd                	li	s1,-1
    80204e2c:	b9a5                	j	80204aa4 <exec+0x76>
    ip = 0;
    80204e2e:	4b01                	li	s6,0
    80204e30:	bde9                	j	80204d0a <exec+0x2dc>
    80204e32:	4b01                	li	s6,0
    if (newpt) uvmfree(newpt, sz);
    80204e34:	bdd9                	j	80204d0a <exec+0x2dc>

0000000080204e36 <binit>:
    struct buf buf[NBUF];
    struct buf head;          /* LRU list: head.next = most recent */
} bcache;

void binit(void)
{
    80204e36:	7179                	addi	sp,sp,-48
    80204e38:	f406                	sd	ra,40(sp)
    80204e3a:	f022                	sd	s0,32(sp)
    80204e3c:	ec26                	sd	s1,24(sp)
    80204e3e:	e84a                	sd	s2,16(sp)
    80204e40:	e44e                	sd	s3,8(sp)
    80204e42:	e052                	sd	s4,0(sp)
    80204e44:	1800                	addi	s0,sp,48
    initlock(&bcache.lock, "bcache");
    80204e46:	00003597          	auipc	a1,0x3
    80204e4a:	b2a58593          	addi	a1,a1,-1238 # 80207970 <etext+0x970>
    80204e4e:	00136517          	auipc	a0,0x136
    80204e52:	7b250513          	addi	a0,a0,1970 # 8033b600 <bcache>
    80204e56:	ffffc097          	auipc	ra,0xffffc
    80204e5a:	456080e7          	jalr	1110(ra) # 802012ac <initlock>
    bcache.head.prev = &bcache.head;
    80204e5e:	0013e797          	auipc	a5,0x13e
    80204e62:	7a278793          	addi	a5,a5,1954 # 80343600 <bcache+0x8000>
    80204e66:	0013f717          	auipc	a4,0x13f
    80204e6a:	a0270713          	addi	a4,a4,-1534 # 80343868 <bcache+0x8268>
    80204e6e:	2ae7b823          	sd	a4,688(a5)
    bcache.head.next = &bcache.head;
    80204e72:	2ae7bc23          	sd	a4,696(a5)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80204e76:	00136497          	auipc	s1,0x136
    80204e7a:	7a248493          	addi	s1,s1,1954 # 8033b618 <bcache+0x18>
        b->next = bcache.head.next;
    80204e7e:	893e                	mv	s2,a5
        b->prev = &bcache.head;
    80204e80:	89ba                	mv	s3,a4
        initsleeplock(&b->lock, "buffer");
    80204e82:	00003a17          	auipc	s4,0x3
    80204e86:	af6a0a13          	addi	s4,s4,-1290 # 80207978 <etext+0x978>
        b->next = bcache.head.next;
    80204e8a:	2b893783          	ld	a5,696(s2)
    80204e8e:	e8bc                	sd	a5,80(s1)
        b->prev = &bcache.head;
    80204e90:	0534b423          	sd	s3,72(s1)
        initsleeplock(&b->lock, "buffer");
    80204e94:	85d2                	mv	a1,s4
    80204e96:	01048513          	addi	a0,s1,16
    80204e9a:	ffffc097          	auipc	ra,0xffffc
    80204e9e:	58a080e7          	jalr	1418(ra) # 80201424 <initsleeplock>
        bcache.head.next->prev = b;
    80204ea2:	2b893783          	ld	a5,696(s2)
    80204ea6:	e7a4                	sd	s1,72(a5)
        bcache.head.next = b;
    80204ea8:	2a993c23          	sd	s1,696(s2)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80204eac:	45848493          	addi	s1,s1,1112
    80204eb0:	fd349de3          	bne	s1,s3,80204e8a <binit+0x54>
    }
}
    80204eb4:	70a2                	ld	ra,40(sp)
    80204eb6:	7402                	ld	s0,32(sp)
    80204eb8:	64e2                	ld	s1,24(sp)
    80204eba:	6942                	ld	s2,16(sp)
    80204ebc:	69a2                	ld	s3,8(sp)
    80204ebe:	6a02                	ld	s4,0(sp)
    80204ec0:	6145                	addi	sp,sp,48
    80204ec2:	8082                	ret

0000000080204ec4 <bread>:
    }
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
}

struct buf *bread(uint32 dev, uint32 blockno)
{
    80204ec4:	7179                	addi	sp,sp,-48
    80204ec6:	f406                	sd	ra,40(sp)
    80204ec8:	f022                	sd	s0,32(sp)
    80204eca:	ec26                	sd	s1,24(sp)
    80204ecc:	e84a                	sd	s2,16(sp)
    80204ece:	e44e                	sd	s3,8(sp)
    80204ed0:	1800                	addi	s0,sp,48
    80204ed2:	892a                	mv	s2,a0
    80204ed4:	89ae                	mv	s3,a1
    acquire(&bcache.lock);
    80204ed6:	00136517          	auipc	a0,0x136
    80204eda:	72a50513          	addi	a0,a0,1834 # 8033b600 <bcache>
    80204ede:	ffffc097          	auipc	ra,0xffffc
    80204ee2:	44a080e7          	jalr	1098(ra) # 80201328 <acquire>
    for (struct buf *b = bcache.head.next; b != &bcache.head; b = b->next) {
    80204ee6:	0013f497          	auipc	s1,0x13f
    80204eea:	9d24b483          	ld	s1,-1582(s1) # 803438b8 <bcache+0x82b8>
    80204eee:	0013f797          	auipc	a5,0x13f
    80204ef2:	97a78793          	addi	a5,a5,-1670 # 80343868 <bcache+0x8268>
    80204ef6:	02f48f63          	beq	s1,a5,80204f34 <bread+0x70>
    80204efa:	873e                	mv	a4,a5
    80204efc:	a021                	j	80204f04 <bread+0x40>
    80204efe:	68a4                	ld	s1,80(s1)
    80204f00:	02e48a63          	beq	s1,a4,80204f34 <bread+0x70>
        if (b->dev == dev && b->blockno == blockno) {
    80204f04:	449c                	lw	a5,8(s1)
    80204f06:	ff279ce3          	bne	a5,s2,80204efe <bread+0x3a>
    80204f0a:	44dc                	lw	a5,12(s1)
    80204f0c:	ff3799e3          	bne	a5,s3,80204efe <bread+0x3a>
            b->refcnt++;
    80204f10:	40bc                	lw	a5,64(s1)
    80204f12:	2785                	addiw	a5,a5,1
    80204f14:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    80204f16:	00136517          	auipc	a0,0x136
    80204f1a:	6ea50513          	addi	a0,a0,1770 # 8033b600 <bcache>
    80204f1e:	ffffc097          	auipc	ra,0xffffc
    80204f22:	4be080e7          	jalr	1214(ra) # 802013dc <release>
            acquiresleep(&b->lock);
    80204f26:	01048513          	addi	a0,s1,16
    80204f2a:	ffffc097          	auipc	ra,0xffffc
    80204f2e:	534080e7          	jalr	1332(ra) # 8020145e <acquiresleep>
            return b;
    80204f32:	a8b9                	j	80204f90 <bread+0xcc>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80204f34:	0013f497          	auipc	s1,0x13f
    80204f38:	97c4b483          	ld	s1,-1668(s1) # 803438b0 <bcache+0x82b0>
    80204f3c:	0013f797          	auipc	a5,0x13f
    80204f40:	92c78793          	addi	a5,a5,-1748 # 80343868 <bcache+0x8268>
    80204f44:	00f48863          	beq	s1,a5,80204f54 <bread+0x90>
    80204f48:	873e                	mv	a4,a5
        if (b->refcnt == 0) {
    80204f4a:	40bc                	lw	a5,64(s1)
    80204f4c:	cf81                	beqz	a5,80204f64 <bread+0xa0>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80204f4e:	64a4                	ld	s1,72(s1)
    80204f50:	fee49de3          	bne	s1,a4,80204f4a <bread+0x86>
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
    80204f54:	00003517          	auipc	a0,0x3
    80204f58:	a2c50513          	addi	a0,a0,-1492 # 80207980 <etext+0x980>
    80204f5c:	ffffb097          	auipc	ra,0xffffb
    80204f60:	696080e7          	jalr	1686(ra) # 802005f2 <panic>
            b->dev = dev;
    80204f64:	0124a423          	sw	s2,8(s1)
            b->blockno = blockno;
    80204f68:	0134a623          	sw	s3,12(s1)
            b->valid = 0;
    80204f6c:	0004a023          	sw	zero,0(s1)
            b->refcnt = 1;
    80204f70:	4785                	li	a5,1
    80204f72:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    80204f74:	00136517          	auipc	a0,0x136
    80204f78:	68c50513          	addi	a0,a0,1676 # 8033b600 <bcache>
    80204f7c:	ffffc097          	auipc	ra,0xffffc
    80204f80:	460080e7          	jalr	1120(ra) # 802013dc <release>
            acquiresleep(&b->lock);
    80204f84:	01048513          	addi	a0,s1,16
    80204f88:	ffffc097          	auipc	ra,0xffffc
    80204f8c:	4d6080e7          	jalr	1238(ra) # 8020145e <acquiresleep>
    struct buf *b = bget(dev, blockno);
    if (!b->valid) {
    80204f90:	409c                	lw	a5,0(s1)
    80204f92:	cb89                	beqz	a5,80204fa4 <bread+0xe0>
        hal_block_rw(b, 0);
        b->valid = 1;
    }
    return b;
}
    80204f94:	8526                	mv	a0,s1
    80204f96:	70a2                	ld	ra,40(sp)
    80204f98:	7402                	ld	s0,32(sp)
    80204f9a:	64e2                	ld	s1,24(sp)
    80204f9c:	6942                	ld	s2,16(sp)
    80204f9e:	69a2                	ld	s3,8(sp)
    80204fa0:	6145                	addi	sp,sp,48
    80204fa2:	8082                	ret
        hal_block_rw(b, 0);
    80204fa4:	4581                	li	a1,0
    80204fa6:	8526                	mv	a0,s1
    80204fa8:	00002097          	auipc	ra,0x2
    80204fac:	c46080e7          	jalr	-954(ra) # 80206bee <hal_block_rw>
        b->valid = 1;
    80204fb0:	4785                	li	a5,1
    80204fb2:	c09c                	sw	a5,0(s1)
    return b;
    80204fb4:	b7c5                	j	80204f94 <bread+0xd0>

0000000080204fb6 <bwrite>:

/* Caller must hold b->lock (i.e. this buf came from bread). */
void bwrite(struct buf *b)
{
    80204fb6:	1101                	addi	sp,sp,-32
    80204fb8:	ec06                	sd	ra,24(sp)
    80204fba:	e822                	sd	s0,16(sp)
    80204fbc:	e426                	sd	s1,8(sp)
    80204fbe:	1000                	addi	s0,sp,32
    80204fc0:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80204fc2:	0541                	addi	a0,a0,16
    80204fc4:	ffffc097          	auipc	ra,0xffffc
    80204fc8:	534080e7          	jalr	1332(ra) # 802014f8 <holdingsleep>
    80204fcc:	cd01                	beqz	a0,80204fe4 <bwrite+0x2e>
    hal_block_rw(b, 1);
    80204fce:	4585                	li	a1,1
    80204fd0:	8526                	mv	a0,s1
    80204fd2:	00002097          	auipc	ra,0x2
    80204fd6:	c1c080e7          	jalr	-996(ra) # 80206bee <hal_block_rw>
}
    80204fda:	60e2                	ld	ra,24(sp)
    80204fdc:	6442                	ld	s0,16(sp)
    80204fde:	64a2                	ld	s1,8(sp)
    80204fe0:	6105                	addi	sp,sp,32
    80204fe2:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80204fe4:	00003517          	auipc	a0,0x3
    80204fe8:	9dc50513          	addi	a0,a0,-1572 # 802079c0 <etext+0x9c0>
    80204fec:	ffffb097          	auipc	ra,0xffffb
    80204ff0:	606080e7          	jalr	1542(ra) # 802005f2 <panic>

0000000080204ff4 <brelse>:

void brelse(struct buf *b)
{
    80204ff4:	1101                	addi	sp,sp,-32
    80204ff6:	ec06                	sd	ra,24(sp)
    80204ff8:	e822                	sd	s0,16(sp)
    80204ffa:	e426                	sd	s1,8(sp)
    80204ffc:	e04a                	sd	s2,0(sp)
    80204ffe:	1000                	addi	s0,sp,32
    80205000:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80205002:	01050913          	addi	s2,a0,16
    80205006:	854a                	mv	a0,s2
    80205008:	ffffc097          	auipc	ra,0xffffc
    8020500c:	4f0080e7          	jalr	1264(ra) # 802014f8 <holdingsleep>
    80205010:	c925                	beqz	a0,80205080 <brelse+0x8c>
    releasesleep(&b->lock);
    80205012:	854a                	mv	a0,s2
    80205014:	ffffc097          	auipc	ra,0xffffc
    80205018:	4a0080e7          	jalr	1184(ra) # 802014b4 <releasesleep>

    acquire(&bcache.lock);
    8020501c:	00136517          	auipc	a0,0x136
    80205020:	5e450513          	addi	a0,a0,1508 # 8033b600 <bcache>
    80205024:	ffffc097          	auipc	ra,0xffffc
    80205028:	304080e7          	jalr	772(ra) # 80201328 <acquire>
    b->refcnt--;
    8020502c:	40bc                	lw	a5,64(s1)
    8020502e:	37fd                	addiw	a5,a5,-1
    80205030:	0007871b          	sext.w	a4,a5
    80205034:	c0bc                	sw	a5,64(s1)
    if (b->refcnt == 0) {
    80205036:	e71d                	bnez	a4,80205064 <brelse+0x70>
        /* Move to the front: most recently used. */
        b->next->prev = b->prev;
    80205038:	68b8                	ld	a4,80(s1)
    8020503a:	64bc                	ld	a5,72(s1)
    8020503c:	e73c                	sd	a5,72(a4)
        b->prev->next = b->next;
    8020503e:	68b8                	ld	a4,80(s1)
    80205040:	ebb8                	sd	a4,80(a5)
        b->next = bcache.head.next;
    80205042:	0013e797          	auipc	a5,0x13e
    80205046:	5be78793          	addi	a5,a5,1470 # 80343600 <bcache+0x8000>
    8020504a:	2b87b703          	ld	a4,696(a5)
    8020504e:	e8b8                	sd	a4,80(s1)
        b->prev = &bcache.head;
    80205050:	0013f717          	auipc	a4,0x13f
    80205054:	81870713          	addi	a4,a4,-2024 # 80343868 <bcache+0x8268>
    80205058:	e4b8                	sd	a4,72(s1)
        bcache.head.next->prev = b;
    8020505a:	2b87b703          	ld	a4,696(a5)
    8020505e:	e724                	sd	s1,72(a4)
        bcache.head.next = b;
    80205060:	2a97bc23          	sd	s1,696(a5)
    }
    release(&bcache.lock);
    80205064:	00136517          	auipc	a0,0x136
    80205068:	59c50513          	addi	a0,a0,1436 # 8033b600 <bcache>
    8020506c:	ffffc097          	auipc	ra,0xffffc
    80205070:	370080e7          	jalr	880(ra) # 802013dc <release>
}
    80205074:	60e2                	ld	ra,24(sp)
    80205076:	6442                	ld	s0,16(sp)
    80205078:	64a2                	ld	s1,8(sp)
    8020507a:	6902                	ld	s2,0(sp)
    8020507c:	6105                	addi	sp,sp,32
    8020507e:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80205080:	00003517          	auipc	a0,0x3
    80205084:	95850513          	addi	a0,a0,-1704 # 802079d8 <etext+0x9d8>
    80205088:	ffffb097          	auipc	ra,0xffffb
    8020508c:	56a080e7          	jalr	1386(ra) # 802005f2 <panic>

0000000080205090 <bfree>:
    printf("luitfs: out of data blocks\n");
    return 0;
}

static void bfree(int dev, uint32 b)
{
    80205090:	1101                	addi	sp,sp,-32
    80205092:	ec06                	sd	ra,24(sp)
    80205094:	e822                	sd	s0,16(sp)
    80205096:	e426                	sd	s1,8(sp)
    80205098:	e04a                	sd	s2,0(sp)
    8020509a:	1000                	addi	s0,sp,32
    8020509c:	84ae                	mv	s1,a1
    struct buf *bp = bread(dev, DBBLOCK(b, sb));
    8020509e:	00d5d59b          	srliw	a1,a1,0xd
    802050a2:	0013f797          	auipc	a5,0x13f
    802050a6:	c367a783          	lw	a5,-970(a5) # 80343cd8 <sb+0x18>
    802050aa:	9dbd                	addw	a1,a1,a5
    802050ac:	00000097          	auipc	ra,0x0
    802050b0:	e18080e7          	jalr	-488(ra) # 80204ec4 <bread>
    uint32 bi = b % BPB;
    int m = 1 << (bi % 8);
    802050b4:	0074f713          	andi	a4,s1,7
    802050b8:	4785                	li	a5,1
    802050ba:	00e797bb          	sllw	a5,a5,a4
    uint32 bi = b % BPB;
    802050be:	14ce                	slli	s1,s1,0x33
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    802050c0:	0364d713          	srli	a4,s1,0x36
    802050c4:	00e504b3          	add	s1,a0,a4
    802050c8:	0584c683          	lbu	a3,88(s1)
    802050cc:	00d7f633          	and	a2,a5,a3
    802050d0:	ca0d                	beqz	a2,80205102 <bfree+0x72>
    802050d2:	892a                	mv	s2,a0
    bp->data[bi / 8] &= ~m;
    802050d4:	1702                	slli	a4,a4,0x20
    802050d6:	9301                	srli	a4,a4,0x20
    802050d8:	972a                	add	a4,a4,a0
    802050da:	fff7c793          	not	a5,a5
    802050de:	8efd                	and	a3,a3,a5
    802050e0:	04d70c23          	sb	a3,88(a4)
    bwrite(bp);
    802050e4:	00000097          	auipc	ra,0x0
    802050e8:	ed2080e7          	jalr	-302(ra) # 80204fb6 <bwrite>
    brelse(bp);
    802050ec:	854a                	mv	a0,s2
    802050ee:	00000097          	auipc	ra,0x0
    802050f2:	f06080e7          	jalr	-250(ra) # 80204ff4 <brelse>
}
    802050f6:	60e2                	ld	ra,24(sp)
    802050f8:	6442                	ld	s0,16(sp)
    802050fa:	64a2                	ld	s1,8(sp)
    802050fc:	6902                	ld	s2,0(sp)
    802050fe:	6105                	addi	sp,sp,32
    80205100:	8082                	ret
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80205102:	00003517          	auipc	a0,0x3
    80205106:	8ee50513          	addi	a0,a0,-1810 # 802079f0 <etext+0x9f0>
    8020510a:	ffffb097          	auipc	ra,0xffffb
    8020510e:	4e8080e7          	jalr	1256(ra) # 802005f2 <panic>

0000000080205112 <balloc>:
{
    80205112:	711d                	addi	sp,sp,-96
    80205114:	ec86                	sd	ra,88(sp)
    80205116:	e8a2                	sd	s0,80(sp)
    80205118:	e4a6                	sd	s1,72(sp)
    8020511a:	1080                	addi	s0,sp,96
    for (uint32 b = 0; b < sb.size; b += BPB) {
    8020511c:	0013f797          	auipc	a5,0x13f
    80205120:	bac7a783          	lw	a5,-1108(a5) # 80343cc8 <sb+0x8>
    80205124:	10078463          	beqz	a5,8020522c <balloc+0x11a>
    80205128:	e0ca                	sd	s2,64(sp)
    8020512a:	fc4e                	sd	s3,56(sp)
    8020512c:	f852                	sd	s4,48(sp)
    8020512e:	f456                	sd	s5,40(sp)
    80205130:	f05a                	sd	s6,32(sp)
    80205132:	ec5e                	sd	s7,24(sp)
    80205134:	e862                	sd	s8,16(sp)
    80205136:	e466                	sd	s9,8(sp)
    80205138:	8baa                	mv	s7,a0
    8020513a:	4a81                	li	s5,0
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    8020513c:	0013fb17          	auipc	s6,0x13f
    80205140:	b84b0b13          	addi	s6,s6,-1148 # 80343cc0 <sb>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80205144:	4c01                	li	s8,0
            int m = 1 << (bi % 8);
    80205146:	4985                	li	s3,1
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80205148:	6a09                	lui	s4,0x2
    for (uint32 b = 0; b < sb.size; b += BPB) {
    8020514a:	6c89                	lui	s9,0x2
    8020514c:	a061                	j	802051d4 <balloc+0xc2>
                bp->data[bi / 8] |= m;              /* claim it... */
    8020514e:	1582                	slli	a1,a1,0x20
    80205150:	9181                	srli	a1,a1,0x20
    80205152:	95ca                	add	a1,a1,s2
    80205154:	8ed9                	or	a3,a3,a4
    80205156:	04d58c23          	sb	a3,88(a1)
                bwrite(bp);                         /* ...ON DISK, before use */
    8020515a:	854a                	mv	a0,s2
    8020515c:	00000097          	auipc	ra,0x0
    80205160:	e5a080e7          	jalr	-422(ra) # 80204fb6 <bwrite>
                brelse(bp);
    80205164:	854a                	mv	a0,s2
    80205166:	00000097          	auipc	ra,0x0
    8020516a:	e8e080e7          	jalr	-370(ra) # 80204ff4 <brelse>
    struct buf *bp = bread(dev, bno);
    8020516e:	85a6                	mv	a1,s1
    80205170:	855e                	mv	a0,s7
    80205172:	00000097          	auipc	ra,0x0
    80205176:	d52080e7          	jalr	-686(ra) # 80204ec4 <bread>
    8020517a:	892a                	mv	s2,a0
    memset(bp->data, 0, BSIZE);
    8020517c:	40000613          	li	a2,1024
    80205180:	4581                	li	a1,0
    80205182:	05850513          	addi	a0,a0,88
    80205186:	ffffb097          	auipc	ra,0xffffb
    8020518a:	512080e7          	jalr	1298(ra) # 80200698 <memset>
    bwrite(bp);
    8020518e:	854a                	mv	a0,s2
    80205190:	00000097          	auipc	ra,0x0
    80205194:	e26080e7          	jalr	-474(ra) # 80204fb6 <bwrite>
    brelse(bp);
    80205198:	854a                	mv	a0,s2
    8020519a:	00000097          	auipc	ra,0x0
    8020519e:	e5a080e7          	jalr	-422(ra) # 80204ff4 <brelse>
}
    802051a2:	6906                	ld	s2,64(sp)
    802051a4:	79e2                	ld	s3,56(sp)
    802051a6:	7a42                	ld	s4,48(sp)
    802051a8:	7aa2                	ld	s5,40(sp)
    802051aa:	7b02                	ld	s6,32(sp)
    802051ac:	6be2                	ld	s7,24(sp)
    802051ae:	6c42                	ld	s8,16(sp)
    802051b0:	6ca2                	ld	s9,8(sp)
}
    802051b2:	8526                	mv	a0,s1
    802051b4:	60e6                	ld	ra,88(sp)
    802051b6:	6446                	ld	s0,80(sp)
    802051b8:	64a6                	ld	s1,72(sp)
    802051ba:	6125                	addi	sp,sp,96
    802051bc:	8082                	ret
        brelse(bp);
    802051be:	854a                	mv	a0,s2
    802051c0:	00000097          	auipc	ra,0x0
    802051c4:	e34080e7          	jalr	-460(ra) # 80204ff4 <brelse>
    for (uint32 b = 0; b < sb.size; b += BPB) {
    802051c8:	015c8abb          	addw	s5,s9,s5
    802051cc:	008b2783          	lw	a5,8(s6)
    802051d0:	04faf663          	bgeu	s5,a5,8020521c <balloc+0x10a>
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    802051d4:	00dad59b          	srliw	a1,s5,0xd
    802051d8:	018b2783          	lw	a5,24(s6)
    802051dc:	9dbd                	addw	a1,a1,a5
    802051de:	855e                	mv	a0,s7
    802051e0:	00000097          	auipc	ra,0x0
    802051e4:	ce4080e7          	jalr	-796(ra) # 80204ec4 <bread>
    802051e8:	892a                	mv	s2,a0
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    802051ea:	008b2503          	lw	a0,8(s6)
    802051ee:	84d6                	mv	s1,s5
    802051f0:	87e2                	mv	a5,s8
    802051f2:	fca4f6e3          	bgeu	s1,a0,802051be <balloc+0xac>
            int m = 1 << (bi % 8);
    802051f6:	0077f713          	andi	a4,a5,7
    802051fa:	00e9973b          	sllw	a4,s3,a4
            if ((bp->data[bi / 8] & m) == 0) {
    802051fe:	0037d59b          	srliw	a1,a5,0x3
    80205202:	0037d69b          	srliw	a3,a5,0x3
    80205206:	96ca                	add	a3,a3,s2
    80205208:	0586c683          	lbu	a3,88(a3)
    8020520c:	00d77633          	and	a2,a4,a3
    80205210:	de1d                	beqz	a2,8020514e <balloc+0x3c>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80205212:	2785                	addiw	a5,a5,1
    80205214:	2485                	addiw	s1,s1,1
    80205216:	fd479ee3          	bne	a5,s4,802051f2 <balloc+0xe0>
    8020521a:	b755                	j	802051be <balloc+0xac>
    8020521c:	6906                	ld	s2,64(sp)
    8020521e:	79e2                	ld	s3,56(sp)
    80205220:	7a42                	ld	s4,48(sp)
    80205222:	7aa2                	ld	s5,40(sp)
    80205224:	7b02                	ld	s6,32(sp)
    80205226:	6be2                	ld	s7,24(sp)
    80205228:	6c42                	ld	s8,16(sp)
    8020522a:	6ca2                	ld	s9,8(sp)
    printf("luitfs: out of data blocks\n");
    8020522c:	00002517          	auipc	a0,0x2
    80205230:	7e450513          	addi	a0,a0,2020 # 80207a10 <etext+0xa10>
    80205234:	ffffb097          	auipc	ra,0xffffb
    80205238:	14c080e7          	jalr	332(ra) # 80200380 <printf>
    return 0;
    8020523c:	4481                	li	s1,0
    8020523e:	bf95                	j	802051b2 <balloc+0xa0>

0000000080205240 <bmap>:
/* ---------- block mapping ---------- */

/* Return the disk block holding byte-offset block `bn` of ip, allocating it
 * (and the indirect block) on demand. 0 = out of space. Caller holds ip->lock. */
static uint32 bmap(struct inode *ip, uint32 bn)
{
    80205240:	7179                	addi	sp,sp,-48
    80205242:	f406                	sd	ra,40(sp)
    80205244:	f022                	sd	s0,32(sp)
    80205246:	ec26                	sd	s1,24(sp)
    80205248:	e84a                	sd	s2,16(sp)
    8020524a:	e44e                	sd	s3,8(sp)
    8020524c:	1800                	addi	s0,sp,48
    8020524e:	89aa                	mv	s3,a0
    if (bn < NDIRECT) {
    80205250:	47ad                	li	a5,11
    80205252:	02b7e863          	bltu	a5,a1,80205282 <bmap+0x42>
        uint32 addr = ip->addrs[bn];
    80205256:	02059793          	slli	a5,a1,0x20
    8020525a:	01e7d593          	srli	a1,a5,0x1e
    8020525e:	00b504b3          	add	s1,a0,a1
    80205262:	0504a903          	lw	s2,80(s1)
        if (addr == 0) {
    80205266:	08091263          	bnez	s2,802052ea <bmap+0xaa>
            addr = balloc(ip->dev);
    8020526a:	4108                	lw	a0,0(a0)
    8020526c:	00000097          	auipc	ra,0x0
    80205270:	ea6080e7          	jalr	-346(ra) # 80205112 <balloc>
    80205274:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80205278:	06090963          	beqz	s2,802052ea <bmap+0xaa>
            ip->addrs[bn] = addr;
    8020527c:	0524a823          	sw	s2,80(s1)
    80205280:	a0ad                	j	802052ea <bmap+0xaa>
        }
        return addr;
    }
    bn -= NDIRECT;
    80205282:	ff45849b          	addiw	s1,a1,-12
    80205286:	0004871b          	sext.w	a4,s1
    if (bn < NINDIRECT) {
    8020528a:	0ff00793          	li	a5,255
    8020528e:	08e7e863          	bltu	a5,a4,8020531e <bmap+0xde>
        /* Lab 9 extends this function with a DOUBLE-indirect level. */
        uint32 addr = ip->addrs[NDIRECT];
    80205292:	08052903          	lw	s2,128(a0)
        if (addr == 0) {
    80205296:	00091f63          	bnez	s2,802052b4 <bmap+0x74>
            addr = balloc(ip->dev);
    8020529a:	4108                	lw	a0,0(a0)
    8020529c:	00000097          	auipc	ra,0x0
    802052a0:	e76080e7          	jalr	-394(ra) # 80205112 <balloc>
    802052a4:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    802052a8:	04090163          	beqz	s2,802052ea <bmap+0xaa>
    802052ac:	e052                	sd	s4,0(sp)
            ip->addrs[NDIRECT] = addr;
    802052ae:	0929a023          	sw	s2,128(s3)
    802052b2:	a011                	j	802052b6 <bmap+0x76>
    802052b4:	e052                	sd	s4,0(sp)
        }
        struct buf *bp = bread(ip->dev, addr);
    802052b6:	85ca                	mv	a1,s2
    802052b8:	0009a503          	lw	a0,0(s3)
    802052bc:	00000097          	auipc	ra,0x0
    802052c0:	c08080e7          	jalr	-1016(ra) # 80204ec4 <bread>
    802052c4:	8a2a                	mv	s4,a0
        uint32 *a = (uint32 *)bp->data;
    802052c6:	05850793          	addi	a5,a0,88
        if ((addr = a[bn]) == 0) {
    802052ca:	02049713          	slli	a4,s1,0x20
    802052ce:	01e75593          	srli	a1,a4,0x1e
    802052d2:	00b784b3          	add	s1,a5,a1
    802052d6:	0004a903          	lw	s2,0(s1)
    802052da:	02090063          	beqz	s2,802052fa <bmap+0xba>
            addr = balloc(ip->dev);
            if (addr) { a[bn] = addr; bwrite(bp); }
        }
        brelse(bp);
    802052de:	8552                	mv	a0,s4
    802052e0:	00000097          	auipc	ra,0x0
    802052e4:	d14080e7          	jalr	-748(ra) # 80204ff4 <brelse>
        return addr;
    802052e8:	6a02                	ld	s4,0(sp)
    }
    panic("bmap: block number beyond MAXFILE");
}
    802052ea:	854a                	mv	a0,s2
    802052ec:	70a2                	ld	ra,40(sp)
    802052ee:	7402                	ld	s0,32(sp)
    802052f0:	64e2                	ld	s1,24(sp)
    802052f2:	6942                	ld	s2,16(sp)
    802052f4:	69a2                	ld	s3,8(sp)
    802052f6:	6145                	addi	sp,sp,48
    802052f8:	8082                	ret
            addr = balloc(ip->dev);
    802052fa:	0009a503          	lw	a0,0(s3)
    802052fe:	00000097          	auipc	ra,0x0
    80205302:	e14080e7          	jalr	-492(ra) # 80205112 <balloc>
    80205306:	0005091b          	sext.w	s2,a0
            if (addr) { a[bn] = addr; bwrite(bp); }
    8020530a:	fc090ae3          	beqz	s2,802052de <bmap+0x9e>
    8020530e:	0124a023          	sw	s2,0(s1)
    80205312:	8552                	mv	a0,s4
    80205314:	00000097          	auipc	ra,0x0
    80205318:	ca2080e7          	jalr	-862(ra) # 80204fb6 <bwrite>
    8020531c:	b7c9                	j	802052de <bmap+0x9e>
    8020531e:	e052                	sd	s4,0(sp)
    panic("bmap: block number beyond MAXFILE");
    80205320:	00002517          	auipc	a0,0x2
    80205324:	71050513          	addi	a0,a0,1808 # 80207a30 <etext+0xa30>
    80205328:	ffffb097          	auipc	ra,0xffffb
    8020532c:	2ca080e7          	jalr	714(ra) # 802005f2 <panic>

0000000080205330 <iget>:
{
    80205330:	7179                	addi	sp,sp,-48
    80205332:	f406                	sd	ra,40(sp)
    80205334:	f022                	sd	s0,32(sp)
    80205336:	ec26                	sd	s1,24(sp)
    80205338:	e84a                	sd	s2,16(sp)
    8020533a:	e44e                	sd	s3,8(sp)
    8020533c:	e052                	sd	s4,0(sp)
    8020533e:	1800                	addi	s0,sp,48
    80205340:	89aa                	mv	s3,a0
    80205342:	8a2e                	mv	s4,a1
    acquire(&icache.lock);
    80205344:	0013f517          	auipc	a0,0x13f
    80205348:	9a450513          	addi	a0,a0,-1628 # 80343ce8 <icache>
    8020534c:	ffffc097          	auipc	ra,0xffffc
    80205350:	fdc080e7          	jalr	-36(ra) # 80201328 <acquire>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80205354:	0013f497          	auipc	s1,0x13f
    80205358:	9ac48493          	addi	s1,s1,-1620 # 80343d00 <icache+0x18>
    struct inode *empty = 0;
    8020535c:	4901                	li	s2,0
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    8020535e:	00140697          	auipc	a3,0x140
    80205362:	43268693          	addi	a3,a3,1074 # 80345790 <devsw>
    80205366:	a039                	j	80205374 <iget+0x44>
        if (empty == 0 && ip->ref == 0)
    80205368:	02090b63          	beqz	s2,8020539e <iget+0x6e>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    8020536c:	08848493          	addi	s1,s1,136
    80205370:	02d48a63          	beq	s1,a3,802053a4 <iget+0x74>
        if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80205374:	449c                	lw	a5,8(s1)
    80205376:	fef059e3          	blez	a5,80205368 <iget+0x38>
    8020537a:	4098                	lw	a4,0(s1)
    8020537c:	ff3716e3          	bne	a4,s3,80205368 <iget+0x38>
    80205380:	40d8                	lw	a4,4(s1)
    80205382:	ff4713e3          	bne	a4,s4,80205368 <iget+0x38>
            ip->ref++;
    80205386:	2785                	addiw	a5,a5,1
    80205388:	c49c                	sw	a5,8(s1)
            release(&icache.lock);
    8020538a:	0013f517          	auipc	a0,0x13f
    8020538e:	95e50513          	addi	a0,a0,-1698 # 80343ce8 <icache>
    80205392:	ffffc097          	auipc	ra,0xffffc
    80205396:	04a080e7          	jalr	74(ra) # 802013dc <release>
            return ip;
    8020539a:	8926                	mv	s2,s1
    8020539c:	a03d                	j	802053ca <iget+0x9a>
        if (empty == 0 && ip->ref == 0)
    8020539e:	f7f9                	bnez	a5,8020536c <iget+0x3c>
            empty = ip;
    802053a0:	8926                	mv	s2,s1
    802053a2:	b7e9                	j	8020536c <iget+0x3c>
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    802053a4:	02090c63          	beqz	s2,802053dc <iget+0xac>
    ip->dev = dev; ip->inum = inum; ip->ref = 1; ip->valid = 0;
    802053a8:	01392023          	sw	s3,0(s2)
    802053ac:	01492223          	sw	s4,4(s2)
    802053b0:	4785                	li	a5,1
    802053b2:	00f92423          	sw	a5,8(s2)
    802053b6:	04092023          	sw	zero,64(s2)
    release(&icache.lock);
    802053ba:	0013f517          	auipc	a0,0x13f
    802053be:	92e50513          	addi	a0,a0,-1746 # 80343ce8 <icache>
    802053c2:	ffffc097          	auipc	ra,0xffffc
    802053c6:	01a080e7          	jalr	26(ra) # 802013dc <release>
}
    802053ca:	854a                	mv	a0,s2
    802053cc:	70a2                	ld	ra,40(sp)
    802053ce:	7402                	ld	s0,32(sp)
    802053d0:	64e2                	ld	s1,24(sp)
    802053d2:	6942                	ld	s2,16(sp)
    802053d4:	69a2                	ld	s3,8(sp)
    802053d6:	6a02                	ld	s4,0(sp)
    802053d8:	6145                	addi	sp,sp,48
    802053da:	8082                	ret
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    802053dc:	00002517          	auipc	a0,0x2
    802053e0:	67c50513          	addi	a0,a0,1660 # 80207a58 <etext+0xa58>
    802053e4:	ffffb097          	auipc	ra,0xffffb
    802053e8:	20e080e7          	jalr	526(ra) # 802005f2 <panic>

00000000802053ec <fsinit>:
{
    802053ec:	1101                	addi	sp,sp,-32
    802053ee:	ec06                	sd	ra,24(sp)
    802053f0:	e822                	sd	s0,16(sp)
    802053f2:	e426                	sd	s1,8(sp)
    802053f4:	e04a                	sd	s2,0(sp)
    802053f6:	1000                	addi	s0,sp,32
    struct buf *bp = bread(dev, 1);
    802053f8:	4585                	li	a1,1
    802053fa:	00000097          	auipc	ra,0x0
    802053fe:	aca080e7          	jalr	-1334(ra) # 80204ec4 <bread>
    80205402:	84aa                	mv	s1,a0
    memmove(&sb, bp->data, sizeof(sb));
    80205404:	0013f917          	auipc	s2,0x13f
    80205408:	8bc90913          	addi	s2,s2,-1860 # 80343cc0 <sb>
    8020540c:	02800613          	li	a2,40
    80205410:	05850593          	addi	a1,a0,88
    80205414:	854a                	mv	a0,s2
    80205416:	ffffb097          	auipc	ra,0xffffb
    8020541a:	29e080e7          	jalr	670(ra) # 802006b4 <memmove>
    brelse(bp);
    8020541e:	8526                	mv	a0,s1
    80205420:	00000097          	auipc	ra,0x0
    80205424:	bd4080e7          	jalr	-1068(ra) # 80204ff4 <brelse>
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80205428:	00092703          	lw	a4,0(s2)
    8020542c:	4c5557b7          	lui	a5,0x4c555
    80205430:	95478793          	addi	a5,a5,-1708 # 4c554954 <_entry-0x33cab6ac>
    80205434:	02f71e63          	bne	a4,a5,80205470 <fsinit+0x84>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80205438:	0013f717          	auipc	a4,0x13f
    8020543c:	88c72703          	lw	a4,-1908(a4) # 80343cc4 <sb+0x4>
    80205440:	4785                	li	a5,1
    80205442:	02f71f63          	bne	a4,a5,80205480 <fsinit+0x94>
    printf("luitfs: %d blocks, %d inodes, data at block %d\n",
    80205446:	0013f797          	auipc	a5,0x13f
    8020544a:	87a78793          	addi	a5,a5,-1926 # 80343cc0 <sb>
    8020544e:	5394                	lw	a3,32(a5)
    80205450:	47d0                	lw	a2,12(a5)
    80205452:	478c                	lw	a1,8(a5)
    80205454:	00002517          	auipc	a0,0x2
    80205458:	67450513          	addi	a0,a0,1652 # 80207ac8 <etext+0xac8>
    8020545c:	ffffb097          	auipc	ra,0xffffb
    80205460:	f24080e7          	jalr	-220(ra) # 80200380 <printf>
}
    80205464:	60e2                	ld	ra,24(sp)
    80205466:	6442                	ld	s0,16(sp)
    80205468:	64a2                	ld	s1,8(sp)
    8020546a:	6902                	ld	s2,0(sp)
    8020546c:	6105                	addi	sp,sp,32
    8020546e:	8082                	ret
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80205470:	00002517          	auipc	a0,0x2
    80205474:	61050513          	addi	a0,a0,1552 # 80207a80 <etext+0xa80>
    80205478:	ffffb097          	auipc	ra,0xffffb
    8020547c:	17a080e7          	jalr	378(ra) # 802005f2 <panic>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80205480:	00002517          	auipc	a0,0x2
    80205484:	62850513          	addi	a0,a0,1576 # 80207aa8 <etext+0xaa8>
    80205488:	ffffb097          	auipc	ra,0xffffb
    8020548c:	16a080e7          	jalr	362(ra) # 802005f2 <panic>

0000000080205490 <iinit>:
{
    80205490:	7179                	addi	sp,sp,-48
    80205492:	f406                	sd	ra,40(sp)
    80205494:	f022                	sd	s0,32(sp)
    80205496:	ec26                	sd	s1,24(sp)
    80205498:	e84a                	sd	s2,16(sp)
    8020549a:	e44e                	sd	s3,8(sp)
    8020549c:	1800                	addi	s0,sp,48
    initlock(&icache.lock, "icache");
    8020549e:	00002597          	auipc	a1,0x2
    802054a2:	65a58593          	addi	a1,a1,1626 # 80207af8 <etext+0xaf8>
    802054a6:	0013f517          	auipc	a0,0x13f
    802054aa:	84250513          	addi	a0,a0,-1982 # 80343ce8 <icache>
    802054ae:	ffffc097          	auipc	ra,0xffffc
    802054b2:	dfe080e7          	jalr	-514(ra) # 802012ac <initlock>
    for (int i = 0; i < NINODE; i++)
    802054b6:	0013f497          	auipc	s1,0x13f
    802054ba:	85a48493          	addi	s1,s1,-1958 # 80343d10 <icache+0x28>
    802054be:	00140997          	auipc	s3,0x140
    802054c2:	2e298993          	addi	s3,s3,738 # 803457a0 <devsw+0x10>
        initsleeplock(&icache.inode[i].lock, "inode");
    802054c6:	00002917          	auipc	s2,0x2
    802054ca:	63a90913          	addi	s2,s2,1594 # 80207b00 <etext+0xb00>
    802054ce:	85ca                	mv	a1,s2
    802054d0:	8526                	mv	a0,s1
    802054d2:	ffffc097          	auipc	ra,0xffffc
    802054d6:	f52080e7          	jalr	-174(ra) # 80201424 <initsleeplock>
    for (int i = 0; i < NINODE; i++)
    802054da:	08848493          	addi	s1,s1,136
    802054de:	ff3498e3          	bne	s1,s3,802054ce <iinit+0x3e>
}
    802054e2:	70a2                	ld	ra,40(sp)
    802054e4:	7402                	ld	s0,32(sp)
    802054e6:	64e2                	ld	s1,24(sp)
    802054e8:	6942                	ld	s2,16(sp)
    802054ea:	69a2                	ld	s3,8(sp)
    802054ec:	6145                	addi	sp,sp,48
    802054ee:	8082                	ret

00000000802054f0 <ialloc>:
{
    802054f0:	715d                	addi	sp,sp,-80
    802054f2:	e486                	sd	ra,72(sp)
    802054f4:	e0a2                	sd	s0,64(sp)
    802054f6:	0880                	addi	s0,sp,80
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    802054f8:	0013e717          	auipc	a4,0x13e
    802054fc:	7d472703          	lw	a4,2004(a4) # 80343ccc <sb+0xc>
    80205500:	4785                	li	a5,1
    80205502:	06e7fe63          	bgeu	a5,a4,8020557e <ialloc+0x8e>
    80205506:	fc26                	sd	s1,56(sp)
    80205508:	f84a                	sd	s2,48(sp)
    8020550a:	f44e                	sd	s3,40(sp)
    8020550c:	f052                	sd	s4,32(sp)
    8020550e:	ec56                	sd	s5,24(sp)
    80205510:	e85a                	sd	s6,16(sp)
    80205512:	e45e                	sd	s7,8(sp)
    80205514:	8a2a                	mv	s4,a0
    80205516:	8bae                	mv	s7,a1
    80205518:	4485                	li	s1,1
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    8020551a:	0013e997          	auipc	s3,0x13e
    8020551e:	7a698993          	addi	s3,s3,1958 # 80343cc0 <sb>
        int m = 1 << (bi % 8);
    80205522:	4b05                	li	s6,1
        uint32 bi = i % BPB;
    80205524:	6a89                	lui	s5,0x2
    80205526:	1afd                	addi	s5,s5,-1 # 1fff <_entry-0x801fe001>
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80205528:	00d4d59b          	srliw	a1,s1,0xd
    8020552c:	0149a783          	lw	a5,20(s3)
    80205530:	9dbd                	addw	a1,a1,a5
    80205532:	8552                	mv	a0,s4
    80205534:	00000097          	auipc	ra,0x0
    80205538:	990080e7          	jalr	-1648(ra) # 80204ec4 <bread>
    8020553c:	892a                	mv	s2,a0
        int m = 1 << (bi % 8);
    8020553e:	0074f713          	andi	a4,s1,7
    80205542:	00eb173b          	sllw	a4,s6,a4
        uint32 bi = i % BPB;
    80205546:	0154f7b3          	and	a5,s1,s5
        if ((bp->data[bi / 8] & m) == 0) {
    8020554a:	0037d61b          	srliw	a2,a5,0x3
    8020554e:	0037d79b          	srliw	a5,a5,0x3
    80205552:	97aa                	add	a5,a5,a0
    80205554:	0587c783          	lbu	a5,88(a5)
    80205558:	00f776b3          	and	a3,a4,a5
    8020555c:	ce95                	beqz	a3,80205598 <ialloc+0xa8>
        brelse(bp);
    8020555e:	00000097          	auipc	ra,0x0
    80205562:	a96080e7          	jalr	-1386(ra) # 80204ff4 <brelse>
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80205566:	2485                	addiw	s1,s1,1
    80205568:	00c9a783          	lw	a5,12(s3)
    8020556c:	faf4eee3          	bltu	s1,a5,80205528 <ialloc+0x38>
    80205570:	74e2                	ld	s1,56(sp)
    80205572:	7942                	ld	s2,48(sp)
    80205574:	79a2                	ld	s3,40(sp)
    80205576:	7a02                	ld	s4,32(sp)
    80205578:	6ae2                	ld	s5,24(sp)
    8020557a:	6b42                	ld	s6,16(sp)
    8020557c:	6ba2                	ld	s7,8(sp)
    printf("luitfs: out of inodes\n");
    8020557e:	00002517          	auipc	a0,0x2
    80205582:	58a50513          	addi	a0,a0,1418 # 80207b08 <etext+0xb08>
    80205586:	ffffb097          	auipc	ra,0xffffb
    8020558a:	dfa080e7          	jalr	-518(ra) # 80200380 <printf>
    return 0;
    8020558e:	4501                	li	a0,0
}
    80205590:	60a6                	ld	ra,72(sp)
    80205592:	6406                	ld	s0,64(sp)
    80205594:	6161                	addi	sp,sp,80
    80205596:	8082                	ret
            bp->data[bi / 8] |= m;
    80205598:	1602                	slli	a2,a2,0x20
    8020559a:	9201                	srli	a2,a2,0x20
    8020559c:	962a                	add	a2,a2,a0
    8020559e:	8fd9                	or	a5,a5,a4
    802055a0:	04f60c23          	sb	a5,88(a2) # 1058 <_entry-0x801fefa8>
            bwrite(bp);
    802055a4:	00000097          	auipc	ra,0x0
    802055a8:	a12080e7          	jalr	-1518(ra) # 80204fb6 <bwrite>
            brelse(bp);
    802055ac:	854a                	mv	a0,s2
    802055ae:	00000097          	auipc	ra,0x0
    802055b2:	a46080e7          	jalr	-1466(ra) # 80204ff4 <brelse>
            bp = bread(dev, IBLOCK(i, sb));
    802055b6:	0044d59b          	srliw	a1,s1,0x4
    802055ba:	0013e797          	auipc	a5,0x13e
    802055be:	7227a783          	lw	a5,1826(a5) # 80343cdc <sb+0x1c>
    802055c2:	9dbd                	addw	a1,a1,a5
    802055c4:	8552                	mv	a0,s4
    802055c6:	00000097          	auipc	ra,0x0
    802055ca:	8fe080e7          	jalr	-1794(ra) # 80204ec4 <bread>
    802055ce:	892a                	mv	s2,a0
            struct dinode *dip = (struct dinode *)bp->data + i % IPB;
    802055d0:	05850993          	addi	s3,a0,88
    802055d4:	00f4f793          	andi	a5,s1,15
    802055d8:	079a                	slli	a5,a5,0x6
    802055da:	99be                	add	s3,s3,a5
            memset(dip, 0, sizeof(*dip));
    802055dc:	04000613          	li	a2,64
    802055e0:	4581                	li	a1,0
    802055e2:	854e                	mv	a0,s3
    802055e4:	ffffb097          	auipc	ra,0xffffb
    802055e8:	0b4080e7          	jalr	180(ra) # 80200698 <memset>
            dip->type = type;
    802055ec:	01799023          	sh	s7,0(s3)
            bwrite(bp);
    802055f0:	854a                	mv	a0,s2
    802055f2:	00000097          	auipc	ra,0x0
    802055f6:	9c4080e7          	jalr	-1596(ra) # 80204fb6 <bwrite>
            brelse(bp);
    802055fa:	854a                	mv	a0,s2
    802055fc:	00000097          	auipc	ra,0x0
    80205600:	9f8080e7          	jalr	-1544(ra) # 80204ff4 <brelse>
            return iget(dev, i);
    80205604:	85a6                	mv	a1,s1
    80205606:	8552                	mv	a0,s4
    80205608:	00000097          	auipc	ra,0x0
    8020560c:	d28080e7          	jalr	-728(ra) # 80205330 <iget>
    80205610:	74e2                	ld	s1,56(sp)
    80205612:	7942                	ld	s2,48(sp)
    80205614:	79a2                	ld	s3,40(sp)
    80205616:	7a02                	ld	s4,32(sp)
    80205618:	6ae2                	ld	s5,24(sp)
    8020561a:	6b42                	ld	s6,16(sp)
    8020561c:	6ba2                	ld	s7,8(sp)
    8020561e:	bf8d                	j	80205590 <ialloc+0xa0>

0000000080205620 <iupdate>:
{
    80205620:	1101                	addi	sp,sp,-32
    80205622:	ec06                	sd	ra,24(sp)
    80205624:	e822                	sd	s0,16(sp)
    80205626:	e426                	sd	s1,8(sp)
    80205628:	e04a                	sd	s2,0(sp)
    8020562a:	1000                	addi	s0,sp,32
    8020562c:	84aa                	mv	s1,a0
    struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8020562e:	415c                	lw	a5,4(a0)
    80205630:	0047d79b          	srliw	a5,a5,0x4
    80205634:	0013e597          	auipc	a1,0x13e
    80205638:	6a85a583          	lw	a1,1704(a1) # 80343cdc <sb+0x1c>
    8020563c:	9dbd                	addw	a1,a1,a5
    8020563e:	4108                	lw	a0,0(a0)
    80205640:	00000097          	auipc	ra,0x0
    80205644:	884080e7          	jalr	-1916(ra) # 80204ec4 <bread>
    80205648:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    8020564a:	05850793          	addi	a5,a0,88
    8020564e:	40d8                	lw	a4,4(s1)
    80205650:	8b3d                	andi	a4,a4,15
    80205652:	071a                	slli	a4,a4,0x6
    80205654:	97ba                	add	a5,a5,a4
    dip->type  = ip->type;
    80205656:	0444d703          	lhu	a4,68(s1)
    8020565a:	00e79023          	sh	a4,0(a5)
    dip->major = ip->major;
    8020565e:	0464d703          	lhu	a4,70(s1)
    80205662:	00e79123          	sh	a4,2(a5)
    dip->minor = ip->minor;
    80205666:	0484d703          	lhu	a4,72(s1)
    8020566a:	00e79223          	sh	a4,4(a5)
    dip->nlink = ip->nlink;
    8020566e:	04a4d703          	lhu	a4,74(s1)
    80205672:	00e79323          	sh	a4,6(a5)
    dip->size  = ip->size;
    80205676:	44f8                	lw	a4,76(s1)
    80205678:	c798                	sw	a4,8(a5)
    memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8020567a:	03400613          	li	a2,52
    8020567e:	05048593          	addi	a1,s1,80
    80205682:	00c78513          	addi	a0,a5,12
    80205686:	ffffb097          	auipc	ra,0xffffb
    8020568a:	02e080e7          	jalr	46(ra) # 802006b4 <memmove>
    bwrite(bp);
    8020568e:	854a                	mv	a0,s2
    80205690:	00000097          	auipc	ra,0x0
    80205694:	926080e7          	jalr	-1754(ra) # 80204fb6 <bwrite>
    brelse(bp);
    80205698:	854a                	mv	a0,s2
    8020569a:	00000097          	auipc	ra,0x0
    8020569e:	95a080e7          	jalr	-1702(ra) # 80204ff4 <brelse>
}
    802056a2:	60e2                	ld	ra,24(sp)
    802056a4:	6442                	ld	s0,16(sp)
    802056a6:	64a2                	ld	s1,8(sp)
    802056a8:	6902                	ld	s2,0(sp)
    802056aa:	6105                	addi	sp,sp,32
    802056ac:	8082                	ret

00000000802056ae <idup>:
{
    802056ae:	1101                	addi	sp,sp,-32
    802056b0:	ec06                	sd	ra,24(sp)
    802056b2:	e822                	sd	s0,16(sp)
    802056b4:	e426                	sd	s1,8(sp)
    802056b6:	1000                	addi	s0,sp,32
    802056b8:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    802056ba:	0013e517          	auipc	a0,0x13e
    802056be:	62e50513          	addi	a0,a0,1582 # 80343ce8 <icache>
    802056c2:	ffffc097          	auipc	ra,0xffffc
    802056c6:	c66080e7          	jalr	-922(ra) # 80201328 <acquire>
    ip->ref++;
    802056ca:	449c                	lw	a5,8(s1)
    802056cc:	2785                	addiw	a5,a5,1
    802056ce:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    802056d0:	0013e517          	auipc	a0,0x13e
    802056d4:	61850513          	addi	a0,a0,1560 # 80343ce8 <icache>
    802056d8:	ffffc097          	auipc	ra,0xffffc
    802056dc:	d04080e7          	jalr	-764(ra) # 802013dc <release>
}
    802056e0:	8526                	mv	a0,s1
    802056e2:	60e2                	ld	ra,24(sp)
    802056e4:	6442                	ld	s0,16(sp)
    802056e6:	64a2                	ld	s1,8(sp)
    802056e8:	6105                	addi	sp,sp,32
    802056ea:	8082                	ret

00000000802056ec <ilock>:
{
    802056ec:	1101                	addi	sp,sp,-32
    802056ee:	ec06                	sd	ra,24(sp)
    802056f0:	e822                	sd	s0,16(sp)
    802056f2:	e426                	sd	s1,8(sp)
    802056f4:	1000                	addi	s0,sp,32
    if (ip == 0 || ip->ref < 1) panic("ilock");
    802056f6:	c10d                	beqz	a0,80205718 <ilock+0x2c>
    802056f8:	84aa                	mv	s1,a0
    802056fa:	451c                	lw	a5,8(a0)
    802056fc:	00f05e63          	blez	a5,80205718 <ilock+0x2c>
    acquiresleep(&ip->lock);
    80205700:	0541                	addi	a0,a0,16
    80205702:	ffffc097          	auipc	ra,0xffffc
    80205706:	d5c080e7          	jalr	-676(ra) # 8020145e <acquiresleep>
    if (!ip->valid) {
    8020570a:	40bc                	lw	a5,64(s1)
    8020570c:	cf99                	beqz	a5,8020572a <ilock+0x3e>
}
    8020570e:	60e2                	ld	ra,24(sp)
    80205710:	6442                	ld	s0,16(sp)
    80205712:	64a2                	ld	s1,8(sp)
    80205714:	6105                	addi	sp,sp,32
    80205716:	8082                	ret
    80205718:	e04a                	sd	s2,0(sp)
    if (ip == 0 || ip->ref < 1) panic("ilock");
    8020571a:	00002517          	auipc	a0,0x2
    8020571e:	40650513          	addi	a0,a0,1030 # 80207b20 <etext+0xb20>
    80205722:	ffffb097          	auipc	ra,0xffffb
    80205726:	ed0080e7          	jalr	-304(ra) # 802005f2 <panic>
    8020572a:	e04a                	sd	s2,0(sp)
        struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8020572c:	40dc                	lw	a5,4(s1)
    8020572e:	0047d79b          	srliw	a5,a5,0x4
    80205732:	0013e597          	auipc	a1,0x13e
    80205736:	5aa5a583          	lw	a1,1450(a1) # 80343cdc <sb+0x1c>
    8020573a:	9dbd                	addw	a1,a1,a5
    8020573c:	4088                	lw	a0,0(s1)
    8020573e:	fffff097          	auipc	ra,0xfffff
    80205742:	786080e7          	jalr	1926(ra) # 80204ec4 <bread>
    80205746:	892a                	mv	s2,a0
        struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    80205748:	05850593          	addi	a1,a0,88
    8020574c:	40dc                	lw	a5,4(s1)
    8020574e:	8bbd                	andi	a5,a5,15
    80205750:	079a                	slli	a5,a5,0x6
    80205752:	95be                	add	a1,a1,a5
        ip->type  = dip->type;
    80205754:	0005d783          	lhu	a5,0(a1)
    80205758:	04f49223          	sh	a5,68(s1)
        ip->major = dip->major;
    8020575c:	0025d783          	lhu	a5,2(a1)
    80205760:	04f49323          	sh	a5,70(s1)
        ip->minor = dip->minor;
    80205764:	0045d783          	lhu	a5,4(a1)
    80205768:	04f49423          	sh	a5,72(s1)
        ip->nlink = dip->nlink;
    8020576c:	0065d783          	lhu	a5,6(a1)
    80205770:	04f49523          	sh	a5,74(s1)
        ip->size  = dip->size;
    80205774:	459c                	lw	a5,8(a1)
    80205776:	c4fc                	sw	a5,76(s1)
        memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80205778:	03400613          	li	a2,52
    8020577c:	05b1                	addi	a1,a1,12
    8020577e:	05048513          	addi	a0,s1,80
    80205782:	ffffb097          	auipc	ra,0xffffb
    80205786:	f32080e7          	jalr	-206(ra) # 802006b4 <memmove>
        brelse(bp);
    8020578a:	854a                	mv	a0,s2
    8020578c:	00000097          	auipc	ra,0x0
    80205790:	868080e7          	jalr	-1944(ra) # 80204ff4 <brelse>
        ip->valid = 1;
    80205794:	4785                	li	a5,1
    80205796:	c0bc                	sw	a5,64(s1)
        if (ip->type == 0) panic("ilock: inode has no type (bitmap out of sync)");
    80205798:	0444d783          	lhu	a5,68(s1)
    8020579c:	c399                	beqz	a5,802057a2 <ilock+0xb6>
    8020579e:	6902                	ld	s2,0(sp)
    802057a0:	b7bd                	j	8020570e <ilock+0x22>
    802057a2:	00002517          	auipc	a0,0x2
    802057a6:	38650513          	addi	a0,a0,902 # 80207b28 <etext+0xb28>
    802057aa:	ffffb097          	auipc	ra,0xffffb
    802057ae:	e48080e7          	jalr	-440(ra) # 802005f2 <panic>

00000000802057b2 <iunlock>:
{
    802057b2:	1101                	addi	sp,sp,-32
    802057b4:	ec06                	sd	ra,24(sp)
    802057b6:	e822                	sd	s0,16(sp)
    802057b8:	e426                	sd	s1,8(sp)
    802057ba:	e04a                	sd	s2,0(sp)
    802057bc:	1000                	addi	s0,sp,32
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    802057be:	c905                	beqz	a0,802057ee <iunlock+0x3c>
    802057c0:	84aa                	mv	s1,a0
    802057c2:	01050913          	addi	s2,a0,16
    802057c6:	854a                	mv	a0,s2
    802057c8:	ffffc097          	auipc	ra,0xffffc
    802057cc:	d30080e7          	jalr	-720(ra) # 802014f8 <holdingsleep>
    802057d0:	cd19                	beqz	a0,802057ee <iunlock+0x3c>
    802057d2:	449c                	lw	a5,8(s1)
    802057d4:	00f05d63          	blez	a5,802057ee <iunlock+0x3c>
    releasesleep(&ip->lock);
    802057d8:	854a                	mv	a0,s2
    802057da:	ffffc097          	auipc	ra,0xffffc
    802057de:	cda080e7          	jalr	-806(ra) # 802014b4 <releasesleep>
}
    802057e2:	60e2                	ld	ra,24(sp)
    802057e4:	6442                	ld	s0,16(sp)
    802057e6:	64a2                	ld	s1,8(sp)
    802057e8:	6902                	ld	s2,0(sp)
    802057ea:	6105                	addi	sp,sp,32
    802057ec:	8082                	ret
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    802057ee:	00002517          	auipc	a0,0x2
    802057f2:	36a50513          	addi	a0,a0,874 # 80207b58 <etext+0xb58>
    802057f6:	ffffb097          	auipc	ra,0xffffb
    802057fa:	dfc080e7          	jalr	-516(ra) # 802005f2 <panic>

00000000802057fe <itrunc>:

/* Free all data blocks of ip and set size 0. Caller holds ip->lock. */
void itrunc(struct inode *ip)
{
    802057fe:	7179                	addi	sp,sp,-48
    80205800:	f406                	sd	ra,40(sp)
    80205802:	f022                	sd	s0,32(sp)
    80205804:	ec26                	sd	s1,24(sp)
    80205806:	e84a                	sd	s2,16(sp)
    80205808:	e44e                	sd	s3,8(sp)
    8020580a:	1800                	addi	s0,sp,48
    8020580c:	89aa                	mv	s3,a0
    for (int i = 0; i < NDIRECT; i++) {
    8020580e:	05050493          	addi	s1,a0,80
    80205812:	08050913          	addi	s2,a0,128
    80205816:	a021                	j	8020581e <itrunc+0x20>
    80205818:	0491                	addi	s1,s1,4
    8020581a:	01248d63          	beq	s1,s2,80205834 <itrunc+0x36>
        if (ip->addrs[i]) { bfree(ip->dev, ip->addrs[i]); ip->addrs[i] = 0; }
    8020581e:	408c                	lw	a1,0(s1)
    80205820:	dde5                	beqz	a1,80205818 <itrunc+0x1a>
    80205822:	0009a503          	lw	a0,0(s3)
    80205826:	00000097          	auipc	ra,0x0
    8020582a:	86a080e7          	jalr	-1942(ra) # 80205090 <bfree>
    8020582e:	0004a023          	sw	zero,0(s1)
    80205832:	b7dd                	j	80205818 <itrunc+0x1a>
    }
    if (ip->addrs[NDIRECT]) {
    80205834:	0809a583          	lw	a1,128(s3)
    80205838:	ed99                	bnez	a1,80205856 <itrunc+0x58>
            if (a[j]) bfree(ip->dev, a[j]);
        brelse(bp);
        bfree(ip->dev, ip->addrs[NDIRECT]);
        ip->addrs[NDIRECT] = 0;
    }
    ip->size = 0;
    8020583a:	0409a623          	sw	zero,76(s3)
    iupdate(ip);
    8020583e:	854e                	mv	a0,s3
    80205840:	00000097          	auipc	ra,0x0
    80205844:	de0080e7          	jalr	-544(ra) # 80205620 <iupdate>
}
    80205848:	70a2                	ld	ra,40(sp)
    8020584a:	7402                	ld	s0,32(sp)
    8020584c:	64e2                	ld	s1,24(sp)
    8020584e:	6942                	ld	s2,16(sp)
    80205850:	69a2                	ld	s3,8(sp)
    80205852:	6145                	addi	sp,sp,48
    80205854:	8082                	ret
    80205856:	e052                	sd	s4,0(sp)
        struct buf *bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80205858:	0009a503          	lw	a0,0(s3)
    8020585c:	fffff097          	auipc	ra,0xfffff
    80205860:	668080e7          	jalr	1640(ra) # 80204ec4 <bread>
    80205864:	8a2a                	mv	s4,a0
        for (uint32 j = 0; j < NINDIRECT; j++)
    80205866:	05850493          	addi	s1,a0,88
    8020586a:	45850913          	addi	s2,a0,1112
    8020586e:	a021                	j	80205876 <itrunc+0x78>
    80205870:	0491                	addi	s1,s1,4
    80205872:	01248b63          	beq	s1,s2,80205888 <itrunc+0x8a>
            if (a[j]) bfree(ip->dev, a[j]);
    80205876:	408c                	lw	a1,0(s1)
    80205878:	dde5                	beqz	a1,80205870 <itrunc+0x72>
    8020587a:	0009a503          	lw	a0,0(s3)
    8020587e:	00000097          	auipc	ra,0x0
    80205882:	812080e7          	jalr	-2030(ra) # 80205090 <bfree>
    80205886:	b7ed                	j	80205870 <itrunc+0x72>
        brelse(bp);
    80205888:	8552                	mv	a0,s4
    8020588a:	fffff097          	auipc	ra,0xfffff
    8020588e:	76a080e7          	jalr	1898(ra) # 80204ff4 <brelse>
        bfree(ip->dev, ip->addrs[NDIRECT]);
    80205892:	0809a583          	lw	a1,128(s3)
    80205896:	0009a503          	lw	a0,0(s3)
    8020589a:	fffff097          	auipc	ra,0xfffff
    8020589e:	7f6080e7          	jalr	2038(ra) # 80205090 <bfree>
        ip->addrs[NDIRECT] = 0;
    802058a2:	0809a023          	sw	zero,128(s3)
    802058a6:	6a02                	ld	s4,0(sp)
    802058a8:	bf49                	j	8020583a <itrunc+0x3c>

00000000802058aa <iput>:
{
    802058aa:	7179                	addi	sp,sp,-48
    802058ac:	f406                	sd	ra,40(sp)
    802058ae:	f022                	sd	s0,32(sp)
    802058b0:	ec26                	sd	s1,24(sp)
    802058b2:	1800                	addi	s0,sp,48
    802058b4:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    802058b6:	0013e517          	auipc	a0,0x13e
    802058ba:	43250513          	addi	a0,a0,1074 # 80343ce8 <icache>
    802058be:	ffffc097          	auipc	ra,0xffffc
    802058c2:	a6a080e7          	jalr	-1430(ra) # 80201328 <acquire>
    if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    802058c6:	4498                	lw	a4,8(s1)
    802058c8:	4785                	li	a5,1
    802058ca:	00f71763          	bne	a4,a5,802058d8 <iput+0x2e>
    802058ce:	40bc                	lw	a5,64(s1)
    802058d0:	c781                	beqz	a5,802058d8 <iput+0x2e>
    802058d2:	04a4d783          	lhu	a5,74(s1)
    802058d6:	c38d                	beqz	a5,802058f8 <iput+0x4e>
    ip->ref--;
    802058d8:	449c                	lw	a5,8(s1)
    802058da:	37fd                	addiw	a5,a5,-1
    802058dc:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    802058de:	0013e517          	auipc	a0,0x13e
    802058e2:	40a50513          	addi	a0,a0,1034 # 80343ce8 <icache>
    802058e6:	ffffc097          	auipc	ra,0xffffc
    802058ea:	af6080e7          	jalr	-1290(ra) # 802013dc <release>
}
    802058ee:	70a2                	ld	ra,40(sp)
    802058f0:	7402                	ld	s0,32(sp)
    802058f2:	64e2                	ld	s1,24(sp)
    802058f4:	6145                	addi	sp,sp,48
    802058f6:	8082                	ret
    802058f8:	e84a                	sd	s2,16(sp)
    802058fa:	e44e                	sd	s3,8(sp)
        acquiresleep(&ip->lock);
    802058fc:	01048993          	addi	s3,s1,16
    80205900:	854e                	mv	a0,s3
    80205902:	ffffc097          	auipc	ra,0xffffc
    80205906:	b5c080e7          	jalr	-1188(ra) # 8020145e <acquiresleep>
        release(&icache.lock);
    8020590a:	0013e517          	auipc	a0,0x13e
    8020590e:	3de50513          	addi	a0,a0,990 # 80343ce8 <icache>
    80205912:	ffffc097          	auipc	ra,0xffffc
    80205916:	aca080e7          	jalr	-1334(ra) # 802013dc <release>
        itrunc(ip);
    8020591a:	8526                	mv	a0,s1
    8020591c:	00000097          	auipc	ra,0x0
    80205920:	ee2080e7          	jalr	-286(ra) # 802057fe <itrunc>
        ip->type = 0;
    80205924:	04049223          	sh	zero,68(s1)
        iupdate(ip);
    80205928:	8526                	mv	a0,s1
    8020592a:	00000097          	auipc	ra,0x0
    8020592e:	cf6080e7          	jalr	-778(ra) # 80205620 <iupdate>
        struct buf *bp = bread(ip->dev, IBBLOCK(ip->inum, sb));
    80205932:	40dc                	lw	a5,4(s1)
    80205934:	00d7d79b          	srliw	a5,a5,0xd
    80205938:	0013e597          	auipc	a1,0x13e
    8020593c:	39c5a583          	lw	a1,924(a1) # 80343cd4 <sb+0x14>
    80205940:	9dbd                	addw	a1,a1,a5
    80205942:	4088                	lw	a0,0(s1)
    80205944:	fffff097          	auipc	ra,0xfffff
    80205948:	580080e7          	jalr	1408(ra) # 80204ec4 <bread>
    8020594c:	892a                	mv	s2,a0
        uint32 bi = ip->inum % BPB;
    8020594e:	40d4                	lw	a3,4(s1)
    80205950:	03369793          	slli	a5,a3,0x33
        if ((bp->data[bi / 8] & (1 << (bi % 8))) == 0)
    80205954:	0367d713          	srli	a4,a5,0x36
    80205958:	00e507b3          	add	a5,a0,a4
    8020595c:	0587c603          	lbu	a2,88(a5)
    80205960:	8a9d                	andi	a3,a3,7
    80205962:	40d657bb          	sraw	a5,a2,a3
    80205966:	8b85                	andi	a5,a5,1
    80205968:	cba1                	beqz	a5,802059b8 <iput+0x10e>
        bp->data[bi / 8] &= ~(1 << (bi % 8));
    8020596a:	02071793          	slli	a5,a4,0x20
    8020596e:	9381                	srli	a5,a5,0x20
    80205970:	97aa                	add	a5,a5,a0
    80205972:	4705                	li	a4,1
    80205974:	00d7173b          	sllw	a4,a4,a3
    80205978:	fff74713          	not	a4,a4
    8020597c:	8e79                	and	a2,a2,a4
    8020597e:	04c78c23          	sb	a2,88(a5)
        bwrite(bp);
    80205982:	fffff097          	auipc	ra,0xfffff
    80205986:	634080e7          	jalr	1588(ra) # 80204fb6 <bwrite>
        brelse(bp);
    8020598a:	854a                	mv	a0,s2
    8020598c:	fffff097          	auipc	ra,0xfffff
    80205990:	668080e7          	jalr	1640(ra) # 80204ff4 <brelse>
        ip->valid = 0;
    80205994:	0404a023          	sw	zero,64(s1)
        releasesleep(&ip->lock);
    80205998:	854e                	mv	a0,s3
    8020599a:	ffffc097          	auipc	ra,0xffffc
    8020599e:	b1a080e7          	jalr	-1254(ra) # 802014b4 <releasesleep>
        acquire(&icache.lock);
    802059a2:	0013e517          	auipc	a0,0x13e
    802059a6:	34650513          	addi	a0,a0,838 # 80343ce8 <icache>
    802059aa:	ffffc097          	auipc	ra,0xffffc
    802059ae:	97e080e7          	jalr	-1666(ra) # 80201328 <acquire>
    802059b2:	6942                	ld	s2,16(sp)
    802059b4:	69a2                	ld	s3,8(sp)
    802059b6:	b70d                	j	802058d8 <iput+0x2e>
            panic("iput: inode bitmap already clear");
    802059b8:	00002517          	auipc	a0,0x2
    802059bc:	1a850513          	addi	a0,a0,424 # 80207b60 <etext+0xb60>
    802059c0:	ffffb097          	auipc	ra,0xffffb
    802059c4:	c32080e7          	jalr	-974(ra) # 802005f2 <panic>

00000000802059c8 <iunlockput>:
void iunlockput(struct inode *ip) { iunlock(ip); iput(ip); }
    802059c8:	1101                	addi	sp,sp,-32
    802059ca:	ec06                	sd	ra,24(sp)
    802059cc:	e822                	sd	s0,16(sp)
    802059ce:	e426                	sd	s1,8(sp)
    802059d0:	1000                	addi	s0,sp,32
    802059d2:	84aa                	mv	s1,a0
    802059d4:	00000097          	auipc	ra,0x0
    802059d8:	dde080e7          	jalr	-546(ra) # 802057b2 <iunlock>
    802059dc:	8526                	mv	a0,s1
    802059de:	00000097          	auipc	ra,0x0
    802059e2:	ecc080e7          	jalr	-308(ra) # 802058aa <iput>
    802059e6:	60e2                	ld	ra,24(sp)
    802059e8:	6442                	ld	s0,16(sp)
    802059ea:	64a2                	ld	s1,8(sp)
    802059ec:	6105                	addi	sp,sp,32
    802059ee:	8082                	ret

00000000802059f0 <stati>:

void stati(struct inode *ip, struct stat *st)
{
    802059f0:	1141                	addi	sp,sp,-16
    802059f2:	e422                	sd	s0,8(sp)
    802059f4:	0800                	addi	s0,sp,16
    st->dev   = ip->dev;
    802059f6:	411c                	lw	a5,0(a0)
    802059f8:	c19c                	sw	a5,0(a1)
    st->ino   = ip->inum;
    802059fa:	415c                	lw	a5,4(a0)
    802059fc:	c1dc                	sw	a5,4(a1)
    st->type  = ip->type;
    802059fe:	04455783          	lhu	a5,68(a0)
    80205a02:	00f59423          	sh	a5,8(a1)
    st->nlink = ip->nlink;
    80205a06:	04a55783          	lhu	a5,74(a0)
    80205a0a:	00f59523          	sh	a5,10(a1)
    st->size  = ip->size;
    80205a0e:	04c56783          	lwu	a5,76(a0)
    80205a12:	e99c                	sd	a5,16(a1)
}
    80205a14:	6422                	ld	s0,8(sp)
    80205a16:	0141                	addi	sp,sp,16
    80205a18:	8082                	ret

0000000080205a1a <readi>:

/* Read n bytes at offset off into dst (user va if user_dst, else kernel).
 * Returns bytes read, or -1. Caller holds ip->lock. */
int readi(struct inode *ip, int user_dst, uint64 dst, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return 0;
    80205a1a:	457c                	lw	a5,76(a0)
    80205a1c:	12d7e763          	bltu	a5,a3,80205b4a <readi+0x130>
{
    80205a20:	7159                	addi	sp,sp,-112
    80205a22:	f486                	sd	ra,104(sp)
    80205a24:	f0a2                	sd	s0,96(sp)
    80205a26:	eca6                	sd	s1,88(sp)
    80205a28:	e0d2                	sd	s4,64(sp)
    80205a2a:	f45e                	sd	s7,40(sp)
    80205a2c:	f062                	sd	s8,32(sp)
    80205a2e:	ec66                	sd	s9,24(sp)
    80205a30:	1880                	addi	s0,sp,112
    80205a32:	8c2a                	mv	s8,a0
    80205a34:	8cae                	mv	s9,a1
    80205a36:	8a32                	mv	s4,a2
    80205a38:	84b6                	mv	s1,a3
    80205a3a:	8bba                	mv	s7,a4
    if (off > ip->size || off + n < off) return 0;
    80205a3c:	9f35                	addw	a4,a4,a3
    80205a3e:	4501                	li	a0,0
    80205a40:	0ed76c63          	bltu	a4,a3,80205b38 <readi+0x11e>
    80205a44:	e4ce                	sd	s3,72(sp)
    if (off + n > ip->size) n = ip->size - off;
    80205a46:	00e7f463          	bgeu	a5,a4,80205a4e <readi+0x34>
    80205a4a:	40d78bbb          	subw	s7,a5,a3

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205a4e:	0c0b8b63          	beqz	s7,80205b24 <readi+0x10a>
    80205a52:	e8ca                	sd	s2,80(sp)
    80205a54:	fc56                	sd	s5,56(sp)
    80205a56:	f85a                	sd	s6,48(sp)
    80205a58:	e86a                	sd	s10,16(sp)
    80205a5a:	e46e                	sd	s11,8(sp)
    80205a5c:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80205a5e:	40000d13          	li	s10,1024
    80205a62:	a81d                	j	80205a98 <readi+0x7e>
                brelse(bp);
                tot = -1;
                break;
            }
        } else {
            memmove((void *)dst, bp->data + off % BSIZE, m);
    80205a64:	05890593          	addi	a1,s2,88
    80205a68:	020a9613          	slli	a2,s5,0x20
    80205a6c:	9201                	srli	a2,a2,0x20
    80205a6e:	95da                	add	a1,a1,s6
    80205a70:	8552                	mv	a0,s4
    80205a72:	ffffb097          	auipc	ra,0xffffb
    80205a76:	c42080e7          	jalr	-958(ra) # 802006b4 <memmove>
        }
        brelse(bp);
    80205a7a:	854a                	mv	a0,s2
    80205a7c:	fffff097          	auipc	ra,0xfffff
    80205a80:	578080e7          	jalr	1400(ra) # 80204ff4 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205a84:	013d89bb          	addw	s3,s11,s3
    80205a88:	009d84bb          	addw	s1,s11,s1
    80205a8c:	1d82                	slli	s11,s11,0x20
    80205a8e:	020ddd93          	srli	s11,s11,0x20
    80205a92:	9a6e                	add	s4,s4,s11
    80205a94:	0979f263          	bgeu	s3,s7,80205b18 <readi+0xfe>
        uint32 addr = bmap(ip, off / BSIZE);
    80205a98:	00a4d59b          	srliw	a1,s1,0xa
    80205a9c:	8562                	mv	a0,s8
    80205a9e:	fffff097          	auipc	ra,0xfffff
    80205aa2:	7a2080e7          	jalr	1954(ra) # 80205240 <bmap>
    80205aa6:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;
    80205aaa:	cdbd                	beqz	a1,80205b28 <readi+0x10e>
        struct buf *bp = bread(ip->dev, addr);
    80205aac:	000c2503          	lw	a0,0(s8)
    80205ab0:	fffff097          	auipc	ra,0xfffff
    80205ab4:	414080e7          	jalr	1044(ra) # 80204ec4 <bread>
    80205ab8:	892a                	mv	s2,a0
        m = BSIZE - off % BSIZE;
    80205aba:	3ff4fb13          	andi	s6,s1,1023
        if (m > n - tot) m = n - tot;
    80205abe:	413b87bb          	subw	a5,s7,s3
        m = BSIZE - off % BSIZE;
    80205ac2:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    80205ac6:	8abe                	mv	s5,a5
    80205ac8:	2781                	sext.w	a5,a5
    80205aca:	0007069b          	sext.w	a3,a4
    80205ace:	00f6f363          	bgeu	a3,a5,80205ad4 <readi+0xba>
    80205ad2:	8aba                	mv	s5,a4
    80205ad4:	000a8d9b          	sext.w	s11,s5
        if (user_dst) {
    80205ad8:	f80c86e3          	beqz	s9,80205a64 <readi+0x4a>
            if (copyout(myproc()->pagetable, dst,
    80205adc:	ffffc097          	auipc	ra,0xffffc
    80205ae0:	c8a080e7          	jalr	-886(ra) # 80201766 <myproc>
                        (char *)bp->data + off % BSIZE, m) < 0) {
    80205ae4:	05890613          	addi	a2,s2,88
            if (copyout(myproc()->pagetable, dst,
    80205ae8:	020a9693          	slli	a3,s5,0x20
    80205aec:	9281                	srli	a3,a3,0x20
    80205aee:	965a                	add	a2,a2,s6
    80205af0:	85d2                	mv	a1,s4
    80205af2:	6928                	ld	a0,80(a0)
    80205af4:	ffffd097          	auipc	ra,0xffffd
    80205af8:	48a080e7          	jalr	1162(ra) # 80202f7e <copyout>
    80205afc:	f6055fe3          	bgez	a0,80205a7a <readi+0x60>
                brelse(bp);
    80205b00:	854a                	mv	a0,s2
    80205b02:	fffff097          	auipc	ra,0xfffff
    80205b06:	4f2080e7          	jalr	1266(ra) # 80204ff4 <brelse>
                tot = -1;
    80205b0a:	59fd                	li	s3,-1
                break;
    80205b0c:	6946                	ld	s2,80(sp)
    80205b0e:	7ae2                	ld	s5,56(sp)
    80205b10:	7b42                	ld	s6,48(sp)
    80205b12:	6d42                	ld	s10,16(sp)
    80205b14:	6da2                	ld	s11,8(sp)
    80205b16:	a831                	j	80205b32 <readi+0x118>
    80205b18:	6946                	ld	s2,80(sp)
    80205b1a:	7ae2                	ld	s5,56(sp)
    80205b1c:	7b42                	ld	s6,48(sp)
    80205b1e:	6d42                	ld	s10,16(sp)
    80205b20:	6da2                	ld	s11,8(sp)
    80205b22:	a801                	j	80205b32 <readi+0x118>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205b24:	89de                	mv	s3,s7
    80205b26:	a031                	j	80205b32 <readi+0x118>
    80205b28:	6946                	ld	s2,80(sp)
    80205b2a:	7ae2                	ld	s5,56(sp)
    80205b2c:	7b42                	ld	s6,48(sp)
    80205b2e:	6d42                	ld	s10,16(sp)
    80205b30:	6da2                	ld	s11,8(sp)
    }
    return tot;
    80205b32:	0009851b          	sext.w	a0,s3
    80205b36:	69a6                	ld	s3,72(sp)
}
    80205b38:	70a6                	ld	ra,104(sp)
    80205b3a:	7406                	ld	s0,96(sp)
    80205b3c:	64e6                	ld	s1,88(sp)
    80205b3e:	6a06                	ld	s4,64(sp)
    80205b40:	7ba2                	ld	s7,40(sp)
    80205b42:	7c02                	ld	s8,32(sp)
    80205b44:	6ce2                	ld	s9,24(sp)
    80205b46:	6165                	addi	sp,sp,112
    80205b48:	8082                	ret
    if (off > ip->size || off + n < off) return 0;
    80205b4a:	4501                	li	a0,0
}
    80205b4c:	8082                	ret

0000000080205b4e <writei>:

/* Write n bytes at off from src. Grows the file if needed. Caller holds lock. */
int writei(struct inode *ip, int user_src, uint64 src, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return -1;
    80205b4e:	457c                	lw	a5,76(a0)
    80205b50:	14d7e063          	bltu	a5,a3,80205c90 <writei+0x142>
{
    80205b54:	7159                	addi	sp,sp,-112
    80205b56:	f486                	sd	ra,104(sp)
    80205b58:	f0a2                	sd	s0,96(sp)
    80205b5a:	e8ca                	sd	s2,80(sp)
    80205b5c:	fc56                	sd	s5,56(sp)
    80205b5e:	f45e                	sd	s7,40(sp)
    80205b60:	f062                	sd	s8,32(sp)
    80205b62:	ec66                	sd	s9,24(sp)
    80205b64:	1880                	addi	s0,sp,112
    80205b66:	8baa                	mv	s7,a0
    80205b68:	8cae                	mv	s9,a1
    80205b6a:	8ab2                	mv	s5,a2
    80205b6c:	8936                	mv	s2,a3
    80205b6e:	8c3a                	mv	s8,a4
    if (off > ip->size || off + n < off) return -1;
    80205b70:	00e687bb          	addw	a5,a3,a4
    80205b74:	12d7e063          	bltu	a5,a3,80205c94 <writei+0x146>
    if (off + n > MAXFILE * BSIZE) return -1;
    80205b78:	00043737          	lui	a4,0x43
    80205b7c:	10f76e63          	bltu	a4,a5,80205c98 <writei+0x14a>
    80205b80:	e4ce                	sd	s3,72(sp)

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205b82:	0e0c0f63          	beqz	s8,80205c80 <writei+0x132>
    80205b86:	eca6                	sd	s1,88(sp)
    80205b88:	e0d2                	sd	s4,64(sp)
    80205b8a:	f85a                	sd	s6,48(sp)
    80205b8c:	e86a                	sd	s10,16(sp)
    80205b8e:	e46e                	sd	s11,8(sp)
    80205b90:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;                     /* disk full: partial write */
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80205b92:	40000d13          	li	s10,1024
    80205b96:	a081                	j	80205bd6 <writei+0x88>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
                brelse(bp);
                break;
            }
        } else {
            memmove(bp->data + off % BSIZE, (void *)src, m);
    80205b98:	05848513          	addi	a0,s1,88
    80205b9c:	020a1613          	slli	a2,s4,0x20
    80205ba0:	9201                	srli	a2,a2,0x20
    80205ba2:	85d6                	mv	a1,s5
    80205ba4:	955a                	add	a0,a0,s6
    80205ba6:	ffffb097          	auipc	ra,0xffffb
    80205baa:	b0e080e7          	jalr	-1266(ra) # 802006b4 <memmove>
        }
        bwrite(bp);
    80205bae:	8526                	mv	a0,s1
    80205bb0:	fffff097          	auipc	ra,0xfffff
    80205bb4:	406080e7          	jalr	1030(ra) # 80204fb6 <bwrite>
        brelse(bp);
    80205bb8:	8526                	mv	a0,s1
    80205bba:	fffff097          	auipc	ra,0xfffff
    80205bbe:	43a080e7          	jalr	1082(ra) # 80204ff4 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205bc2:	013d89bb          	addw	s3,s11,s3
    80205bc6:	012d893b          	addw	s2,s11,s2
    80205bca:	1d82                	slli	s11,s11,0x20
    80205bcc:	020ddd93          	srli	s11,s11,0x20
    80205bd0:	9aee                	add	s5,s5,s11
    80205bd2:	0789fb63          	bgeu	s3,s8,80205c48 <writei+0xfa>
        uint32 addr = bmap(ip, off / BSIZE);
    80205bd6:	00a9559b          	srliw	a1,s2,0xa
    80205bda:	855e                	mv	a0,s7
    80205bdc:	fffff097          	auipc	ra,0xfffff
    80205be0:	664080e7          	jalr	1636(ra) # 80205240 <bmap>
    80205be4:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;                     /* disk full: partial write */
    80205be8:	c1a5                	beqz	a1,80205c48 <writei+0xfa>
        struct buf *bp = bread(ip->dev, addr);
    80205bea:	000ba503          	lw	a0,0(s7)
    80205bee:	fffff097          	auipc	ra,0xfffff
    80205bf2:	2d6080e7          	jalr	726(ra) # 80204ec4 <bread>
    80205bf6:	84aa                	mv	s1,a0
        m = BSIZE - off % BSIZE;
    80205bf8:	3ff97b13          	andi	s6,s2,1023
        if (m > n - tot) m = n - tot;
    80205bfc:	413c07bb          	subw	a5,s8,s3
        m = BSIZE - off % BSIZE;
    80205c00:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    80205c04:	8a3e                	mv	s4,a5
    80205c06:	2781                	sext.w	a5,a5
    80205c08:	0007069b          	sext.w	a3,a4
    80205c0c:	00f6f363          	bgeu	a3,a5,80205c12 <writei+0xc4>
    80205c10:	8a3a                	mv	s4,a4
    80205c12:	000a0d9b          	sext.w	s11,s4
        if (user_src) {
    80205c16:	f80c81e3          	beqz	s9,80205b98 <writei+0x4a>
            if (copyin(myproc()->pagetable,
    80205c1a:	ffffc097          	auipc	ra,0xffffc
    80205c1e:	b4c080e7          	jalr	-1204(ra) # 80201766 <myproc>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
    80205c22:	05848593          	addi	a1,s1,88
            if (copyin(myproc()->pagetable,
    80205c26:	020a1693          	slli	a3,s4,0x20
    80205c2a:	9281                	srli	a3,a3,0x20
    80205c2c:	8656                	mv	a2,s5
    80205c2e:	95da                	add	a1,a1,s6
    80205c30:	6928                	ld	a0,80(a0)
    80205c32:	ffffd097          	auipc	ra,0xffffd
    80205c36:	440080e7          	jalr	1088(ra) # 80203072 <copyin>
    80205c3a:	f6055ae3          	bgez	a0,80205bae <writei+0x60>
                brelse(bp);
    80205c3e:	8526                	mv	a0,s1
    80205c40:	fffff097          	auipc	ra,0xfffff
    80205c44:	3b4080e7          	jalr	948(ra) # 80204ff4 <brelse>
    }
    if (off > ip->size) ip->size = off;
    80205c48:	04cba783          	lw	a5,76(s7)
    80205c4c:	0327fc63          	bgeu	a5,s2,80205c84 <writei+0x136>
    80205c50:	052ba623          	sw	s2,76(s7)
    80205c54:	64e6                	ld	s1,88(sp)
    80205c56:	6a06                	ld	s4,64(sp)
    80205c58:	7b42                	ld	s6,48(sp)
    80205c5a:	6d42                	ld	s10,16(sp)
    80205c5c:	6da2                	ld	s11,8(sp)
    iupdate(ip);                    /* size and any new addrs[] hit the disk */
    80205c5e:	855e                	mv	a0,s7
    80205c60:	00000097          	auipc	ra,0x0
    80205c64:	9c0080e7          	jalr	-1600(ra) # 80205620 <iupdate>
    return tot;
    80205c68:	0009851b          	sext.w	a0,s3
    80205c6c:	69a6                	ld	s3,72(sp)
}
    80205c6e:	70a6                	ld	ra,104(sp)
    80205c70:	7406                	ld	s0,96(sp)
    80205c72:	6946                	ld	s2,80(sp)
    80205c74:	7ae2                	ld	s5,56(sp)
    80205c76:	7ba2                	ld	s7,40(sp)
    80205c78:	7c02                	ld	s8,32(sp)
    80205c7a:	6ce2                	ld	s9,24(sp)
    80205c7c:	6165                	addi	sp,sp,112
    80205c7e:	8082                	ret
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205c80:	89e2                	mv	s3,s8
    80205c82:	bff1                	j	80205c5e <writei+0x110>
    80205c84:	64e6                	ld	s1,88(sp)
    80205c86:	6a06                	ld	s4,64(sp)
    80205c88:	7b42                	ld	s6,48(sp)
    80205c8a:	6d42                	ld	s10,16(sp)
    80205c8c:	6da2                	ld	s11,8(sp)
    80205c8e:	bfc1                	j	80205c5e <writei+0x110>
    if (off > ip->size || off + n < off) return -1;
    80205c90:	557d                	li	a0,-1
}
    80205c92:	8082                	ret
    if (off > ip->size || off + n < off) return -1;
    80205c94:	557d                	li	a0,-1
    80205c96:	bfe1                	j	80205c6e <writei+0x120>
    if (off + n > MAXFILE * BSIZE) return -1;
    80205c98:	557d                	li	a0,-1
    80205c9a:	bfd1                	j	80205c6e <writei+0x120>

0000000080205c9c <namecmp>:

/* ---------- directories ---------- */

int namecmp(const char *s, const char *t) { return strncmp(s, t, DIRSIZ); }
    80205c9c:	1141                	addi	sp,sp,-16
    80205c9e:	e406                	sd	ra,8(sp)
    80205ca0:	e022                	sd	s0,0(sp)
    80205ca2:	0800                	addi	s0,sp,16
    80205ca4:	4671                	li	a2,28
    80205ca6:	ffffb097          	auipc	ra,0xffffb
    80205caa:	a7e080e7          	jalr	-1410(ra) # 80200724 <strncmp>
    80205cae:	60a2                	ld	ra,8(sp)
    80205cb0:	6402                	ld	s0,0(sp)
    80205cb2:	0141                	addi	sp,sp,16
    80205cb4:	8082                	ret

0000000080205cb6 <dirlookup>:

/* Look up name in directory dp. Returns unlocked inode; *poff = entry offset. */
struct inode *dirlookup(struct inode *dp, char *name, uint32 *poff)
{
    80205cb6:	715d                	addi	sp,sp,-80
    80205cb8:	e486                	sd	ra,72(sp)
    80205cba:	e0a2                	sd	s0,64(sp)
    80205cbc:	fc26                	sd	s1,56(sp)
    80205cbe:	f84a                	sd	s2,48(sp)
    80205cc0:	f44e                	sd	s3,40(sp)
    80205cc2:	f052                	sd	s4,32(sp)
    80205cc4:	0880                	addi	s0,sp,80
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    80205cc6:	04455703          	lhu	a4,68(a0)
    80205cca:	4785                	li	a5,1
    80205ccc:	00f71a63          	bne	a4,a5,80205ce0 <dirlookup+0x2a>
    80205cd0:	892a                	mv	s2,a0
    80205cd2:	89ae                	mv	s3,a1
    80205cd4:	8a32                	mv	s4,a2

    struct dirent de;
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80205cd6:	457c                	lw	a5,76(a0)
    80205cd8:	4481                	li	s1,0
        if (namecmp(name, de.name) == 0) {
            if (poff) *poff = off;
            return iget(dp->dev, de.inum);
        }
    }
    return 0;
    80205cda:	4501                	li	a0,0
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80205cdc:	eb85                	bnez	a5,80205d0c <dirlookup+0x56>
    80205cde:	a8bd                	j	80205d5c <dirlookup+0xa6>
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    80205ce0:	00002517          	auipc	a0,0x2
    80205ce4:	ea850513          	addi	a0,a0,-344 # 80207b88 <etext+0xb88>
    80205ce8:	ffffb097          	auipc	ra,0xffffb
    80205cec:	90a080e7          	jalr	-1782(ra) # 802005f2 <panic>
            panic("dirlookup: short directory read");
    80205cf0:	00002517          	auipc	a0,0x2
    80205cf4:	eb850513          	addi	a0,a0,-328 # 80207ba8 <etext+0xba8>
    80205cf8:	ffffb097          	auipc	ra,0xffffb
    80205cfc:	8fa080e7          	jalr	-1798(ra) # 802005f2 <panic>
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80205d00:	0204849b          	addiw	s1,s1,32
    80205d04:	04c92783          	lw	a5,76(s2)
    80205d08:	04f4f963          	bgeu	s1,a5,80205d5a <dirlookup+0xa4>
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205d0c:	02000713          	li	a4,32
    80205d10:	86a6                	mv	a3,s1
    80205d12:	fb040613          	addi	a2,s0,-80
    80205d16:	4581                	li	a1,0
    80205d18:	854a                	mv	a0,s2
    80205d1a:	00000097          	auipc	ra,0x0
    80205d1e:	d00080e7          	jalr	-768(ra) # 80205a1a <readi>
    80205d22:	02000793          	li	a5,32
    80205d26:	fcf515e3          	bne	a0,a5,80205cf0 <dirlookup+0x3a>
        if (de.inum == 0) continue;
    80205d2a:	fb042783          	lw	a5,-80(s0)
    80205d2e:	dbe9                	beqz	a5,80205d00 <dirlookup+0x4a>
        if (namecmp(name, de.name) == 0) {
    80205d30:	fb440593          	addi	a1,s0,-76
    80205d34:	854e                	mv	a0,s3
    80205d36:	00000097          	auipc	ra,0x0
    80205d3a:	f66080e7          	jalr	-154(ra) # 80205c9c <namecmp>
    80205d3e:	f169                	bnez	a0,80205d00 <dirlookup+0x4a>
            if (poff) *poff = off;
    80205d40:	000a0463          	beqz	s4,80205d48 <dirlookup+0x92>
    80205d44:	009a2023          	sw	s1,0(s4) # 2000 <_entry-0x801fe000>
            return iget(dp->dev, de.inum);
    80205d48:	fb042583          	lw	a1,-80(s0)
    80205d4c:	00092503          	lw	a0,0(s2)
    80205d50:	fffff097          	auipc	ra,0xfffff
    80205d54:	5e0080e7          	jalr	1504(ra) # 80205330 <iget>
    80205d58:	a011                	j	80205d5c <dirlookup+0xa6>
    return 0;
    80205d5a:	4501                	li	a0,0
}
    80205d5c:	60a6                	ld	ra,72(sp)
    80205d5e:	6406                	ld	s0,64(sp)
    80205d60:	74e2                	ld	s1,56(sp)
    80205d62:	7942                	ld	s2,48(sp)
    80205d64:	79a2                	ld	s3,40(sp)
    80205d66:	7a02                	ld	s4,32(sp)
    80205d68:	6161                	addi	sp,sp,80
    80205d6a:	8082                	ret

0000000080205d6c <namex>:
}

/* Walk path from / (or the cwd). If parent, stop one level early and copy the
 * final element into name. The RETURNED inode is unlocked and referenced. */
static struct inode *namex(char *path, int nameiparent_, char *name)
{
    80205d6c:	711d                	addi	sp,sp,-96
    80205d6e:	ec86                	sd	ra,88(sp)
    80205d70:	e8a2                	sd	s0,80(sp)
    80205d72:	e4a6                	sd	s1,72(sp)
    80205d74:	e0ca                	sd	s2,64(sp)
    80205d76:	fc4e                	sd	s3,56(sp)
    80205d78:	f852                	sd	s4,48(sp)
    80205d7a:	f456                	sd	s5,40(sp)
    80205d7c:	f05a                	sd	s6,32(sp)
    80205d7e:	ec5e                	sd	s7,24(sp)
    80205d80:	e862                	sd	s8,16(sp)
    80205d82:	e466                	sd	s9,8(sp)
    80205d84:	1080                	addi	s0,sp,96
    80205d86:	84aa                	mv	s1,a0
    80205d88:	8b2e                	mv	s6,a1
    80205d8a:	8ab2                	mv	s5,a2
    struct inode *ip;
    if (*path == '/')
    80205d8c:	00054703          	lbu	a4,0(a0)
    80205d90:	02f00793          	li	a5,47
    80205d94:	02f70263          	beq	a4,a5,80205db8 <namex+0x4c>
        ip = iget(ROOTDEV, ROOTINO);
    else
        ip = idup(myproc()->cwd);
    80205d98:	ffffc097          	auipc	ra,0xffffc
    80205d9c:	9ce080e7          	jalr	-1586(ra) # 80201766 <myproc>
    80205da0:	15053503          	ld	a0,336(a0)
    80205da4:	00000097          	auipc	ra,0x0
    80205da8:	90a080e7          	jalr	-1782(ra) # 802056ae <idup>
    80205dac:	8a2a                	mv	s4,a0
    while (*path == '/') path++;
    80205dae:	02f00913          	li	s2,47
    if (len >= DIRSIZ) {
    80205db2:	4c6d                	li	s8,27

    while ((path = skipelem(path, name)) != 0) {
        ilock(ip);
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205db4:	4b85                	li	s7,1
    80205db6:	a865                	j	80205e6e <namex+0x102>
        ip = iget(ROOTDEV, ROOTINO);
    80205db8:	4585                	li	a1,1
    80205dba:	4501                	li	a0,0
    80205dbc:	fffff097          	auipc	ra,0xfffff
    80205dc0:	574080e7          	jalr	1396(ra) # 80205330 <iget>
    80205dc4:	8a2a                	mv	s4,a0
    80205dc6:	b7e5                	j	80205dae <namex+0x42>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205dc8:	8552                	mv	a0,s4
    80205dca:	00000097          	auipc	ra,0x0
    80205dce:	bfe080e7          	jalr	-1026(ra) # 802059c8 <iunlockput>
    80205dd2:	4a01                	li	s4,0
        iunlockput(ip);
        ip = next;
    }
    if (nameiparent_) { iput(ip); return 0; }
    return ip;
}
    80205dd4:	8552                	mv	a0,s4
    80205dd6:	60e6                	ld	ra,88(sp)
    80205dd8:	6446                	ld	s0,80(sp)
    80205dda:	64a6                	ld	s1,72(sp)
    80205ddc:	6906                	ld	s2,64(sp)
    80205dde:	79e2                	ld	s3,56(sp)
    80205de0:	7a42                	ld	s4,48(sp)
    80205de2:	7aa2                	ld	s5,40(sp)
    80205de4:	7b02                	ld	s6,32(sp)
    80205de6:	6be2                	ld	s7,24(sp)
    80205de8:	6c42                	ld	s8,16(sp)
    80205dea:	6ca2                	ld	s9,8(sp)
    80205dec:	6125                	addi	sp,sp,96
    80205dee:	8082                	ret
            iunlock(ip);                          /* stop at the parent */
    80205df0:	8552                	mv	a0,s4
    80205df2:	00000097          	auipc	ra,0x0
    80205df6:	9c0080e7          	jalr	-1600(ra) # 802057b2 <iunlock>
            return ip;
    80205dfa:	bfe9                	j	80205dd4 <namex+0x68>
        if (next == 0) { iunlockput(ip); return 0; }
    80205dfc:	8552                	mv	a0,s4
    80205dfe:	00000097          	auipc	ra,0x0
    80205e02:	bca080e7          	jalr	-1078(ra) # 802059c8 <iunlockput>
    80205e06:	8a4e                	mv	s4,s3
    80205e08:	b7f1                	j	80205dd4 <namex+0x68>
    int len = path - s;
    80205e0a:	40998cbb          	subw	s9,s3,s1
    if (len >= DIRSIZ) {
    80205e0e:	099c5763          	bge	s8,s9,80205e9c <namex+0x130>
        memmove(name, s, DIRSIZ);                 /* truncate long names */
    80205e12:	4671                	li	a2,28
    80205e14:	85a6                	mv	a1,s1
    80205e16:	8556                	mv	a0,s5
    80205e18:	ffffb097          	auipc	ra,0xffffb
    80205e1c:	89c080e7          	jalr	-1892(ra) # 802006b4 <memmove>
    80205e20:	84ce                	mv	s1,s3
    while (*path == '/') path++;
    80205e22:	0004c783          	lbu	a5,0(s1)
    80205e26:	01279763          	bne	a5,s2,80205e34 <namex+0xc8>
    80205e2a:	0485                	addi	s1,s1,1
    80205e2c:	0004c783          	lbu	a5,0(s1)
    80205e30:	ff278de3          	beq	a5,s2,80205e2a <namex+0xbe>
        ilock(ip);
    80205e34:	8552                	mv	a0,s4
    80205e36:	00000097          	auipc	ra,0x0
    80205e3a:	8b6080e7          	jalr	-1866(ra) # 802056ec <ilock>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205e3e:	044a5783          	lhu	a5,68(s4)
    80205e42:	f97793e3          	bne	a5,s7,80205dc8 <namex+0x5c>
        if (nameiparent_ && *path == '\0') {
    80205e46:	000b0563          	beqz	s6,80205e50 <namex+0xe4>
    80205e4a:	0004c783          	lbu	a5,0(s1)
    80205e4e:	d3cd                	beqz	a5,80205df0 <namex+0x84>
        struct inode *next = dirlookup(ip, name, 0);
    80205e50:	4601                	li	a2,0
    80205e52:	85d6                	mv	a1,s5
    80205e54:	8552                	mv	a0,s4
    80205e56:	00000097          	auipc	ra,0x0
    80205e5a:	e60080e7          	jalr	-416(ra) # 80205cb6 <dirlookup>
    80205e5e:	89aa                	mv	s3,a0
        if (next == 0) { iunlockput(ip); return 0; }
    80205e60:	dd51                	beqz	a0,80205dfc <namex+0x90>
        iunlockput(ip);
    80205e62:	8552                	mv	a0,s4
    80205e64:	00000097          	auipc	ra,0x0
    80205e68:	b64080e7          	jalr	-1180(ra) # 802059c8 <iunlockput>
        ip = next;
    80205e6c:	8a4e                	mv	s4,s3
    while (*path == '/') path++;
    80205e6e:	0004c783          	lbu	a5,0(s1)
    80205e72:	01279763          	bne	a5,s2,80205e80 <namex+0x114>
    80205e76:	0485                	addi	s1,s1,1
    80205e78:	0004c783          	lbu	a5,0(s1)
    80205e7c:	ff278de3          	beq	a5,s2,80205e76 <namex+0x10a>
    if (*path == 0) return 0;
    80205e80:	cb95                	beqz	a5,80205eb4 <namex+0x148>
    while (*path != '/' && *path != 0) path++;
    80205e82:	0004c783          	lbu	a5,0(s1)
    80205e86:	89a6                	mv	s3,s1
    int len = path - s;
    80205e88:	4c81                	li	s9,0
    while (*path != '/' && *path != 0) path++;
    80205e8a:	01278963          	beq	a5,s2,80205e9c <namex+0x130>
    80205e8e:	dfb5                	beqz	a5,80205e0a <namex+0x9e>
    80205e90:	0985                	addi	s3,s3,1
    80205e92:	0009c783          	lbu	a5,0(s3)
    80205e96:	ff279ce3          	bne	a5,s2,80205e8e <namex+0x122>
    80205e9a:	bf85                	j	80205e0a <namex+0x9e>
        memmove(name, s, len);
    80205e9c:	8666                	mv	a2,s9
    80205e9e:	85a6                	mv	a1,s1
    80205ea0:	8556                	mv	a0,s5
    80205ea2:	ffffb097          	auipc	ra,0xffffb
    80205ea6:	812080e7          	jalr	-2030(ra) # 802006b4 <memmove>
        name[len] = 0;
    80205eaa:	9cd6                	add	s9,s9,s5
    80205eac:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x801fe000>
    80205eb0:	84ce                	mv	s1,s3
    80205eb2:	bf85                	j	80205e22 <namex+0xb6>
    if (nameiparent_) { iput(ip); return 0; }
    80205eb4:	f20b00e3          	beqz	s6,80205dd4 <namex+0x68>
    80205eb8:	8552                	mv	a0,s4
    80205eba:	00000097          	auipc	ra,0x0
    80205ebe:	9f0080e7          	jalr	-1552(ra) # 802058aa <iput>
    80205ec2:	4a01                	li	s4,0
    80205ec4:	bf01                	j	80205dd4 <namex+0x68>

0000000080205ec6 <dirlink>:
{
    80205ec6:	715d                	addi	sp,sp,-80
    80205ec8:	e486                	sd	ra,72(sp)
    80205eca:	e0a2                	sd	s0,64(sp)
    80205ecc:	f84a                	sd	s2,48(sp)
    80205ece:	f44e                	sd	s3,40(sp)
    80205ed0:	f052                	sd	s4,32(sp)
    80205ed2:	0880                	addi	s0,sp,80
    80205ed4:	892a                	mv	s2,a0
    80205ed6:	8a2e                	mv	s4,a1
    80205ed8:	89b2                	mv	s3,a2
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    80205eda:	4601                	li	a2,0
    80205edc:	00000097          	auipc	ra,0x0
    80205ee0:	dda080e7          	jalr	-550(ra) # 80205cb6 <dirlookup>
    80205ee4:	e141                	bnez	a0,80205f64 <dirlink+0x9e>
    80205ee6:	fc26                	sd	s1,56(sp)
    for (off = 0; off < dp->size; off += sizeof(de)) {
    80205ee8:	04c92483          	lw	s1,76(s2)
    80205eec:	c895                	beqz	s1,80205f20 <dirlink+0x5a>
    80205eee:	4481                	li	s1,0
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205ef0:	02000713          	li	a4,32
    80205ef4:	86a6                	mv	a3,s1
    80205ef6:	fb040613          	addi	a2,s0,-80
    80205efa:	4581                	li	a1,0
    80205efc:	854a                	mv	a0,s2
    80205efe:	00000097          	auipc	ra,0x0
    80205f02:	b1c080e7          	jalr	-1252(ra) # 80205a1a <readi>
    80205f06:	02000793          	li	a5,32
    80205f0a:	06f51363          	bne	a0,a5,80205f70 <dirlink+0xaa>
        if (de.inum == 0) break;                  /* reuse a freed slot */
    80205f0e:	fb042783          	lw	a5,-80(s0)
    80205f12:	c799                	beqz	a5,80205f20 <dirlink+0x5a>
    for (off = 0; off < dp->size; off += sizeof(de)) {
    80205f14:	0204849b          	addiw	s1,s1,32
    80205f18:	04c92783          	lw	a5,76(s2)
    80205f1c:	fcf4eae3          	bltu	s1,a5,80205ef0 <dirlink+0x2a>
    strncpy(de.name, name, DIRSIZ);
    80205f20:	4671                	li	a2,28
    80205f22:	85d2                	mv	a1,s4
    80205f24:	fb440513          	addi	a0,s0,-76
    80205f28:	ffffb097          	auipc	ra,0xffffb
    80205f2c:	832080e7          	jalr	-1998(ra) # 8020075a <strncpy>
    de.inum = inum;
    80205f30:	fb342823          	sw	s3,-80(s0)
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205f34:	02000713          	li	a4,32
    80205f38:	86a6                	mv	a3,s1
    80205f3a:	fb040613          	addi	a2,s0,-80
    80205f3e:	4581                	li	a1,0
    80205f40:	854a                	mv	a0,s2
    80205f42:	00000097          	auipc	ra,0x0
    80205f46:	c0c080e7          	jalr	-1012(ra) # 80205b4e <writei>
    80205f4a:	1501                	addi	a0,a0,-32
    80205f4c:	00a03533          	snez	a0,a0
    80205f50:	40a00533          	neg	a0,a0
    80205f54:	74e2                	ld	s1,56(sp)
}
    80205f56:	60a6                	ld	ra,72(sp)
    80205f58:	6406                	ld	s0,64(sp)
    80205f5a:	7942                	ld	s2,48(sp)
    80205f5c:	79a2                	ld	s3,40(sp)
    80205f5e:	7a02                	ld	s4,32(sp)
    80205f60:	6161                	addi	sp,sp,80
    80205f62:	8082                	ret
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    80205f64:	00000097          	auipc	ra,0x0
    80205f68:	946080e7          	jalr	-1722(ra) # 802058aa <iput>
    80205f6c:	557d                	li	a0,-1
    80205f6e:	b7e5                	j	80205f56 <dirlink+0x90>
            panic("dirlink: short directory read");
    80205f70:	00002517          	auipc	a0,0x2
    80205f74:	c5850513          	addi	a0,a0,-936 # 80207bc8 <etext+0xbc8>
    80205f78:	ffffa097          	auipc	ra,0xffffa
    80205f7c:	67a080e7          	jalr	1658(ra) # 802005f2 <panic>

0000000080205f80 <namei>:

struct inode *namei(char *path)
{
    80205f80:	7179                	addi	sp,sp,-48
    80205f82:	f406                	sd	ra,40(sp)
    80205f84:	f022                	sd	s0,32(sp)
    80205f86:	1800                	addi	s0,sp,48
    char name[DIRSIZ];
    return namex(path, 0, name);
    80205f88:	fd040613          	addi	a2,s0,-48
    80205f8c:	4581                	li	a1,0
    80205f8e:	00000097          	auipc	ra,0x0
    80205f92:	dde080e7          	jalr	-546(ra) # 80205d6c <namex>
}
    80205f96:	70a2                	ld	ra,40(sp)
    80205f98:	7402                	ld	s0,32(sp)
    80205f9a:	6145                	addi	sp,sp,48
    80205f9c:	8082                	ret

0000000080205f9e <nameiparent>:

struct inode *nameiparent(char *path, char *name)
{
    80205f9e:	1141                	addi	sp,sp,-16
    80205fa0:	e406                	sd	ra,8(sp)
    80205fa2:	e022                	sd	s0,0(sp)
    80205fa4:	0800                	addi	s0,sp,16
    80205fa6:	862e                	mv	a2,a1
    return namex(path, 1, name);
    80205fa8:	4585                	li	a1,1
    80205faa:	00000097          	auipc	ra,0x0
    80205fae:	dc2080e7          	jalr	-574(ra) # 80205d6c <namex>
}
    80205fb2:	60a2                	ld	ra,8(sp)
    80205fb4:	6402                	ld	s0,0(sp)
    80205fb6:	0141                	addi	sp,sp,16
    80205fb8:	8082                	ret

0000000080205fba <fileinit>:
static struct {
    struct spinlock lock;
    struct file file[NFILE];
} ftable;

void fileinit(void) { initlock(&ftable.lock, "ftable"); }
    80205fba:	1141                	addi	sp,sp,-16
    80205fbc:	e406                	sd	ra,8(sp)
    80205fbe:	e022                	sd	s0,0(sp)
    80205fc0:	0800                	addi	s0,sp,16
    80205fc2:	00002597          	auipc	a1,0x2
    80205fc6:	c2658593          	addi	a1,a1,-986 # 80207be8 <etext+0xbe8>
    80205fca:	00140517          	auipc	a0,0x140
    80205fce:	86650513          	addi	a0,a0,-1946 # 80345830 <ftable>
    80205fd2:	ffffb097          	auipc	ra,0xffffb
    80205fd6:	2da080e7          	jalr	730(ra) # 802012ac <initlock>
    80205fda:	60a2                	ld	ra,8(sp)
    80205fdc:	6402                	ld	s0,0(sp)
    80205fde:	0141                	addi	sp,sp,16
    80205fe0:	8082                	ret

0000000080205fe2 <filealloc>:

struct file *filealloc(void)
{
    80205fe2:	1101                	addi	sp,sp,-32
    80205fe4:	ec06                	sd	ra,24(sp)
    80205fe6:	e822                	sd	s0,16(sp)
    80205fe8:	e426                	sd	s1,8(sp)
    80205fea:	1000                	addi	s0,sp,32
    acquire(&ftable.lock);
    80205fec:	00140517          	auipc	a0,0x140
    80205ff0:	84450513          	addi	a0,a0,-1980 # 80345830 <ftable>
    80205ff4:	ffffb097          	auipc	ra,0xffffb
    80205ff8:	334080e7          	jalr	820(ra) # 80201328 <acquire>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    80205ffc:	00140497          	auipc	s1,0x140
    80206000:	84c48493          	addi	s1,s1,-1972 # 80345848 <ftable+0x18>
    80206004:	00140717          	auipc	a4,0x140
    80206008:	7e470713          	addi	a4,a4,2020 # 803467e8 <ftable+0xfb8>
        if (f->ref == 0) {
    8020600c:	40dc                	lw	a5,4(s1)
    8020600e:	cf99                	beqz	a5,8020602c <filealloc+0x4a>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    80206010:	02848493          	addi	s1,s1,40
    80206014:	fee49ce3          	bne	s1,a4,8020600c <filealloc+0x2a>
            f->ref = 1;
            release(&ftable.lock);
            return f;
        }
    }
    release(&ftable.lock);
    80206018:	00140517          	auipc	a0,0x140
    8020601c:	81850513          	addi	a0,a0,-2024 # 80345830 <ftable>
    80206020:	ffffb097          	auipc	ra,0xffffb
    80206024:	3bc080e7          	jalr	956(ra) # 802013dc <release>
    return 0;
    80206028:	4481                	li	s1,0
    8020602a:	a819                	j	80206040 <filealloc+0x5e>
            f->ref = 1;
    8020602c:	4785                	li	a5,1
    8020602e:	c0dc                	sw	a5,4(s1)
            release(&ftable.lock);
    80206030:	00140517          	auipc	a0,0x140
    80206034:	80050513          	addi	a0,a0,-2048 # 80345830 <ftable>
    80206038:	ffffb097          	auipc	ra,0xffffb
    8020603c:	3a4080e7          	jalr	932(ra) # 802013dc <release>
}
    80206040:	8526                	mv	a0,s1
    80206042:	60e2                	ld	ra,24(sp)
    80206044:	6442                	ld	s0,16(sp)
    80206046:	64a2                	ld	s1,8(sp)
    80206048:	6105                	addi	sp,sp,32
    8020604a:	8082                	ret

000000008020604c <filedup>:

struct file *filedup(struct file *f)
{
    8020604c:	1101                	addi	sp,sp,-32
    8020604e:	ec06                	sd	ra,24(sp)
    80206050:	e822                	sd	s0,16(sp)
    80206052:	e426                	sd	s1,8(sp)
    80206054:	1000                	addi	s0,sp,32
    80206056:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    80206058:	0013f517          	auipc	a0,0x13f
    8020605c:	7d850513          	addi	a0,a0,2008 # 80345830 <ftable>
    80206060:	ffffb097          	auipc	ra,0xffffb
    80206064:	2c8080e7          	jalr	712(ra) # 80201328 <acquire>
    if (f->ref < 1) panic("filedup");
    80206068:	40dc                	lw	a5,4(s1)
    8020606a:	02f05263          	blez	a5,8020608e <filedup+0x42>
    f->ref++;
    8020606e:	2785                	addiw	a5,a5,1
    80206070:	c0dc                	sw	a5,4(s1)
    release(&ftable.lock);
    80206072:	0013f517          	auipc	a0,0x13f
    80206076:	7be50513          	addi	a0,a0,1982 # 80345830 <ftable>
    8020607a:	ffffb097          	auipc	ra,0xffffb
    8020607e:	362080e7          	jalr	866(ra) # 802013dc <release>
    return f;
}
    80206082:	8526                	mv	a0,s1
    80206084:	60e2                	ld	ra,24(sp)
    80206086:	6442                	ld	s0,16(sp)
    80206088:	64a2                	ld	s1,8(sp)
    8020608a:	6105                	addi	sp,sp,32
    8020608c:	8082                	ret
    if (f->ref < 1) panic("filedup");
    8020608e:	00002517          	auipc	a0,0x2
    80206092:	b6250513          	addi	a0,a0,-1182 # 80207bf0 <etext+0xbf0>
    80206096:	ffffa097          	auipc	ra,0xffffa
    8020609a:	55c080e7          	jalr	1372(ra) # 802005f2 <panic>

000000008020609e <fileclose>:

void fileclose(struct file *f)
{
    8020609e:	7139                	addi	sp,sp,-64
    802060a0:	fc06                	sd	ra,56(sp)
    802060a2:	f822                	sd	s0,48(sp)
    802060a4:	f426                	sd	s1,40(sp)
    802060a6:	0080                	addi	s0,sp,64
    802060a8:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    802060aa:	0013f517          	auipc	a0,0x13f
    802060ae:	78650513          	addi	a0,a0,1926 # 80345830 <ftable>
    802060b2:	ffffb097          	auipc	ra,0xffffb
    802060b6:	276080e7          	jalr	630(ra) # 80201328 <acquire>
    if (f->ref < 1) panic("fileclose");
    802060ba:	40dc                	lw	a5,4(s1)
    802060bc:	04f05c63          	blez	a5,80206114 <fileclose+0x76>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    802060c0:	37fd                	addiw	a5,a5,-1
    802060c2:	0007871b          	sext.w	a4,a5
    802060c6:	c0dc                	sw	a5,4(s1)
    802060c8:	06e04263          	bgtz	a4,8020612c <fileclose+0x8e>
    802060cc:	f04a                	sd	s2,32(sp)
    802060ce:	ec4e                	sd	s3,24(sp)
    802060d0:	e852                	sd	s4,16(sp)
    802060d2:	e456                	sd	s5,8(sp)

    struct file ff = *f;                 /* copy, then free the slot */
    802060d4:	0004a903          	lw	s2,0(s1)
    802060d8:	0094ca83          	lbu	s5,9(s1)
    802060dc:	0104ba03          	ld	s4,16(s1)
    802060e0:	0184b983          	ld	s3,24(s1)
    f->ref = 0;
    802060e4:	0004a223          	sw	zero,4(s1)
    f->type = FD_NONE;
    802060e8:	0004a023          	sw	zero,0(s1)
    release(&ftable.lock);
    802060ec:	0013f517          	auipc	a0,0x13f
    802060f0:	74450513          	addi	a0,a0,1860 # 80345830 <ftable>
    802060f4:	ffffb097          	auipc	ra,0xffffb
    802060f8:	2e8080e7          	jalr	744(ra) # 802013dc <release>

    if (ff.type == FD_PIPE)
    802060fc:	4785                	li	a5,1
    802060fe:	04f90463          	beq	s2,a5,80206146 <fileclose+0xa8>
        pipeclose(ff.pipe, ff.writable);
    else if (ff.type == FD_INODE || ff.type == FD_DEVICE)
    80206102:	3979                	addiw	s2,s2,-2
    80206104:	4785                	li	a5,1
    80206106:	0527fb63          	bgeu	a5,s2,8020615c <fileclose+0xbe>
    8020610a:	7902                	ld	s2,32(sp)
    8020610c:	69e2                	ld	s3,24(sp)
    8020610e:	6a42                	ld	s4,16(sp)
    80206110:	6aa2                	ld	s5,8(sp)
    80206112:	a02d                	j	8020613c <fileclose+0x9e>
    80206114:	f04a                	sd	s2,32(sp)
    80206116:	ec4e                	sd	s3,24(sp)
    80206118:	e852                	sd	s4,16(sp)
    8020611a:	e456                	sd	s5,8(sp)
    if (f->ref < 1) panic("fileclose");
    8020611c:	00002517          	auipc	a0,0x2
    80206120:	adc50513          	addi	a0,a0,-1316 # 80207bf8 <etext+0xbf8>
    80206124:	ffffa097          	auipc	ra,0xffffa
    80206128:	4ce080e7          	jalr	1230(ra) # 802005f2 <panic>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    8020612c:	0013f517          	auipc	a0,0x13f
    80206130:	70450513          	addi	a0,a0,1796 # 80345830 <ftable>
    80206134:	ffffb097          	auipc	ra,0xffffb
    80206138:	2a8080e7          	jalr	680(ra) # 802013dc <release>
        iput(ff.ip);
}
    8020613c:	70e2                	ld	ra,56(sp)
    8020613e:	7442                	ld	s0,48(sp)
    80206140:	74a2                	ld	s1,40(sp)
    80206142:	6121                	addi	sp,sp,64
    80206144:	8082                	ret
        pipeclose(ff.pipe, ff.writable);
    80206146:	85d6                	mv	a1,s5
    80206148:	8552                	mv	a0,s4
    8020614a:	00000097          	auipc	ra,0x0
    8020614e:	324080e7          	jalr	804(ra) # 8020646e <pipeclose>
    80206152:	7902                	ld	s2,32(sp)
    80206154:	69e2                	ld	s3,24(sp)
    80206156:	6a42                	ld	s4,16(sp)
    80206158:	6aa2                	ld	s5,8(sp)
    8020615a:	b7cd                	j	8020613c <fileclose+0x9e>
        iput(ff.ip);
    8020615c:	854e                	mv	a0,s3
    8020615e:	fffff097          	auipc	ra,0xfffff
    80206162:	74c080e7          	jalr	1868(ra) # 802058aa <iput>
    80206166:	7902                	ld	s2,32(sp)
    80206168:	69e2                	ld	s3,24(sp)
    8020616a:	6a42                	ld	s4,16(sp)
    8020616c:	6aa2                	ld	s5,8(sp)
    8020616e:	b7f9                	j	8020613c <fileclose+0x9e>

0000000080206170 <filestat>:

int filestat(struct file *f, uint64 uaddr)
{
    if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80206170:	411c                	lw	a5,0(a0)
    80206172:	37f9                	addiw	a5,a5,-2
    80206174:	4705                	li	a4,1
    80206176:	06f76063          	bltu	a4,a5,802061d6 <filestat+0x66>
{
    8020617a:	7139                	addi	sp,sp,-64
    8020617c:	fc06                	sd	ra,56(sp)
    8020617e:	f822                	sd	s0,48(sp)
    80206180:	f426                	sd	s1,40(sp)
    80206182:	f04a                	sd	s2,32(sp)
    80206184:	0080                	addi	s0,sp,64
    80206186:	84aa                	mv	s1,a0
    80206188:	892e                	mv	s2,a1
        struct stat st;
        ilock(f->ip);
    8020618a:	6d08                	ld	a0,24(a0)
    8020618c:	fffff097          	auipc	ra,0xfffff
    80206190:	560080e7          	jalr	1376(ra) # 802056ec <ilock>
        stati(f->ip, &st);
    80206194:	fc840593          	addi	a1,s0,-56
    80206198:	6c88                	ld	a0,24(s1)
    8020619a:	00000097          	auipc	ra,0x0
    8020619e:	856080e7          	jalr	-1962(ra) # 802059f0 <stati>
        iunlock(f->ip);
    802061a2:	6c88                	ld	a0,24(s1)
    802061a4:	fffff097          	auipc	ra,0xfffff
    802061a8:	60e080e7          	jalr	1550(ra) # 802057b2 <iunlock>
        if (copyout(myproc()->pagetable, uaddr, (char *)&st, sizeof(st)) < 0)
    802061ac:	ffffb097          	auipc	ra,0xffffb
    802061b0:	5ba080e7          	jalr	1466(ra) # 80201766 <myproc>
    802061b4:	46e1                	li	a3,24
    802061b6:	fc840613          	addi	a2,s0,-56
    802061ba:	85ca                	mv	a1,s2
    802061bc:	6928                	ld	a0,80(a0)
    802061be:	ffffd097          	auipc	ra,0xffffd
    802061c2:	dc0080e7          	jalr	-576(ra) # 80202f7e <copyout>
    802061c6:	41f5551b          	sraiw	a0,a0,0x1f
            return -1;
        return 0;
    }
    return -1;
}
    802061ca:	70e2                	ld	ra,56(sp)
    802061cc:	7442                	ld	s0,48(sp)
    802061ce:	74a2                	ld	s1,40(sp)
    802061d0:	7902                	ld	s2,32(sp)
    802061d2:	6121                	addi	sp,sp,64
    802061d4:	8082                	ret
    return -1;
    802061d6:	557d                	li	a0,-1
}
    802061d8:	8082                	ret

00000000802061da <fileread>:

int fileread(struct file *f, uint64 uaddr, int n)
{
    802061da:	7179                	addi	sp,sp,-48
    802061dc:	f406                	sd	ra,40(sp)
    802061de:	f022                	sd	s0,32(sp)
    802061e0:	e84a                	sd	s2,16(sp)
    802061e2:	1800                	addi	s0,sp,48
    if (f->readable == 0) return -1;
    802061e4:	00854783          	lbu	a5,8(a0)
    802061e8:	cbcd                	beqz	a5,8020629a <fileread+0xc0>
    802061ea:	ec26                	sd	s1,24(sp)
    802061ec:	e44e                	sd	s3,8(sp)
    802061ee:	84aa                	mv	s1,a0
    802061f0:	89ae                	mv	s3,a1
    802061f2:	8932                	mv	s2,a2

    if (f->type == FD_PIPE)
    802061f4:	411c                	lw	a5,0(a0)
    802061f6:	4705                	li	a4,1
    802061f8:	04e78963          	beq	a5,a4,8020624a <fileread+0x70>
        return piperead(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    802061fc:	470d                	li	a4,3
    802061fe:	04e78f63          	beq	a5,a4,8020625c <fileread+0x82>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
        return devsw[f->major].read(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80206202:	4709                	li	a4,2
    80206204:	08e79363          	bne	a5,a4,8020628a <fileread+0xb0>
        ilock(f->ip);
    80206208:	6d08                	ld	a0,24(a0)
    8020620a:	fffff097          	auipc	ra,0xfffff
    8020620e:	4e2080e7          	jalr	1250(ra) # 802056ec <ilock>
        int r = readi(f->ip, 1, uaddr, f->off, n);
    80206212:	874a                	mv	a4,s2
    80206214:	5094                	lw	a3,32(s1)
    80206216:	864e                	mv	a2,s3
    80206218:	4585                	li	a1,1
    8020621a:	6c88                	ld	a0,24(s1)
    8020621c:	fffff097          	auipc	ra,0xfffff
    80206220:	7fe080e7          	jalr	2046(ra) # 80205a1a <readi>
    80206224:	892a                	mv	s2,a0
        if (r > 0) f->off += r;          /* offset update under the inode lock */
    80206226:	00a05563          	blez	a0,80206230 <fileread+0x56>
    8020622a:	509c                	lw	a5,32(s1)
    8020622c:	9fa9                	addw	a5,a5,a0
    8020622e:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80206230:	6c88                	ld	a0,24(s1)
    80206232:	fffff097          	auipc	ra,0xfffff
    80206236:	580080e7          	jalr	1408(ra) # 802057b2 <iunlock>
        return r;
    8020623a:	64e2                	ld	s1,24(sp)
    8020623c:	69a2                	ld	s3,8(sp)
    }
    panic("fileread");
}
    8020623e:	854a                	mv	a0,s2
    80206240:	70a2                	ld	ra,40(sp)
    80206242:	7402                	ld	s0,32(sp)
    80206244:	6942                	ld	s2,16(sp)
    80206246:	6145                	addi	sp,sp,48
    80206248:	8082                	ret
        return piperead(f->pipe, uaddr, n);
    8020624a:	6908                	ld	a0,16(a0)
    8020624c:	00000097          	auipc	ra,0x0
    80206250:	38a080e7          	jalr	906(ra) # 802065d6 <piperead>
    80206254:	892a                	mv	s2,a0
    80206256:	64e2                	ld	s1,24(sp)
    80206258:	69a2                	ld	s3,8(sp)
    8020625a:	b7d5                	j	8020623e <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    8020625c:	02451783          	lh	a5,36(a0)
    80206260:	03079693          	slli	a3,a5,0x30
    80206264:	92c1                	srli	a3,a3,0x30
    80206266:	4725                	li	a4,9
    80206268:	02d76b63          	bltu	a4,a3,8020629e <fileread+0xc4>
    8020626c:	0792                	slli	a5,a5,0x4
    8020626e:	0013f717          	auipc	a4,0x13f
    80206272:	52270713          	addi	a4,a4,1314 # 80345790 <devsw>
    80206276:	97ba                	add	a5,a5,a4
    80206278:	639c                	ld	a5,0(a5)
    8020627a:	c795                	beqz	a5,802062a6 <fileread+0xcc>
        return devsw[f->major].read(uaddr, n);
    8020627c:	85b2                	mv	a1,a2
    8020627e:	854e                	mv	a0,s3
    80206280:	9782                	jalr	a5
    80206282:	892a                	mv	s2,a0
    80206284:	64e2                	ld	s1,24(sp)
    80206286:	69a2                	ld	s3,8(sp)
    80206288:	bf5d                	j	8020623e <fileread+0x64>
    panic("fileread");
    8020628a:	00002517          	auipc	a0,0x2
    8020628e:	97e50513          	addi	a0,a0,-1666 # 80207c08 <etext+0xc08>
    80206292:	ffffa097          	auipc	ra,0xffffa
    80206296:	360080e7          	jalr	864(ra) # 802005f2 <panic>
    if (f->readable == 0) return -1;
    8020629a:	597d                	li	s2,-1
    8020629c:	b74d                	j	8020623e <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    8020629e:	597d                	li	s2,-1
    802062a0:	64e2                	ld	s1,24(sp)
    802062a2:	69a2                	ld	s3,8(sp)
    802062a4:	bf69                	j	8020623e <fileread+0x64>
    802062a6:	597d                	li	s2,-1
    802062a8:	64e2                	ld	s1,24(sp)
    802062aa:	69a2                	ld	s3,8(sp)
    802062ac:	bf49                	j	8020623e <fileread+0x64>

00000000802062ae <filewrite>:

int filewrite(struct file *f, uint64 uaddr, int n)
{
    802062ae:	7179                	addi	sp,sp,-48
    802062b0:	f406                	sd	ra,40(sp)
    802062b2:	f022                	sd	s0,32(sp)
    802062b4:	e84a                	sd	s2,16(sp)
    802062b6:	1800                	addi	s0,sp,48
    if (f->writable == 0) return -1;
    802062b8:	00954783          	lbu	a5,9(a0)
    802062bc:	cfdd                	beqz	a5,8020637a <filewrite+0xcc>
    802062be:	ec26                	sd	s1,24(sp)
    802062c0:	e44e                	sd	s3,8(sp)
    802062c2:	84aa                	mv	s1,a0
    802062c4:	892e                	mv	s2,a1
    802062c6:	89b2                	mv	s3,a2

    if (f->type == FD_PIPE)
    802062c8:	411c                	lw	a5,0(a0)
    802062ca:	4705                	li	a4,1
    802062cc:	04e78c63          	beq	a5,a4,80206324 <filewrite+0x76>
        return pipewrite(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    802062d0:	470d                	li	a4,3
    802062d2:	06e78263          	beq	a5,a4,80206336 <filewrite+0x88>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
        return devsw[f->major].write(uaddr, n);
    }
    if (f->type == FD_INODE) {
    802062d6:	4709                	li	a4,2
    802062d8:	08e79963          	bne	a5,a4,8020636a <filewrite+0xbc>
        ilock(f->ip);
    802062dc:	6d08                	ld	a0,24(a0)
    802062de:	fffff097          	auipc	ra,0xfffff
    802062e2:	40e080e7          	jalr	1038(ra) # 802056ec <ilock>
        int r = writei(f->ip, 1, uaddr, f->off, n);
    802062e6:	874e                	mv	a4,s3
    802062e8:	5094                	lw	a3,32(s1)
    802062ea:	864a                	mv	a2,s2
    802062ec:	4585                	li	a1,1
    802062ee:	6c88                	ld	a0,24(s1)
    802062f0:	00000097          	auipc	ra,0x0
    802062f4:	85e080e7          	jalr	-1954(ra) # 80205b4e <writei>
    802062f8:	892a                	mv	s2,a0
        if (r > 0) f->off += r;
    802062fa:	00a05563          	blez	a0,80206304 <filewrite+0x56>
    802062fe:	509c                	lw	a5,32(s1)
    80206300:	9fa9                	addw	a5,a5,a0
    80206302:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80206304:	6c88                	ld	a0,24(s1)
    80206306:	fffff097          	auipc	ra,0xfffff
    8020630a:	4ac080e7          	jalr	1196(ra) # 802057b2 <iunlock>
        return (r == n) ? n : -1;        /* short write = disk full = error */
    8020630e:	05298b63          	beq	s3,s2,80206364 <filewrite+0xb6>
    80206312:	597d                	li	s2,-1
    80206314:	64e2                	ld	s1,24(sp)
    80206316:	69a2                	ld	s3,8(sp)
    }
    panic("filewrite");
}
    80206318:	854a                	mv	a0,s2
    8020631a:	70a2                	ld	ra,40(sp)
    8020631c:	7402                	ld	s0,32(sp)
    8020631e:	6942                	ld	s2,16(sp)
    80206320:	6145                	addi	sp,sp,48
    80206322:	8082                	ret
        return pipewrite(f->pipe, uaddr, n);
    80206324:	6908                	ld	a0,16(a0)
    80206326:	00000097          	auipc	ra,0x0
    8020632a:	1b8080e7          	jalr	440(ra) # 802064de <pipewrite>
    8020632e:	892a                	mv	s2,a0
    80206330:	64e2                	ld	s1,24(sp)
    80206332:	69a2                	ld	s3,8(sp)
    80206334:	b7d5                	j	80206318 <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80206336:	02451783          	lh	a5,36(a0)
    8020633a:	03079693          	slli	a3,a5,0x30
    8020633e:	92c1                	srli	a3,a3,0x30
    80206340:	4725                	li	a4,9
    80206342:	02d76e63          	bltu	a4,a3,8020637e <filewrite+0xd0>
    80206346:	0792                	slli	a5,a5,0x4
    80206348:	0013f717          	auipc	a4,0x13f
    8020634c:	44870713          	addi	a4,a4,1096 # 80345790 <devsw>
    80206350:	97ba                	add	a5,a5,a4
    80206352:	679c                	ld	a5,8(a5)
    80206354:	cb8d                	beqz	a5,80206386 <filewrite+0xd8>
        return devsw[f->major].write(uaddr, n);
    80206356:	85b2                	mv	a1,a2
    80206358:	854a                	mv	a0,s2
    8020635a:	9782                	jalr	a5
    8020635c:	892a                	mv	s2,a0
    8020635e:	64e2                	ld	s1,24(sp)
    80206360:	69a2                	ld	s3,8(sp)
    80206362:	bf5d                	j	80206318 <filewrite+0x6a>
    80206364:	64e2                	ld	s1,24(sp)
    80206366:	69a2                	ld	s3,8(sp)
    80206368:	bf45                	j	80206318 <filewrite+0x6a>
    panic("filewrite");
    8020636a:	00002517          	auipc	a0,0x2
    8020636e:	8ae50513          	addi	a0,a0,-1874 # 80207c18 <etext+0xc18>
    80206372:	ffffa097          	auipc	ra,0xffffa
    80206376:	280080e7          	jalr	640(ra) # 802005f2 <panic>
    if (f->writable == 0) return -1;
    8020637a:	597d                	li	s2,-1
    8020637c:	bf71                	j	80206318 <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    8020637e:	597d                	li	s2,-1
    80206380:	64e2                	ld	s1,24(sp)
    80206382:	69a2                	ld	s3,8(sp)
    80206384:	bf51                	j	80206318 <filewrite+0x6a>
    80206386:	597d                	li	s2,-1
    80206388:	64e2                	ld	s1,24(sp)
    8020638a:	69a2                	ld	s3,8(sp)
    8020638c:	b771                	j	80206318 <filewrite+0x6a>

000000008020638e <pipealloc>:
    int    readopen;
    int    writeopen;
};

int pipealloc(struct file **f0, struct file **f1)
{
    8020638e:	7179                	addi	sp,sp,-48
    80206390:	f406                	sd	ra,40(sp)
    80206392:	f022                	sd	s0,32(sp)
    80206394:	ec26                	sd	s1,24(sp)
    80206396:	e052                	sd	s4,0(sp)
    80206398:	1800                	addi	s0,sp,48
    8020639a:	84aa                	mv	s1,a0
    8020639c:	8a2e                	mv	s4,a1
    struct pipe *pi = 0;
    *f0 = *f1 = 0;
    8020639e:	0005b023          	sd	zero,0(a1)
    802063a2:	00053023          	sd	zero,0(a0)

    if ((*f0 = filealloc()) == 0) goto bad;
    802063a6:	00000097          	auipc	ra,0x0
    802063aa:	c3c080e7          	jalr	-964(ra) # 80205fe2 <filealloc>
    802063ae:	e088                	sd	a0,0(s1)
    802063b0:	cd49                	beqz	a0,8020644a <pipealloc+0xbc>
    if ((*f1 = filealloc()) == 0) goto bad;
    802063b2:	00000097          	auipc	ra,0x0
    802063b6:	c30080e7          	jalr	-976(ra) # 80205fe2 <filealloc>
    802063ba:	00aa3023          	sd	a0,0(s4)
    802063be:	c141                	beqz	a0,8020643e <pipealloc+0xb0>
    802063c0:	e84a                	sd	s2,16(sp)
    if ((pi = (struct pipe *)palloc()) == 0) goto bad;
    802063c2:	ffffb097          	auipc	ra,0xffffb
    802063c6:	cd8080e7          	jalr	-808(ra) # 8020109a <palloc>
    802063ca:	892a                	mv	s2,a0
    802063cc:	c13d                	beqz	a0,80206432 <pipealloc+0xa4>
    802063ce:	e44e                	sd	s3,8(sp)

    pi->readopen  = 1;
    802063d0:	4985                	li	s3,1
    802063d2:	23352023          	sw	s3,544(a0)
    pi->writeopen = 1;
    802063d6:	23352223          	sw	s3,548(a0)
    pi->nread  = 0;
    802063da:	20052c23          	sw	zero,536(a0)
    pi->nwrite = 0;
    802063de:	20052e23          	sw	zero,540(a0)
    initlock(&pi->lock, "pipe");
    802063e2:	00002597          	auipc	a1,0x2
    802063e6:	84658593          	addi	a1,a1,-1978 # 80207c28 <etext+0xc28>
    802063ea:	ffffb097          	auipc	ra,0xffffb
    802063ee:	ec2080e7          	jalr	-318(ra) # 802012ac <initlock>

    (*f0)->type = FD_PIPE; (*f0)->readable = 1; (*f0)->writable = 0; (*f0)->pipe = pi;
    802063f2:	609c                	ld	a5,0(s1)
    802063f4:	0137a023          	sw	s3,0(a5)
    802063f8:	609c                	ld	a5,0(s1)
    802063fa:	01378423          	sb	s3,8(a5)
    802063fe:	609c                	ld	a5,0(s1)
    80206400:	000784a3          	sb	zero,9(a5)
    80206404:	609c                	ld	a5,0(s1)
    80206406:	0127b823          	sd	s2,16(a5)
    (*f1)->type = FD_PIPE; (*f1)->readable = 0; (*f1)->writable = 1; (*f1)->pipe = pi;
    8020640a:	000a3783          	ld	a5,0(s4)
    8020640e:	0137a023          	sw	s3,0(a5)
    80206412:	000a3783          	ld	a5,0(s4)
    80206416:	00078423          	sb	zero,8(a5)
    8020641a:	000a3783          	ld	a5,0(s4)
    8020641e:	013784a3          	sb	s3,9(a5)
    80206422:	000a3783          	ld	a5,0(s4)
    80206426:	0127b823          	sd	s2,16(a5)
    return 0;
    8020642a:	4501                	li	a0,0
    8020642c:	6942                	ld	s2,16(sp)
    8020642e:	69a2                	ld	s3,8(sp)
    80206430:	a03d                	j	8020645e <pipealloc+0xd0>

bad:
    if (*f0) fileclose(*f0);
    80206432:	6088                	ld	a0,0(s1)
    80206434:	c119                	beqz	a0,8020643a <pipealloc+0xac>
    80206436:	6942                	ld	s2,16(sp)
    80206438:	a029                	j	80206442 <pipealloc+0xb4>
    8020643a:	6942                	ld	s2,16(sp)
    8020643c:	a039                	j	8020644a <pipealloc+0xbc>
    8020643e:	6088                	ld	a0,0(s1)
    80206440:	c50d                	beqz	a0,8020646a <pipealloc+0xdc>
    80206442:	00000097          	auipc	ra,0x0
    80206446:	c5c080e7          	jalr	-932(ra) # 8020609e <fileclose>
    if (*f1) fileclose(*f1);
    8020644a:	000a3783          	ld	a5,0(s4)
    return -1;
    8020644e:	557d                	li	a0,-1
    if (*f1) fileclose(*f1);
    80206450:	c799                	beqz	a5,8020645e <pipealloc+0xd0>
    80206452:	853e                	mv	a0,a5
    80206454:	00000097          	auipc	ra,0x0
    80206458:	c4a080e7          	jalr	-950(ra) # 8020609e <fileclose>
    return -1;
    8020645c:	557d                	li	a0,-1
}
    8020645e:	70a2                	ld	ra,40(sp)
    80206460:	7402                	ld	s0,32(sp)
    80206462:	64e2                	ld	s1,24(sp)
    80206464:	6a02                	ld	s4,0(sp)
    80206466:	6145                	addi	sp,sp,48
    80206468:	8082                	ret
    return -1;
    8020646a:	557d                	li	a0,-1
    8020646c:	bfcd                	j	8020645e <pipealloc+0xd0>

000000008020646e <pipeclose>:

void pipeclose(struct pipe *pi, int writable)
{
    8020646e:	1101                	addi	sp,sp,-32
    80206470:	ec06                	sd	ra,24(sp)
    80206472:	e822                	sd	s0,16(sp)
    80206474:	e426                	sd	s1,8(sp)
    80206476:	e04a                	sd	s2,0(sp)
    80206478:	1000                	addi	s0,sp,32
    8020647a:	84aa                	mv	s1,a0
    8020647c:	892e                	mv	s2,a1
    acquire(&pi->lock);
    8020647e:	ffffb097          	auipc	ra,0xffffb
    80206482:	eaa080e7          	jalr	-342(ra) # 80201328 <acquire>
    if (writable) {
    80206486:	02090d63          	beqz	s2,802064c0 <pipeclose+0x52>
        pi->writeopen = 0;
    8020648a:	2204a223          	sw	zero,548(s1)
        wakeup(&pi->nread);          /* blocked readers must see EOF */
    8020648e:	21848513          	addi	a0,s1,536
    80206492:	ffffc097          	auipc	ra,0xffffc
    80206496:	b00080e7          	jalr	-1280(ra) # 80201f92 <wakeup>
    } else {
        pi->readopen = 0;
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    }
    if (pi->readopen == 0 && pi->writeopen == 0) {
    8020649a:	2204b783          	ld	a5,544(s1)
    8020649e:	eb95                	bnez	a5,802064d2 <pipeclose+0x64>
        release(&pi->lock);
    802064a0:	8526                	mv	a0,s1
    802064a2:	ffffb097          	auipc	ra,0xffffb
    802064a6:	f3a080e7          	jalr	-198(ra) # 802013dc <release>
        pfree(pi);
    802064aa:	8526                	mv	a0,s1
    802064ac:	ffffb097          	auipc	ra,0xffffb
    802064b0:	cfe080e7          	jalr	-770(ra) # 802011aa <pfree>
    } else {
        release(&pi->lock);
    }
}
    802064b4:	60e2                	ld	ra,24(sp)
    802064b6:	6442                	ld	s0,16(sp)
    802064b8:	64a2                	ld	s1,8(sp)
    802064ba:	6902                	ld	s2,0(sp)
    802064bc:	6105                	addi	sp,sp,32
    802064be:	8082                	ret
        pi->readopen = 0;
    802064c0:	2204a023          	sw	zero,544(s1)
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    802064c4:	21c48513          	addi	a0,s1,540
    802064c8:	ffffc097          	auipc	ra,0xffffc
    802064cc:	aca080e7          	jalr	-1334(ra) # 80201f92 <wakeup>
    802064d0:	b7e9                	j	8020649a <pipeclose+0x2c>
        release(&pi->lock);
    802064d2:	8526                	mv	a0,s1
    802064d4:	ffffb097          	auipc	ra,0xffffb
    802064d8:	f08080e7          	jalr	-248(ra) # 802013dc <release>
}
    802064dc:	bfe1                	j	802064b4 <pipeclose+0x46>

00000000802064de <pipewrite>:

int pipewrite(struct pipe *pi, uint64 uaddr, int n)
{
    802064de:	711d                	addi	sp,sp,-96
    802064e0:	ec86                	sd	ra,88(sp)
    802064e2:	e8a2                	sd	s0,80(sp)
    802064e4:	e4a6                	sd	s1,72(sp)
    802064e6:	e0ca                	sd	s2,64(sp)
    802064e8:	fc4e                	sd	s3,56(sp)
    802064ea:	f852                	sd	s4,48(sp)
    802064ec:	f456                	sd	s5,40(sp)
    802064ee:	1080                	addi	s0,sp,96
    802064f0:	84aa                	mv	s1,a0
    802064f2:	8aae                	mv	s5,a1
    802064f4:	8a32                	mv	s4,a2
    struct proc *pr = myproc();
    802064f6:	ffffb097          	auipc	ra,0xffffb
    802064fa:	270080e7          	jalr	624(ra) # 80201766 <myproc>
    802064fe:	89aa                	mv	s3,a0
    int i = 0;

    acquire(&pi->lock);
    80206500:	8526                	mv	a0,s1
    80206502:	ffffb097          	auipc	ra,0xffffb
    80206506:	e26080e7          	jalr	-474(ra) # 80201328 <acquire>
    while (i < n) {
    8020650a:	0d405163          	blez	s4,802065cc <pipewrite+0xee>
    8020650e:	f05a                	sd	s6,32(sp)
    80206510:	ec5e                	sd	s7,24(sp)
    int i = 0;
    80206512:	4901                	li	s2,0
        if (pi->readopen == 0 || pr->killed) {
            release(&pi->lock);
            return -1;
        }
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
            wakeup(&pi->nread);
    80206514:	21848b93          	addi	s7,s1,536
            sleep(&pi->nwrite, &pi->lock);
    80206518:	21c48b13          	addi	s6,s1,540
    8020651c:	a081                	j	8020655c <pipewrite+0x7e>
            release(&pi->lock);
    8020651e:	8526                	mv	a0,s1
    80206520:	ffffb097          	auipc	ra,0xffffb
    80206524:	ebc080e7          	jalr	-324(ra) # 802013dc <release>
            return -1;
    80206528:	597d                	li	s2,-1
    8020652a:	7b02                	ld	s6,32(sp)
    8020652c:	6be2                	ld	s7,24(sp)
        }
    }
    wakeup(&pi->nread);
    release(&pi->lock);
    return i;
}
    8020652e:	854a                	mv	a0,s2
    80206530:	60e6                	ld	ra,88(sp)
    80206532:	6446                	ld	s0,80(sp)
    80206534:	64a6                	ld	s1,72(sp)
    80206536:	6906                	ld	s2,64(sp)
    80206538:	79e2                	ld	s3,56(sp)
    8020653a:	7a42                	ld	s4,48(sp)
    8020653c:	7aa2                	ld	s5,40(sp)
    8020653e:	6125                	addi	sp,sp,96
    80206540:	8082                	ret
            wakeup(&pi->nread);
    80206542:	855e                	mv	a0,s7
    80206544:	ffffc097          	auipc	ra,0xffffc
    80206548:	a4e080e7          	jalr	-1458(ra) # 80201f92 <wakeup>
            sleep(&pi->nwrite, &pi->lock);
    8020654c:	85a6                	mv	a1,s1
    8020654e:	855a                	mv	a0,s6
    80206550:	ffffc097          	auipc	ra,0xffffc
    80206554:	8bc080e7          	jalr	-1860(ra) # 80201e0c <sleep>
    while (i < n) {
    80206558:	05495c63          	bge	s2,s4,802065b0 <pipewrite+0xd2>
        if (pi->readopen == 0 || pr->killed) {
    8020655c:	2204a783          	lw	a5,544(s1)
    80206560:	dfdd                	beqz	a5,8020651e <pipewrite+0x40>
    80206562:	0289a783          	lw	a5,40(s3)
    80206566:	ffc5                	bnez	a5,8020651e <pipewrite+0x40>
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
    80206568:	2184a783          	lw	a5,536(s1)
    8020656c:	21c4a703          	lw	a4,540(s1)
    80206570:	2007879b          	addiw	a5,a5,512
    80206574:	fcf707e3          	beq	a4,a5,80206542 <pipewrite+0x64>
            if (copyin(pr->pagetable, &ch, uaddr + i, 1) < 0) break;
    80206578:	4685                	li	a3,1
    8020657a:	01590633          	add	a2,s2,s5
    8020657e:	faf40593          	addi	a1,s0,-81
    80206582:	0509b503          	ld	a0,80(s3)
    80206586:	ffffd097          	auipc	ra,0xffffd
    8020658a:	aec080e7          	jalr	-1300(ra) # 80203072 <copyin>
    8020658e:	04054163          	bltz	a0,802065d0 <pipewrite+0xf2>
            pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80206592:	21c4a783          	lw	a5,540(s1)
    80206596:	0017871b          	addiw	a4,a5,1
    8020659a:	20e4ae23          	sw	a4,540(s1)
    8020659e:	1ff7f793          	andi	a5,a5,511
    802065a2:	97a6                	add	a5,a5,s1
    802065a4:	faf44703          	lbu	a4,-81(s0)
    802065a8:	00e78c23          	sb	a4,24(a5)
            i++;
    802065ac:	2905                	addiw	s2,s2,1
    802065ae:	b76d                	j	80206558 <pipewrite+0x7a>
    802065b0:	7b02                	ld	s6,32(sp)
    802065b2:	6be2                	ld	s7,24(sp)
    wakeup(&pi->nread);
    802065b4:	21848513          	addi	a0,s1,536
    802065b8:	ffffc097          	auipc	ra,0xffffc
    802065bc:	9da080e7          	jalr	-1574(ra) # 80201f92 <wakeup>
    release(&pi->lock);
    802065c0:	8526                	mv	a0,s1
    802065c2:	ffffb097          	auipc	ra,0xffffb
    802065c6:	e1a080e7          	jalr	-486(ra) # 802013dc <release>
    return i;
    802065ca:	b795                	j	8020652e <pipewrite+0x50>
    int i = 0;
    802065cc:	4901                	li	s2,0
    802065ce:	b7dd                	j	802065b4 <pipewrite+0xd6>
    802065d0:	7b02                	ld	s6,32(sp)
    802065d2:	6be2                	ld	s7,24(sp)
    802065d4:	b7c5                	j	802065b4 <pipewrite+0xd6>

00000000802065d6 <piperead>:

int piperead(struct pipe *pi, uint64 uaddr, int n)
{
    802065d6:	715d                	addi	sp,sp,-80
    802065d8:	e486                	sd	ra,72(sp)
    802065da:	e0a2                	sd	s0,64(sp)
    802065dc:	fc26                	sd	s1,56(sp)
    802065de:	f84a                	sd	s2,48(sp)
    802065e0:	f44e                	sd	s3,40(sp)
    802065e2:	f052                	sd	s4,32(sp)
    802065e4:	ec56                	sd	s5,24(sp)
    802065e6:	0880                	addi	s0,sp,80
    802065e8:	84aa                	mv	s1,a0
    802065ea:	892e                	mv	s2,a1
    802065ec:	8ab2                	mv	s5,a2
    struct proc *pr = myproc();
    802065ee:	ffffb097          	auipc	ra,0xffffb
    802065f2:	178080e7          	jalr	376(ra) # 80201766 <myproc>
    802065f6:	8a2a                	mv	s4,a0

    acquire(&pi->lock);
    802065f8:	8526                	mv	a0,s1
    802065fa:	ffffb097          	auipc	ra,0xffffb
    802065fe:	d2e080e7          	jalr	-722(ra) # 80201328 <acquire>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80206602:	2184a703          	lw	a4,536(s1)
    80206606:	21c4a783          	lw	a5,540(s1)
        if (pr->killed) { release(&pi->lock); return -1; }
        sleep(&pi->nread, &pi->lock);
    8020660a:	21848993          	addi	s3,s1,536
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    8020660e:	02f71463          	bne	a4,a5,80206636 <piperead+0x60>
    80206612:	2244a783          	lw	a5,548(s1)
    80206616:	c385                	beqz	a5,80206636 <piperead+0x60>
        if (pr->killed) { release(&pi->lock); return -1; }
    80206618:	028a2783          	lw	a5,40(s4)
    8020661c:	e7d9                	bnez	a5,802066aa <piperead+0xd4>
        sleep(&pi->nread, &pi->lock);
    8020661e:	85a6                	mv	a1,s1
    80206620:	854e                	mv	a0,s3
    80206622:	ffffb097          	auipc	ra,0xffffb
    80206626:	7ea080e7          	jalr	2026(ra) # 80201e0c <sleep>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    8020662a:	2184a703          	lw	a4,536(s1)
    8020662e:	21c4a783          	lw	a5,540(s1)
    80206632:	fef700e3          	beq	a4,a5,80206612 <piperead+0x3c>
    }
    int i;
    for (i = 0; i < n; i++) {
    80206636:	4981                	li	s3,0
    80206638:	05505463          	blez	s5,80206680 <piperead+0xaa>
        if (pi->nread == pi->nwrite) break;             /* drained */
    8020663c:	2184a783          	lw	a5,536(s1)
    80206640:	21c4a703          	lw	a4,540(s1)
    80206644:	02f70e63          	beq	a4,a5,80206680 <piperead+0xaa>
        char ch = pi->data[pi->nread++ % PIPESIZE];
    80206648:	0017871b          	addiw	a4,a5,1
    8020664c:	20e4ac23          	sw	a4,536(s1)
    80206650:	1ff7f793          	andi	a5,a5,511
    80206654:	97a6                	add	a5,a5,s1
    80206656:	0187c783          	lbu	a5,24(a5)
    8020665a:	faf40fa3          	sb	a5,-65(s0)
        if (copyout(pr->pagetable, uaddr + i, &ch, 1) < 0) break;
    8020665e:	4685                	li	a3,1
    80206660:	fbf40613          	addi	a2,s0,-65
    80206664:	85ca                	mv	a1,s2
    80206666:	050a3503          	ld	a0,80(s4)
    8020666a:	ffffd097          	auipc	ra,0xffffd
    8020666e:	914080e7          	jalr	-1772(ra) # 80202f7e <copyout>
    80206672:	00054763          	bltz	a0,80206680 <piperead+0xaa>
    for (i = 0; i < n; i++) {
    80206676:	2985                	addiw	s3,s3,1
    80206678:	0905                	addi	s2,s2,1
    8020667a:	fd3a91e3          	bne	s5,s3,8020663c <piperead+0x66>
    8020667e:	89d6                	mv	s3,s5
    }
    wakeup(&pi->nwrite);
    80206680:	21c48513          	addi	a0,s1,540
    80206684:	ffffc097          	auipc	ra,0xffffc
    80206688:	90e080e7          	jalr	-1778(ra) # 80201f92 <wakeup>
    release(&pi->lock);
    8020668c:	8526                	mv	a0,s1
    8020668e:	ffffb097          	auipc	ra,0xffffb
    80206692:	d4e080e7          	jalr	-690(ra) # 802013dc <release>
    return i;                                           /* 0 here = EOF */
}
    80206696:	854e                	mv	a0,s3
    80206698:	60a6                	ld	ra,72(sp)
    8020669a:	6406                	ld	s0,64(sp)
    8020669c:	74e2                	ld	s1,56(sp)
    8020669e:	7942                	ld	s2,48(sp)
    802066a0:	79a2                	ld	s3,40(sp)
    802066a2:	7a02                	ld	s4,32(sp)
    802066a4:	6ae2                	ld	s5,24(sp)
    802066a6:	6161                	addi	sp,sp,80
    802066a8:	8082                	ret
        if (pr->killed) { release(&pi->lock); return -1; }
    802066aa:	8526                	mv	a0,s1
    802066ac:	ffffb097          	auipc	ra,0xffffb
    802066b0:	d30080e7          	jalr	-720(ra) # 802013dc <release>
    802066b4:	59fd                	li	s3,-1
    802066b6:	b7c5                	j	80206696 <piperead+0xc0>

00000000802066b8 <hal_intc_init>:
#define PLIC_PRIORITY(irq)   (plic + (irq) * 4)
#define PLIC_SENABLE(h)      (plic + 0x2080 + (h) * 0x100)
#define PLIC_STHRESHOLD(h)   (plic + 0x201000 + (h) * 0x2000)
#define PLIC_SCLAIM(h)       (plic + 0x201004 + (h) * 0x2000)

void hal_intc_init(uint64 plic_base) { plic = plic_base; }
    802066b8:	1141                	addi	sp,sp,-16
    802066ba:	e422                	sd	s0,8(sp)
    802066bc:	0800                	addi	s0,sp,16
    802066be:	00144797          	auipc	a5,0x144
    802066c2:	96a7b523          	sd	a0,-1686(a5) # 8034a028 <plic>
    802066c6:	6422                	ld	s0,8(sp)
    802066c8:	0141                	addi	sp,sp,16
    802066ca:	8082                	ret

00000000802066cc <hal_intc_enable>:

void hal_intc_enable(int irq)
{
    802066cc:	1141                	addi	sp,sp,-16
    802066ce:	e422                	sd	s0,8(sp)
    802066d0:	0800                	addi	s0,sp,16
    if (!plic) return;
    802066d2:	00144797          	auipc	a5,0x144
    802066d6:	9567b783          	ld	a5,-1706(a5) # 8034a028 <plic>
    802066da:	c791                	beqz	a5,802066e6 <hal_intc_enable+0x1a>
    *(volatile uint32 *)PLIC_PRIORITY(irq) = 1;   /* priority 0 = never fire */
    802066dc:	0025151b          	slliw	a0,a0,0x2
    802066e0:	953e                	add	a0,a0,a5
    802066e2:	4785                	li	a5,1
    802066e4:	c11c                	sw	a5,0(a0)
}
    802066e6:	6422                	ld	s0,8(sp)
    802066e8:	0141                	addi	sp,sp,16
    802066ea:	8082                	ret

00000000802066ec <hal_intc_hart_init>:

void hal_intc_hart_init(int hart)
{
    802066ec:	1141                	addi	sp,sp,-16
    802066ee:	e422                	sd	s0,8(sp)
    802066f0:	0800                	addi	s0,sp,16
    if (!plic) return;
    802066f2:	00144797          	auipc	a5,0x144
    802066f6:	9367b783          	ld	a5,-1738(a5) # 8034a028 <plic>
    802066fa:	cb89                	beqz	a5,8020670c <hal_intc_hart_init+0x20>
    *(volatile uint32 *)PLIC_STHRESHOLD(hart) = 0; /* accept any priority > 0 */
    802066fc:	00d5151b          	slliw	a0,a0,0xd
    80206700:	00201737          	lui	a4,0x201
    80206704:	97ba                	add	a5,a5,a4
    80206706:	953e                	add	a0,a0,a5
    80206708:	00052023          	sw	zero,0(a0)
}
    8020670c:	6422                	ld	s0,8(sp)
    8020670e:	0141                	addi	sp,sp,16
    80206710:	8082                	ret

0000000080206712 <hal_intc_enable_hart>:

/* Enable irq for this hart (must be called after hal_intc_enable). */
void hal_intc_enable_hart(int hart, int irq)
{
    80206712:	1141                	addi	sp,sp,-16
    80206714:	e422                	sd	s0,8(sp)
    80206716:	0800                	addi	s0,sp,16
    if (!plic) return;
    80206718:	00144797          	auipc	a5,0x144
    8020671c:	9107b783          	ld	a5,-1776(a5) # 8034a028 <plic>
    80206720:	cb85                	beqz	a5,80206750 <hal_intc_enable_hart+0x3e>
    volatile uint32 *en = (volatile uint32 *)PLIC_SENABLE(hart);
    80206722:	0085151b          	slliw	a0,a0,0x8
    80206726:	6709                	lui	a4,0x2
    80206728:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    8020672c:	97ba                	add	a5,a5,a4
    8020672e:	953e                	add	a0,a0,a5
    en[irq / 32] |= (1u << (irq % 32));
    80206730:	41f5d79b          	sraiw	a5,a1,0x1f
    80206734:	01b7d79b          	srliw	a5,a5,0x1b
    80206738:	9fad                	addw	a5,a5,a1
    8020673a:	4057d79b          	sraiw	a5,a5,0x5
    8020673e:	078a                	slli	a5,a5,0x2
    80206740:	953e                	add	a0,a0,a5
    80206742:	411c                	lw	a5,0(a0)
    80206744:	4705                	li	a4,1
    80206746:	00b7173b          	sllw	a4,a4,a1
    8020674a:	8fd9                	or	a5,a5,a4
    8020674c:	2781                	sext.w	a5,a5
    8020674e:	c11c                	sw	a5,0(a0)
}
    80206750:	6422                	ld	s0,8(sp)
    80206752:	0141                	addi	sp,sp,16
    80206754:	8082                	ret

0000000080206756 <hal_intc_claim>:

int hal_intc_claim(void)
{
    80206756:	1141                	addi	sp,sp,-16
    80206758:	e422                	sd	s0,8(sp)
    8020675a:	0800                	addi	s0,sp,16
    if (!plic) return 0;
    8020675c:	00144797          	auipc	a5,0x144
    80206760:	8cc7b783          	ld	a5,-1844(a5) # 8034a028 <plic>
    80206764:	4501                	li	a0,0
    80206766:	e781                	bnez	a5,8020676e <hal_intc_claim+0x18>
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
}
    80206768:	6422                	ld	s0,8(sp)
    8020676a:	0141                	addi	sp,sp,16
    8020676c:	8082                	ret
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    8020676e:	8712                	mv	a4,tp
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
    80206770:	00d7171b          	slliw	a4,a4,0xd
    80206774:	002016b7          	lui	a3,0x201
    80206778:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    8020677a:	97b6                	add	a5,a5,a3
    8020677c:	97ba                	add	a5,a5,a4
    8020677e:	4388                	lw	a0,0(a5)
    80206780:	b7e5                	j	80206768 <hal_intc_claim+0x12>

0000000080206782 <hal_intc_complete>:

void hal_intc_complete(int irq)
{
    80206782:	1141                	addi	sp,sp,-16
    80206784:	e422                	sd	s0,8(sp)
    80206786:	0800                	addi	s0,sp,16
    if (!plic) return;
    80206788:	00144797          	auipc	a5,0x144
    8020678c:	8a07b783          	ld	a5,-1888(a5) # 8034a028 <plic>
    80206790:	e781                	bnez	a5,80206798 <hal_intc_complete+0x16>
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
}
    80206792:	6422                	ld	s0,8(sp)
    80206794:	0141                	addi	sp,sp,16
    80206796:	8082                	ret
    80206798:	8712                	mv	a4,tp
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
    8020679a:	00d7171b          	slliw	a4,a4,0xd
    8020679e:	002016b7          	lui	a3,0x201
    802067a2:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    802067a4:	97b6                	add	a5,a5,a3
    802067a6:	97ba                	add	a5,a5,a4
    802067a8:	2501                	sext.w	a0,a0
    802067aa:	c388                	sw	a0,0(a5)
    802067ac:	b7dd                	j	80206792 <hal_intc_complete+0x10>

00000000802067ae <hal_hart_id>:

int hal_hart_id(void) { return (int)r_tp(); }
    802067ae:	1141                	addi	sp,sp,-16
    802067b0:	e422                	sd	s0,8(sp)
    802067b2:	0800                	addi	s0,sp,16
    802067b4:	8512                	mv	a0,tp
    802067b6:	2501                	sext.w	a0,a0
    802067b8:	6422                	ld	s0,8(sp)
    802067ba:	0141                	addi	sp,sp,16
    802067bc:	8082                	ret

00000000802067be <plic_dbg>:

int plic_dbg(int which)
{
    802067be:	1141                	addi	sp,sp,-16
    802067c0:	e422                	sd	s0,8(sp)
    802067c2:	0800                	addi	s0,sp,16
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    802067c4:	cd09                	beqz	a0,802067de <plic_dbg+0x20>
    return *(volatile uint32 *)PLIC_SENABLE(0);
    802067c6:	6709                	lui	a4,0x2
    802067c8:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    802067cc:	00144797          	auipc	a5,0x144
    802067d0:	85c7b783          	ld	a5,-1956(a5) # 8034a028 <plic>
    802067d4:	97ba                	add	a5,a5,a4
    802067d6:	4388                	lw	a0,0(a5)
}
    802067d8:	6422                	ld	s0,8(sp)
    802067da:	0141                	addi	sp,sp,16
    802067dc:	8082                	ret
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    802067de:	00144797          	auipc	a5,0x144
    802067e2:	84a7b783          	ld	a5,-1974(a5) # 8034a028 <plic>
    802067e6:	5788                	lw	a0,40(a5)
    802067e8:	bfc5                	j	802067d8 <plic_dbg+0x1a>

00000000802067ea <hal_time_read>:
#include "hal.h"
#include "riscv.h"
#include "defs.h"

void    hal_timer_init(void)          { hal_timer_next(1000000); }
uint64  hal_time_read(void)           { return r_time(); }
    802067ea:	1141                	addi	sp,sp,-16
    802067ec:	e422                	sd	s0,8(sp)
    802067ee:	0800                	addi	s0,sp,16
static inline uint64 r_time(void){ uint64 x; asm volatile("rdtime %0":"=r"(x)); return x; }
    802067f0:	c0102573          	rdtime	a0
    802067f4:	6422                	ld	s0,8(sp)
    802067f6:	0141                	addi	sp,sp,16
    802067f8:	8082                	ret

00000000802067fa <hal_timer_set>:
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    802067fa:	1141                	addi	sp,sp,-16
    802067fc:	e406                	sd	ra,8(sp)
    802067fe:	e022                	sd	s0,0(sp)
    80206800:	0800                	addi	s0,sp,16
    80206802:	ffffa097          	auipc	ra,0xffffa
    80206806:	ff2080e7          	jalr	-14(ra) # 802007f4 <sbi_set_timer>
    8020680a:	60a2                	ld	ra,8(sp)
    8020680c:	6402                	ld	s0,0(sp)
    8020680e:	0141                	addi	sp,sp,16
    80206810:	8082                	ret

0000000080206812 <hal_timer_ack>:
void    hal_timer_ack(void)           { /* SBI: next set_timer clears STIP */ }
    80206812:	1141                	addi	sp,sp,-16
    80206814:	e422                	sd	s0,8(sp)
    80206816:	0800                	addi	s0,sp,16
    80206818:	6422                	ld	s0,8(sp)
    8020681a:	0141                	addi	sp,sp,16
    8020681c:	8082                	ret

000000008020681e <hal_timer_next>:
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    8020681e:	1141                	addi	sp,sp,-16
    80206820:	e406                	sd	ra,8(sp)
    80206822:	e022                	sd	s0,0(sp)
    80206824:	0800                	addi	s0,sp,16
    80206826:	c01027f3          	rdtime	a5
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    8020682a:	953e                	add	a0,a0,a5
    8020682c:	ffffa097          	auipc	ra,0xffffa
    80206830:	fc8080e7          	jalr	-56(ra) # 802007f4 <sbi_set_timer>
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    80206834:	60a2                	ld	ra,8(sp)
    80206836:	6402                	ld	s0,0(sp)
    80206838:	0141                	addi	sp,sp,16
    8020683a:	8082                	ret

000000008020683c <hal_timer_init>:
void    hal_timer_init(void)          { hal_timer_next(1000000); }
    8020683c:	1141                	addi	sp,sp,-16
    8020683e:	e406                	sd	ra,8(sp)
    80206840:	e022                	sd	s0,0(sp)
    80206842:	0800                	addi	s0,sp,16
    80206844:	000f4537          	lui	a0,0xf4
    80206848:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    8020684c:	00000097          	auipc	ra,0x0
    80206850:	fd2080e7          	jalr	-46(ra) # 8020681e <hal_timer_next>
    80206854:	60a2                	ld	ra,8(sp)
    80206856:	6402                	ld	s0,0(sp)
    80206858:	0141                	addi	sp,sp,16
    8020685a:	8082                	ret

000000008020685c <hal_console_init>:
#define LSR 5   /* line status              */
#define LSR_RX_READY  (1 << 0)
#define LSR_TX_IDLE   (1 << 5)

void hal_console_init(uint64 uart_base)
{
    8020685c:	1141                	addi	sp,sp,-16
    8020685e:	e422                	sd	s0,8(sp)
    80206860:	0800                	addi	s0,sp,16
    uart = (volatile uint8 *)uart_base;
    80206862:	00143797          	auipc	a5,0x143
    80206866:	7ca7b723          	sd	a0,1998(a5) # 8034a030 <uart>
    uart[IER] = 0x00;              /* interrupts off while we configure */
    8020686a:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x80;              /* DLAB=1: divisor latch visible     */
    8020686e:	f8000793          	li	a5,-128
    80206872:	00f501a3          	sb	a5,3(a0)
    uart[0]   = 0x03;              /* divisor low: 38.4K                */
    80206876:	478d                	li	a5,3
    80206878:	00f50023          	sb	a5,0(a0)
    uart[1]   = 0x00;              /* divisor high                      */
    8020687c:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x03;              /* DLAB=0, 8 bits, no parity, 1 stop */
    80206880:	00f501a3          	sb	a5,3(a0)
    uart[FCR] = 0x07;              /* enable + clear FIFOs              */
    80206884:	479d                	li	a5,7
    80206886:	00f50123          	sb	a5,2(a0)
    uart[IER] = 0x01;              /* receive interrupts on             */
    8020688a:	4785                	li	a5,1
    8020688c:	00f500a3          	sb	a5,1(a0)
}
    80206890:	6422                	ld	s0,8(sp)
    80206892:	0141                	addi	sp,sp,16
    80206894:	8082                	ret

0000000080206896 <hal_console_putc>:

void hal_console_putc(char c)
{
    80206896:	1141                	addi	sp,sp,-16
    80206898:	e422                	sd	s0,8(sp)
    8020689a:	0800                	addi	s0,sp,16
    if (!uart) { return; }
    8020689c:	00143717          	auipc	a4,0x143
    802068a0:	79473703          	ld	a4,1940(a4) # 8034a030 <uart>
    802068a4:	cb01                	beqz	a4,802068b4 <hal_console_putc+0x1e>
    while ((uart[LSR] & LSR_TX_IDLE) == 0)   /* wait for the holding reg */
    802068a6:	00574783          	lbu	a5,5(a4)
    802068aa:	0207f793          	andi	a5,a5,32
    802068ae:	dfe5                	beqz	a5,802068a6 <hal_console_putc+0x10>
        ;
    uart[THR] = c;
    802068b0:	00a70023          	sb	a0,0(a4)
}
    802068b4:	6422                	ld	s0,8(sp)
    802068b6:	0141                	addi	sp,sp,16
    802068b8:	8082                	ret

00000000802068ba <hal_console_getc>:

int hal_console_getc(void)
{
    802068ba:	1141                	addi	sp,sp,-16
    802068bc:	e422                	sd	s0,8(sp)
    802068be:	0800                	addi	s0,sp,16
    if (!uart) return -1;
    802068c0:	00143717          	auipc	a4,0x143
    802068c4:	77073703          	ld	a4,1904(a4) # 8034a030 <uart>
    802068c8:	cb11                	beqz	a4,802068dc <hal_console_getc+0x22>
    if (uart[LSR] & LSR_RX_READY)
    802068ca:	00574783          	lbu	a5,5(a4)
    802068ce:	8b85                	andi	a5,a5,1
    802068d0:	cb81                	beqz	a5,802068e0 <hal_console_getc+0x26>
        return uart[RHR];
    802068d2:	00074503          	lbu	a0,0(a4)
    return -1;
}
    802068d6:	6422                	ld	s0,8(sp)
    802068d8:	0141                	addi	sp,sp,16
    802068da:	8082                	ret
    if (!uart) return -1;
    802068dc:	557d                	li	a0,-1
    802068de:	bfe5                	j	802068d6 <hal_console_getc+0x1c>
    return -1;
    802068e0:	557d                	li	a0,-1
    802068e2:	bfd5                	j	802068d6 <hal_console_getc+0x1c>

00000000802068e4 <free_desc>:
    for (int i = 0; i < VNUM; i++)
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    return -1;
}
static void free_desc(int i)
{
    802068e4:	1141                	addi	sp,sp,-16
    802068e6:	e406                	sd	ra,8(sp)
    802068e8:	e022                	sd	s0,0(sp)
    802068ea:	0800                	addi	s0,sp,16
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    802068ec:	479d                	li	a5,7
    802068ee:	04a7c663          	blt	a5,a0,8020693a <free_desc+0x56>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    802068f2:	00140797          	auipc	a5,0x140
    802068f6:	70e78793          	addi	a5,a5,1806 # 80347000 <vdisk>
    802068fa:	97aa                	add	a5,a5,a0
    802068fc:	0287c783          	lbu	a5,40(a5)
    80206900:	e7a9                	bnez	a5,8020694a <free_desc+0x66>
    vdisk.desc[i] = (struct virtq_desc){0};
    80206902:	00140797          	auipc	a5,0x140
    80206906:	6fe78793          	addi	a5,a5,1790 # 80347000 <vdisk>
    8020690a:	6b98                	ld	a4,16(a5)
    8020690c:	00451693          	slli	a3,a0,0x4
    80206910:	9736                	add	a4,a4,a3
    80206912:	00073023          	sd	zero,0(a4)
    80206916:	00073423          	sd	zero,8(a4)
    vdisk.free[i] = 1;
    8020691a:	97aa                	add	a5,a5,a0
    8020691c:	4705                	li	a4,1
    8020691e:	02e78423          	sb	a4,40(a5)
    wakeup(&vdisk.free[0]);
    80206922:	00140517          	auipc	a0,0x140
    80206926:	70650513          	addi	a0,a0,1798 # 80347028 <vdisk+0x28>
    8020692a:	ffffb097          	auipc	ra,0xffffb
    8020692e:	668080e7          	jalr	1640(ra) # 80201f92 <wakeup>
}
    80206932:	60a2                	ld	ra,8(sp)
    80206934:	6402                	ld	s0,0(sp)
    80206936:	0141                	addi	sp,sp,16
    80206938:	8082                	ret
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    8020693a:	00001517          	auipc	a0,0x1
    8020693e:	2f650513          	addi	a0,a0,758 # 80207c30 <etext+0xc30>
    80206942:	ffffa097          	auipc	ra,0xffffa
    80206946:	cb0080e7          	jalr	-848(ra) # 802005f2 <panic>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    8020694a:	00001517          	auipc	a0,0x1
    8020694e:	30650513          	addi	a0,a0,774 # 80207c50 <etext+0xc50>
    80206952:	ffffa097          	auipc	ra,0xffffa
    80206956:	ca0080e7          	jalr	-864(ra) # 802005f2 <panic>

000000008020695a <hal_block_irq>:
int hal_block_irq(void) { return vdisk.base ? vdisk.irq : 0; }
    8020695a:	1141                	addi	sp,sp,-16
    8020695c:	e422                	sd	s0,8(sp)
    8020695e:	0800                	addi	s0,sp,16
    80206960:	00140797          	auipc	a5,0x140
    80206964:	6a07b783          	ld	a5,1696(a5) # 80347000 <vdisk>
    80206968:	4501                	li	a0,0
    8020696a:	c789                	beqz	a5,80206974 <hal_block_irq+0x1a>
    8020696c:	00140517          	auipc	a0,0x140
    80206970:	69c52503          	lw	a0,1692(a0) # 80347008 <vdisk+0x8>
    80206974:	6422                	ld	s0,8(sp)
    80206976:	0141                	addi	sp,sp,16
    80206978:	8082                	ret

000000008020697a <hal_block_init>:
{
    8020697a:	7139                	addi	sp,sp,-64
    8020697c:	fc06                	sd	ra,56(sp)
    8020697e:	f822                	sd	s0,48(sp)
    80206980:	f426                	sd	s1,40(sp)
    80206982:	0080                	addi	s0,sp,64
    initlock(&vdisk.lock, "virtio_blk");
    80206984:	00001597          	auipc	a1,0x1
    80206988:	2ec58593          	addi	a1,a1,748 # 80207c70 <etext+0xc70>
    8020698c:	00140517          	auipc	a0,0x140
    80206990:	7ac50513          	addi	a0,a0,1964 # 80347138 <vdisk+0x138>
    80206994:	ffffb097          	auipc	ra,0xffffb
    80206998:	918080e7          	jalr	-1768(ra) # 802012ac <initlock>
    for (int i = 0; i < fdt.nvirtio; i++) {
    8020699c:	00022797          	auipc	a5,0x22
    802069a0:	7047a783          	lw	a5,1796(a5) # 802290a0 <fdt+0x88>
    802069a4:	08f05c63          	blez	a5,80206a3c <hal_block_init+0xc2>
    802069a8:	f04a                	sd	s2,32(sp)
    802069aa:	ec4e                	sd	s3,24(sp)
    802069ac:	e852                	sd	s4,16(sp)
    802069ae:	e456                	sd	s5,8(sp)
    802069b0:	e05a                	sd	s6,0(sp)
    802069b2:	00022917          	auipc	s2,0x22
    802069b6:	66690913          	addi	s2,s2,1638 # 80229018 <fdt>
    802069ba:	4481                	li	s1,0
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    802069bc:	747279b7          	lui	s3,0x74727
    802069c0:	97698993          	addi	s3,s3,-1674 # 74726976 <_entry-0xbad968a>
    802069c4:	4a89                	li	s5,2
    802069c6:	4b05                	li	s6,1
    for (int i = 0; i < fdt.nvirtio; i++) {
    802069c8:	8a4a                	mv	s4,s2
    802069ca:	a039                	j	802069d8 <hal_block_init+0x5e>
    802069cc:	2485                	addiw	s1,s1,1
    802069ce:	0921                	addi	s2,s2,8
    802069d0:	088a2783          	lw	a5,136(s4)
    802069d4:	04f4df63          	bge	s1,a5,80206a32 <hal_block_init+0xb8>
        uint64 va = mmio_alias(fdt.virtio_base[i]);
    802069d8:	02893503          	ld	a0,40(s2)
    802069dc:	ffffc097          	auipc	ra,0xffffc
    802069e0:	0d0080e7          	jalr	208(ra) # 80202aac <mmio_alias>
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    802069e4:	411c                	lw	a5,0(a0)
    802069e6:	2781                	sext.w	a5,a5
    802069e8:	ff3792e3          	bne	a5,s3,802069cc <hal_block_init+0x52>
    802069ec:	451c                	lw	a5,8(a0)
    802069ee:	2781                	sext.w	a5,a5
    802069f0:	fd579ee3          	bne	a5,s5,802069cc <hal_block_init+0x52>
    802069f4:	415c                	lw	a5,4(a0)
    802069f6:	2781                	sext.w	a5,a5
    802069f8:	01678663          	beq	a5,s6,80206a04 <hal_block_init+0x8a>
    802069fc:	415c                	lw	a5,4(a0)
    802069fe:	2781                	sext.w	a5,a5
    80206a00:	fd5796e3          	bne	a5,s5,802069cc <hal_block_init+0x52>
            vdisk.base    = va;
    80206a04:	00140717          	auipc	a4,0x140
    80206a08:	5fc70713          	addi	a4,a4,1532 # 80347000 <vdisk>
    80206a0c:	e308                	sd	a0,0(a4)
            vdisk.irq     = fdt.virtio_irq[i];
    80206a0e:	01848793          	addi	a5,s1,24
    80206a12:	078a                	slli	a5,a5,0x2
    80206a14:	00022697          	auipc	a3,0x22
    80206a18:	60468693          	addi	a3,a3,1540 # 80229018 <fdt>
    80206a1c:	97b6                	add	a5,a5,a3
    80206a1e:	479c                	lw	a5,8(a5)
    80206a20:	c71c                	sw	a5,8(a4)
            vdisk.version = *vers;
    80206a22:	415c                	lw	a5,4(a0)
    80206a24:	c75c                	sw	a5,12(a4)
            break;
    80206a26:	7902                	ld	s2,32(sp)
    80206a28:	69e2                	ld	s3,24(sp)
    80206a2a:	6a42                	ld	s4,16(sp)
    80206a2c:	6aa2                	ld	s5,8(sp)
    80206a2e:	6b02                	ld	s6,0(sp)
    80206a30:	a031                	j	80206a3c <hal_block_init+0xc2>
    80206a32:	7902                	ld	s2,32(sp)
    80206a34:	69e2                	ld	s3,24(sp)
    80206a36:	6a42                	ld	s4,16(sp)
    80206a38:	6aa2                	ld	s5,8(sp)
    80206a3a:	6b02                	ld	s6,0(sp)
    if (!vdisk.base) return -1;                   /* no disk on this board */
    80206a3c:	00140797          	auipc	a5,0x140
    80206a40:	5c47b783          	ld	a5,1476(a5) # 80347000 <vdisk>
    80206a44:	1a078363          	beqz	a5,80206bea <hal_block_init+0x270>
    *R(VIRTIO_MMIO_STATUS) = 0;
    80206a48:	0607a823          	sw	zero,112(a5)
    *R(VIRTIO_MMIO_STATUS) = status;
    80206a4c:	00140797          	auipc	a5,0x140
    80206a50:	5b478793          	addi	a5,a5,1460 # 80347000 <vdisk>
    80206a54:	6398                	ld	a4,0(a5)
    80206a56:	4685                	li	a3,1
    80206a58:	db34                	sw	a3,112(a4)
    *R(VIRTIO_MMIO_STATUS) = status;
    80206a5a:	6398                	ld	a4,0(a5)
    80206a5c:	468d                	li	a3,3
    80206a5e:	db34                	sw	a3,112(a4)
    uint32 feats = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80206a60:	6390                	ld	a2,0(a5)
    80206a62:	4a18                	lw	a4,16(a2)
    feats &= ~(1u << VIRTIO_RING_F_EVENT_IDX);
    80206a64:	c7ffe6b7          	lui	a3,0xc7ffe
    80206a68:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <uart+0xffffffff47cb472f>
    80206a6c:	8f75                	and	a4,a4,a3
    *R(VIRTIO_MMIO_DRIVER_FEATURES) = feats;
    80206a6e:	d218                	sw	a4,32(a2)
    if (vdisk.version == 2) {
    80206a70:	47d8                	lw	a4,12(a5)
    80206a72:	4789                	li	a5,2
    status |= VIRTIO_CONFIG_S_DRIVER;
    80206a74:	448d                	li	s1,3
    if (vdisk.version == 2) {
    80206a76:	0ef70563          	beq	a4,a5,80206b60 <hal_block_init+0x1e6>
    *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80206a7a:	00140797          	auipc	a5,0x140
    80206a7e:	58678793          	addi	a5,a5,1414 # 80347000 <vdisk>
    80206a82:	6398                	ld	a4,0(a5)
    80206a84:	02072823          	sw	zero,48(a4)
    uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80206a88:	6398                	ld	a4,0(a5)
    80206a8a:	5b5c                	lw	a5,52(a4)
    80206a8c:	2781                	sext.w	a5,a5
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206a8e:	10078263          	beqz	a5,80206b92 <hal_block_init+0x218>
    if (max < VNUM) panic("virtio_blk: queue too short");
    80206a92:	469d                	li	a3,7
    80206a94:	10f6fc63          	bgeu	a3,a5,80206bac <hal_block_init+0x232>
    *R(VIRTIO_MMIO_QUEUE_NUM) = VNUM;
    80206a98:	47a1                	li	a5,8
    80206a9a:	df1c                	sw	a5,56(a4)
    memset(pages, 0, sizeof(pages));
    80206a9c:	6609                	lui	a2,0x2
    80206a9e:	4581                	li	a1,0
    80206aa0:	00141517          	auipc	a0,0x141
    80206aa4:	56050513          	addi	a0,a0,1376 # 80348000 <pages.0>
    80206aa8:	ffffa097          	auipc	ra,0xffffa
    80206aac:	bf0080e7          	jalr	-1040(ra) # 80200698 <memset>
    vdisk.desc  = (struct virtq_desc *)pages;
    80206ab0:	00140797          	auipc	a5,0x140
    80206ab4:	55078793          	addi	a5,a5,1360 # 80347000 <vdisk>
    80206ab8:	00141717          	auipc	a4,0x141
    80206abc:	54870713          	addi	a4,a4,1352 # 80348000 <pages.0>
    80206ac0:	eb98                	sd	a4,16(a5)
    vdisk.avail = (struct virtq_avail *)(pages + VNUM * sizeof(struct virtq_desc));
    80206ac2:	00141717          	auipc	a4,0x141
    80206ac6:	5be70713          	addi	a4,a4,1470 # 80348080 <pages.0+0x80>
    80206aca:	ef98                	sd	a4,24(a5)
    vdisk.used  = (struct virtq_used *)(pages + PGSIZE);
    80206acc:	00142717          	auipc	a4,0x142
    80206ad0:	53470713          	addi	a4,a4,1332 # 80349000 <pages.0+0x1000>
    80206ad4:	f398                	sd	a4,32(a5)
    if (vdisk.version == 1) {
    80206ad6:	47d8                	lw	a4,12(a5)
    80206ad8:	4785                	li	a5,1
    80206ada:	0ef70663          	beq	a4,a5,80206bc6 <hal_block_init+0x24c>
        *R(VIRTIO_MMIO_QUEUE_DESC_LOW)   = (uint64)vdisk.desc;
    80206ade:	00140797          	auipc	a5,0x140
    80206ae2:	52278793          	addi	a5,a5,1314 # 80347000 <vdisk>
    80206ae6:	6398                	ld	a4,0(a5)
    80206ae8:	00141697          	auipc	a3,0x141
    80206aec:	51868693          	addi	a3,a3,1304 # 80348000 <pages.0>
    80206af0:	08d72023          	sw	a3,128(a4)
        *R(VIRTIO_MMIO_QUEUE_DESC_HIGH)  = (uint64)vdisk.desc >> 32;
    80206af4:	6398                	ld	a4,0(a5)
    80206af6:	4bd4                	lw	a3,20(a5)
    80206af8:	08d72223          	sw	a3,132(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_LOW)  = (uint64)vdisk.avail;
    80206afc:	6398                	ld	a4,0(a5)
    80206afe:	4f94                	lw	a3,24(a5)
    80206b00:	08d72823          	sw	a3,144(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)vdisk.avail >> 32;
    80206b04:	6398                	ld	a4,0(a5)
    80206b06:	4fd4                	lw	a3,28(a5)
    80206b08:	08d72a23          	sw	a3,148(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_LOW)  = (uint64)vdisk.used;
    80206b0c:	6398                	ld	a4,0(a5)
    80206b0e:	5394                	lw	a3,32(a5)
    80206b10:	0ad72023          	sw	a3,160(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)vdisk.used >> 32;
    80206b14:	6398                	ld	a4,0(a5)
    80206b16:	53d4                	lw	a3,36(a5)
    80206b18:	0ad72223          	sw	a3,164(a4)
        *R(VIRTIO_MMIO_QUEUE_READY) = 1;
    80206b1c:	639c                	ld	a5,0(a5)
    80206b1e:	4705                	li	a4,1
    80206b20:	c3f8                	sw	a4,68(a5)
    for (int i = 0; i < VNUM; i++) vdisk.free[i] = 1;
    80206b22:	00140797          	auipc	a5,0x140
    80206b26:	4de78793          	addi	a5,a5,1246 # 80347000 <vdisk>
    80206b2a:	4705                	li	a4,1
    80206b2c:	02e78423          	sb	a4,40(a5)
    80206b30:	02e784a3          	sb	a4,41(a5)
    80206b34:	02e78523          	sb	a4,42(a5)
    80206b38:	02e785a3          	sb	a4,43(a5)
    80206b3c:	02e78623          	sb	a4,44(a5)
    80206b40:	02e786a3          	sb	a4,45(a5)
    80206b44:	02e78723          	sb	a4,46(a5)
    80206b48:	02e787a3          	sb	a4,47(a5)
    status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80206b4c:	0044e493          	ori	s1,s1,4
    *R(VIRTIO_MMIO_STATUS) = status;
    80206b50:	639c                	ld	a5,0(a5)
    80206b52:	dba4                	sw	s1,112(a5)
    return 0;
    80206b54:	4501                	li	a0,0
}
    80206b56:	70e2                	ld	ra,56(sp)
    80206b58:	7442                	ld	s0,48(sp)
    80206b5a:	74a2                	ld	s1,40(sp)
    80206b5c:	6121                	addi	sp,sp,64
    80206b5e:	8082                	ret
        *R(VIRTIO_MMIO_STATUS) = status;
    80206b60:	00140797          	auipc	a5,0x140
    80206b64:	4a078793          	addi	a5,a5,1184 # 80347000 <vdisk>
    80206b68:	6398                	ld	a4,0(a5)
    80206b6a:	46ad                	li	a3,11
    80206b6c:	db34                	sw	a3,112(a4)
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80206b6e:	639c                	ld	a5,0(a5)
    80206b70:	5bbc                	lw	a5,112(a5)
    80206b72:	8ba1                	andi	a5,a5,8
        status |= VIRTIO_CONFIG_S_FEATURES_OK;
    80206b74:	44ad                	li	s1,11
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80206b76:	f391                	bnez	a5,80206a7a <hal_block_init+0x100>
    80206b78:	f04a                	sd	s2,32(sp)
    80206b7a:	ec4e                	sd	s3,24(sp)
    80206b7c:	e852                	sd	s4,16(sp)
    80206b7e:	e456                	sd	s5,8(sp)
    80206b80:	e05a                	sd	s6,0(sp)
            panic("virtio_blk: device rejected our feature set");
    80206b82:	00001517          	auipc	a0,0x1
    80206b86:	0fe50513          	addi	a0,a0,254 # 80207c80 <etext+0xc80>
    80206b8a:	ffffa097          	auipc	ra,0xffffa
    80206b8e:	a68080e7          	jalr	-1432(ra) # 802005f2 <panic>
    80206b92:	f04a                	sd	s2,32(sp)
    80206b94:	ec4e                	sd	s3,24(sp)
    80206b96:	e852                	sd	s4,16(sp)
    80206b98:	e456                	sd	s5,8(sp)
    80206b9a:	e05a                	sd	s6,0(sp)
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206b9c:	00001517          	auipc	a0,0x1
    80206ba0:	11450513          	addi	a0,a0,276 # 80207cb0 <etext+0xcb0>
    80206ba4:	ffffa097          	auipc	ra,0xffffa
    80206ba8:	a4e080e7          	jalr	-1458(ra) # 802005f2 <panic>
    80206bac:	f04a                	sd	s2,32(sp)
    80206bae:	ec4e                	sd	s3,24(sp)
    80206bb0:	e852                	sd	s4,16(sp)
    80206bb2:	e456                	sd	s5,8(sp)
    80206bb4:	e05a                	sd	s6,0(sp)
    if (max < VNUM) panic("virtio_blk: queue too short");
    80206bb6:	00001517          	auipc	a0,0x1
    80206bba:	12250513          	addi	a0,a0,290 # 80207cd8 <etext+0xcd8>
    80206bbe:	ffffa097          	auipc	ra,0xffffa
    80206bc2:	a34080e7          	jalr	-1484(ra) # 802005f2 <panic>
        *R(VIRTIO_MMIO_GUEST_PAGE_SIZE) = PGSIZE;
    80206bc6:	00140797          	auipc	a5,0x140
    80206bca:	43a78793          	addi	a5,a5,1082 # 80347000 <vdisk>
    80206bce:	6394                	ld	a3,0(a5)
    80206bd0:	6705                	lui	a4,0x1
    80206bd2:	d698                	sw	a4,40(a3)
        *R(VIRTIO_MMIO_QUEUE_ALIGN)     = PGSIZE;
    80206bd4:	6394                	ld	a3,0(a5)
    80206bd6:	ded8                	sw	a4,60(a3)
        *R(VIRTIO_MMIO_QUEUE_PFN)       = ((uint64)pages) >> 12;
    80206bd8:	6398                	ld	a4,0(a5)
    80206bda:	00141797          	auipc	a5,0x141
    80206bde:	42678793          	addi	a5,a5,1062 # 80348000 <pages.0>
    80206be2:	83b1                	srli	a5,a5,0xc
    80206be4:	2781                	sext.w	a5,a5
    80206be6:	c33c                	sw	a5,64(a4)
    80206be8:	bf2d                	j	80206b22 <hal_block_init+0x1a8>
    if (!vdisk.base) return -1;                   /* no disk on this board */
    80206bea:	557d                	li	a0,-1
    80206bec:	b7ad                	j	80206b56 <hal_block_init+0x1dc>

0000000080206bee <hal_block_rw>:
    }
    return 0;
}

void hal_block_rw(struct buf *b, int write)
{
    80206bee:	7159                	addi	sp,sp,-112
    80206bf0:	f486                	sd	ra,104(sp)
    80206bf2:	f0a2                	sd	s0,96(sp)
    80206bf4:	eca6                	sd	s1,88(sp)
    80206bf6:	e8ca                	sd	s2,80(sp)
    80206bf8:	e4ce                	sd	s3,72(sp)
    80206bfa:	e0d2                	sd	s4,64(sp)
    80206bfc:	fc56                	sd	s5,56(sp)
    80206bfe:	f85a                	sd	s6,48(sp)
    80206c00:	f45e                	sd	s7,40(sp)
    80206c02:	f062                	sd	s8,32(sp)
    80206c04:	ec66                	sd	s9,24(sp)
    80206c06:	1880                	addi	s0,sp,112
    80206c08:	8a2a                	mv	s4,a0
    80206c0a:	8cae                	mv	s9,a1
    /* LuitFS blocks are 1024 bytes = two 512-byte disk sectors. */
    uint64 sector = b->blockno * (BSIZE / 512);
    80206c0c:	00c52c03          	lw	s8,12(a0)
    80206c10:	001c1c1b          	slliw	s8,s8,0x1
    80206c14:	1c02                	slli	s8,s8,0x20
    80206c16:	020c5c13          	srli	s8,s8,0x20

    acquire(&vdisk.lock);
    80206c1a:	00140517          	auipc	a0,0x140
    80206c1e:	51e50513          	addi	a0,a0,1310 # 80347138 <vdisk+0x138>
    80206c22:	ffffa097          	auipc	ra,0xffffa
    80206c26:	706080e7          	jalr	1798(ra) # 80201328 <acquire>
    for (int i = 0; i < 3; i++) {
    80206c2a:	4981                	li	s3,0
    for (int i = 0; i < VNUM; i++)
    80206c2c:	44a1                	li	s1,8
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206c2e:	00140b17          	auipc	s6,0x140
    80206c32:	3d2b0b13          	addi	s6,s6,978 # 80347000 <vdisk>
    for (int i = 0; i < 3; i++) {
    80206c36:	4a8d                	li	s5,3

    int idx[3];
    while (alloc3_desc(idx) != 0)
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    80206c38:	00140b97          	auipc	s7,0x140
    80206c3c:	500b8b93          	addi	s7,s7,1280 # 80347138 <vdisk+0x138>
    while (alloc3_desc(idx) != 0)
    80206c40:	a0ad                	j	80206caa <hal_block_rw+0xbc>
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206c42:	00fb0733          	add	a4,s6,a5
    80206c46:	02070423          	sb	zero,40(a4) # 1028 <_entry-0x801fefd8>
        idx[i] = alloc_desc();
    80206c4a:	c19c                	sw	a5,0(a1)
        if (idx[i] < 0) {
    80206c4c:	0207c563          	bltz	a5,80206c76 <hal_block_rw+0x88>
    for (int i = 0; i < 3; i++) {
    80206c50:	2905                	addiw	s2,s2,1
    80206c52:	0611                	addi	a2,a2,4 # 2004 <_entry-0x801fdffc>
    80206c54:	05590f63          	beq	s2,s5,80206cb2 <hal_block_rw+0xc4>
        idx[i] = alloc_desc();
    80206c58:	85b2                	mv	a1,a2
    for (int i = 0; i < VNUM; i++)
    80206c5a:	00140717          	auipc	a4,0x140
    80206c5e:	3a670713          	addi	a4,a4,934 # 80347000 <vdisk>
    80206c62:	87ce                	mv	a5,s3
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    80206c64:	02874683          	lbu	a3,40(a4)
    80206c68:	fee9                	bnez	a3,80206c42 <hal_block_rw+0x54>
    for (int i = 0; i < VNUM; i++)
    80206c6a:	2785                	addiw	a5,a5,1
    80206c6c:	0705                	addi	a4,a4,1
    80206c6e:	fe979be3          	bne	a5,s1,80206c64 <hal_block_rw+0x76>
        idx[i] = alloc_desc();
    80206c72:	57fd                	li	a5,-1
    80206c74:	c19c                	sw	a5,0(a1)
            for (int j = 0; j < i; j++) free_desc(idx[j]);
    80206c76:	03205163          	blez	s2,80206c98 <hal_block_rw+0xaa>
    80206c7a:	f9042503          	lw	a0,-112(s0)
    80206c7e:	00000097          	auipc	ra,0x0
    80206c82:	c66080e7          	jalr	-922(ra) # 802068e4 <free_desc>
    80206c86:	4785                	li	a5,1
    80206c88:	0127d863          	bge	a5,s2,80206c98 <hal_block_rw+0xaa>
    80206c8c:	f9442503          	lw	a0,-108(s0)
    80206c90:	00000097          	auipc	ra,0x0
    80206c94:	c54080e7          	jalr	-940(ra) # 802068e4 <free_desc>
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    80206c98:	85de                	mv	a1,s7
    80206c9a:	00140517          	auipc	a0,0x140
    80206c9e:	38e50513          	addi	a0,a0,910 # 80347028 <vdisk+0x28>
    80206ca2:	ffffb097          	auipc	ra,0xffffb
    80206ca6:	16a080e7          	jalr	362(ra) # 80201e0c <sleep>
    for (int i = 0; i < 3; i++) {
    80206caa:	f9040613          	addi	a2,s0,-112
    80206cae:	894e                	mv	s2,s3
    80206cb0:	b765                	j	80206c58 <hal_block_rw+0x6a>

    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80206cb2:	f9042683          	lw	a3,-112(s0)
    80206cb6:	00268793          	addi	a5,a3,2
    80206cba:	0796                	slli	a5,a5,0x5
    req->type     = write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN;
    80206cbc:	00140597          	auipc	a1,0x140
    80206cc0:	34458593          	addi	a1,a1,836 # 80347000 <vdisk>
    80206cc4:	00569713          	slli	a4,a3,0x5
    80206cc8:	972e                	add	a4,a4,a1
    80206cca:	01903633          	snez	a2,s9
    80206cce:	c330                	sw	a2,64(a4)
    req->reserved = 0;
    80206cd0:	04072223          	sw	zero,68(a4)
    req->sector   = sector;
    80206cd4:	05873423          	sd	s8,72(a4)

    vdisk.desc[idx[0]] = (struct virtq_desc){
    80206cd8:	00469613          	slli	a2,a3,0x4
    80206cdc:	6998                	ld	a4,16(a1)
    80206cde:	9732                	add	a4,a4,a2
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80206ce0:	f9442603          	lw	a2,-108(s0)
    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80206ce4:	00f58533          	add	a0,a1,a5
    vdisk.desc[idx[0]] = (struct virtq_desc){
    80206ce8:	e308                	sd	a0,0(a4)
    80206cea:	4541                	li	a0,16
    80206cec:	c708                	sw	a0,8(a4)
    80206cee:	4505                	li	a0,1
    80206cf0:	00a71623          	sh	a0,12(a4)
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80206cf4:	00c71723          	sh	a2,14(a4)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    80206cf8:	0612                	slli	a2,a2,0x4
    80206cfa:	6998                	ld	a4,16(a1)
    80206cfc:	9732                	add	a4,a4,a2
        (uint64)b->data, BSIZE,
    80206cfe:	058a0513          	addi	a0,s4,88
        (uint16)((write ? 0 : VRING_DESC_F_WRITE) | VRING_DESC_F_NEXT),
    80206d02:	460d                	li	a2,3
    80206d04:	000c8363          	beqz	s9,80206d0a <hal_block_rw+0x11c>
    80206d08:	4605                	li	a2,1
        (uint16)idx[2] };
    80206d0a:	f9842583          	lw	a1,-104(s0)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    80206d0e:	e308                	sd	a0,0(a4)
    80206d10:	40000513          	li	a0,1024
    80206d14:	c708                	sw	a0,8(a4)
    80206d16:	00c71623          	sh	a2,12(a4)
        (uint16)idx[2] };
    80206d1a:	00b71723          	sh	a1,14(a4)
    vdisk.info[idx[0]].status = 0xff;             /* device overwrites on success */
    80206d1e:	00140717          	auipc	a4,0x140
    80206d22:	2e270713          	addi	a4,a4,738 # 80347000 <vdisk>
    80206d26:	00268613          	addi	a2,a3,2
    80206d2a:	0616                	slli	a2,a2,0x5
    80206d2c:	963a                	add	a2,a2,a4
    80206d2e:	557d                	li	a0,-1
    80206d30:	00a60823          	sb	a0,16(a2)
    vdisk.desc[idx[2]] = (struct virtq_desc){
    80206d34:	0592                	slli	a1,a1,0x4
    80206d36:	6b10                	ld	a2,16(a4)
    80206d38:	962e                	add	a2,a2,a1
        (uint64)&vdisk.info[idx[0]].status, 1, VRING_DESC_F_WRITE, 0 };
    80206d3a:	07c1                	addi	a5,a5,16
    80206d3c:	97ba                	add	a5,a5,a4
    vdisk.desc[idx[2]] = (struct virtq_desc){
    80206d3e:	e21c                	sd	a5,0(a2)
    80206d40:	4585                	li	a1,1
    80206d42:	c60c                	sw	a1,8(a2)
    80206d44:	4789                	li	a5,2
    80206d46:	00f61623          	sh	a5,12(a2)
    80206d4a:	00061723          	sh	zero,14(a2)

    b->disk = 1;                                  /* I2: device owns b->data */
    80206d4e:	00ba2223          	sw	a1,4(s4)
    vdisk.info[idx[0]].b = b;                     /* I3 */
    80206d52:	00569793          	slli	a5,a3,0x5
    80206d56:	97ba                	add	a5,a5,a4
    80206d58:	0347bc23          	sd	s4,56(a5)

    vdisk.avail->ring[vdisk.avail->idx % VNUM] = idx[0];
    80206d5c:	6f10                	ld	a2,24(a4)
    80206d5e:	00265783          	lhu	a5,2(a2)
    80206d62:	8b9d                	andi	a5,a5,7
    80206d64:	0786                	slli	a5,a5,0x1
    80206d66:	963e                	add	a2,a2,a5
    80206d68:	00d61223          	sh	a3,4(a2)
    __sync_synchronize();          /* ring entry visible BEFORE idx bump */
    80206d6c:	0ff0000f          	fence
    vdisk.avail->idx += 1;
    80206d70:	6f14                	ld	a3,24(a4)
    80206d72:	0026d783          	lhu	a5,2(a3)
    80206d76:	2785                	addiw	a5,a5,1
    80206d78:	00f69123          	sh	a5,2(a3)
    __sync_synchronize();          /* idx visible BEFORE the doorbell    */
    80206d7c:	0ff0000f          	fence
    *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0;
    80206d80:	631c                	ld	a5,0(a4)
    80206d82:	0407a823          	sw	zero,80(a5)

    while (b->disk == 1)
    80206d86:	004a2783          	lw	a5,4(s4)
    80206d8a:	02b79163          	bne	a5,a1,80206dac <hal_block_rw+0x1be>
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    80206d8e:	00140917          	auipc	s2,0x140
    80206d92:	3aa90913          	addi	s2,s2,938 # 80347138 <vdisk+0x138>
    while (b->disk == 1)
    80206d96:	4485                	li	s1,1
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    80206d98:	85ca                	mv	a1,s2
    80206d9a:	8552                	mv	a0,s4
    80206d9c:	ffffb097          	auipc	ra,0xffffb
    80206da0:	070080e7          	jalr	112(ra) # 80201e0c <sleep>
    while (b->disk == 1)
    80206da4:	004a2783          	lw	a5,4(s4)
    80206da8:	fe9788e3          	beq	a5,s1,80206d98 <hal_block_rw+0x1aa>

    vdisk.info[idx[0]].b = 0;
    80206dac:	f9042503          	lw	a0,-112(s0)
    80206db0:	00551713          	slli	a4,a0,0x5
    80206db4:	00140797          	auipc	a5,0x140
    80206db8:	24c78793          	addi	a5,a5,588 # 80347000 <vdisk>
    80206dbc:	97ba                	add	a5,a5,a4
    80206dbe:	0207bc23          	sd	zero,56(a5)
    free_desc(idx[0]); free_desc(idx[1]); free_desc(idx[2]);
    80206dc2:	00000097          	auipc	ra,0x0
    80206dc6:	b22080e7          	jalr	-1246(ra) # 802068e4 <free_desc>
    80206dca:	f9442503          	lw	a0,-108(s0)
    80206dce:	00000097          	auipc	ra,0x0
    80206dd2:	b16080e7          	jalr	-1258(ra) # 802068e4 <free_desc>
    80206dd6:	f9842503          	lw	a0,-104(s0)
    80206dda:	00000097          	auipc	ra,0x0
    80206dde:	b0a080e7          	jalr	-1270(ra) # 802068e4 <free_desc>

    release(&vdisk.lock);
    80206de2:	00140517          	auipc	a0,0x140
    80206de6:	35650513          	addi	a0,a0,854 # 80347138 <vdisk+0x138>
    80206dea:	ffffa097          	auipc	ra,0xffffa
    80206dee:	5f2080e7          	jalr	1522(ra) # 802013dc <release>
}
    80206df2:	70a6                	ld	ra,104(sp)
    80206df4:	7406                	ld	s0,96(sp)
    80206df6:	64e6                	ld	s1,88(sp)
    80206df8:	6946                	ld	s2,80(sp)
    80206dfa:	69a6                	ld	s3,72(sp)
    80206dfc:	6a06                	ld	s4,64(sp)
    80206dfe:	7ae2                	ld	s5,56(sp)
    80206e00:	7b42                	ld	s6,48(sp)
    80206e02:	7ba2                	ld	s7,40(sp)
    80206e04:	7c02                	ld	s8,32(sp)
    80206e06:	6ce2                	ld	s9,24(sp)
    80206e08:	6165                	addi	sp,sp,112
    80206e0a:	8082                	ret

0000000080206e0c <hal_block_intr>:

void hal_block_intr(void)
{
    80206e0c:	1101                	addi	sp,sp,-32
    80206e0e:	ec06                	sd	ra,24(sp)
    80206e10:	e822                	sd	s0,16(sp)
    80206e12:	e426                	sd	s1,8(sp)
    80206e14:	1000                	addi	s0,sp,32
    acquire(&vdisk.lock);
    80206e16:	00140497          	auipc	s1,0x140
    80206e1a:	1ea48493          	addi	s1,s1,490 # 80347000 <vdisk>
    80206e1e:	00140517          	auipc	a0,0x140
    80206e22:	31a50513          	addi	a0,a0,794 # 80347138 <vdisk+0x138>
    80206e26:	ffffa097          	auipc	ra,0xffffa
    80206e2a:	502080e7          	jalr	1282(ra) # 80201328 <acquire>

    /* Ack FIRST: a completion that lands after this read re-raises the
     * interrupt instead of being lost. */
    *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80206e2e:	6098                	ld	a4,0(s1)
    80206e30:	533c                	lw	a5,96(a4)
    80206e32:	8b8d                	andi	a5,a5,3
    80206e34:	d37c                	sw	a5,100(a4)
    __sync_synchronize();
    80206e36:	0ff0000f          	fence

    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    80206e3a:	709c                	ld	a5,32(s1)
    80206e3c:	0304d703          	lhu	a4,48(s1)
    80206e40:	0027d783          	lhu	a5,2(a5)
    80206e44:	04f70e63          	beq	a4,a5,80206ea0 <hal_block_intr+0x94>
    80206e48:	e04a                	sd	s2,0(sp)

        if (vdisk.info[id].status != 0)
            panic("virtio_blk: request failed (status byte nonzero)");

        struct buf *b = vdisk.info[id].b;
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    80206e4a:	4905                	li	s2,1
        __sync_synchronize();
    80206e4c:	0ff0000f          	fence
        int id = vdisk.used->ring[vdisk.used_idx % VNUM].id;
    80206e50:	7098                	ld	a4,32(s1)
    80206e52:	0304d783          	lhu	a5,48(s1)
    80206e56:	8b9d                	andi	a5,a5,7
    80206e58:	078e                	slli	a5,a5,0x3
    80206e5a:	97ba                	add	a5,a5,a4
    80206e5c:	43dc                	lw	a5,4(a5)
        if (vdisk.info[id].status != 0)
    80206e5e:	00278713          	addi	a4,a5,2
    80206e62:	0716                	slli	a4,a4,0x5
    80206e64:	9726                	add	a4,a4,s1
    80206e66:	01074703          	lbu	a4,16(a4)
    80206e6a:	eb21                	bnez	a4,80206eba <hal_block_intr+0xae>
        struct buf *b = vdisk.info[id].b;
    80206e6c:	0796                	slli	a5,a5,0x5
    80206e6e:	97a6                	add	a5,a5,s1
    80206e70:	7f88                	ld	a0,56(a5)
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    80206e72:	cd21                	beqz	a0,80206eca <hal_block_intr+0xbe>
    80206e74:	415c                	lw	a5,4(a0)
    80206e76:	05279a63          	bne	a5,s2,80206eca <hal_block_intr+0xbe>
        b->disk = 0;                              /* I2: hart owns data again */
    80206e7a:	00052223          	sw	zero,4(a0)
        wakeup(b);
    80206e7e:	ffffb097          	auipc	ra,0xffffb
    80206e82:	114080e7          	jalr	276(ra) # 80201f92 <wakeup>

        vdisk.used_idx += 1;
    80206e86:	0304d783          	lhu	a5,48(s1)
    80206e8a:	2785                	addiw	a5,a5,1
    80206e8c:	17c2                	slli	a5,a5,0x30
    80206e8e:	93c1                	srli	a5,a5,0x30
    80206e90:	02f49823          	sh	a5,48(s1)
    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    80206e94:	7098                	ld	a4,32(s1)
    80206e96:	00275703          	lhu	a4,2(a4)
    80206e9a:	faf719e3          	bne	a4,a5,80206e4c <hal_block_intr+0x40>
    80206e9e:	6902                	ld	s2,0(sp)
    }
    release(&vdisk.lock);
    80206ea0:	00140517          	auipc	a0,0x140
    80206ea4:	29850513          	addi	a0,a0,664 # 80347138 <vdisk+0x138>
    80206ea8:	ffffa097          	auipc	ra,0xffffa
    80206eac:	534080e7          	jalr	1332(ra) # 802013dc <release>
}
    80206eb0:	60e2                	ld	ra,24(sp)
    80206eb2:	6442                	ld	s0,16(sp)
    80206eb4:	64a2                	ld	s1,8(sp)
    80206eb6:	6105                	addi	sp,sp,32
    80206eb8:	8082                	ret
            panic("virtio_blk: request failed (status byte nonzero)");
    80206eba:	00001517          	auipc	a0,0x1
    80206ebe:	e3e50513          	addi	a0,a0,-450 # 80207cf8 <etext+0xcf8>
    80206ec2:	ffff9097          	auipc	ra,0xffff9
    80206ec6:	730080e7          	jalr	1840(ra) # 802005f2 <panic>
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    80206eca:	00001517          	auipc	a0,0x1
    80206ece:	e6650513          	addi	a0,a0,-410 # 80207d30 <etext+0xd30>
    80206ed2:	ffff9097          	auipc	ra,0xffff9
    80206ed6:	720080e7          	jalr	1824(ra) # 802005f2 <panic>
