user/sleep.o: user/sleep.c user/ulib.h user/../kernel/stat.h \
 user/../kernel/fcntl.h user/../kernel/pstat.h
