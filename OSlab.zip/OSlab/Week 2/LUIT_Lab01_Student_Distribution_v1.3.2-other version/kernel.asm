
kernel.elf:     file format elf64-littleriscv


Disassembly of section .text:

0000000080200000 <_entry>:
# L1/L2 - first instructions. OpenSBI enters here in S-mode.
# a0 = hartid, a1 = physical address of the FDT blob. Both must survive to start().
.section .text.entry
.globl _entry
_entry:
        la      t0, boot_stacks
    80200000:	00009297          	auipc	t0,0x9
    80200004:	00028293          	mv	t0,t0
        li      t1, 16384
    80200008:	6311                	lui	t1,0x4
        addi    t2, a0, 1
    8020000a:	00150393          	addi	t2,a0,1
        mul     t1, t1, t2
    8020000e:	02730333          	mul	t1,t1,t2
        add     sp, t0, t1      # sp = boot_stacks + (hartid+1)*16384
    80200012:	00628133          	add	sp,t0,t1
        mv      tp, a0          # tp = hartid, for mycpu()
    80200016:	822a                	mv	tp,a0
        call    start
    80200018:	00000097          	auipc	ra,0x0
    8020001c:	022080e7          	jalr	34(ra) # 8020003a <start>

0000000080200020 <spin>:
spin:   wfi
    80200020:	10500073          	wfi
        j       spin
    80200024:	bff5                	j	80200020 <spin>

0000000080200026 <boot_hart_id>:
 * architectural guarantee and newer firmware/QEMU combinations may choose a
 * different hart. The first hart entering start() becomes Luit's boot hart. */
volatile static int boot_hart = -1;

int boot_hart_id(void)
{
    80200026:	1141                	addi	sp,sp,-16
    80200028:	e422                	sd	s0,8(sp)
    8020002a:	0800                	addi	s0,sp,16
    return boot_hart;
}
    8020002c:	00008517          	auipc	a0,0x8
    80200030:	fd452503          	lw	a0,-44(a0) # 80208000 <boot_hart>
    80200034:	6422                	ld	s0,8(sp)
    80200036:	0141                	addi	sp,sp,16
    80200038:	8082                	ret

000000008020003a <start>:
    printf("hart %d: online\n", hal_hart_id());
    scheduler();            /* never returns */
}

void start(uint64 hartid, uint64 fdt_pa)
{
    8020003a:	7139                	addi	sp,sp,-64
    8020003c:	fc06                	sd	ra,56(sp)
    8020003e:	f822                	sd	s0,48(sp)
    80200040:	f04a                	sd	s2,32(sp)
    80200042:	0080                	addi	s0,sp,64
    80200044:	892a                	mv	s2,a0
    /* Normally only OpenSBI's selected boot hart enters here initially.
     * The atomic claim also makes this safe on firmware that releases more
     * than one hart at reset. */
    int is_boot_hart = __sync_bool_compare_and_swap(&boot_hart, -1, (int)hartid);
    80200046:	00008717          	auipc	a4,0x8
    8020004a:	fba70713          	addi	a4,a4,-70 # 80208000 <boot_hart>
    8020004e:	56fd                	li	a3,-1
    80200050:	0f50000f          	fence	iorw,ow
    80200054:	140727af          	lr.w.aq	a5,(a4)
    80200058:	00d79563          	bne	a5,a3,80200062 <start+0x28>
    8020005c:	1ca7262f          	sc.w.aq	a2,a0,(a4)
    80200060:	fa75                	bnez	a2,80200054 <start+0x1a>
    80200062:	2785                	addiw	a5,a5,1

    if (is_boot_hart) {
    80200064:	1c079663          	bnez	a5,80200230 <start+0x1f6>
    80200068:	f426                	sd	s1,40(sp)
    8020006a:	ec4e                	sd	s3,24(sp)
    8020006c:	e852                	sd	s4,16(sp)
    8020006e:	852e                	mv	a0,a1
        /* --- firmware-selected boot hart --- */

        /* BEFORE anything else, ask the firmware what hardware we have.
         * Until fdt_init() runs we know nothing about this board - and we do
         * not pretend to. Use SBI's console for the very first messages. */
        fdt_init(fdt_pa);
    80200070:	00001097          	auipc	ra,0x1
    80200074:	88e080e7          	jalr	-1906(ra) # 802008fe <fdt_init>

        /* Report what we discovered BEFORE we trust it - these lines go out over
         * the SBI console, so they are visible even if the UART base is wrong. */
        printf("\n");
    80200078:	00007517          	auipc	a0,0x7
    8020007c:	f8850513          	addi	a0,a0,-120 # 80207000 <etext>
    80200080:	00000097          	auipc	ra,0x0
    80200084:	30c080e7          	jalr	780(ra) # 8020038c <printf>
        printf("=========================================\n");
    80200088:	00007517          	auipc	a0,0x7
    8020008c:	f8050513          	addi	a0,a0,-128 # 80207008 <etext+0x8>
    80200090:	00000097          	auipc	ra,0x0
    80200094:	2fc080e7          	jalr	764(ra) # 8020038c <printf>
        printf("  BrahmaputraOS / kernel Luit\n");
    80200098:	00007517          	auipc	a0,0x7
    8020009c:	fa050513          	addi	a0,a0,-96 # 80207038 <etext+0x38>
    802000a0:	00000097          	auipc	ra,0x0
    802000a4:	2ec080e7          	jalr	748(ra) # 8020038c <printf>
        printf("  IIT Guwahati - CS3106L\n");
    802000a8:	00007517          	auipc	a0,0x7
    802000ac:	fb050513          	addi	a0,a0,-80 # 80207058 <etext+0x58>
    802000b0:	00000097          	auipc	ra,0x0
    802000b4:	2dc080e7          	jalr	732(ra) # 8020038c <printf>
        printf("=========================================\n");
    802000b8:	00007517          	auipc	a0,0x7
    802000bc:	f5050513          	addi	a0,a0,-176 # 80207008 <etext+0x8>
    802000c0:	00000097          	auipc	ra,0x0
    802000c4:	2cc080e7          	jalr	716(ra) # 8020038c <printf>
        printf("fdt   : blob at %p (%d bytes)\n", fdt.blob, fdt.blob_size);
    802000c8:	00029497          	auipc	s1,0x29
    802000cc:	f5048493          	addi	s1,s1,-176 # 80229018 <fdt>
    802000d0:	6490                	ld	a2,8(s1)
    802000d2:	608c                	ld	a1,0(s1)
    802000d4:	00007517          	auipc	a0,0x7
    802000d8:	fa450513          	addi	a0,a0,-92 # 80207078 <etext+0x78>
    802000dc:	00000097          	auipc	ra,0x0
    802000e0:	2b0080e7          	jalr	688(ra) # 8020038c <printf>
        printf("uart  : %p  (discovered, not hardcoded)\n", fdt.uart_base);
    802000e4:	688c                	ld	a1,16(s1)
    802000e6:	00007517          	auipc	a0,0x7
    802000ea:	fb250513          	addi	a0,a0,-78 # 80207098 <etext+0x98>
    802000ee:	00000097          	auipc	ra,0x0
    802000f2:	29e080e7          	jalr	670(ra) # 8020038c <printf>
        printf("plic  : %p\n", fdt.plic_base);
    802000f6:	6c8c                	ld	a1,24(s1)
    802000f8:	00007517          	auipc	a0,0x7
    802000fc:	fd050513          	addi	a0,a0,-48 # 802070c8 <etext+0xc8>
    80200100:	00000097          	auipc	ra,0x0
    80200104:	28c080e7          	jalr	652(ra) # 8020038c <printf>
        printf("memory: %p + %d MiB\n", fdt.mem_base, fdt.mem_size >> 20);
    80200108:	6cd0                	ld	a2,152(s1)
    8020010a:	8251                	srli	a2,a2,0x14
    8020010c:	68cc                	ld	a1,144(s1)
    8020010e:	00007517          	auipc	a0,0x7
    80200112:	fca50513          	addi	a0,a0,-54 # 802070d8 <etext+0xd8>
    80200116:	00000097          	auipc	ra,0x0
    8020011a:	276080e7          	jalr	630(ra) # 8020038c <printf>
        printf("harts : %d\n", fdt.ncpu);
    8020011e:	0a04a583          	lw	a1,160(s1)
    80200122:	00007517          	auipc	a0,0x7
    80200126:	fce50513          	addi	a0,a0,-50 # 802070f0 <etext+0xf0>
    8020012a:	00000097          	auipc	ra,0x0
    8020012e:	262080e7          	jalr	610(ra) # 8020038c <printf>

        /* Now switch to our own UART driver. */
        hal_console_init(fdt.uart_base);
    80200132:	6888                	ld	a0,16(s1)
    80200134:	00006097          	auipc	ra,0x6
    80200138:	09c080e7          	jalr	156(ra) # 802061d0 <hal_console_init>
        hal_intc_init(fdt.plic_base);
    8020013c:	6c88                	ld	a0,24(s1)
    8020013e:	00006097          	auipc	ra,0x6
    80200142:	eee080e7          	jalr	-274(ra) # 8020602c <hal_intc_init>
        console_ready = 1;
    80200146:	0013f997          	auipc	s3,0x13f
    8020014a:	ebe98993          	addi	s3,s3,-322 # 8033f004 <console_ready>
    8020014e:	4a05                	li	s4,1
    80200150:	0149a023          	sw	s4,0(s3)

        palloc_init();
    80200154:	00001097          	auipc	ra,0x1
    80200158:	e36080e7          	jalr	-458(ra) # 80200f8a <palloc_init>
        printfinit();       /* locked printf, now that we have locks + memory */
    8020015c:	00000097          	auipc	ra,0x0
    80200160:	470080e7          	jalr	1136(ra) # 802005cc <printfinit>
        procinit();
    80200164:	00001097          	auipc	ra,0x1
    80200168:	662080e7          	jalr	1634(ra) # 802017c6 <procinit>
        kvminit();
    8020016c:	00003097          	auipc	ra,0x3
    80200170:	ae0080e7          	jalr	-1312(ra) # 80202c4c <kvminit>
        kvminithart();      /* paging ON for this hart */
    80200174:	00003097          	auipc	ra,0x3
    80200178:	bea080e7          	jalr	-1046(ra) # 80202d5e <kvminithart>

        /* MMIO is now behind the page table at its high alias - re-point the
         * drivers at the virtual addresses. This is why the HAL takes a base
         * address as an argument instead of hardcoding one. */
        console_ready = 0;                    /* SBI console while we re-point */
    8020017c:	0009a023          	sw	zero,0(s3)
        hal_console_init(mmio_alias(fdt.uart_base));
    80200180:	6888                	ld	a0,16(s1)
    80200182:	00003097          	auipc	ra,0x3
    80200186:	8fa080e7          	jalr	-1798(ra) # 80202a7c <mmio_alias>
    8020018a:	00006097          	auipc	ra,0x6
    8020018e:	046080e7          	jalr	70(ra) # 802061d0 <hal_console_init>
        console_ready = 1;
    80200192:	0149a023          	sw	s4,0(s3)
        hal_intc_init(mmio_alias(fdt.plic_base));
    80200196:	6c88                	ld	a0,24(s1)
    80200198:	00003097          	auipc	ra,0x3
    8020019c:	8e4080e7          	jalr	-1820(ra) # 80202a7c <mmio_alias>
    802001a0:	00006097          	auipc	ra,0x6
    802001a4:	e8c080e7          	jalr	-372(ra) # 8020602c <hal_intc_init>

        consoleinit();      /* console device (major CONSOLE)         */
    802001a8:	00004097          	auipc	ra,0x4
    802001ac:	06e080e7          	jalr	110(ra) # 80204216 <consoleinit>
        binit();            /* buffer cache                           */
    802001b0:	00004097          	auipc	ra,0x4
    802001b4:	5fa080e7          	jalr	1530(ra) # 802047aa <binit>
        iinit();            /* inode cache                            */
    802001b8:	00005097          	auipc	ra,0x5
    802001bc:	c4c080e7          	jalr	-948(ra) # 80204e04 <iinit>
        fileinit();         /* system-wide open-file table            */
    802001c0:	00005097          	auipc	ra,0x5
    802001c4:	76e080e7          	jalr	1902(ra) # 8020592e <fileinit>
        if (hal_block_init() < 0)
    802001c8:	00006097          	auipc	ra,0x6
    802001cc:	126080e7          	jalr	294(ra) # 802062ee <hal_block_init>
    802001d0:	0a054663          	bltz	a0,8020027c <start+0x242>
    802001d4:	e456                	sd	s5,8(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
        trapinit_hart();    /* traps, timer, PLIC (incl. the disk irq) */
    802001d6:	00002097          	auipc	ra,0x2
    802001da:	2be080e7          	jalr	702(ra) # 80202494 <trapinit_hart>
        userinit();         /* the first user process                 */
    802001de:	00001097          	auipc	ra,0x1
    802001e2:	680080e7          	jalr	1664(ra) # 8020185e <userinit>

        printf("hart %d: online\n", (int)hartid);
    802001e6:	2901                	sext.w	s2,s2
    802001e8:	85ca                	mv	a1,s2
    802001ea:	00007517          	auipc	a0,0x7
    802001ee:	f5e50513          	addi	a0,a0,-162 # 80207148 <etext+0x148>
    802001f2:	00000097          	auipc	ra,0x0
    802001f6:	19a080e7          	jalr	410(ra) # 8020038c <printf>
        __sync_synchronize();
    802001fa:	0ff0000f          	fence
        started = 1;
    802001fe:	4785                	li	a5,1
    80200200:	0013f717          	auipc	a4,0x13f
    80200204:	e0f72023          	sw	a5,-512(a4) # 8033f000 <started>

        /* L9: SMP. Start every OTHER hart the device tree told us about.
         * We do not assume 1. We do not assume 4. We ask. */
        for (int i = 0; i < fdt.ncpu; i++) {
    80200208:	00029797          	auipc	a5,0x29
    8020020c:	eb07a783          	lw	a5,-336(a5) # 802290b8 <fdt+0xa0>
    80200210:	0af05b63          	blez	a5,802002c6 <start+0x28c>
    80200214:	4481                	li	s1,0
            if (i == (int)hartid)
                continue;
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    80200216:	00000a17          	auipc	s4,0x0
    8020021a:	deaa0a13          	addi	s4,s4,-534 # 80200000 <_entry>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    8020021e:	00007a97          	auipc	s5,0x7
    80200222:	f42a8a93          	addi	s5,s5,-190 # 80207160 <etext+0x160>
        for (int i = 0; i < fdt.ncpu; i++) {
    80200226:	00029997          	auipc	s3,0x29
    8020022a:	df298993          	addi	s3,s3,-526 # 80229018 <fdt>
    8020022e:	a0bd                	j	8020029c <start+0x262>
    80200230:	f426                	sd	s1,40(sp)
    80200232:	ec4e                	sd	s3,24(sp)
    80200234:	e852                	sd	s4,16(sp)
    80200236:	e456                	sd	s5,8(sp)
        }

        scheduler();
    } else {
        /* --- secondary harts --- */
        while (started == 0)
    80200238:	0013f717          	auipc	a4,0x13f
    8020023c:	dc870713          	addi	a4,a4,-568 # 8033f000 <started>
    80200240:	431c                	lw	a5,0(a4)
    80200242:	2781                	sext.w	a5,a5
    80200244:	dff5                	beqz	a5,80200240 <start+0x206>
            ;
        __sync_synchronize();
    80200246:	0ff0000f          	fence
    kvminithart();          /* same kernel page table */
    8020024a:	00003097          	auipc	ra,0x3
    8020024e:	b14080e7          	jalr	-1260(ra) # 80202d5e <kvminithart>
    trapinit_hart();        /* own stvec, own timer, own PLIC context */
    80200252:	00002097          	auipc	ra,0x2
    80200256:	242080e7          	jalr	578(ra) # 80202494 <trapinit_hart>
    printf("hart %d: online\n", hal_hart_id());
    8020025a:	00006097          	auipc	ra,0x6
    8020025e:	ec8080e7          	jalr	-312(ra) # 80206122 <hal_hart_id>
    80200262:	85aa                	mv	a1,a0
    80200264:	00007517          	auipc	a0,0x7
    80200268:	ee450513          	addi	a0,a0,-284 # 80207148 <etext+0x148>
    8020026c:	00000097          	auipc	ra,0x0
    80200270:	120080e7          	jalr	288(ra) # 8020038c <printf>
    scheduler();            /* never returns */
    80200274:	00002097          	auipc	ra,0x2
    80200278:	916080e7          	jalr	-1770(ra) # 80201b8a <scheduler>
    8020027c:	e456                	sd	s5,8(sp)
            panic("no block device: did you forget -drive/-device? (make qemu adds it)");
    8020027e:	00007517          	auipc	a0,0x7
    80200282:	e8250513          	addi	a0,a0,-382 # 80207100 <etext+0x100>
    80200286:	00000097          	auipc	ra,0x0
    8020028a:	378080e7          	jalr	888(ra) # 802005fe <panic>
        for (int i = 0; i < fdt.ncpu; i++) {
    8020028e:	0485                	addi	s1,s1,1
    80200290:	0a09a703          	lw	a4,160(s3)
    80200294:	0004879b          	sext.w	a5,s1
    80200298:	02e7d763          	bge	a5,a4,802002c6 <start+0x28c>
            if (i == (int)hartid)
    8020029c:	0004879b          	sext.w	a5,s1
    802002a0:	fef907e3          	beq	s2,a5,8020028e <start+0x254>
            long err = sbi_hart_start(i, (uint64)_entry, 0);
    802002a4:	4601                	li	a2,0
    802002a6:	85d2                	mv	a1,s4
    802002a8:	8526                	mv	a0,s1
    802002aa:	00000097          	auipc	ra,0x0
    802002ae:	574080e7          	jalr	1396(ra) # 8020081e <sbi_hart_start>
            if (err) printf("hart %d: failed to start (sbi err %d)\n", i, err);
    802002b2:	dd71                	beqz	a0,8020028e <start+0x254>
    802002b4:	862a                	mv	a2,a0
    802002b6:	0004859b          	sext.w	a1,s1
    802002ba:	8556                	mv	a0,s5
    802002bc:	00000097          	auipc	ra,0x0
    802002c0:	0d0080e7          	jalr	208(ra) # 8020038c <printf>
    802002c4:	b7e9                	j	8020028e <start+0x254>
        scheduler();
    802002c6:	00002097          	auipc	ra,0x2
    802002ca:	8c4080e7          	jalr	-1852(ra) # 80201b8a <scheduler>

00000000802002ce <putc>:

/* Before the UART driver exists (i.e. before the device tree has told us where
 * the UART is), fall back to OpenSBI's console. This is why a panic inside
 * fdt_init() is still visible - a silent early panic is a nightmare to debug. */
int console_ready = 0;
static void putc(char c) { if (console_ready) hal_console_putc(c); else sbi_putchar(c); }
    802002ce:	1141                	addi	sp,sp,-16
    802002d0:	e406                	sd	ra,8(sp)
    802002d2:	e022                	sd	s0,0(sp)
    802002d4:	0800                	addi	s0,sp,16
    802002d6:	0013f797          	auipc	a5,0x13f
    802002da:	d2e7a783          	lw	a5,-722(a5) # 8033f004 <console_ready>
    802002de:	cb89                	beqz	a5,802002f0 <putc+0x22>
    802002e0:	00006097          	auipc	ra,0x6
    802002e4:	f2a080e7          	jalr	-214(ra) # 8020620a <hal_console_putc>
    802002e8:	60a2                	ld	ra,8(sp)
    802002ea:	6402                	ld	s0,0(sp)
    802002ec:	0141                	addi	sp,sp,16
    802002ee:	8082                	ret
    802002f0:	00000097          	auipc	ra,0x0
    802002f4:	4dc080e7          	jalr	1244(ra) # 802007cc <sbi_putchar>
    802002f8:	bfc5                	j	802002e8 <putc+0x1a>

00000000802002fa <printint>:

static void printint(long long xx, int base, int sign)
{
    802002fa:	7139                	addi	sp,sp,-64
    802002fc:	fc06                	sd	ra,56(sp)
    802002fe:	f822                	sd	s0,48(sp)
    80200300:	0080                	addi	s0,sp,64
    char buf[24];
    int i = 0;
    unsigned long long x;

    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    80200302:	c219                	beqz	a2,80200308 <printint+0xe>
    80200304:	08054163          	bltz	a0,80200386 <printint+0x8c>
    80200308:	4601                	li	a2,0
    8020030a:	fc840693          	addi	a3,s0,-56
    8020030e:	4781                	li	a5,0
    do { buf[i++] = digits[x % base]; } while ((x /= base) != 0);
    80200310:	00008817          	auipc	a6,0x8
    80200314:	a9880813          	addi	a6,a6,-1384 # 80207da8 <digits>
    80200318:	88be                	mv	a7,a5
    8020031a:	2785                	addiw	a5,a5,1
    8020031c:	02b57733          	remu	a4,a0,a1
    80200320:	9742                	add	a4,a4,a6
    80200322:	00074703          	lbu	a4,0(a4)
    80200326:	00e68023          	sb	a4,0(a3)
    8020032a:	872a                	mv	a4,a0
    8020032c:	02b55533          	divu	a0,a0,a1
    80200330:	0685                	addi	a3,a3,1
    80200332:	feb773e3          	bgeu	a4,a1,80200318 <printint+0x1e>
    if (sign) buf[i++] = '-';
    80200336:	ca09                	beqz	a2,80200348 <printint+0x4e>
    80200338:	1781                	addi	a5,a5,-32
    8020033a:	97a2                	add	a5,a5,s0
    8020033c:	02d00713          	li	a4,45
    80200340:	fee78423          	sb	a4,-24(a5)
    80200344:	0028879b          	addiw	a5,a7,2
    while (--i >= 0) putc(buf[i]);
    80200348:	02f05b63          	blez	a5,8020037e <printint+0x84>
    8020034c:	f426                	sd	s1,40(sp)
    8020034e:	f04a                	sd	s2,32(sp)
    80200350:	fc840713          	addi	a4,s0,-56
    80200354:	00f704b3          	add	s1,a4,a5
    80200358:	fff70913          	addi	s2,a4,-1
    8020035c:	993e                	add	s2,s2,a5
    8020035e:	37fd                	addiw	a5,a5,-1
    80200360:	1782                	slli	a5,a5,0x20
    80200362:	9381                	srli	a5,a5,0x20
    80200364:	40f90933          	sub	s2,s2,a5
    80200368:	fff4c503          	lbu	a0,-1(s1)
    8020036c:	00000097          	auipc	ra,0x0
    80200370:	f62080e7          	jalr	-158(ra) # 802002ce <putc>
    80200374:	14fd                	addi	s1,s1,-1
    80200376:	ff2499e3          	bne	s1,s2,80200368 <printint+0x6e>
    8020037a:	74a2                	ld	s1,40(sp)
    8020037c:	7902                	ld	s2,32(sp)
}
    8020037e:	70e2                	ld	ra,56(sp)
    80200380:	7442                	ld	s0,48(sp)
    80200382:	6121                	addi	sp,sp,64
    80200384:	8082                	ret
    if (sign && xx < 0) { x = -xx; } else { sign = 0; x = xx; }
    80200386:	40a00533          	neg	a0,a0
    8020038a:	b741                	j	8020030a <printint+0x10>

000000008020038c <printf>:
    for (int i = 0; i < 16; i++, x <<= 4)
        putc(digits[x >> 60]);
}

void printf(const char *fmt, ...)
{
    8020038c:	7171                	addi	sp,sp,-176
    8020038e:	f486                	sd	ra,104(sp)
    80200390:	f0a2                	sd	s0,96(sp)
    80200392:	e0d2                	sd	s4,64(sp)
    80200394:	f062                	sd	s8,32(sp)
    80200396:	1880                	addi	s0,sp,112
    80200398:	8a2a                	mv	s4,a0
    8020039a:	e40c                	sd	a1,8(s0)
    8020039c:	e810                	sd	a2,16(s0)
    8020039e:	ec14                	sd	a3,24(s0)
    802003a0:	f018                	sd	a4,32(s0)
    802003a2:	f41c                	sd	a5,40(s0)
    802003a4:	03043823          	sd	a6,48(s0)
    802003a8:	03143c23          	sd	a7,56(s0)
    va_list ap;
    int locking = pr_locking;
    802003ac:	0013fc17          	auipc	s8,0x13f
    802003b0:	c5cc2c03          	lw	s8,-932(s8) # 8033f008 <pr_locking>
    if (locking) acquire(&pr_lock);
    802003b4:	020c1863          	bnez	s8,802003e4 <printf+0x58>

    va_start(ap, fmt);
    802003b8:	00840793          	addi	a5,s0,8
    802003bc:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003c0:	00054503          	lbu	a0,0(a0)
    802003c4:	1e050063          	beqz	a0,802005a4 <printf+0x218>
    802003c8:	eca6                	sd	s1,88(sp)
    802003ca:	e8ca                	sd	s2,80(sp)
    802003cc:	fc56                	sd	s5,56(sp)
    802003ce:	f85a                	sd	s6,48(sp)
    802003d0:	f45e                	sd	s7,40(sp)
    802003d2:	4481                	li	s1,0
        char c = fmt[i];
        if (c != '%') { putc(c); continue; }
    802003d4:	02500a93          	li	s5,37
        c = fmt[++i];
        if (!c) break;
        switch (c) {
    802003d8:	4b55                	li	s6,21
    802003da:	00008b97          	auipc	s7,0x8
    802003de:	976b8b93          	addi	s7,s7,-1674 # 80207d50 <etext+0xd50>
    802003e2:	a825                	j	8020041a <printf+0x8e>
    if (locking) acquire(&pr_lock);
    802003e4:	00029517          	auipc	a0,0x29
    802003e8:	c1c50513          	addi	a0,a0,-996 # 80229000 <pr_lock>
    802003ec:	00001097          	auipc	ra,0x1
    802003f0:	f48080e7          	jalr	-184(ra) # 80201334 <acquire>
    va_start(ap, fmt);
    802003f4:	00840793          	addi	a5,s0,8
    802003f8:	f8f43c23          	sd	a5,-104(s0)
    for (int i = 0; fmt[i]; i++) {
    802003fc:	000a4503          	lbu	a0,0(s4)
    80200400:	f561                	bnez	a0,802003c8 <printf+0x3c>
    80200402:	aa65                	j	802005ba <printf+0x22e>
        if (c != '%') { putc(c); continue; }
    80200404:	00000097          	auipc	ra,0x0
    80200408:	eca080e7          	jalr	-310(ra) # 802002ce <putc>
    for (int i = 0; fmt[i]; i++) {
    8020040c:	2485                	addiw	s1,s1,1
    8020040e:	009a07b3          	add	a5,s4,s1
    80200412:	0007c503          	lbu	a0,0(a5)
    80200416:	18050063          	beqz	a0,80200596 <printf+0x20a>
        if (c != '%') { putc(c); continue; }
    8020041a:	ff5515e3          	bne	a0,s5,80200404 <printf+0x78>
        c = fmt[++i];
    8020041e:	2485                	addiw	s1,s1,1
    80200420:	009a07b3          	add	a5,s4,s1
    80200424:	0007c903          	lbu	s2,0(a5)
        if (!c) break;
    80200428:	16090763          	beqz	s2,80200596 <printf+0x20a>
        switch (c) {
    8020042c:	15590263          	beq	s2,s5,80200570 <printf+0x1e4>
    80200430:	f9d9079b          	addiw	a5,s2,-99
    80200434:	0ff7f793          	zext.b	a5,a5
    80200438:	14fb6363          	bltu	s6,a5,8020057e <printf+0x1f2>
    8020043c:	f9d9079b          	addiw	a5,s2,-99
    80200440:	0ff7f713          	zext.b	a4,a5
    80200444:	12eb6d63          	bltu	s6,a4,8020057e <printf+0x1f2>
    80200448:	00271793          	slli	a5,a4,0x2
    8020044c:	97de                	add	a5,a5,s7
    8020044e:	439c                	lw	a5,0(a5)
    80200450:	97de                	add	a5,a5,s7
    80200452:	8782                	jr	a5
        case 'd': printint(va_arg(ap, int), 10, 1); break;
    80200454:	f9843783          	ld	a5,-104(s0)
    80200458:	00878713          	addi	a4,a5,8
    8020045c:	f8e43c23          	sd	a4,-104(s0)
    80200460:	4605                	li	a2,1
    80200462:	45a9                	li	a1,10
    80200464:	4388                	lw	a0,0(a5)
    80200466:	00000097          	auipc	ra,0x0
    8020046a:	e94080e7          	jalr	-364(ra) # 802002fa <printint>
    8020046e:	bf79                	j	8020040c <printf+0x80>
        case 'l': printint(va_arg(ap, uint64), 10, 0); break;
    80200470:	f9843783          	ld	a5,-104(s0)
    80200474:	00878713          	addi	a4,a5,8
    80200478:	f8e43c23          	sd	a4,-104(s0)
    8020047c:	4601                	li	a2,0
    8020047e:	45a9                	li	a1,10
    80200480:	6388                	ld	a0,0(a5)
    80200482:	00000097          	auipc	ra,0x0
    80200486:	e78080e7          	jalr	-392(ra) # 802002fa <printint>
    8020048a:	b749                	j	8020040c <printf+0x80>
        case 'u': printint(va_arg(ap, uint64), 10, 0); break;
    8020048c:	f9843783          	ld	a5,-104(s0)
    80200490:	00878713          	addi	a4,a5,8
    80200494:	f8e43c23          	sd	a4,-104(s0)
    80200498:	4601                	li	a2,0
    8020049a:	45a9                	li	a1,10
    8020049c:	6388                	ld	a0,0(a5)
    8020049e:	00000097          	auipc	ra,0x0
    802004a2:	e5c080e7          	jalr	-420(ra) # 802002fa <printint>
    802004a6:	b79d                	j	8020040c <printf+0x80>
        case 'x': printint(va_arg(ap, uint64), 16, 0); break;
    802004a8:	f9843783          	ld	a5,-104(s0)
    802004ac:	00878713          	addi	a4,a5,8
    802004b0:	f8e43c23          	sd	a4,-104(s0)
    802004b4:	4601                	li	a2,0
    802004b6:	45c1                	li	a1,16
    802004b8:	6388                	ld	a0,0(a5)
    802004ba:	00000097          	auipc	ra,0x0
    802004be:	e40080e7          	jalr	-448(ra) # 802002fa <printint>
    802004c2:	b7a9                	j	8020040c <printf+0x80>
    802004c4:	e4ce                	sd	s3,72(sp)
    802004c6:	ec66                	sd	s9,24(sp)
        case 'p': printptr(va_arg(ap, uint64)); break;
    802004c8:	f9843783          	ld	a5,-104(s0)
    802004cc:	00878713          	addi	a4,a5,8
    802004d0:	f8e43c23          	sd	a4,-104(s0)
    802004d4:	0007b983          	ld	s3,0(a5)
    putc('0'); putc('x');
    802004d8:	03000513          	li	a0,48
    802004dc:	00000097          	auipc	ra,0x0
    802004e0:	df2080e7          	jalr	-526(ra) # 802002ce <putc>
    802004e4:	07800513          	li	a0,120
    802004e8:	00000097          	auipc	ra,0x0
    802004ec:	de6080e7          	jalr	-538(ra) # 802002ce <putc>
    802004f0:	4941                	li	s2,16
        putc(digits[x >> 60]);
    802004f2:	00008c97          	auipc	s9,0x8
    802004f6:	8b6c8c93          	addi	s9,s9,-1866 # 80207da8 <digits>
    802004fa:	03c9d793          	srli	a5,s3,0x3c
    802004fe:	97e6                	add	a5,a5,s9
    80200500:	0007c503          	lbu	a0,0(a5)
    80200504:	00000097          	auipc	ra,0x0
    80200508:	dca080e7          	jalr	-566(ra) # 802002ce <putc>
    for (int i = 0; i < 16; i++, x <<= 4)
    8020050c:	0992                	slli	s3,s3,0x4
    8020050e:	397d                	addiw	s2,s2,-1
    80200510:	fe0915e3          	bnez	s2,802004fa <printf+0x16e>
    80200514:	69a6                	ld	s3,72(sp)
    80200516:	6ce2                	ld	s9,24(sp)
    80200518:	bdd5                	j	8020040c <printf+0x80>
        case 'c': putc((char)va_arg(ap, int)); break;
    8020051a:	f9843783          	ld	a5,-104(s0)
    8020051e:	00878713          	addi	a4,a5,8
    80200522:	f8e43c23          	sd	a4,-104(s0)
    80200526:	0007c503          	lbu	a0,0(a5)
    8020052a:	00000097          	auipc	ra,0x0
    8020052e:	da4080e7          	jalr	-604(ra) # 802002ce <putc>
    80200532:	bde9                	j	8020040c <printf+0x80>
        case 's': {
            const char *s = va_arg(ap, const char *);
    80200534:	f9843783          	ld	a5,-104(s0)
    80200538:	00878713          	addi	a4,a5,8
    8020053c:	f8e43c23          	sd	a4,-104(s0)
    80200540:	0007b903          	ld	s2,0(a5)
            if (!s) s = "(null)";
    80200544:	00090f63          	beqz	s2,80200562 <printf+0x1d6>
            while (*s) putc(*s++);
    80200548:	00094503          	lbu	a0,0(s2)
    8020054c:	ec0500e3          	beqz	a0,8020040c <printf+0x80>
    80200550:	0905                	addi	s2,s2,1
    80200552:	00000097          	auipc	ra,0x0
    80200556:	d7c080e7          	jalr	-644(ra) # 802002ce <putc>
    8020055a:	00094503          	lbu	a0,0(s2)
    8020055e:	f96d                	bnez	a0,80200550 <printf+0x1c4>
    80200560:	b575                	j	8020040c <printf+0x80>
            if (!s) s = "(null)";
    80200562:	00007917          	auipc	s2,0x7
    80200566:	c2690913          	addi	s2,s2,-986 # 80207188 <etext+0x188>
            while (*s) putc(*s++);
    8020056a:	02800513          	li	a0,40
    8020056e:	b7cd                	j	80200550 <printf+0x1c4>
            break;
        }
        case '%': putc('%'); break;
    80200570:	02500513          	li	a0,37
    80200574:	00000097          	auipc	ra,0x0
    80200578:	d5a080e7          	jalr	-678(ra) # 802002ce <putc>
    8020057c:	bd41                	j	8020040c <printf+0x80>
        default:  putc('%'); putc(c); break;
    8020057e:	02500513          	li	a0,37
    80200582:	00000097          	auipc	ra,0x0
    80200586:	d4c080e7          	jalr	-692(ra) # 802002ce <putc>
    8020058a:	854a                	mv	a0,s2
    8020058c:	00000097          	auipc	ra,0x0
    80200590:	d42080e7          	jalr	-702(ra) # 802002ce <putc>
    80200594:	bda5                	j	8020040c <printf+0x80>
        }
    }
    va_end(ap);
    if (locking) release(&pr_lock);
    80200596:	000c1d63          	bnez	s8,802005b0 <printf+0x224>
    8020059a:	64e6                	ld	s1,88(sp)
    8020059c:	6946                	ld	s2,80(sp)
    8020059e:	7ae2                	ld	s5,56(sp)
    802005a0:	7b42                	ld	s6,48(sp)
    802005a2:	7ba2                	ld	s7,40(sp)
}
    802005a4:	70a6                	ld	ra,104(sp)
    802005a6:	7406                	ld	s0,96(sp)
    802005a8:	6a06                	ld	s4,64(sp)
    802005aa:	7c02                	ld	s8,32(sp)
    802005ac:	614d                	addi	sp,sp,176
    802005ae:	8082                	ret
    802005b0:	64e6                	ld	s1,88(sp)
    802005b2:	6946                	ld	s2,80(sp)
    802005b4:	7ae2                	ld	s5,56(sp)
    802005b6:	7b42                	ld	s6,48(sp)
    802005b8:	7ba2                	ld	s7,40(sp)
    if (locking) release(&pr_lock);
    802005ba:	00029517          	auipc	a0,0x29
    802005be:	a4650513          	addi	a0,a0,-1466 # 80229000 <pr_lock>
    802005c2:	00001097          	auipc	ra,0x1
    802005c6:	e26080e7          	jalr	-474(ra) # 802013e8 <release>
}
    802005ca:	bfe9                	j	802005a4 <printf+0x218>

00000000802005cc <printfinit>:

void printfinit(void) { initlock(&pr_lock, "pr"); pr_locking = 1; }
    802005cc:	1141                	addi	sp,sp,-16
    802005ce:	e406                	sd	ra,8(sp)
    802005d0:	e022                	sd	s0,0(sp)
    802005d2:	0800                	addi	s0,sp,16
    802005d4:	00007597          	auipc	a1,0x7
    802005d8:	bbc58593          	addi	a1,a1,-1092 # 80207190 <etext+0x190>
    802005dc:	00029517          	auipc	a0,0x29
    802005e0:	a2450513          	addi	a0,a0,-1500 # 80229000 <pr_lock>
    802005e4:	00001097          	auipc	ra,0x1
    802005e8:	cd4080e7          	jalr	-812(ra) # 802012b8 <initlock>
    802005ec:	4785                	li	a5,1
    802005ee:	0013f717          	auipc	a4,0x13f
    802005f2:	a0f72d23          	sw	a5,-1510(a4) # 8033f008 <pr_locking>
    802005f6:	60a2                	ld	ra,8(sp)
    802005f8:	6402                	ld	s0,0(sp)
    802005fa:	0141                	addi	sp,sp,16
    802005fc:	8082                	ret

00000000802005fe <panic>:

void panic(const char *s)
{
    802005fe:	1101                	addi	sp,sp,-32
    80200600:	ec06                	sd	ra,24(sp)
    80200602:	e822                	sd	s0,16(sp)
    80200604:	e426                	sd	s1,8(sp)
    80200606:	1000                	addi	s0,sp,32
    80200608:	84aa                	mv	s1,a0
    pr_locking = 0;                       /* never deadlock inside a panic */
    8020060a:	0013f797          	auipc	a5,0x13f
    8020060e:	9e07af23          	sw	zero,-1538(a5) # 8033f008 <pr_locking>
    printf("\n=== KERNEL PANIC (hart %d) ===\n", hal_hart_id());
    80200612:	00006097          	auipc	ra,0x6
    80200616:	b10080e7          	jalr	-1264(ra) # 80206122 <hal_hart_id>
    8020061a:	85aa                	mv	a1,a0
    8020061c:	00007517          	auipc	a0,0x7
    80200620:	b7c50513          	addi	a0,a0,-1156 # 80207198 <etext+0x198>
    80200624:	00000097          	auipc	ra,0x0
    80200628:	d68080e7          	jalr	-664(ra) # 8020038c <printf>
    printf("  %s\n", s);
    8020062c:	85a6                	mv	a1,s1
    8020062e:	00007517          	auipc	a0,0x7
    80200632:	b9250513          	addi	a0,a0,-1134 # 802071c0 <etext+0x1c0>
    80200636:	00000097          	auipc	ra,0x0
    8020063a:	d56080e7          	jalr	-682(ra) # 8020038c <printf>
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    8020063e:	141025f3          	csrr	a1,sepc
    printf("  sepc   = %p\n", r_sepc());
    80200642:	00007517          	auipc	a0,0x7
    80200646:	b8650513          	addi	a0,a0,-1146 # 802071c8 <etext+0x1c8>
    8020064a:	00000097          	auipc	ra,0x0
    8020064e:	d42080e7          	jalr	-702(ra) # 8020038c <printf>
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80200652:	142025f3          	csrr	a1,scause
    printf("  scause = %p\n", r_scause());
    80200656:	00007517          	auipc	a0,0x7
    8020065a:	b8250513          	addi	a0,a0,-1150 # 802071d8 <etext+0x1d8>
    8020065e:	00000097          	auipc	ra,0x0
    80200662:	d2e080e7          	jalr	-722(ra) # 8020038c <printf>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80200666:	143025f3          	csrr	a1,stval
    printf("  stval  = %p\n", r_stval());
    8020066a:	00007517          	auipc	a0,0x7
    8020066e:	b7e50513          	addi	a0,a0,-1154 # 802071e8 <etext+0x1e8>
    80200672:	00000097          	auipc	ra,0x0
    80200676:	d1a080e7          	jalr	-742(ra) # 8020038c <printf>
static inline void   w_sscratch(uint64 x){ asm volatile("csrw sscratch, %0"::"r"(x)); }
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    8020067a:	180025f3          	csrr	a1,satp
    printf("  satp   = %p\n", r_satp());
    8020067e:	00007517          	auipc	a0,0x7
    80200682:	b7a50513          	addi	a0,a0,-1158 # 802071f8 <etext+0x1f8>
    80200686:	00000097          	auipc	ra,0x0
    8020068a:	d06080e7          	jalr	-762(ra) # 8020038c <printf>
    printf("=============================\n");
    8020068e:	00007517          	auipc	a0,0x7
    80200692:	b7a50513          	addi	a0,a0,-1158 # 80207208 <etext+0x208>
    80200696:	00000097          	auipc	ra,0x0
    8020069a:	cf6080e7          	jalr	-778(ra) # 8020038c <printf>
    for (;;) asm volatile("wfi");
    8020069e:	10500073          	wfi
    802006a2:	bff5                	j	8020069e <panic+0xa0>

00000000802006a4 <memset>:
#include "types.h"
#include "defs.h"
void *memset(void *dst, int c, usize n){ char *d=dst; while(n--) *d++=(char)c; return dst; }
    802006a4:	1141                	addi	sp,sp,-16
    802006a6:	e422                	sd	s0,8(sp)
    802006a8:	0800                	addi	s0,sp,16
    802006aa:	ca01                	beqz	a2,802006ba <memset+0x16>
    802006ac:	962a                	add	a2,a2,a0
    802006ae:	87aa                	mv	a5,a0
    802006b0:	0785                	addi	a5,a5,1
    802006b2:	feb78fa3          	sb	a1,-1(a5)
    802006b6:	fef61de3          	bne	a2,a5,802006b0 <memset+0xc>
    802006ba:	6422                	ld	s0,8(sp)
    802006bc:	0141                	addi	sp,sp,16
    802006be:	8082                	ret

00000000802006c0 <memmove>:
void *memmove(void *dst, const void *src, usize n){
    802006c0:	1141                	addi	sp,sp,-16
    802006c2:	e422                	sd	s0,8(sp)
    802006c4:	0800                	addi	s0,sp,16
    char *d=dst; const char *s=src;
    if (d < s) { while(n--) *d++ = *s++; }
    802006c6:	02b57063          	bgeu	a0,a1,802006e6 <memmove+0x26>
    802006ca:	ca19                	beqz	a2,802006e0 <memmove+0x20>
    802006cc:	962a                	add	a2,a2,a0
    char *d=dst; const char *s=src;
    802006ce:	87aa                	mv	a5,a0
    if (d < s) { while(n--) *d++ = *s++; }
    802006d0:	0585                	addi	a1,a1,1
    802006d2:	0785                	addi	a5,a5,1
    802006d4:	fff5c703          	lbu	a4,-1(a1)
    802006d8:	fee78fa3          	sb	a4,-1(a5)
    802006dc:	fef61ae3          	bne	a2,a5,802006d0 <memmove+0x10>
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    return dst;
}
    802006e0:	6422                	ld	s0,8(sp)
    802006e2:	0141                	addi	sp,sp,16
    802006e4:	8082                	ret
    else { d+=n; s+=n; while(n--) *--d = *--s; }
    802006e6:	00c507b3          	add	a5,a0,a2
    802006ea:	95b2                	add	a1,a1,a2
    802006ec:	da75                	beqz	a2,802006e0 <memmove+0x20>
    802006ee:	15fd                	addi	a1,a1,-1
    802006f0:	17fd                	addi	a5,a5,-1
    802006f2:	0005c703          	lbu	a4,0(a1)
    802006f6:	00e78023          	sb	a4,0(a5)
    802006fa:	fef51ae3          	bne	a0,a5,802006ee <memmove+0x2e>
    802006fe:	b7cd                	j	802006e0 <memmove+0x20>

0000000080200700 <memcmp>:
int memcmp(const void *a, const void *b, usize n){
    80200700:	1141                	addi	sp,sp,-16
    80200702:	e422                	sd	s0,8(sp)
    80200704:	0800                	addi	s0,sp,16
    const uint8 *x=a,*y=b;
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    80200706:	c21d                	beqz	a2,8020072c <memcmp+0x2c>
    80200708:	962a                	add	a2,a2,a0
    8020070a:	00054783          	lbu	a5,0(a0)
    8020070e:	0005c703          	lbu	a4,0(a1)
    80200712:	00e79863          	bne	a5,a4,80200722 <memcmp+0x22>
    80200716:	0505                	addi	a0,a0,1
    80200718:	0585                	addi	a1,a1,1
    8020071a:	fea618e3          	bne	a2,a0,8020070a <memcmp+0xa>
    return 0;
    8020071e:	4501                	li	a0,0
    80200720:	a019                	j	80200726 <memcmp+0x26>
    while(n--){ if(*x != *y) return *x - *y; x++; y++; }
    80200722:	40e7853b          	subw	a0,a5,a4
}
    80200726:	6422                	ld	s0,8(sp)
    80200728:	0141                	addi	sp,sp,16
    8020072a:	8082                	ret
    return 0;
    8020072c:	4501                	li	a0,0
    8020072e:	bfe5                	j	80200726 <memcmp+0x26>

0000000080200730 <strncmp>:
int strncmp(const char *a, const char *b, usize n){
    80200730:	1141                	addi	sp,sp,-16
    80200732:	e422                	sd	s0,8(sp)
    80200734:	0800                	addi	s0,sp,16
    while(n > 0 && *a && *a == *b){ a++; b++; n--; }
    80200736:	ce11                	beqz	a2,80200752 <strncmp+0x22>
    80200738:	00054783          	lbu	a5,0(a0)
    8020073c:	cf89                	beqz	a5,80200756 <strncmp+0x26>
    8020073e:	0005c703          	lbu	a4,0(a1)
    80200742:	00f71a63          	bne	a4,a5,80200756 <strncmp+0x26>
    80200746:	0505                	addi	a0,a0,1
    80200748:	0585                	addi	a1,a1,1
    8020074a:	167d                	addi	a2,a2,-1
    8020074c:	f675                	bnez	a2,80200738 <strncmp+0x8>
    if(n == 0) return 0;
    8020074e:	4501                	li	a0,0
    80200750:	a801                	j	80200760 <strncmp+0x30>
    80200752:	4501                	li	a0,0
    80200754:	a031                	j	80200760 <strncmp+0x30>
    return (uint8)*a - (uint8)*b;
    80200756:	00054503          	lbu	a0,0(a0)
    8020075a:	0005c783          	lbu	a5,0(a1)
    8020075e:	9d1d                	subw	a0,a0,a5
}
    80200760:	6422                	ld	s0,8(sp)
    80200762:	0141                	addi	sp,sp,16
    80200764:	8082                	ret

0000000080200766 <strncpy>:
char *strncpy(char *d, const char *s, int n){
    80200766:	1141                	addi	sp,sp,-16
    80200768:	e422                	sd	s0,8(sp)
    8020076a:	0800                	addi	s0,sp,16
    char *r=d;
    while(n-- > 0 && (*d++ = *s++) != 0) ;
    8020076c:	87aa                	mv	a5,a0
    8020076e:	86b2                	mv	a3,a2
    80200770:	367d                	addiw	a2,a2,-1
    80200772:	02d05563          	blez	a3,8020079c <strncpy+0x36>
    80200776:	0785                	addi	a5,a5,1
    80200778:	0005c703          	lbu	a4,0(a1)
    8020077c:	fee78fa3          	sb	a4,-1(a5)
    80200780:	0585                	addi	a1,a1,1
    80200782:	f775                	bnez	a4,8020076e <strncpy+0x8>
    while(n-- > 0) *d++ = 0;
    80200784:	873e                	mv	a4,a5
    80200786:	9fb5                	addw	a5,a5,a3
    80200788:	37fd                	addiw	a5,a5,-1
    8020078a:	00c05963          	blez	a2,8020079c <strncpy+0x36>
    8020078e:	0705                	addi	a4,a4,1
    80200790:	fe070fa3          	sb	zero,-1(a4)
    80200794:	40e786bb          	subw	a3,a5,a4
    80200798:	fed04be3          	bgtz	a3,8020078e <strncpy+0x28>
    return r;
}
    8020079c:	6422                	ld	s0,8(sp)
    8020079e:	0141                	addi	sp,sp,16
    802007a0:	8082                	ret

00000000802007a2 <strlen>:
int strlen(const char *s){ int n=0; while(s[n]) n++; return n; }
    802007a2:	1141                	addi	sp,sp,-16
    802007a4:	e422                	sd	s0,8(sp)
    802007a6:	0800                	addi	s0,sp,16
    802007a8:	00054783          	lbu	a5,0(a0)
    802007ac:	cf91                	beqz	a5,802007c8 <strlen+0x26>
    802007ae:	0505                	addi	a0,a0,1
    802007b0:	87aa                	mv	a5,a0
    802007b2:	86be                	mv	a3,a5
    802007b4:	0785                	addi	a5,a5,1
    802007b6:	fff7c703          	lbu	a4,-1(a5)
    802007ba:	ff65                	bnez	a4,802007b2 <strlen+0x10>
    802007bc:	40a6853b          	subw	a0,a3,a0
    802007c0:	2505                	addiw	a0,a0,1
    802007c2:	6422                	ld	s0,8(sp)
    802007c4:	0141                	addi	sp,sp,16
    802007c6:	8082                	ret
    802007c8:	4501                	li	a0,0
    802007ca:	bfe5                	j	802007c2 <strlen+0x20>

00000000802007cc <sbi_putchar>:
 * NOTE: the LEGACY console extension (EID 0x01) is deprecated and is disabled
 * in recent OpenSBI. Use DBCN (Debug Console, EID 0x4442434E) and fall back to
 * legacy only if DBCN is unavailable. Students hit this: an early sbi_putchar
 * that silently does nothing makes a boot panic invisible. */
void sbi_putchar(int c)
{
    802007cc:	1141                	addi	sp,sp,-16
    802007ce:	e422                	sd	s0,8(sp)
    802007d0:	0800                	addi	s0,sp,16
    802007d2:	87aa                	mv	a5,a0
    unsigned char ch = (unsigned char)c;
    /* DBCN console_write_byte = EID 0x4442434E, FID 2 */
    struct sbiret r = sbi_call(0x4442434E, 2, ch, 0, 0);
    802007d4:	0ff57513          	zext.b	a0,a0
    register long r_a1 asm("a1") = a1;
    802007d8:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    802007da:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    802007dc:	4809                	li	a6,2
    register long r_a7 asm("a7") = eid;
    802007de:	444248b7          	lui	a7,0x44424
    802007e2:	34e88893          	addi	a7,a7,846 # 4442434e <_entry-0x3bddbcb2>
    asm volatile ("ecall"
    802007e6:	00000073          	ecall
    if (r.error != 0)
    802007ea:	e501                	bnez	a0,802007f2 <sbi_putchar+0x26>
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
}
    802007ec:	6422                	ld	s0,8(sp)
    802007ee:	0141                	addi	sp,sp,16
    802007f0:	8082                	ret
        sbi_call(0x01, 0, c, 0, 0);        /* legacy putchar */
    802007f2:	853e                	mv	a0,a5
    register long r_a1 asm("a1") = a1;
    802007f4:	4581                	li	a1,0
    register long r_a6 asm("a6") = fid;
    802007f6:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    802007f8:	4885                	li	a7,1
    asm volatile ("ecall"
    802007fa:	00000073          	ecall
}
    802007fe:	b7fd                	j	802007ec <sbi_putchar+0x20>

0000000080200800 <sbi_set_timer>:

/* TIME extension: set the next timer interrupt (absolute time). */
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    80200800:	1141                	addi	sp,sp,-16
    80200802:	e422                	sd	s0,8(sp)
    80200804:	0800                	addi	s0,sp,16
    register long r_a1 asm("a1") = a1;
    80200806:	4581                	li	a1,0
    register long r_a2 asm("a2") = a2;
    80200808:	4601                	li	a2,0
    register long r_a6 asm("a6") = fid;
    8020080a:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    8020080c:	544958b7          	lui	a7,0x54495
    80200810:	d4588893          	addi	a7,a7,-699 # 54494d45 <_entry-0x2bd6b2bb>
    asm volatile ("ecall"
    80200814:	00000073          	ecall
void sbi_set_timer(uint64 stime) { sbi_call(0x54494D45, 0, stime, 0, 0); }
    80200818:	6422                	ld	s0,8(sp)
    8020081a:	0141                	addi	sp,sp,16
    8020081c:	8082                	ret

000000008020081e <sbi_hart_start>:

/* HSM extension: start a secondary hart at `addr` (L9, SMP). */
long sbi_hart_start(uint64 hartid, uint64 addr, uint64 opaque)
{
    8020081e:	1141                	addi	sp,sp,-16
    80200820:	e422                	sd	s0,8(sp)
    80200822:	0800                	addi	s0,sp,16
    register long r_a6 asm("a6") = fid;
    80200824:	4801                	li	a6,0
    register long r_a7 asm("a7") = eid;
    80200826:	004858b7          	lui	a7,0x485
    8020082a:	34d88893          	addi	a7,a7,845 # 48534d <_entry-0x7fd7acb3>
    asm volatile ("ecall"
    8020082e:	00000073          	ecall
    return sbi_call(0x48534D, 0, hartid, addr, opaque).error;
}
    80200832:	6422                	ld	s0,8(sp)
    80200834:	0141                	addi	sp,sp,16
    80200836:	8082                	ret

0000000080200838 <be32>:
    uint32 off_mem_rsvmap, version, last_comp_version;
    uint32 boot_cpuid_phys, size_dt_strings, size_dt_struct;
};

/* The FDT is big-endian; RISC-V is little-endian. Swap on every read. */
static uint32 be32(uint32 x) {
    80200838:	1141                	addi	sp,sp,-16
    8020083a:	e422                	sd	s0,8(sp)
    8020083c:	0800                	addi	s0,sp,16
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    8020083e:	0185179b          	slliw	a5,a0,0x18
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    80200842:	0185571b          	srliw	a4,a0,0x18
    80200846:	8fd9                	or	a5,a5,a4
    return ((x & 0xFF) << 24) | ((x & 0xFF00) << 8) |
    80200848:	0085171b          	slliw	a4,a0,0x8
    8020084c:	00ff06b7          	lui	a3,0xff0
    80200850:	8f75                	and	a4,a4,a3
           ((x >> 8) & 0xFF00) | ((x >> 24) & 0xFF);
    80200852:	8fd9                	or	a5,a5,a4
    80200854:	0085551b          	srliw	a0,a0,0x8
    80200858:	6741                	lui	a4,0x10
    8020085a:	f0070713          	addi	a4,a4,-256 # ff00 <_entry-0x801f0100>
    8020085e:	8d79                	and	a0,a0,a4
    80200860:	8d5d                	or	a0,a0,a5
}
    80200862:	2501                	sext.w	a0,a0
    80200864:	6422                	ld	s0,8(sp)
    80200866:	0141                	addi	sp,sp,16
    80200868:	8082                	ret

000000008020086a <streq>:
#define MAXDEPTH 16

struct fdt_info fdt;                 /* what we discovered about this board */
static const char *strings;          /* strings block base */

static int streq(const char *a, const char *b) {
    8020086a:	1141                	addi	sp,sp,-16
    8020086c:	e422                	sd	s0,8(sp)
    8020086e:	0800                	addi	s0,sp,16
    while (*a && *a == *b) { a++; b++; }
    80200870:	00054783          	lbu	a5,0(a0)
    80200874:	cb91                	beqz	a5,80200888 <streq+0x1e>
    80200876:	0005c703          	lbu	a4,0(a1)
    8020087a:	00f71763          	bne	a4,a5,80200888 <streq+0x1e>
    8020087e:	0505                	addi	a0,a0,1
    80200880:	0585                	addi	a1,a1,1
    80200882:	00054783          	lbu	a5,0(a0)
    80200886:	fbe5                	bnez	a5,80200876 <streq+0xc>
    return *a == *b;
    80200888:	0005c503          	lbu	a0,0(a1)
    8020088c:	8d1d                	sub	a0,a0,a5
}
    8020088e:	00153513          	seqz	a0,a0
    80200892:	6422                	ld	s0,8(sp)
    80200894:	0141                	addi	sp,sp,16
    80200896:	8082                	ret

0000000080200898 <strlist_has>:
/* does `list` (a NUL-separated string list of length len) contain `want`? */
static int strlist_has(const char *list, int len, const char *want) {
    int i = 0;
    while (i < len) {
    80200898:	04b05f63          	blez	a1,802008f6 <strlist_has+0x5e>
static int strlist_has(const char *list, int len, const char *want) {
    8020089c:	7139                	addi	sp,sp,-64
    8020089e:	fc06                	sd	ra,56(sp)
    802008a0:	f822                	sd	s0,48(sp)
    802008a2:	f426                	sd	s1,40(sp)
    802008a4:	f04a                	sd	s2,32(sp)
    802008a6:	ec4e                	sd	s3,24(sp)
    802008a8:	e852                	sd	s4,16(sp)
    802008aa:	e456                	sd	s5,8(sp)
    802008ac:	0080                	addi	s0,sp,64
    802008ae:	8a2a                	mv	s4,a0
    802008b0:	89ae                	mv	s3,a1
    802008b2:	8ab2                	mv	s5,a2
    int i = 0;
    802008b4:	4481                	li	s1,0
    802008b6:	a021                	j	802008be <strlist_has+0x26>
        if (streq(&list[i], want)) return 1;
        while (i < len && list[i]) i++;
        i++;
    802008b8:	2485                	addiw	s1,s1,1
    while (i < len) {
    802008ba:	0334d563          	bge	s1,s3,802008e4 <strlist_has+0x4c>
        if (streq(&list[i], want)) return 1;
    802008be:	009a0933          	add	s2,s4,s1
    802008c2:	85d6                	mv	a1,s5
    802008c4:	854a                	mv	a0,s2
    802008c6:	00000097          	auipc	ra,0x0
    802008ca:	fa4080e7          	jalr	-92(ra) # 8020086a <streq>
    802008ce:	e515                	bnez	a0,802008fa <strlist_has+0x62>
        while (i < len && list[i]) i++;
    802008d0:	ff34d4e3          	bge	s1,s3,802008b8 <strlist_has+0x20>
    802008d4:	87ca                	mv	a5,s2
    802008d6:	0007c703          	lbu	a4,0(a5)
    802008da:	df79                	beqz	a4,802008b8 <strlist_has+0x20>
    802008dc:	2485                	addiw	s1,s1,1
    802008de:	0785                	addi	a5,a5,1
    802008e0:	fe999be3          	bne	s3,s1,802008d6 <strlist_has+0x3e>
    }
    return 0;
}
    802008e4:	70e2                	ld	ra,56(sp)
    802008e6:	7442                	ld	s0,48(sp)
    802008e8:	74a2                	ld	s1,40(sp)
    802008ea:	7902                	ld	s2,32(sp)
    802008ec:	69e2                	ld	s3,24(sp)
    802008ee:	6a42                	ld	s4,16(sp)
    802008f0:	6aa2                	ld	s5,8(sp)
    802008f2:	6121                	addi	sp,sp,64
    802008f4:	8082                	ret
    return 0;
    802008f6:	4501                	li	a0,0
}
    802008f8:	8082                	ret
        if (streq(&list[i], want)) return 1;
    802008fa:	4505                	li	a0,1
    802008fc:	b7e5                	j	802008e4 <strlist_has+0x4c>

00000000802008fe <fdt_init>:
 *
 * Also: a node's `reg` is decoded with its PARENT's #address-cells/#size-cells,
 * not its own. We keep a small stack of them.
 */
void fdt_init(uint64 fdt_pa)
{
    802008fe:	712d                	addi	sp,sp,-288
    80200900:	ee06                	sd	ra,280(sp)
    80200902:	ea22                	sd	s0,272(sp)
    80200904:	fdce                	sd	s3,248(sp)
    80200906:	1200                	addi	s0,sp,288
    80200908:	89aa                	mv	s3,a0
    struct fdt_header *h = (struct fdt_header *)fdt_pa;

    if (be32(h->magic) != FDT_MAGIC)
    8020090a:	4108                	lw	a0,0(a0)
    8020090c:	00000097          	auipc	ra,0x0
    80200910:	f2c080e7          	jalr	-212(ra) # 80200838 <be32>
    80200914:	2501                	sext.w	a0,a0
    80200916:	d00e07b7          	lui	a5,0xd00e0
    8020091a:	eed78793          	addi	a5,a5,-275 # ffffffffd00dfeed <uart+0xffffffff4fda0ebd>
    8020091e:	0cf51263          	bne	a0,a5,802009e2 <fdt_init+0xe4>
    80200922:	e626                	sd	s1,264(sp)
    80200924:	e24a                	sd	s2,256(sp)
    80200926:	f9d2                	sd	s4,240(sp)
    80200928:	f5d6                	sd	s5,232(sp)
    8020092a:	f1da                	sd	s6,224(sp)
    8020092c:	edde                	sd	s7,216(sp)
    8020092e:	e9e2                	sd	s8,208(sp)
    80200930:	e1ea                	sd	s10,192(sp)
        panic("fdt: bad magic - is a1 really the device tree?");

    strings = (const char *)(fdt_pa + be32(h->off_dt_strings));
    80200932:	00c9a503          	lw	a0,12(s3)
    80200936:	00000097          	auipc	ra,0x0
    8020093a:	f02080e7          	jalr	-254(ra) # 80200838 <be32>
    8020093e:	02051b13          	slli	s6,a0,0x20
    80200942:	020b5b13          	srli	s6,s6,0x20
    80200946:	9b4e                	add	s6,s6,s3
    const uint32 *p = (const uint32 *)(fdt_pa + be32(h->off_dt_struct));
    80200948:	0089a503          	lw	a0,8(s3)
    8020094c:	00000097          	auipc	ra,0x0
    80200950:	eec080e7          	jalr	-276(ra) # 80200838 <be32>
    80200954:	02051493          	slli	s1,a0,0x20
    80200958:	9081                	srli	s1,s1,0x20
    8020095a:	94ce                	add	s1,s1,s3

    fdt.blob = fdt_pa;
    8020095c:	00028917          	auipc	s2,0x28
    80200960:	6bc90913          	addi	s2,s2,1724 # 80229018 <fdt>
    80200964:	01393023          	sd	s3,0(s2)
    fdt.blob_size = be32(h->totalsize);
    80200968:	0049a503          	lw	a0,4(s3)
    8020096c:	00000097          	auipc	ra,0x0
    80200970:	ecc080e7          	jalr	-308(ra) # 80200838 <be32>
    80200974:	1502                	slli	a0,a0,0x20
    80200976:	9101                	srli	a0,a0,0x20
    80200978:	00a93423          	sd	a0,8(s2)
    fdt.ncpu = 0;
    8020097c:	0a092023          	sw	zero,160(s2)
    fdt.uart_base = 0; fdt.plic_base = 0; fdt.uart_irq = 0;
    80200980:	00093823          	sd	zero,16(s2)
    80200984:	00093c23          	sd	zero,24(s2)
    80200988:	02092023          	sw	zero,32(s2)
    fdt.nvirtio = 0;
    8020098c:	08092423          	sw	zero,136(s2)
    fdt.mem_base = 0;  fdt.mem_size = 0;
    80200990:	08093823          	sd	zero,144(s2)
    80200994:	08093c23          	sd	zero,152(s2)

    /* #address-cells / #size-cells, one slot per depth. Defaults per spec. */
    int ac[MAXDEPTH], sc[MAXDEPTH];
    ac[0] = 2; sc[0] = 2;
    80200998:	4789                	li	a5,2
    8020099a:	f4f42823          	sw	a5,-176(s0)
    8020099e:	f0f42823          	sw	a5,-240(s0)

    /* properties buffered for the node we are currently inside */
    int    kind = PEND_NONE;
    int    have_reg = 0;
    uint64 reg_base = 0, reg_size = 0;
    int    have_irq = 0, irq = 0;
    802009a2:	ee043423          	sd	zero,-280(s0)
    802009a6:	ee043823          	sd	zero,-272(s0)
    uint64 reg_base = 0, reg_size = 0;
    802009aa:	f0043023          	sd	zero,-256(s0)
    802009ae:	f0043423          	sd	zero,-248(s0)
    int    have_reg = 0;
    802009b2:	4d01                	li	s10,0
    int    kind = PEND_NONE;
    802009b4:	4c01                	li	s8,0
    int cpus_depth = -1;
    802009b6:	5bfd                	li	s7,-1
    int depth = 0;
    802009b8:	4981                	li	s3,0
    802009ba:	4aa5                	li	s5,9
    802009bc:	00007917          	auipc	s2,0x7
    802009c0:	40090913          	addi	s2,s2,1024 # 80207dbc <digits+0x14>

    for (;;) {
        uint32 tok = be32(*p++);
    802009c4:	00448a13          	addi	s4,s1,4
    802009c8:	4088                	lw	a0,0(s1)
    802009ca:	00000097          	auipc	ra,0x0
    802009ce:	e6e080e7          	jalr	-402(ra) # 80200838 <be32>
    802009d2:	2501                	sext.w	a0,a0

        if (tok == FDT_END) break;
    802009d4:	4eaaee63          	bltu	s5,a0,80200ed0 <fdt_init+0x5d2>
    802009d8:	050a                	slli	a0,a0,0x2
    802009da:	954a                	add	a0,a0,s2
    802009dc:	411c                	lw	a5,0(a0)
    802009de:	97ca                	add	a5,a5,s2
    802009e0:	8782                	jr	a5
    802009e2:	e626                	sd	s1,264(sp)
    802009e4:	e24a                	sd	s2,256(sp)
    802009e6:	f9d2                	sd	s4,240(sp)
    802009e8:	f5d6                	sd	s5,232(sp)
    802009ea:	f1da                	sd	s6,224(sp)
    802009ec:	edde                	sd	s7,216(sp)
    802009ee:	e9e2                	sd	s8,208(sp)
    802009f0:	e5e6                	sd	s9,200(sp)
    802009f2:	e1ea                	sd	s10,192(sp)
    802009f4:	fd6e                	sd	s11,184(sp)
        panic("fdt: bad magic - is a1 really the device tree?");
    802009f6:	00007517          	auipc	a0,0x7
    802009fa:	83a50513          	addi	a0,a0,-1990 # 80207230 <etext+0x230>
    802009fe:	00000097          	auipc	ra,0x0
    80200a02:	c00080e7          	jalr	-1024(ra) # 802005fe <panic>
        uint32 tok = be32(*p++);
    80200a06:	84d2                	mv	s1,s4
    80200a08:	bf75                	j	802009c4 <fdt_init+0xc6>
        if (tok == FDT_BEGIN_NODE) {
            const char *name = (const char *)p;
            int len = 0; while (name[len]) len++;
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */

            depth++;
    80200a0a:	89e2                	mv	s3,s8
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
            sc[depth] = sc[depth - 1];

            /* start a fresh property buffer for this node */
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
            have_irq = 0; irq = 0;
    80200a0c:	ee043423          	sd	zero,-280(s0)
    80200a10:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200a14:	f0043023          	sd	zero,-256(s0)
    80200a18:	f0043423          	sd	zero,-248(s0)
    80200a1c:	4d01                	li	s10,0
    80200a1e:	4c01                	li	s8,0
    80200a20:	b755                	j	802009c4 <fdt_init+0xc6>
        if (tok == FDT_PROP) {
            uint32 len     = be32(*p++);
            uint32 nameoff = be32(*p++);
            const char *pname = &strings[nameoff];
            const uint32 *val = p;
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a22:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
                else if (strlist_has(c, len, "riscv,plic0") ||
                         strlist_has(c, len, "sifive,plic-1.0.0"))
                    kind = PEND_PLIC;
                else if (strlist_has(c, len, "virtio,mmio"))
                    kind = PEND_VIRTIO;
    80200a26:	4c0d                	li	s8,3
    80200a28:	6cae                	ld	s9,200(sp)
    80200a2a:	7dea                	ld	s11,184(sp)
    80200a2c:	bf61                	j	802009c4 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a2e:	ef843483          	ld	s1,-264(s0)
            } else if (streq(pname, "device_type")) {
                if (strlist_has((const char *)val, len, "memory"))
                    kind = PEND_MEM;
    80200a32:	4c11                	li	s8,4
    80200a34:	6cae                	ld	s9,200(sp)
    80200a36:	7dea                	ld	s11,184(sp)
    80200a38:	b771                	j	802009c4 <fdt_init+0xc6>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200a3a:	ef843483          	ld	s1,-264(s0)
    80200a3e:	6cae                	ld	s9,200(sp)
    80200a40:	7dea                	ld	s11,184(sp)
    80200a42:	b749                	j	802009c4 <fdt_init+0xc6>
    80200a44:	ef843483          	ld	s1,-264(s0)
    80200a48:	6cae                	ld	s9,200(sp)
    80200a4a:	7dea                	ld	s11,184(sp)
    80200a4c:	bfa5                	j	802009c4 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200a4e:	0044c783          	lbu	a5,4(s1)
    80200a52:	c7d9                	beqz	a5,80200ae0 <fdt_init+0x1e2>
    80200a54:	0495                	addi	s1,s1,5
    80200a56:	87a6                	mv	a5,s1
    80200a58:	86be                	mv	a3,a5
    80200a5a:	0785                	addi	a5,a5,1
    80200a5c:	fff7c703          	lbu	a4,-1(a5)
    80200a60:	ff65                	bnez	a4,80200a58 <fdt_init+0x15a>
    80200a62:	9e85                	subw	a3,a3,s1
    80200a64:	2685                	addiw	a3,a3,1 # ff0001 <_entry-0x7f20ffff>
            p += (len + 4) / 4;                 /* NUL-terminated, 4-byte padded */
    80200a66:	2691                	addiw	a3,a3,4
    80200a68:	41f6d49b          	sraiw	s1,a3,0x1f
    80200a6c:	01e4d49b          	srliw	s1,s1,0x1e
    80200a70:	9cb5                	addw	s1,s1,a3
    80200a72:	4024d49b          	sraiw	s1,s1,0x2
    80200a76:	048a                	slli	s1,s1,0x2
    80200a78:	94d2                	add	s1,s1,s4
            depth++;
    80200a7a:	00198c1b          	addiw	s8,s3,1
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200a7e:	47bd                	li	a5,15
    80200a80:	0787c263          	blt	a5,s8,80200ae4 <fdt_init+0x1e6>
            ac[depth] = ac[depth - 1];          /* inherit until told otherwise */
    80200a84:	00299713          	slli	a4,s3,0x2
    80200a88:	f9070793          	addi	a5,a4,-112
    80200a8c:	00878733          	add	a4,a5,s0
    80200a90:	fc072683          	lw	a3,-64(a4)
    80200a94:	002c1793          	slli	a5,s8,0x2
    80200a98:	f9078793          	addi	a5,a5,-112
    80200a9c:	97a2                	add	a5,a5,s0
    80200a9e:	fcd7a023          	sw	a3,-64(a5)
            sc[depth] = sc[depth - 1];
    80200aa2:	f8072703          	lw	a4,-128(a4)
    80200aa6:	f8e7a023          	sw	a4,-128(a5)
            if (streq(name, "cpus")) cpus_depth = depth;
    80200aaa:	00006597          	auipc	a1,0x6
    80200aae:	7ce58593          	addi	a1,a1,1998 # 80207278 <etext+0x278>
    80200ab2:	8552                	mv	a0,s4
    80200ab4:	00000097          	auipc	ra,0x0
    80200ab8:	db6080e7          	jalr	-586(ra) # 8020086a <streq>
    80200abc:	c111                	beqz	a0,80200ac0 <fdt_init+0x1c2>
    80200abe:	8be2                	mv	s7,s8
            if (cpus_depth > 0 && depth == cpus_depth + 1 && startswith(name, "cpu@"))
    80200ac0:	f57055e3          	blez	s7,80200a0a <fdt_init+0x10c>
    80200ac4:	03798a63          	beq	s3,s7,80200af8 <fdt_init+0x1fa>
            depth++;
    80200ac8:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200aca:	ee043423          	sd	zero,-280(s0)
    80200ace:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200ad2:	f0043023          	sd	zero,-256(s0)
    80200ad6:	f0043423          	sd	zero,-248(s0)
    80200ada:	4d01                	li	s10,0
    80200adc:	4c01                	li	s8,0
    80200ade:	b5dd                	j	802009c4 <fdt_init+0xc6>
            int len = 0; while (name[len]) len++;
    80200ae0:	4681                	li	a3,0
    80200ae2:	b751                	j	80200a66 <fdt_init+0x168>
    80200ae4:	e5e6                	sd	s9,200(sp)
    80200ae6:	fd6e                	sd	s11,184(sp)
            if (depth >= MAXDEPTH) panic("fdt: tree too deep");
    80200ae8:	00006517          	auipc	a0,0x6
    80200aec:	77850513          	addi	a0,a0,1912 # 80207260 <etext+0x260>
    80200af0:	00000097          	auipc	ra,0x0
    80200af4:	b0e080e7          	jalr	-1266(ra) # 802005fe <panic>
    80200af8:	00006797          	auipc	a5,0x6
    80200afc:	73078793          	addi	a5,a5,1840 # 80207228 <etext+0x228>
    while (*pre) { if (*s++ != *pre++) return 0; }
    80200b00:	0007c703          	lbu	a4,0(a5)
    80200b04:	44070e63          	beqz	a4,80200f60 <fdt_init+0x662>
    80200b08:	0a05                	addi	s4,s4,1
    80200b0a:	0785                	addi	a5,a5,1
    80200b0c:	fffa4683          	lbu	a3,-1(s4)
    80200b10:	fee688e3          	beq	a3,a4,80200b00 <fdt_init+0x202>
            depth++;
    80200b14:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200b16:	ee043423          	sd	zero,-280(s0)
    80200b1a:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200b1e:	f0043023          	sd	zero,-256(s0)
    80200b22:	f0043423          	sd	zero,-248(s0)
    80200b26:	4d01                	li	s10,0
    80200b28:	4c01                	li	s8,0
    80200b2a:	bd69                	j	802009c4 <fdt_init+0xc6>
            if (have_reg && kind != PEND_NONE) {
    80200b2c:	040d0863          	beqz	s10,80200b7c <fdt_init+0x27e>
    80200b30:	040c0663          	beqz	s8,80200b7c <fdt_init+0x27e>
                switch (kind) {
    80200b34:	478d                	li	a5,3
    80200b36:	06fc0f63          	beq	s8,a5,80200bb4 <fdt_init+0x2b6>
    80200b3a:	0387c463          	blt	a5,s8,80200b62 <fdt_init+0x264>
    80200b3e:	4785                	li	a5,1
    80200b40:	04fc0563          	beq	s8,a5,80200b8a <fdt_init+0x28c>
    80200b44:	4789                	li	a5,2
    80200b46:	02fc1b63          	bne	s8,a5,80200b7c <fdt_init+0x27e>
                case PEND_PLIC:   if (!fdt.plic_base) fdt.plic_base = reg_base; break;
    80200b4a:	00028797          	auipc	a5,0x28
    80200b4e:	4e67b783          	ld	a5,1254(a5) # 80229030 <fdt+0x18>
    80200b52:	e78d                	bnez	a5,80200b7c <fdt_init+0x27e>
    80200b54:	f0843703          	ld	a4,-248(s0)
    80200b58:	00028797          	auipc	a5,0x28
    80200b5c:	4ce7bc23          	sd	a4,1240(a5) # 80229030 <fdt+0x18>
    80200b60:	a831                	j	80200b7c <fdt_init+0x27e>
                switch (kind) {
    80200b62:	4791                	li	a5,4
    80200b64:	00fc1c63          	bne	s8,a5,80200b7c <fdt_init+0x27e>
                case PEND_MEM:    fdt.mem_base = reg_base; fdt.mem_size = reg_size; break;
    80200b68:	00028797          	auipc	a5,0x28
    80200b6c:	4b078793          	addi	a5,a5,1200 # 80229018 <fdt>
    80200b70:	f0843703          	ld	a4,-248(s0)
    80200b74:	ebd8                	sd	a4,144(a5)
    80200b76:	f0043703          	ld	a4,-256(s0)
    80200b7a:	efd8                	sd	a4,152(a5)
            if (depth == cpus_depth) cpus_depth = -1;
    80200b7c:	09798163          	beq	s3,s7,80200bfe <fdt_init+0x300>
            depth--;
    80200b80:	39fd                	addiw	s3,s3,-1
        uint32 tok = be32(*p++);
    80200b82:	84d2                	mv	s1,s4
            kind = PEND_NONE; have_reg = 0;
    80200b84:	4d01                	li	s10,0
    80200b86:	4c01                	li	s8,0
            continue;
    80200b88:	bd35                	j	802009c4 <fdt_init+0xc6>
                    if (!fdt.uart_base) {
    80200b8a:	00028797          	auipc	a5,0x28
    80200b8e:	49e7b783          	ld	a5,1182(a5) # 80229028 <fdt+0x10>
    80200b92:	f7ed                	bnez	a5,80200b7c <fdt_init+0x27e>
                        fdt.uart_base = reg_base;
    80200b94:	f0843703          	ld	a4,-248(s0)
    80200b98:	00028797          	auipc	a5,0x28
    80200b9c:	48e7b823          	sd	a4,1168(a5) # 80229028 <fdt+0x10>
                        if (have_irq) fdt.uart_irq = irq;
    80200ba0:	ef043783          	ld	a5,-272(s0)
    80200ba4:	dfe1                	beqz	a5,80200b7c <fdt_init+0x27e>
    80200ba6:	ee843703          	ld	a4,-280(s0)
    80200baa:	00028797          	auipc	a5,0x28
    80200bae:	48e7a723          	sw	a4,1166(a5) # 80229038 <fdt+0x20>
    80200bb2:	b7e9                	j	80200b7c <fdt_init+0x27e>
                    if (fdt.nvirtio < FDT_MAX_VIRTIO) {
    80200bb4:	00028797          	auipc	a5,0x28
    80200bb8:	4ec7a783          	lw	a5,1260(a5) # 802290a0 <fdt+0x88>
    80200bbc:	471d                	li	a4,7
    80200bbe:	faf74fe3          	blt	a4,a5,80200b7c <fdt_init+0x27e>
                        fdt.virtio_base[fdt.nvirtio] = reg_base;
    80200bc2:	00478693          	addi	a3,a5,4
    80200bc6:	068e                	slli	a3,a3,0x3
    80200bc8:	00028717          	auipc	a4,0x28
    80200bcc:	45070713          	addi	a4,a4,1104 # 80229018 <fdt>
    80200bd0:	9736                	add	a4,a4,a3
    80200bd2:	f0843683          	ld	a3,-248(s0)
    80200bd6:	e714                	sd	a3,8(a4)
                        fdt.virtio_irq[fdt.nvirtio]  = have_irq ? irq : 0;
    80200bd8:	ef043703          	ld	a4,-272(s0)
    80200bdc:	863a                	mv	a2,a4
    80200bde:	c319                	beqz	a4,80200be4 <fdt_init+0x2e6>
    80200be0:	ee843603          	ld	a2,-280(s0)
    80200be4:	00028697          	auipc	a3,0x28
    80200be8:	43468693          	addi	a3,a3,1076 # 80229018 <fdt>
    80200bec:	01878713          	addi	a4,a5,24
    80200bf0:	070a                	slli	a4,a4,0x2
    80200bf2:	9736                	add	a4,a4,a3
    80200bf4:	c710                	sw	a2,8(a4)
                        fdt.nvirtio++;
    80200bf6:	2785                	addiw	a5,a5,1
    80200bf8:	08f6a423          	sw	a5,136(a3)
    80200bfc:	b741                	j	80200b7c <fdt_init+0x27e>
            if (depth == cpus_depth) cpus_depth = -1;
    80200bfe:	5bfd                	li	s7,-1
    80200c00:	b741                	j	80200b80 <fdt_init+0x282>
    80200c02:	e5e6                	sd	s9,200(sp)
    80200c04:	fd6e                	sd	s11,184(sp)
            uint32 len     = be32(*p++);
    80200c06:	40c8                	lw	a0,4(s1)
    80200c08:	00000097          	auipc	ra,0x0
    80200c0c:	c30080e7          	jalr	-976(ra) # 80200838 <be32>
    80200c10:	00050c9b          	sext.w	s9,a0
            uint32 nameoff = be32(*p++);
    80200c14:	00c48d93          	addi	s11,s1,12
    80200c18:	4488                	lw	a0,8(s1)
    80200c1a:	00000097          	auipc	ra,0x0
    80200c1e:	c1e080e7          	jalr	-994(ra) # 80200838 <be32>
            const char *pname = &strings[nameoff];
    80200c22:	02051a13          	slli	s4,a0,0x20
    80200c26:	020a5a13          	srli	s4,s4,0x20
    80200c2a:	9a5a                	add	s4,s4,s6
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c2c:	003c879b          	addiw	a5,s9,3
    80200c30:	0027d79b          	srliw	a5,a5,0x2
    80200c34:	078a                	slli	a5,a5,0x2
    80200c36:	97ee                	add	a5,a5,s11
    80200c38:	eef43c23          	sd	a5,-264(s0)
            if (streq(pname, "#address-cells")) {
    80200c3c:	00006597          	auipc	a1,0x6
    80200c40:	64458593          	addi	a1,a1,1604 # 80207280 <etext+0x280>
    80200c44:	8552                	mv	a0,s4
    80200c46:	00000097          	auipc	ra,0x0
    80200c4a:	c24080e7          	jalr	-988(ra) # 8020086a <streq>
    80200c4e:	c11d                	beqz	a0,80200c74 <fdt_init+0x376>
                ac[depth] = be32(val[0]);
    80200c50:	44c8                	lw	a0,12(s1)
    80200c52:	00000097          	auipc	ra,0x0
    80200c56:	be6080e7          	jalr	-1050(ra) # 80200838 <be32>
    80200c5a:	00299793          	slli	a5,s3,0x2
    80200c5e:	f9078713          	addi	a4,a5,-112
    80200c62:	008707b3          	add	a5,a4,s0
    80200c66:	fca7a023          	sw	a0,-64(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200c6a:	ef843483          	ld	s1,-264(s0)
    80200c6e:	6cae                	ld	s9,200(sp)
    80200c70:	7dea                	ld	s11,184(sp)
    80200c72:	bb89                	j	802009c4 <fdt_init+0xc6>
            } else if (streq(pname, "#size-cells")) {
    80200c74:	00006597          	auipc	a1,0x6
    80200c78:	61c58593          	addi	a1,a1,1564 # 80207290 <etext+0x290>
    80200c7c:	8552                	mv	a0,s4
    80200c7e:	00000097          	auipc	ra,0x0
    80200c82:	bec080e7          	jalr	-1044(ra) # 8020086a <streq>
    80200c86:	c115                	beqz	a0,80200caa <fdt_init+0x3ac>
                sc[depth] = be32(val[0]);
    80200c88:	44c8                	lw	a0,12(s1)
    80200c8a:	00000097          	auipc	ra,0x0
    80200c8e:	bae080e7          	jalr	-1106(ra) # 80200838 <be32>
    80200c92:	00299793          	slli	a5,s3,0x2
    80200c96:	f9078793          	addi	a5,a5,-112
    80200c9a:	97a2                	add	a5,a5,s0
    80200c9c:	f8a7a023          	sw	a0,-128(a5)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200ca0:	ef843483          	ld	s1,-264(s0)
    80200ca4:	6cae                	ld	s9,200(sp)
    80200ca6:	7dea                	ld	s11,184(sp)
    80200ca8:	bb31                	j	802009c4 <fdt_init+0xc6>
            } else if (streq(pname, "compatible")) {
    80200caa:	00006597          	auipc	a1,0x6
    80200cae:	5f658593          	addi	a1,a1,1526 # 802072a0 <etext+0x2a0>
    80200cb2:	8552                	mv	a0,s4
    80200cb4:	00000097          	auipc	ra,0x0
    80200cb8:	bb6080e7          	jalr	-1098(ra) # 8020086a <streq>
    80200cbc:	c55d                	beqz	a0,80200d6a <fdt_init+0x46c>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200cbe:	2c81                	sext.w	s9,s9
    80200cc0:	00006617          	auipc	a2,0x6
    80200cc4:	5f060613          	addi	a2,a2,1520 # 802072b0 <etext+0x2b0>
    80200cc8:	85e6                	mv	a1,s9
    80200cca:	856e                	mv	a0,s11
    80200ccc:	00000097          	auipc	ra,0x0
    80200cd0:	bcc080e7          	jalr	-1076(ra) # 80200898 <strlist_has>
    80200cd4:	c519                	beqz	a0,80200ce2 <fdt_init+0x3e4>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cd6:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cda:	4c05                	li	s8,1
    80200cdc:	6cae                	ld	s9,200(sp)
    80200cde:	7dea                	ld	s11,184(sp)
    80200ce0:	b1d5                	j	802009c4 <fdt_init+0xc6>
                if (strlist_has(c, len, "ns16550a") || strlist_has(c, len, "ns16550"))
    80200ce2:	00006617          	auipc	a2,0x6
    80200ce6:	5de60613          	addi	a2,a2,1502 # 802072c0 <etext+0x2c0>
    80200cea:	85e6                	mv	a1,s9
    80200cec:	856e                	mv	a0,s11
    80200cee:	00000097          	auipc	ra,0x0
    80200cf2:	baa080e7          	jalr	-1110(ra) # 80200898 <strlist_has>
    80200cf6:	c519                	beqz	a0,80200d04 <fdt_init+0x406>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200cf8:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_UART;
    80200cfc:	4c05                	li	s8,1
    80200cfe:	6cae                	ld	s9,200(sp)
    80200d00:	7dea                	ld	s11,184(sp)
    80200d02:	b1c9                	j	802009c4 <fdt_init+0xc6>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200d04:	00006617          	auipc	a2,0x6
    80200d08:	5c460613          	addi	a2,a2,1476 # 802072c8 <etext+0x2c8>
    80200d0c:	85e6                	mv	a1,s9
    80200d0e:	856e                	mv	a0,s11
    80200d10:	00000097          	auipc	ra,0x0
    80200d14:	b88080e7          	jalr	-1144(ra) # 80200898 <strlist_has>
    80200d18:	c519                	beqz	a0,80200d26 <fdt_init+0x428>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d1a:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d1e:	4c09                	li	s8,2
    80200d20:	6cae                	ld	s9,200(sp)
    80200d22:	7dea                	ld	s11,184(sp)
    80200d24:	b145                	j	802009c4 <fdt_init+0xc6>
                         strlist_has(c, len, "sifive,plic-1.0.0"))
    80200d26:	00006617          	auipc	a2,0x6
    80200d2a:	5b260613          	addi	a2,a2,1458 # 802072d8 <etext+0x2d8>
    80200d2e:	85e6                	mv	a1,s9
    80200d30:	856e                	mv	a0,s11
    80200d32:	00000097          	auipc	ra,0x0
    80200d36:	b66080e7          	jalr	-1178(ra) # 80200898 <strlist_has>
                else if (strlist_has(c, len, "riscv,plic0") ||
    80200d3a:	c519                	beqz	a0,80200d48 <fdt_init+0x44a>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d3c:	ef843483          	ld	s1,-264(s0)
                    kind = PEND_PLIC;
    80200d40:	4c09                	li	s8,2
    80200d42:	6cae                	ld	s9,200(sp)
    80200d44:	7dea                	ld	s11,184(sp)
    80200d46:	b9bd                	j	802009c4 <fdt_init+0xc6>
                else if (strlist_has(c, len, "virtio,mmio"))
    80200d48:	00006617          	auipc	a2,0x6
    80200d4c:	5a860613          	addi	a2,a2,1448 # 802072f0 <etext+0x2f0>
    80200d50:	85e6                	mv	a1,s9
    80200d52:	856e                	mv	a0,s11
    80200d54:	00000097          	auipc	ra,0x0
    80200d58:	b44080e7          	jalr	-1212(ra) # 80200898 <strlist_has>
    80200d5c:	cc0513e3          	bnez	a0,80200a22 <fdt_init+0x124>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d60:	ef843483          	ld	s1,-264(s0)
    80200d64:	6cae                	ld	s9,200(sp)
    80200d66:	7dea                	ld	s11,184(sp)
    80200d68:	b9b1                	j	802009c4 <fdt_init+0xc6>
            } else if (streq(pname, "device_type")) {
    80200d6a:	00006597          	auipc	a1,0x6
    80200d6e:	59658593          	addi	a1,a1,1430 # 80207300 <etext+0x300>
    80200d72:	8552                	mv	a0,s4
    80200d74:	00000097          	auipc	ra,0x0
    80200d78:	af6080e7          	jalr	-1290(ra) # 8020086a <streq>
    80200d7c:	c115                	beqz	a0,80200da0 <fdt_init+0x4a2>
                if (strlist_has((const char *)val, len, "memory"))
    80200d7e:	00006617          	auipc	a2,0x6
    80200d82:	59260613          	addi	a2,a2,1426 # 80207310 <etext+0x310>
    80200d86:	85e6                	mv	a1,s9
    80200d88:	856e                	mv	a0,s11
    80200d8a:	00000097          	auipc	ra,0x0
    80200d8e:	b0e080e7          	jalr	-1266(ra) # 80200898 <strlist_has>
    80200d92:	c8051ee3          	bnez	a0,80200a2e <fdt_init+0x130>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200d96:	ef843483          	ld	s1,-264(s0)
    80200d9a:	6cae                	ld	s9,200(sp)
    80200d9c:	7dea                	ld	s11,184(sp)
    80200d9e:	b11d                	j	802009c4 <fdt_init+0xc6>
            } else if (streq(pname, "interrupts")) {
    80200da0:	00006597          	auipc	a1,0x6
    80200da4:	57858593          	addi	a1,a1,1400 # 80207318 <etext+0x318>
    80200da8:	8552                	mv	a0,s4
    80200daa:	00000097          	auipc	ra,0x0
    80200dae:	ac0080e7          	jalr	-1344(ra) # 8020086a <streq>
    80200db2:	c50d                	beqz	a0,80200ddc <fdt_init+0x4de>
                /* First cell = PLIC source number (qemu virt uses plain
                 * one-cell specifiers for uart and virtio). */
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200db4:	478d                	li	a5,3
    80200db6:	c997f2e3          	bgeu	a5,s9,80200a3a <fdt_init+0x13c>
    80200dba:	44c8                	lw	a0,12(s1)
    80200dbc:	00000097          	auipc	ra,0x0
    80200dc0:	a7c080e7          	jalr	-1412(ra) # 80200838 <be32>
    80200dc4:	0005079b          	sext.w	a5,a0
    80200dc8:	eef43423          	sd	a5,-280(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200dcc:	ef843483          	ld	s1,-264(s0)
                if (len >= 4) { irq = be32(val[0]); have_irq = 1; }
    80200dd0:	4785                	li	a5,1
    80200dd2:	eef43823          	sd	a5,-272(s0)
    80200dd6:	6cae                	ld	s9,200(sp)
    80200dd8:	7dea                	ld	s11,184(sp)
    80200dda:	b6ed                	j	802009c4 <fdt_init+0xc6>
            } else if (streq(pname, "reg")) {
    80200ddc:	00006597          	auipc	a1,0x6
    80200de0:	54c58593          	addi	a1,a1,1356 # 80207328 <etext+0x328>
    80200de4:	8552                	mv	a0,s4
    80200de6:	00000097          	auipc	ra,0x0
    80200dea:	a84080e7          	jalr	-1404(ra) # 8020086a <streq>
    80200dee:	c4050be3          	beqz	a0,80200a44 <fdt_init+0x146>
                /* Decode with the PARENT's cell counts. */
                int pac = ac[depth - 1];
    80200df2:	fff9879b          	addiw	a5,s3,-1
    80200df6:	078a                	slli	a5,a5,0x2
    80200df8:	f9078793          	addi	a5,a5,-112
    80200dfc:	97a2                	add	a5,a5,s0
    80200dfe:	fc07aa03          	lw	s4,-64(a5)
                int psc = sc[depth - 1];
    80200e02:	f807ad03          	lw	s10,-128(a5)
                if (pac == 2)      reg_base = be64(val);
    80200e06:	4789                	li	a5,2
    80200e08:	02fa0563          	beq	s4,a5,80200e32 <fdt_init+0x534>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e0c:	4785                	li	a5,1
                else               reg_base = 0;
    80200e0e:	f0043423          	sd	zero,-248(s0)
                else if (pac == 1) reg_base = be32(val[0]);
    80200e12:	04fa0563          	beq	s4,a5,80200e5c <fdt_init+0x55e>

                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e16:	4789                	li	a5,2
    80200e18:	04fd0d63          	beq	s10,a5,80200e72 <fdt_init+0x574>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200e1c:	4785                	li	a5,1
    80200e1e:	08fd0763          	beq	s10,a5,80200eac <fdt_init+0x5ae>
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200e22:	ef843483          	ld	s1,-264(s0)
                else               reg_size = 0;
    80200e26:	f0043023          	sd	zero,-256(s0)
                have_reg = 1;
    80200e2a:	4d05                	li	s10,1
    80200e2c:	6cae                	ld	s9,200(sp)
    80200e2e:	7dea                	ld	s11,184(sp)
    80200e30:	be51                	j	802009c4 <fdt_init+0xc6>
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e32:	44c8                	lw	a0,12(s1)
    80200e34:	00000097          	auipc	ra,0x0
    80200e38:	a04080e7          	jalr	-1532(ra) # 80200838 <be32>
    80200e3c:	00050c9b          	sext.w	s9,a0
    80200e40:	4888                	lw	a0,16(s1)
    80200e42:	00000097          	auipc	ra,0x0
    80200e46:	9f6080e7          	jalr	-1546(ra) # 80200838 <be32>
    80200e4a:	1c82                	slli	s9,s9,0x20
    80200e4c:	02051793          	slli	a5,a0,0x20
    80200e50:	9381                	srli	a5,a5,0x20
    80200e52:	00fce7b3          	or	a5,s9,a5
    80200e56:	f0f43423          	sd	a5,-248(s0)
    80200e5a:	bf75                	j	80200e16 <fdt_init+0x518>
                else if (pac == 1) reg_base = be32(val[0]);
    80200e5c:	44c8                	lw	a0,12(s1)
    80200e5e:	00000097          	auipc	ra,0x0
    80200e62:	9da080e7          	jalr	-1574(ra) # 80200838 <be32>
    80200e66:	02051793          	slli	a5,a0,0x20
    80200e6a:	9381                	srli	a5,a5,0x20
    80200e6c:	f0f43423          	sd	a5,-248(s0)
    80200e70:	b75d                	j	80200e16 <fdt_init+0x518>
                if (psc == 2)      reg_size = be64(&val[pac]);
    80200e72:	002a1493          	slli	s1,s4,0x2
    80200e76:	94ee                	add	s1,s1,s11
    return ((uint64)be32(p[0]) << 32) | be32(p[1]);
    80200e78:	4088                	lw	a0,0(s1)
    80200e7a:	00000097          	auipc	ra,0x0
    80200e7e:	9be080e7          	jalr	-1602(ra) # 80200838 <be32>
    80200e82:	00050a1b          	sext.w	s4,a0
    80200e86:	40c8                	lw	a0,4(s1)
    80200e88:	00000097          	auipc	ra,0x0
    80200e8c:	9b0080e7          	jalr	-1616(ra) # 80200838 <be32>
    80200e90:	1a02                	slli	s4,s4,0x20
    80200e92:	02051793          	slli	a5,a0,0x20
    80200e96:	9381                	srli	a5,a5,0x20
    80200e98:	00fa67b3          	or	a5,s4,a5
    80200e9c:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200ea0:	ef843483          	ld	s1,-264(s0)
                have_reg = 1;
    80200ea4:	4d05                	li	s10,1
    80200ea6:	6cae                	ld	s9,200(sp)
    80200ea8:	7dea                	ld	s11,184(sp)
    80200eaa:	be29                	j	802009c4 <fdt_init+0xc6>
                else if (psc == 1) reg_size = be32(val[pac]);
    80200eac:	0a0a                	slli	s4,s4,0x2
    80200eae:	9dd2                	add	s11,s11,s4
    80200eb0:	000da503          	lw	a0,0(s11)
    80200eb4:	00000097          	auipc	ra,0x0
    80200eb8:	984080e7          	jalr	-1660(ra) # 80200838 <be32>
    80200ebc:	02051793          	slli	a5,a0,0x20
    80200ec0:	9381                	srli	a5,a5,0x20
    80200ec2:	f0f43023          	sd	a5,-256(s0)
            p += (len + 3) / 4;                 /* properties are 4-byte aligned */
    80200ec6:	ef843483          	ld	s1,-264(s0)
    80200eca:	6cae                	ld	s9,200(sp)
    80200ecc:	7dea                	ld	s11,184(sp)
    80200ece:	bcdd                	j	802009c4 <fdt_init+0xc6>
    80200ed0:	e5e6                	sd	s9,200(sp)
    80200ed2:	fd6e                	sd	s11,184(sp)
            }
            continue;
        }
        panic("fdt: unknown token in structure block");
    80200ed4:	00006517          	auipc	a0,0x6
    80200ed8:	45c50513          	addi	a0,a0,1116 # 80207330 <etext+0x330>
    80200edc:	fffff097          	auipc	ra,0xfffff
    80200ee0:	722080e7          	jalr	1826(ra) # 802005fe <panic>
    }

    if (fdt.ncpu == 0) fdt.ncpu = 1;
    80200ee4:	00028797          	auipc	a5,0x28
    80200ee8:	1d47a783          	lw	a5,468(a5) # 802290b8 <fdt+0xa0>
    80200eec:	ef8d                	bnez	a5,80200f26 <fdt_init+0x628>
    80200eee:	4785                	li	a5,1
    80200ef0:	00028717          	auipc	a4,0x28
    80200ef4:	1cf72423          	sw	a5,456(a4) # 802290b8 <fdt+0xa0>
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200ef8:	00028797          	auipc	a5,0x28
    80200efc:	1307b783          	ld	a5,304(a5) # 80229028 <fdt+0x10>
    80200f00:	cf85                	beqz	a5,80200f38 <fdt_init+0x63a>
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f02:	00028797          	auipc	a5,0x28
    80200f06:	1ae7b783          	ld	a5,430(a5) # 802290b0 <fdt+0x98>
    80200f0a:	c3a9                	beqz	a5,80200f4c <fdt_init+0x64e>
    80200f0c:	64b2                	ld	s1,264(sp)
    80200f0e:	6912                	ld	s2,256(sp)
    80200f10:	7a4e                	ld	s4,240(sp)
    80200f12:	7aae                	ld	s5,232(sp)
    80200f14:	7b0e                	ld	s6,224(sp)
    80200f16:	6bee                	ld	s7,216(sp)
    80200f18:	6c4e                	ld	s8,208(sp)
    80200f1a:	6d0e                	ld	s10,192(sp)
}
    80200f1c:	60f2                	ld	ra,280(sp)
    80200f1e:	6452                	ld	s0,272(sp)
    80200f20:	79ee                	ld	s3,248(sp)
    80200f22:	6115                	addi	sp,sp,288
    80200f24:	8082                	ret
    if (fdt.ncpu > NCPU) fdt.ncpu = NCPU;
    80200f26:	4721                	li	a4,8
    80200f28:	fcf758e3          	bge	a4,a5,80200ef8 <fdt_init+0x5fa>
    80200f2c:	47a1                	li	a5,8
    80200f2e:	00028717          	auipc	a4,0x28
    80200f32:	18f72523          	sw	a5,394(a4) # 802290b8 <fdt+0xa0>
    80200f36:	b7c9                	j	80200ef8 <fdt_init+0x5fa>
    80200f38:	e5e6                	sd	s9,200(sp)
    80200f3a:	fd6e                	sd	s11,184(sp)
    if (!fdt.uart_base) panic("fdt: no console found on this board");
    80200f3c:	00006517          	auipc	a0,0x6
    80200f40:	41c50513          	addi	a0,a0,1052 # 80207358 <etext+0x358>
    80200f44:	fffff097          	auipc	ra,0xfffff
    80200f48:	6ba080e7          	jalr	1722(ra) # 802005fe <panic>
    80200f4c:	e5e6                	sd	s9,200(sp)
    80200f4e:	fd6e                	sd	s11,184(sp)
    if (!fdt.mem_size)  panic("fdt: no memory node");
    80200f50:	00006517          	auipc	a0,0x6
    80200f54:	43050513          	addi	a0,a0,1072 # 80207380 <etext+0x380>
    80200f58:	fffff097          	auipc	ra,0xfffff
    80200f5c:	6a6080e7          	jalr	1702(ra) # 802005fe <panic>
                fdt.ncpu++;
    80200f60:	00028717          	auipc	a4,0x28
    80200f64:	0b870713          	addi	a4,a4,184 # 80229018 <fdt>
    80200f68:	0a072783          	lw	a5,160(a4)
    80200f6c:	2785                	addiw	a5,a5,1
    80200f6e:	0af72023          	sw	a5,160(a4)
            depth++;
    80200f72:	89e2                	mv	s3,s8
            have_irq = 0; irq = 0;
    80200f74:	ee043423          	sd	zero,-280(s0)
    80200f78:	ee043823          	sd	zero,-272(s0)
            kind = PEND_NONE; have_reg = 0; reg_base = 0; reg_size = 0;
    80200f7c:	f0043023          	sd	zero,-256(s0)
    80200f80:	f0043423          	sd	zero,-248(s0)
    80200f84:	4d01                	li	s10,0
    80200f86:	4c01                	li	s8,0
    80200f88:	bc35                	j	802009c4 <fdt_init+0xc6>

0000000080200f8a <palloc_init>:
} kmem;

#define PA2IDX(pa) (((uint64)(pa) - kmem.base) >> PGSHIFT)

void palloc_init(void)
{
    80200f8a:	715d                	addi	sp,sp,-80
    80200f8c:	e486                	sd	ra,72(sp)
    80200f8e:	e0a2                	sd	s0,64(sp)
    80200f90:	fc26                	sd	s1,56(sp)
    80200f92:	f84a                	sd	s2,48(sp)
    80200f94:	f44e                	sd	s3,40(sp)
    80200f96:	f052                	sd	s4,32(sp)
    80200f98:	ec56                	sd	s5,24(sp)
    80200f9a:	e85a                	sd	s6,16(sp)
    80200f9c:	e45e                	sd	s7,8(sp)
    80200f9e:	e062                	sd	s8,0(sp)
    80200fa0:	0880                	addi	s0,sp,80
    initlock(&kmem.lock, "kmem");
    80200fa2:	00028b97          	auipc	s7,0x28
    80200fa6:	11eb8b93          	addi	s7,s7,286 # 802290c0 <kmem>
    80200faa:	00006597          	auipc	a1,0x6
    80200fae:	3ee58593          	addi	a1,a1,1006 # 80207398 <etext+0x398>
    80200fb2:	855e                	mv	a0,s7
    80200fb4:	00000097          	auipc	ra,0x0
    80200fb8:	304080e7          	jalr	772(ra) # 802012b8 <initlock>

    uint64 mem_start = fdt.mem_base;
    80200fbc:	00028717          	auipc	a4,0x28
    80200fc0:	05c70713          	addi	a4,a4,92 # 80229018 <fdt>
    80200fc4:	09073a83          	ld	s5,144(a4)
    uint64 mem_end   = fdt.mem_base + fdt.mem_size;
    80200fc8:	09873a03          	ld	s4,152(a4)
    80200fcc:	9a56                	add	s4,s4,s5
     * TOP of RAM (on qemu virt, ~0x87e00000). If you "reserve" it by pushing
     * free_start past it, you throw away almost all your memory and end up with
     * a kernel that has 1 MiB and cannot say why. Do NOT skip PAST the blob -
     * skip OVER its pages, and keep everything else.
     */
    uint64 free_start = PGROUNDUP((uint64)kernel_end);
    80200fce:	6c05                	lui	s8,0x1
    80200fd0:	fffc0693          	addi	a3,s8,-1 # fff <_entry-0x801ff001>
    80200fd4:	77fd                	lui	a5,0xfffff
    80200fd6:	0013f617          	auipc	a2,0x13f
    80200fda:	02960613          	addi	a2,a2,41 # 8033ffff <uart+0xfcf>
    80200fde:	00f674b3          	and	s1,a2,a5
    uint64 fdt_lo = PGROUNDDOWN(fdt.blob);
    80200fe2:	00073903          	ld	s2,0(a4)
    80200fe6:	00f979b3          	and	s3,s2,a5
    uint64 fdt_hi = PGROUNDUP(fdt.blob + fdt.blob_size);
    80200fea:	6718                	ld	a4,8(a4)
    80200fec:	993a                	add	s2,s2,a4
    80200fee:	9936                	add	s2,s2,a3
    80200ff0:	00f97933          	and	s2,s2,a5

    uint64 npages = (mem_end - free_start) >> PGSHIFT;
    80200ff4:	409a0b33          	sub	s6,s4,s1
    80200ff8:	00cb5b13          	srli	s6,s6,0xc

    /* One refcount byte per page (L11, copy-on-write). Carve it out of the
     * front of free memory - which is below the FDT, so this is safe. */
    uint64 refbytes = PGROUNDUP(npages);
    80200ffc:	9b36                	add	s6,s6,a3
    80200ffe:	00fb7b33          	and	s6,s6,a5
    kmem.refcnt = (uint8 *)free_start;
    80201002:	029bbc23          	sd	s1,56(s7)
    memset(kmem.refcnt, 0, refbytes);
    80201006:	865a                	mv	a2,s6
    80201008:	4581                	li	a1,0
    8020100a:	8526                	mv	a0,s1
    8020100c:	fffff097          	auipc	ra,0xfffff
    80201010:	698080e7          	jalr	1688(ra) # 802006a4 <memset>
    free_start += refbytes;
    80201014:	01648633          	add	a2,s1,s6

    kmem.base = free_start;
    80201018:	02cbb023          	sd	a2,32(s7)
    kmem.top  = mem_end;
    8020101c:	034bb423          	sd	s4,40(s7)
    kmem.freelist = 0;
    80201020:	000bbc23          	sd	zero,24(s7)
    kmem.nfree = 0;
    80201024:	020ba823          	sw	zero,48(s7)

    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201028:	9c32                	add	s8,s8,a2
    8020102a:	058a6063          	bltu	s4,s8,8020106a <palloc_init+0xe0>
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
            continue;                       /* never hand this page out    */
        struct run *r = (struct run *)p;
        kmem.refcnt[PA2IDX(p)] = 0;
    8020102e:	87de                	mv	a5,s7
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201030:	6505                	lui	a0,0x1
    80201032:	6589                	lui	a1,0x2
    80201034:	a035                	j	80201060 <palloc_init+0xd6>
        kmem.refcnt[PA2IDX(p)] = 0;
    80201036:	7398                	ld	a4,32(a5)
    80201038:	40e60733          	sub	a4,a2,a4
    8020103c:	8331                	srli	a4,a4,0xc
    8020103e:	7f94                	ld	a3,56(a5)
    80201040:	9736                	add	a4,a4,a3
    80201042:	00070023          	sb	zero,0(a4)
        r->next = kmem.freelist;
    80201046:	6f98                	ld	a4,24(a5)
    80201048:	e218                	sd	a4,0(a2)
        kmem.freelist = r;
    8020104a:	ef90                	sd	a2,24(a5)
        kmem.nfree++;
    8020104c:	5b98                	lw	a4,48(a5)
    8020104e:	2705                	addiw	a4,a4,1
    80201050:	db98                	sw	a4,48(a5)
    for (uint64 p = kmem.base; p + PGSIZE <= kmem.top; p += PGSIZE) {
    80201052:	00a606b3          	add	a3,a2,a0
    80201056:	962e                	add	a2,a2,a1
    80201058:	7798                	ld	a4,40(a5)
    8020105a:	00c76863          	bltu	a4,a2,8020106a <palloc_init+0xe0>
    8020105e:	8636                	mv	a2,a3
        if (p >= fdt_lo && p < fdt_hi)      /* the device tree lives here */
    80201060:	fd366be3          	bltu	a2,s3,80201036 <palloc_init+0xac>
    80201064:	fd2679e3          	bgeu	a2,s2,80201036 <palloc_init+0xac>
    80201068:	b7ed                	j	80201052 <palloc_init+0xc8>
    }
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    8020106a:	00028697          	auipc	a3,0x28
    8020106e:	0866a683          	lw	a3,134(a3) # 802290f0 <kmem+0x30>
           mem_start, mem_end, kmem.nfree, (kmem.nfree * PGSIZE) >> 20);
    80201072:	00c6971b          	slliw	a4,a3,0xc
    printf("palloc: RAM %p..%p, managing %d free pages (%d MiB)\n",
    80201076:	4147571b          	sraiw	a4,a4,0x14
    8020107a:	8652                	mv	a2,s4
    8020107c:	85d6                	mv	a1,s5
    8020107e:	00006517          	auipc	a0,0x6
    80201082:	32250513          	addi	a0,a0,802 # 802073a0 <etext+0x3a0>
    80201086:	fffff097          	auipc	ra,0xfffff
    8020108a:	306080e7          	jalr	774(ra) # 8020038c <printf>
}
    8020108e:	60a6                	ld	ra,72(sp)
    80201090:	6406                	ld	s0,64(sp)
    80201092:	74e2                	ld	s1,56(sp)
    80201094:	7942                	ld	s2,48(sp)
    80201096:	79a2                	ld	s3,40(sp)
    80201098:	7a02                	ld	s4,32(sp)
    8020109a:	6ae2                	ld	s5,24(sp)
    8020109c:	6b42                	ld	s6,16(sp)
    8020109e:	6ba2                	ld	s7,8(sp)
    802010a0:	6c02                	ld	s8,0(sp)
    802010a2:	6161                	addi	sp,sp,80
    802010a4:	8082                	ret

00000000802010a6 <palloc>:

void *palloc(void)
{
    802010a6:	1101                	addi	sp,sp,-32
    802010a8:	ec06                	sd	ra,24(sp)
    802010aa:	e822                	sd	s0,16(sp)
    802010ac:	e426                	sd	s1,8(sp)
    802010ae:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    802010b0:	00028497          	auipc	s1,0x28
    802010b4:	01048493          	addi	s1,s1,16 # 802290c0 <kmem>
    802010b8:	8526                	mv	a0,s1
    802010ba:	00000097          	auipc	ra,0x0
    802010be:	27a080e7          	jalr	634(ra) # 80201334 <acquire>
    struct run *r = kmem.freelist;
    802010c2:	6c84                	ld	s1,24(s1)
    if (r) {
    802010c4:	c4a1                	beqz	s1,8020110c <palloc+0x66>
        kmem.freelist = r->next;
    802010c6:	609c                	ld	a5,0(s1)
    802010c8:	00028517          	auipc	a0,0x28
    802010cc:	ff850513          	addi	a0,a0,-8 # 802290c0 <kmem>
    802010d0:	ed1c                	sd	a5,24(a0)
        kmem.nfree--;
    802010d2:	591c                	lw	a5,48(a0)
    802010d4:	37fd                	addiw	a5,a5,-1 # ffffffffffffefff <uart+0xffffffff7fcbffcf>
    802010d6:	d91c                	sw	a5,48(a0)
        kmem.refcnt[PA2IDX(r)] = 1;
    802010d8:	711c                	ld	a5,32(a0)
    802010da:	40f487b3          	sub	a5,s1,a5
    802010de:	83b1                	srli	a5,a5,0xc
    802010e0:	7d18                	ld	a4,56(a0)
    802010e2:	97ba                	add	a5,a5,a4
    802010e4:	4705                	li	a4,1
    802010e6:	00e78023          	sb	a4,0(a5)
    }
    release(&kmem.lock);
    802010ea:	00000097          	auipc	ra,0x0
    802010ee:	2fe080e7          	jalr	766(ra) # 802013e8 <release>

    if (r)
        memset((void *)r, 5, PGSIZE);   /* poison: catch use-before-init */
    802010f2:	6605                	lui	a2,0x1
    802010f4:	4595                	li	a1,5
    802010f6:	8526                	mv	a0,s1
    802010f8:	fffff097          	auipc	ra,0xfffff
    802010fc:	5ac080e7          	jalr	1452(ra) # 802006a4 <memset>
    return (void *)r;
}
    80201100:	8526                	mv	a0,s1
    80201102:	60e2                	ld	ra,24(sp)
    80201104:	6442                	ld	s0,16(sp)
    80201106:	64a2                	ld	s1,8(sp)
    80201108:	6105                	addi	sp,sp,32
    8020110a:	8082                	ret
    release(&kmem.lock);
    8020110c:	00028517          	auipc	a0,0x28
    80201110:	fb450513          	addi	a0,a0,-76 # 802290c0 <kmem>
    80201114:	00000097          	auipc	ra,0x0
    80201118:	2d4080e7          	jalr	724(ra) # 802013e8 <release>
    if (r)
    8020111c:	b7d5                	j	80201100 <palloc+0x5a>

000000008020111e <palloc_ref_inc>:

void palloc_ref_inc(void *pa)
{
    8020111e:	1101                	addi	sp,sp,-32
    80201120:	ec06                	sd	ra,24(sp)
    80201122:	e822                	sd	s0,16(sp)
    80201124:	e426                	sd	s1,8(sp)
    80201126:	e04a                	sd	s2,0(sp)
    80201128:	1000                	addi	s0,sp,32
    8020112a:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    8020112c:	00028917          	auipc	s2,0x28
    80201130:	f9490913          	addi	s2,s2,-108 # 802290c0 <kmem>
    80201134:	854a                	mv	a0,s2
    80201136:	00000097          	auipc	ra,0x0
    8020113a:	1fe080e7          	jalr	510(ra) # 80201334 <acquire>
    kmem.refcnt[PA2IDX(pa)]++;
    8020113e:	02093783          	ld	a5,32(s2)
    80201142:	8c9d                	sub	s1,s1,a5
    80201144:	80b1                	srli	s1,s1,0xc
    80201146:	03893783          	ld	a5,56(s2)
    8020114a:	97a6                	add	a5,a5,s1
    8020114c:	0007c703          	lbu	a4,0(a5)
    80201150:	2705                	addiw	a4,a4,1
    80201152:	00e78023          	sb	a4,0(a5)
    release(&kmem.lock);
    80201156:	854a                	mv	a0,s2
    80201158:	00000097          	auipc	ra,0x0
    8020115c:	290080e7          	jalr	656(ra) # 802013e8 <release>
}
    80201160:	60e2                	ld	ra,24(sp)
    80201162:	6442                	ld	s0,16(sp)
    80201164:	64a2                	ld	s1,8(sp)
    80201166:	6902                	ld	s2,0(sp)
    80201168:	6105                	addi	sp,sp,32
    8020116a:	8082                	ret

000000008020116c <palloc_ref_get>:

int palloc_ref_get(void *pa)
{
    8020116c:	1101                	addi	sp,sp,-32
    8020116e:	ec06                	sd	ra,24(sp)
    80201170:	e822                	sd	s0,16(sp)
    80201172:	e426                	sd	s1,8(sp)
    80201174:	e04a                	sd	s2,0(sp)
    80201176:	1000                	addi	s0,sp,32
    80201178:	84aa                	mv	s1,a0
    acquire(&kmem.lock);
    8020117a:	00028917          	auipc	s2,0x28
    8020117e:	f4690913          	addi	s2,s2,-186 # 802290c0 <kmem>
    80201182:	854a                	mv	a0,s2
    80201184:	00000097          	auipc	ra,0x0
    80201188:	1b0080e7          	jalr	432(ra) # 80201334 <acquire>
    int n = kmem.refcnt[PA2IDX(pa)];
    8020118c:	02093783          	ld	a5,32(s2)
    80201190:	8c9d                	sub	s1,s1,a5
    80201192:	80b1                	srli	s1,s1,0xc
    80201194:	03893783          	ld	a5,56(s2)
    80201198:	97a6                	add	a5,a5,s1
    8020119a:	0007c483          	lbu	s1,0(a5)
    release(&kmem.lock);
    8020119e:	854a                	mv	a0,s2
    802011a0:	00000097          	auipc	ra,0x0
    802011a4:	248080e7          	jalr	584(ra) # 802013e8 <release>
    return n;
}
    802011a8:	8526                	mv	a0,s1
    802011aa:	60e2                	ld	ra,24(sp)
    802011ac:	6442                	ld	s0,16(sp)
    802011ae:	64a2                	ld	s1,8(sp)
    802011b0:	6902                	ld	s2,0(sp)
    802011b2:	6105                	addi	sp,sp,32
    802011b4:	8082                	ret

00000000802011b6 <pfree>:

void pfree(void *pa)
{
    802011b6:	1101                	addi	sp,sp,-32
    802011b8:	ec06                	sd	ra,24(sp)
    802011ba:	e822                	sd	s0,16(sp)
    802011bc:	e426                	sd	s1,8(sp)
    802011be:	e04a                	sd	s2,0(sp)
    802011c0:	1000                	addi	s0,sp,32
    if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < kmem.base || (uint64)pa >= kmem.top)
    802011c2:	03451713          	slli	a4,a0,0x34
    802011c6:	e359                	bnez	a4,8020124c <pfree+0x96>
    802011c8:	84aa                	mv	s1,a0
    802011ca:	00028717          	auipc	a4,0x28
    802011ce:	f1673703          	ld	a4,-234(a4) # 802290e0 <kmem+0x20>
    802011d2:	06e56d63          	bltu	a0,a4,8020124c <pfree+0x96>
    802011d6:	00028717          	auipc	a4,0x28
    802011da:	f1273703          	ld	a4,-238(a4) # 802290e8 <kmem+0x28>
    802011de:	06e57763          	bgeu	a0,a4,8020124c <pfree+0x96>
        panic("pfree: bad pointer");

    acquire(&kmem.lock);
    802011e2:	00028917          	auipc	s2,0x28
    802011e6:	ede90913          	addi	s2,s2,-290 # 802290c0 <kmem>
    802011ea:	854a                	mv	a0,s2
    802011ec:	00000097          	auipc	ra,0x0
    802011f0:	148080e7          	jalr	328(ra) # 80201334 <acquire>
    uint64 i = PA2IDX(pa);
    802011f4:	02093783          	ld	a5,32(s2)
    802011f8:	40f487b3          	sub	a5,s1,a5
    802011fc:	83b1                	srli	a5,a5,0xc
    if (kmem.refcnt[i] < 1)
    802011fe:	03893703          	ld	a4,56(s2)
    80201202:	973e                	add	a4,a4,a5
    80201204:	00074783          	lbu	a5,0(a4)
    80201208:	cbb1                	beqz	a5,8020125c <pfree+0xa6>
        panic("pfree: double free / refcount underflow");

    if (--kmem.refcnt[i] > 0) {          /* still shared (COW) - not really free */
    8020120a:	37fd                	addiw	a5,a5,-1
    8020120c:	0ff7f793          	zext.b	a5,a5
    80201210:	00f70023          	sb	a5,0(a4)
    80201214:	efa1                	bnez	a5,8020126c <pfree+0xb6>
        release(&kmem.lock);
        return;
    }
    memset(pa, 1, PGSIZE);               /* poison: catch use-after-free */
    80201216:	6605                	lui	a2,0x1
    80201218:	4585                	li	a1,1
    8020121a:	8526                	mv	a0,s1
    8020121c:	fffff097          	auipc	ra,0xfffff
    80201220:	488080e7          	jalr	1160(ra) # 802006a4 <memset>
    struct run *r = (struct run *)pa;
    r->next = kmem.freelist;
    80201224:	00028517          	auipc	a0,0x28
    80201228:	e9c50513          	addi	a0,a0,-356 # 802290c0 <kmem>
    8020122c:	6d1c                	ld	a5,24(a0)
    8020122e:	e09c                	sd	a5,0(s1)
    kmem.freelist = r;
    80201230:	ed04                	sd	s1,24(a0)
    kmem.nfree++;
    80201232:	591c                	lw	a5,48(a0)
    80201234:	2785                	addiw	a5,a5,1
    80201236:	d91c                	sw	a5,48(a0)
    release(&kmem.lock);
    80201238:	00000097          	auipc	ra,0x0
    8020123c:	1b0080e7          	jalr	432(ra) # 802013e8 <release>
}
    80201240:	60e2                	ld	ra,24(sp)
    80201242:	6442                	ld	s0,16(sp)
    80201244:	64a2                	ld	s1,8(sp)
    80201246:	6902                	ld	s2,0(sp)
    80201248:	6105                	addi	sp,sp,32
    8020124a:	8082                	ret
        panic("pfree: bad pointer");
    8020124c:	00006517          	auipc	a0,0x6
    80201250:	18c50513          	addi	a0,a0,396 # 802073d8 <etext+0x3d8>
    80201254:	fffff097          	auipc	ra,0xfffff
    80201258:	3aa080e7          	jalr	938(ra) # 802005fe <panic>
        panic("pfree: double free / refcount underflow");
    8020125c:	00006517          	auipc	a0,0x6
    80201260:	19450513          	addi	a0,a0,404 # 802073f0 <etext+0x3f0>
    80201264:	fffff097          	auipc	ra,0xfffff
    80201268:	39a080e7          	jalr	922(ra) # 802005fe <panic>
        release(&kmem.lock);
    8020126c:	00028517          	auipc	a0,0x28
    80201270:	e5450513          	addi	a0,a0,-428 # 802290c0 <kmem>
    80201274:	00000097          	auipc	ra,0x0
    80201278:	174080e7          	jalr	372(ra) # 802013e8 <release>
        return;
    8020127c:	b7d1                	j	80201240 <pfree+0x8a>

000000008020127e <palloc_free_count>:

int palloc_free_count(void)
{
    8020127e:	1101                	addi	sp,sp,-32
    80201280:	ec06                	sd	ra,24(sp)
    80201282:	e822                	sd	s0,16(sp)
    80201284:	e426                	sd	s1,8(sp)
    80201286:	e04a                	sd	s2,0(sp)
    80201288:	1000                	addi	s0,sp,32
    acquire(&kmem.lock);
    8020128a:	00028497          	auipc	s1,0x28
    8020128e:	e3648493          	addi	s1,s1,-458 # 802290c0 <kmem>
    80201292:	8526                	mv	a0,s1
    80201294:	00000097          	auipc	ra,0x0
    80201298:	0a0080e7          	jalr	160(ra) # 80201334 <acquire>
    int n = kmem.nfree;
    8020129c:	0304a903          	lw	s2,48(s1)
    release(&kmem.lock);
    802012a0:	8526                	mv	a0,s1
    802012a2:	00000097          	auipc	ra,0x0
    802012a6:	146080e7          	jalr	326(ra) # 802013e8 <release>
    return n;
}
    802012aa:	854a                	mv	a0,s2
    802012ac:	60e2                	ld	ra,24(sp)
    802012ae:	6442                	ld	s0,16(sp)
    802012b0:	64a2                	ld	s1,8(sp)
    802012b2:	6902                	ld	s2,0(sp)
    802012b4:	6105                	addi	sp,sp,32
    802012b6:	8082                	ret

00000000802012b8 <initlock>:
#include "types.h"
#include "defs.h"
#include "hal.h"

void initlock(struct spinlock *lk, const char *name)
{
    802012b8:	1141                	addi	sp,sp,-16
    802012ba:	e422                	sd	s0,8(sp)
    802012bc:	0800                	addi	s0,sp,16
    lk->name = name; lk->locked = 0; lk->cpu = -1;
    802012be:	e50c                	sd	a1,8(a0)
    802012c0:	00052023          	sw	zero,0(a0)
    802012c4:	57fd                	li	a5,-1
    802012c6:	c91c                	sw	a5,16(a0)
}
    802012c8:	6422                	ld	s0,8(sp)
    802012ca:	0141                	addi	sp,sp,16
    802012cc:	8082                	ret

00000000802012ce <holding>:
    pop_off();
}

int holding(struct spinlock *lk)
{
    return lk->locked && lk->cpu == hal_hart_id();
    802012ce:	411c                	lw	a5,0(a0)
    802012d0:	e399                	bnez	a5,802012d6 <holding+0x8>
    802012d2:	4501                	li	a0,0
}
    802012d4:	8082                	ret
{
    802012d6:	1101                	addi	sp,sp,-32
    802012d8:	ec06                	sd	ra,24(sp)
    802012da:	e822                	sd	s0,16(sp)
    802012dc:	e426                	sd	s1,8(sp)
    802012de:	1000                	addi	s0,sp,32
    return lk->locked && lk->cpu == hal_hart_id();
    802012e0:	4904                	lw	s1,16(a0)
    802012e2:	00005097          	auipc	ra,0x5
    802012e6:	e40080e7          	jalr	-448(ra) # 80206122 <hal_hart_id>
    802012ea:	40a48533          	sub	a0,s1,a0
    802012ee:	00153513          	seqz	a0,a0
}
    802012f2:	60e2                	ld	ra,24(sp)
    802012f4:	6442                	ld	s0,16(sp)
    802012f6:	64a2                	ld	s1,8(sp)
    802012f8:	6105                	addi	sp,sp,32
    802012fa:	8082                	ret

00000000802012fc <push_off>:

void push_off(void)
{
    802012fc:	1101                	addi	sp,sp,-32
    802012fe:	ec06                	sd	ra,24(sp)
    80201300:	e822                	sd	s0,16(sp)
    80201302:	e426                	sd	s1,8(sp)
    80201304:	1000                	addi	s0,sp,32
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201306:	100024f3          	csrr	s1,sstatus
    8020130a:	100027f3          	csrr	a5,sstatus
#define SIE_SSIE (1L << 1)
#define SIE_STIE (1L << 5)       /* timer  */
#define SIE_SEIE (1L << 9)       /* external */

static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    8020130e:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201310:	10079073          	csrw	sstatus,a5
    int old = intr_get();
    intr_off();
    struct cpu *c = mycpu();
    80201314:	00000097          	auipc	ra,0x0
    80201318:	3e6080e7          	jalr	998(ra) # 802016fa <mycpu>
    if (c->noff == 0) c->intena = old;   /* remember the ORIGINAL state */
    8020131c:	5d3c                	lw	a5,120(a0)
    8020131e:	e781                	bnez	a5,80201326 <push_off+0x2a>
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201320:	8085                	srli	s1,s1,0x1
    80201322:	8885                	andi	s1,s1,1
    80201324:	dd64                	sw	s1,124(a0)
    c->noff++;
    80201326:	2785                	addiw	a5,a5,1
    80201328:	dd3c                	sw	a5,120(a0)
}
    8020132a:	60e2                	ld	ra,24(sp)
    8020132c:	6442                	ld	s0,16(sp)
    8020132e:	64a2                	ld	s1,8(sp)
    80201330:	6105                	addi	sp,sp,32
    80201332:	8082                	ret

0000000080201334 <acquire>:
{
    80201334:	1101                	addi	sp,sp,-32
    80201336:	ec06                	sd	ra,24(sp)
    80201338:	e822                	sd	s0,16(sp)
    8020133a:	e426                	sd	s1,8(sp)
    8020133c:	1000                	addi	s0,sp,32
    8020133e:	84aa                	mv	s1,a0
    push_off();
    80201340:	00000097          	auipc	ra,0x0
    80201344:	fbc080e7          	jalr	-68(ra) # 802012fc <push_off>
    if (holding(lk)) panic("acquire: already holding this lock");
    80201348:	8526                	mv	a0,s1
    8020134a:	00000097          	auipc	ra,0x0
    8020134e:	f84080e7          	jalr	-124(ra) # 802012ce <holding>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80201352:	4705                	li	a4,1
    if (holding(lk)) panic("acquire: already holding this lock");
    80201354:	e115                	bnez	a0,80201378 <acquire+0x44>
    while (__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80201356:	87ba                	mv	a5,a4
    80201358:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8020135c:	2781                	sext.w	a5,a5
    8020135e:	ffe5                	bnez	a5,80201356 <acquire+0x22>
    __sync_synchronize();          /* fence: nothing below moves above this */
    80201360:	0ff0000f          	fence
    lk->cpu = hal_hart_id();
    80201364:	00005097          	auipc	ra,0x5
    80201368:	dbe080e7          	jalr	-578(ra) # 80206122 <hal_hart_id>
    8020136c:	c888                	sw	a0,16(s1)
}
    8020136e:	60e2                	ld	ra,24(sp)
    80201370:	6442                	ld	s0,16(sp)
    80201372:	64a2                	ld	s1,8(sp)
    80201374:	6105                	addi	sp,sp,32
    80201376:	8082                	ret
    if (holding(lk)) panic("acquire: already holding this lock");
    80201378:	00006517          	auipc	a0,0x6
    8020137c:	0a050513          	addi	a0,a0,160 # 80207418 <etext+0x418>
    80201380:	fffff097          	auipc	ra,0xfffff
    80201384:	27e080e7          	jalr	638(ra) # 802005fe <panic>

0000000080201388 <pop_off>:

void pop_off(void)
{
    80201388:	1141                	addi	sp,sp,-16
    8020138a:	e406                	sd	ra,8(sp)
    8020138c:	e022                	sd	s0,0(sp)
    8020138e:	0800                	addi	s0,sp,16
    struct cpu *c = mycpu();
    80201390:	00000097          	auipc	ra,0x0
    80201394:	36a080e7          	jalr	874(ra) # 802016fa <mycpu>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201398:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    8020139c:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("pop_off: interrupts already on");
    8020139e:	e78d                	bnez	a5,802013c8 <pop_off+0x40>
    if (c->noff < 1) panic("pop_off: unbalanced");
    802013a0:	5d3c                	lw	a5,120(a0)
    802013a2:	02f05b63          	blez	a5,802013d8 <pop_off+0x50>
    c->noff--;
    802013a6:	37fd                	addiw	a5,a5,-1
    802013a8:	0007871b          	sext.w	a4,a5
    802013ac:	dd3c                	sw	a5,120(a0)
    if (c->noff == 0 && c->intena) intr_on();
    802013ae:	eb09                	bnez	a4,802013c0 <pop_off+0x38>
    802013b0:	5d7c                	lw	a5,124(a0)
    802013b2:	c799                	beqz	a5,802013c0 <pop_off+0x38>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    802013b4:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    802013b8:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    802013bc:	10079073          	csrw	sstatus,a5
}
    802013c0:	60a2                	ld	ra,8(sp)
    802013c2:	6402                	ld	s0,0(sp)
    802013c4:	0141                	addi	sp,sp,16
    802013c6:	8082                	ret
    if (intr_get()) panic("pop_off: interrupts already on");
    802013c8:	00006517          	auipc	a0,0x6
    802013cc:	07850513          	addi	a0,a0,120 # 80207440 <etext+0x440>
    802013d0:	fffff097          	auipc	ra,0xfffff
    802013d4:	22e080e7          	jalr	558(ra) # 802005fe <panic>
    if (c->noff < 1) panic("pop_off: unbalanced");
    802013d8:	00006517          	auipc	a0,0x6
    802013dc:	08850513          	addi	a0,a0,136 # 80207460 <etext+0x460>
    802013e0:	fffff097          	auipc	ra,0xfffff
    802013e4:	21e080e7          	jalr	542(ra) # 802005fe <panic>

00000000802013e8 <release>:
{
    802013e8:	1101                	addi	sp,sp,-32
    802013ea:	ec06                	sd	ra,24(sp)
    802013ec:	e822                	sd	s0,16(sp)
    802013ee:	e426                	sd	s1,8(sp)
    802013f0:	1000                	addi	s0,sp,32
    802013f2:	84aa                	mv	s1,a0
    if (!holding(lk)) panic("release: not holding this lock");
    802013f4:	00000097          	auipc	ra,0x0
    802013f8:	eda080e7          	jalr	-294(ra) # 802012ce <holding>
    802013fc:	c115                	beqz	a0,80201420 <release+0x38>
    lk->cpu = -1;
    802013fe:	57fd                	li	a5,-1
    80201400:	c89c                	sw	a5,16(s1)
    __sync_synchronize();          /* fence: nothing above moves below this */
    80201402:	0ff0000f          	fence
    __sync_lock_release(&lk->locked);
    80201406:	0f50000f          	fence	iorw,ow
    8020140a:	0804a02f          	amoswap.w	zero,zero,(s1)
    pop_off();
    8020140e:	00000097          	auipc	ra,0x0
    80201412:	f7a080e7          	jalr	-134(ra) # 80201388 <pop_off>
}
    80201416:	60e2                	ld	ra,24(sp)
    80201418:	6442                	ld	s0,16(sp)
    8020141a:	64a2                	ld	s1,8(sp)
    8020141c:	6105                	addi	sp,sp,32
    8020141e:	8082                	ret
    if (!holding(lk)) panic("release: not holding this lock");
    80201420:	00006517          	auipc	a0,0x6
    80201424:	05850513          	addi	a0,a0,88 # 80207478 <etext+0x478>
    80201428:	fffff097          	auipc	ra,0xfffff
    8020142c:	1d6080e7          	jalr	470(ra) # 802005fe <panic>

0000000080201430 <initsleeplock>:
 */
#include "types.h"
#include "defs.h"

void initsleeplock(struct sleeplock *lk, const char *name)
{
    80201430:	1101                	addi	sp,sp,-32
    80201432:	ec06                	sd	ra,24(sp)
    80201434:	e822                	sd	s0,16(sp)
    80201436:	e426                	sd	s1,8(sp)
    80201438:	e04a                	sd	s2,0(sp)
    8020143a:	1000                	addi	s0,sp,32
    8020143c:	84aa                	mv	s1,a0
    8020143e:	892e                	mv	s2,a1
    initlock(&lk->lk, "sleep lock");
    80201440:	00006597          	auipc	a1,0x6
    80201444:	05858593          	addi	a1,a1,88 # 80207498 <etext+0x498>
    80201448:	0521                	addi	a0,a0,8
    8020144a:	00000097          	auipc	ra,0x0
    8020144e:	e6e080e7          	jalr	-402(ra) # 802012b8 <initlock>
    lk->name = name;
    80201452:	0324b023          	sd	s2,32(s1)
    lk->locked = 0;
    80201456:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    8020145a:	0204a423          	sw	zero,40(s1)
}
    8020145e:	60e2                	ld	ra,24(sp)
    80201460:	6442                	ld	s0,16(sp)
    80201462:	64a2                	ld	s1,8(sp)
    80201464:	6902                	ld	s2,0(sp)
    80201466:	6105                	addi	sp,sp,32
    80201468:	8082                	ret

000000008020146a <acquiresleep>:

void acquiresleep(struct sleeplock *lk)
{
    8020146a:	1101                	addi	sp,sp,-32
    8020146c:	ec06                	sd	ra,24(sp)
    8020146e:	e822                	sd	s0,16(sp)
    80201470:	e426                	sd	s1,8(sp)
    80201472:	e04a                	sd	s2,0(sp)
    80201474:	1000                	addi	s0,sp,32
    80201476:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201478:	00850913          	addi	s2,a0,8
    8020147c:	854a                	mv	a0,s2
    8020147e:	00000097          	auipc	ra,0x0
    80201482:	eb6080e7          	jalr	-330(ra) # 80201334 <acquire>
    while (lk->locked)
    80201486:	409c                	lw	a5,0(s1)
    80201488:	cb89                	beqz	a5,8020149a <acquiresleep+0x30>
        sleep(lk, &lk->lk);       /* releases lk->lk while asleep */
    8020148a:	85ca                	mv	a1,s2
    8020148c:	8526                	mv	a0,s1
    8020148e:	00001097          	auipc	ra,0x1
    80201492:	8f4080e7          	jalr	-1804(ra) # 80201d82 <sleep>
    while (lk->locked)
    80201496:	409c                	lw	a5,0(s1)
    80201498:	fbed                	bnez	a5,8020148a <acquiresleep+0x20>
    lk->locked = 1;
    8020149a:	4785                	li	a5,1
    8020149c:	c09c                	sw	a5,0(s1)
    lk->pid = myproc()->pid;
    8020149e:	00000097          	auipc	ra,0x0
    802014a2:	280080e7          	jalr	640(ra) # 8020171e <myproc>
    802014a6:	591c                	lw	a5,48(a0)
    802014a8:	d49c                	sw	a5,40(s1)
    release(&lk->lk);
    802014aa:	854a                	mv	a0,s2
    802014ac:	00000097          	auipc	ra,0x0
    802014b0:	f3c080e7          	jalr	-196(ra) # 802013e8 <release>
}
    802014b4:	60e2                	ld	ra,24(sp)
    802014b6:	6442                	ld	s0,16(sp)
    802014b8:	64a2                	ld	s1,8(sp)
    802014ba:	6902                	ld	s2,0(sp)
    802014bc:	6105                	addi	sp,sp,32
    802014be:	8082                	ret

00000000802014c0 <releasesleep>:

void releasesleep(struct sleeplock *lk)
{
    802014c0:	1101                	addi	sp,sp,-32
    802014c2:	ec06                	sd	ra,24(sp)
    802014c4:	e822                	sd	s0,16(sp)
    802014c6:	e426                	sd	s1,8(sp)
    802014c8:	e04a                	sd	s2,0(sp)
    802014ca:	1000                	addi	s0,sp,32
    802014cc:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    802014ce:	00850913          	addi	s2,a0,8
    802014d2:	854a                	mv	a0,s2
    802014d4:	00000097          	auipc	ra,0x0
    802014d8:	e60080e7          	jalr	-416(ra) # 80201334 <acquire>
    lk->locked = 0;
    802014dc:	0004a023          	sw	zero,0(s1)
    lk->pid = 0;
    802014e0:	0204a423          	sw	zero,40(s1)
    wakeup(lk);
    802014e4:	8526                	mv	a0,s1
    802014e6:	00001097          	auipc	ra,0x1
    802014ea:	a22080e7          	jalr	-1502(ra) # 80201f08 <wakeup>
    release(&lk->lk);
    802014ee:	854a                	mv	a0,s2
    802014f0:	00000097          	auipc	ra,0x0
    802014f4:	ef8080e7          	jalr	-264(ra) # 802013e8 <release>
}
    802014f8:	60e2                	ld	ra,24(sp)
    802014fa:	6442                	ld	s0,16(sp)
    802014fc:	64a2                	ld	s1,8(sp)
    802014fe:	6902                	ld	s2,0(sp)
    80201500:	6105                	addi	sp,sp,32
    80201502:	8082                	ret

0000000080201504 <holdingsleep>:

int holdingsleep(struct sleeplock *lk)
{
    80201504:	7179                	addi	sp,sp,-48
    80201506:	f406                	sd	ra,40(sp)
    80201508:	f022                	sd	s0,32(sp)
    8020150a:	ec26                	sd	s1,24(sp)
    8020150c:	e84a                	sd	s2,16(sp)
    8020150e:	1800                	addi	s0,sp,48
    80201510:	84aa                	mv	s1,a0
    acquire(&lk->lk);
    80201512:	00850913          	addi	s2,a0,8
    80201516:	854a                	mv	a0,s2
    80201518:	00000097          	auipc	ra,0x0
    8020151c:	e1c080e7          	jalr	-484(ra) # 80201334 <acquire>
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201520:	409c                	lw	a5,0(s1)
    80201522:	ef91                	bnez	a5,8020153e <holdingsleep+0x3a>
    80201524:	4481                	li	s1,0
    release(&lk->lk);
    80201526:	854a                	mv	a0,s2
    80201528:	00000097          	auipc	ra,0x0
    8020152c:	ec0080e7          	jalr	-320(ra) # 802013e8 <release>
    return r;
}
    80201530:	8526                	mv	a0,s1
    80201532:	70a2                	ld	ra,40(sp)
    80201534:	7402                	ld	s0,32(sp)
    80201536:	64e2                	ld	s1,24(sp)
    80201538:	6942                	ld	s2,16(sp)
    8020153a:	6145                	addi	sp,sp,48
    8020153c:	8082                	ret
    8020153e:	e44e                	sd	s3,8(sp)
    int r = lk->locked && (lk->pid == myproc()->pid);
    80201540:	0284a983          	lw	s3,40(s1)
    80201544:	00000097          	auipc	ra,0x0
    80201548:	1da080e7          	jalr	474(ra) # 8020171e <myproc>
    8020154c:	5904                	lw	s1,48(a0)
    8020154e:	413484b3          	sub	s1,s1,s3
    80201552:	0014b493          	seqz	s1,s1
    80201556:	69a2                	ld	s3,8(sp)
    80201558:	b7f9                	j	80201526 <holdingsleep+0x22>

000000008020155a <freeproc>:
        p->kstack = 0;
    }
}

static void freeproc(struct proc *p)
{
    8020155a:	1101                	addi	sp,sp,-32
    8020155c:	ec06                	sd	ra,24(sp)
    8020155e:	e822                	sd	s0,16(sp)
    80201560:	e426                	sd	s1,8(sp)
    80201562:	1000                	addi	s0,sp,32
    80201564:	84aa                	mv	s1,a0
    if (p->tf) pfree((void *)p->tf);
    80201566:	6d28                	ld	a0,88(a0)
    80201568:	c509                	beqz	a0,80201572 <freeproc+0x18>
    8020156a:	00000097          	auipc	ra,0x0
    8020156e:	c4c080e7          	jalr	-948(ra) # 802011b6 <pfree>
    p->tf = 0;
    80201572:	0404bc23          	sd	zero,88(s1)
    if (p->pagetable) uvmfree(p->pagetable, p->sz);
    80201576:	68a8                	ld	a0,80(s1)
    80201578:	c511                	beqz	a0,80201584 <freeproc+0x2a>
    8020157a:	64ac                	ld	a1,72(s1)
    8020157c:	00002097          	auipc	ra,0x2
    80201580:	8ca080e7          	jalr	-1846(ra) # 80202e46 <uvmfree>
    p->pagetable = 0;
    80201584:	0404b823          	sd	zero,80(s1)
    p->kstack = 0;              /* statically allocated - nothing to free */
    80201588:	0404b023          	sd	zero,64(s1)
    p->sz = 0; p->pid = 0; p->parent = 0;
    8020158c:	0404b423          	sd	zero,72(s1)
    80201590:	0204a823          	sw	zero,48(s1)
    80201594:	0204bc23          	sd	zero,56(s1)
    p->name[0] = 0; p->chan = 0; p->killed = 0; p->xstate = 0;
    80201598:	14048c23          	sb	zero,344(s1)
    8020159c:	0204b023          	sd	zero,32(s1)
    802015a0:	0204a423          	sw	zero,40(s1)
    802015a4:	0204a623          	sw	zero,44(s1)
    p->state = UNUSED;
    802015a8:	0004ac23          	sw	zero,24(s1)
}
    802015ac:	60e2                	ld	ra,24(sp)
    802015ae:	6442                	ld	s0,16(sp)
    802015b0:	64a2                	ld	s1,8(sp)
    802015b2:	6105                	addi	sp,sp,32
    802015b4:	8082                	ret

00000000802015b6 <allocproc>:
    }
    usertrapret();
}

static struct proc *allocproc(void)
{
    802015b6:	7179                	addi	sp,sp,-48
    802015b8:	f406                	sd	ra,40(sp)
    802015ba:	f022                	sd	s0,32(sp)
    802015bc:	ec26                	sd	s1,24(sp)
    802015be:	e84a                	sd	s2,16(sp)
    802015c0:	1800                	addi	s0,sp,48
    struct proc *p;
    for (p = proc; p < &proc[NPROC]; p++) {
    802015c2:	0012a497          	auipc	s1,0x12a
    802015c6:	a3e48493          	addi	s1,s1,-1474 # 8032b000 <proc>
    802015ca:	0012f917          	auipc	s2,0x12f
    802015ce:	43690913          	addi	s2,s2,1078 # 80330a00 <tickslock>
        acquire(&p->lock);
    802015d2:	8526                	mv	a0,s1
    802015d4:	00000097          	auipc	ra,0x0
    802015d8:	d60080e7          	jalr	-672(ra) # 80201334 <acquire>
        if (p->state == UNUSED) goto found;
    802015dc:	4c9c                	lw	a5,24(s1)
    802015de:	cf81                	beqz	a5,802015f6 <allocproc+0x40>
        release(&p->lock);
    802015e0:	8526                	mv	a0,s1
    802015e2:	00000097          	auipc	ra,0x0
    802015e6:	e06080e7          	jalr	-506(ra) # 802013e8 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    802015ea:	16848493          	addi	s1,s1,360
    802015ee:	ff2492e3          	bne	s1,s2,802015d2 <allocproc+0x1c>
    }
    return 0;
    802015f2:	4481                	li	s1,0
    802015f4:	a0d1                	j	802016b8 <allocproc+0x102>
    802015f6:	e44e                	sd	s3,8(sp)
    acquire(&pid_lock);
    802015f8:	00029997          	auipc	s3,0x29
    802015fc:	a0898993          	addi	s3,s3,-1528 # 8022a000 <pid_lock>
    80201600:	854e                	mv	a0,s3
    80201602:	00000097          	auipc	ra,0x0
    80201606:	d32080e7          	jalr	-718(ra) # 80201334 <acquire>
    int pid = nextpid++;
    8020160a:	00007797          	auipc	a5,0x7
    8020160e:	9fe78793          	addi	a5,a5,-1538 # 80208008 <nextpid>
    80201612:	0007a903          	lw	s2,0(a5)
    80201616:	0019071b          	addiw	a4,s2,1
    8020161a:	c398                	sw	a4,0(a5)
    release(&pid_lock);
    8020161c:	854e                	mv	a0,s3
    8020161e:	00000097          	auipc	ra,0x0
    80201622:	dca080e7          	jalr	-566(ra) # 802013e8 <release>

found:
    p->pid    = allocpid();
    80201626:	0324a823          	sw	s2,48(s1)
    p->state  = USED;
    8020162a:	4785                	li	a5,1
    8020162c:	cc9c                	sw	a5,24(s1)
    p->killed = 0;
    8020162e:	0204a423          	sw	zero,40(s1)
    p->xstate = 0;
    80201632:	0204a623          	sw	zero,44(s1)
    p->chan   = 0;
    80201636:	0204b023          	sd	zero,32(s1)

    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    8020163a:	00000097          	auipc	ra,0x0
    8020163e:	a6c080e7          	jalr	-1428(ra) # 802010a6 <palloc>
    80201642:	892a                	mv	s2,a0
    80201644:	eca8                	sd	a0,88(s1)
    80201646:	c141                	beqz	a0,802016c6 <allocproc+0x110>

    /* Contiguous, statically reserved. See the note at the top of this file. */
    p->kstack = (uint64)kstacks[p - proc];
    80201648:	0012a797          	auipc	a5,0x12a
    8020164c:	9b878793          	addi	a5,a5,-1608 # 8032b000 <proc>
    80201650:	40f487b3          	sub	a5,s1,a5
    80201654:	4037d713          	srai	a4,a5,0x3
    80201658:	04fa57b7          	lui	a5,0x4fa5
    8020165c:	fa578793          	addi	a5,a5,-91 # 4fa4fa5 <_entry-0x7b25b05b>
    80201660:	07b2                	slli	a5,a5,0xc
    80201662:	fa578793          	addi	a5,a5,-91
    80201666:	07b2                	slli	a5,a5,0xc
    80201668:	fa578793          	addi	a5,a5,-91
    8020166c:	07b2                	slli	a5,a5,0xc
    8020166e:	fa578793          	addi	a5,a5,-91
    80201672:	02f707b3          	mul	a5,a4,a5
    80201676:	07ba                	slli	a5,a5,0xe
    80201678:	0002a717          	auipc	a4,0x2a
    8020167c:	98870713          	addi	a4,a4,-1656 # 8022b000 <kstacks>
    80201680:	97ba                	add	a5,a5,a4
    80201682:	e0bc                	sd	a5,64(s1)

    p->pagetable = uvmcreate();
    80201684:	00001097          	auipc	ra,0x1
    80201688:	702080e7          	jalr	1794(ra) # 80202d86 <uvmcreate>
    8020168c:	892a                	mv	s2,a0
    8020168e:	e8a8                	sd	a0,80(s1)
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    80201690:	c921                	beqz	a0,802016e0 <allocproc+0x12a>

    memset(&p->context, 0, sizeof(p->context));
    80201692:	07000613          	li	a2,112
    80201696:	4581                	li	a1,0
    80201698:	06048513          	addi	a0,s1,96
    8020169c:	fffff097          	auipc	ra,0xfffff
    802016a0:	008080e7          	jalr	8(ra) # 802006a4 <memset>
    p->context.ra = (uint64)forkret;
    802016a4:	00000797          	auipc	a5,0x0
    802016a8:	0b678793          	addi	a5,a5,182 # 8020175a <forkret>
    802016ac:	f0bc                	sd	a5,96(s1)
    p->context.sp = p->kstack + KSTACK_SIZE;
    802016ae:	60bc                	ld	a5,64(s1)
    802016b0:	6711                	lui	a4,0x4
    802016b2:	97ba                	add	a5,a5,a4
    802016b4:	f4bc                	sd	a5,104(s1)
    802016b6:	69a2                	ld	s3,8(sp)
    return p;
}
    802016b8:	8526                	mv	a0,s1
    802016ba:	70a2                	ld	ra,40(sp)
    802016bc:	7402                	ld	s0,32(sp)
    802016be:	64e2                	ld	s1,24(sp)
    802016c0:	6942                	ld	s2,16(sp)
    802016c2:	6145                	addi	sp,sp,48
    802016c4:	8082                	ret
    if ((p->tf = (struct trapframe *)palloc()) == 0) { freeproc(p); release(&p->lock); return 0; }
    802016c6:	8526                	mv	a0,s1
    802016c8:	00000097          	auipc	ra,0x0
    802016cc:	e92080e7          	jalr	-366(ra) # 8020155a <freeproc>
    802016d0:	8526                	mv	a0,s1
    802016d2:	00000097          	auipc	ra,0x0
    802016d6:	d16080e7          	jalr	-746(ra) # 802013e8 <release>
    802016da:	84ca                	mv	s1,s2
    802016dc:	69a2                	ld	s3,8(sp)
    802016de:	bfe9                	j	802016b8 <allocproc+0x102>
    if (!p->pagetable) { freeproc(p); release(&p->lock); return 0; }
    802016e0:	8526                	mv	a0,s1
    802016e2:	00000097          	auipc	ra,0x0
    802016e6:	e78080e7          	jalr	-392(ra) # 8020155a <freeproc>
    802016ea:	8526                	mv	a0,s1
    802016ec:	00000097          	auipc	ra,0x0
    802016f0:	cfc080e7          	jalr	-772(ra) # 802013e8 <release>
    802016f4:	84ca                	mv	s1,s2
    802016f6:	69a2                	ld	s3,8(sp)
    802016f8:	b7c1                	j	802016b8 <allocproc+0x102>

00000000802016fa <mycpu>:
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    802016fa:	1141                	addi	sp,sp,-16
    802016fc:	e406                	sd	ra,8(sp)
    802016fe:	e022                	sd	s0,0(sp)
    80201700:	0800                	addi	s0,sp,16
    80201702:	00005097          	auipc	ra,0x5
    80201706:	a20080e7          	jalr	-1504(ra) # 80206122 <hal_hart_id>
    8020170a:	051e                	slli	a0,a0,0x7
    8020170c:	00029797          	auipc	a5,0x29
    80201710:	90c78793          	addi	a5,a5,-1780 # 8022a018 <cpus>
    80201714:	953e                	add	a0,a0,a5
    80201716:	60a2                	ld	ra,8(sp)
    80201718:	6402                	ld	s0,0(sp)
    8020171a:	0141                	addi	sp,sp,16
    8020171c:	8082                	ret

000000008020171e <myproc>:
{
    8020171e:	1101                	addi	sp,sp,-32
    80201720:	ec06                	sd	ra,24(sp)
    80201722:	e822                	sd	s0,16(sp)
    80201724:	e426                	sd	s1,8(sp)
    80201726:	1000                	addi	s0,sp,32
    push_off();
    80201728:	00000097          	auipc	ra,0x0
    8020172c:	bd4080e7          	jalr	-1068(ra) # 802012fc <push_off>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201730:	00005097          	auipc	ra,0x5
    80201734:	9f2080e7          	jalr	-1550(ra) # 80206122 <hal_hart_id>
    struct proc *p = mycpu()->proc;
    80201738:	051e                	slli	a0,a0,0x7
    8020173a:	00029797          	auipc	a5,0x29
    8020173e:	8c678793          	addi	a5,a5,-1850 # 8022a000 <pid_lock>
    80201742:	97aa                	add	a5,a5,a0
    80201744:	6f84                	ld	s1,24(a5)
    pop_off();
    80201746:	00000097          	auipc	ra,0x0
    8020174a:	c42080e7          	jalr	-958(ra) # 80201388 <pop_off>
}
    8020174e:	8526                	mv	a0,s1
    80201750:	60e2                	ld	ra,24(sp)
    80201752:	6442                	ld	s0,16(sp)
    80201754:	64a2                	ld	s1,8(sp)
    80201756:	6105                	addi	sp,sp,32
    80201758:	8082                	ret

000000008020175a <forkret>:
{
    8020175a:	1101                	addi	sp,sp,-32
    8020175c:	ec06                	sd	ra,24(sp)
    8020175e:	e822                	sd	s0,16(sp)
    80201760:	1000                	addi	s0,sp,32
    release(&myproc()->lock);
    80201762:	00000097          	auipc	ra,0x0
    80201766:	fbc080e7          	jalr	-68(ra) # 8020171e <myproc>
    8020176a:	00000097          	auipc	ra,0x0
    8020176e:	c7e080e7          	jalr	-898(ra) # 802013e8 <release>
    if (first) {
    80201772:	00007797          	auipc	a5,0x7
    80201776:	8927a783          	lw	a5,-1902(a5) # 80208004 <first.1>
    8020177a:	eb89                	bnez	a5,8020178c <forkret+0x32>
    usertrapret();
    8020177c:	00001097          	auipc	ra,0x1
    80201780:	e8e080e7          	jalr	-370(ra) # 8020260a <usertrapret>
}
    80201784:	60e2                	ld	ra,24(sp)
    80201786:	6442                	ld	s0,16(sp)
    80201788:	6105                	addi	sp,sp,32
    8020178a:	8082                	ret
    8020178c:	e426                	sd	s1,8(sp)
        first = 0;
    8020178e:	00007797          	auipc	a5,0x7
    80201792:	8607ab23          	sw	zero,-1930(a5) # 80208004 <first.1>
        fsinit(ROOTDEV);
    80201796:	4501                	li	a0,0
    80201798:	00003097          	auipc	ra,0x3
    8020179c:	5c8080e7          	jalr	1480(ra) # 80204d60 <fsinit>
        myproc()->cwd = namei("/");
    802017a0:	00000097          	auipc	ra,0x0
    802017a4:	f7e080e7          	jalr	-130(ra) # 8020171e <myproc>
    802017a8:	84aa                	mv	s1,a0
    802017aa:	00006517          	auipc	a0,0x6
    802017ae:	cfe50513          	addi	a0,a0,-770 # 802074a8 <etext+0x4a8>
    802017b2:	00004097          	auipc	ra,0x4
    802017b6:	142080e7          	jalr	322(ra) # 802058f4 <namei>
    802017ba:	14a4b823          	sd	a0,336(s1)
        __sync_synchronize();
    802017be:	0ff0000f          	fence
    802017c2:	64a2                	ld	s1,8(sp)
    802017c4:	bf65                	j	8020177c <forkret+0x22>

00000000802017c6 <procinit>:
{
    802017c6:	7179                	addi	sp,sp,-48
    802017c8:	f406                	sd	ra,40(sp)
    802017ca:	f022                	sd	s0,32(sp)
    802017cc:	ec26                	sd	s1,24(sp)
    802017ce:	e84a                	sd	s2,16(sp)
    802017d0:	e44e                	sd	s3,8(sp)
    802017d2:	1800                	addi	s0,sp,48
    initlock(&pid_lock,  "nextpid");
    802017d4:	00006597          	auipc	a1,0x6
    802017d8:	cdc58593          	addi	a1,a1,-804 # 802074b0 <etext+0x4b0>
    802017dc:	00029517          	auipc	a0,0x29
    802017e0:	82450513          	addi	a0,a0,-2012 # 8022a000 <pid_lock>
    802017e4:	00000097          	auipc	ra,0x0
    802017e8:	ad4080e7          	jalr	-1324(ra) # 802012b8 <initlock>
    initlock(&wait_lock, "wait_lock");
    802017ec:	00006597          	auipc	a1,0x6
    802017f0:	ccc58593          	addi	a1,a1,-820 # 802074b8 <etext+0x4b8>
    802017f4:	00029517          	auipc	a0,0x29
    802017f8:	c2450513          	addi	a0,a0,-988 # 8022a418 <wait_lock>
    802017fc:	00000097          	auipc	ra,0x0
    80201800:	abc080e7          	jalr	-1348(ra) # 802012b8 <initlock>
    initlock(&tickslock, "time");
    80201804:	00006597          	auipc	a1,0x6
    80201808:	cc458593          	addi	a1,a1,-828 # 802074c8 <etext+0x4c8>
    8020180c:	0012f517          	auipc	a0,0x12f
    80201810:	1f450513          	addi	a0,a0,500 # 80330a00 <tickslock>
    80201814:	00000097          	auipc	ra,0x0
    80201818:	aa4080e7          	jalr	-1372(ra) # 802012b8 <initlock>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020181c:	00129497          	auipc	s1,0x129
    80201820:	7e448493          	addi	s1,s1,2020 # 8032b000 <proc>
        initlock(&p->lock, "proc");
    80201824:	00006997          	auipc	s3,0x6
    80201828:	cac98993          	addi	s3,s3,-852 # 802074d0 <etext+0x4d0>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020182c:	0012f917          	auipc	s2,0x12f
    80201830:	1d490913          	addi	s2,s2,468 # 80330a00 <tickslock>
        initlock(&p->lock, "proc");
    80201834:	85ce                	mv	a1,s3
    80201836:	8526                	mv	a0,s1
    80201838:	00000097          	auipc	ra,0x0
    8020183c:	a80080e7          	jalr	-1408(ra) # 802012b8 <initlock>
        p->state  = UNUSED;
    80201840:	0004ac23          	sw	zero,24(s1)
        p->kstack = 0;
    80201844:	0404b023          	sd	zero,64(s1)
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201848:	16848493          	addi	s1,s1,360
    8020184c:	ff2494e3          	bne	s1,s2,80201834 <procinit+0x6e>
}
    80201850:	70a2                	ld	ra,40(sp)
    80201852:	7402                	ld	s0,32(sp)
    80201854:	64e2                	ld	s1,24(sp)
    80201856:	6942                	ld	s2,16(sp)
    80201858:	69a2                	ld	s3,8(sp)
    8020185a:	6145                	addi	sp,sp,48
    8020185c:	8082                	ret

000000008020185e <userinit>:

/* --- the very first user process, built by hand --- */
extern char _binary_user_initcode_start[], _binary_user_initcode_end[];

void userinit(void)
{
    8020185e:	7179                	addi	sp,sp,-48
    80201860:	f406                	sd	ra,40(sp)
    80201862:	f022                	sd	s0,32(sp)
    80201864:	ec26                	sd	s1,24(sp)
    80201866:	e84a                	sd	s2,16(sp)
    80201868:	e44e                	sd	s3,8(sp)
    8020186a:	1800                	addi	s0,sp,48
    struct proc *p = allocproc();
    8020186c:	00000097          	auipc	ra,0x0
    80201870:	d4a080e7          	jalr	-694(ra) # 802015b6 <allocproc>
    if (!p) panic("userinit: allocproc failed");
    80201874:	c569                	beqz	a0,8020193e <userinit+0xe0>
    80201876:	84aa                	mv	s1,a0
    initproc = p;
    80201878:	0013d797          	auipc	a5,0x13d
    8020187c:	78a7bc23          	sd	a0,1944(a5) # 8033f010 <initproc>

    uint64 sz = (uint64)(_binary_user_initcode_end - _binary_user_initcode_start);
    80201880:	00006997          	auipc	s3,0x6
    80201884:	6e898993          	addi	s3,s3,1768 # 80207f68 <_binary_user_initcode_end>
    80201888:	00006797          	auipc	a5,0x6
    8020188c:	6a878793          	addi	a5,a5,1704 # 80207f30 <_binary_user_initcode_start>
    80201890:	40f989b3          	sub	s3,s3,a5
    if (sz > PGSIZE) panic("userinit: initcode too big");
    80201894:	6785                	lui	a5,0x1
    80201896:	0b37ec63          	bltu	a5,s3,8020194e <userinit+0xf0>

    char *mem = palloc();
    8020189a:	00000097          	auipc	ra,0x0
    8020189e:	80c080e7          	jalr	-2036(ra) # 802010a6 <palloc>
    802018a2:	892a                	mv	s2,a0
    memset(mem, 0, PGSIZE);
    802018a4:	6605                	lui	a2,0x1
    802018a6:	4581                	li	a1,0
    802018a8:	fffff097          	auipc	ra,0xfffff
    802018ac:	dfc080e7          	jalr	-516(ra) # 802006a4 <memset>
    memmove(mem, _binary_user_initcode_start, sz);
    802018b0:	864e                	mv	a2,s3
    802018b2:	00006597          	auipc	a1,0x6
    802018b6:	67e58593          	addi	a1,a1,1662 # 80207f30 <_binary_user_initcode_start>
    802018ba:	854a                	mv	a0,s2
    802018bc:	fffff097          	auipc	ra,0xfffff
    802018c0:	e04080e7          	jalr	-508(ra) # 802006c0 <memmove>
    mappages(p->pagetable, 0, PGSIZE, (uint64)mem, PTE_R | PTE_W | PTE_X | PTE_U);
    802018c4:	4779                	li	a4,30
    802018c6:	86ca                	mv	a3,s2
    802018c8:	6605                	lui	a2,0x1
    802018ca:	4581                	li	a1,0
    802018cc:	68a8                	ld	a0,80(s1)
    802018ce:	00001097          	auipc	ra,0x1
    802018d2:	2a6080e7          	jalr	678(ra) # 80202b74 <mappages>

    char *stack = palloc();
    802018d6:	fffff097          	auipc	ra,0xfffff
    802018da:	7d0080e7          	jalr	2000(ra) # 802010a6 <palloc>
    802018de:	892a                	mv	s2,a0
    memset(stack, 0, PGSIZE);
    802018e0:	6605                	lui	a2,0x1
    802018e2:	4581                	li	a1,0
    802018e4:	fffff097          	auipc	ra,0xfffff
    802018e8:	dc0080e7          	jalr	-576(ra) # 802006a4 <memset>
    mappages(p->pagetable, PGSIZE, PGSIZE, (uint64)stack, PTE_R | PTE_W | PTE_U);
    802018ec:	4759                	li	a4,22
    802018ee:	86ca                	mv	a3,s2
    802018f0:	6605                	lui	a2,0x1
    802018f2:	6585                	lui	a1,0x1
    802018f4:	68a8                	ld	a0,80(s1)
    802018f6:	00001097          	auipc	ra,0x1
    802018fa:	27e080e7          	jalr	638(ra) # 80202b74 <mappages>

    p->sz       = 2 * PGSIZE;
    802018fe:	6789                	lui	a5,0x2
    80201900:	e4bc                	sd	a5,72(s1)
    p->tf->epc  = 0;                    /* start at the first byte of initcode */
    80201902:	6cb8                	ld	a4,88(s1)
    80201904:	00073c23          	sd	zero,24(a4) # 4018 <_entry-0x801fbfe8>
    p->tf->sp   = 2 * PGSIZE;           /* stack grows down from the top       */
    80201908:	6cb8                	ld	a4,88(s1)
    8020190a:	fb1c                	sd	a5,48(a4)
    strncpy(p->name, "initcode", sizeof(p->name));
    8020190c:	4641                	li	a2,16
    8020190e:	00006597          	auipc	a1,0x6
    80201912:	c0a58593          	addi	a1,a1,-1014 # 80207518 <etext+0x518>
    80201916:	15848513          	addi	a0,s1,344
    8020191a:	fffff097          	auipc	ra,0xfffff
    8020191e:	e4c080e7          	jalr	-436(ra) # 80200766 <strncpy>
    /* p->cwd is set by forkret once the filesystem is initialized. */
    p->state    = RUNNABLE;
    80201922:	478d                	li	a5,3
    80201924:	cc9c                	sw	a5,24(s1)
    release(&p->lock);
    80201926:	8526                	mv	a0,s1
    80201928:	00000097          	auipc	ra,0x0
    8020192c:	ac0080e7          	jalr	-1344(ra) # 802013e8 <release>
}
    80201930:	70a2                	ld	ra,40(sp)
    80201932:	7402                	ld	s0,32(sp)
    80201934:	64e2                	ld	s1,24(sp)
    80201936:	6942                	ld	s2,16(sp)
    80201938:	69a2                	ld	s3,8(sp)
    8020193a:	6145                	addi	sp,sp,48
    8020193c:	8082                	ret
    if (!p) panic("userinit: allocproc failed");
    8020193e:	00006517          	auipc	a0,0x6
    80201942:	b9a50513          	addi	a0,a0,-1126 # 802074d8 <etext+0x4d8>
    80201946:	fffff097          	auipc	ra,0xfffff
    8020194a:	cb8080e7          	jalr	-840(ra) # 802005fe <panic>
    if (sz > PGSIZE) panic("userinit: initcode too big");
    8020194e:	00006517          	auipc	a0,0x6
    80201952:	baa50513          	addi	a0,a0,-1110 # 802074f8 <etext+0x4f8>
    80201956:	fffff097          	auipc	ra,0xfffff
    8020195a:	ca8080e7          	jalr	-856(ra) # 802005fe <panic>

000000008020195e <growproc>:

int growproc(int n)
{
    8020195e:	7139                	addi	sp,sp,-64
    80201960:	fc06                	sd	ra,56(sp)
    80201962:	f822                	sd	s0,48(sp)
    80201964:	ec4e                	sd	s3,24(sp)
    80201966:	e852                	sd	s4,16(sp)
    80201968:	e456                	sd	s5,8(sp)
    8020196a:	0080                	addi	s0,sp,64
    8020196c:	8a2a                	mv	s4,a0
    struct proc *p = myproc();
    8020196e:	00000097          	auipc	ra,0x0
    80201972:	db0080e7          	jalr	-592(ra) # 8020171e <myproc>
    80201976:	89aa                	mv	s3,a0
    uint64 sz = p->sz;
    80201978:	04853a83          	ld	s5,72(a0)

    if (n > 0) {
    8020197c:	07405863          	blez	s4,802019ec <growproc+0x8e>
    80201980:	f04a                	sd	s2,32(sp)
    80201982:	e05a                	sd	s6,0(sp)
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    80201984:	6905                	lui	s2,0x1
    80201986:	197d                	addi	s2,s2,-1 # fff <_entry-0x801ff001>
    80201988:	9956                	add	s2,s2,s5
    8020198a:	77fd                	lui	a5,0xfffff
    8020198c:	00f97933          	and	s2,s2,a5
    80201990:	015a0b33          	add	s6,s4,s5
    80201994:	0b697263          	bgeu	s2,s6,80201a38 <growproc+0xda>
    80201998:	f426                	sd	s1,40(sp)
            char *mem = palloc();
    8020199a:	fffff097          	auipc	ra,0xfffff
    8020199e:	70c080e7          	jalr	1804(ra) # 802010a6 <palloc>
    802019a2:	84aa                	mv	s1,a0
            if (!mem) return -1;
    802019a4:	cd49                	beqz	a0,80201a3e <growproc+0xe0>
            memset(mem, 0, PGSIZE);
    802019a6:	6605                	lui	a2,0x1
    802019a8:	4581                	li	a1,0
    802019aa:	fffff097          	auipc	ra,0xfffff
    802019ae:	cfa080e7          	jalr	-774(ra) # 802006a4 <memset>
            if (mappages(p->pagetable, a, PGSIZE, (uint64)mem,
    802019b2:	4759                	li	a4,22
    802019b4:	86a6                	mv	a3,s1
    802019b6:	6605                	lui	a2,0x1
    802019b8:	85ca                	mv	a1,s2
    802019ba:	0509b503          	ld	a0,80(s3)
    802019be:	00001097          	auipc	ra,0x1
    802019c2:	1b6080e7          	jalr	438(ra) # 80202b74 <mappages>
    802019c6:	e909                	bnez	a0,802019d8 <growproc+0x7a>
        for (uint64 a = PGROUNDUP(sz); a < sz + n; a += PGSIZE) {
    802019c8:	6785                	lui	a5,0x1
    802019ca:	993e                	add	s2,s2,a5
    802019cc:	fd6967e3          	bltu	s2,s6,8020199a <growproc+0x3c>
    802019d0:	74a2                	ld	s1,40(sp)
    802019d2:	7902                	ld	s2,32(sp)
    802019d4:	6b02                	ld	s6,0(sp)
    802019d6:	a829                	j	802019f0 <growproc+0x92>
                         PTE_R | PTE_W | PTE_U) != 0) {
                pfree(mem);
    802019d8:	8526                	mv	a0,s1
    802019da:	fffff097          	auipc	ra,0xfffff
    802019de:	7dc080e7          	jalr	2012(ra) # 802011b6 <pfree>
                return -1;
    802019e2:	557d                	li	a0,-1
    802019e4:	74a2                	ld	s1,40(sp)
    802019e6:	7902                	ld	s2,32(sp)
    802019e8:	6b02                	ld	s6,0(sp)
    802019ea:	a039                	j	802019f8 <growproc+0x9a>
            }
        }
    } else if (n < 0) {
    802019ec:	000a4d63          	bltz	s4,80201a06 <growproc+0xa8>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
        sz = newsz;
        p->sz = sz;
        return 0;
    }
    p->sz = sz + n;
    802019f0:	9a56                	add	s4,s4,s5
    802019f2:	0549b423          	sd	s4,72(s3)
    return 0;
    802019f6:	4501                	li	a0,0
}
    802019f8:	70e2                	ld	ra,56(sp)
    802019fa:	7442                	ld	s0,48(sp)
    802019fc:	69e2                	ld	s3,24(sp)
    802019fe:	6a42                	ld	s4,16(sp)
    80201a00:	6aa2                	ld	s5,8(sp)
    80201a02:	6121                	addi	sp,sp,64
    80201a04:	8082                	ret
        uint64 newsz = sz + n;
    80201a06:	9a56                	add	s4,s4,s5
        if (PGROUNDUP(newsz) < PGROUNDUP(sz))
    80201a08:	6785                	lui	a5,0x1
    80201a0a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80201a0c:	00fa05b3          	add	a1,s4,a5
    80201a10:	777d                	lui	a4,0xfffff
    80201a12:	8df9                	and	a1,a1,a4
    80201a14:	97d6                	add	a5,a5,s5
    80201a16:	8ff9                	and	a5,a5,a4
    80201a18:	00f5e663          	bltu	a1,a5,80201a24 <growproc+0xc6>
        p->sz = sz;
    80201a1c:	0549b423          	sd	s4,72(s3)
        return 0;
    80201a20:	4501                	li	a0,0
    80201a22:	bfd9                	j	802019f8 <growproc+0x9a>
                     (PGROUNDUP(sz) - PGROUNDUP(newsz)) / PGSIZE, 1);
    80201a24:	8f8d                	sub	a5,a5,a1
            uvmunmap(p->pagetable, PGROUNDUP(newsz),
    80201a26:	4685                	li	a3,1
    80201a28:	00c7d613          	srli	a2,a5,0xc
    80201a2c:	6928                	ld	a0,80(a0)
    80201a2e:	00001097          	auipc	ra,0x1
    80201a32:	3a4080e7          	jalr	932(ra) # 80202dd2 <uvmunmap>
    80201a36:	b7dd                	j	80201a1c <growproc+0xbe>
    80201a38:	7902                	ld	s2,32(sp)
    80201a3a:	6b02                	ld	s6,0(sp)
    80201a3c:	bf55                	j	802019f0 <growproc+0x92>
            if (!mem) return -1;
    80201a3e:	557d                	li	a0,-1
    80201a40:	74a2                	ld	s1,40(sp)
    80201a42:	7902                	ld	s2,32(sp)
    80201a44:	6b02                	ld	s6,0(sp)
    80201a46:	bf4d                	j	802019f8 <growproc+0x9a>

0000000080201a48 <fork>:

int fork(void)
{
    80201a48:	7139                	addi	sp,sp,-64
    80201a4a:	fc06                	sd	ra,56(sp)
    80201a4c:	f822                	sd	s0,48(sp)
    80201a4e:	f04a                	sd	s2,32(sp)
    80201a50:	e456                	sd	s5,8(sp)
    80201a52:	0080                	addi	s0,sp,64
    struct proc *parent = myproc();
    80201a54:	00000097          	auipc	ra,0x0
    80201a58:	cca080e7          	jalr	-822(ra) # 8020171e <myproc>
    80201a5c:	8aaa                	mv	s5,a0
    struct proc *np = allocproc();
    80201a5e:	00000097          	auipc	ra,0x0
    80201a62:	b58080e7          	jalr	-1192(ra) # 802015b6 <allocproc>
    if (!np) return -1;
    80201a66:	12050063          	beqz	a0,80201b86 <fork+0x13e>
    80201a6a:	e852                	sd	s4,16(sp)
    80201a6c:	8a2a                	mv	s4,a0

    /* EAGER COPY: every user page is duplicated, right now. Simple, correct,
     * and O(memory) even for fork+exec - which is why Lab 5 replaces this
     * with copy-on-write. Do not bring COW forward; the graders diff it. */
    if (uvmcopy(parent->pagetable, np->pagetable, parent->sz) < 0) {
    80201a6e:	048ab603          	ld	a2,72(s5)
    80201a72:	692c                	ld	a1,80(a0)
    80201a74:	050ab503          	ld	a0,80(s5)
    80201a78:	00001097          	auipc	ra,0x1
    80201a7c:	40a080e7          	jalr	1034(ra) # 80202e82 <uvmcopy>
    80201a80:	04054a63          	bltz	a0,80201ad4 <fork+0x8c>
    80201a84:	f426                	sd	s1,40(sp)
    80201a86:	ec4e                	sd	s3,24(sp)
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = parent->sz;
    80201a88:	048ab783          	ld	a5,72(s5)
    80201a8c:	04fa3423          	sd	a5,72(s4)
    *(np->tf) = *(parent->tf);
    80201a90:	058ab683          	ld	a3,88(s5)
    80201a94:	87b6                	mv	a5,a3
    80201a96:	058a3703          	ld	a4,88(s4)
    80201a9a:	12068693          	addi	a3,a3,288
    80201a9e:	0007b803          	ld	a6,0(a5)
    80201aa2:	6788                	ld	a0,8(a5)
    80201aa4:	6b8c                	ld	a1,16(a5)
    80201aa6:	6f90                	ld	a2,24(a5)
    80201aa8:	01073023          	sd	a6,0(a4) # fffffffffffff000 <uart+0xffffffff7fcbffd0>
    80201aac:	e708                	sd	a0,8(a4)
    80201aae:	eb0c                	sd	a1,16(a4)
    80201ab0:	ef10                	sd	a2,24(a4)
    80201ab2:	02078793          	addi	a5,a5,32
    80201ab6:	02070713          	addi	a4,a4,32
    80201aba:	fed792e3          	bne	a5,a3,80201a9e <fork+0x56>
    np->tf->a0 = 0;                 /* the child sees fork() return 0 */
    80201abe:	058a3783          	ld	a5,88(s4)
    80201ac2:	0607b823          	sd	zero,112(a5)

    /* The child INHERITS the parent's open files and cwd - this is what makes
     * `cmd > file` work: the shell redirects, then forks, and the child keeps
     * the redirected descriptor. Same struct file, same offset. */
    for (int i = 0; i < NOFILE; i++)
    80201ac6:	0d0a8493          	addi	s1,s5,208
    80201aca:	0d0a0913          	addi	s2,s4,208
    80201ace:	150a8993          	addi	s3,s5,336
    80201ad2:	a015                	j	80201af6 <fork+0xae>
        freeproc(np);
    80201ad4:	8552                	mv	a0,s4
    80201ad6:	00000097          	auipc	ra,0x0
    80201ada:	a84080e7          	jalr	-1404(ra) # 8020155a <freeproc>
        release(&np->lock);
    80201ade:	8552                	mv	a0,s4
    80201ae0:	00000097          	auipc	ra,0x0
    80201ae4:	908080e7          	jalr	-1784(ra) # 802013e8 <release>
        return -1;
    80201ae8:	597d                	li	s2,-1
    80201aea:	6a42                	ld	s4,16(sp)
    80201aec:	a071                	j	80201b78 <fork+0x130>
    for (int i = 0; i < NOFILE; i++)
    80201aee:	04a1                	addi	s1,s1,8
    80201af0:	0921                	addi	s2,s2,8
    80201af2:	01348b63          	beq	s1,s3,80201b08 <fork+0xc0>
        if (parent->ofile[i])
    80201af6:	6088                	ld	a0,0(s1)
    80201af8:	d97d                	beqz	a0,80201aee <fork+0xa6>
            np->ofile[i] = filedup(parent->ofile[i]);
    80201afa:	00004097          	auipc	ra,0x4
    80201afe:	ec6080e7          	jalr	-314(ra) # 802059c0 <filedup>
    80201b02:	00a93023          	sd	a0,0(s2)
    80201b06:	b7e5                	j	80201aee <fork+0xa6>
    np->cwd = idup(parent->cwd);
    80201b08:	150ab503          	ld	a0,336(s5)
    80201b0c:	00003097          	auipc	ra,0x3
    80201b10:	516080e7          	jalr	1302(ra) # 80205022 <idup>
    80201b14:	14aa3823          	sd	a0,336(s4)

    strncpy(np->name, parent->name, sizeof(np->name));
    80201b18:	4641                	li	a2,16
    80201b1a:	158a8593          	addi	a1,s5,344
    80201b1e:	158a0513          	addi	a0,s4,344
    80201b22:	fffff097          	auipc	ra,0xfffff
    80201b26:	c44080e7          	jalr	-956(ra) # 80200766 <strncpy>
    int pid = np->pid;
    80201b2a:	030a2903          	lw	s2,48(s4)
    release(&np->lock);
    80201b2e:	8552                	mv	a0,s4
    80201b30:	00000097          	auipc	ra,0x0
    80201b34:	8b8080e7          	jalr	-1864(ra) # 802013e8 <release>

    acquire(&wait_lock);
    80201b38:	00029497          	auipc	s1,0x29
    80201b3c:	8e048493          	addi	s1,s1,-1824 # 8022a418 <wait_lock>
    80201b40:	8526                	mv	a0,s1
    80201b42:	fffff097          	auipc	ra,0xfffff
    80201b46:	7f2080e7          	jalr	2034(ra) # 80201334 <acquire>
    np->parent = parent;
    80201b4a:	035a3c23          	sd	s5,56(s4)
    release(&wait_lock);
    80201b4e:	8526                	mv	a0,s1
    80201b50:	00000097          	auipc	ra,0x0
    80201b54:	898080e7          	jalr	-1896(ra) # 802013e8 <release>

    acquire(&np->lock);
    80201b58:	8552                	mv	a0,s4
    80201b5a:	fffff097          	auipc	ra,0xfffff
    80201b5e:	7da080e7          	jalr	2010(ra) # 80201334 <acquire>
    np->state = RUNNABLE;
    80201b62:	478d                	li	a5,3
    80201b64:	00fa2c23          	sw	a5,24(s4)
    release(&np->lock);
    80201b68:	8552                	mv	a0,s4
    80201b6a:	00000097          	auipc	ra,0x0
    80201b6e:	87e080e7          	jalr	-1922(ra) # 802013e8 <release>
    return pid;
    80201b72:	74a2                	ld	s1,40(sp)
    80201b74:	69e2                	ld	s3,24(sp)
    80201b76:	6a42                	ld	s4,16(sp)
}
    80201b78:	854a                	mv	a0,s2
    80201b7a:	70e2                	ld	ra,56(sp)
    80201b7c:	7442                	ld	s0,48(sp)
    80201b7e:	7902                	ld	s2,32(sp)
    80201b80:	6aa2                	ld	s5,8(sp)
    80201b82:	6121                	addi	sp,sp,64
    80201b84:	8082                	ret
    if (!np) return -1;
    80201b86:	597d                	li	s2,-1
    80201b88:	bfc5                	j	80201b78 <fork+0x130>

0000000080201b8a <scheduler>:
    }
}

/* --- the scheduler: one instance per hart (L9) --- */
void scheduler(void)
{
    80201b8a:	715d                	addi	sp,sp,-80
    80201b8c:	e486                	sd	ra,72(sp)
    80201b8e:	e0a2                	sd	s0,64(sp)
    80201b90:	fc26                	sd	s1,56(sp)
    80201b92:	f84a                	sd	s2,48(sp)
    80201b94:	f44e                	sd	s3,40(sp)
    80201b96:	f052                	sd	s4,32(sp)
    80201b98:	ec56                	sd	s5,24(sp)
    80201b9a:	e85a                	sd	s6,16(sp)
    80201b9c:	e45e                	sd	s7,8(sp)
    80201b9e:	0880                	addi	s0,sp,80
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201ba0:	00004097          	auipc	ra,0x4
    80201ba4:	582080e7          	jalr	1410(ra) # 80206122 <hal_hart_id>
    struct cpu *c = mycpu();
    c->proc = 0;
    80201ba8:	00751b13          	slli	s6,a0,0x7
    80201bac:	00028717          	auipc	a4,0x28
    80201bb0:	45470713          	addi	a4,a4,1108 # 8022a000 <pid_lock>
    80201bb4:	975a                	add	a4,a4,s6
    80201bb6:	00073c23          	sd	zero,24(a4)
                p->state = RUNNING;
                c->proc  = p;
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
                sfence_vma();

                swtch(&c->context, &p->context);
    80201bba:	00028717          	auipc	a4,0x28
    80201bbe:	46670713          	addi	a4,a4,1126 # 8022a020 <cpus+0x8>
    80201bc2:	9b3a                	add	s6,s6,a4
                c->proc  = p;
    80201bc4:	00751793          	slli	a5,a0,0x7
    80201bc8:	00028a97          	auipc	s5,0x28
    80201bcc:	438a8a93          	addi	s5,s5,1080 # 8022a000 <pid_lock>
    80201bd0:	9abe                	add	s5,s5,a5
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201bd2:	5a7d                	li	s4,-1
    80201bd4:	1a7e                	slli	s4,s4,0x3f

                w_satp(MAKE_SATP(kernel_pagetable));
    80201bd6:	0013db97          	auipc	s7,0x13d
    80201bda:	44ab8b93          	addi	s7,s7,1098 # 8033f020 <kernel_pagetable>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201bde:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80201be2:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80201be6:	10079073          	csrw	sstatus,a5
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201bea:	00129497          	auipc	s1,0x129
    80201bee:	41648493          	addi	s1,s1,1046 # 8032b000 <proc>
            if (p->state == RUNNABLE) {
    80201bf2:	498d                	li	s3,3
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201bf4:	0012f917          	auipc	s2,0x12f
    80201bf8:	e0c90913          	addi	s2,s2,-500 # 80330a00 <tickslock>
    80201bfc:	a811                	j	80201c10 <scheduler+0x86>
                sfence_vma();
                c->proc = 0;
            }
            release(&p->lock);
    80201bfe:	8526                	mv	a0,s1
    80201c00:	fffff097          	auipc	ra,0xfffff
    80201c04:	7e8080e7          	jalr	2024(ra) # 802013e8 <release>
        for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201c08:	16848493          	addi	s1,s1,360
    80201c0c:	fd2489e3          	beq	s1,s2,80201bde <scheduler+0x54>
            acquire(&p->lock);
    80201c10:	8526                	mv	a0,s1
    80201c12:	fffff097          	auipc	ra,0xfffff
    80201c16:	722080e7          	jalr	1826(ra) # 80201334 <acquire>
            if (p->state == RUNNABLE) {
    80201c1a:	4c9c                	lw	a5,24(s1)
    80201c1c:	ff3791e3          	bne	a5,s3,80201bfe <scheduler+0x74>
                p->state = RUNNING;
    80201c20:	4791                	li	a5,4
    80201c22:	cc9c                	sw	a5,24(s1)
                c->proc  = p;
    80201c24:	009abc23          	sd	s1,24(s5)
                w_satp(MAKE_SATP(p->pagetable));   /* into its address space */
    80201c28:	68bc                	ld	a5,80(s1)
    80201c2a:	83b1                	srli	a5,a5,0xc
    80201c2c:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201c30:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201c34:	12000073          	sfence.vma
                swtch(&c->context, &p->context);
    80201c38:	06048593          	addi	a1,s1,96
    80201c3c:	855a                	mv	a0,s6
    80201c3e:	00000097          	auipc	ra,0x0
    80201c42:	654080e7          	jalr	1620(ra) # 80202292 <swtch>
                w_satp(MAKE_SATP(kernel_pagetable));
    80201c46:	000bb783          	ld	a5,0(s7)
    80201c4a:	83b1                	srli	a5,a5,0xc
    80201c4c:	0147e7b3          	or	a5,a5,s4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80201c50:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80201c54:	12000073          	sfence.vma
                c->proc = 0;
    80201c58:	000abc23          	sd	zero,24(s5)
    80201c5c:	b74d                	j	80201bfe <scheduler+0x74>

0000000080201c5e <sched>:
    }
}

/* Switch to the scheduler. Must hold p->lock and have changed p->state. */
void sched(void)
{
    80201c5e:	7179                	addi	sp,sp,-48
    80201c60:	f406                	sd	ra,40(sp)
    80201c62:	f022                	sd	s0,32(sp)
    80201c64:	ec26                	sd	s1,24(sp)
    80201c66:	e84a                	sd	s2,16(sp)
    80201c68:	e44e                	sd	s3,8(sp)
    80201c6a:	1800                	addi	s0,sp,48
    struct proc *p = myproc();
    80201c6c:	00000097          	auipc	ra,0x0
    80201c70:	ab2080e7          	jalr	-1358(ra) # 8020171e <myproc>
    80201c74:	84aa                	mv	s1,a0
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201c76:	fffff097          	auipc	ra,0xfffff
    80201c7a:	658080e7          	jalr	1624(ra) # 802012ce <holding>
    80201c7e:	c541                	beqz	a0,80201d06 <sched+0xa8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201c80:	00004097          	auipc	ra,0x4
    80201c84:	4a2080e7          	jalr	1186(ra) # 80206122 <hal_hart_id>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201c88:	051e                	slli	a0,a0,0x7
    80201c8a:	00028797          	auipc	a5,0x28
    80201c8e:	37678793          	addi	a5,a5,886 # 8022a000 <pid_lock>
    80201c92:	97aa                	add	a5,a5,a0
    80201c94:	0907a703          	lw	a4,144(a5)
    80201c98:	4785                	li	a5,1
    80201c9a:	06f71e63          	bne	a4,a5,80201d16 <sched+0xb8>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201c9e:	4c98                	lw	a4,24(s1)
    80201ca0:	4791                	li	a5,4
    80201ca2:	08f70263          	beq	a4,a5,80201d26 <sched+0xc8>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80201ca6:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    80201caa:	8b89                	andi	a5,a5,2
    if (intr_get())           panic("sched: interrupts are on");
    80201cac:	e7c9                	bnez	a5,80201d36 <sched+0xd8>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201cae:	00004097          	auipc	ra,0x4
    80201cb2:	474080e7          	jalr	1140(ra) # 80206122 <hal_hart_id>

    int intena = mycpu()->intena;
    80201cb6:	00028917          	auipc	s2,0x28
    80201cba:	34a90913          	addi	s2,s2,842 # 8022a000 <pid_lock>
    80201cbe:	00751793          	slli	a5,a0,0x7
    80201cc2:	97ca                	add	a5,a5,s2
    80201cc4:	0947a983          	lw	s3,148(a5)
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201cc8:	00004097          	auipc	ra,0x4
    80201ccc:	45a080e7          	jalr	1114(ra) # 80206122 <hal_hart_id>
    swtch(&p->context, &mycpu()->context);
    80201cd0:	051e                	slli	a0,a0,0x7
    80201cd2:	00028597          	auipc	a1,0x28
    80201cd6:	34e58593          	addi	a1,a1,846 # 8022a020 <cpus+0x8>
    80201cda:	95aa                	add	a1,a1,a0
    80201cdc:	06048513          	addi	a0,s1,96
    80201ce0:	00000097          	auipc	ra,0x0
    80201ce4:	5b2080e7          	jalr	1458(ra) # 80202292 <swtch>
struct cpu *mycpu(void) { return &cpus[hal_hart_id()]; }
    80201ce8:	00004097          	auipc	ra,0x4
    80201cec:	43a080e7          	jalr	1082(ra) # 80206122 <hal_hart_id>
    mycpu()->intena = intena;
    80201cf0:	051e                	slli	a0,a0,0x7
    80201cf2:	992a                	add	s2,s2,a0
    80201cf4:	09392a23          	sw	s3,148(s2)
}
    80201cf8:	70a2                	ld	ra,40(sp)
    80201cfa:	7402                	ld	s0,32(sp)
    80201cfc:	64e2                	ld	s1,24(sp)
    80201cfe:	6942                	ld	s2,16(sp)
    80201d00:	69a2                	ld	s3,8(sp)
    80201d02:	6145                	addi	sp,sp,48
    80201d04:	8082                	ret
    if (!holding(&p->lock))   panic("sched: not holding p->lock");
    80201d06:	00006517          	auipc	a0,0x6
    80201d0a:	82250513          	addi	a0,a0,-2014 # 80207528 <etext+0x528>
    80201d0e:	fffff097          	auipc	ra,0xfffff
    80201d12:	8f0080e7          	jalr	-1808(ra) # 802005fe <panic>
    if (mycpu()->noff != 1)   panic("sched: holding another lock too");
    80201d16:	00006517          	auipc	a0,0x6
    80201d1a:	83250513          	addi	a0,a0,-1998 # 80207548 <etext+0x548>
    80201d1e:	fffff097          	auipc	ra,0xfffff
    80201d22:	8e0080e7          	jalr	-1824(ra) # 802005fe <panic>
    if (p->state == RUNNING)  panic("sched: process is still RUNNING");
    80201d26:	00006517          	auipc	a0,0x6
    80201d2a:	84250513          	addi	a0,a0,-1982 # 80207568 <etext+0x568>
    80201d2e:	fffff097          	auipc	ra,0xfffff
    80201d32:	8d0080e7          	jalr	-1840(ra) # 802005fe <panic>
    if (intr_get())           panic("sched: interrupts are on");
    80201d36:	00006517          	auipc	a0,0x6
    80201d3a:	85250513          	addi	a0,a0,-1966 # 80207588 <etext+0x588>
    80201d3e:	fffff097          	auipc	ra,0xfffff
    80201d42:	8c0080e7          	jalr	-1856(ra) # 802005fe <panic>

0000000080201d46 <yield>:

void yield(void)
{
    80201d46:	1101                	addi	sp,sp,-32
    80201d48:	ec06                	sd	ra,24(sp)
    80201d4a:	e822                	sd	s0,16(sp)
    80201d4c:	e426                	sd	s1,8(sp)
    80201d4e:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    80201d50:	00000097          	auipc	ra,0x0
    80201d54:	9ce080e7          	jalr	-1586(ra) # 8020171e <myproc>
    80201d58:	84aa                	mv	s1,a0
    acquire(&p->lock);
    80201d5a:	fffff097          	auipc	ra,0xfffff
    80201d5e:	5da080e7          	jalr	1498(ra) # 80201334 <acquire>
    p->state = RUNNABLE;
    80201d62:	478d                	li	a5,3
    80201d64:	cc9c                	sw	a5,24(s1)
    sched();
    80201d66:	00000097          	auipc	ra,0x0
    80201d6a:	ef8080e7          	jalr	-264(ra) # 80201c5e <sched>
    release(&p->lock);
    80201d6e:	8526                	mv	a0,s1
    80201d70:	fffff097          	auipc	ra,0xfffff
    80201d74:	678080e7          	jalr	1656(ra) # 802013e8 <release>
}
    80201d78:	60e2                	ld	ra,24(sp)
    80201d7a:	6442                	ld	s0,16(sp)
    80201d7c:	64a2                	ld	s1,8(sp)
    80201d7e:	6105                	addi	sp,sp,32
    80201d80:	8082                	ret

0000000080201d82 <sleep>:

void sleep(void *chan, struct spinlock *lk)
{
    80201d82:	7179                	addi	sp,sp,-48
    80201d84:	f406                	sd	ra,40(sp)
    80201d86:	f022                	sd	s0,32(sp)
    80201d88:	ec26                	sd	s1,24(sp)
    80201d8a:	e84a                	sd	s2,16(sp)
    80201d8c:	e44e                	sd	s3,8(sp)
    80201d8e:	1800                	addi	s0,sp,48
    80201d90:	89aa                	mv	s3,a0
    80201d92:	892e                	mv	s2,a1
    struct proc *p = myproc();
    80201d94:	00000097          	auipc	ra,0x0
    80201d98:	98a080e7          	jalr	-1654(ra) # 8020171e <myproc>
    80201d9c:	84aa                	mv	s1,a0

    /* Acquire p->lock BEFORE releasing lk. If we did it the other way round, a
     * wakeup could slip in between and be lost - the classic missed-wakeup race. */
    acquire(&p->lock);
    80201d9e:	fffff097          	auipc	ra,0xfffff
    80201da2:	596080e7          	jalr	1430(ra) # 80201334 <acquire>
    release(lk);
    80201da6:	854a                	mv	a0,s2
    80201da8:	fffff097          	auipc	ra,0xfffff
    80201dac:	640080e7          	jalr	1600(ra) # 802013e8 <release>

    p->chan  = chan;
    80201db0:	0334b023          	sd	s3,32(s1)
    p->state = SLEEPING;
    80201db4:	4789                	li	a5,2
    80201db6:	cc9c                	sw	a5,24(s1)
    sched();
    80201db8:	00000097          	auipc	ra,0x0
    80201dbc:	ea6080e7          	jalr	-346(ra) # 80201c5e <sched>

    p->chan = 0;
    80201dc0:	0204b023          	sd	zero,32(s1)
    release(&p->lock);
    80201dc4:	8526                	mv	a0,s1
    80201dc6:	fffff097          	auipc	ra,0xfffff
    80201dca:	622080e7          	jalr	1570(ra) # 802013e8 <release>
    acquire(lk);
    80201dce:	854a                	mv	a0,s2
    80201dd0:	fffff097          	auipc	ra,0xfffff
    80201dd4:	564080e7          	jalr	1380(ra) # 80201334 <acquire>
}
    80201dd8:	70a2                	ld	ra,40(sp)
    80201dda:	7402                	ld	s0,32(sp)
    80201ddc:	64e2                	ld	s1,24(sp)
    80201dde:	6942                	ld	s2,16(sp)
    80201de0:	69a2                	ld	s3,8(sp)
    80201de2:	6145                	addi	sp,sp,48
    80201de4:	8082                	ret

0000000080201de6 <wait>:
{
    80201de6:	715d                	addi	sp,sp,-80
    80201de8:	e486                	sd	ra,72(sp)
    80201dea:	e0a2                	sd	s0,64(sp)
    80201dec:	fc26                	sd	s1,56(sp)
    80201dee:	f84a                	sd	s2,48(sp)
    80201df0:	f44e                	sd	s3,40(sp)
    80201df2:	f052                	sd	s4,32(sp)
    80201df4:	ec56                	sd	s5,24(sp)
    80201df6:	e85a                	sd	s6,16(sp)
    80201df8:	e45e                	sd	s7,8(sp)
    80201dfa:	0880                	addi	s0,sp,80
    80201dfc:	8b2a                	mv	s6,a0
    struct proc *p = myproc();
    80201dfe:	00000097          	auipc	ra,0x0
    80201e02:	920080e7          	jalr	-1760(ra) # 8020171e <myproc>
    80201e06:	892a                	mv	s2,a0
    acquire(&wait_lock);
    80201e08:	00028517          	auipc	a0,0x28
    80201e0c:	61050513          	addi	a0,a0,1552 # 8022a418 <wait_lock>
    80201e10:	fffff097          	auipc	ra,0xfffff
    80201e14:	524080e7          	jalr	1316(ra) # 80201334 <acquire>
        int havekids = 0;
    80201e18:	4b81                	li	s7,0
            if (pp->state == ZOMBIE) {
    80201e1a:	4a15                	li	s4,5
            havekids = 1;
    80201e1c:	4a85                	li	s5,1
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201e1e:	0012f997          	auipc	s3,0x12f
    80201e22:	be298993          	addi	s3,s3,-1054 # 80330a00 <tickslock>
    80201e26:	00129497          	auipc	s1,0x129
    80201e2a:	1da48493          	addi	s1,s1,474 # 8032b000 <proc>
        int havekids = 0;
    80201e2e:	875e                	mv	a4,s7
    80201e30:	a051                	j	80201eb4 <wait+0xce>
                int pid = pp->pid;
    80201e32:	0304a983          	lw	s3,48(s1)
                if (addr && copyout(p->pagetable, addr,
    80201e36:	000b0e63          	beqz	s6,80201e52 <wait+0x6c>
    80201e3a:	4691                	li	a3,4
    80201e3c:	02c48613          	addi	a2,s1,44
    80201e40:	85da                	mv	a1,s6
    80201e42:	05093503          	ld	a0,80(s2)
    80201e46:	00001097          	auipc	ra,0x1
    80201e4a:	108080e7          	jalr	264(ra) # 80202f4e <copyout>
    80201e4e:	04054063          	bltz	a0,80201e8e <wait+0xa8>
                freeproc(pp);
    80201e52:	8526                	mv	a0,s1
    80201e54:	fffff097          	auipc	ra,0xfffff
    80201e58:	706080e7          	jalr	1798(ra) # 8020155a <freeproc>
                release(&pp->lock);
    80201e5c:	8526                	mv	a0,s1
    80201e5e:	fffff097          	auipc	ra,0xfffff
    80201e62:	58a080e7          	jalr	1418(ra) # 802013e8 <release>
                release(&wait_lock);
    80201e66:	00028517          	auipc	a0,0x28
    80201e6a:	5b250513          	addi	a0,a0,1458 # 8022a418 <wait_lock>
    80201e6e:	fffff097          	auipc	ra,0xfffff
    80201e72:	57a080e7          	jalr	1402(ra) # 802013e8 <release>
}
    80201e76:	854e                	mv	a0,s3
    80201e78:	60a6                	ld	ra,72(sp)
    80201e7a:	6406                	ld	s0,64(sp)
    80201e7c:	74e2                	ld	s1,56(sp)
    80201e7e:	7942                	ld	s2,48(sp)
    80201e80:	79a2                	ld	s3,40(sp)
    80201e82:	7a02                	ld	s4,32(sp)
    80201e84:	6ae2                	ld	s5,24(sp)
    80201e86:	6b42                	ld	s6,16(sp)
    80201e88:	6ba2                	ld	s7,8(sp)
    80201e8a:	6161                	addi	sp,sp,80
    80201e8c:	8082                	ret
                    release(&pp->lock);
    80201e8e:	8526                	mv	a0,s1
    80201e90:	fffff097          	auipc	ra,0xfffff
    80201e94:	558080e7          	jalr	1368(ra) # 802013e8 <release>
                    release(&wait_lock);
    80201e98:	00028517          	auipc	a0,0x28
    80201e9c:	58050513          	addi	a0,a0,1408 # 8022a418 <wait_lock>
    80201ea0:	fffff097          	auipc	ra,0xfffff
    80201ea4:	548080e7          	jalr	1352(ra) # 802013e8 <release>
                    return -1;
    80201ea8:	59fd                	li	s3,-1
    80201eaa:	b7f1                	j	80201e76 <wait+0x90>
        for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201eac:	16848493          	addi	s1,s1,360
    80201eb0:	03348463          	beq	s1,s3,80201ed8 <wait+0xf2>
            if (pp->parent != p) continue;
    80201eb4:	7c9c                	ld	a5,56(s1)
    80201eb6:	ff279be3          	bne	a5,s2,80201eac <wait+0xc6>
            acquire(&pp->lock);
    80201eba:	8526                	mv	a0,s1
    80201ebc:	fffff097          	auipc	ra,0xfffff
    80201ec0:	478080e7          	jalr	1144(ra) # 80201334 <acquire>
            if (pp->state == ZOMBIE) {
    80201ec4:	4c9c                	lw	a5,24(s1)
    80201ec6:	f74786e3          	beq	a5,s4,80201e32 <wait+0x4c>
            release(&pp->lock);
    80201eca:	8526                	mv	a0,s1
    80201ecc:	fffff097          	auipc	ra,0xfffff
    80201ed0:	51c080e7          	jalr	1308(ra) # 802013e8 <release>
            havekids = 1;
    80201ed4:	8756                	mv	a4,s5
    80201ed6:	bfd9                	j	80201eac <wait+0xc6>
        if (!havekids || p->killed) {
    80201ed8:	cf11                	beqz	a4,80201ef4 <wait+0x10e>
    80201eda:	02892783          	lw	a5,40(s2)
    80201ede:	eb99                	bnez	a5,80201ef4 <wait+0x10e>
        sleep(p, &wait_lock);
    80201ee0:	00028597          	auipc	a1,0x28
    80201ee4:	53858593          	addi	a1,a1,1336 # 8022a418 <wait_lock>
    80201ee8:	854a                	mv	a0,s2
    80201eea:	00000097          	auipc	ra,0x0
    80201eee:	e98080e7          	jalr	-360(ra) # 80201d82 <sleep>
    for (;;) {
    80201ef2:	bf15                	j	80201e26 <wait+0x40>
            release(&wait_lock);
    80201ef4:	00028517          	auipc	a0,0x28
    80201ef8:	52450513          	addi	a0,a0,1316 # 8022a418 <wait_lock>
    80201efc:	fffff097          	auipc	ra,0xfffff
    80201f00:	4ec080e7          	jalr	1260(ra) # 802013e8 <release>
            return -1;
    80201f04:	59fd                	li	s3,-1
    80201f06:	bf85                	j	80201e76 <wait+0x90>

0000000080201f08 <wakeup>:

void wakeup(void *chan)
{
    80201f08:	7139                	addi	sp,sp,-64
    80201f0a:	fc06                	sd	ra,56(sp)
    80201f0c:	f822                	sd	s0,48(sp)
    80201f0e:	f426                	sd	s1,40(sp)
    80201f10:	f04a                	sd	s2,32(sp)
    80201f12:	ec4e                	sd	s3,24(sp)
    80201f14:	e852                	sd	s4,16(sp)
    80201f16:	e456                	sd	s5,8(sp)
    80201f18:	0080                	addi	s0,sp,64
    80201f1a:	8a2a                	mv	s4,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f1c:	00129497          	auipc	s1,0x129
    80201f20:	0e448493          	addi	s1,s1,228 # 8032b000 <proc>
        if (p != myproc()) {
            acquire(&p->lock);
            if (p->state == SLEEPING && p->chan == chan)
    80201f24:	4989                	li	s3,2
                p->state = RUNNABLE;
    80201f26:	4a8d                	li	s5,3
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f28:	0012f917          	auipc	s2,0x12f
    80201f2c:	ad890913          	addi	s2,s2,-1320 # 80330a00 <tickslock>
    80201f30:	a811                	j	80201f44 <wakeup+0x3c>
            release(&p->lock);
    80201f32:	8526                	mv	a0,s1
    80201f34:	fffff097          	auipc	ra,0xfffff
    80201f38:	4b4080e7          	jalr	1204(ra) # 802013e8 <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80201f3c:	16848493          	addi	s1,s1,360
    80201f40:	03248663          	beq	s1,s2,80201f6c <wakeup+0x64>
        if (p != myproc()) {
    80201f44:	fffff097          	auipc	ra,0xfffff
    80201f48:	7da080e7          	jalr	2010(ra) # 8020171e <myproc>
    80201f4c:	fea488e3          	beq	s1,a0,80201f3c <wakeup+0x34>
            acquire(&p->lock);
    80201f50:	8526                	mv	a0,s1
    80201f52:	fffff097          	auipc	ra,0xfffff
    80201f56:	3e2080e7          	jalr	994(ra) # 80201334 <acquire>
            if (p->state == SLEEPING && p->chan == chan)
    80201f5a:	4c9c                	lw	a5,24(s1)
    80201f5c:	fd379be3          	bne	a5,s3,80201f32 <wakeup+0x2a>
    80201f60:	709c                	ld	a5,32(s1)
    80201f62:	fd4798e3          	bne	a5,s4,80201f32 <wakeup+0x2a>
                p->state = RUNNABLE;
    80201f66:	0154ac23          	sw	s5,24(s1)
    80201f6a:	b7e1                	j	80201f32 <wakeup+0x2a>
        }
    }
}
    80201f6c:	70e2                	ld	ra,56(sp)
    80201f6e:	7442                	ld	s0,48(sp)
    80201f70:	74a2                	ld	s1,40(sp)
    80201f72:	7902                	ld	s2,32(sp)
    80201f74:	69e2                	ld	s3,24(sp)
    80201f76:	6a42                	ld	s4,16(sp)
    80201f78:	6aa2                	ld	s5,8(sp)
    80201f7a:	6121                	addi	sp,sp,64
    80201f7c:	8082                	ret

0000000080201f7e <exit>:
{
    80201f7e:	7139                	addi	sp,sp,-64
    80201f80:	fc06                	sd	ra,56(sp)
    80201f82:	f822                	sd	s0,48(sp)
    80201f84:	f426                	sd	s1,40(sp)
    80201f86:	f04a                	sd	s2,32(sp)
    80201f88:	ec4e                	sd	s3,24(sp)
    80201f8a:	e456                	sd	s5,8(sp)
    80201f8c:	0080                	addi	s0,sp,64
    80201f8e:	8aaa                	mv	s5,a0
    struct proc *p = myproc();
    80201f90:	fffff097          	auipc	ra,0xfffff
    80201f94:	78e080e7          	jalr	1934(ra) # 8020171e <myproc>
    80201f98:	892a                	mv	s2,a0
    if (p == initproc) panic("init exiting");
    80201f9a:	0013d797          	auipc	a5,0x13d
    80201f9e:	0767b783          	ld	a5,118(a5) # 8033f010 <initproc>
    80201fa2:	0d050493          	addi	s1,a0,208
    80201fa6:	15050993          	addi	s3,a0,336
    80201faa:	00a78463          	beq	a5,a0,80201fb2 <exit+0x34>
    80201fae:	e852                	sd	s4,16(sp)
    80201fb0:	a01d                	j	80201fd6 <exit+0x58>
    80201fb2:	e852                	sd	s4,16(sp)
    80201fb4:	00005517          	auipc	a0,0x5
    80201fb8:	5f450513          	addi	a0,a0,1524 # 802075a8 <etext+0x5a8>
    80201fbc:	ffffe097          	auipc	ra,0xffffe
    80201fc0:	642080e7          	jalr	1602(ra) # 802005fe <panic>
            fileclose(p->ofile[fd]);
    80201fc4:	00004097          	auipc	ra,0x4
    80201fc8:	a4e080e7          	jalr	-1458(ra) # 80205a12 <fileclose>
            p->ofile[fd] = 0;
    80201fcc:	0004b023          	sd	zero,0(s1)
    for (int fd = 0; fd < NOFILE; fd++) {
    80201fd0:	04a1                	addi	s1,s1,8
    80201fd2:	01348563          	beq	s1,s3,80201fdc <exit+0x5e>
        if (p->ofile[fd]) {
    80201fd6:	6088                	ld	a0,0(s1)
    80201fd8:	f575                	bnez	a0,80201fc4 <exit+0x46>
    80201fda:	bfdd                	j	80201fd0 <exit+0x52>
    iput(p->cwd);
    80201fdc:	15093503          	ld	a0,336(s2)
    80201fe0:	00003097          	auipc	ra,0x3
    80201fe4:	23e080e7          	jalr	574(ra) # 8020521e <iput>
    p->cwd = 0;
    80201fe8:	14093823          	sd	zero,336(s2)
    acquire(&wait_lock);
    80201fec:	00028517          	auipc	a0,0x28
    80201ff0:	42c50513          	addi	a0,a0,1068 # 8022a418 <wait_lock>
    80201ff4:	fffff097          	auipc	ra,0xfffff
    80201ff8:	340080e7          	jalr	832(ra) # 80201334 <acquire>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80201ffc:	00129497          	auipc	s1,0x129
    80202000:	00448493          	addi	s1,s1,4 # 8032b000 <proc>
            pp->parent = initproc;
    80202004:	0013da17          	auipc	s4,0x13d
    80202008:	00ca0a13          	addi	s4,s4,12 # 8033f010 <initproc>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    8020200c:	0012f997          	auipc	s3,0x12f
    80202010:	9f498993          	addi	s3,s3,-1548 # 80330a00 <tickslock>
    80202014:	a821                	j	8020202c <exit+0xae>
            pp->parent = initproc;
    80202016:	000a3503          	ld	a0,0(s4)
    8020201a:	fc88                	sd	a0,56(s1)
            wakeup(initproc);
    8020201c:	00000097          	auipc	ra,0x0
    80202020:	eec080e7          	jalr	-276(ra) # 80201f08 <wakeup>
    for (struct proc *pp = proc; pp < &proc[NPROC]; pp++) {
    80202024:	16848493          	addi	s1,s1,360
    80202028:	01348663          	beq	s1,s3,80202034 <exit+0xb6>
        if (pp->parent == p) {
    8020202c:	7c9c                	ld	a5,56(s1)
    8020202e:	fef91be3          	bne	s2,a5,80202024 <exit+0xa6>
    80202032:	b7d5                	j	80202016 <exit+0x98>
    wakeup(p->parent);
    80202034:	03893503          	ld	a0,56(s2)
    80202038:	00000097          	auipc	ra,0x0
    8020203c:	ed0080e7          	jalr	-304(ra) # 80201f08 <wakeup>
    acquire(&p->lock);
    80202040:	854a                	mv	a0,s2
    80202042:	fffff097          	auipc	ra,0xfffff
    80202046:	2f2080e7          	jalr	754(ra) # 80201334 <acquire>
    p->xstate = status;
    8020204a:	03592623          	sw	s5,44(s2)
    p->state  = ZOMBIE;
    8020204e:	4795                	li	a5,5
    80202050:	00f92c23          	sw	a5,24(s2)
    release(&wait_lock);
    80202054:	00028517          	auipc	a0,0x28
    80202058:	3c450513          	addi	a0,a0,964 # 8022a418 <wait_lock>
    8020205c:	fffff097          	auipc	ra,0xfffff
    80202060:	38c080e7          	jalr	908(ra) # 802013e8 <release>
    sched();                        /* never returns */
    80202064:	00000097          	auipc	ra,0x0
    80202068:	bfa080e7          	jalr	-1030(ra) # 80201c5e <sched>
    panic("zombie exit");
    8020206c:	00005517          	auipc	a0,0x5
    80202070:	54c50513          	addi	a0,a0,1356 # 802075b8 <etext+0x5b8>
    80202074:	ffffe097          	auipc	ra,0xffffe
    80202078:	58a080e7          	jalr	1418(ra) # 802005fe <panic>

000000008020207c <kill>:

int kill(int pid)
{
    8020207c:	7179                	addi	sp,sp,-48
    8020207e:	f406                	sd	ra,40(sp)
    80202080:	f022                	sd	s0,32(sp)
    80202082:	ec26                	sd	s1,24(sp)
    80202084:	e84a                	sd	s2,16(sp)
    80202086:	e44e                	sd	s3,8(sp)
    80202088:	1800                	addi	s0,sp,48
    8020208a:	892a                	mv	s2,a0
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    8020208c:	00129497          	auipc	s1,0x129
    80202090:	f7448493          	addi	s1,s1,-140 # 8032b000 <proc>
    80202094:	0012f997          	auipc	s3,0x12f
    80202098:	96c98993          	addi	s3,s3,-1684 # 80330a00 <tickslock>
        acquire(&p->lock);
    8020209c:	8526                	mv	a0,s1
    8020209e:	fffff097          	auipc	ra,0xfffff
    802020a2:	296080e7          	jalr	662(ra) # 80201334 <acquire>
        if (p->pid == pid) {
    802020a6:	589c                	lw	a5,48(s1)
    802020a8:	01278d63          	beq	a5,s2,802020c2 <kill+0x46>
            p->killed = 1;
            if (p->state == SLEEPING) p->state = RUNNABLE;
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    802020ac:	8526                	mv	a0,s1
    802020ae:	fffff097          	auipc	ra,0xfffff
    802020b2:	33a080e7          	jalr	826(ra) # 802013e8 <release>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    802020b6:	16848493          	addi	s1,s1,360
    802020ba:	ff3491e3          	bne	s1,s3,8020209c <kill+0x20>
    }
    return -1;
    802020be:	557d                	li	a0,-1
    802020c0:	a829                	j	802020da <kill+0x5e>
            p->killed = 1;
    802020c2:	4785                	li	a5,1
    802020c4:	d49c                	sw	a5,40(s1)
            if (p->state == SLEEPING) p->state = RUNNABLE;
    802020c6:	4c98                	lw	a4,24(s1)
    802020c8:	4789                	li	a5,2
    802020ca:	00f70f63          	beq	a4,a5,802020e8 <kill+0x6c>
            release(&p->lock);
    802020ce:	8526                	mv	a0,s1
    802020d0:	fffff097          	auipc	ra,0xfffff
    802020d4:	318080e7          	jalr	792(ra) # 802013e8 <release>
            return 0;
    802020d8:	4501                	li	a0,0
}
    802020da:	70a2                	ld	ra,40(sp)
    802020dc:	7402                	ld	s0,32(sp)
    802020de:	64e2                	ld	s1,24(sp)
    802020e0:	6942                	ld	s2,16(sp)
    802020e2:	69a2                	ld	s3,8(sp)
    802020e4:	6145                	addi	sp,sp,48
    802020e6:	8082                	ret
            if (p->state == SLEEPING) p->state = RUNNABLE;
    802020e8:	478d                	li	a5,3
    802020ea:	cc9c                	sw	a5,24(s1)
    802020ec:	b7cd                	j	802020ce <kill+0x52>

00000000802020ee <procstat>:
 * Parent pointers are protected by wait_lock. The established lock order in
 * fork/exit/wait is wait_lock -> p->lock, so procstat follows the same order.
 * copyout() is performed after releasing both locks because it may fault and
 * must not run while process-table locks are held. */
int procstat(uint64 uaddr, int max)
{
    802020ee:	7159                	addi	sp,sp,-112
    802020f0:	f486                	sd	ra,104(sp)
    802020f2:	f0a2                	sd	s0,96(sp)
    802020f4:	e8ca                	sd	s2,80(sp)
    802020f6:	1880                	addi	s0,sp,112
    struct pstat ps;
    int n = 0;

    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802020f8:	0eb05b63          	blez	a1,802021ee <procstat+0x100>
    802020fc:	eca6                	sd	s1,88(sp)
    802020fe:	e4ce                	sd	s3,72(sp)
    80202100:	e0d2                	sd	s4,64(sp)
    80202102:	fc56                	sd	s5,56(sp)
    80202104:	f85a                	sd	s6,48(sp)
    80202106:	f45e                	sd	s7,40(sp)
    80202108:	f062                	sd	s8,32(sp)
    8020210a:	8aaa                	mv	s5,a0
    8020210c:	8a2e                	mv	s4,a1
    8020210e:	00129497          	auipc	s1,0x129
    80202112:	ef248493          	addi	s1,s1,-270 # 8032b000 <proc>
    int n = 0;
    80202116:	4901                	li	s2,0
        acquire(&wait_lock);
    80202118:	00028997          	auipc	s3,0x28
    8020211c:	30098993          	addi	s3,s3,768 # 8022a418 <wait_lock>
            release(&wait_lock);
            continue;
        }

        ps.pid   = p->pid;
        ps.ppid  = p->parent ? p->parent->pid : 0;
    80202120:	4b81                	li	s7,0
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    80202122:	0012fb17          	auipc	s6,0x12f
    80202126:	8deb0b13          	addi	s6,s6,-1826 # 80330a00 <tickslock>
    8020212a:	a049                	j	802021ac <procstat+0xbe>
            release(&p->lock);
    8020212c:	8526                	mv	a0,s1
    8020212e:	fffff097          	auipc	ra,0xfffff
    80202132:	2ba080e7          	jalr	698(ra) # 802013e8 <release>
            release(&wait_lock);
    80202136:	854e                	mv	a0,s3
    80202138:	fffff097          	auipc	ra,0xfffff
    8020213c:	2b0080e7          	jalr	688(ra) # 802013e8 <release>
            continue;
    80202140:	a085                	j	802021a0 <procstat+0xb2>
        ps.ppid  = p->parent ? p->parent->pid : 0;
    80202142:	5a98                	lw	a4,48(a3)
    80202144:	f8e42a23          	sw	a4,-108(s0)
        ps.state = p->state;
    80202148:	f8f42c23          	sw	a5,-104(s0)
        memmove(ps.name, p->name, sizeof(ps.name));
    8020214c:	4641                	li	a2,16
    8020214e:	158c0593          	addi	a1,s8,344
    80202152:	f9c40513          	addi	a0,s0,-100
    80202156:	ffffe097          	auipc	ra,0xffffe
    8020215a:	56a080e7          	jalr	1386(ra) # 802006c0 <memmove>
        ps.name[sizeof(ps.name) - 1] = 0;
    8020215e:	fa0405a3          	sb	zero,-85(s0)

        release(&p->lock);
    80202162:	8526                	mv	a0,s1
    80202164:	fffff097          	auipc	ra,0xfffff
    80202168:	284080e7          	jalr	644(ra) # 802013e8 <release>
        release(&wait_lock);
    8020216c:	854e                	mv	a0,s3
    8020216e:	fffff097          	auipc	ra,0xfffff
    80202172:	27a080e7          	jalr	634(ra) # 802013e8 <release>

        if (copyout(myproc()->pagetable, uaddr + n * sizeof(ps),
    80202176:	fffff097          	auipc	ra,0xfffff
    8020217a:	5a8080e7          	jalr	1448(ra) # 8020171e <myproc>
    8020217e:	00391593          	slli	a1,s2,0x3
    80202182:	412585b3          	sub	a1,a1,s2
    80202186:	058a                	slli	a1,a1,0x2
    80202188:	46f1                	li	a3,28
    8020218a:	f9040613          	addi	a2,s0,-112
    8020218e:	95d6                	add	a1,a1,s5
    80202190:	6928                	ld	a0,80(a0)
    80202192:	00001097          	auipc	ra,0x1
    80202196:	dbc080e7          	jalr	-580(ra) # 80202f4e <copyout>
    8020219a:	04054c63          	bltz	a0,802021f2 <procstat+0x104>
                    (char *)&ps, sizeof(ps)) < 0)
            return -1;
        n++;
    8020219e:	2905                	addiw	s2,s2,1
    for (struct proc *p = proc; p < &proc[NPROC] && n < max; p++) {
    802021a0:	16848493          	addi	s1,s1,360
    802021a4:	07648063          	beq	s1,s6,80202204 <procstat+0x116>
    802021a8:	03495663          	bge	s2,s4,802021d4 <procstat+0xe6>
        acquire(&wait_lock);
    802021ac:	854e                	mv	a0,s3
    802021ae:	fffff097          	auipc	ra,0xfffff
    802021b2:	186080e7          	jalr	390(ra) # 80201334 <acquire>
        acquire(&p->lock);
    802021b6:	8c26                	mv	s8,s1
    802021b8:	8526                	mv	a0,s1
    802021ba:	fffff097          	auipc	ra,0xfffff
    802021be:	17a080e7          	jalr	378(ra) # 80201334 <acquire>
        if (p->state == UNUSED) {
    802021c2:	4c9c                	lw	a5,24(s1)
    802021c4:	d7a5                	beqz	a5,8020212c <procstat+0x3e>
        ps.pid   = p->pid;
    802021c6:	5898                	lw	a4,48(s1)
    802021c8:	f8e42823          	sw	a4,-112(s0)
        ps.ppid  = p->parent ? p->parent->pid : 0;
    802021cc:	7c94                	ld	a3,56(s1)
    802021ce:	875e                	mv	a4,s7
    802021d0:	faad                	bnez	a3,80202142 <procstat+0x54>
    802021d2:	bf8d                	j	80202144 <procstat+0x56>
    802021d4:	64e6                	ld	s1,88(sp)
    802021d6:	69a6                	ld	s3,72(sp)
    802021d8:	6a06                	ld	s4,64(sp)
    802021da:	7ae2                	ld	s5,56(sp)
    802021dc:	7b42                	ld	s6,48(sp)
    802021de:	7ba2                	ld	s7,40(sp)
    802021e0:	7c02                	ld	s8,32(sp)
    }
    return n;
}
    802021e2:	854a                	mv	a0,s2
    802021e4:	70a6                	ld	ra,104(sp)
    802021e6:	7406                	ld	s0,96(sp)
    802021e8:	6946                	ld	s2,80(sp)
    802021ea:	6165                	addi	sp,sp,112
    802021ec:	8082                	ret
    return n;
    802021ee:	4901                	li	s2,0
    802021f0:	bfcd                	j	802021e2 <procstat+0xf4>
            return -1;
    802021f2:	597d                	li	s2,-1
    802021f4:	64e6                	ld	s1,88(sp)
    802021f6:	69a6                	ld	s3,72(sp)
    802021f8:	6a06                	ld	s4,64(sp)
    802021fa:	7ae2                	ld	s5,56(sp)
    802021fc:	7b42                	ld	s6,48(sp)
    802021fe:	7ba2                	ld	s7,40(sp)
    80202200:	7c02                	ld	s8,32(sp)
    80202202:	b7c5                	j	802021e2 <procstat+0xf4>
    80202204:	64e6                	ld	s1,88(sp)
    80202206:	69a6                	ld	s3,72(sp)
    80202208:	6a06                	ld	s4,64(sp)
    8020220a:	7ae2                	ld	s5,56(sp)
    8020220c:	7b42                	ld	s6,48(sp)
    8020220e:	7ba2                	ld	s7,40(sp)
    80202210:	7c02                	ld	s8,32(sp)
    80202212:	bfc1                	j	802021e2 <procstat+0xf4>

0000000080202214 <procdump>:

void procdump(void)
{
    80202214:	7179                	addi	sp,sp,-48
    80202216:	f406                	sd	ra,40(sp)
    80202218:	f022                	sd	s0,32(sp)
    8020221a:	ec26                	sd	s1,24(sp)
    8020221c:	e84a                	sd	s2,16(sp)
    8020221e:	e44e                	sd	s3,8(sp)
    80202220:	e052                	sd	s4,0(sp)
    80202222:	1800                	addi	s0,sp,48
    static const char *st[] = {
        [UNUSED]"unused", [USED]"used", [SLEEPING]"sleep",
        [RUNNABLE]"runble", [RUNNING]"run", [ZOMBIE]"zombie"
    };
    printf("\n--- process table ---\n");
    80202224:	00005517          	auipc	a0,0x5
    80202228:	3a450513          	addi	a0,a0,932 # 802075c8 <etext+0x5c8>
    8020222c:	ffffe097          	auipc	ra,0xffffe
    80202230:	160080e7          	jalr	352(ra) # 8020038c <printf>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202234:	00129497          	auipc	s1,0x129
    80202238:	f2448493          	addi	s1,s1,-220 # 8032b158 <proc+0x158>
    8020223c:	0012f917          	auipc	s2,0x12f
    80202240:	91c90913          	addi	s2,s2,-1764 # 80330b58 <bcache+0x98>
        if (p->state == UNUSED) continue;
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    80202244:	00006a17          	auipc	s4,0x6
    80202248:	ba4a0a13          	addi	s4,s4,-1116 # 80207de8 <st.0>
    8020224c:	00005997          	auipc	s3,0x5
    80202250:	39498993          	addi	s3,s3,916 # 802075e0 <etext+0x5e0>
    80202254:	a029                	j	8020225e <procdump+0x4a>
    for (struct proc *p = proc; p < &proc[NPROC]; p++) {
    80202256:	16848493          	addi	s1,s1,360
    8020225a:	03248463          	beq	s1,s2,80202282 <procdump+0x6e>
        if (p->state == UNUSED) continue;
    8020225e:	ec04a783          	lw	a5,-320(s1)
    80202262:	dbf5                	beqz	a5,80202256 <procdump+0x42>
        printf("pid %d %s %s\n", p->pid, st[p->state], p->name);
    80202264:	02079713          	slli	a4,a5,0x20
    80202268:	01d75793          	srli	a5,a4,0x1d
    8020226c:	97d2                	add	a5,a5,s4
    8020226e:	86a6                	mv	a3,s1
    80202270:	6390                	ld	a2,0(a5)
    80202272:	ed84a583          	lw	a1,-296(s1)
    80202276:	854e                	mv	a0,s3
    80202278:	ffffe097          	auipc	ra,0xffffe
    8020227c:	114080e7          	jalr	276(ra) # 8020038c <printf>
    80202280:	bfd9                	j	80202256 <procdump+0x42>
    }
}
    80202282:	70a2                	ld	ra,40(sp)
    80202284:	7402                	ld	s0,32(sp)
    80202286:	64e2                	ld	s1,24(sp)
    80202288:	6942                	ld	s2,16(sp)
    8020228a:	69a2                	ld	s3,8(sp)
    8020228c:	6a02                	ld	s4,0(sp)
    8020228e:	6145                	addi	sp,sp,48
    80202290:	8082                	ret

0000000080202292 <swtch>:
# L7 - context switch. Only the CALLEE-SAVED registers need saving: the C
# calling convention says the caller already spilled anything else it cared about.
# Nine loads, nine stores, one ret - and a process wakes up years later, unaware.
        .globl swtch
swtch:
        sd ra,  0(a0)
    80202292:	00153023          	sd	ra,0(a0)
        sd sp,  8(a0)
    80202296:	00253423          	sd	sp,8(a0)
        sd s0,  16(a0)
    8020229a:	e900                	sd	s0,16(a0)
        sd s1,  24(a0)
    8020229c:	ed04                	sd	s1,24(a0)
        sd s2,  32(a0)
    8020229e:	03253023          	sd	s2,32(a0)
        sd s3,  40(a0)
    802022a2:	03353423          	sd	s3,40(a0)
        sd s4,  48(a0)
    802022a6:	03453823          	sd	s4,48(a0)
        sd s5,  56(a0)
    802022aa:	03553c23          	sd	s5,56(a0)
        sd s6,  64(a0)
    802022ae:	05653023          	sd	s6,64(a0)
        sd s7,  72(a0)
    802022b2:	05753423          	sd	s7,72(a0)
        sd s8,  80(a0)
    802022b6:	05853823          	sd	s8,80(a0)
        sd s9,  88(a0)
    802022ba:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    802022be:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    802022c2:	07b53423          	sd	s11,104(a0)

        ld ra,  0(a1)
    802022c6:	0005b083          	ld	ra,0(a1)
        ld sp,  8(a1)
    802022ca:	0085b103          	ld	sp,8(a1)
        ld s0,  16(a1)
    802022ce:	6980                	ld	s0,16(a1)
        ld s1,  24(a1)
    802022d0:	6d84                	ld	s1,24(a1)
        ld s2,  32(a1)
    802022d2:	0205b903          	ld	s2,32(a1)
        ld s3,  40(a1)
    802022d6:	0285b983          	ld	s3,40(a1)
        ld s4,  48(a1)
    802022da:	0305ba03          	ld	s4,48(a1)
        ld s5,  56(a1)
    802022de:	0385ba83          	ld	s5,56(a1)
        ld s6,  64(a1)
    802022e2:	0405bb03          	ld	s6,64(a1)
        ld s7,  72(a1)
    802022e6:	0485bb83          	ld	s7,72(a1)
        ld s8,  80(a1)
    802022ea:	0505bc03          	ld	s8,80(a1)
        ld s9,  88(a1)
    802022ee:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    802022f2:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    802022f6:	0685bd83          	ld	s11,104(a1)
        ret
    802022fa:	8082                	ret

00000000802022fc <cause_str>:
    }
    return 0;
}

static const char *cause_str(uint64 c)
{
    802022fc:	1141                	addi	sp,sp,-16
    802022fe:	e422                	sd	s0,8(sp)
    80202300:	0800                	addi	s0,sp,16
    switch (c) {
    80202302:	47bd                	li	a5,15
    80202304:	06a7ea63          	bltu	a5,a0,80202378 <cause_str+0x7c>
    80202308:	050a                	slli	a0,a0,0x2
    8020230a:	00006717          	auipc	a4,0x6
    8020230e:	b0e70713          	addi	a4,a4,-1266 # 80207e18 <st.0+0x30>
    80202312:	953a                	add	a0,a0,a4
    80202314:	411c                	lw	a5,0(a0)
    80202316:	97ba                	add	a5,a5,a4
    80202318:	8782                	jr	a5
    case 0:  return "instruction address misaligned";
    8020231a:	00005517          	auipc	a0,0x5
    8020231e:	30650513          	addi	a0,a0,774 # 80207620 <etext+0x620>
    80202322:	a029                	j	8020232c <cause_str+0x30>
    case 1:  return "instruction access fault";
    case 2:  return "illegal instruction";
    80202324:	00005517          	auipc	a0,0x5
    80202328:	33c50513          	addi	a0,a0,828 # 80207660 <etext+0x660>
    case 12: return "instruction page fault";
    case 13: return "load page fault";
    case 15: return "store page fault";
    default: return "unknown";
    }
}
    8020232c:	6422                	ld	s0,8(sp)
    8020232e:	0141                	addi	sp,sp,16
    80202330:	8082                	ret
    case 3:  return "breakpoint";
    80202332:	00005517          	auipc	a0,0x5
    80202336:	34650513          	addi	a0,a0,838 # 80207678 <etext+0x678>
    8020233a:	bfcd                	j	8020232c <cause_str+0x30>
    case 5:  return "load access fault";
    8020233c:	00005517          	auipc	a0,0x5
    80202340:	34c50513          	addi	a0,a0,844 # 80207688 <etext+0x688>
    80202344:	b7e5                	j	8020232c <cause_str+0x30>
    case 7:  return "store access fault";
    80202346:	00005517          	auipc	a0,0x5
    8020234a:	35a50513          	addi	a0,a0,858 # 802076a0 <etext+0x6a0>
    8020234e:	bff9                	j	8020232c <cause_str+0x30>
    case 8:  return "ecall from user";
    80202350:	00005517          	auipc	a0,0x5
    80202354:	36850513          	addi	a0,a0,872 # 802076b8 <etext+0x6b8>
    80202358:	bfd1                	j	8020232c <cause_str+0x30>
    case 12: return "instruction page fault";
    8020235a:	00005517          	auipc	a0,0x5
    8020235e:	36e50513          	addi	a0,a0,878 # 802076c8 <etext+0x6c8>
    80202362:	b7e9                	j	8020232c <cause_str+0x30>
    case 13: return "load page fault";
    80202364:	00005517          	auipc	a0,0x5
    80202368:	37c50513          	addi	a0,a0,892 # 802076e0 <etext+0x6e0>
    8020236c:	b7c1                	j	8020232c <cause_str+0x30>
    case 15: return "store page fault";
    8020236e:	00005517          	auipc	a0,0x5
    80202372:	38250513          	addi	a0,a0,898 # 802076f0 <etext+0x6f0>
    80202376:	bf5d                	j	8020232c <cause_str+0x30>
    default: return "unknown";
    80202378:	00005517          	auipc	a0,0x5
    8020237c:	39050513          	addi	a0,a0,912 # 80207708 <etext+0x708>
    80202380:	b775                	j	8020232c <cause_str+0x30>
    switch (c) {
    80202382:	00005517          	auipc	a0,0x5
    80202386:	2be50513          	addi	a0,a0,702 # 80207640 <etext+0x640>
    8020238a:	b74d                	j	8020232c <cause_str+0x30>

000000008020238c <devintr>:
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    8020238c:	142027f3          	csrr	a5,scause
    if (!(scause & 0x8000000000000000UL)) return 0;   /* top bit = interrupt */
    80202390:	4501                	li	a0,0
    80202392:	1007d063          	bgez	a5,80202492 <devintr+0x106>
{
    80202396:	1101                	addi	sp,sp,-32
    80202398:	ec06                	sd	ra,24(sp)
    8020239a:	e822                	sd	s0,16(sp)
    8020239c:	1000                	addi	s0,sp,32
    uint64 code = scause & 0xff;
    8020239e:	0ff7f793          	zext.b	a5,a5
    if (code == 9) {                     /* supervisor external -> PLIC */
    802023a2:	4725                	li	a4,9
    802023a4:	00e78a63          	beq	a5,a4,802023b8 <devintr+0x2c>
    if (code == 5) {
    802023a8:	4715                	li	a4,5
    return 0;
    802023aa:	4501                	li	a0,0
    if (code == 5) {
    802023ac:	08e78263          	beq	a5,a4,80202430 <devintr+0xa4>
}
    802023b0:	60e2                	ld	ra,24(sp)
    802023b2:	6442                	ld	s0,16(sp)
    802023b4:	6105                	addi	sp,sp,32
    802023b6:	8082                	ret
    802023b8:	e426                	sd	s1,8(sp)
        int irq = hal_intc_claim();
    802023ba:	00004097          	auipc	ra,0x4
    802023be:	d10080e7          	jalr	-752(ra) # 802060ca <hal_intc_claim>
    802023c2:	84aa                	mv	s1,a0
        if (irq == fdt.uart_irq) {
    802023c4:	00027797          	auipc	a5,0x27
    802023c8:	c747a783          	lw	a5,-908(a5) # 80229038 <fdt+0x20>
    802023cc:	00a78663          	beq	a5,a0,802023d8 <devintr+0x4c>
        return 1;
    802023d0:	4505                	li	a0,1
        } else if (irq && irq == hal_block_irq()) {
    802023d2:	e09d                	bnez	s1,802023f8 <devintr+0x6c>
    802023d4:	64a2                	ld	s1,8(sp)
    802023d6:	bfe9                	j	802023b0 <devintr+0x24>
            int c = hal_console_getc();
    802023d8:	00004097          	auipc	ra,0x4
    802023dc:	e56080e7          	jalr	-426(ra) # 8020622e <hal_console_getc>
            if (c != -1) consoleintr(c);
    802023e0:	57fd                	li	a5,-1
    802023e2:	00f51663          	bne	a0,a5,802023ee <devintr+0x62>
        return 1;
    802023e6:	4505                	li	a0,1
        if (irq) hal_intc_complete(irq);
    802023e8:	e49d                	bnez	s1,80202416 <devintr+0x8a>
    802023ea:	64a2                	ld	s1,8(sp)
    802023ec:	b7d1                	j	802023b0 <devintr+0x24>
            if (c != -1) consoleintr(c);
    802023ee:	00002097          	auipc	ra,0x2
    802023f2:	e6c080e7          	jalr	-404(ra) # 8020425a <consoleintr>
    802023f6:	bfc5                	j	802023e6 <devintr+0x5a>
        } else if (irq && irq == hal_block_irq()) {
    802023f8:	00004097          	auipc	ra,0x4
    802023fc:	ed6080e7          	jalr	-298(ra) # 802062ce <hal_block_irq>
    80202400:	02950363          	beq	a0,s1,80202426 <devintr+0x9a>
            printf("devintr: unexpected PLIC irq %d\n", irq);
    80202404:	85a6                	mv	a1,s1
    80202406:	00005517          	auipc	a0,0x5
    8020240a:	30a50513          	addi	a0,a0,778 # 80207710 <etext+0x710>
    8020240e:	ffffe097          	auipc	ra,0xffffe
    80202412:	f7e080e7          	jalr	-130(ra) # 8020038c <printf>
        if (irq) hal_intc_complete(irq);
    80202416:	8526                	mv	a0,s1
    80202418:	00004097          	auipc	ra,0x4
    8020241c:	cde080e7          	jalr	-802(ra) # 802060f6 <hal_intc_complete>
        return 1;
    80202420:	4505                	li	a0,1
    80202422:	64a2                	ld	s1,8(sp)
    80202424:	b771                	j	802023b0 <devintr+0x24>
            hal_block_intr();
    80202426:	00004097          	auipc	ra,0x4
    8020242a:	35a080e7          	jalr	858(ra) # 80206780 <hal_block_intr>
    8020242e:	b7e5                	j	80202416 <devintr+0x8a>
    80202430:	e426                	sd	s1,8(sp)
        if (hal_hart_id() == boot_hart_id()) { /* one hart keeps the clock */
    80202432:	00004097          	auipc	ra,0x4
    80202436:	cf0080e7          	jalr	-784(ra) # 80206122 <hal_hart_id>
    8020243a:	84aa                	mv	s1,a0
    8020243c:	ffffe097          	auipc	ra,0xffffe
    80202440:	bea080e7          	jalr	-1046(ra) # 80200026 <boot_hart_id>
    80202444:	00a48d63          	beq	s1,a0,8020245e <devintr+0xd2>
        hal_timer_next(1000000);
    80202448:	000f4537          	lui	a0,0xf4
    8020244c:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    80202450:	00004097          	auipc	ra,0x4
    80202454:	d42080e7          	jalr	-702(ra) # 80206192 <hal_timer_next>
        return 2;
    80202458:	4509                	li	a0,2
    8020245a:	64a2                	ld	s1,8(sp)
    8020245c:	bf91                	j	802023b0 <devintr+0x24>
            acquire(&tickslock);
    8020245e:	0012e497          	auipc	s1,0x12e
    80202462:	5a248493          	addi	s1,s1,1442 # 80330a00 <tickslock>
    80202466:	8526                	mv	a0,s1
    80202468:	fffff097          	auipc	ra,0xfffff
    8020246c:	ecc080e7          	jalr	-308(ra) # 80201334 <acquire>
            ticks++;
    80202470:	0013d517          	auipc	a0,0x13d
    80202474:	ba850513          	addi	a0,a0,-1112 # 8033f018 <ticks>
    80202478:	611c                	ld	a5,0(a0)
    8020247a:	0785                	addi	a5,a5,1
    8020247c:	e11c                	sd	a5,0(a0)
            wakeup(&ticks);
    8020247e:	00000097          	auipc	ra,0x0
    80202482:	a8a080e7          	jalr	-1398(ra) # 80201f08 <wakeup>
            release(&tickslock);
    80202486:	8526                	mv	a0,s1
    80202488:	fffff097          	auipc	ra,0xfffff
    8020248c:	f60080e7          	jalr	-160(ra) # 802013e8 <release>
    80202490:	bf65                	j	80202448 <devintr+0xbc>
}
    80202492:	8082                	ret

0000000080202494 <trapinit_hart>:
{
    80202494:	1101                	addi	sp,sp,-32
    80202496:	ec06                	sd	ra,24(sp)
    80202498:	e822                	sd	s0,16(sp)
    8020249a:	e426                	sd	s1,8(sp)
    8020249c:	1000                	addi	s0,sp,32
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    8020249e:	00000797          	auipc	a5,0x0
    802024a2:	32278793          	addi	a5,a5,802 # 802027c0 <kernelvec>
    802024a6:	10579073          	csrw	stvec,a5
    hal_intc_enable(fdt.uart_irq);              /* priority 1; 0 = never fires */
    802024aa:	00027497          	auipc	s1,0x27
    802024ae:	b6e48493          	addi	s1,s1,-1170 # 80229018 <fdt>
    802024b2:	5088                	lw	a0,32(s1)
    802024b4:	00004097          	auipc	ra,0x4
    802024b8:	b8c080e7          	jalr	-1140(ra) # 80206040 <hal_intc_enable>
    hal_intc_hart_init(hal_hart_id());
    802024bc:	00004097          	auipc	ra,0x4
    802024c0:	c66080e7          	jalr	-922(ra) # 80206122 <hal_hart_id>
    802024c4:	00004097          	auipc	ra,0x4
    802024c8:	b9c080e7          	jalr	-1124(ra) # 80206060 <hal_intc_hart_init>
    hal_intc_enable_hart(hal_hart_id(), fdt.uart_irq);
    802024cc:	00004097          	auipc	ra,0x4
    802024d0:	c56080e7          	jalr	-938(ra) # 80206122 <hal_hart_id>
    802024d4:	508c                	lw	a1,32(s1)
    802024d6:	00004097          	auipc	ra,0x4
    802024da:	bb0080e7          	jalr	-1104(ra) # 80206086 <hal_intc_enable_hart>
    if (hal_block_irq()) {
    802024de:	00004097          	auipc	ra,0x4
    802024e2:	df0080e7          	jalr	-528(ra) # 802062ce <hal_block_irq>
    802024e6:	e915                	bnez	a0,8020251a <trapinit_hart+0x86>
static inline uint64 r_sie(void){ uint64 x; asm volatile("csrr %0, sie":"=r"(x)); return x; }
    802024e8:	104027f3          	csrr	a5,sie
    w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    802024ec:	2227e793          	ori	a5,a5,546
static inline void   w_sie(uint64 x){ asm volatile("csrw sie, %0"::"r"(x)); }
    802024f0:	10479073          	csrw	sie,a5
    hal_timer_next(1000000);
    802024f4:	000f4537          	lui	a0,0xf4
    802024f8:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    802024fc:	00004097          	auipc	ra,0x4
    80202500:	c96080e7          	jalr	-874(ra) # 80206192 <hal_timer_next>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202504:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    80202508:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    8020250c:	10079073          	csrw	sstatus,a5
}
    80202510:	60e2                	ld	ra,24(sp)
    80202512:	6442                	ld	s0,16(sp)
    80202514:	64a2                	ld	s1,8(sp)
    80202516:	6105                	addi	sp,sp,32
    80202518:	8082                	ret
        hal_intc_enable(hal_block_irq());
    8020251a:	00004097          	auipc	ra,0x4
    8020251e:	db4080e7          	jalr	-588(ra) # 802062ce <hal_block_irq>
    80202522:	00004097          	auipc	ra,0x4
    80202526:	b1e080e7          	jalr	-1250(ra) # 80206040 <hal_intc_enable>
        hal_intc_enable_hart(hal_hart_id(), hal_block_irq());
    8020252a:	00004097          	auipc	ra,0x4
    8020252e:	bf8080e7          	jalr	-1032(ra) # 80206122 <hal_hart_id>
    80202532:	84aa                	mv	s1,a0
    80202534:	00004097          	auipc	ra,0x4
    80202538:	d9a080e7          	jalr	-614(ra) # 802062ce <hal_block_irq>
    8020253c:	85aa                	mv	a1,a0
    8020253e:	8526                	mv	a0,s1
    80202540:	00004097          	auipc	ra,0x4
    80202544:	b46080e7          	jalr	-1210(ra) # 80206086 <hal_intc_enable_hart>
    80202548:	b745                	j	802024e8 <trapinit_hart+0x54>

000000008020254a <kerneltrap>:

/* Trap while already in the kernel. */
void kerneltrap(void)
{
    8020254a:	7179                	addi	sp,sp,-48
    8020254c:	f406                	sd	ra,40(sp)
    8020254e:	f022                	sd	s0,32(sp)
    80202550:	ec26                	sd	s1,24(sp)
    80202552:	e84a                	sd	s2,16(sp)
    80202554:	e44e                	sd	s3,8(sp)
    80202556:	1800                	addi	s0,sp,48
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    80202558:	14102973          	csrr	s2,sepc
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020255c:	100024f3          	csrr	s1,sstatus
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    80202560:	142029f3          	csrr	s3,scause
    uint64 sepc     = r_sepc();
    uint64 sstatus  = r_sstatus();
    uint64 scause   = r_scause();

    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    80202564:	1004f793          	andi	a5,s1,256
    80202568:	cb85                	beqz	a5,80202598 <kerneltrap+0x4e>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020256a:	100027f3          	csrr	a5,sstatus
static inline int  intr_get(void){ return (r_sstatus() & SSTATUS_SIE) != 0; }
    8020256e:	8b89                	andi	a5,a5,2
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    80202570:	ef85                	bnez	a5,802025a8 <kerneltrap+0x5e>

    int which = devintr();
    80202572:	00000097          	auipc	ra,0x0
    80202576:	e1a080e7          	jalr	-486(ra) # 8020238c <devintr>
    if (which == 0) {
    8020257a:	cd1d                	beqz	a0,802025b8 <kerneltrap+0x6e>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
        panic("kernel exception");
    }
    /* Timer: give up the CPU, but only if we are running a process. */
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    8020257c:	4789                	li	a5,2
    8020257e:	06f50463          	beq	a0,a5,802025e6 <kerneltrap+0x9c>
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    80202582:	14191073          	csrw	sepc,s2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202586:	10049073          	csrw	sstatus,s1
        yield();

    /* yield() may have run other code; restore what sret needs. */
    w_sepc(sepc);
    w_sstatus(sstatus);
}
    8020258a:	70a2                	ld	ra,40(sp)
    8020258c:	7402                	ld	s0,32(sp)
    8020258e:	64e2                	ld	s1,24(sp)
    80202590:	6942                	ld	s2,16(sp)
    80202592:	69a2                	ld	s3,8(sp)
    80202594:	6145                	addi	sp,sp,48
    80202596:	8082                	ret
    if ((sstatus & SSTATUS_SPP) == 0) panic("kerneltrap: not from S-mode");
    80202598:	00005517          	auipc	a0,0x5
    8020259c:	1a050513          	addi	a0,a0,416 # 80207738 <etext+0x738>
    802025a0:	ffffe097          	auipc	ra,0xffffe
    802025a4:	05e080e7          	jalr	94(ra) # 802005fe <panic>
    if (intr_get()) panic("kerneltrap: interrupts were enabled");
    802025a8:	00005517          	auipc	a0,0x5
    802025ac:	1b050513          	addi	a0,a0,432 # 80207758 <etext+0x758>
    802025b0:	ffffe097          	auipc	ra,0xffffe
    802025b4:	04e080e7          	jalr	78(ra) # 802005fe <panic>
        printf("\nkerneltrap: %s\n", cause_str(scause & 0xff));
    802025b8:	0ff9f513          	zext.b	a0,s3
    802025bc:	00000097          	auipc	ra,0x0
    802025c0:	d40080e7          	jalr	-704(ra) # 802022fc <cause_str>
    802025c4:	85aa                	mv	a1,a0
    802025c6:	00005517          	auipc	a0,0x5
    802025ca:	1ba50513          	addi	a0,a0,442 # 80207780 <etext+0x780>
    802025ce:	ffffe097          	auipc	ra,0xffffe
    802025d2:	dbe080e7          	jalr	-578(ra) # 8020038c <printf>
        panic("kernel exception");
    802025d6:	00005517          	auipc	a0,0x5
    802025da:	1c250513          	addi	a0,a0,450 # 80207798 <etext+0x798>
    802025de:	ffffe097          	auipc	ra,0xffffe
    802025e2:	020080e7          	jalr	32(ra) # 802005fe <panic>
    if (which == 2 && myproc() && myproc()->state == RUNNING)
    802025e6:	fffff097          	auipc	ra,0xfffff
    802025ea:	138080e7          	jalr	312(ra) # 8020171e <myproc>
    802025ee:	d951                	beqz	a0,80202582 <kerneltrap+0x38>
    802025f0:	fffff097          	auipc	ra,0xfffff
    802025f4:	12e080e7          	jalr	302(ra) # 8020171e <myproc>
    802025f8:	4d18                	lw	a4,24(a0)
    802025fa:	4791                	li	a5,4
    802025fc:	f8f713e3          	bne	a4,a5,80202582 <kerneltrap+0x38>
        yield();
    80202600:	fffff097          	auipc	ra,0xfffff
    80202604:	746080e7          	jalr	1862(ra) # 80201d46 <yield>
    80202608:	bfad                	j	80202582 <kerneltrap+0x38>

000000008020260a <usertrapret>:
    if (p->killed) exit(-1);
    usertrapret();
}

void usertrapret(void)
{
    8020260a:	1141                	addi	sp,sp,-16
    8020260c:	e406                	sd	ra,8(sp)
    8020260e:	e022                	sd	s0,0(sp)
    80202610:	0800                	addi	s0,sp,16
    struct proc *p = myproc();
    80202612:	fffff097          	auipc	ra,0xfffff
    80202616:	10c080e7          	jalr	268(ra) # 8020171e <myproc>
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020261a:	100027f3          	csrr	a5,sstatus
static inline void intr_off(void){ w_sstatus(r_sstatus() & ~SSTATUS_SIE); }
    8020261e:	9bf5                	andi	a5,a5,-3
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202620:	10079073          	csrw	sstatus,a5
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    80202624:	00000797          	auipc	a5,0x0
    80202628:	1fc78793          	addi	a5,a5,508 # 80202820 <uservec>
    8020262c:	10579073          	csrw	stvec,a5

    intr_off();                       /* no interrupts between stvec and sret */
    w_stvec((uint64)uservec);

    p->tf->kernel_satp   = r_satp();
    80202630:	6d3c                	ld	a5,88(a0)
static inline uint64 r_satp(void){ uint64 x; asm volatile("csrr %0, satp":"=r"(x)); return x; }
    80202632:	18002773          	csrr	a4,satp
    80202636:	e398                	sd	a4,0(a5)
    p->tf->kernel_sp     = p->kstack + 4 * PGSIZE;   /* top of the kernel stack */
    80202638:	6d38                	ld	a4,88(a0)
    8020263a:	613c                	ld	a5,64(a0)
    8020263c:	6691                	lui	a3,0x4
    8020263e:	97b6                	add	a5,a5,a3
    80202640:	e71c                	sd	a5,8(a4)
    p->tf->kernel_trap   = (uint64)usertrap;
    80202642:	6d3c                	ld	a5,88(a0)
    80202644:	00000717          	auipc	a4,0x0
    80202648:	03870713          	addi	a4,a4,56 # 8020267c <usertrap>
    8020264c:	eb98                	sd	a4,16(a5)
    p->tf->kernel_hartid = r_tp();
    8020264e:	6d3c                	ld	a5,88(a0)
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    80202650:	8712                	mv	a4,tp
    80202652:	f398                	sd	a4,32(a5)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202654:	100027f3          	csrr	a5,sstatus

    uint64 x = r_sstatus();
    x &= ~SSTATUS_SPP;                /* SPP=0 -> sret drops us to U-mode */
    80202658:	eff7f793          	andi	a5,a5,-257
    x |= SSTATUS_SPIE;                /* re-enable interrupts in user mode */
    8020265c:	0207e793          	ori	a5,a5,32
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202660:	10079073          	csrw	sstatus,a5
    w_sstatus(x);
    w_sepc(p->tf->epc);
    80202664:	6d28                	ld	a0,88(a0)
static inline void   w_sepc(uint64 x){ asm volatile("csrw sepc, %0"::"r"(x)); }
    80202666:	6d1c                	ld	a5,24(a0)
    80202668:	14179073          	csrw	sepc,a5

    userret(p->tf);
    8020266c:	00000097          	auipc	ra,0x0
    80202670:	240080e7          	jalr	576(ra) # 802028ac <userret>
}
    80202674:	60a2                	ld	ra,8(sp)
    80202676:	6402                	ld	s0,0(sp)
    80202678:	0141                	addi	sp,sp,16
    8020267a:	8082                	ret

000000008020267c <usertrap>:
{
    8020267c:	7179                	addi	sp,sp,-48
    8020267e:	f406                	sd	ra,40(sp)
    80202680:	f022                	sd	s0,32(sp)
    80202682:	1800                	addi	s0,sp,48
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    80202684:	100027f3          	csrr	a5,sstatus
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    80202688:	1007f793          	andi	a5,a5,256
    8020268c:	efa9                	bnez	a5,802026e6 <usertrap+0x6a>
    8020268e:	ec26                	sd	s1,24(sp)
    80202690:	e84a                	sd	s2,16(sp)
static inline void   w_stvec(uint64 x){ asm volatile("csrw stvec, %0"::"r"(x)); }
    80202692:	00000797          	auipc	a5,0x0
    80202696:	12e78793          	addi	a5,a5,302 # 802027c0 <kernelvec>
    8020269a:	10579073          	csrw	stvec,a5
    struct proc *p = myproc();
    8020269e:	fffff097          	auipc	ra,0xfffff
    802026a2:	080080e7          	jalr	128(ra) # 8020171e <myproc>
    802026a6:	84aa                	mv	s1,a0
    p->tf->epc = r_sepc();
    802026a8:	6d3c                	ld	a5,88(a0)
static inline uint64 r_sepc(void){ uint64 x; asm volatile("csrr %0, sepc":"=r"(x)); return x; }
    802026aa:	14102773          	csrr	a4,sepc
    802026ae:	ef98                	sd	a4,24(a5)
static inline uint64 r_scause(void){ uint64 x; asm volatile("csrr %0, scause":"=r"(x)); return x; }
    802026b0:	14202973          	csrr	s2,scause
    if (scause == 8) {               /* ecall: a system call */
    802026b4:	47a1                	li	a5,8
    802026b6:	04f90463          	beq	s2,a5,802026fe <usertrap+0x82>
    } else if (scause == 15 || scause == 13) {   /* store / load page fault */
    802026ba:	ffd97793          	andi	a5,s2,-3
    802026be:	4735                	li	a4,13
    802026c0:	08e78263          	beq	a5,a4,80202744 <usertrap+0xc8>
        int which = devintr();
    802026c4:	00000097          	auipc	ra,0x0
    802026c8:	cc8080e7          	jalr	-824(ra) # 8020238c <devintr>
        if (which == 0) {
    802026cc:	c95d                	beqz	a0,80202782 <usertrap+0x106>
        if (which == 2 && p->state == RUNNING) yield();
    802026ce:	4789                	li	a5,2
    802026d0:	04f51763          	bne	a0,a5,8020271e <usertrap+0xa2>
    802026d4:	4c98                	lw	a4,24(s1)
    802026d6:	4791                	li	a5,4
    802026d8:	04f71363          	bne	a4,a5,8020271e <usertrap+0xa2>
    802026dc:	fffff097          	auipc	ra,0xfffff
    802026e0:	66a080e7          	jalr	1642(ra) # 80201d46 <yield>
    802026e4:	a82d                	j	8020271e <usertrap+0xa2>
    802026e6:	ec26                	sd	s1,24(sp)
    802026e8:	e84a                	sd	s2,16(sp)
    802026ea:	e44e                	sd	s3,8(sp)
    802026ec:	e052                	sd	s4,0(sp)
    if (r_sstatus() & SSTATUS_SPP) panic("usertrap: came from S-mode");
    802026ee:	00005517          	auipc	a0,0x5
    802026f2:	0c250513          	addi	a0,a0,194 # 802077b0 <etext+0x7b0>
    802026f6:	ffffe097          	auipc	ra,0xffffe
    802026fa:	f08080e7          	jalr	-248(ra) # 802005fe <panic>
        if (p->killed) exit(-1);
    802026fe:	551c                	lw	a5,40(a0)
    80202700:	eb9d                	bnez	a5,80202736 <usertrap+0xba>
        p->tf->epc += 4;             /* return AFTER the ecall, not onto it */
    80202702:	6d38                	ld	a4,88(a0)
    80202704:	6f1c                	ld	a5,24(a4)
    80202706:	0791                	addi	a5,a5,4
    80202708:	ef1c                	sd	a5,24(a4)
static inline uint64 r_sstatus(void){ uint64 x; asm volatile("csrr %0, sstatus":"=r"(x)); return x; }
    8020270a:	100027f3          	csrr	a5,sstatus
static inline void intr_on(void){ w_sstatus(r_sstatus() | SSTATUS_SIE); }
    8020270e:	0027e793          	ori	a5,a5,2
static inline void   w_sstatus(uint64 x){ asm volatile("csrw sstatus, %0"::"r"(x)); }
    80202712:	10079073          	csrw	sstatus,a5
        syscall();
    80202716:	00001097          	auipc	ra,0x1
    8020271a:	e08080e7          	jalr	-504(ra) # 8020351e <syscall>
    if (p->killed) exit(-1);
    8020271e:	549c                	lw	a5,40(s1)
    80202720:	ebd9                	bnez	a5,802027b6 <usertrap+0x13a>
    usertrapret();
    80202722:	00000097          	auipc	ra,0x0
    80202726:	ee8080e7          	jalr	-280(ra) # 8020260a <usertrapret>
    8020272a:	64e2                	ld	s1,24(sp)
    8020272c:	6942                	ld	s2,16(sp)
}
    8020272e:	70a2                	ld	ra,40(sp)
    80202730:	7402                	ld	s0,32(sp)
    80202732:	6145                	addi	sp,sp,48
    80202734:	8082                	ret
    80202736:	e44e                	sd	s3,8(sp)
    80202738:	e052                	sd	s4,0(sp)
        if (p->killed) exit(-1);
    8020273a:	557d                	li	a0,-1
    8020273c:	00000097          	auipc	ra,0x0
    80202740:	842080e7          	jalr	-1982(ra) # 80201f7e <exit>
    80202744:	e44e                	sd	s3,8(sp)
    80202746:	e052                	sd	s4,0(sp)
static inline uint64 r_stval(void){ uint64 x; asm volatile("csrr %0, stval":"=r"(x)); return x; }
    80202748:	14302a73          	csrr	s4,stval
        printf("usertrap: pid %d %s at va %p (sepc %p) - killing\n",
    8020274c:	03052983          	lw	s3,48(a0)
    80202750:	854a                	mv	a0,s2
    80202752:	00000097          	auipc	ra,0x0
    80202756:	baa080e7          	jalr	-1110(ra) # 802022fc <cause_str>
    8020275a:	862a                	mv	a2,a0
    8020275c:	6cbc                	ld	a5,88(s1)
    8020275e:	6f98                	ld	a4,24(a5)
    80202760:	86d2                	mv	a3,s4
    80202762:	85ce                	mv	a1,s3
    80202764:	00005517          	auipc	a0,0x5
    80202768:	06c50513          	addi	a0,a0,108 # 802077d0 <etext+0x7d0>
    8020276c:	ffffe097          	auipc	ra,0xffffe
    80202770:	c20080e7          	jalr	-992(ra) # 8020038c <printf>
        p->killed = 1;
    80202774:	4785                	li	a5,1
    80202776:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    80202778:	557d                	li	a0,-1
    8020277a:	00000097          	auipc	ra,0x0
    8020277e:	804080e7          	jalr	-2044(ra) # 80201f7e <exit>
    80202782:	e44e                	sd	s3,8(sp)
            printf("usertrap: pid %d unexpected %s (scause %p, stval %p) - killing\n",
    80202784:	0304a983          	lw	s3,48(s1)
    80202788:	0ff97513          	zext.b	a0,s2
    8020278c:	00000097          	auipc	ra,0x0
    80202790:	b70080e7          	jalr	-1168(ra) # 802022fc <cause_str>
    80202794:	862a                	mv	a2,a0
    80202796:	14302773          	csrr	a4,stval
    8020279a:	86ca                	mv	a3,s2
    8020279c:	85ce                	mv	a1,s3
    8020279e:	00005517          	auipc	a0,0x5
    802027a2:	06a50513          	addi	a0,a0,106 # 80207808 <etext+0x808>
    802027a6:	ffffe097          	auipc	ra,0xffffe
    802027aa:	be6080e7          	jalr	-1050(ra) # 8020038c <printf>
            p->killed = 1;
    802027ae:	4785                	li	a5,1
    802027b0:	d49c                	sw	a5,40(s1)
    if (p->killed) exit(-1);
    802027b2:	e052                	sd	s4,0(sp)
    802027b4:	b7d1                	j	80202778 <usertrap+0xfc>
    802027b6:	e44e                	sd	s3,8(sp)
    802027b8:	e052                	sd	s4,0(sp)
    802027ba:	bf7d                	j	80202778 <usertrap+0xfc>
    802027bc:	0000                	unimp
	...

00000000802027c0 <kernelvec>:
        .globl kernelvec
        .align 4
kernelvec:
        # We were already in the kernel: our sp is a valid kernel stack.
        # Save every caller-saved register - kerneltrap() is C and may clobber them.
        addi    sp, sp, -256
    802027c0:	7111                	addi	sp,sp,-256
        sd      ra, 0(sp)
    802027c2:	e006                	sd	ra,0(sp)
        sd      sp, 8(sp)
    802027c4:	e40a                	sd	sp,8(sp)
        sd      gp, 16(sp)
    802027c6:	e80e                	sd	gp,16(sp)
        sd      tp, 24(sp)
    802027c8:	ec12                	sd	tp,24(sp)
        sd      t0, 32(sp)
    802027ca:	f016                	sd	t0,32(sp)
        sd      t1, 40(sp)
    802027cc:	f41a                	sd	t1,40(sp)
        sd      t2, 48(sp)
    802027ce:	f81e                	sd	t2,48(sp)
        sd      a0, 72(sp)
    802027d0:	e4aa                	sd	a0,72(sp)
        sd      a1, 80(sp)
    802027d2:	e8ae                	sd	a1,80(sp)
        sd      a2, 88(sp)
    802027d4:	ecb2                	sd	a2,88(sp)
        sd      a3, 96(sp)
    802027d6:	f0b6                	sd	a3,96(sp)
        sd      a4, 104(sp)
    802027d8:	f4ba                	sd	a4,104(sp)
        sd      a5, 112(sp)
    802027da:	f8be                	sd	a5,112(sp)
        sd      a6, 120(sp)
    802027dc:	fcc2                	sd	a6,120(sp)
        sd      a7, 128(sp)
    802027de:	e146                	sd	a7,128(sp)
        sd      t3, 216(sp)
    802027e0:	edf2                	sd	t3,216(sp)
        sd      t4, 224(sp)
    802027e2:	f1f6                	sd	t4,224(sp)
        sd      t5, 232(sp)
    802027e4:	f5fa                	sd	t5,232(sp)
        sd      t6, 240(sp)
    802027e6:	f9fe                	sd	t6,240(sp)

        call    kerneltrap
    802027e8:	00000097          	auipc	ra,0x0
    802027ec:	d62080e7          	jalr	-670(ra) # 8020254a <kerneltrap>

        ld      ra, 0(sp)
    802027f0:	6082                	ld	ra,0(sp)
        ld      gp, 16(sp)
    802027f2:	61c2                	ld	gp,16(sp)
        # NOT tp - kerneltrap may have moved us to another hart's scheduler.
        ld      t0, 32(sp)
    802027f4:	7282                	ld	t0,32(sp)
        ld      t1, 40(sp)
    802027f6:	7322                	ld	t1,40(sp)
        ld      t2, 48(sp)
    802027f8:	73c2                	ld	t2,48(sp)
        ld      a0, 72(sp)
    802027fa:	6526                	ld	a0,72(sp)
        ld      a1, 80(sp)
    802027fc:	65c6                	ld	a1,80(sp)
        ld      a2, 88(sp)
    802027fe:	6666                	ld	a2,88(sp)
        ld      a3, 96(sp)
    80202800:	7686                	ld	a3,96(sp)
        ld      a4, 104(sp)
    80202802:	7726                	ld	a4,104(sp)
        ld      a5, 112(sp)
    80202804:	77c6                	ld	a5,112(sp)
        ld      a6, 120(sp)
    80202806:	7866                	ld	a6,120(sp)
        ld      a7, 128(sp)
    80202808:	688a                	ld	a7,128(sp)
        ld      t3, 216(sp)
    8020280a:	6e6e                	ld	t3,216(sp)
        ld      t4, 224(sp)
    8020280c:	7e8e                	ld	t4,224(sp)
        ld      t5, 232(sp)
    8020280e:	7f2e                	ld	t5,232(sp)
        ld      t6, 240(sp)
    80202810:	7fce                	ld	t6,240(sp)
        addi    sp, sp, 256
    80202812:	6111                	addi	sp,sp,256
        # sepc/sstatus were saved+restored by kerneltrap() in C.
        sret
    80202814:	10200073          	sret
    80202818:	00000013          	nop
    8020281c:	00000013          	nop

0000000080202820 <uservec>:
        .globl uservec
        .globl userret
        .globl usertrap
        .align 4
uservec:
        csrrw   a0, sscratch, a0        # a0 = &tf ; sscratch = user's a0
    80202820:	14051573          	csrrw	a0,sscratch,a0

        sd ra,  40(a0)
    80202824:	02153423          	sd	ra,40(a0)
        sd sp,  48(a0)
    80202828:	02253823          	sd	sp,48(a0)
        sd gp,  56(a0)
    8020282c:	02353c23          	sd	gp,56(a0)
        sd tp,  64(a0)
    80202830:	04453023          	sd	tp,64(a0)
        sd t0,  72(a0)
    80202834:	04553423          	sd	t0,72(a0)
        sd t1,  80(a0)
    80202838:	04653823          	sd	t1,80(a0)
        sd t2,  88(a0)
    8020283c:	04753c23          	sd	t2,88(a0)
        sd s0,  96(a0)
    80202840:	f120                	sd	s0,96(a0)
        sd s1,  104(a0)
    80202842:	f524                	sd	s1,104(a0)
        sd a1,  120(a0)
    80202844:	fd2c                	sd	a1,120(a0)
        sd a2,  128(a0)
    80202846:	e150                	sd	a2,128(a0)
        sd a3,  136(a0)
    80202848:	e554                	sd	a3,136(a0)
        sd a4,  144(a0)
    8020284a:	e958                	sd	a4,144(a0)
        sd a5,  152(a0)
    8020284c:	ed5c                	sd	a5,152(a0)
        sd a6,  160(a0)
    8020284e:	0b053023          	sd	a6,160(a0)
        sd a7,  168(a0)
    80202852:	0b153423          	sd	a7,168(a0)
        sd s2,  176(a0)
    80202856:	0b253823          	sd	s2,176(a0)
        sd s3,  184(a0)
    8020285a:	0b353c23          	sd	s3,184(a0)
        sd s4,  192(a0)
    8020285e:	0d453023          	sd	s4,192(a0)
        sd s5,  200(a0)
    80202862:	0d553423          	sd	s5,200(a0)
        sd s6,  208(a0)
    80202866:	0d653823          	sd	s6,208(a0)
        sd s7,  216(a0)
    8020286a:	0d753c23          	sd	s7,216(a0)
        sd s8,  224(a0)
    8020286e:	0f853023          	sd	s8,224(a0)
        sd s9,  232(a0)
    80202872:	0f953423          	sd	s9,232(a0)
        sd s10, 240(a0)
    80202876:	0fa53823          	sd	s10,240(a0)
        sd s11, 248(a0)
    8020287a:	0fb53c23          	sd	s11,248(a0)
        sd t3,  256(a0)
    8020287e:	11c53023          	sd	t3,256(a0)
        sd t4,  264(a0)
    80202882:	11d53423          	sd	t4,264(a0)
        sd t5,  272(a0)
    80202886:	11e53823          	sd	t5,272(a0)
        sd t6,  280(a0)
    8020288a:	11f53c23          	sd	t6,280(a0)

        csrr    t0, sscratch            # t0 = user's original a0
    8020288e:	140022f3          	csrr	t0,sscratch
        sd      t0, 112(a0)             # tf->a0
    80202892:	06553823          	sd	t0,112(a0)

        csrr    t1, sepc
    80202896:	14102373          	csrr	t1,sepc
        sd      t1, 24(a0)              # tf->epc = where user was
    8020289a:	00653c23          	sd	t1,24(a0)

        ld      tp, 32(a0)              # restore our hartid into tp
    8020289e:	02053203          	ld	tp,32(a0)
        ld      sp, 8(a0)               # switch to the kernel stack
    802028a2:	00853103          	ld	sp,8(a0)
        ld      t1, 16(a0)              # tf->kernel_trap = &usertrap
    802028a6:	01053303          	ld	t1,16(a0)
        jr      t1
    802028aa:	8302                	jr	t1

00000000802028ac <userret>:

# void userret(struct trapframe *tf)  -- a0 = tf
userret:
        csrw    sscratch, a0            # so the next uservec can find it
    802028ac:	14051073          	csrw	sscratch,a0

        ld t0,  24(a0)
    802028b0:	01853283          	ld	t0,24(a0)
        csrw    sepc, t0                # return to where the user left off
    802028b4:	14129073          	csrw	sepc,t0

        ld ra,  40(a0)
    802028b8:	02853083          	ld	ra,40(a0)
        ld sp,  48(a0)
    802028bc:	03053103          	ld	sp,48(a0)
        ld gp,  56(a0)
    802028c0:	03853183          	ld	gp,56(a0)
        ld tp,  64(a0)
    802028c4:	04053203          	ld	tp,64(a0)
        ld t0,  72(a0)
    802028c8:	04853283          	ld	t0,72(a0)
        ld t1,  80(a0)
    802028cc:	05053303          	ld	t1,80(a0)
        ld t2,  88(a0)
    802028d0:	05853383          	ld	t2,88(a0)
        ld s0,  96(a0)
    802028d4:	7120                	ld	s0,96(a0)
        ld s1,  104(a0)
    802028d6:	7524                	ld	s1,104(a0)
        ld a1,  120(a0)
    802028d8:	7d2c                	ld	a1,120(a0)
        ld a2,  128(a0)
    802028da:	6150                	ld	a2,128(a0)
        ld a3,  136(a0)
    802028dc:	6554                	ld	a3,136(a0)
        ld a4,  144(a0)
    802028de:	6958                	ld	a4,144(a0)
        ld a5,  152(a0)
    802028e0:	6d5c                	ld	a5,152(a0)
        ld a6,  160(a0)
    802028e2:	0a053803          	ld	a6,160(a0)
        ld a7,  168(a0)
    802028e6:	0a853883          	ld	a7,168(a0)
        ld s2,  176(a0)
    802028ea:	0b053903          	ld	s2,176(a0)
        ld s3,  184(a0)
    802028ee:	0b853983          	ld	s3,184(a0)
        ld s4,  192(a0)
    802028f2:	0c053a03          	ld	s4,192(a0)
        ld s5,  200(a0)
    802028f6:	0c853a83          	ld	s5,200(a0)
        ld s6,  208(a0)
    802028fa:	0d053b03          	ld	s6,208(a0)
        ld s7,  216(a0)
    802028fe:	0d853b83          	ld	s7,216(a0)
        ld s8,  224(a0)
    80202902:	0e053c03          	ld	s8,224(a0)
        ld s9,  232(a0)
    80202906:	0e853c83          	ld	s9,232(a0)
        ld s10, 240(a0)
    8020290a:	0f053d03          	ld	s10,240(a0)
        ld s11, 248(a0)
    8020290e:	0f853d83          	ld	s11,248(a0)
        ld t3,  256(a0)
    80202912:	10053e03          	ld	t3,256(a0)
        ld t4,  264(a0)
    80202916:	10853e83          	ld	t4,264(a0)
        ld t5,  272(a0)
    8020291a:	11053f03          	ld	t5,272(a0)
        ld t6,  280(a0)
    8020291e:	11853f83          	ld	t6,280(a0)

        ld a0,  112(a0)                 # finally, the user's a0 (syscall retval)
    80202922:	7928                	ld	a0,112(a0)
        sret
    80202924:	10200073          	sret
    80202928:	00000013          	nop
    8020292c:	00000013          	nop

0000000080202930 <freewalk_user>:
}

/* Free ONLY the user half of the tree (indices 0..1). Kernel entries are
 * borrowed, not owned - freeing them would take down every other process. */
static void freewalk_user(pagetable_t pt, int level)
{
    80202930:	7139                	addi	sp,sp,-64
    80202932:	fc06                	sd	ra,56(sp)
    80202934:	f822                	sd	s0,48(sp)
    80202936:	f426                	sd	s1,40(sp)
    80202938:	f04a                	sd	s2,32(sp)
    8020293a:	ec4e                	sd	s3,24(sp)
    8020293c:	e852                	sd	s4,16(sp)
    8020293e:	e456                	sd	s5,8(sp)
    80202940:	0080                	addi	s0,sp,64
    80202942:	89aa                	mv	s3,a0
    80202944:	8a2e                	mv	s4,a1
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    80202946:	4789                	li	a5,2
    80202948:	20000913          	li	s2,512
    8020294c:	02f58c63          	beq	a1,a5,80202984 <freewalk_user+0x54>
    for (int i = 0; i < limit; i++) {
    80202950:	84ce                	mv	s1,s3
    80202952:	090e                	slli	s2,s2,0x3
    80202954:	994e                	add	s2,s2,s3
        pte_t pte = pt[i];
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80202956:	4a85                	li	s5,1
        pte_t pte = pt[i];
    80202958:	609c                	ld	a5,0(s1)
        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8020295a:	00f7f713          	andi	a4,a5,15
    8020295e:	03570563          	beq	a4,s5,80202988 <freewalk_user+0x58>
    for (int i = 0; i < limit; i++) {
    80202962:	04a1                	addi	s1,s1,8
    80202964:	ff249ae3          	bne	s1,s2,80202958 <freewalk_user+0x28>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
            pt[i] = 0;
        }
    }
    pfree((void *)pt);
    80202968:	854e                	mv	a0,s3
    8020296a:	fffff097          	auipc	ra,0xfffff
    8020296e:	84c080e7          	jalr	-1972(ra) # 802011b6 <pfree>
}
    80202972:	70e2                	ld	ra,56(sp)
    80202974:	7442                	ld	s0,48(sp)
    80202976:	74a2                	ld	s1,40(sp)
    80202978:	7902                	ld	s2,32(sp)
    8020297a:	69e2                	ld	s3,24(sp)
    8020297c:	6a42                	ld	s4,16(sp)
    8020297e:	6aa2                	ld	s5,8(sp)
    80202980:	6121                	addi	sp,sp,64
    80202982:	8082                	ret
    int limit = (level == 2) ? KERN_IDX_LO : 512;
    80202984:	892e                	mv	s2,a1
    80202986:	b7e9                	j	80202950 <freewalk_user+0x20>
            freewalk_user((pagetable_t)PTE2PA(pte), level - 1);
    80202988:	83a9                	srli	a5,a5,0xa
    8020298a:	fffa059b          	addiw	a1,s4,-1
    8020298e:	00c79513          	slli	a0,a5,0xc
    80202992:	00000097          	auipc	ra,0x0
    80202996:	f9e080e7          	jalr	-98(ra) # 80202930 <freewalk_user>
            pt[i] = 0;
    8020299a:	0004b023          	sd	zero,0(s1)
    8020299e:	b7d1                	j	80202962 <freewalk_user+0x32>

00000000802029a0 <vmprint_lvl>:
    return got_null ? 0 : -1;
}

/* Debug aid you will use all semester, and in Viva #2. */
static void vmprint_lvl(pagetable_t pt, int level)
{
    802029a0:	711d                	addi	sp,sp,-96
    802029a2:	ec86                	sd	ra,88(sp)
    802029a4:	e8a2                	sd	s0,80(sp)
    802029a6:	e4a6                	sd	s1,72(sp)
    802029a8:	e0ca                	sd	s2,64(sp)
    802029aa:	fc4e                	sd	s3,56(sp)
    802029ac:	f852                	sd	s4,48(sp)
    802029ae:	f456                	sd	s5,40(sp)
    802029b0:	f05a                	sd	s6,32(sp)
    802029b2:	ec5e                	sd	s7,24(sp)
    802029b4:	e862                	sd	s8,16(sp)
    802029b6:	e466                	sd	s9,8(sp)
    802029b8:	e06a                	sd	s10,0(sp)
    802029ba:	1080                	addi	s0,sp,96
    802029bc:	892e                	mv	s2,a1
    for (int i = 0; i < 512; i++) {
    802029be:	8b2a                	mv	s6,a0
    802029c0:	4a01                	li	s4,0
        pte_t pte = pt[i];
        if (!(pte & PTE_V)) continue;
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    802029c2:	4b89                	li	s7,2
        for (int d = 2; d >= level; d--) printf(" ..");
    802029c4:	00005a97          	auipc	s5,0x5
    802029c8:	e84a8a93          	addi	s5,s5,-380 # 80207848 <etext+0x848>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    802029cc:	00005c97          	auipc	s9,0x5
    802029d0:	e84c8c93          	addi	s9,s9,-380 # 80207850 <etext+0x850>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    802029d4:	4d05                	li	s10,1
    for (int i = 0; i < 512; i++) {
    802029d6:	20000c13          	li	s8,512
    802029da:	a089                	j	80202a1c <vmprint_lvl+0x7c>
        for (int d = 2; d >= level; d--) printf(" ..");
    802029dc:	84de                	mv	s1,s7
    802029de:	052bca63          	blt	s7,s2,80202a32 <vmprint_lvl+0x92>
    802029e2:	8556                	mv	a0,s5
    802029e4:	ffffe097          	auipc	ra,0xffffe
    802029e8:	9a8080e7          	jalr	-1624(ra) # 8020038c <printf>
    802029ec:	34fd                	addiw	s1,s1,-1
    802029ee:	ff24dae3          	bge	s1,s2,802029e2 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    802029f2:	00a9d493          	srli	s1,s3,0xa
    802029f6:	04b2                	slli	s1,s1,0xc
    802029f8:	86a6                	mv	a3,s1
    802029fa:	864e                	mv	a2,s3
    802029fc:	85d2                	mv	a1,s4
    802029fe:	8566                	mv	a0,s9
    80202a00:	ffffe097          	auipc	ra,0xffffe
    80202a04:	98c080e7          	jalr	-1652(ra) # 8020038c <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202a08:	00e9f993          	andi	s3,s3,14
    80202a0c:	00099463          	bnez	s3,80202a14 <vmprint_lvl+0x74>
    80202a10:	05204063          	bgtz	s2,80202a50 <vmprint_lvl+0xb0>
    for (int i = 0; i < 512; i++) {
    80202a14:	2a05                	addiw	s4,s4,1
    80202a16:	0b21                	addi	s6,s6,8
    80202a18:	058a0463          	beq	s4,s8,80202a60 <vmprint_lvl+0xc0>
        pte_t pte = pt[i];
    80202a1c:	000b3983          	ld	s3,0(s6)
        if (!(pte & PTE_V)) continue;
    80202a20:	0019f793          	andi	a5,s3,1
    80202a24:	dbe5                	beqz	a5,80202a14 <vmprint_lvl+0x74>
        if (level == 2 && i >= KERN_IDX_LO) continue;   /* skip borrowed kernel */
    80202a26:	fb791be3          	bne	s2,s7,802029dc <vmprint_lvl+0x3c>
    80202a2a:	ff4d45e3          	blt	s10,s4,80202a14 <vmprint_lvl+0x74>
    80202a2e:	84ca                	mv	s1,s2
    80202a30:	bf4d                	j	802029e2 <vmprint_lvl+0x42>
        printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80202a32:	00a9d493          	srli	s1,s3,0xa
    80202a36:	04b2                	slli	s1,s1,0xc
    80202a38:	86a6                	mv	a3,s1
    80202a3a:	864e                	mv	a2,s3
    80202a3c:	85d2                	mv	a1,s4
    80202a3e:	8566                	mv	a0,s9
    80202a40:	ffffe097          	auipc	ra,0xffffe
    80202a44:	94c080e7          	jalr	-1716(ra) # 8020038c <printf>
        if ((pte & (PTE_R | PTE_W | PTE_X)) == 0 && level > 0)
    80202a48:	00e9f993          	andi	s3,s3,14
    80202a4c:	fc0994e3          	bnez	s3,80202a14 <vmprint_lvl+0x74>
            vmprint_lvl((pagetable_t)PTE2PA(pte), level - 1);
    80202a50:	fff9059b          	addiw	a1,s2,-1
    80202a54:	8526                	mv	a0,s1
    80202a56:	00000097          	auipc	ra,0x0
    80202a5a:	f4a080e7          	jalr	-182(ra) # 802029a0 <vmprint_lvl>
    80202a5e:	bf5d                	j	80202a14 <vmprint_lvl+0x74>
    }
}
    80202a60:	60e6                	ld	ra,88(sp)
    80202a62:	6446                	ld	s0,80(sp)
    80202a64:	64a6                	ld	s1,72(sp)
    80202a66:	6906                	ld	s2,64(sp)
    80202a68:	79e2                	ld	s3,56(sp)
    80202a6a:	7a42                	ld	s4,48(sp)
    80202a6c:	7aa2                	ld	s5,40(sp)
    80202a6e:	7b02                	ld	s6,32(sp)
    80202a70:	6be2                	ld	s7,24(sp)
    80202a72:	6c42                	ld	s8,16(sp)
    80202a74:	6ca2                	ld	s9,8(sp)
    80202a76:	6d02                	ld	s10,0(sp)
    80202a78:	6125                	addi	sp,sp,96
    80202a7a:	8082                	ret

0000000080202a7c <mmio_alias>:
uint64 mmio_alias(uint64 pa) { return MMIO_VA(pa); }
    80202a7c:	1141                	addi	sp,sp,-16
    80202a7e:	e422                	sd	s0,8(sp)
    80202a80:	0800                	addi	s0,sp,16
    80202a82:	4785                	li	a5,1
    80202a84:	1782                	slli	a5,a5,0x20
    80202a86:	953e                	add	a0,a0,a5
    80202a88:	6422                	ld	s0,8(sp)
    80202a8a:	0141                	addi	sp,sp,16
    80202a8c:	8082                	ret

0000000080202a8e <walk>:
{
    80202a8e:	7139                	addi	sp,sp,-64
    80202a90:	fc06                	sd	ra,56(sp)
    80202a92:	f822                	sd	s0,48(sp)
    80202a94:	f426                	sd	s1,40(sp)
    80202a96:	f04a                	sd	s2,32(sp)
    80202a98:	ec4e                	sd	s3,24(sp)
    80202a9a:	e852                	sd	s4,16(sp)
    80202a9c:	e456                	sd	s5,8(sp)
    80202a9e:	e05a                	sd	s6,0(sp)
    80202aa0:	0080                	addi	s0,sp,64
    80202aa2:	84aa                	mv	s1,a0
    80202aa4:	89ae                	mv	s3,a1
    80202aa6:	8ab2                	mv	s5,a2
    if (va >= MAXVA) panic("walk: va out of range");
    80202aa8:	57fd                	li	a5,-1
    80202aaa:	83e9                	srli	a5,a5,0x1a
    80202aac:	4a79                	li	s4,30
    for (int level = 2; level > 0; level--) {
    80202aae:	4b31                	li	s6,12
    if (va >= MAXVA) panic("walk: va out of range");
    80202ab0:	04b7f263          	bgeu	a5,a1,80202af4 <walk+0x66>
    80202ab4:	00005517          	auipc	a0,0x5
    80202ab8:	db450513          	addi	a0,a0,-588 # 80207868 <etext+0x868>
    80202abc:	ffffe097          	auipc	ra,0xffffe
    80202ac0:	b42080e7          	jalr	-1214(ra) # 802005fe <panic>
            if (!alloc) return 0;
    80202ac4:	060a8663          	beqz	s5,80202b30 <walk+0xa2>
            pt = (pagetable_t)palloc();
    80202ac8:	ffffe097          	auipc	ra,0xffffe
    80202acc:	5de080e7          	jalr	1502(ra) # 802010a6 <palloc>
    80202ad0:	84aa                	mv	s1,a0
            if (!pt) return 0;
    80202ad2:	c529                	beqz	a0,80202b1c <walk+0x8e>
            memset(pt, 0, PGSIZE);
    80202ad4:	6605                	lui	a2,0x1
    80202ad6:	4581                	li	a1,0
    80202ad8:	ffffe097          	auipc	ra,0xffffe
    80202adc:	bcc080e7          	jalr	-1076(ra) # 802006a4 <memset>
            *pte = PA2PTE(pt) | PTE_V;
    80202ae0:	00c4d793          	srli	a5,s1,0xc
    80202ae4:	07aa                	slli	a5,a5,0xa
    80202ae6:	0017e793          	ori	a5,a5,1
    80202aea:	00f93023          	sd	a5,0(s2)
    for (int level = 2; level > 0; level--) {
    80202aee:	3a5d                	addiw	s4,s4,-9
    80202af0:	036a0063          	beq	s4,s6,80202b10 <walk+0x82>
        pte_t *pte = &pt[PX(level, va)];
    80202af4:	0149d933          	srl	s2,s3,s4
    80202af8:	1ff97913          	andi	s2,s2,511
    80202afc:	090e                	slli	s2,s2,0x3
    80202afe:	9926                	add	s2,s2,s1
        if (*pte & PTE_V) {
    80202b00:	00093483          	ld	s1,0(s2)
    80202b04:	0014f793          	andi	a5,s1,1
    80202b08:	dfd5                	beqz	a5,80202ac4 <walk+0x36>
            pt = (pagetable_t)PTE2PA(*pte);
    80202b0a:	80a9                	srli	s1,s1,0xa
    80202b0c:	04b2                	slli	s1,s1,0xc
    80202b0e:	b7c5                	j	80202aee <walk+0x60>
    return &pt[PX(0, va)];
    80202b10:	00c9d513          	srli	a0,s3,0xc
    80202b14:	1ff57513          	andi	a0,a0,511
    80202b18:	050e                	slli	a0,a0,0x3
    80202b1a:	9526                	add	a0,a0,s1
}
    80202b1c:	70e2                	ld	ra,56(sp)
    80202b1e:	7442                	ld	s0,48(sp)
    80202b20:	74a2                	ld	s1,40(sp)
    80202b22:	7902                	ld	s2,32(sp)
    80202b24:	69e2                	ld	s3,24(sp)
    80202b26:	6a42                	ld	s4,16(sp)
    80202b28:	6aa2                	ld	s5,8(sp)
    80202b2a:	6b02                	ld	s6,0(sp)
    80202b2c:	6121                	addi	sp,sp,64
    80202b2e:	8082                	ret
            if (!alloc) return 0;
    80202b30:	4501                	li	a0,0
    80202b32:	b7ed                	j	80202b1c <walk+0x8e>

0000000080202b34 <walkaddr>:
    if (va >= MAXVA) return 0;
    80202b34:	57fd                	li	a5,-1
    80202b36:	83e9                	srli	a5,a5,0x1a
    80202b38:	00b7f463          	bgeu	a5,a1,80202b40 <walkaddr+0xc>
    80202b3c:	4501                	li	a0,0
}
    80202b3e:	8082                	ret
{
    80202b40:	1141                	addi	sp,sp,-16
    80202b42:	e406                	sd	ra,8(sp)
    80202b44:	e022                	sd	s0,0(sp)
    80202b46:	0800                	addi	s0,sp,16
    pte_t *pte = walk(pt, va, 0);
    80202b48:	4601                	li	a2,0
    80202b4a:	00000097          	auipc	ra,0x0
    80202b4e:	f44080e7          	jalr	-188(ra) # 80202a8e <walk>
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202b52:	cd19                	beqz	a0,80202b70 <walkaddr+0x3c>
    80202b54:	611c                	ld	a5,0(a0)
    80202b56:	0117f693          	andi	a3,a5,17
    80202b5a:	4745                	li	a4,17
    80202b5c:	4501                	li	a0,0
    80202b5e:	00e69563          	bne	a3,a4,80202b68 <walkaddr+0x34>
    return PTE2PA(*pte);
    80202b62:	83a9                	srli	a5,a5,0xa
    80202b64:	00c79513          	slli	a0,a5,0xc
}
    80202b68:	60a2                	ld	ra,8(sp)
    80202b6a:	6402                	ld	s0,0(sp)
    80202b6c:	0141                	addi	sp,sp,16
    80202b6e:	8082                	ret
    if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return 0;
    80202b70:	4501                	li	a0,0
    80202b72:	bfdd                	j	80202b68 <walkaddr+0x34>

0000000080202b74 <mappages>:
{
    80202b74:	715d                	addi	sp,sp,-80
    80202b76:	e486                	sd	ra,72(sp)
    80202b78:	e0a2                	sd	s0,64(sp)
    80202b7a:	fc26                	sd	s1,56(sp)
    80202b7c:	f84a                	sd	s2,48(sp)
    80202b7e:	f44e                	sd	s3,40(sp)
    80202b80:	f052                	sd	s4,32(sp)
    80202b82:	ec56                	sd	s5,24(sp)
    80202b84:	e85a                	sd	s6,16(sp)
    80202b86:	e45e                	sd	s7,8(sp)
    80202b88:	0880                	addi	s0,sp,80
    if (size == 0) panic("mappages: zero size");
    80202b8a:	c639                	beqz	a2,80202bd8 <mappages+0x64>
    80202b8c:	8aaa                	mv	s5,a0
    80202b8e:	8b3a                	mv	s6,a4
    uint64 a    = PGROUNDDOWN(va);
    80202b90:	777d                	lui	a4,0xfffff
    80202b92:	00e5f7b3          	and	a5,a1,a4
    uint64 last = PGROUNDDOWN(va + size - 1);
    80202b96:	fff58993          	addi	s3,a1,-1
    80202b9a:	99b2                	add	s3,s3,a2
    80202b9c:	00e9f9b3          	and	s3,s3,a4
    uint64 a    = PGROUNDDOWN(va);
    80202ba0:	893e                	mv	s2,a5
    80202ba2:	40f68a33          	sub	s4,a3,a5
        a  += PGSIZE;
    80202ba6:	6b85                	lui	s7,0x1
    80202ba8:	014904b3          	add	s1,s2,s4
        pte_t *pte = walk(pt, a, 1);
    80202bac:	4605                	li	a2,1
    80202bae:	85ca                	mv	a1,s2
    80202bb0:	8556                	mv	a0,s5
    80202bb2:	00000097          	auipc	ra,0x0
    80202bb6:	edc080e7          	jalr	-292(ra) # 80202a8e <walk>
        if (!pte) return -1;
    80202bba:	cd1d                	beqz	a0,80202bf8 <mappages+0x84>
        if (*pte & PTE_V) panic("mappages: remap");
    80202bbc:	611c                	ld	a5,0(a0)
    80202bbe:	8b85                	andi	a5,a5,1
    80202bc0:	e785                	bnez	a5,80202be8 <mappages+0x74>
        *pte = PA2PTE(pa) | perm | PTE_V;
    80202bc2:	80b1                	srli	s1,s1,0xc
    80202bc4:	04aa                	slli	s1,s1,0xa
    80202bc6:	0164e4b3          	or	s1,s1,s6
    80202bca:	0014e493          	ori	s1,s1,1
    80202bce:	e104                	sd	s1,0(a0)
        if (a == last) break;
    80202bd0:	05390063          	beq	s2,s3,80202c10 <mappages+0x9c>
        a  += PGSIZE;
    80202bd4:	995e                	add	s2,s2,s7
    for (;;) {
    80202bd6:	bfc9                	j	80202ba8 <mappages+0x34>
    if (size == 0) panic("mappages: zero size");
    80202bd8:	00005517          	auipc	a0,0x5
    80202bdc:	ca850513          	addi	a0,a0,-856 # 80207880 <etext+0x880>
    80202be0:	ffffe097          	auipc	ra,0xffffe
    80202be4:	a1e080e7          	jalr	-1506(ra) # 802005fe <panic>
        if (*pte & PTE_V) panic("mappages: remap");
    80202be8:	00005517          	auipc	a0,0x5
    80202bec:	cb050513          	addi	a0,a0,-848 # 80207898 <etext+0x898>
    80202bf0:	ffffe097          	auipc	ra,0xffffe
    80202bf4:	a0e080e7          	jalr	-1522(ra) # 802005fe <panic>
        if (!pte) return -1;
    80202bf8:	557d                	li	a0,-1
}
    80202bfa:	60a6                	ld	ra,72(sp)
    80202bfc:	6406                	ld	s0,64(sp)
    80202bfe:	74e2                	ld	s1,56(sp)
    80202c00:	7942                	ld	s2,48(sp)
    80202c02:	79a2                	ld	s3,40(sp)
    80202c04:	7a02                	ld	s4,32(sp)
    80202c06:	6ae2                	ld	s5,24(sp)
    80202c08:	6b42                	ld	s6,16(sp)
    80202c0a:	6ba2                	ld	s7,8(sp)
    80202c0c:	6161                	addi	sp,sp,80
    80202c0e:	8082                	ret
    return 0;
    80202c10:	4501                	li	a0,0
    80202c12:	b7e5                	j	80202bfa <mappages+0x86>

0000000080202c14 <kvmmap>:
{
    80202c14:	1141                	addi	sp,sp,-16
    80202c16:	e406                	sd	ra,8(sp)
    80202c18:	e022                	sd	s0,0(sp)
    80202c1a:	0800                	addi	s0,sp,16
    80202c1c:	8736                	mv	a4,a3
    if (mappages(kernel_pagetable, va, sz, pa, perm) != 0)
    80202c1e:	86ae                	mv	a3,a1
    80202c20:	85aa                	mv	a1,a0
    80202c22:	0013c517          	auipc	a0,0x13c
    80202c26:	3fe53503          	ld	a0,1022(a0) # 8033f020 <kernel_pagetable>
    80202c2a:	00000097          	auipc	ra,0x0
    80202c2e:	f4a080e7          	jalr	-182(ra) # 80202b74 <mappages>
    80202c32:	e509                	bnez	a0,80202c3c <kvmmap+0x28>
}
    80202c34:	60a2                	ld	ra,8(sp)
    80202c36:	6402                	ld	s0,0(sp)
    80202c38:	0141                	addi	sp,sp,16
    80202c3a:	8082                	ret
        panic("kvmmap");
    80202c3c:	00005517          	auipc	a0,0x5
    80202c40:	c6c50513          	addi	a0,a0,-916 # 802078a8 <etext+0x8a8>
    80202c44:	ffffe097          	auipc	ra,0xffffe
    80202c48:	9ba080e7          	jalr	-1606(ra) # 802005fe <panic>

0000000080202c4c <kvminit>:
{
    80202c4c:	7179                	addi	sp,sp,-48
    80202c4e:	f406                	sd	ra,40(sp)
    80202c50:	f022                	sd	s0,32(sp)
    80202c52:	ec26                	sd	s1,24(sp)
    80202c54:	e84a                	sd	s2,16(sp)
    80202c56:	1800                	addi	s0,sp,48
    kernel_pagetable = (pagetable_t)palloc();
    80202c58:	ffffe097          	auipc	ra,0xffffe
    80202c5c:	44e080e7          	jalr	1102(ra) # 802010a6 <palloc>
    80202c60:	0013c717          	auipc	a4,0x13c
    80202c64:	3ca73023          	sd	a0,960(a4) # 8033f020 <kernel_pagetable>
    memset(kernel_pagetable, 0, PGSIZE);
    80202c68:	6605                	lui	a2,0x1
    80202c6a:	4581                	li	a1,0
    80202c6c:	ffffe097          	auipc	ra,0xffffe
    80202c70:	a38080e7          	jalr	-1480(ra) # 802006a4 <memset>
    kvmmap(MMIO_VA(fdt.uart_base), fdt.uart_base, PGSIZE, PTE_R | PTE_W);
    80202c74:	00026497          	auipc	s1,0x26
    80202c78:	3a448493          	addi	s1,s1,932 # 80229018 <fdt>
    80202c7c:	688c                	ld	a1,16(s1)
    80202c7e:	4505                	li	a0,1
    80202c80:	1502                	slli	a0,a0,0x20
    80202c82:	4699                	li	a3,6
    80202c84:	6605                	lui	a2,0x1
    80202c86:	952e                	add	a0,a0,a1
    80202c88:	00000097          	auipc	ra,0x0
    80202c8c:	f8c080e7          	jalr	-116(ra) # 80202c14 <kvmmap>
    if (fdt.plic_base)
    80202c90:	6c8c                	ld	a1,24(s1)
    80202c92:	e1d5                	bnez	a1,80202d36 <kvminit+0xea>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202c94:	00026797          	auipc	a5,0x26
    80202c98:	40c7a783          	lw	a5,1036(a5) # 802290a0 <fdt+0x88>
    80202c9c:	02f05e63          	blez	a5,80202cd8 <kvminit+0x8c>
    80202ca0:	e44e                	sd	s3,8(sp)
    80202ca2:	e052                	sd	s4,0(sp)
    80202ca4:	00026917          	auipc	s2,0x26
    80202ca8:	37490913          	addi	s2,s2,884 # 80229018 <fdt>
    80202cac:	4481                	li	s1,0
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202cae:	4985                	li	s3,1
    80202cb0:	1982                	slli	s3,s3,0x20
    for (int i = 0; i < fdt.nvirtio; i++)
    80202cb2:	8a4a                	mv	s4,s2
        kvmmap(MMIO_VA(fdt.virtio_base[i]), fdt.virtio_base[i], PGSIZE, PTE_R | PTE_W);
    80202cb4:	02893583          	ld	a1,40(s2)
    80202cb8:	4699                	li	a3,6
    80202cba:	6605                	lui	a2,0x1
    80202cbc:	01358533          	add	a0,a1,s3
    80202cc0:	00000097          	auipc	ra,0x0
    80202cc4:	f54080e7          	jalr	-172(ra) # 80202c14 <kvmmap>
    for (int i = 0; i < fdt.nvirtio; i++)
    80202cc8:	2485                	addiw	s1,s1,1
    80202cca:	0921                	addi	s2,s2,8
    80202ccc:	088a2783          	lw	a5,136(s4)
    80202cd0:	fef4c2e3          	blt	s1,a5,80202cb4 <kvminit+0x68>
    80202cd4:	69a2                	ld	s3,8(sp)
    80202cd6:	6a02                	ld	s4,0(sp)
    kvmmap(ktext, ktext, (uint64)etext - ktext, PTE_R | PTE_X);
    80202cd8:	00004497          	auipc	s1,0x4
    80202cdc:	32848493          	addi	s1,s1,808 # 80207000 <etext>
    80202ce0:	bff00613          	li	a2,-1025
    80202ce4:	0656                	slli	a2,a2,0x15
    80202ce6:	46a9                	li	a3,10
    80202ce8:	9626                	add	a2,a2,s1
    80202cea:	40100593          	li	a1,1025
    80202cee:	05d6                	slli	a1,a1,0x15
    80202cf0:	852e                	mv	a0,a1
    80202cf2:	00000097          	auipc	ra,0x0
    80202cf6:	f22080e7          	jalr	-222(ra) # 80202c14 <kvmmap>
    uint64 mem_end = fdt.mem_base + fdt.mem_size;
    80202cfa:	00026917          	auipc	s2,0x26
    80202cfe:	31e90913          	addi	s2,s2,798 # 80229018 <fdt>
    80202d02:	09093603          	ld	a2,144(s2)
    80202d06:	09893783          	ld	a5,152(s2)
    80202d0a:	963e                	add	a2,a2,a5
    kvmmap((uint64)etext, (uint64)etext, mem_end - (uint64)etext, PTE_R | PTE_W);
    80202d0c:	4699                	li	a3,6
    80202d0e:	8e05                	sub	a2,a2,s1
    80202d10:	85a6                	mv	a1,s1
    80202d12:	8526                	mv	a0,s1
    80202d14:	00000097          	auipc	ra,0x0
    80202d18:	f00080e7          	jalr	-256(ra) # 80202c14 <kvmmap>
    if (fdt.mem_base < ktext)
    80202d1c:	09093503          	ld	a0,144(s2)
    80202d20:	40100793          	li	a5,1025
    80202d24:	07d6                	slli	a5,a5,0x15
    80202d26:	02f56363          	bltu	a0,a5,80202d4c <kvminit+0x100>
}
    80202d2a:	70a2                	ld	ra,40(sp)
    80202d2c:	7402                	ld	s0,32(sp)
    80202d2e:	64e2                	ld	s1,24(sp)
    80202d30:	6942                	ld	s2,16(sp)
    80202d32:	6145                	addi	sp,sp,48
    80202d34:	8082                	ret
        kvmmap(MMIO_VA(fdt.plic_base), fdt.plic_base, 0x400000, PTE_R | PTE_W);
    80202d36:	4505                	li	a0,1
    80202d38:	1502                	slli	a0,a0,0x20
    80202d3a:	4699                	li	a3,6
    80202d3c:	00400637          	lui	a2,0x400
    80202d40:	952e                	add	a0,a0,a1
    80202d42:	00000097          	auipc	ra,0x0
    80202d46:	ed2080e7          	jalr	-302(ra) # 80202c14 <kvmmap>
    80202d4a:	b7a9                	j	80202c94 <kvminit+0x48>
        kvmmap(fdt.mem_base, fdt.mem_base, ktext - fdt.mem_base, PTE_R | PTE_W);
    80202d4c:	4699                	li	a3,6
    80202d4e:	40a78633          	sub	a2,a5,a0
    80202d52:	85aa                	mv	a1,a0
    80202d54:	00000097          	auipc	ra,0x0
    80202d58:	ec0080e7          	jalr	-320(ra) # 80202c14 <kvmmap>
}
    80202d5c:	b7f9                	j	80202d2a <kvminit+0xde>

0000000080202d5e <kvminithart>:
{
    80202d5e:	1141                	addi	sp,sp,-16
    80202d60:	e422                	sd	s0,8(sp)
    80202d62:	0800                	addi	s0,sp,16
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202d64:	12000073          	sfence.vma
    w_satp(MAKE_SATP(kernel_pagetable));
    80202d68:	0013c797          	auipc	a5,0x13c
    80202d6c:	2b87b783          	ld	a5,696(a5) # 8033f020 <kernel_pagetable>
    80202d70:	83b1                	srli	a5,a5,0xc
    80202d72:	577d                	li	a4,-1
    80202d74:	177e                	slli	a4,a4,0x3f
    80202d76:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80202d78:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80202d7c:	12000073          	sfence.vma
}
    80202d80:	6422                	ld	s0,8(sp)
    80202d82:	0141                	addi	sp,sp,16
    80202d84:	8082                	ret

0000000080202d86 <uvmcreate>:
{
    80202d86:	1101                	addi	sp,sp,-32
    80202d88:	ec06                	sd	ra,24(sp)
    80202d8a:	e822                	sd	s0,16(sp)
    80202d8c:	e426                	sd	s1,8(sp)
    80202d8e:	1000                	addi	s0,sp,32
    pagetable_t pt = (pagetable_t)palloc();
    80202d90:	ffffe097          	auipc	ra,0xffffe
    80202d94:	316080e7          	jalr	790(ra) # 802010a6 <palloc>
    80202d98:	84aa                	mv	s1,a0
    if (!pt) return 0;
    80202d9a:	c515                	beqz	a0,80202dc6 <uvmcreate+0x40>
    memset(pt, 0, PGSIZE);
    80202d9c:	6605                	lui	a2,0x1
    80202d9e:	4581                	li	a1,0
    80202da0:	ffffe097          	auipc	ra,0xffffe
    80202da4:	904080e7          	jalr	-1788(ra) # 802006a4 <memset>
    80202da8:	47c1                	li	a5,16
        pt[i] = kernel_pagetable[i];
    80202daa:	0013c597          	auipc	a1,0x13c
    80202dae:	27658593          	addi	a1,a1,630 # 8033f020 <kernel_pagetable>
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202db2:	6605                	lui	a2,0x1
        pt[i] = kernel_pagetable[i];
    80202db4:	6198                	ld	a4,0(a1)
    80202db6:	973e                	add	a4,a4,a5
    80202db8:	6314                	ld	a3,0(a4)
    80202dba:	00f48733          	add	a4,s1,a5
    80202dbe:	e314                	sd	a3,0(a4)
    for (int i = KERN_IDX_LO; i < 512; i++)
    80202dc0:	07a1                	addi	a5,a5,8
    80202dc2:	fec799e3          	bne	a5,a2,80202db4 <uvmcreate+0x2e>
}
    80202dc6:	8526                	mv	a0,s1
    80202dc8:	60e2                	ld	ra,24(sp)
    80202dca:	6442                	ld	s0,16(sp)
    80202dcc:	64a2                	ld	s1,8(sp)
    80202dce:	6105                	addi	sp,sp,32
    80202dd0:	8082                	ret

0000000080202dd2 <uvmunmap>:
{
    80202dd2:	7139                	addi	sp,sp,-64
    80202dd4:	fc06                	sd	ra,56(sp)
    80202dd6:	f822                	sd	s0,48(sp)
    80202dd8:	ec4e                	sd	s3,24(sp)
    80202dda:	0080                	addi	s0,sp,64
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202ddc:	0632                	slli	a2,a2,0xc
    80202dde:	00b609b3          	add	s3,a2,a1
    80202de2:	0535fd63          	bgeu	a1,s3,80202e3c <uvmunmap+0x6a>
    80202de6:	f426                	sd	s1,40(sp)
    80202de8:	f04a                	sd	s2,32(sp)
    80202dea:	e852                	sd	s4,16(sp)
    80202dec:	e456                	sd	s5,8(sp)
    80202dee:	e05a                	sd	s6,0(sp)
    80202df0:	8a2a                	mv	s4,a0
    80202df2:	892e                	mv	s2,a1
    80202df4:	8ab6                	mv	s5,a3
    80202df6:	6b05                	lui	s6,0x1
    80202df8:	a031                	j	80202e04 <uvmunmap+0x32>
        *pte = 0;
    80202dfa:	0004b023          	sd	zero,0(s1)
    for (uint64 a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80202dfe:	995a                	add	s2,s2,s6
    80202e00:	03397963          	bgeu	s2,s3,80202e32 <uvmunmap+0x60>
        pte_t *pte = walk(pt, a, 0);
    80202e04:	4601                	li	a2,0
    80202e06:	85ca                	mv	a1,s2
    80202e08:	8552                	mv	a0,s4
    80202e0a:	00000097          	auipc	ra,0x0
    80202e0e:	c84080e7          	jalr	-892(ra) # 80202a8e <walk>
    80202e12:	84aa                	mv	s1,a0
        if (!pte || !(*pte & PTE_V)) continue;     /* lazily-allocated: fine */
    80202e14:	d56d                	beqz	a0,80202dfe <uvmunmap+0x2c>
    80202e16:	611c                	ld	a5,0(a0)
    80202e18:	0017f713          	andi	a4,a5,1
    80202e1c:	d36d                	beqz	a4,80202dfe <uvmunmap+0x2c>
        if (do_free) pfree((void *)PTE2PA(*pte));
    80202e1e:	fc0a8ee3          	beqz	s5,80202dfa <uvmunmap+0x28>
    80202e22:	83a9                	srli	a5,a5,0xa
    80202e24:	00c79513          	slli	a0,a5,0xc
    80202e28:	ffffe097          	auipc	ra,0xffffe
    80202e2c:	38e080e7          	jalr	910(ra) # 802011b6 <pfree>
    80202e30:	b7e9                	j	80202dfa <uvmunmap+0x28>
    80202e32:	74a2                	ld	s1,40(sp)
    80202e34:	7902                	ld	s2,32(sp)
    80202e36:	6a42                	ld	s4,16(sp)
    80202e38:	6aa2                	ld	s5,8(sp)
    80202e3a:	6b02                	ld	s6,0(sp)
}
    80202e3c:	70e2                	ld	ra,56(sp)
    80202e3e:	7442                	ld	s0,48(sp)
    80202e40:	69e2                	ld	s3,24(sp)
    80202e42:	6121                	addi	sp,sp,64
    80202e44:	8082                	ret

0000000080202e46 <uvmfree>:
{
    80202e46:	1101                	addi	sp,sp,-32
    80202e48:	ec06                	sd	ra,24(sp)
    80202e4a:	e822                	sd	s0,16(sp)
    80202e4c:	e426                	sd	s1,8(sp)
    80202e4e:	1000                	addi	s0,sp,32
    80202e50:	84aa                	mv	s1,a0
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202e52:	ed81                	bnez	a1,80202e6a <uvmfree+0x24>
    freewalk_user(pt, 2);
    80202e54:	4589                	li	a1,2
    80202e56:	8526                	mv	a0,s1
    80202e58:	00000097          	auipc	ra,0x0
    80202e5c:	ad8080e7          	jalr	-1320(ra) # 80202930 <freewalk_user>
}
    80202e60:	60e2                	ld	ra,24(sp)
    80202e62:	6442                	ld	s0,16(sp)
    80202e64:	64a2                	ld	s1,8(sp)
    80202e66:	6105                	addi	sp,sp,32
    80202e68:	8082                	ret
    if (sz > 0) uvmunmap(pt, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80202e6a:	6785                	lui	a5,0x1
    80202e6c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    80202e6e:	95be                	add	a1,a1,a5
    80202e70:	4685                	li	a3,1
    80202e72:	00c5d613          	srli	a2,a1,0xc
    80202e76:	4581                	li	a1,0
    80202e78:	00000097          	auipc	ra,0x0
    80202e7c:	f5a080e7          	jalr	-166(ra) # 80202dd2 <uvmunmap>
    80202e80:	bfd1                	j	80202e54 <uvmfree+0xe>

0000000080202e82 <uvmcopy>:
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202e82:	c661                	beqz	a2,80202f4a <uvmcopy+0xc8>
{
    80202e84:	715d                	addi	sp,sp,-80
    80202e86:	e486                	sd	ra,72(sp)
    80202e88:	e0a2                	sd	s0,64(sp)
    80202e8a:	fc26                	sd	s1,56(sp)
    80202e8c:	f84a                	sd	s2,48(sp)
    80202e8e:	f44e                	sd	s3,40(sp)
    80202e90:	f052                	sd	s4,32(sp)
    80202e92:	ec56                	sd	s5,24(sp)
    80202e94:	e85a                	sd	s6,16(sp)
    80202e96:	e45e                	sd	s7,8(sp)
    80202e98:	0880                	addi	s0,sp,80
    80202e9a:	8aaa                	mv	s5,a0
    80202e9c:	8b2e                	mv	s6,a1
    80202e9e:	8a32                	mv	s4,a2
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202ea0:	4481                	li	s1,0
    80202ea2:	a005                	j	80202ec2 <uvmcopy+0x40>
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202ea4:	4685                	li	a3,1
    80202ea6:	00c4d613          	srli	a2,s1,0xc
    80202eaa:	4581                	li	a1,0
    80202eac:	855a                	mv	a0,s6
    80202eae:	00000097          	auipc	ra,0x0
    80202eb2:	f24080e7          	jalr	-220(ra) # 80202dd2 <uvmunmap>
    80202eb6:	557d                	li	a0,-1
    80202eb8:	a8b5                	j	80202f34 <uvmcopy+0xb2>
    for (uint64 i = 0; i < sz; i += PGSIZE) {
    80202eba:	6785                	lui	a5,0x1
    80202ebc:	94be                	add	s1,s1,a5
    80202ebe:	0744fa63          	bgeu	s1,s4,80202f32 <uvmcopy+0xb0>
        pte_t *pte = walk(old, i, 0);
    80202ec2:	4601                	li	a2,0
    80202ec4:	85a6                	mv	a1,s1
    80202ec6:	8556                	mv	a0,s5
    80202ec8:	00000097          	auipc	ra,0x0
    80202ecc:	bc6080e7          	jalr	-1082(ra) # 80202a8e <walk>
        if (!pte || !(*pte & PTE_V)) continue;
    80202ed0:	d56d                	beqz	a0,80202eba <uvmcopy+0x38>
    80202ed2:	6118                	ld	a4,0(a0)
    80202ed4:	00177793          	andi	a5,a4,1
    80202ed8:	d3ed                	beqz	a5,80202eba <uvmcopy+0x38>
        uint64 pa    = PTE2PA(*pte);
    80202eda:	00a75593          	srli	a1,a4,0xa
    80202ede:	00c59b93          	slli	s7,a1,0xc
        uint64 flags = PTE_FLAGS(*pte);
    80202ee2:	3ff77913          	andi	s2,a4,1023
        char *mem = palloc();
    80202ee6:	ffffe097          	auipc	ra,0xffffe
    80202eea:	1c0080e7          	jalr	448(ra) # 802010a6 <palloc>
    80202eee:	89aa                	mv	s3,a0
        if (!mem) { uvmunmap(new, 0, i / PGSIZE, 1); return -1; }
    80202ef0:	d955                	beqz	a0,80202ea4 <uvmcopy+0x22>
        memmove(mem, (void *)pa, PGSIZE);
    80202ef2:	6605                	lui	a2,0x1
    80202ef4:	85de                	mv	a1,s7
    80202ef6:	ffffd097          	auipc	ra,0xffffd
    80202efa:	7ca080e7          	jalr	1994(ra) # 802006c0 <memmove>
        if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    80202efe:	874a                	mv	a4,s2
    80202f00:	86ce                	mv	a3,s3
    80202f02:	6605                	lui	a2,0x1
    80202f04:	85a6                	mv	a1,s1
    80202f06:	855a                	mv	a0,s6
    80202f08:	00000097          	auipc	ra,0x0
    80202f0c:	c6c080e7          	jalr	-916(ra) # 80202b74 <mappages>
    80202f10:	d54d                	beqz	a0,80202eba <uvmcopy+0x38>
            pfree(mem);
    80202f12:	854e                	mv	a0,s3
    80202f14:	ffffe097          	auipc	ra,0xffffe
    80202f18:	2a2080e7          	jalr	674(ra) # 802011b6 <pfree>
            uvmunmap(new, 0, i / PGSIZE, 1);
    80202f1c:	4685                	li	a3,1
    80202f1e:	00c4d613          	srli	a2,s1,0xc
    80202f22:	4581                	li	a1,0
    80202f24:	855a                	mv	a0,s6
    80202f26:	00000097          	auipc	ra,0x0
    80202f2a:	eac080e7          	jalr	-340(ra) # 80202dd2 <uvmunmap>
            return -1;
    80202f2e:	557d                	li	a0,-1
    80202f30:	a011                	j	80202f34 <uvmcopy+0xb2>
    return 0;
    80202f32:	4501                	li	a0,0
}
    80202f34:	60a6                	ld	ra,72(sp)
    80202f36:	6406                	ld	s0,64(sp)
    80202f38:	74e2                	ld	s1,56(sp)
    80202f3a:	7942                	ld	s2,48(sp)
    80202f3c:	79a2                	ld	s3,40(sp)
    80202f3e:	7a02                	ld	s4,32(sp)
    80202f40:	6ae2                	ld	s5,24(sp)
    80202f42:	6b42                	ld	s6,16(sp)
    80202f44:	6ba2                	ld	s7,8(sp)
    80202f46:	6161                	addi	sp,sp,80
    80202f48:	8082                	ret
    return 0;
    80202f4a:	4501                	li	a0,0
}
    80202f4c:	8082                	ret

0000000080202f4e <copyout>:
    while (len > 0) {
    80202f4e:	c2d5                	beqz	a3,80202ff2 <copyout+0xa4>
{
    80202f50:	711d                	addi	sp,sp,-96
    80202f52:	ec86                	sd	ra,88(sp)
    80202f54:	e8a2                	sd	s0,80(sp)
    80202f56:	e4a6                	sd	s1,72(sp)
    80202f58:	fc4e                	sd	s3,56(sp)
    80202f5a:	f456                	sd	s5,40(sp)
    80202f5c:	f05a                	sd	s6,32(sp)
    80202f5e:	ec5e                	sd	s7,24(sp)
    80202f60:	1080                	addi	s0,sp,96
    80202f62:	8baa                	mv	s7,a0
    80202f64:	8aae                	mv	s5,a1
    80202f66:	8b32                	mv	s6,a2
    80202f68:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(dstva);
    80202f6a:	74fd                	lui	s1,0xfffff
    80202f6c:	8ced                	and	s1,s1,a1
        if (va0 >= USER_TOP) return -1;
    80202f6e:	800007b7          	lui	a5,0x80000
    80202f72:	fff7c793          	not	a5,a5
    80202f76:	0897e063          	bltu	a5,s1,80202ff6 <copyout+0xa8>
    80202f7a:	e0ca                	sd	s2,64(sp)
    80202f7c:	f852                	sd	s4,48(sp)
    80202f7e:	e862                	sd	s8,16(sp)
    80202f80:	e466                	sd	s9,8(sp)
    80202f82:	e06a                	sd	s10,0(sp)
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202f84:	4cc5                	li	s9,17
    80202f86:	6d05                	lui	s10,0x1
        if (va0 >= USER_TOP) return -1;
    80202f88:	8c3e                	mv	s8,a5
    80202f8a:	a02d                	j	80202fb4 <copyout+0x66>
        uint64 pa0 = PTE2PA(*pte);
    80202f8c:	83a9                	srli	a5,a5,0xa
    80202f8e:	07b2                	slli	a5,a5,0xc
        memmove((void *)(pa0 + (dstva - va0)), src, n);
    80202f90:	409a8533          	sub	a0,s5,s1
    80202f94:	864a                	mv	a2,s2
    80202f96:	85da                	mv	a1,s6
    80202f98:	953e                	add	a0,a0,a5
    80202f9a:	ffffd097          	auipc	ra,0xffffd
    80202f9e:	726080e7          	jalr	1830(ra) # 802006c0 <memmove>
        len -= n; src += n; dstva = va0 + PGSIZE;
    80202fa2:	412989b3          	sub	s3,s3,s2
    80202fa6:	9b4a                	add	s6,s6,s2
    while (len > 0) {
    80202fa8:	02098e63          	beqz	s3,80202fe4 <copyout+0x96>
        if (va0 >= USER_TOP) return -1;
    80202fac:	054c6763          	bltu	s8,s4,80202ffa <copyout+0xac>
    80202fb0:	84d2                	mv	s1,s4
    80202fb2:	8ad2                	mv	s5,s4
        pte_t *pte = walk(pt, va0, 0);
    80202fb4:	4601                	li	a2,0
    80202fb6:	85a6                	mv	a1,s1
    80202fb8:	855e                	mv	a0,s7
    80202fba:	00000097          	auipc	ra,0x0
    80202fbe:	ad4080e7          	jalr	-1324(ra) # 80202a8e <walk>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80202fc2:	c139                	beqz	a0,80203008 <copyout+0xba>
    80202fc4:	611c                	ld	a5,0(a0)
    80202fc6:	0117f713          	andi	a4,a5,17
    80202fca:	05971e63          	bne	a4,s9,80203026 <copyout+0xd8>
        if (!(*pte & PTE_W)) return -1;   /* read-only page: refuse.
    80202fce:	0047f713          	andi	a4,a5,4
    80202fd2:	c32d                	beqz	a4,80203034 <copyout+0xe6>
        uint64 n = PGSIZE - (dstva - va0);
    80202fd4:	01a48a33          	add	s4,s1,s10
    80202fd8:	415a0933          	sub	s2,s4,s5
        if (n > len) n = len;
    80202fdc:	fb29f8e3          	bgeu	s3,s2,80202f8c <copyout+0x3e>
    80202fe0:	894e                	mv	s2,s3
    80202fe2:	b76d                	j	80202f8c <copyout+0x3e>
    return 0;
    80202fe4:	4501                	li	a0,0
    80202fe6:	6906                	ld	s2,64(sp)
    80202fe8:	7a42                	ld	s4,48(sp)
    80202fea:	6c42                	ld	s8,16(sp)
    80202fec:	6ca2                	ld	s9,8(sp)
    80202fee:	6d02                	ld	s10,0(sp)
    80202ff0:	a015                	j	80203014 <copyout+0xc6>
    80202ff2:	4501                	li	a0,0
}
    80202ff4:	8082                	ret
        if (va0 >= USER_TOP) return -1;
    80202ff6:	557d                	li	a0,-1
    80202ff8:	a831                	j	80203014 <copyout+0xc6>
    80202ffa:	557d                	li	a0,-1
    80202ffc:	6906                	ld	s2,64(sp)
    80202ffe:	7a42                	ld	s4,48(sp)
    80203000:	6c42                	ld	s8,16(sp)
    80203002:	6ca2                	ld	s9,8(sp)
    80203004:	6d02                	ld	s10,0(sp)
    80203006:	a039                	j	80203014 <copyout+0xc6>
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203008:	557d                	li	a0,-1
    8020300a:	6906                	ld	s2,64(sp)
    8020300c:	7a42                	ld	s4,48(sp)
    8020300e:	6c42                	ld	s8,16(sp)
    80203010:	6ca2                	ld	s9,8(sp)
    80203012:	6d02                	ld	s10,0(sp)
}
    80203014:	60e6                	ld	ra,88(sp)
    80203016:	6446                	ld	s0,80(sp)
    80203018:	64a6                	ld	s1,72(sp)
    8020301a:	79e2                	ld	s3,56(sp)
    8020301c:	7aa2                	ld	s5,40(sp)
    8020301e:	7b02                	ld	s6,32(sp)
    80203020:	6be2                	ld	s7,24(sp)
    80203022:	6125                	addi	sp,sp,96
    80203024:	8082                	ret
        if (!pte || !(*pte & PTE_V) || !(*pte & PTE_U)) return -1;
    80203026:	557d                	li	a0,-1
    80203028:	6906                	ld	s2,64(sp)
    8020302a:	7a42                	ld	s4,48(sp)
    8020302c:	6c42                	ld	s8,16(sp)
    8020302e:	6ca2                	ld	s9,8(sp)
    80203030:	6d02                	ld	s10,0(sp)
    80203032:	b7cd                	j	80203014 <copyout+0xc6>
        if (!(*pte & PTE_W)) return -1;   /* read-only page: refuse.
    80203034:	557d                	li	a0,-1
    80203036:	6906                	ld	s2,64(sp)
    80203038:	7a42                	ld	s4,48(sp)
    8020303a:	6c42                	ld	s8,16(sp)
    8020303c:	6ca2                	ld	s9,8(sp)
    8020303e:	6d02                	ld	s10,0(sp)
    80203040:	bfd1                	j	80203014 <copyout+0xc6>

0000000080203042 <copyin>:
    while (len > 0) {
    80203042:	c6bd                	beqz	a3,802030b0 <copyin+0x6e>
{
    80203044:	715d                	addi	sp,sp,-80
    80203046:	e486                	sd	ra,72(sp)
    80203048:	e0a2                	sd	s0,64(sp)
    8020304a:	fc26                	sd	s1,56(sp)
    8020304c:	f84a                	sd	s2,48(sp)
    8020304e:	f44e                	sd	s3,40(sp)
    80203050:	f052                	sd	s4,32(sp)
    80203052:	ec56                	sd	s5,24(sp)
    80203054:	e85a                	sd	s6,16(sp)
    80203056:	e45e                	sd	s7,8(sp)
    80203058:	e062                	sd	s8,0(sp)
    8020305a:	0880                	addi	s0,sp,80
    8020305c:	8b2a                	mv	s6,a0
    8020305e:	8a2e                	mv	s4,a1
    80203060:	8c32                	mv	s8,a2
    80203062:	89b6                	mv	s3,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    80203064:	7bfd                	lui	s7,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    80203066:	6a85                	lui	s5,0x1
    80203068:	a015                	j	8020308c <copyin+0x4a>
        memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8020306a:	018505b3          	add	a1,a0,s8
    8020306e:	8626                	mv	a2,s1
    80203070:	412585b3          	sub	a1,a1,s2
    80203074:	8552                	mv	a0,s4
    80203076:	ffffd097          	auipc	ra,0xffffd
    8020307a:	64a080e7          	jalr	1610(ra) # 802006c0 <memmove>
        len -= n; dst += n; srcva = va0 + PGSIZE;
    8020307e:	409989b3          	sub	s3,s3,s1
    80203082:	9a26                	add	s4,s4,s1
    80203084:	01590c33          	add	s8,s2,s5
    while (len > 0) {
    80203088:	02098263          	beqz	s3,802030ac <copyin+0x6a>
        uint64 va0 = PGROUNDDOWN(srcva);
    8020308c:	017c7933          	and	s2,s8,s7
        uint64 pa0 = walkaddr(pt, va0);
    80203090:	85ca                	mv	a1,s2
    80203092:	855a                	mv	a0,s6
    80203094:	00000097          	auipc	ra,0x0
    80203098:	aa0080e7          	jalr	-1376(ra) # 80202b34 <walkaddr>
        if (pa0 == 0) return -1;
    8020309c:	cd01                	beqz	a0,802030b4 <copyin+0x72>
        uint64 n = PGSIZE - (srcva - va0);
    8020309e:	418904b3          	sub	s1,s2,s8
    802030a2:	94d6                	add	s1,s1,s5
        if (n > len) n = len;
    802030a4:	fc99f3e3          	bgeu	s3,s1,8020306a <copyin+0x28>
    802030a8:	84ce                	mv	s1,s3
    802030aa:	b7c1                	j	8020306a <copyin+0x28>
    return 0;
    802030ac:	4501                	li	a0,0
    802030ae:	a021                	j	802030b6 <copyin+0x74>
    802030b0:	4501                	li	a0,0
}
    802030b2:	8082                	ret
        if (pa0 == 0) return -1;
    802030b4:	557d                	li	a0,-1
}
    802030b6:	60a6                	ld	ra,72(sp)
    802030b8:	6406                	ld	s0,64(sp)
    802030ba:	74e2                	ld	s1,56(sp)
    802030bc:	7942                	ld	s2,48(sp)
    802030be:	79a2                	ld	s3,40(sp)
    802030c0:	7a02                	ld	s4,32(sp)
    802030c2:	6ae2                	ld	s5,24(sp)
    802030c4:	6b42                	ld	s6,16(sp)
    802030c6:	6ba2                	ld	s7,8(sp)
    802030c8:	6c02                	ld	s8,0(sp)
    802030ca:	6161                	addi	sp,sp,80
    802030cc:	8082                	ret

00000000802030ce <copyinstr>:
    while (got_null == 0 && max > 0) {
    802030ce:	c6cd                	beqz	a3,80203178 <copyinstr+0xaa>
{
    802030d0:	715d                	addi	sp,sp,-80
    802030d2:	e486                	sd	ra,72(sp)
    802030d4:	e0a2                	sd	s0,64(sp)
    802030d6:	fc26                	sd	s1,56(sp)
    802030d8:	f84a                	sd	s2,48(sp)
    802030da:	f44e                	sd	s3,40(sp)
    802030dc:	f052                	sd	s4,32(sp)
    802030de:	ec56                	sd	s5,24(sp)
    802030e0:	e85a                	sd	s6,16(sp)
    802030e2:	e45e                	sd	s7,8(sp)
    802030e4:	0880                	addi	s0,sp,80
    802030e6:	8a2a                	mv	s4,a0
    802030e8:	8b2e                	mv	s6,a1
    802030ea:	8bb2                	mv	s7,a2
    802030ec:	8936                	mv	s2,a3
        uint64 va0 = PGROUNDDOWN(srcva);
    802030ee:	7afd                	lui	s5,0xfffff
        uint64 n = PGSIZE - (srcva - va0);
    802030f0:	6985                	lui	s3,0x1
    802030f2:	a811                	j	80203106 <copyinstr+0x38>
    802030f4:	01258733          	add	a4,a1,s2
            dst++; p++; n--; max--;
    802030f8:	40f70933          	sub	s2,a4,a5
        srcva = va0 + PGSIZE;
    802030fc:	01348bb3          	add	s7,s1,s3
    while (got_null == 0 && max > 0) {
    80203100:	06e78463          	beq	a5,a4,80203168 <copyinstr+0x9a>
{
    80203104:	8b3e                	mv	s6,a5
        uint64 va0 = PGROUNDDOWN(srcva);
    80203106:	015bf4b3          	and	s1,s7,s5
        uint64 pa0 = walkaddr(pt, va0);
    8020310a:	85a6                	mv	a1,s1
    8020310c:	8552                	mv	a0,s4
    8020310e:	00000097          	auipc	ra,0x0
    80203112:	a26080e7          	jalr	-1498(ra) # 80202b34 <walkaddr>
        if (pa0 == 0) return -1;
    80203116:	c939                	beqz	a0,8020316c <copyinstr+0x9e>
        uint64 n = PGSIZE - (srcva - va0);
    80203118:	417486b3          	sub	a3,s1,s7
    8020311c:	96ce                	add	a3,a3,s3
        if (n > max) n = max;
    8020311e:	00d97363          	bgeu	s2,a3,80203124 <copyinstr+0x56>
    80203122:	86ca                	mv	a3,s2
        char *p = (char *)(pa0 + (srcva - va0));
    80203124:	955e                	add	a0,a0,s7
    80203126:	8d05                	sub	a0,a0,s1
        while (n > 0) {
    80203128:	c6a1                	beqz	a3,80203170 <copyinstr+0xa2>
    8020312a:	87da                	mv	a5,s6
    8020312c:	85da                	mv	a1,s6
            *dst = *p;
    8020312e:	41650633          	sub	a2,a0,s6
        while (n > 0) {
    80203132:	96da                	add	a3,a3,s6
            *dst = *p;
    80203134:	00c78733          	add	a4,a5,a2
    80203138:	00074703          	lbu	a4,0(a4)
    8020313c:	00e78023          	sb	a4,0(a5) # ffffffff80000000 <uart+0xfffffffeffcc0fd0>
            if (*p == '\0') { got_null = 1; break; }
    80203140:	c709                	beqz	a4,8020314a <copyinstr+0x7c>
            dst++; p++; n--; max--;
    80203142:	0785                	addi	a5,a5,1
        while (n > 0) {
    80203144:	fef698e3          	bne	a3,a5,80203134 <copyinstr+0x66>
    80203148:	b775                	j	802030f4 <copyinstr+0x26>
    8020314a:	4785                	li	a5,1
    return got_null ? 0 : -1;
    8020314c:	37fd                	addiw	a5,a5,-1
    8020314e:	0007851b          	sext.w	a0,a5
}
    80203152:	60a6                	ld	ra,72(sp)
    80203154:	6406                	ld	s0,64(sp)
    80203156:	74e2                	ld	s1,56(sp)
    80203158:	7942                	ld	s2,48(sp)
    8020315a:	79a2                	ld	s3,40(sp)
    8020315c:	7a02                	ld	s4,32(sp)
    8020315e:	6ae2                	ld	s5,24(sp)
    80203160:	6b42                	ld	s6,16(sp)
    80203162:	6ba2                	ld	s7,8(sp)
    80203164:	6161                	addi	sp,sp,80
    80203166:	8082                	ret
    80203168:	4781                	li	a5,0
    8020316a:	b7cd                	j	8020314c <copyinstr+0x7e>
        if (pa0 == 0) return -1;
    8020316c:	557d                	li	a0,-1
    8020316e:	b7d5                	j	80203152 <copyinstr+0x84>
        srcva = va0 + PGSIZE;
    80203170:	6b85                	lui	s7,0x1
    80203172:	9ba6                	add	s7,s7,s1
    80203174:	87da                	mv	a5,s6
    80203176:	b779                	j	80203104 <copyinstr+0x36>
    int got_null = 0;
    80203178:	4781                	li	a5,0
    return got_null ? 0 : -1;
    8020317a:	37fd                	addiw	a5,a5,-1
    8020317c:	0007851b          	sext.w	a0,a5
}
    80203180:	8082                	ret

0000000080203182 <vmprint>:
void vmprint(pagetable_t pt)
{
    80203182:	1101                	addi	sp,sp,-32
    80203184:	ec06                	sd	ra,24(sp)
    80203186:	e822                	sd	s0,16(sp)
    80203188:	e426                	sd	s1,8(sp)
    8020318a:	1000                	addi	s0,sp,32
    8020318c:	84aa                	mv	s1,a0
    printf("page table %p (user half)\n", pt);
    8020318e:	85aa                	mv	a1,a0
    80203190:	00004517          	auipc	a0,0x4
    80203194:	72050513          	addi	a0,a0,1824 # 802078b0 <etext+0x8b0>
    80203198:	ffffd097          	auipc	ra,0xffffd
    8020319c:	1f4080e7          	jalr	500(ra) # 8020038c <printf>
    vmprint_lvl(pt, 2);
    802031a0:	4589                	li	a1,2
    802031a2:	8526                	mv	a0,s1
    802031a4:	fffff097          	auipc	ra,0xfffff
    802031a8:	7fc080e7          	jalr	2044(ra) # 802029a0 <vmprint_lvl>
}
    802031ac:	60e2                	ld	ra,24(sp)
    802031ae:	6442                	ld	s0,16(sp)
    802031b0:	64a2                	ld	s1,8(sp)
    802031b2:	6105                	addi	sp,sp,32
    802031b4:	8082                	ret

00000000802031b6 <sys_getpid>:
    int n; argint(0, &n);
    exit(n);
    return 0;
}

uint64 sys_getpid(void) { return myproc()->pid; }
    802031b6:	1141                	addi	sp,sp,-16
    802031b8:	e406                	sd	ra,8(sp)
    802031ba:	e022                	sd	s0,0(sp)
    802031bc:	0800                	addi	s0,sp,16
    802031be:	ffffe097          	auipc	ra,0xffffe
    802031c2:	560080e7          	jalr	1376(ra) # 8020171e <myproc>
    802031c6:	5908                	lw	a0,48(a0)
    802031c8:	60a2                	ld	ra,8(sp)
    802031ca:	6402                	ld	s0,0(sp)
    802031cc:	0141                	addi	sp,sp,16
    802031ce:	8082                	ret

00000000802031d0 <argraw>:
{
    802031d0:	1101                	addi	sp,sp,-32
    802031d2:	ec06                	sd	ra,24(sp)
    802031d4:	e822                	sd	s0,16(sp)
    802031d6:	e426                	sd	s1,8(sp)
    802031d8:	1000                	addi	s0,sp,32
    802031da:	84aa                	mv	s1,a0
    struct trapframe *tf = myproc()->tf;
    802031dc:	ffffe097          	auipc	ra,0xffffe
    802031e0:	542080e7          	jalr	1346(ra) # 8020171e <myproc>
    802031e4:	6d34                	ld	a3,88(a0)
    switch (n) {
    802031e6:	4795                	li	a5,5
    802031e8:	0297eb63          	bltu	a5,s1,8020321e <argraw+0x4e>
    802031ec:	048a                	slli	s1,s1,0x2
    802031ee:	00005717          	auipc	a4,0x5
    802031f2:	c6a70713          	addi	a4,a4,-918 # 80207e58 <st.0+0x70>
    802031f6:	94ba                	add	s1,s1,a4
    802031f8:	409c                	lw	a5,0(s1)
    802031fa:	97ba                	add	a5,a5,a4
    802031fc:	8782                	jr	a5
    case 0: return tf->a0;
    802031fe:	7aa8                	ld	a0,112(a3)
}
    80203200:	60e2                	ld	ra,24(sp)
    80203202:	6442                	ld	s0,16(sp)
    80203204:	64a2                	ld	s1,8(sp)
    80203206:	6105                	addi	sp,sp,32
    80203208:	8082                	ret
    case 1: return tf->a1;
    8020320a:	7ea8                	ld	a0,120(a3)
    8020320c:	bfd5                	j	80203200 <argraw+0x30>
    case 2: return tf->a2;
    8020320e:	62c8                	ld	a0,128(a3)
    80203210:	bfc5                	j	80203200 <argraw+0x30>
    case 3: return tf->a3;
    80203212:	66c8                	ld	a0,136(a3)
    80203214:	b7f5                	j	80203200 <argraw+0x30>
    case 4: return tf->a4;
    80203216:	6ac8                	ld	a0,144(a3)
    80203218:	b7e5                	j	80203200 <argraw+0x30>
    case 5: return tf->a5;
    8020321a:	6ec8                	ld	a0,152(a3)
    8020321c:	b7d5                	j	80203200 <argraw+0x30>
    panic("argraw: bad arg index");
    8020321e:	00004517          	auipc	a0,0x4
    80203222:	6b250513          	addi	a0,a0,1714 # 802078d0 <etext+0x8d0>
    80203226:	ffffd097          	auipc	ra,0xffffd
    8020322a:	3d8080e7          	jalr	984(ra) # 802005fe <panic>

000000008020322e <sys_fork>:

uint64 sys_fork(void)   { return fork(); }
    8020322e:	1141                	addi	sp,sp,-16
    80203230:	e406                	sd	ra,8(sp)
    80203232:	e022                	sd	s0,0(sp)
    80203234:	0800                	addi	s0,sp,16
    80203236:	fffff097          	auipc	ra,0xfffff
    8020323a:	812080e7          	jalr	-2030(ra) # 80201a48 <fork>
    8020323e:	60a2                	ld	ra,8(sp)
    80203240:	6402                	ld	s0,0(sp)
    80203242:	0141                	addi	sp,sp,16
    80203244:	8082                	ret

0000000080203246 <sys_uptime>:
    int pid; argint(0, &pid);
    return kill(pid);
}

uint64 sys_uptime(void)
{
    80203246:	1101                	addi	sp,sp,-32
    80203248:	ec06                	sd	ra,24(sp)
    8020324a:	e822                	sd	s0,16(sp)
    8020324c:	e426                	sd	s1,8(sp)
    8020324e:	1000                	addi	s0,sp,32
    acquire(&tickslock);
    80203250:	0012d517          	auipc	a0,0x12d
    80203254:	7b050513          	addi	a0,a0,1968 # 80330a00 <tickslock>
    80203258:	ffffe097          	auipc	ra,0xffffe
    8020325c:	0dc080e7          	jalr	220(ra) # 80201334 <acquire>
    uint64 t = ticks;
    80203260:	0013c497          	auipc	s1,0x13c
    80203264:	db84b483          	ld	s1,-584(s1) # 8033f018 <ticks>
    release(&tickslock);
    80203268:	0012d517          	auipc	a0,0x12d
    8020326c:	79850513          	addi	a0,a0,1944 # 80330a00 <tickslock>
    80203270:	ffffe097          	auipc	ra,0xffffe
    80203274:	178080e7          	jalr	376(ra) # 802013e8 <release>
    return t;
}
    80203278:	8526                	mv	a0,s1
    8020327a:	60e2                	ld	ra,24(sp)
    8020327c:	6442                	ld	s0,16(sp)
    8020327e:	64a2                	ld	s1,8(sp)
    80203280:	6105                	addi	sp,sp,32
    80203282:	8082                	ret

0000000080203284 <sys_freepages>:

/* Luit extras: test hooks and observability (used by meminfo and ps). */
uint64 sys_freepages(void) { return palloc_free_count(); }
    80203284:	1141                	addi	sp,sp,-16
    80203286:	e406                	sd	ra,8(sp)
    80203288:	e022                	sd	s0,0(sp)
    8020328a:	0800                	addi	s0,sp,16
    8020328c:	ffffe097          	auipc	ra,0xffffe
    80203290:	ff2080e7          	jalr	-14(ra) # 8020127e <palloc_free_count>
    80203294:	60a2                	ld	ra,8(sp)
    80203296:	6402                	ld	s0,0(sp)
    80203298:	0141                	addi	sp,sp,16
    8020329a:	8082                	ret

000000008020329c <argint>:
int argint(int n, int *ip)     { *ip = (int)argraw(n); return 0; }
    8020329c:	1101                	addi	sp,sp,-32
    8020329e:	ec06                	sd	ra,24(sp)
    802032a0:	e822                	sd	s0,16(sp)
    802032a2:	e426                	sd	s1,8(sp)
    802032a4:	1000                	addi	s0,sp,32
    802032a6:	84ae                	mv	s1,a1
    802032a8:	00000097          	auipc	ra,0x0
    802032ac:	f28080e7          	jalr	-216(ra) # 802031d0 <argraw>
    802032b0:	c088                	sw	a0,0(s1)
    802032b2:	4501                	li	a0,0
    802032b4:	60e2                	ld	ra,24(sp)
    802032b6:	6442                	ld	s0,16(sp)
    802032b8:	64a2                	ld	s1,8(sp)
    802032ba:	6105                	addi	sp,sp,32
    802032bc:	8082                	ret

00000000802032be <sys_exit>:
{
    802032be:	1101                	addi	sp,sp,-32
    802032c0:	ec06                	sd	ra,24(sp)
    802032c2:	e822                	sd	s0,16(sp)
    802032c4:	1000                	addi	s0,sp,32
    int n; argint(0, &n);
    802032c6:	fec40593          	addi	a1,s0,-20
    802032ca:	4501                	li	a0,0
    802032cc:	00000097          	auipc	ra,0x0
    802032d0:	fd0080e7          	jalr	-48(ra) # 8020329c <argint>
    exit(n);
    802032d4:	fec42503          	lw	a0,-20(s0)
    802032d8:	fffff097          	auipc	ra,0xfffff
    802032dc:	ca6080e7          	jalr	-858(ra) # 80201f7e <exit>

00000000802032e0 <sys_sbrk>:
{
    802032e0:	7179                	addi	sp,sp,-48
    802032e2:	f406                	sd	ra,40(sp)
    802032e4:	f022                	sd	s0,32(sp)
    802032e6:	ec26                	sd	s1,24(sp)
    802032e8:	1800                	addi	s0,sp,48
    int n; argint(0, &n);
    802032ea:	fdc40593          	addi	a1,s0,-36
    802032ee:	4501                	li	a0,0
    802032f0:	00000097          	auipc	ra,0x0
    802032f4:	fac080e7          	jalr	-84(ra) # 8020329c <argint>
    uint64 addr = myproc()->sz;
    802032f8:	ffffe097          	auipc	ra,0xffffe
    802032fc:	426080e7          	jalr	1062(ra) # 8020171e <myproc>
    80203300:	6524                	ld	s1,72(a0)
    if (growproc(n) < 0) return -1;
    80203302:	fdc42503          	lw	a0,-36(s0)
    80203306:	ffffe097          	auipc	ra,0xffffe
    8020330a:	658080e7          	jalr	1624(ra) # 8020195e <growproc>
    8020330e:	00054863          	bltz	a0,8020331e <sys_sbrk+0x3e>
}
    80203312:	8526                	mv	a0,s1
    80203314:	70a2                	ld	ra,40(sp)
    80203316:	7402                	ld	s0,32(sp)
    80203318:	64e2                	ld	s1,24(sp)
    8020331a:	6145                	addi	sp,sp,48
    8020331c:	8082                	ret
    if (growproc(n) < 0) return -1;
    8020331e:	54fd                	li	s1,-1
    80203320:	bfcd                	j	80203312 <sys_sbrk+0x32>

0000000080203322 <sys_sleep>:
{
    80203322:	7139                	addi	sp,sp,-64
    80203324:	fc06                	sd	ra,56(sp)
    80203326:	f822                	sd	s0,48(sp)
    80203328:	f04a                	sd	s2,32(sp)
    8020332a:	ec4e                	sd	s3,24(sp)
    8020332c:	0080                	addi	s0,sp,64
    int n; argint(0, &n);
    8020332e:	fcc40593          	addi	a1,s0,-52
    80203332:	4501                	li	a0,0
    80203334:	00000097          	auipc	ra,0x0
    80203338:	f68080e7          	jalr	-152(ra) # 8020329c <argint>
    acquire(&tickslock);
    8020333c:	0012d517          	auipc	a0,0x12d
    80203340:	6c450513          	addi	a0,a0,1732 # 80330a00 <tickslock>
    80203344:	ffffe097          	auipc	ra,0xffffe
    80203348:	ff0080e7          	jalr	-16(ra) # 80201334 <acquire>
    uint64 t0 = ticks;
    8020334c:	0013c997          	auipc	s3,0x13c
    80203350:	ccc9b983          	ld	s3,-820(s3) # 8033f018 <ticks>
    while (ticks - t0 < (uint64)n) {
    80203354:	fcc42903          	lw	s2,-52(s0)
    80203358:	02090f63          	beqz	s2,80203396 <sys_sleep+0x74>
    8020335c:	f426                	sd	s1,40(sp)
    8020335e:	e852                	sd	s4,16(sp)
        sleep(&ticks, &tickslock);
    80203360:	0012da17          	auipc	s4,0x12d
    80203364:	6a0a0a13          	addi	s4,s4,1696 # 80330a00 <tickslock>
    80203368:	0013c497          	auipc	s1,0x13c
    8020336c:	cb048493          	addi	s1,s1,-848 # 8033f018 <ticks>
        if (myproc()->killed) { release(&tickslock); return -1; }
    80203370:	ffffe097          	auipc	ra,0xffffe
    80203374:	3ae080e7          	jalr	942(ra) # 8020171e <myproc>
    80203378:	551c                	lw	a5,40(a0)
    8020337a:	ef8d                	bnez	a5,802033b4 <sys_sleep+0x92>
        sleep(&ticks, &tickslock);
    8020337c:	85d2                	mv	a1,s4
    8020337e:	8526                	mv	a0,s1
    80203380:	fffff097          	auipc	ra,0xfffff
    80203384:	a02080e7          	jalr	-1534(ra) # 80201d82 <sleep>
    while (ticks - t0 < (uint64)n) {
    80203388:	609c                	ld	a5,0(s1)
    8020338a:	413787b3          	sub	a5,a5,s3
    8020338e:	ff27e1e3          	bltu	a5,s2,80203370 <sys_sleep+0x4e>
    80203392:	74a2                	ld	s1,40(sp)
    80203394:	6a42                	ld	s4,16(sp)
    release(&tickslock);
    80203396:	0012d517          	auipc	a0,0x12d
    8020339a:	66a50513          	addi	a0,a0,1642 # 80330a00 <tickslock>
    8020339e:	ffffe097          	auipc	ra,0xffffe
    802033a2:	04a080e7          	jalr	74(ra) # 802013e8 <release>
    return 0;
    802033a6:	4501                	li	a0,0
}
    802033a8:	70e2                	ld	ra,56(sp)
    802033aa:	7442                	ld	s0,48(sp)
    802033ac:	7902                	ld	s2,32(sp)
    802033ae:	69e2                	ld	s3,24(sp)
    802033b0:	6121                	addi	sp,sp,64
    802033b2:	8082                	ret
        if (myproc()->killed) { release(&tickslock); return -1; }
    802033b4:	0012d517          	auipc	a0,0x12d
    802033b8:	64c50513          	addi	a0,a0,1612 # 80330a00 <tickslock>
    802033bc:	ffffe097          	auipc	ra,0xffffe
    802033c0:	02c080e7          	jalr	44(ra) # 802013e8 <release>
    802033c4:	557d                	li	a0,-1
    802033c6:	74a2                	ld	s1,40(sp)
    802033c8:	6a42                	ld	s4,16(sp)
    802033ca:	bff9                	j	802033a8 <sys_sleep+0x86>

00000000802033cc <sys_kill>:
{
    802033cc:	1101                	addi	sp,sp,-32
    802033ce:	ec06                	sd	ra,24(sp)
    802033d0:	e822                	sd	s0,16(sp)
    802033d2:	1000                	addi	s0,sp,32
    int pid; argint(0, &pid);
    802033d4:	fec40593          	addi	a1,s0,-20
    802033d8:	4501                	li	a0,0
    802033da:	00000097          	auipc	ra,0x0
    802033de:	ec2080e7          	jalr	-318(ra) # 8020329c <argint>
    return kill(pid);
    802033e2:	fec42503          	lw	a0,-20(s0)
    802033e6:	fffff097          	auipc	ra,0xfffff
    802033ea:	c96080e7          	jalr	-874(ra) # 8020207c <kill>
}
    802033ee:	60e2                	ld	ra,24(sp)
    802033f0:	6442                	ld	s0,16(sp)
    802033f2:	6105                	addi	sp,sp,32
    802033f4:	8082                	ret

00000000802033f6 <argaddr>:
int argaddr(int n, uint64 *ap) { *ap = argraw(n); return 0; }
    802033f6:	1101                	addi	sp,sp,-32
    802033f8:	ec06                	sd	ra,24(sp)
    802033fa:	e822                	sd	s0,16(sp)
    802033fc:	e426                	sd	s1,8(sp)
    802033fe:	1000                	addi	s0,sp,32
    80203400:	84ae                	mv	s1,a1
    80203402:	00000097          	auipc	ra,0x0
    80203406:	dce080e7          	jalr	-562(ra) # 802031d0 <argraw>
    8020340a:	e088                	sd	a0,0(s1)
    8020340c:	4501                	li	a0,0
    8020340e:	60e2                	ld	ra,24(sp)
    80203410:	6442                	ld	s0,16(sp)
    80203412:	64a2                	ld	s1,8(sp)
    80203414:	6105                	addi	sp,sp,32
    80203416:	8082                	ret

0000000080203418 <sys_wait>:
{
    80203418:	1101                	addi	sp,sp,-32
    8020341a:	ec06                	sd	ra,24(sp)
    8020341c:	e822                	sd	s0,16(sp)
    8020341e:	1000                	addi	s0,sp,32
    uint64 p; argaddr(0, &p);
    80203420:	fe840593          	addi	a1,s0,-24
    80203424:	4501                	li	a0,0
    80203426:	00000097          	auipc	ra,0x0
    8020342a:	fd0080e7          	jalr	-48(ra) # 802033f6 <argaddr>
    return wait(p);
    8020342e:	fe843503          	ld	a0,-24(s0)
    80203432:	fffff097          	auipc	ra,0xfffff
    80203436:	9b4080e7          	jalr	-1612(ra) # 80201de6 <wait>
}
    8020343a:	60e2                	ld	ra,24(sp)
    8020343c:	6442                	ld	s0,16(sp)
    8020343e:	6105                	addi	sp,sp,32
    80203440:	8082                	ret

0000000080203442 <sys_procstat>:

uint64 sys_procstat(void)
{
    80203442:	1101                	addi	sp,sp,-32
    80203444:	ec06                	sd	ra,24(sp)
    80203446:	e822                	sd	s0,16(sp)
    80203448:	1000                	addi	s0,sp,32
    uint64 uaddr;
    int max;
    argaddr(0, &uaddr);
    8020344a:	fe840593          	addi	a1,s0,-24
    8020344e:	4501                	li	a0,0
    80203450:	00000097          	auipc	ra,0x0
    80203454:	fa6080e7          	jalr	-90(ra) # 802033f6 <argaddr>
    argint(1, &max);
    80203458:	fe440593          	addi	a1,s0,-28
    8020345c:	4505                	li	a0,1
    8020345e:	00000097          	auipc	ra,0x0
    80203462:	e3e080e7          	jalr	-450(ra) # 8020329c <argint>
    if (max <= 0) return -1;
    80203466:	fe442783          	lw	a5,-28(s0)
    8020346a:	02f05663          	blez	a5,80203496 <sys_procstat+0x54>
    if (max > NPROC) max = NPROC;
    8020346e:	04000713          	li	a4,64
    80203472:	00f75663          	bge	a4,a5,8020347e <sys_procstat+0x3c>
    80203476:	04000793          	li	a5,64
    8020347a:	fef42223          	sw	a5,-28(s0)
    return procstat(uaddr, max);
    8020347e:	fe442583          	lw	a1,-28(s0)
    80203482:	fe843503          	ld	a0,-24(s0)
    80203486:	fffff097          	auipc	ra,0xfffff
    8020348a:	c68080e7          	jalr	-920(ra) # 802020ee <procstat>
}
    8020348e:	60e2                	ld	ra,24(sp)
    80203490:	6442                	ld	s0,16(sp)
    80203492:	6105                	addi	sp,sp,32
    80203494:	8082                	ret
    if (max <= 0) return -1;
    80203496:	557d                	li	a0,-1
    80203498:	bfdd                	j	8020348e <sys_procstat+0x4c>

000000008020349a <fetchstr>:
{
    8020349a:	7179                	addi	sp,sp,-48
    8020349c:	f406                	sd	ra,40(sp)
    8020349e:	f022                	sd	s0,32(sp)
    802034a0:	ec26                	sd	s1,24(sp)
    802034a2:	e84a                	sd	s2,16(sp)
    802034a4:	e44e                	sd	s3,8(sp)
    802034a6:	1800                	addi	s0,sp,48
    802034a8:	892a                	mv	s2,a0
    802034aa:	84ae                	mv	s1,a1
    802034ac:	89b2                	mv	s3,a2
    struct proc *p = myproc();
    802034ae:	ffffe097          	auipc	ra,0xffffe
    802034b2:	270080e7          	jalr	624(ra) # 8020171e <myproc>
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    802034b6:	86ce                	mv	a3,s3
    802034b8:	864a                	mv	a2,s2
    802034ba:	85a6                	mv	a1,s1
    802034bc:	6928                	ld	a0,80(a0)
    802034be:	00000097          	auipc	ra,0x0
    802034c2:	c10080e7          	jalr	-1008(ra) # 802030ce <copyinstr>
    802034c6:	00054e63          	bltz	a0,802034e2 <fetchstr+0x48>
    return strlen(buf);
    802034ca:	8526                	mv	a0,s1
    802034cc:	ffffd097          	auipc	ra,0xffffd
    802034d0:	2d6080e7          	jalr	726(ra) # 802007a2 <strlen>
}
    802034d4:	70a2                	ld	ra,40(sp)
    802034d6:	7402                	ld	s0,32(sp)
    802034d8:	64e2                	ld	s1,24(sp)
    802034da:	6942                	ld	s2,16(sp)
    802034dc:	69a2                	ld	s3,8(sp)
    802034de:	6145                	addi	sp,sp,48
    802034e0:	8082                	ret
    if (copyinstr(p->pagetable, buf, addr, max) < 0) return -1;
    802034e2:	557d                	li	a0,-1
    802034e4:	bfc5                	j	802034d4 <fetchstr+0x3a>

00000000802034e6 <argstr>:
{
    802034e6:	7179                	addi	sp,sp,-48
    802034e8:	f406                	sd	ra,40(sp)
    802034ea:	f022                	sd	s0,32(sp)
    802034ec:	ec26                	sd	s1,24(sp)
    802034ee:	e84a                	sd	s2,16(sp)
    802034f0:	1800                	addi	s0,sp,48
    802034f2:	84ae                	mv	s1,a1
    802034f4:	8932                	mv	s2,a2
    argaddr(n, &addr);
    802034f6:	fd840593          	addi	a1,s0,-40
    802034fa:	00000097          	auipc	ra,0x0
    802034fe:	efc080e7          	jalr	-260(ra) # 802033f6 <argaddr>
    return fetchstr(addr, buf, max);
    80203502:	864a                	mv	a2,s2
    80203504:	85a6                	mv	a1,s1
    80203506:	fd843503          	ld	a0,-40(s0)
    8020350a:	00000097          	auipc	ra,0x0
    8020350e:	f90080e7          	jalr	-112(ra) # 8020349a <fetchstr>
}
    80203512:	70a2                	ld	ra,40(sp)
    80203514:	7402                	ld	s0,32(sp)
    80203516:	64e2                	ld	s1,24(sp)
    80203518:	6942                	ld	s2,16(sp)
    8020351a:	6145                	addi	sp,sp,48
    8020351c:	8082                	ret

000000008020351e <syscall>:
/* ---- dispatch ---- */

#include "syscalltab.h"     /* GENERATED: syscalls[] and syscall_names[] */

void syscall(void)
{
    8020351e:	1101                	addi	sp,sp,-32
    80203520:	ec06                	sd	ra,24(sp)
    80203522:	e822                	sd	s0,16(sp)
    80203524:	e426                	sd	s1,8(sp)
    80203526:	e04a                	sd	s2,0(sp)
    80203528:	1000                	addi	s0,sp,32
    struct proc *p = myproc();
    8020352a:	ffffe097          	auipc	ra,0xffffe
    8020352e:	1f4080e7          	jalr	500(ra) # 8020171e <myproc>
    80203532:	84aa                	mv	s1,a0
    uint64 num = p->tf->a7;
    80203534:	05853903          	ld	s2,88(a0)
    80203538:	0a893683          	ld	a3,168(s2)

    /* Validate the number BEFORE indexing the table. A bad syscall number is a
     * hostile input, not a bug - return an error and stay alive.
     * Lab 2 (trace) hooks in HERE: this is the one point every call crosses. */
    if (num > 0 && num < sizeof(syscalls)/sizeof(syscalls[0]) && syscalls[num]) {
    8020353c:	fff68713          	addi	a4,a3,-1 # 3fff <_entry-0x801fc001>
    80203540:	47d9                	li	a5,22
    80203542:	00e7ef63          	bltu	a5,a4,80203560 <syscall+0x42>
    80203546:	00369713          	slli	a4,a3,0x3
    8020354a:	00005797          	auipc	a5,0x5
    8020354e:	92678793          	addi	a5,a5,-1754 # 80207e70 <syscalls>
    80203552:	97ba                	add	a5,a5,a4
    80203554:	639c                	ld	a5,0(a5)
    80203556:	c789                	beqz	a5,80203560 <syscall+0x42>
        p->tf->a0 = syscalls[num]();
    80203558:	9782                	jalr	a5
    8020355a:	06a93823          	sd	a0,112(s2)
    8020355e:	a839                	j	8020357c <syscall+0x5e>
    } else {
        printf("pid %d (%s): unknown syscall %d\n", p->pid, p->name, num);
    80203560:	15848613          	addi	a2,s1,344
    80203564:	588c                	lw	a1,48(s1)
    80203566:	00004517          	auipc	a0,0x4
    8020356a:	38250513          	addi	a0,a0,898 # 802078e8 <etext+0x8e8>
    8020356e:	ffffd097          	auipc	ra,0xffffd
    80203572:	e1e080e7          	jalr	-482(ra) # 8020038c <printf>
        p->tf->a0 = -1;
    80203576:	6cbc                	ld	a5,88(s1)
    80203578:	577d                	li	a4,-1
    8020357a:	fbb8                	sd	a4,112(a5)
    }
    (void)syscall_name;      /* used by Lab 2; referenced here to stay warning-clean */
}
    8020357c:	60e2                	ld	ra,24(sp)
    8020357e:	6442                	ld	s0,16(sp)
    80203580:	64a2                	ld	s1,8(sp)
    80203582:	6902                	ld	s2,0(sp)
    80203584:	6105                	addi	sp,sp,32
    80203586:	8082                	ret

0000000080203588 <argfd>:
#include "defs.h"
#include "fcntl.h"

/* Fetch the n'th arg as a file descriptor; return the struct file too. */
static int argfd(int n, int *pfd, struct file **pf)
{
    80203588:	7179                	addi	sp,sp,-48
    8020358a:	f406                	sd	ra,40(sp)
    8020358c:	f022                	sd	s0,32(sp)
    8020358e:	ec26                	sd	s1,24(sp)
    80203590:	e84a                	sd	s2,16(sp)
    80203592:	1800                	addi	s0,sp,48
    80203594:	892e                	mv	s2,a1
    80203596:	84b2                	mv	s1,a2
    int fd;
    argint(n, &fd);
    80203598:	fdc40593          	addi	a1,s0,-36
    8020359c:	00000097          	auipc	ra,0x0
    802035a0:	d00080e7          	jalr	-768(ra) # 8020329c <argint>
    if (fd < 0 || fd >= NOFILE) return -1;
    802035a4:	fdc42703          	lw	a4,-36(s0)
    802035a8:	47bd                	li	a5,15
    802035aa:	02e7eb63          	bltu	a5,a4,802035e0 <argfd+0x58>
    struct file *f = myproc()->ofile[fd];
    802035ae:	ffffe097          	auipc	ra,0xffffe
    802035b2:	170080e7          	jalr	368(ra) # 8020171e <myproc>
    802035b6:	fdc42703          	lw	a4,-36(s0)
    802035ba:	01a70793          	addi	a5,a4,26
    802035be:	078e                	slli	a5,a5,0x3
    802035c0:	953e                	add	a0,a0,a5
    802035c2:	611c                	ld	a5,0(a0)
    if (f == 0) return -1;
    802035c4:	c385                	beqz	a5,802035e4 <argfd+0x5c>
    if (pfd) *pfd = fd;
    802035c6:	00090463          	beqz	s2,802035ce <argfd+0x46>
    802035ca:	00e92023          	sw	a4,0(s2)
    if (pf)  *pf  = f;
    return 0;
    802035ce:	4501                	li	a0,0
    if (pf)  *pf  = f;
    802035d0:	c091                	beqz	s1,802035d4 <argfd+0x4c>
    802035d2:	e09c                	sd	a5,0(s1)
}
    802035d4:	70a2                	ld	ra,40(sp)
    802035d6:	7402                	ld	s0,32(sp)
    802035d8:	64e2                	ld	s1,24(sp)
    802035da:	6942                	ld	s2,16(sp)
    802035dc:	6145                	addi	sp,sp,48
    802035de:	8082                	ret
    if (fd < 0 || fd >= NOFILE) return -1;
    802035e0:	557d                	li	a0,-1
    802035e2:	bfcd                	j	802035d4 <argfd+0x4c>
    if (f == 0) return -1;
    802035e4:	557d                	li	a0,-1
    802035e6:	b7fd                	j	802035d4 <argfd+0x4c>

00000000802035e8 <fdalloc>:

/* Install f in the first free slot of the fd table. */
static int fdalloc(struct file *f)
{
    802035e8:	1101                	addi	sp,sp,-32
    802035ea:	ec06                	sd	ra,24(sp)
    802035ec:	e822                	sd	s0,16(sp)
    802035ee:	e426                	sd	s1,8(sp)
    802035f0:	1000                	addi	s0,sp,32
    802035f2:	84aa                	mv	s1,a0
    struct proc *p = myproc();
    802035f4:	ffffe097          	auipc	ra,0xffffe
    802035f8:	12a080e7          	jalr	298(ra) # 8020171e <myproc>
    802035fc:	862a                	mv	a2,a0
    for (int fd = 0; fd < NOFILE; fd++) {
    802035fe:	0d050793          	addi	a5,a0,208
    80203602:	4501                	li	a0,0
    80203604:	46c1                	li	a3,16
        if (p->ofile[fd] == 0) {
    80203606:	6398                	ld	a4,0(a5)
    80203608:	cb19                	beqz	a4,8020361e <fdalloc+0x36>
    for (int fd = 0; fd < NOFILE; fd++) {
    8020360a:	2505                	addiw	a0,a0,1
    8020360c:	07a1                	addi	a5,a5,8
    8020360e:	fed51ce3          	bne	a0,a3,80203606 <fdalloc+0x1e>
            p->ofile[fd] = f;
            return fd;
        }
    }
    return -1;
    80203612:	557d                	li	a0,-1
}
    80203614:	60e2                	ld	ra,24(sp)
    80203616:	6442                	ld	s0,16(sp)
    80203618:	64a2                	ld	s1,8(sp)
    8020361a:	6105                	addi	sp,sp,32
    8020361c:	8082                	ret
            p->ofile[fd] = f;
    8020361e:	01a50793          	addi	a5,a0,26
    80203622:	078e                	slli	a5,a5,0x3
    80203624:	963e                	add	a2,a2,a5
    80203626:	e204                	sd	s1,0(a2)
            return fd;
    80203628:	b7f5                	j	80203614 <fdalloc+0x2c>

000000008020362a <create>:
}

/* Create path as type. Returns LOCKED inode, or 0. Handles the T_DIR case
 * (".", "..", parent nlink) and open(O_CREATE) racing an existing file. */
static struct inode *create(char *path, uint16 type, uint16 major, uint16 minor)
{
    8020362a:	711d                	addi	sp,sp,-96
    8020362c:	ec86                	sd	ra,88(sp)
    8020362e:	e8a2                	sd	s0,80(sp)
    80203630:	e4a6                	sd	s1,72(sp)
    80203632:	e0ca                	sd	s2,64(sp)
    80203634:	fc4e                	sd	s3,56(sp)
    80203636:	f456                	sd	s5,40(sp)
    80203638:	f05a                	sd	s6,32(sp)
    8020363a:	1080                	addi	s0,sp,96
    8020363c:	8b2e                	mv	s6,a1
    8020363e:	89b2                	mv	s3,a2
    80203640:	8936                	mv	s2,a3
    char name[DIRSIZ];
    struct inode *dp = nameiparent(path, name);
    80203642:	fa040593          	addi	a1,s0,-96
    80203646:	00002097          	auipc	ra,0x2
    8020364a:	2cc080e7          	jalr	716(ra) # 80205912 <nameiparent>
    8020364e:	84aa                	mv	s1,a0
    if (dp == 0) return 0;
    80203650:	16050263          	beqz	a0,802037b4 <create+0x18a>
    ilock(dp);
    80203654:	00002097          	auipc	ra,0x2
    80203658:	a0c080e7          	jalr	-1524(ra) # 80205060 <ilock>

    struct inode *ip = dirlookup(dp, name, 0);
    8020365c:	4601                	li	a2,0
    8020365e:	fa040593          	addi	a1,s0,-96
    80203662:	8526                	mv	a0,s1
    80203664:	00002097          	auipc	ra,0x2
    80203668:	fc6080e7          	jalr	-58(ra) # 8020562a <dirlookup>
    8020366c:	8aaa                	mv	s5,a0
    if (ip != 0) {
    8020366e:	c929                	beqz	a0,802036c0 <create+0x96>
        iunlockput(dp);
    80203670:	8526                	mv	a0,s1
    80203672:	00002097          	auipc	ra,0x2
    80203676:	cca080e7          	jalr	-822(ra) # 8020533c <iunlockput>
        ilock(ip);
    8020367a:	8556                	mv	a0,s5
    8020367c:	00002097          	auipc	ra,0x2
    80203680:	9e4080e7          	jalr	-1564(ra) # 80205060 <ilock>
        if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEV))
    80203684:	000b059b          	sext.w	a1,s6
    80203688:	4789                	li	a5,2
    8020368a:	02f59463          	bne	a1,a5,802036b2 <create+0x88>
    8020368e:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <uart+0xffffffff7fcc0014>
    80203692:	37f9                	addiw	a5,a5,-2
    80203694:	17c2                	slli	a5,a5,0x30
    80203696:	93c1                	srli	a5,a5,0x30
    80203698:	4705                	li	a4,1
    8020369a:	00f76c63          	bltu	a4,a5,802036b2 <create+0x88>
    ip->nlink = 0;
    iupdate(ip);
    iunlockput(ip);
    iunlockput(dp);
    return 0;
}
    8020369e:	8556                	mv	a0,s5
    802036a0:	60e6                	ld	ra,88(sp)
    802036a2:	6446                	ld	s0,80(sp)
    802036a4:	64a6                	ld	s1,72(sp)
    802036a6:	6906                	ld	s2,64(sp)
    802036a8:	79e2                	ld	s3,56(sp)
    802036aa:	7aa2                	ld	s5,40(sp)
    802036ac:	7b02                	ld	s6,32(sp)
    802036ae:	6125                	addi	sp,sp,96
    802036b0:	8082                	ret
        iunlockput(ip);
    802036b2:	8556                	mv	a0,s5
    802036b4:	00002097          	auipc	ra,0x2
    802036b8:	c88080e7          	jalr	-888(ra) # 8020533c <iunlockput>
        return 0;
    802036bc:	4a81                	li	s5,0
    802036be:	b7c5                	j	8020369e <create+0x74>
    802036c0:	f852                	sd	s4,48(sp)
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    802036c2:	85da                	mv	a1,s6
    802036c4:	4088                	lw	a0,0(s1)
    802036c6:	00001097          	auipc	ra,0x1
    802036ca:	79e080e7          	jalr	1950(ra) # 80204e64 <ialloc>
    802036ce:	8a2a                	mv	s4,a0
    802036d0:	c921                	beqz	a0,80203720 <create+0xf6>
    ilock(ip);
    802036d2:	00002097          	auipc	ra,0x2
    802036d6:	98e080e7          	jalr	-1650(ra) # 80205060 <ilock>
    ip->major = major;
    802036da:	053a1323          	sh	s3,70(s4)
    ip->minor = minor;
    802036de:	052a1423          	sh	s2,72(s4)
    ip->nlink = 1;
    802036e2:	4905                	li	s2,1
    802036e4:	052a1523          	sh	s2,74(s4)
    iupdate(ip);
    802036e8:	8552                	mv	a0,s4
    802036ea:	00002097          	auipc	ra,0x2
    802036ee:	8aa080e7          	jalr	-1878(ra) # 80204f94 <iupdate>
    if (type == T_DIR) {
    802036f2:	000b059b          	sext.w	a1,s6
    802036f6:	03258d63          	beq	a1,s2,80203730 <create+0x106>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    802036fa:	004a2603          	lw	a2,4(s4)
    802036fe:	fa040593          	addi	a1,s0,-96
    80203702:	8526                	mv	a0,s1
    80203704:	00002097          	auipc	ra,0x2
    80203708:	136080e7          	jalr	310(ra) # 8020583a <dirlink>
    8020370c:	08054163          	bltz	a0,8020378e <create+0x164>
    iunlockput(dp);
    80203710:	8526                	mv	a0,s1
    80203712:	00002097          	auipc	ra,0x2
    80203716:	c2a080e7          	jalr	-982(ra) # 8020533c <iunlockput>
    return ip;
    8020371a:	8ad2                	mv	s5,s4
    8020371c:	7a42                	ld	s4,48(sp)
    8020371e:	b741                	j	8020369e <create+0x74>
    if ((ip = ialloc(dp->dev, type)) == 0) { iunlockput(dp); return 0; }
    80203720:	8526                	mv	a0,s1
    80203722:	00002097          	auipc	ra,0x2
    80203726:	c1a080e7          	jalr	-998(ra) # 8020533c <iunlockput>
    8020372a:	8ad2                	mv	s5,s4
    8020372c:	7a42                	ld	s4,48(sp)
    8020372e:	bf85                	j	8020369e <create+0x74>
        if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80203730:	004a2603          	lw	a2,4(s4)
    80203734:	00004597          	auipc	a1,0x4
    80203738:	1dc58593          	addi	a1,a1,476 # 80207910 <etext+0x910>
    8020373c:	8552                	mv	a0,s4
    8020373e:	00002097          	auipc	ra,0x2
    80203742:	0fc080e7          	jalr	252(ra) # 8020583a <dirlink>
    80203746:	04054463          	bltz	a0,8020378e <create+0x164>
    8020374a:	40d0                	lw	a2,4(s1)
    8020374c:	00004597          	auipc	a1,0x4
    80203750:	1cc58593          	addi	a1,a1,460 # 80207918 <etext+0x918>
    80203754:	8552                	mv	a0,s4
    80203756:	00002097          	auipc	ra,0x2
    8020375a:	0e4080e7          	jalr	228(ra) # 8020583a <dirlink>
    8020375e:	02054863          	bltz	a0,8020378e <create+0x164>
    if (dirlink(dp, name, ip->inum) < 0) goto fail;
    80203762:	004a2603          	lw	a2,4(s4)
    80203766:	fa040593          	addi	a1,s0,-96
    8020376a:	8526                	mv	a0,s1
    8020376c:	00002097          	auipc	ra,0x2
    80203770:	0ce080e7          	jalr	206(ra) # 8020583a <dirlink>
    80203774:	00054d63          	bltz	a0,8020378e <create+0x164>
        dp->nlink++;
    80203778:	04a4d783          	lhu	a5,74(s1)
    8020377c:	2785                	addiw	a5,a5,1
    8020377e:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80203782:	8526                	mv	a0,s1
    80203784:	00002097          	auipc	ra,0x2
    80203788:	810080e7          	jalr	-2032(ra) # 80204f94 <iupdate>
    8020378c:	b751                	j	80203710 <create+0xe6>
    ip->nlink = 0;
    8020378e:	040a1523          	sh	zero,74(s4)
    iupdate(ip);
    80203792:	8552                	mv	a0,s4
    80203794:	00002097          	auipc	ra,0x2
    80203798:	800080e7          	jalr	-2048(ra) # 80204f94 <iupdate>
    iunlockput(ip);
    8020379c:	8552                	mv	a0,s4
    8020379e:	00002097          	auipc	ra,0x2
    802037a2:	b9e080e7          	jalr	-1122(ra) # 8020533c <iunlockput>
    iunlockput(dp);
    802037a6:	8526                	mv	a0,s1
    802037a8:	00002097          	auipc	ra,0x2
    802037ac:	b94080e7          	jalr	-1132(ra) # 8020533c <iunlockput>
    return 0;
    802037b0:	7a42                	ld	s4,48(sp)
    802037b2:	b5f5                	j	8020369e <create+0x74>
    if (dp == 0) return 0;
    802037b4:	8aaa                	mv	s5,a0
    802037b6:	b5e5                	j	8020369e <create+0x74>

00000000802037b8 <sys_dup>:
{
    802037b8:	7179                	addi	sp,sp,-48
    802037ba:	f406                	sd	ra,40(sp)
    802037bc:	f022                	sd	s0,32(sp)
    802037be:	1800                	addi	s0,sp,48
    if (argfd(0, 0, &f) < 0) return -1;
    802037c0:	fd840613          	addi	a2,s0,-40
    802037c4:	4581                	li	a1,0
    802037c6:	4501                	li	a0,0
    802037c8:	00000097          	auipc	ra,0x0
    802037cc:	dc0080e7          	jalr	-576(ra) # 80203588 <argfd>
    802037d0:	57fd                	li	a5,-1
    802037d2:	02054763          	bltz	a0,80203800 <sys_dup+0x48>
    802037d6:	ec26                	sd	s1,24(sp)
    802037d8:	e84a                	sd	s2,16(sp)
    int fd = fdalloc(f);
    802037da:	fd843903          	ld	s2,-40(s0)
    802037de:	854a                	mv	a0,s2
    802037e0:	00000097          	auipc	ra,0x0
    802037e4:	e08080e7          	jalr	-504(ra) # 802035e8 <fdalloc>
    802037e8:	84aa                	mv	s1,a0
    if (fd < 0) return -1;
    802037ea:	57fd                	li	a5,-1
    802037ec:	00054f63          	bltz	a0,8020380a <sys_dup+0x52>
    filedup(f);
    802037f0:	854a                	mv	a0,s2
    802037f2:	00002097          	auipc	ra,0x2
    802037f6:	1ce080e7          	jalr	462(ra) # 802059c0 <filedup>
    return fd;
    802037fa:	87a6                	mv	a5,s1
    802037fc:	64e2                	ld	s1,24(sp)
    802037fe:	6942                	ld	s2,16(sp)
}
    80203800:	853e                	mv	a0,a5
    80203802:	70a2                	ld	ra,40(sp)
    80203804:	7402                	ld	s0,32(sp)
    80203806:	6145                	addi	sp,sp,48
    80203808:	8082                	ret
    8020380a:	64e2                	ld	s1,24(sp)
    8020380c:	6942                	ld	s2,16(sp)
    8020380e:	bfcd                	j	80203800 <sys_dup+0x48>

0000000080203810 <sys_read>:
{
    80203810:	7179                	addi	sp,sp,-48
    80203812:	f406                	sd	ra,40(sp)
    80203814:	f022                	sd	s0,32(sp)
    80203816:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    80203818:	fd840593          	addi	a1,s0,-40
    8020381c:	4505                	li	a0,1
    8020381e:	00000097          	auipc	ra,0x0
    80203822:	bd8080e7          	jalr	-1064(ra) # 802033f6 <argaddr>
    argint(2, &n);
    80203826:	fe440593          	addi	a1,s0,-28
    8020382a:	4509                	li	a0,2
    8020382c:	00000097          	auipc	ra,0x0
    80203830:	a70080e7          	jalr	-1424(ra) # 8020329c <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203834:	fe840613          	addi	a2,s0,-24
    80203838:	4581                	li	a1,0
    8020383a:	4501                	li	a0,0
    8020383c:	00000097          	auipc	ra,0x0
    80203840:	d4c080e7          	jalr	-692(ra) # 80203588 <argfd>
    80203844:	02054363          	bltz	a0,8020386a <sys_read+0x5a>
    80203848:	fe442603          	lw	a2,-28(s0)
    8020384c:	557d                	li	a0,-1
    8020384e:	00064a63          	bltz	a2,80203862 <sys_read+0x52>
    return fileread(f, p, n);
    80203852:	fd843583          	ld	a1,-40(s0)
    80203856:	fe843503          	ld	a0,-24(s0)
    8020385a:	00002097          	auipc	ra,0x2
    8020385e:	2f4080e7          	jalr	756(ra) # 80205b4e <fileread>
}
    80203862:	70a2                	ld	ra,40(sp)
    80203864:	7402                	ld	s0,32(sp)
    80203866:	6145                	addi	sp,sp,48
    80203868:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    8020386a:	557d                	li	a0,-1
    8020386c:	bfdd                	j	80203862 <sys_read+0x52>

000000008020386e <sys_write>:
{
    8020386e:	7179                	addi	sp,sp,-48
    80203870:	f406                	sd	ra,40(sp)
    80203872:	f022                	sd	s0,32(sp)
    80203874:	1800                	addi	s0,sp,48
    argaddr(1, &p);
    80203876:	fd840593          	addi	a1,s0,-40
    8020387a:	4505                	li	a0,1
    8020387c:	00000097          	auipc	ra,0x0
    80203880:	b7a080e7          	jalr	-1158(ra) # 802033f6 <argaddr>
    argint(2, &n);
    80203884:	fe440593          	addi	a1,s0,-28
    80203888:	4509                	li	a0,2
    8020388a:	00000097          	auipc	ra,0x0
    8020388e:	a12080e7          	jalr	-1518(ra) # 8020329c <argint>
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    80203892:	fe840613          	addi	a2,s0,-24
    80203896:	4581                	li	a1,0
    80203898:	4501                	li	a0,0
    8020389a:	00000097          	auipc	ra,0x0
    8020389e:	cee080e7          	jalr	-786(ra) # 80203588 <argfd>
    802038a2:	02054363          	bltz	a0,802038c8 <sys_write+0x5a>
    802038a6:	fe442603          	lw	a2,-28(s0)
    802038aa:	557d                	li	a0,-1
    802038ac:	00064a63          	bltz	a2,802038c0 <sys_write+0x52>
    return filewrite(f, p, n);
    802038b0:	fd843583          	ld	a1,-40(s0)
    802038b4:	fe843503          	ld	a0,-24(s0)
    802038b8:	00002097          	auipc	ra,0x2
    802038bc:	36a080e7          	jalr	874(ra) # 80205c22 <filewrite>
}
    802038c0:	70a2                	ld	ra,40(sp)
    802038c2:	7402                	ld	s0,32(sp)
    802038c4:	6145                	addi	sp,sp,48
    802038c6:	8082                	ret
    if (argfd(0, 0, &f) < 0 || n < 0) return -1;
    802038c8:	557d                	li	a0,-1
    802038ca:	bfdd                	j	802038c0 <sys_write+0x52>

00000000802038cc <sys_close>:
{
    802038cc:	1101                	addi	sp,sp,-32
    802038ce:	ec06                	sd	ra,24(sp)
    802038d0:	e822                	sd	s0,16(sp)
    802038d2:	1000                	addi	s0,sp,32
    if (argfd(0, &fd, &f) < 0) return -1;
    802038d4:	fe040613          	addi	a2,s0,-32
    802038d8:	fec40593          	addi	a1,s0,-20
    802038dc:	4501                	li	a0,0
    802038de:	00000097          	auipc	ra,0x0
    802038e2:	caa080e7          	jalr	-854(ra) # 80203588 <argfd>
    802038e6:	57fd                	li	a5,-1
    802038e8:	02054463          	bltz	a0,80203910 <sys_close+0x44>
    myproc()->ofile[fd] = 0;
    802038ec:	ffffe097          	auipc	ra,0xffffe
    802038f0:	e32080e7          	jalr	-462(ra) # 8020171e <myproc>
    802038f4:	fec42783          	lw	a5,-20(s0)
    802038f8:	07e9                	addi	a5,a5,26
    802038fa:	078e                	slli	a5,a5,0x3
    802038fc:	953e                	add	a0,a0,a5
    802038fe:	00053023          	sd	zero,0(a0)
    fileclose(f);
    80203902:	fe043503          	ld	a0,-32(s0)
    80203906:	00002097          	auipc	ra,0x2
    8020390a:	10c080e7          	jalr	268(ra) # 80205a12 <fileclose>
    return 0;
    8020390e:	4781                	li	a5,0
}
    80203910:	853e                	mv	a0,a5
    80203912:	60e2                	ld	ra,24(sp)
    80203914:	6442                	ld	s0,16(sp)
    80203916:	6105                	addi	sp,sp,32
    80203918:	8082                	ret

000000008020391a <sys_fstat>:
{
    8020391a:	1101                	addi	sp,sp,-32
    8020391c:	ec06                	sd	ra,24(sp)
    8020391e:	e822                	sd	s0,16(sp)
    80203920:	1000                	addi	s0,sp,32
    argaddr(1, &st);
    80203922:	fe040593          	addi	a1,s0,-32
    80203926:	4505                	li	a0,1
    80203928:	00000097          	auipc	ra,0x0
    8020392c:	ace080e7          	jalr	-1330(ra) # 802033f6 <argaddr>
    if (argfd(0, 0, &f) < 0) return -1;
    80203930:	fe840613          	addi	a2,s0,-24
    80203934:	4581                	li	a1,0
    80203936:	4501                	li	a0,0
    80203938:	00000097          	auipc	ra,0x0
    8020393c:	c50080e7          	jalr	-944(ra) # 80203588 <argfd>
    80203940:	87aa                	mv	a5,a0
    80203942:	557d                	li	a0,-1
    80203944:	0007ca63          	bltz	a5,80203958 <sys_fstat+0x3e>
    return filestat(f, st);
    80203948:	fe043583          	ld	a1,-32(s0)
    8020394c:	fe843503          	ld	a0,-24(s0)
    80203950:	00002097          	auipc	ra,0x2
    80203954:	194080e7          	jalr	404(ra) # 80205ae4 <filestat>
}
    80203958:	60e2                	ld	ra,24(sp)
    8020395a:	6442                	ld	s0,16(sp)
    8020395c:	6105                	addi	sp,sp,32
    8020395e:	8082                	ret

0000000080203960 <sys_link>:
{
    80203960:	7129                	addi	sp,sp,-320
    80203962:	fe06                	sd	ra,312(sp)
    80203964:	fa22                	sd	s0,304(sp)
    80203966:	0280                	addi	s0,sp,320
    if (argstr(0, oldp, MAXPATH) < 0 || argstr(1, newp, MAXPATH) < 0) return -1;
    80203968:	08000613          	li	a2,128
    8020396c:	ec040593          	addi	a1,s0,-320
    80203970:	4501                	li	a0,0
    80203972:	00000097          	auipc	ra,0x0
    80203976:	b74080e7          	jalr	-1164(ra) # 802034e6 <argstr>
    8020397a:	57fd                	li	a5,-1
    8020397c:	0e054f63          	bltz	a0,80203a7a <sys_link+0x11a>
    80203980:	08000613          	li	a2,128
    80203984:	f4040593          	addi	a1,s0,-192
    80203988:	4505                	li	a0,1
    8020398a:	00000097          	auipc	ra,0x0
    8020398e:	b5c080e7          	jalr	-1188(ra) # 802034e6 <argstr>
    80203992:	57fd                	li	a5,-1
    80203994:	0e054363          	bltz	a0,80203a7a <sys_link+0x11a>
    80203998:	f626                	sd	s1,296(sp)
    struct inode *ip = namei(oldp);
    8020399a:	ec040513          	addi	a0,s0,-320
    8020399e:	00002097          	auipc	ra,0x2
    802039a2:	f56080e7          	jalr	-170(ra) # 802058f4 <namei>
    802039a6:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    802039a8:	cd71                	beqz	a0,80203a84 <sys_link+0x124>
    ilock(ip);
    802039aa:	00001097          	auipc	ra,0x1
    802039ae:	6b6080e7          	jalr	1718(ra) # 80205060 <ilock>
    if (ip->type == T_DIR) {          /* hard links to dirs make cycles */
    802039b2:	0444d703          	lhu	a4,68(s1)
    802039b6:	4785                	li	a5,1
    802039b8:	06f70d63          	beq	a4,a5,80203a32 <sys_link+0xd2>
    802039bc:	f24a                	sd	s2,288(sp)
    ip->nlink++;
    802039be:	04a4d783          	lhu	a5,74(s1)
    802039c2:	2785                	addiw	a5,a5,1
    802039c4:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    802039c8:	8526                	mv	a0,s1
    802039ca:	00001097          	auipc	ra,0x1
    802039ce:	5ca080e7          	jalr	1482(ra) # 80204f94 <iupdate>
    iunlock(ip);
    802039d2:	8526                	mv	a0,s1
    802039d4:	00001097          	auipc	ra,0x1
    802039d8:	752080e7          	jalr	1874(ra) # 80205126 <iunlock>
    struct inode *dp = nameiparent(newp, name);
    802039dc:	fc040593          	addi	a1,s0,-64
    802039e0:	f4040513          	addi	a0,s0,-192
    802039e4:	00002097          	auipc	ra,0x2
    802039e8:	f2e080e7          	jalr	-210(ra) # 80205912 <nameiparent>
    802039ec:	892a                	mv	s2,a0
    if (dp == 0) goto bad;
    802039ee:	cd39                	beqz	a0,80203a4c <sys_link+0xec>
    ilock(dp);
    802039f0:	00001097          	auipc	ra,0x1
    802039f4:	670080e7          	jalr	1648(ra) # 80205060 <ilock>
    if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    802039f8:	00092703          	lw	a4,0(s2)
    802039fc:	409c                	lw	a5,0(s1)
    802039fe:	04f71263          	bne	a4,a5,80203a42 <sys_link+0xe2>
    80203a02:	40d0                	lw	a2,4(s1)
    80203a04:	fc040593          	addi	a1,s0,-64
    80203a08:	854a                	mv	a0,s2
    80203a0a:	00002097          	auipc	ra,0x2
    80203a0e:	e30080e7          	jalr	-464(ra) # 8020583a <dirlink>
    80203a12:	02054863          	bltz	a0,80203a42 <sys_link+0xe2>
    iunlockput(dp);
    80203a16:	854a                	mv	a0,s2
    80203a18:	00002097          	auipc	ra,0x2
    80203a1c:	924080e7          	jalr	-1756(ra) # 8020533c <iunlockput>
    iput(ip);
    80203a20:	8526                	mv	a0,s1
    80203a22:	00001097          	auipc	ra,0x1
    80203a26:	7fc080e7          	jalr	2044(ra) # 8020521e <iput>
    return 0;
    80203a2a:	4781                	li	a5,0
    80203a2c:	74b2                	ld	s1,296(sp)
    80203a2e:	7912                	ld	s2,288(sp)
    80203a30:	a0a9                	j	80203a7a <sys_link+0x11a>
        iunlockput(ip);
    80203a32:	8526                	mv	a0,s1
    80203a34:	00002097          	auipc	ra,0x2
    80203a38:	908080e7          	jalr	-1784(ra) # 8020533c <iunlockput>
        return -1;
    80203a3c:	57fd                	li	a5,-1
    80203a3e:	74b2                	ld	s1,296(sp)
    80203a40:	a82d                	j	80203a7a <sys_link+0x11a>
        iunlockput(dp);
    80203a42:	854a                	mv	a0,s2
    80203a44:	00002097          	auipc	ra,0x2
    80203a48:	8f8080e7          	jalr	-1800(ra) # 8020533c <iunlockput>
    ilock(ip);
    80203a4c:	8526                	mv	a0,s1
    80203a4e:	00001097          	auipc	ra,0x1
    80203a52:	612080e7          	jalr	1554(ra) # 80205060 <ilock>
    ip->nlink--;
    80203a56:	04a4d783          	lhu	a5,74(s1)
    80203a5a:	37fd                	addiw	a5,a5,-1
    80203a5c:	04f49523          	sh	a5,74(s1)
    iupdate(ip);
    80203a60:	8526                	mv	a0,s1
    80203a62:	00001097          	auipc	ra,0x1
    80203a66:	532080e7          	jalr	1330(ra) # 80204f94 <iupdate>
    iunlockput(ip);
    80203a6a:	8526                	mv	a0,s1
    80203a6c:	00002097          	auipc	ra,0x2
    80203a70:	8d0080e7          	jalr	-1840(ra) # 8020533c <iunlockput>
    return -1;
    80203a74:	57fd                	li	a5,-1
    80203a76:	74b2                	ld	s1,296(sp)
    80203a78:	7912                	ld	s2,288(sp)
}
    80203a7a:	853e                	mv	a0,a5
    80203a7c:	70f2                	ld	ra,312(sp)
    80203a7e:	7452                	ld	s0,304(sp)
    80203a80:	6131                	addi	sp,sp,320
    80203a82:	8082                	ret
    if (ip == 0) return -1;
    80203a84:	57fd                	li	a5,-1
    80203a86:	74b2                	ld	s1,296(sp)
    80203a88:	bfcd                	j	80203a7a <sys_link+0x11a>

0000000080203a8a <sys_unlink>:
{
    80203a8a:	712d                	addi	sp,sp,-288
    80203a8c:	ee06                	sd	ra,280(sp)
    80203a8e:	ea22                	sd	s0,272(sp)
    80203a90:	1200                	addi	s0,sp,288
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203a92:	08000613          	li	a2,128
    80203a96:	f3040593          	addi	a1,s0,-208
    80203a9a:	4501                	li	a0,0
    80203a9c:	00000097          	auipc	ra,0x0
    80203aa0:	a4a080e7          	jalr	-1462(ra) # 802034e6 <argstr>
    80203aa4:	18054d63          	bltz	a0,80203c3e <sys_unlink+0x1b4>
    80203aa8:	e626                	sd	s1,264(sp)
    struct inode *dp = nameiparent(path, name);
    80203aaa:	fb040593          	addi	a1,s0,-80
    80203aae:	f3040513          	addi	a0,s0,-208
    80203ab2:	00002097          	auipc	ra,0x2
    80203ab6:	e60080e7          	jalr	-416(ra) # 80205912 <nameiparent>
    80203aba:	84aa                	mv	s1,a0
    if (dp == 0) return -1;
    80203abc:	18050363          	beqz	a0,80203c42 <sys_unlink+0x1b8>
    ilock(dp);
    80203ac0:	00001097          	auipc	ra,0x1
    80203ac4:	5a0080e7          	jalr	1440(ra) # 80205060 <ilock>
    if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0) goto bad;
    80203ac8:	00004597          	auipc	a1,0x4
    80203acc:	e4858593          	addi	a1,a1,-440 # 80207910 <etext+0x910>
    80203ad0:	fb040513          	addi	a0,s0,-80
    80203ad4:	00002097          	auipc	ra,0x2
    80203ad8:	b3c080e7          	jalr	-1220(ra) # 80205610 <namecmp>
    80203adc:	14050663          	beqz	a0,80203c28 <sys_unlink+0x19e>
    80203ae0:	00004597          	auipc	a1,0x4
    80203ae4:	e3858593          	addi	a1,a1,-456 # 80207918 <etext+0x918>
    80203ae8:	fb040513          	addi	a0,s0,-80
    80203aec:	00002097          	auipc	ra,0x2
    80203af0:	b24080e7          	jalr	-1244(ra) # 80205610 <namecmp>
    80203af4:	12050a63          	beqz	a0,80203c28 <sys_unlink+0x19e>
    80203af8:	e24a                	sd	s2,256(sp)
    struct inode *ip = dirlookup(dp, name, &off);
    80203afa:	f2c40613          	addi	a2,s0,-212
    80203afe:	fb040593          	addi	a1,s0,-80
    80203b02:	8526                	mv	a0,s1
    80203b04:	00002097          	auipc	ra,0x2
    80203b08:	b26080e7          	jalr	-1242(ra) # 8020562a <dirlookup>
    80203b0c:	892a                	mv	s2,a0
    if (ip == 0) goto bad;
    80203b0e:	10050c63          	beqz	a0,80203c26 <sys_unlink+0x19c>
    ilock(ip);                        /* lock order: parent, then child */
    80203b12:	00001097          	auipc	ra,0x1
    80203b16:	54e080e7          	jalr	1358(ra) # 80205060 <ilock>
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203b1a:	04a95783          	lhu	a5,74(s2)
    80203b1e:	cfa5                	beqz	a5,80203b96 <sys_unlink+0x10c>
    if (ip->type == T_DIR && !isdirempty(ip)) {
    80203b20:	04495703          	lhu	a4,68(s2)
    80203b24:	4785                	li	a5,1
    80203b26:	08f70163          	beq	a4,a5,80203ba8 <sys_unlink+0x11e>
    memset(&de, 0, sizeof(de));
    80203b2a:	02000613          	li	a2,32
    80203b2e:	4581                	li	a1,0
    80203b30:	f0840513          	addi	a0,s0,-248
    80203b34:	ffffd097          	auipc	ra,0xffffd
    80203b38:	b70080e7          	jalr	-1168(ra) # 802006a4 <memset>
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203b3c:	02000713          	li	a4,32
    80203b40:	f2c42683          	lw	a3,-212(s0)
    80203b44:	f0840613          	addi	a2,s0,-248
    80203b48:	4581                	li	a1,0
    80203b4a:	8526                	mv	a0,s1
    80203b4c:	00002097          	auipc	ra,0x2
    80203b50:	976080e7          	jalr	-1674(ra) # 802054c2 <writei>
    80203b54:	02000793          	li	a5,32
    80203b58:	0af51363          	bne	a0,a5,80203bfe <sys_unlink+0x174>
    if (ip->type == T_DIR) {
    80203b5c:	04495703          	lhu	a4,68(s2)
    80203b60:	4785                	li	a5,1
    80203b62:	0af70763          	beq	a4,a5,80203c10 <sys_unlink+0x186>
    iunlockput(dp);
    80203b66:	8526                	mv	a0,s1
    80203b68:	00001097          	auipc	ra,0x1
    80203b6c:	7d4080e7          	jalr	2004(ra) # 8020533c <iunlockput>
    ip->nlink--;
    80203b70:	04a95783          	lhu	a5,74(s2)
    80203b74:	37fd                	addiw	a5,a5,-1
    80203b76:	04f91523          	sh	a5,74(s2)
    iupdate(ip);
    80203b7a:	854a                	mv	a0,s2
    80203b7c:	00001097          	auipc	ra,0x1
    80203b80:	418080e7          	jalr	1048(ra) # 80204f94 <iupdate>
    iunlockput(ip);                   /* data freed in iput if last ref+link */
    80203b84:	854a                	mv	a0,s2
    80203b86:	00001097          	auipc	ra,0x1
    80203b8a:	7b6080e7          	jalr	1974(ra) # 8020533c <iunlockput>
    return 0;
    80203b8e:	4501                	li	a0,0
    80203b90:	64b2                	ld	s1,264(sp)
    80203b92:	6912                	ld	s2,256(sp)
    80203b94:	a04d                	j	80203c36 <sys_unlink+0x1ac>
    80203b96:	fdce                	sd	s3,248(sp)
    if (ip->nlink < 1) panic("unlink: nlink < 1");
    80203b98:	00004517          	auipc	a0,0x4
    80203b9c:	d8850513          	addi	a0,a0,-632 # 80207920 <etext+0x920>
    80203ba0:	ffffd097          	auipc	ra,0xffffd
    80203ba4:	a5e080e7          	jalr	-1442(ra) # 802005fe <panic>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203ba8:	04c92703          	lw	a4,76(s2)
    80203bac:	04000793          	li	a5,64
    80203bb0:	f6e7fde3          	bgeu	a5,a4,80203b2a <sys_unlink+0xa0>
    80203bb4:	fdce                	sd	s3,248(sp)
    80203bb6:	04000993          	li	s3,64
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80203bba:	02000713          	li	a4,32
    80203bbe:	86ce                	mv	a3,s3
    80203bc0:	ee840613          	addi	a2,s0,-280
    80203bc4:	4581                	li	a1,0
    80203bc6:	854a                	mv	a0,s2
    80203bc8:	00001097          	auipc	ra,0x1
    80203bcc:	7c6080e7          	jalr	1990(ra) # 8020538e <readi>
    80203bd0:	02000793          	li	a5,32
    80203bd4:	00f51d63          	bne	a0,a5,80203bee <sys_unlink+0x164>
        if (de.inum != 0) return 0;
    80203bd8:	ee842783          	lw	a5,-280(s0)
    80203bdc:	e7b5                	bnez	a5,80203c48 <sys_unlink+0x1be>
    for (uint32 off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80203bde:	0209899b          	addiw	s3,s3,32
    80203be2:	04c92783          	lw	a5,76(s2)
    80203be6:	fcf9eae3          	bltu	s3,a5,80203bba <sys_unlink+0x130>
    80203bea:	79ee                	ld	s3,248(sp)
    80203bec:	bf3d                	j	80203b2a <sys_unlink+0xa0>
            panic("isdirempty: short read");
    80203bee:	00004517          	auipc	a0,0x4
    80203bf2:	d4a50513          	addi	a0,a0,-694 # 80207938 <etext+0x938>
    80203bf6:	ffffd097          	auipc	ra,0xffffd
    80203bfa:	a08080e7          	jalr	-1528(ra) # 802005fe <panic>
    80203bfe:	fdce                	sd	s3,248(sp)
        panic("unlink: writei");
    80203c00:	00004517          	auipc	a0,0x4
    80203c04:	d5050513          	addi	a0,a0,-688 # 80207950 <etext+0x950>
    80203c08:	ffffd097          	auipc	ra,0xffffd
    80203c0c:	9f6080e7          	jalr	-1546(ra) # 802005fe <panic>
        dp->nlink--;                  /* the child's ".." no longer counts */
    80203c10:	04a4d783          	lhu	a5,74(s1)
    80203c14:	37fd                	addiw	a5,a5,-1
    80203c16:	04f49523          	sh	a5,74(s1)
        iupdate(dp);
    80203c1a:	8526                	mv	a0,s1
    80203c1c:	00001097          	auipc	ra,0x1
    80203c20:	378080e7          	jalr	888(ra) # 80204f94 <iupdate>
    80203c24:	b789                	j	80203b66 <sys_unlink+0xdc>
    80203c26:	6912                	ld	s2,256(sp)
    iunlockput(dp);
    80203c28:	8526                	mv	a0,s1
    80203c2a:	00001097          	auipc	ra,0x1
    80203c2e:	712080e7          	jalr	1810(ra) # 8020533c <iunlockput>
    return -1;
    80203c32:	557d                	li	a0,-1
    80203c34:	64b2                	ld	s1,264(sp)
}
    80203c36:	60f2                	ld	ra,280(sp)
    80203c38:	6452                	ld	s0,272(sp)
    80203c3a:	6115                	addi	sp,sp,288
    80203c3c:	8082                	ret
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203c3e:	557d                	li	a0,-1
    80203c40:	bfdd                	j	80203c36 <sys_unlink+0x1ac>
    if (dp == 0) return -1;
    80203c42:	557d                	li	a0,-1
    80203c44:	64b2                	ld	s1,264(sp)
    80203c46:	bfc5                	j	80203c36 <sys_unlink+0x1ac>
        iunlockput(ip);
    80203c48:	854a                	mv	a0,s2
    80203c4a:	00001097          	auipc	ra,0x1
    80203c4e:	6f2080e7          	jalr	1778(ra) # 8020533c <iunlockput>
        goto bad;
    80203c52:	6912                	ld	s2,256(sp)
    80203c54:	79ee                	ld	s3,248(sp)
    80203c56:	bfc9                	j	80203c28 <sys_unlink+0x19e>

0000000080203c58 <sys_open>:

uint64 sys_open(void)
{
    80203c58:	7131                	addi	sp,sp,-192
    80203c5a:	fd06                	sd	ra,184(sp)
    80203c5c:	f922                	sd	s0,176(sp)
    80203c5e:	0180                	addi	s0,sp,192
    char path[MAXPATH];
    int omode;
    argint(1, &omode);
    80203c60:	f4c40593          	addi	a1,s0,-180
    80203c64:	4505                	li	a0,1
    80203c66:	fffff097          	auipc	ra,0xfffff
    80203c6a:	636080e7          	jalr	1590(ra) # 8020329c <argint>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203c6e:	08000613          	li	a2,128
    80203c72:	f5040593          	addi	a1,s0,-176
    80203c76:	4501                	li	a0,0
    80203c78:	00000097          	auipc	ra,0x0
    80203c7c:	86e080e7          	jalr	-1938(ra) # 802034e6 <argstr>
    80203c80:	12054b63          	bltz	a0,80203db6 <sys_open+0x15e>
    80203c84:	f526                	sd	s1,168(sp)

    struct inode *ip;
    if (omode & O_CREATE) {
    80203c86:	f4c42783          	lw	a5,-180(s0)
    80203c8a:	2007f793          	andi	a5,a5,512
    80203c8e:	c7c5                	beqz	a5,80203d36 <sys_open+0xde>
        ip = create(path, T_FILE, 0, 0);
    80203c90:	4681                	li	a3,0
    80203c92:	4601                	li	a2,0
    80203c94:	4589                	li	a1,2
    80203c96:	f5040513          	addi	a0,s0,-176
    80203c9a:	00000097          	auipc	ra,0x0
    80203c9e:	990080e7          	jalr	-1648(ra) # 8020362a <create>
    80203ca2:	84aa                	mv	s1,a0
        if (ip == 0) return -1;
    80203ca4:	10050b63          	beqz	a0,80203dba <sys_open+0x162>
        if (ip->type == T_DIR && omode != O_RDONLY) {
            iunlockput(ip);
            return -1;
        }
    }
    if (ip->type == T_DEV && (ip->major < 0 || ip->major >= NDEV)) {
    80203ca8:	0444d703          	lhu	a4,68(s1)
    80203cac:	478d                	li	a5,3
    80203cae:	00f71763          	bne	a4,a5,80203cbc <sys_open+0x64>
    80203cb2:	0464d703          	lhu	a4,70(s1)
    80203cb6:	47a5                	li	a5,9
    80203cb8:	0ae7eb63          	bltu	a5,a4,80203d6e <sys_open+0x116>
    80203cbc:	f14a                	sd	s2,160(sp)
        iunlockput(ip);
        return -1;
    }

    struct file *f = filealloc();
    80203cbe:	00002097          	auipc	ra,0x2
    80203cc2:	c98080e7          	jalr	-872(ra) # 80205956 <filealloc>
    80203cc6:	892a                	mv	s2,a0
    int fd;
    if (f == 0 || (fd = fdalloc(f)) < 0) {
    80203cc8:	c169                	beqz	a0,80203d8a <sys_open+0x132>
    80203cca:	ed4e                	sd	s3,152(sp)
    80203ccc:	00000097          	auipc	ra,0x0
    80203cd0:	91c080e7          	jalr	-1764(ra) # 802035e8 <fdalloc>
    80203cd4:	89aa                	mv	s3,a0
    80203cd6:	0a054463          	bltz	a0,80203d7e <sys_open+0x126>
        if (f) fileclose(f);
        iunlockput(ip);
        return -1;
    }

    if (ip->type == T_DEV) {
    80203cda:	0444d703          	lhu	a4,68(s1)
    80203cde:	478d                	li	a5,3
    80203ce0:	0af70e63          	beq	a4,a5,80203d9c <sys_open+0x144>
        f->type  = FD_DEVICE;
        f->major = ip->major;
    } else {
        f->type = FD_INODE;
    80203ce4:	4789                	li	a5,2
    80203ce6:	00f92023          	sw	a5,0(s2)
        f->off  = 0;
    80203cea:	02092023          	sw	zero,32(s2)
    }
    f->ip       = ip;
    80203cee:	00993c23          	sd	s1,24(s2)
    f->readable = !(omode & O_WRONLY);
    80203cf2:	f4c42783          	lw	a5,-180(s0)
    80203cf6:	0017c713          	xori	a4,a5,1
    80203cfa:	8b05                	andi	a4,a4,1
    80203cfc:	00e90423          	sb	a4,8(s2)
    f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80203d00:	0037f713          	andi	a4,a5,3
    80203d04:	00e03733          	snez	a4,a4
    80203d08:	00e904a3          	sb	a4,9(s2)

    if ((omode & O_TRUNC) && ip->type == T_FILE)
    80203d0c:	4007f793          	andi	a5,a5,1024
    80203d10:	c791                	beqz	a5,80203d1c <sys_open+0xc4>
    80203d12:	0444d703          	lhu	a4,68(s1)
    80203d16:	4789                	li	a5,2
    80203d18:	08f70963          	beq	a4,a5,80203daa <sys_open+0x152>
        itrunc(ip);

    iunlock(ip);
    80203d1c:	8526                	mv	a0,s1
    80203d1e:	00001097          	auipc	ra,0x1
    80203d22:	408080e7          	jalr	1032(ra) # 80205126 <iunlock>
    return fd;
    80203d26:	854e                	mv	a0,s3
    80203d28:	74aa                	ld	s1,168(sp)
    80203d2a:	790a                	ld	s2,160(sp)
    80203d2c:	69ea                	ld	s3,152(sp)
}
    80203d2e:	70ea                	ld	ra,184(sp)
    80203d30:	744a                	ld	s0,176(sp)
    80203d32:	6129                	addi	sp,sp,192
    80203d34:	8082                	ret
        if ((ip = namei(path)) == 0) return -1;
    80203d36:	f5040513          	addi	a0,s0,-176
    80203d3a:	00002097          	auipc	ra,0x2
    80203d3e:	bba080e7          	jalr	-1094(ra) # 802058f4 <namei>
    80203d42:	84aa                	mv	s1,a0
    80203d44:	cd35                	beqz	a0,80203dc0 <sys_open+0x168>
        ilock(ip);
    80203d46:	00001097          	auipc	ra,0x1
    80203d4a:	31a080e7          	jalr	794(ra) # 80205060 <ilock>
        if (ip->type == T_DIR && omode != O_RDONLY) {
    80203d4e:	0444d703          	lhu	a4,68(s1)
    80203d52:	4785                	li	a5,1
    80203d54:	f4f71ae3          	bne	a4,a5,80203ca8 <sys_open+0x50>
    80203d58:	f4c42783          	lw	a5,-180(s0)
    80203d5c:	d3a5                	beqz	a5,80203cbc <sys_open+0x64>
            iunlockput(ip);
    80203d5e:	8526                	mv	a0,s1
    80203d60:	00001097          	auipc	ra,0x1
    80203d64:	5dc080e7          	jalr	1500(ra) # 8020533c <iunlockput>
            return -1;
    80203d68:	557d                	li	a0,-1
    80203d6a:	74aa                	ld	s1,168(sp)
    80203d6c:	b7c9                	j	80203d2e <sys_open+0xd6>
        iunlockput(ip);
    80203d6e:	8526                	mv	a0,s1
    80203d70:	00001097          	auipc	ra,0x1
    80203d74:	5cc080e7          	jalr	1484(ra) # 8020533c <iunlockput>
        return -1;
    80203d78:	557d                	li	a0,-1
    80203d7a:	74aa                	ld	s1,168(sp)
    80203d7c:	bf4d                	j	80203d2e <sys_open+0xd6>
        if (f) fileclose(f);
    80203d7e:	854a                	mv	a0,s2
    80203d80:	00002097          	auipc	ra,0x2
    80203d84:	c92080e7          	jalr	-878(ra) # 80205a12 <fileclose>
    80203d88:	69ea                	ld	s3,152(sp)
        iunlockput(ip);
    80203d8a:	8526                	mv	a0,s1
    80203d8c:	00001097          	auipc	ra,0x1
    80203d90:	5b0080e7          	jalr	1456(ra) # 8020533c <iunlockput>
        return -1;
    80203d94:	557d                	li	a0,-1
    80203d96:	74aa                	ld	s1,168(sp)
    80203d98:	790a                	ld	s2,160(sp)
    80203d9a:	bf51                	j	80203d2e <sys_open+0xd6>
        f->type  = FD_DEVICE;
    80203d9c:	00f92023          	sw	a5,0(s2)
        f->major = ip->major;
    80203da0:	0464d783          	lhu	a5,70(s1)
    80203da4:	02f91223          	sh	a5,36(s2)
    80203da8:	b799                	j	80203cee <sys_open+0x96>
        itrunc(ip);
    80203daa:	8526                	mv	a0,s1
    80203dac:	00001097          	auipc	ra,0x1
    80203db0:	3c6080e7          	jalr	966(ra) # 80205172 <itrunc>
    80203db4:	b7a5                	j	80203d1c <sys_open+0xc4>
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203db6:	557d                	li	a0,-1
    80203db8:	bf9d                	j	80203d2e <sys_open+0xd6>
        if (ip == 0) return -1;
    80203dba:	557d                	li	a0,-1
    80203dbc:	74aa                	ld	s1,168(sp)
    80203dbe:	bf85                	j	80203d2e <sys_open+0xd6>
        if ((ip = namei(path)) == 0) return -1;
    80203dc0:	557d                	li	a0,-1
    80203dc2:	74aa                	ld	s1,168(sp)
    80203dc4:	b7ad                	j	80203d2e <sys_open+0xd6>

0000000080203dc6 <sys_mkdir>:

uint64 sys_mkdir(void)
{
    80203dc6:	7175                	addi	sp,sp,-144
    80203dc8:	e506                	sd	ra,136(sp)
    80203dca:	e122                	sd	s0,128(sp)
    80203dcc:	0900                	addi	s0,sp,144
    char path[MAXPATH];
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203dce:	08000613          	li	a2,128
    80203dd2:	f7040593          	addi	a1,s0,-144
    80203dd6:	4501                	li	a0,0
    80203dd8:	fffff097          	auipc	ra,0xfffff
    80203ddc:	70e080e7          	jalr	1806(ra) # 802034e6 <argstr>
    80203de0:	57fd                	li	a5,-1
    80203de2:	02054163          	bltz	a0,80203e04 <sys_mkdir+0x3e>
    struct inode *ip = create(path, T_DIR, 0, 0);
    80203de6:	4681                	li	a3,0
    80203de8:	4601                	li	a2,0
    80203dea:	4585                	li	a1,1
    80203dec:	f7040513          	addi	a0,s0,-144
    80203df0:	00000097          	auipc	ra,0x0
    80203df4:	83a080e7          	jalr	-1990(ra) # 8020362a <create>
    if (ip == 0) return -1;
    80203df8:	c919                	beqz	a0,80203e0e <sys_mkdir+0x48>
    iunlockput(ip);
    80203dfa:	00001097          	auipc	ra,0x1
    80203dfe:	542080e7          	jalr	1346(ra) # 8020533c <iunlockput>
    return 0;
    80203e02:	4781                	li	a5,0
}
    80203e04:	853e                	mv	a0,a5
    80203e06:	60aa                	ld	ra,136(sp)
    80203e08:	640a                	ld	s0,128(sp)
    80203e0a:	6149                	addi	sp,sp,144
    80203e0c:	8082                	ret
    if (ip == 0) return -1;
    80203e0e:	57fd                	li	a5,-1
    80203e10:	bfd5                	j	80203e04 <sys_mkdir+0x3e>

0000000080203e12 <sys_chdir>:

uint64 sys_chdir(void)
{
    80203e12:	7135                	addi	sp,sp,-160
    80203e14:	ed06                	sd	ra,152(sp)
    80203e16:	e922                	sd	s0,144(sp)
    80203e18:	e14a                	sd	s2,128(sp)
    80203e1a:	1100                	addi	s0,sp,160
    char path[MAXPATH];
    struct proc *p = myproc();
    80203e1c:	ffffe097          	auipc	ra,0xffffe
    80203e20:	902080e7          	jalr	-1790(ra) # 8020171e <myproc>
    80203e24:	892a                	mv	s2,a0
    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203e26:	08000613          	li	a2,128
    80203e2a:	f6040593          	addi	a1,s0,-160
    80203e2e:	4501                	li	a0,0
    80203e30:	fffff097          	auipc	ra,0xfffff
    80203e34:	6b6080e7          	jalr	1718(ra) # 802034e6 <argstr>
    80203e38:	57fd                	li	a5,-1
    80203e3a:	04054363          	bltz	a0,80203e80 <sys_chdir+0x6e>
    80203e3e:	e526                	sd	s1,136(sp)
    struct inode *ip = namei(path);
    80203e40:	f6040513          	addi	a0,s0,-160
    80203e44:	00002097          	auipc	ra,0x2
    80203e48:	ab0080e7          	jalr	-1360(ra) # 802058f4 <namei>
    80203e4c:	84aa                	mv	s1,a0
    if (ip == 0) return -1;
    80203e4e:	c539                	beqz	a0,80203e9c <sys_chdir+0x8a>
    ilock(ip);
    80203e50:	00001097          	auipc	ra,0x1
    80203e54:	210080e7          	jalr	528(ra) # 80205060 <ilock>
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203e58:	0444d703          	lhu	a4,68(s1)
    80203e5c:	4785                	li	a5,1
    80203e5e:	02f71763          	bne	a4,a5,80203e8c <sys_chdir+0x7a>
    iunlock(ip);
    80203e62:	8526                	mv	a0,s1
    80203e64:	00001097          	auipc	ra,0x1
    80203e68:	2c2080e7          	jalr	706(ra) # 80205126 <iunlock>
    iput(p->cwd);
    80203e6c:	15093503          	ld	a0,336(s2)
    80203e70:	00001097          	auipc	ra,0x1
    80203e74:	3ae080e7          	jalr	942(ra) # 8020521e <iput>
    p->cwd = ip;
    80203e78:	14993823          	sd	s1,336(s2)
    return 0;
    80203e7c:	4781                	li	a5,0
    80203e7e:	64aa                	ld	s1,136(sp)
}
    80203e80:	853e                	mv	a0,a5
    80203e82:	60ea                	ld	ra,152(sp)
    80203e84:	644a                	ld	s0,144(sp)
    80203e86:	690a                	ld	s2,128(sp)
    80203e88:	610d                	addi	sp,sp,160
    80203e8a:	8082                	ret
    if (ip->type != T_DIR) { iunlockput(ip); return -1; }
    80203e8c:	8526                	mv	a0,s1
    80203e8e:	00001097          	auipc	ra,0x1
    80203e92:	4ae080e7          	jalr	1198(ra) # 8020533c <iunlockput>
    80203e96:	57fd                	li	a5,-1
    80203e98:	64aa                	ld	s1,136(sp)
    80203e9a:	b7dd                	j	80203e80 <sys_chdir+0x6e>
    if (ip == 0) return -1;
    80203e9c:	57fd                	li	a5,-1
    80203e9e:	64aa                	ld	s1,136(sp)
    80203ea0:	b7c5                	j	80203e80 <sys_chdir+0x6e>

0000000080203ea2 <sys_pipe>:

uint64 sys_pipe(void)
{
    80203ea2:	7139                	addi	sp,sp,-64
    80203ea4:	fc06                	sd	ra,56(sp)
    80203ea6:	f822                	sd	s0,48(sp)
    80203ea8:	0080                	addi	s0,sp,64
    uint64 fdarray;                   /* user pointer to int[2] */
    argaddr(0, &fdarray);
    80203eaa:	fd840593          	addi	a1,s0,-40
    80203eae:	4501                	li	a0,0
    80203eb0:	fffff097          	auipc	ra,0xfffff
    80203eb4:	546080e7          	jalr	1350(ra) # 802033f6 <argaddr>

    struct file *rf, *wf;
    if (pipealloc(&rf, &wf) < 0) return -1;
    80203eb8:	fc840593          	addi	a1,s0,-56
    80203ebc:	fd040513          	addi	a0,s0,-48
    80203ec0:	00002097          	auipc	ra,0x2
    80203ec4:	e42080e7          	jalr	-446(ra) # 80205d02 <pipealloc>
    80203ec8:	57fd                	li	a5,-1
    80203eca:	0a054463          	bltz	a0,80203f72 <sys_pipe+0xd0>
    80203ece:	f426                	sd	s1,40(sp)

    struct proc *p = myproc();
    80203ed0:	ffffe097          	auipc	ra,0xffffe
    80203ed4:	84e080e7          	jalr	-1970(ra) # 8020171e <myproc>
    80203ed8:	84aa                	mv	s1,a0
    int fd0 = -1, fd1 = -1;
    80203eda:	57fd                	li	a5,-1
    80203edc:	fcf42223          	sw	a5,-60(s0)
    80203ee0:	fcf42023          	sw	a5,-64(s0)
    if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80203ee4:	fd043503          	ld	a0,-48(s0)
    80203ee8:	fffff097          	auipc	ra,0xfffff
    80203eec:	700080e7          	jalr	1792(ra) # 802035e8 <fdalloc>
    80203ef0:	fca42223          	sw	a0,-60(s0)
    80203ef4:	06054163          	bltz	a0,80203f56 <sys_pipe+0xb4>
    80203ef8:	fc843503          	ld	a0,-56(s0)
    80203efc:	fffff097          	auipc	ra,0xfffff
    80203f00:	6ec080e7          	jalr	1772(ra) # 802035e8 <fdalloc>
    80203f04:	fca42023          	sw	a0,-64(s0)
    80203f08:	02054e63          	bltz	a0,80203f44 <sys_pipe+0xa2>
        if (fd0 >= 0) p->ofile[fd0] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80203f0c:	4691                	li	a3,4
    80203f0e:	fc440613          	addi	a2,s0,-60
    80203f12:	fd843583          	ld	a1,-40(s0)
    80203f16:	68a8                	ld	a0,80(s1)
    80203f18:	fffff097          	auipc	ra,0xfffff
    80203f1c:	036080e7          	jalr	54(ra) # 80202f4e <copyout>
    80203f20:	04054e63          	bltz	a0,80203f7c <sys_pipe+0xda>
        copyout(p->pagetable, fdarray + sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0) {
    80203f24:	4691                	li	a3,4
    80203f26:	fc040613          	addi	a2,s0,-64
    80203f2a:	fd843583          	ld	a1,-40(s0)
    80203f2e:	0591                	addi	a1,a1,4
    80203f30:	68a8                	ld	a0,80(s1)
    80203f32:	fffff097          	auipc	ra,0xfffff
    80203f36:	01c080e7          	jalr	28(ra) # 80202f4e <copyout>
        p->ofile[fd1] = 0;
        fileclose(rf);
        fileclose(wf);
        return -1;
    }
    return 0;
    80203f3a:	4781                	li	a5,0
    if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80203f3c:	04054063          	bltz	a0,80203f7c <sys_pipe+0xda>
    80203f40:	74a2                	ld	s1,40(sp)
    80203f42:	a805                	j	80203f72 <sys_pipe+0xd0>
        if (fd0 >= 0) p->ofile[fd0] = 0;
    80203f44:	fc442783          	lw	a5,-60(s0)
    80203f48:	0007c763          	bltz	a5,80203f56 <sys_pipe+0xb4>
    80203f4c:	07e9                	addi	a5,a5,26
    80203f4e:	078e                	slli	a5,a5,0x3
    80203f50:	97a6                	add	a5,a5,s1
    80203f52:	0007b023          	sd	zero,0(a5)
        fileclose(rf);
    80203f56:	fd043503          	ld	a0,-48(s0)
    80203f5a:	00002097          	auipc	ra,0x2
    80203f5e:	ab8080e7          	jalr	-1352(ra) # 80205a12 <fileclose>
        fileclose(wf);
    80203f62:	fc843503          	ld	a0,-56(s0)
    80203f66:	00002097          	auipc	ra,0x2
    80203f6a:	aac080e7          	jalr	-1364(ra) # 80205a12 <fileclose>
        return -1;
    80203f6e:	57fd                	li	a5,-1
    80203f70:	74a2                	ld	s1,40(sp)
}
    80203f72:	853e                	mv	a0,a5
    80203f74:	70e2                	ld	ra,56(sp)
    80203f76:	7442                	ld	s0,48(sp)
    80203f78:	6121                	addi	sp,sp,64
    80203f7a:	8082                	ret
        p->ofile[fd0] = 0;
    80203f7c:	fc442783          	lw	a5,-60(s0)
    80203f80:	07e9                	addi	a5,a5,26
    80203f82:	078e                	slli	a5,a5,0x3
    80203f84:	97a6                	add	a5,a5,s1
    80203f86:	0007b023          	sd	zero,0(a5)
        p->ofile[fd1] = 0;
    80203f8a:	fc042783          	lw	a5,-64(s0)
    80203f8e:	07e9                	addi	a5,a5,26
    80203f90:	078e                	slli	a5,a5,0x3
    80203f92:	94be                	add	s1,s1,a5
    80203f94:	0004b023          	sd	zero,0(s1)
        fileclose(rf);
    80203f98:	fd043503          	ld	a0,-48(s0)
    80203f9c:	00002097          	auipc	ra,0x2
    80203fa0:	a76080e7          	jalr	-1418(ra) # 80205a12 <fileclose>
        fileclose(wf);
    80203fa4:	fc843503          	ld	a0,-56(s0)
    80203fa8:	00002097          	auipc	ra,0x2
    80203fac:	a6a080e7          	jalr	-1430(ra) # 80205a12 <fileclose>
        return -1;
    80203fb0:	57fd                	li	a5,-1
    80203fb2:	74a2                	ld	s1,40(sp)
    80203fb4:	bf7d                	j	80203f72 <sys_pipe+0xd0>

0000000080203fb6 <sys_exec>:

uint64 sys_exec(void)
{
    80203fb6:	7129                	addi	sp,sp,-320
    80203fb8:	fe06                	sd	ra,312(sp)
    80203fba:	fa22                	sd	s0,304(sp)
    80203fbc:	0280                	addi	s0,sp,320
    char path[MAXPATH];
    uint64 uargv, uarg;
    char *argv[MAXARG];

    if (argstr(0, path, MAXPATH) < 0) return -1;
    80203fbe:	08000613          	li	a2,128
    80203fc2:	f5040593          	addi	a1,s0,-176
    80203fc6:	4501                	li	a0,0
    80203fc8:	fffff097          	auipc	ra,0xfffff
    80203fcc:	51e080e7          	jalr	1310(ra) # 802034e6 <argstr>
    80203fd0:	87aa                	mv	a5,a0
    80203fd2:	557d                	li	a0,-1
    80203fd4:	0a07c763          	bltz	a5,80204082 <sys_exec+0xcc>
    80203fd8:	f626                	sd	s1,296(sp)
    80203fda:	f24a                	sd	s2,288(sp)
    80203fdc:	ee4e                	sd	s3,280(sp)
    80203fde:	ea52                	sd	s4,272(sp)
    argaddr(1, &uargv);
    80203fe0:	f4840593          	addi	a1,s0,-184
    80203fe4:	4505                	li	a0,1
    80203fe6:	fffff097          	auipc	ra,0xfffff
    80203fea:	410080e7          	jalr	1040(ra) # 802033f6 <argaddr>
    memset(argv, 0, sizeof(argv));
    80203fee:	08000613          	li	a2,128
    80203ff2:	4581                	li	a1,0
    80203ff4:	ec040513          	addi	a0,s0,-320
    80203ff8:	ffffc097          	auipc	ra,0xffffc
    80203ffc:	6ac080e7          	jalr	1708(ra) # 802006a4 <memset>

    int ret = -1;
    for (int i = 0; ; i++) {
        if (i >= MAXARG) goto out;
    80204000:	ec040493          	addi	s1,s0,-320
    memset(argv, 0, sizeof(argv));
    80204004:	89a6                	mv	s3,s1
    80204006:	4901                	li	s2,0
        if (i >= MAXARG) goto out;
    80204008:	4a41                	li	s4,16
        if (copyin(myproc()->pagetable, (char *)&uarg,
    8020400a:	ffffd097          	auipc	ra,0xffffd
    8020400e:	714080e7          	jalr	1812(ra) # 8020171e <myproc>
    80204012:	00391613          	slli	a2,s2,0x3
    80204016:	46a1                	li	a3,8
    80204018:	f4843783          	ld	a5,-184(s0)
    8020401c:	963e                	add	a2,a2,a5
    8020401e:	f4040593          	addi	a1,s0,-192
    80204022:	6928                	ld	a0,80(a0)
    80204024:	fffff097          	auipc	ra,0xfffff
    80204028:	01e080e7          	jalr	30(ra) # 80203042 <copyin>
    8020402c:	08054163          	bltz	a0,802040ae <sys_exec+0xf8>
                   uargv + sizeof(uint64) * i, sizeof(uint64)) < 0) goto out;
        if (uarg == 0) { argv[i] = 0; break; }
    80204030:	f4043783          	ld	a5,-192(s0)
    80204034:	cbb9                	beqz	a5,8020408a <sys_exec+0xd4>
        argv[i] = palloc();
    80204036:	ffffd097          	auipc	ra,0xffffd
    8020403a:	070080e7          	jalr	112(ra) # 802010a6 <palloc>
    8020403e:	85aa                	mv	a1,a0
    80204040:	00a9b023          	sd	a0,0(s3)
        if (!argv[i]) goto out;
    80204044:	c53d                	beqz	a0,802040b2 <sys_exec+0xfc>
        if (fetchstr(uarg, argv[i], PGSIZE) < 0) goto out;
    80204046:	6605                	lui	a2,0x1
    80204048:	f4043503          	ld	a0,-192(s0)
    8020404c:	fffff097          	auipc	ra,0xfffff
    80204050:	44e080e7          	jalr	1102(ra) # 8020349a <fetchstr>
    80204054:	06054163          	bltz	a0,802040b6 <sys_exec+0x100>
        if (i >= MAXARG) goto out;
    80204058:	0905                	addi	s2,s2,1
    8020405a:	09a1                	addi	s3,s3,8
    8020405c:	fb4917e3          	bne	s2,s4,8020400a <sys_exec+0x54>
    int ret = -1;
    80204060:	59fd                	li	s3,-1
    }
    ret = exec(path, argv);
out:
    /* Free EVERY page we allocated, on every path - the original version of
     * this function leaked argv pages on a bad pointer. Found in the audit. */
    for (int i = 0; i < MAXARG && argv[i]; i++) pfree(argv[i]);
    80204062:	f4040913          	addi	s2,s0,-192
    80204066:	6088                	ld	a0,0(s1)
    80204068:	c901                	beqz	a0,80204078 <sys_exec+0xc2>
    8020406a:	ffffd097          	auipc	ra,0xffffd
    8020406e:	14c080e7          	jalr	332(ra) # 802011b6 <pfree>
    80204072:	04a1                	addi	s1,s1,8
    80204074:	ff2499e3          	bne	s1,s2,80204066 <sys_exec+0xb0>
    return ret;
    80204078:	854e                	mv	a0,s3
    8020407a:	74b2                	ld	s1,296(sp)
    8020407c:	7912                	ld	s2,288(sp)
    8020407e:	69f2                	ld	s3,280(sp)
    80204080:	6a52                	ld	s4,272(sp)
}
    80204082:	70f2                	ld	ra,312(sp)
    80204084:	7452                	ld	s0,304(sp)
    80204086:	6131                	addi	sp,sp,320
    80204088:	8082                	ret
        if (uarg == 0) { argv[i] = 0; break; }
    8020408a:	0009079b          	sext.w	a5,s2
    8020408e:	078e                	slli	a5,a5,0x3
    80204090:	fd078793          	addi	a5,a5,-48
    80204094:	97a2                	add	a5,a5,s0
    80204096:	ee07b823          	sd	zero,-272(a5)
    ret = exec(path, argv);
    8020409a:	ec040593          	addi	a1,s0,-320
    8020409e:	f5040513          	addi	a0,s0,-176
    802040a2:	00000097          	auipc	ra,0x0
    802040a6:	314080e7          	jalr	788(ra) # 802043b6 <exec>
    802040aa:	89aa                	mv	s3,a0
    802040ac:	bf5d                	j	80204062 <sys_exec+0xac>
    int ret = -1;
    802040ae:	59fd                	li	s3,-1
    802040b0:	bf4d                	j	80204062 <sys_exec+0xac>
    802040b2:	59fd                	li	s3,-1
    802040b4:	b77d                	j	80204062 <sys_exec+0xac>
    802040b6:	59fd                	li	s3,-1
    802040b8:	b76d                	j	80204062 <sys_exec+0xac>

00000000802040ba <consolewrite>:
    devsw[CONSOLE].read  = consoleread;
    devsw[CONSOLE].write = consolewrite;
}

int consolewrite(uint64 src, int n)
{
    802040ba:	7139                	addi	sp,sp,-64
    802040bc:	fc06                	sd	ra,56(sp)
    802040be:	f822                	sd	s0,48(sp)
    802040c0:	ec4e                	sd	s3,24(sp)
    802040c2:	0080                	addi	s0,sp,64
    802040c4:	89ae                	mv	s3,a1
    for (int i = 0; i < n; i++) {
    802040c6:	04b05563          	blez	a1,80204110 <consolewrite+0x56>
    802040ca:	f426                	sd	s1,40(sp)
    802040cc:	f04a                	sd	s2,32(sp)
    802040ce:	84aa                	mv	s1,a0
    802040d0:	00a58933          	add	s2,a1,a0
        char c;
        /* copyin, not a direct dereference - src is a USER pointer. */
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    802040d4:	ffffd097          	auipc	ra,0xffffd
    802040d8:	64a080e7          	jalr	1610(ra) # 8020171e <myproc>
    802040dc:	4685                	li	a3,1
    802040de:	8626                	mv	a2,s1
    802040e0:	fcf40593          	addi	a1,s0,-49
    802040e4:	6928                	ld	a0,80(a0)
    802040e6:	fffff097          	auipc	ra,0xfffff
    802040ea:	f5c080e7          	jalr	-164(ra) # 80203042 <copyin>
    802040ee:	00054e63          	bltz	a0,8020410a <consolewrite+0x50>
        hal_console_putc(c);
    802040f2:	fcf44503          	lbu	a0,-49(s0)
    802040f6:	00002097          	auipc	ra,0x2
    802040fa:	114080e7          	jalr	276(ra) # 8020620a <hal_console_putc>
    for (int i = 0; i < n; i++) {
    802040fe:	0485                	addi	s1,s1,1
    80204100:	fd249ae3          	bne	s1,s2,802040d4 <consolewrite+0x1a>
    80204104:	74a2                	ld	s1,40(sp)
    80204106:	7902                	ld	s2,32(sp)
    80204108:	a021                	j	80204110 <consolewrite+0x56>
        if (copyin(myproc()->pagetable, &c, src + i, 1) < 0) return -1;
    8020410a:	59fd                	li	s3,-1
    8020410c:	74a2                	ld	s1,40(sp)
    8020410e:	7902                	ld	s2,32(sp)
    }
    return n;
}
    80204110:	854e                	mv	a0,s3
    80204112:	70e2                	ld	ra,56(sp)
    80204114:	7442                	ld	s0,48(sp)
    80204116:	69e2                	ld	s3,24(sp)
    80204118:	6121                	addi	sp,sp,64
    8020411a:	8082                	ret

000000008020411c <consoleread>:

int consoleread(uint64 dst, int n)
{
    8020411c:	715d                	addi	sp,sp,-80
    8020411e:	e486                	sd	ra,72(sp)
    80204120:	e0a2                	sd	s0,64(sp)
    80204122:	fc26                	sd	s1,56(sp)
    80204124:	f84a                	sd	s2,48(sp)
    80204126:	f44e                	sd	s3,40(sp)
    80204128:	f052                	sd	s4,32(sp)
    8020412a:	ec56                	sd	s5,24(sp)
    8020412c:	0880                	addi	s0,sp,80
    8020412e:	8a2a                	mv	s4,a0
    80204130:	89ae                	mv	s3,a1
    int target = n;
    acquire(&cons.lock);
    80204132:	0012d517          	auipc	a0,0x12d
    80204136:	8e650513          	addi	a0,a0,-1818 # 80330a18 <cons>
    8020413a:	ffffd097          	auipc	ra,0xffffd
    8020413e:	1fa080e7          	jalr	506(ra) # 80201334 <acquire>
    while (n > 0) {
    80204142:	8ace                	mv	s5,s3
        while (cons.r == cons.w) {
    80204144:	0012d497          	auipc	s1,0x12d
    80204148:	8d448493          	addi	s1,s1,-1836 # 80330a18 <cons>
            if (myproc()->killed) { release(&cons.lock); return -1; }
            sleep(&cons.r, &cons.lock);
    8020414c:	0012d917          	auipc	s2,0x12d
    80204150:	96490913          	addi	s2,s2,-1692 # 80330ab0 <cons+0x98>
    while (n > 0) {
    80204154:	09305463          	blez	s3,802041dc <consoleread+0xc0>
        while (cons.r == cons.w) {
    80204158:	0984a783          	lw	a5,152(s1)
    8020415c:	09c4a703          	lw	a4,156(s1)
    80204160:	02f71463          	bne	a4,a5,80204188 <consoleread+0x6c>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    80204164:	ffffd097          	auipc	ra,0xffffd
    80204168:	5ba080e7          	jalr	1466(ra) # 8020171e <myproc>
    8020416c:	551c                	lw	a5,40(a0)
    8020416e:	e3d1                	bnez	a5,802041f2 <consoleread+0xd6>
            sleep(&cons.r, &cons.lock);
    80204170:	85a6                	mv	a1,s1
    80204172:	854a                	mv	a0,s2
    80204174:	ffffe097          	auipc	ra,0xffffe
    80204178:	c0e080e7          	jalr	-1010(ra) # 80201d82 <sleep>
        while (cons.r == cons.w) {
    8020417c:	0984a783          	lw	a5,152(s1)
    80204180:	09c4a703          	lw	a4,156(s1)
    80204184:	fef700e3          	beq	a4,a5,80204164 <consoleread+0x48>
        }
        char c = cons.buf[cons.r++ % INBUF];
    80204188:	0012d717          	auipc	a4,0x12d
    8020418c:	89070713          	addi	a4,a4,-1904 # 80330a18 <cons>
    80204190:	0017869b          	addiw	a3,a5,1
    80204194:	08d72c23          	sw	a3,152(a4)
    80204198:	07f7f793          	andi	a5,a5,127
    8020419c:	973e                	add	a4,a4,a5
    8020419e:	01874783          	lbu	a5,24(a4)
    802041a2:	faf40fa3          	sb	a5,-65(s0)
        if (c == 4) break;                       /* Ctrl-D */
    802041a6:	4711                	li	a4,4
    802041a8:	02e78a63          	beq	a5,a4,802041dc <consoleread+0xc0>
        if (copyout(myproc()->pagetable, dst, &c, 1) < 0) break;
    802041ac:	ffffd097          	auipc	ra,0xffffd
    802041b0:	572080e7          	jalr	1394(ra) # 8020171e <myproc>
    802041b4:	4685                	li	a3,1
    802041b6:	fbf40613          	addi	a2,s0,-65
    802041ba:	85d2                	mv	a1,s4
    802041bc:	6928                	ld	a0,80(a0)
    802041be:	fffff097          	auipc	ra,0xfffff
    802041c2:	d90080e7          	jalr	-624(ra) # 80202f4e <copyout>
    802041c6:	00054b63          	bltz	a0,802041dc <consoleread+0xc0>
        dst++; n--;
    802041ca:	0a05                	addi	s4,s4,1
    802041cc:	3afd                	addiw	s5,s5,-1
        if (c == '\n') break;
    802041ce:	fbf44703          	lbu	a4,-65(s0)
    802041d2:	47a9                	li	a5,10
    802041d4:	00f70463          	beq	a4,a5,802041dc <consoleread+0xc0>
    while (n > 0) {
    802041d8:	f80a90e3          	bnez	s5,80204158 <consoleread+0x3c>
    }
    release(&cons.lock);
    802041dc:	0012d517          	auipc	a0,0x12d
    802041e0:	83c50513          	addi	a0,a0,-1988 # 80330a18 <cons>
    802041e4:	ffffd097          	auipc	ra,0xffffd
    802041e8:	204080e7          	jalr	516(ra) # 802013e8 <release>
    return target - n;
    802041ec:	4159853b          	subw	a0,s3,s5
    802041f0:	a811                	j	80204204 <consoleread+0xe8>
            if (myproc()->killed) { release(&cons.lock); return -1; }
    802041f2:	0012d517          	auipc	a0,0x12d
    802041f6:	82650513          	addi	a0,a0,-2010 # 80330a18 <cons>
    802041fa:	ffffd097          	auipc	ra,0xffffd
    802041fe:	1ee080e7          	jalr	494(ra) # 802013e8 <release>
    80204202:	557d                	li	a0,-1
}
    80204204:	60a6                	ld	ra,72(sp)
    80204206:	6406                	ld	s0,64(sp)
    80204208:	74e2                	ld	s1,56(sp)
    8020420a:	7942                	ld	s2,48(sp)
    8020420c:	79a2                	ld	s3,40(sp)
    8020420e:	7a02                	ld	s4,32(sp)
    80204210:	6ae2                	ld	s5,24(sp)
    80204212:	6161                	addi	sp,sp,80
    80204214:	8082                	ret

0000000080204216 <consoleinit>:
{
    80204216:	1141                	addi	sp,sp,-16
    80204218:	e406                	sd	ra,8(sp)
    8020421a:	e022                	sd	s0,0(sp)
    8020421c:	0800                	addi	s0,sp,16
    initlock(&cons.lock, "cons");
    8020421e:	00003597          	auipc	a1,0x3
    80204222:	74258593          	addi	a1,a1,1858 # 80207960 <etext+0x960>
    80204226:	0012c517          	auipc	a0,0x12c
    8020422a:	7f250513          	addi	a0,a0,2034 # 80330a18 <cons>
    8020422e:	ffffd097          	auipc	ra,0xffffd
    80204232:	08a080e7          	jalr	138(ra) # 802012b8 <initlock>
    devsw[CONSOLE].read  = consoleread;
    80204236:	00137797          	auipc	a5,0x137
    8020423a:	a1a78793          	addi	a5,a5,-1510 # 8033ac50 <devsw>
    8020423e:	00000717          	auipc	a4,0x0
    80204242:	ede70713          	addi	a4,a4,-290 # 8020411c <consoleread>
    80204246:	eb98                	sd	a4,16(a5)
    devsw[CONSOLE].write = consolewrite;
    80204248:	00000717          	auipc	a4,0x0
    8020424c:	e7270713          	addi	a4,a4,-398 # 802040ba <consolewrite>
    80204250:	ef98                	sd	a4,24(a5)
}
    80204252:	60a2                	ld	ra,8(sp)
    80204254:	6402                	ld	s0,0(sp)
    80204256:	0141                	addi	sp,sp,16
    80204258:	8082                	ret

000000008020425a <consoleintr>:

/* Called from the trap handler when the UART raises an interrupt. */
void consoleintr(int c)
{
    8020425a:	1101                	addi	sp,sp,-32
    8020425c:	ec06                	sd	ra,24(sp)
    8020425e:	e822                	sd	s0,16(sp)
    80204260:	e426                	sd	s1,8(sp)
    80204262:	1000                	addi	s0,sp,32
    80204264:	84aa                	mv	s1,a0
    acquire(&cons.lock);
    80204266:	0012c517          	auipc	a0,0x12c
    8020426a:	7b250513          	addi	a0,a0,1970 # 80330a18 <cons>
    8020426e:	ffffd097          	auipc	ra,0xffffd
    80204272:	0c6080e7          	jalr	198(ra) # 80201334 <acquire>
    switch (c) {
    80204276:	47c1                	li	a5,16
    80204278:	08f48463          	beq	s1,a5,80204300 <consoleintr+0xa6>
    8020427c:	07f00793          	li	a5,127
    80204280:	0af48163          	beq	s1,a5,80204322 <consoleintr+0xc8>
    80204284:	47a1                	li	a5,8
    80204286:	08f48e63          	beq	s1,a5,80204322 <consoleintr+0xc8>
            cons.e--;
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
        }
        break;
    default:
        if (c != 0 && cons.e - cons.r < INBUF) {
    8020428a:	ccbd                	beqz	s1,80204308 <consoleintr+0xae>
    8020428c:	0012c717          	auipc	a4,0x12c
    80204290:	78c70713          	addi	a4,a4,1932 # 80330a18 <cons>
    80204294:	0a072783          	lw	a5,160(a4)
    80204298:	09872703          	lw	a4,152(a4)
    8020429c:	9f99                	subw	a5,a5,a4
    8020429e:	07f00713          	li	a4,127
    802042a2:	06f76363          	bltu	a4,a5,80204308 <consoleintr+0xae>
            c = (c == '\r') ? '\n' : c;
    802042a6:	47b5                	li	a5,13
    802042a8:	0cf48f63          	beq	s1,a5,80204386 <consoleintr+0x12c>
    802042ac:	e04a                	sd	s2,0(sp)
            hal_console_putc(c);                 /* echo */
    802042ae:	0ff4f913          	zext.b	s2,s1
    802042b2:	854a                	mv	a0,s2
    802042b4:	00002097          	auipc	ra,0x2
    802042b8:	f56080e7          	jalr	-170(ra) # 8020620a <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    802042bc:	0012c797          	auipc	a5,0x12c
    802042c0:	75c78793          	addi	a5,a5,1884 # 80330a18 <cons>
    802042c4:	0a07a703          	lw	a4,160(a5)
    802042c8:	0017069b          	addiw	a3,a4,1
    802042cc:	0006861b          	sext.w	a2,a3
    802042d0:	0ad7a023          	sw	a3,160(a5)
    802042d4:	07f77713          	andi	a4,a4,127
    802042d8:	97ba                	add	a5,a5,a4
    802042da:	01278c23          	sb	s2,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    802042de:	47a9                	li	a5,10
    802042e0:	08f48363          	beq	s1,a5,80204366 <consoleintr+0x10c>
    802042e4:	4791                	li	a5,4
    802042e6:	08f48263          	beq	s1,a5,8020436a <consoleintr+0x110>
    802042ea:	0012c797          	auipc	a5,0x12c
    802042ee:	7c67a783          	lw	a5,1990(a5) # 80330ab0 <cons+0x98>
    802042f2:	9e9d                	subw	a3,a3,a5
    802042f4:	08000793          	li	a5,128
    802042f8:	06f68563          	beq	a3,a5,80204362 <consoleintr+0x108>
    802042fc:	6902                	ld	s2,0(sp)
    802042fe:	a029                	j	80204308 <consoleintr+0xae>
        procdump();
    80204300:	ffffe097          	auipc	ra,0xffffe
    80204304:	f14080e7          	jalr	-236(ra) # 80202214 <procdump>
                wakeup(&cons.r);
            }
        }
        break;
    }
    release(&cons.lock);
    80204308:	0012c517          	auipc	a0,0x12c
    8020430c:	71050513          	addi	a0,a0,1808 # 80330a18 <cons>
    80204310:	ffffd097          	auipc	ra,0xffffd
    80204314:	0d8080e7          	jalr	216(ra) # 802013e8 <release>
}
    80204318:	60e2                	ld	ra,24(sp)
    8020431a:	6442                	ld	s0,16(sp)
    8020431c:	64a2                	ld	s1,8(sp)
    8020431e:	6105                	addi	sp,sp,32
    80204320:	8082                	ret
        if (cons.e != cons.w) {
    80204322:	0012c717          	auipc	a4,0x12c
    80204326:	6f670713          	addi	a4,a4,1782 # 80330a18 <cons>
    8020432a:	0a072783          	lw	a5,160(a4)
    8020432e:	09c72703          	lw	a4,156(a4)
    80204332:	fcf70be3          	beq	a4,a5,80204308 <consoleintr+0xae>
            cons.e--;
    80204336:	37fd                	addiw	a5,a5,-1
    80204338:	0012c717          	auipc	a4,0x12c
    8020433c:	78f72023          	sw	a5,1920(a4) # 80330ab8 <cons+0xa0>
            hal_console_putc('\b'); hal_console_putc(' '); hal_console_putc('\b');
    80204340:	4521                	li	a0,8
    80204342:	00002097          	auipc	ra,0x2
    80204346:	ec8080e7          	jalr	-312(ra) # 8020620a <hal_console_putc>
    8020434a:	02000513          	li	a0,32
    8020434e:	00002097          	auipc	ra,0x2
    80204352:	ebc080e7          	jalr	-324(ra) # 8020620a <hal_console_putc>
    80204356:	4521                	li	a0,8
    80204358:	00002097          	auipc	ra,0x2
    8020435c:	eb2080e7          	jalr	-334(ra) # 8020620a <hal_console_putc>
    80204360:	b765                	j	80204308 <consoleintr+0xae>
    80204362:	6902                	ld	s2,0(sp)
    80204364:	a021                	j	8020436c <consoleintr+0x112>
    80204366:	6902                	ld	s2,0(sp)
    80204368:	a011                	j	8020436c <consoleintr+0x112>
    8020436a:	6902                	ld	s2,0(sp)
                cons.w = cons.e;
    8020436c:	0012c797          	auipc	a5,0x12c
    80204370:	74c7a423          	sw	a2,1864(a5) # 80330ab4 <cons+0x9c>
                wakeup(&cons.r);
    80204374:	0012c517          	auipc	a0,0x12c
    80204378:	73c50513          	addi	a0,a0,1852 # 80330ab0 <cons+0x98>
    8020437c:	ffffe097          	auipc	ra,0xffffe
    80204380:	b8c080e7          	jalr	-1140(ra) # 80201f08 <wakeup>
    80204384:	b751                	j	80204308 <consoleintr+0xae>
            hal_console_putc(c);                 /* echo */
    80204386:	4529                	li	a0,10
    80204388:	00002097          	auipc	ra,0x2
    8020438c:	e82080e7          	jalr	-382(ra) # 8020620a <hal_console_putc>
            cons.buf[cons.e++ % INBUF] = c;
    80204390:	0012c797          	auipc	a5,0x12c
    80204394:	68878793          	addi	a5,a5,1672 # 80330a18 <cons>
    80204398:	0a07a703          	lw	a4,160(a5)
    8020439c:	0017069b          	addiw	a3,a4,1
    802043a0:	0006861b          	sext.w	a2,a3
    802043a4:	0ad7a023          	sw	a3,160(a5)
    802043a8:	07f77713          	andi	a4,a4,127
    802043ac:	97ba                	add	a5,a5,a4
    802043ae:	4729                	li	a4,10
    802043b0:	00e78c23          	sb	a4,24(a5)
            if (c == '\n' || c == 4 || cons.e - cons.r == INBUF) {
    802043b4:	bf65                	j	8020436c <consoleintr+0x112>

00000000802043b6 <exec>:
    }
    return 0;
}

int exec(char *path, char **argv)
{
    802043b6:	7125                	addi	sp,sp,-416
    802043b8:	ef06                	sd	ra,408(sp)
    802043ba:	eb22                	sd	s0,400(sp)
    802043bc:	e726                	sd	s1,392(sp)
    802043be:	1300                	addi	s0,sp,416
    802043c0:	e8a43023          	sd	a0,-384(s0)
    802043c4:	e6b43c23          	sd	a1,-392(s0)
    struct inode *ip = namei(path);
    802043c8:	00001097          	auipc	ra,0x1
    802043cc:	52c080e7          	jalr	1324(ra) # 802058f4 <namei>
    if (ip == 0) return -1;
    802043d0:	3c050963          	beqz	a0,802047a2 <exec+0x3ec>
    802043d4:	f2da                	sd	s6,352(sp)
    802043d6:	8b2a                	mv	s6,a0
    ilock(ip);
    802043d8:	00001097          	auipc	ra,0x1
    802043dc:	c88080e7          	jalr	-888(ra) # 80205060 <ilock>

    struct elfhdr eh;
    pagetable_t newpt = 0;
    uint64 sz = 0;

    if (readi(ip, 0, (uint64)&eh, 0, sizeof(eh)) != sizeof(eh)) goto bad;
    802043e0:	04000713          	li	a4,64
    802043e4:	4681                	li	a3,0
    802043e6:	f5040613          	addi	a2,s0,-176
    802043ea:	4581                	li	a1,0
    802043ec:	855a                	mv	a0,s6
    802043ee:	00001097          	auipc	ra,0x1
    802043f2:	fa0080e7          	jalr	-96(ra) # 8020538e <readi>
    802043f6:	04000793          	li	a5,64
    802043fa:	02f51263          	bne	a0,a5,8020441e <exec+0x68>
    if (eh.magic != ELF_MAGIC) goto bad;              /* reject, do not run */
    802043fe:	f5042703          	lw	a4,-176(s0)
    80204402:	464c47b7          	lui	a5,0x464c4
    80204406:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39d3ba81>
    8020440a:	00f71a63          	bne	a4,a5,8020441e <exec+0x68>
    if (eh.phnum == 0 || eh.phnum > 16) goto bad;
    8020440e:	f8845783          	lhu	a5,-120(s0)
    80204412:	37fd                	addiw	a5,a5,-1
    80204414:	17c2                	slli	a5,a5,0x30
    80204416:	93c1                	srli	a5,a5,0x30
    80204418:	473d                	li	a4,15
    8020441a:	00f77f63          	bgeu	a4,a5,80204438 <exec+0x82>
    uvmfree(oldpt, oldsz);
    return argc;

bad:
    if (newpt) uvmfree(newpt, sz);
    if (ip) iunlockput(ip);
    8020441e:	855a                	mv	a0,s6
    80204420:	00001097          	auipc	ra,0x1
    80204424:	f1c080e7          	jalr	-228(ra) # 8020533c <iunlockput>
    return -1;
    80204428:	54fd                	li	s1,-1
    8020442a:	7b16                	ld	s6,352(sp)
}
    8020442c:	8526                	mv	a0,s1
    8020442e:	60fa                	ld	ra,408(sp)
    80204430:	645a                	ld	s0,400(sp)
    80204432:	64ba                	ld	s1,392(sp)
    80204434:	611d                	addi	sp,sp,416
    80204436:	8082                	ret
    80204438:	eae2                	sd	s8,336(sp)
    if ((newpt = uvmcreate()) == 0) goto bad;
    8020443a:	fffff097          	auipc	ra,0xfffff
    8020443e:	94c080e7          	jalr	-1716(ra) # 80202d86 <uvmcreate>
    80204442:	8c2a                	mv	s8,a0
    80204444:	34050d63          	beqz	a0,8020479e <exec+0x3e8>
    80204448:	e34a                	sd	s2,384(sp)
    8020444a:	fece                	sd	s3,376(sp)
    8020444c:	fad2                	sd	s4,368(sp)
    8020444e:	f6d6                	sd	s5,360(sp)
    80204450:	eede                	sd	s7,344(sp)
    80204452:	e6e6                	sd	s9,328(sp)
    80204454:	e2ea                	sd	s10,320(sp)
    80204456:	fe6e                	sd	s11,312(sp)
    for (int i = 0; i < eh.phnum; i++) {
    80204458:	f8845783          	lhu	a5,-120(s0)
    8020445c:	16078563          	beqz	a5,802045c6 <exec+0x210>
    80204460:	4c81                	li	s9,0
    80204462:	4d01                	li	s10,0
    uint64 sz = 0;
    80204464:	e8043423          	sd	zero,-376(s0)
        if (ph.type != ELF_PROG_LOAD) continue;
    80204468:	4d85                	li	s11,1
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    8020446a:	800007b7          	lui	a5,0x80000
    8020446e:	fff7c793          	not	a5,a5
    80204472:	e6f43823          	sd	a5,-400(s0)
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    80204476:	6a05                	lui	s4,0x1
    80204478:	fffa0793          	addi	a5,s4,-1 # fff <_entry-0x801ff001>
    8020447c:	e6f43423          	sd	a5,-408(s0)
    80204480:	a0d1                	j	80204544 <exec+0x18e>
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    80204482:	00c4f563          	bgeu	s1,a2,8020448c <exec+0xd6>
    80204486:	8e05                	sub	a2,a2,s1
    80204488:	4781                	li	a5,0
    8020448a:	a09d                	j	802044f0 <exec+0x13a>
    8020448c:	4781                	li	a5,0
    8020448e:	4601                	li	a2,0
    80204490:	a085                	j	802044f0 <exec+0x13a>
            if (readi(ip, 0, (uint64)(mem + dst_off),
    80204492:	2981                	sext.w	s3,s3
    80204494:	874e                	mv	a4,s3
    80204496:	e9843683          	ld	a3,-360(s0)
    8020449a:	9ebd                	addw	a3,a3,a5
    8020449c:	964a                	add	a2,a2,s2
    8020449e:	4581                	li	a1,0
    802044a0:	855a                	mv	a0,s6
    802044a2:	00001097          	auipc	ra,0x1
    802044a6:	eec080e7          	jalr	-276(ra) # 8020538e <readi>
    802044aa:	05351f63          	bne	a0,s3,80204508 <exec+0x152>
        if (mappages(pt, va, PGSIZE, (uint64)mem, perm) != 0) {
    802044ae:	875e                	mv	a4,s7
    802044b0:	86ca                	mv	a3,s2
    802044b2:	8652                	mv	a2,s4
    802044b4:	85a6                	mv	a1,s1
    802044b6:	8562                	mv	a0,s8
    802044b8:	ffffe097          	auipc	ra,0xffffe
    802044bc:	6bc080e7          	jalr	1724(ra) # 80202b74 <mappages>
    802044c0:	e931                	bnez	a0,80204514 <exec+0x15e>
    for (uint64 va = start; va < end; va += PGSIZE) {
    802044c2:	94d2                	add	s1,s1,s4
    802044c4:	0554fe63          	bgeu	s1,s5,80204520 <exec+0x16a>
        char *mem = palloc();
    802044c8:	ffffd097          	auipc	ra,0xffffd
    802044cc:	bde080e7          	jalr	-1058(ra) # 802010a6 <palloc>
    802044d0:	892a                	mv	s2,a0
        if (!mem) return -1;
    802044d2:	1c050063          	beqz	a0,80204692 <exec+0x2dc>
        memset(mem, 0, PGSIZE);                    /* zero first: this IS the .bss */
    802044d6:	8652                	mv	a2,s4
    802044d8:	4581                	li	a1,0
    802044da:	ffffc097          	auipc	ra,0xffffc
    802044de:	1ca080e7          	jalr	458(ra) # 802006a4 <memset>
        uint64 seg_off = (va > ph->vaddr) ? (va - ph->vaddr) : 0;
    802044e2:	ea043603          	ld	a2,-352(s0)
    802044e6:	f8967ee3          	bgeu	a2,s1,80204482 <exec+0xcc>
    802044ea:	40c487b3          	sub	a5,s1,a2
        uint64 dst_off = (va < ph->vaddr) ? (ph->vaddr - va) : 0;
    802044ee:	4601                	li	a2,0
        if (seg_off < ph->filesz) {
    802044f0:	eb043983          	ld	s3,-336(s0)
    802044f4:	fb37fde3          	bgeu	a5,s3,802044ae <exec+0xf8>
            if (n > PGSIZE - dst_off) n = PGSIZE - dst_off;
    802044f8:	40ca0733          	sub	a4,s4,a2
    802044fc:	40f989b3          	sub	s3,s3,a5
    80204500:	f93779e3          	bgeu	a4,s3,80204492 <exec+0xdc>
    80204504:	89ba                	mv	s3,a4
    80204506:	b771                	j	80204492 <exec+0xdc>
                pfree(mem);
    80204508:	854a                	mv	a0,s2
    8020450a:	ffffd097          	auipc	ra,0xffffd
    8020450e:	cac080e7          	jalr	-852(ra) # 802011b6 <pfree>
                return -1;
    80204512:	a241                	j	80204692 <exec+0x2dc>
            pfree(mem);
    80204514:	854a                	mv	a0,s2
    80204516:	ffffd097          	auipc	ra,0xffffd
    8020451a:	ca0080e7          	jalr	-864(ra) # 802011b6 <pfree>
            return -1;
    8020451e:	aa95                	j	80204692 <exec+0x2dc>
        if (ph.vaddr + ph.memsz > sz) sz = ph.vaddr + ph.memsz;
    80204520:	ea043783          	ld	a5,-352(s0)
    80204524:	eb843703          	ld	a4,-328(s0)
    80204528:	97ba                	add	a5,a5,a4
    8020452a:	e8843703          	ld	a4,-376(s0)
    8020452e:	00f77463          	bgeu	a4,a5,80204536 <exec+0x180>
    80204532:	e8f43423          	sd	a5,-376(s0)
    for (int i = 0; i < eh.phnum; i++) {
    80204536:	2d05                	addiw	s10,s10,1 # 1001 <_entry-0x801fefff>
    80204538:	038c8c9b          	addiw	s9,s9,56
    8020453c:	f8845783          	lhu	a5,-120(s0)
    80204540:	08fd5563          	bge	s10,a5,802045ca <exec+0x214>
        if (readi(ip, 0, (uint64)&ph, eh.phoff + i * sizeof(ph),
    80204544:	03800713          	li	a4,56
    80204548:	f7043683          	ld	a3,-144(s0)
    8020454c:	019686bb          	addw	a3,a3,s9
    80204550:	e9040613          	addi	a2,s0,-368
    80204554:	4581                	li	a1,0
    80204556:	855a                	mv	a0,s6
    80204558:	00001097          	auipc	ra,0x1
    8020455c:	e36080e7          	jalr	-458(ra) # 8020538e <readi>
    80204560:	03800793          	li	a5,56
    80204564:	12f51763          	bne	a0,a5,80204692 <exec+0x2dc>
        if (ph.type != ELF_PROG_LOAD) continue;
    80204568:	e9042783          	lw	a5,-368(s0)
    8020456c:	fdb795e3          	bne	a5,s11,80204536 <exec+0x180>
        if (ph.memsz < ph.filesz) goto bad;           /* malformed */
    80204570:	eb843a83          	ld	s5,-328(s0)
    80204574:	eb043783          	ld	a5,-336(s0)
    80204578:	10faed63          	bltu	s5,a5,80204692 <exec+0x2dc>
        if (ph.vaddr + ph.memsz < ph.vaddr) goto bad; /* overflow  */
    8020457c:	ea043483          	ld	s1,-352(s0)
    80204580:	9aa6                	add	s5,s5,s1
    80204582:	109ae863          	bltu	s5,s1,80204692 <exec+0x2dc>
        if (ph.vaddr + ph.memsz >= 0x80000000UL) goto bad;  /* into kernel! */
    80204586:	e7043783          	ld	a5,-400(s0)
    8020458a:	1157e463          	bltu	a5,s5,80204692 <exec+0x2dc>
    if (ph->flags & ELF_PROG_FLAG_READ)  perm |= PTE_R;
    8020458e:	e9442783          	lw	a5,-364(s0)
    80204592:	0047f713          	andi	a4,a5,4
    80204596:	4bc9                	li	s7,18
    80204598:	e311                	bnez	a4,8020459c <exec+0x1e6>
    int perm = PTE_U;
    8020459a:	4bc1                	li	s7,16
    if (ph->flags & ELF_PROG_FLAG_WRITE) perm |= PTE_W;
    8020459c:	0027f713          	andi	a4,a5,2
    802045a0:	c319                	beqz	a4,802045a6 <exec+0x1f0>
    802045a2:	004beb93          	ori	s7,s7,4
    if (ph->flags & ELF_PROG_FLAG_EXEC)  perm |= PTE_X;
    802045a6:	8b85                	andi	a5,a5,1
    802045a8:	0037979b          	slliw	a5,a5,0x3
    802045ac:	00fbebb3          	or	s7,s7,a5
    802045b0:	2b81                	sext.w	s7,s7
    uint64 start = PGROUNDDOWN(ph->vaddr);
    802045b2:	77fd                	lui	a5,0xfffff
    802045b4:	8cfd                	and	s1,s1,a5
    uint64 end   = PGROUNDUP(ph->vaddr + ph->memsz);
    802045b6:	e6843703          	ld	a4,-408(s0)
    802045ba:	9aba                	add	s5,s5,a4
    802045bc:	00fafab3          	and	s5,s5,a5
    for (uint64 va = start; va < end; va += PGSIZE) {
    802045c0:	f154e4e3          	bltu	s1,s5,802044c8 <exec+0x112>
    802045c4:	bfb1                	j	80204520 <exec+0x16a>
    uint64 sz = 0;
    802045c6:	e8043423          	sd	zero,-376(s0)
    iunlockput(ip);
    802045ca:	855a                	mv	a0,s6
    802045cc:	00001097          	auipc	ra,0x1
    802045d0:	d70080e7          	jalr	-656(ra) # 8020533c <iunlockput>
    sz = PGROUNDUP(sz);
    802045d4:	6785                	lui	a5,0x1
    802045d6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x801ff001>
    802045d8:	e8843703          	ld	a4,-376(s0)
    802045dc:	97ba                	add	a5,a5,a4
    802045de:	7dfd                	lui	s11,0xfffff
    802045e0:	01b7f4b3          	and	s1,a5,s11
    802045e4:	e8943423          	sd	s1,-376(s0)
    char *stack = palloc();
    802045e8:	ffffd097          	auipc	ra,0xffffd
    802045ec:	abe080e7          	jalr	-1346(ra) # 802010a6 <palloc>
    802045f0:	8b2a                	mv	s6,a0
    if (!stack) goto bad;
    802045f2:	c145                	beqz	a0,80204692 <exec+0x2dc>
    uint64 stackbase = guard + PGSIZE;
    802045f4:	6a85                	lui	s5,0x1
    802045f6:	9aa6                	add	s5,s5,s1
    memset(stack, 0, PGSIZE);
    802045f8:	6605                	lui	a2,0x1
    802045fa:	4581                	li	a1,0
    802045fc:	ffffc097          	auipc	ra,0xffffc
    80204600:	0a8080e7          	jalr	168(ra) # 802006a4 <memset>
    if (mappages(newpt, stackbase, PGSIZE, (uint64)stack,
    80204604:	4759                	li	a4,22
    80204606:	86da                	mv	a3,s6
    80204608:	6605                	lui	a2,0x1
    8020460a:	85d6                	mv	a1,s5
    8020460c:	8562                	mv	a0,s8
    8020460e:	ffffe097          	auipc	ra,0xffffe
    80204612:	566080e7          	jalr	1382(ra) # 80202b74 <mappages>
    80204616:	84aa                	mv	s1,a0
    80204618:	e505                	bnez	a0,80204640 <exec+0x28a>
    uint64 sp    = stackbase + PGSIZE;
    8020461a:	6789                	lui	a5,0x2
    8020461c:	e8843703          	ld	a4,-376(s0)
    80204620:	00f70d33          	add	s10,a4,a5
    struct proc *pp = myproc();
    80204624:	ffffd097          	auipc	ra,0xffffd
    80204628:	0fa080e7          	jalr	250(ra) # 8020171e <myproc>
    8020462c:	8baa                	mv	s7,a0
    for (; argv && argv[argc]; argc++) {
    8020462e:	e7843783          	ld	a5,-392(s0)
    80204632:	c7c9                	beqz	a5,802046bc <exec+0x306>
    80204634:	893e                	mv	s2,a5
    80204636:	ec840a13          	addi	s4,s0,-312
    uint64 sp    = stackbase + PGSIZE;
    8020463a:	89ea                	mv	s3,s10
        if (argc >= MAXARG) goto bad;
    8020463c:	4cc1                	li	s9,16
    8020463e:	a821                	j	80204656 <exec+0x2a0>
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    80204640:	855a                	mv	a0,s6
    80204642:	ffffd097          	auipc	ra,0xffffd
    80204646:	b74080e7          	jalr	-1164(ra) # 802011b6 <pfree>
    ip = 0;
    8020464a:	4b01                	li	s6,0
                 PTE_R | PTE_W | PTE_U) != 0) { pfree(stack); goto bad; }
    8020464c:	a099                	j	80204692 <exec+0x2dc>
        ustack[argc] = sp;
    8020464e:	013a3023          	sd	s3,0(s4)
    for (; argv && argv[argc]; argc++) {
    80204652:	2485                	addiw	s1,s1,1
    80204654:	0a21                	addi	s4,s4,8
    80204656:	8b4a                	mv	s6,s2
    80204658:	00093503          	ld	a0,0(s2)
    8020465c:	c12d                	beqz	a0,802046be <exec+0x308>
        if (argc >= MAXARG) goto bad;
    8020465e:	03948963          	beq	s1,s9,80204690 <exec+0x2da>
        uint64 len = strlen(argv[argc]) + 1;
    80204662:	ffffc097          	auipc	ra,0xffffc
    80204666:	140080e7          	jalr	320(ra) # 802007a2 <strlen>
    8020466a:	0015069b          	addiw	a3,a0,1
        sp -= len;
    8020466e:	40d989b3          	sub	s3,s3,a3
        sp &= ~7UL;                                   /* keep it 8-aligned */
    80204672:	ff89f993          	andi	s3,s3,-8
        if (sp < stackbase) goto bad;
    80204676:	0159ed63          	bltu	s3,s5,80204690 <exec+0x2da>
        if (copyout(newpt, sp, argv[argc], len) < 0) goto bad;
    8020467a:	000b3603          	ld	a2,0(s6) # 1000 <_entry-0x801ff000>
    8020467e:	85ce                	mv	a1,s3
    80204680:	8562                	mv	a0,s8
    80204682:	fffff097          	auipc	ra,0xfffff
    80204686:	8cc080e7          	jalr	-1844(ra) # 80202f4e <copyout>
    8020468a:	0921                	addi	s2,s2,8
    8020468c:	fc0551e3          	bgez	a0,8020464e <exec+0x298>
    if (newpt) uvmfree(newpt, sz);
    80204690:	4b01                	li	s6,0
    80204692:	e8843583          	ld	a1,-376(s0)
    80204696:	8562                	mv	a0,s8
    80204698:	ffffe097          	auipc	ra,0xffffe
    8020469c:	7ae080e7          	jalr	1966(ra) # 80202e46 <uvmfree>
    return -1;
    802046a0:	54fd                	li	s1,-1
    if (ip) iunlockput(ip);
    802046a2:	0e0b1463          	bnez	s6,8020478a <exec+0x3d4>
    802046a6:	691a                	ld	s2,384(sp)
    802046a8:	79f6                	ld	s3,376(sp)
    802046aa:	7a56                	ld	s4,368(sp)
    802046ac:	7ab6                	ld	s5,360(sp)
    802046ae:	7b16                	ld	s6,352(sp)
    802046b0:	6bf6                	ld	s7,344(sp)
    802046b2:	6c56                	ld	s8,336(sp)
    802046b4:	6cb6                	ld	s9,328(sp)
    802046b6:	6d16                	ld	s10,320(sp)
    802046b8:	7df2                	ld	s11,312(sp)
    802046ba:	bb8d                	j	8020442c <exec+0x76>
    uint64 sp    = stackbase + PGSIZE;
    802046bc:	89ea                	mv	s3,s10
    ustack[argc] = 0;
    802046be:	00349793          	slli	a5,s1,0x3
    802046c2:	f9078793          	addi	a5,a5,-112 # 1f90 <_entry-0x801fe070>
    802046c6:	97a2                	add	a5,a5,s0
    802046c8:	f207bc23          	sd	zero,-200(a5)
    sp -= (argc + 1) * sizeof(uint64);
    802046cc:	0014869b          	addiw	a3,s1,1
    802046d0:	068e                	slli	a3,a3,0x3
    802046d2:	40d98933          	sub	s2,s3,a3
    sp &= ~15UL;                                      /* 16-byte ABI alignment */
    802046d6:	ff097913          	andi	s2,s2,-16
    ip = 0;
    802046da:	4b01                	li	s6,0
    if (sp < stackbase) goto bad;
    802046dc:	fb596be3          	bltu	s2,s5,80204692 <exec+0x2dc>
    if (copyout(newpt, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) < 0) goto bad;
    802046e0:	ec840613          	addi	a2,s0,-312
    802046e4:	85ca                	mv	a1,s2
    802046e6:	8562                	mv	a0,s8
    802046e8:	fffff097          	auipc	ra,0xfffff
    802046ec:	866080e7          	jalr	-1946(ra) # 80202f4e <copyout>
    802046f0:	0a054b63          	bltz	a0,802047a6 <exec+0x3f0>
    pagetable_t oldpt = pp->pagetable;
    802046f4:	050bb983          	ld	s3,80(s7) # 1050 <_entry-0x801fefb0>
    uint64      oldsz = pp->sz;
    802046f8:	048bba03          	ld	s4,72(s7)
    pp->pagetable = newpt;
    802046fc:	058bb823          	sd	s8,80(s7)
    pp->sz        = newsz;
    80204700:	05abb423          	sd	s10,72(s7)
    pp->tf->epc   = eh.entry;
    80204704:	058bb783          	ld	a5,88(s7)
    80204708:	f6843703          	ld	a4,-152(s0)
    8020470c:	ef98                	sd	a4,24(a5)
    pp->tf->sp    = sp;
    8020470e:	058bb783          	ld	a5,88(s7)
    80204712:	0327b823          	sd	s2,48(a5)
    pp->tf->a1    = sp;                               /* argv for main() */
    80204716:	058bb783          	ld	a5,88(s7)
    8020471a:	0727bc23          	sd	s2,120(a5)
    for (const char *s = path; *s; s++) if (*s == '/') last = s + 1;
    8020471e:	e8043783          	ld	a5,-384(s0)
    80204722:	0007c703          	lbu	a4,0(a5)
    80204726:	cf11                	beqz	a4,80204742 <exec+0x38c>
    80204728:	0785                	addi	a5,a5,1
    8020472a:	02f00693          	li	a3,47
    8020472e:	a039                	j	8020473c <exec+0x386>
    80204730:	e8f43023          	sd	a5,-384(s0)
    80204734:	0785                	addi	a5,a5,1
    80204736:	fff7c703          	lbu	a4,-1(a5)
    8020473a:	c701                	beqz	a4,80204742 <exec+0x38c>
    8020473c:	fed71ce3          	bne	a4,a3,80204734 <exec+0x37e>
    80204740:	bfc5                	j	80204730 <exec+0x37a>
    strncpy(pp->name, last, sizeof(pp->name));
    80204742:	4641                	li	a2,16
    80204744:	e8043583          	ld	a1,-384(s0)
    80204748:	158b8513          	addi	a0,s7,344
    8020474c:	ffffc097          	auipc	ra,0xffffc
    80204750:	01a080e7          	jalr	26(ra) # 80200766 <strncpy>
    w_satp(MAKE_SATP(pp->pagetable));                 /* we are running on it now */
    80204754:	050bb783          	ld	a5,80(s7)
    80204758:	83b1                	srli	a5,a5,0xc
    8020475a:	577d                	li	a4,-1
    8020475c:	177e                	slli	a4,a4,0x3f
    8020475e:	8fd9                	or	a5,a5,a4
static inline void   w_satp(uint64 x){ asm volatile("csrw satp, %0"::"r"(x)); }
    80204760:	18079073          	csrw	satp,a5
static inline void   sfence_vma(void){ asm volatile("sfence.vma zero, zero"); }
    80204764:	12000073          	sfence.vma
    uvmfree(oldpt, oldsz);
    80204768:	85d2                	mv	a1,s4
    8020476a:	854e                	mv	a0,s3
    8020476c:	ffffe097          	auipc	ra,0xffffe
    80204770:	6da080e7          	jalr	1754(ra) # 80202e46 <uvmfree>
    return argc;
    80204774:	691a                	ld	s2,384(sp)
    80204776:	79f6                	ld	s3,376(sp)
    80204778:	7a56                	ld	s4,368(sp)
    8020477a:	7ab6                	ld	s5,360(sp)
    8020477c:	7b16                	ld	s6,352(sp)
    8020477e:	6bf6                	ld	s7,344(sp)
    80204780:	6c56                	ld	s8,336(sp)
    80204782:	6cb6                	ld	s9,328(sp)
    80204784:	6d16                	ld	s10,320(sp)
    80204786:	7df2                	ld	s11,312(sp)
    80204788:	b155                	j	8020442c <exec+0x76>
    8020478a:	691a                	ld	s2,384(sp)
    8020478c:	79f6                	ld	s3,376(sp)
    8020478e:	7a56                	ld	s4,368(sp)
    80204790:	7ab6                	ld	s5,360(sp)
    80204792:	6bf6                	ld	s7,344(sp)
    80204794:	6c56                	ld	s8,336(sp)
    80204796:	6cb6                	ld	s9,328(sp)
    80204798:	6d16                	ld	s10,320(sp)
    8020479a:	7df2                	ld	s11,312(sp)
    8020479c:	b149                	j	8020441e <exec+0x68>
    8020479e:	6c56                	ld	s8,336(sp)
    802047a0:	b9bd                	j	8020441e <exec+0x68>
    if (ip == 0) return -1;
    802047a2:	54fd                	li	s1,-1
    802047a4:	b161                	j	8020442c <exec+0x76>
    ip = 0;
    802047a6:	4b01                	li	s6,0
    if (newpt) uvmfree(newpt, sz);
    802047a8:	b5ed                	j	80204692 <exec+0x2dc>

00000000802047aa <binit>:
    struct buf buf[NBUF];
    struct buf head;          /* LRU list: head.next = most recent */
} bcache;

void binit(void)
{
    802047aa:	7179                	addi	sp,sp,-48
    802047ac:	f406                	sd	ra,40(sp)
    802047ae:	f022                	sd	s0,32(sp)
    802047b0:	ec26                	sd	s1,24(sp)
    802047b2:	e84a                	sd	s2,16(sp)
    802047b4:	e44e                	sd	s3,8(sp)
    802047b6:	e052                	sd	s4,0(sp)
    802047b8:	1800                	addi	s0,sp,48
    initlock(&bcache.lock, "bcache");
    802047ba:	00003597          	auipc	a1,0x3
    802047be:	1ae58593          	addi	a1,a1,430 # 80207968 <etext+0x968>
    802047c2:	0012c517          	auipc	a0,0x12c
    802047c6:	2fe50513          	addi	a0,a0,766 # 80330ac0 <bcache>
    802047ca:	ffffd097          	auipc	ra,0xffffd
    802047ce:	aee080e7          	jalr	-1298(ra) # 802012b8 <initlock>
    bcache.head.prev = &bcache.head;
    802047d2:	00134797          	auipc	a5,0x134
    802047d6:	2ee78793          	addi	a5,a5,750 # 80338ac0 <bcache+0x8000>
    802047da:	00134717          	auipc	a4,0x134
    802047de:	54e70713          	addi	a4,a4,1358 # 80338d28 <bcache+0x8268>
    802047e2:	2ae7b823          	sd	a4,688(a5)
    bcache.head.next = &bcache.head;
    802047e6:	2ae7bc23          	sd	a4,696(a5)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    802047ea:	0012c497          	auipc	s1,0x12c
    802047ee:	2ee48493          	addi	s1,s1,750 # 80330ad8 <bcache+0x18>
        b->next = bcache.head.next;
    802047f2:	893e                	mv	s2,a5
        b->prev = &bcache.head;
    802047f4:	89ba                	mv	s3,a4
        initsleeplock(&b->lock, "buffer");
    802047f6:	00003a17          	auipc	s4,0x3
    802047fa:	17aa0a13          	addi	s4,s4,378 # 80207970 <etext+0x970>
        b->next = bcache.head.next;
    802047fe:	2b893783          	ld	a5,696(s2)
    80204802:	e8bc                	sd	a5,80(s1)
        b->prev = &bcache.head;
    80204804:	0534b423          	sd	s3,72(s1)
        initsleeplock(&b->lock, "buffer");
    80204808:	85d2                	mv	a1,s4
    8020480a:	01048513          	addi	a0,s1,16
    8020480e:	ffffd097          	auipc	ra,0xffffd
    80204812:	c22080e7          	jalr	-990(ra) # 80201430 <initsleeplock>
        bcache.head.next->prev = b;
    80204816:	2b893783          	ld	a5,696(s2)
    8020481a:	e7a4                	sd	s1,72(a5)
        bcache.head.next = b;
    8020481c:	2a993c23          	sd	s1,696(s2)
    for (struct buf *b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80204820:	45848493          	addi	s1,s1,1112
    80204824:	fd349de3          	bne	s1,s3,802047fe <binit+0x54>
    }
}
    80204828:	70a2                	ld	ra,40(sp)
    8020482a:	7402                	ld	s0,32(sp)
    8020482c:	64e2                	ld	s1,24(sp)
    8020482e:	6942                	ld	s2,16(sp)
    80204830:	69a2                	ld	s3,8(sp)
    80204832:	6a02                	ld	s4,0(sp)
    80204834:	6145                	addi	sp,sp,48
    80204836:	8082                	ret

0000000080204838 <bread>:
    }
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
}

struct buf *bread(uint32 dev, uint32 blockno)
{
    80204838:	7179                	addi	sp,sp,-48
    8020483a:	f406                	sd	ra,40(sp)
    8020483c:	f022                	sd	s0,32(sp)
    8020483e:	ec26                	sd	s1,24(sp)
    80204840:	e84a                	sd	s2,16(sp)
    80204842:	e44e                	sd	s3,8(sp)
    80204844:	1800                	addi	s0,sp,48
    80204846:	892a                	mv	s2,a0
    80204848:	89ae                	mv	s3,a1
    acquire(&bcache.lock);
    8020484a:	0012c517          	auipc	a0,0x12c
    8020484e:	27650513          	addi	a0,a0,630 # 80330ac0 <bcache>
    80204852:	ffffd097          	auipc	ra,0xffffd
    80204856:	ae2080e7          	jalr	-1310(ra) # 80201334 <acquire>
    for (struct buf *b = bcache.head.next; b != &bcache.head; b = b->next) {
    8020485a:	00134497          	auipc	s1,0x134
    8020485e:	51e4b483          	ld	s1,1310(s1) # 80338d78 <bcache+0x82b8>
    80204862:	00134797          	auipc	a5,0x134
    80204866:	4c678793          	addi	a5,a5,1222 # 80338d28 <bcache+0x8268>
    8020486a:	02f48f63          	beq	s1,a5,802048a8 <bread+0x70>
    8020486e:	873e                	mv	a4,a5
    80204870:	a021                	j	80204878 <bread+0x40>
    80204872:	68a4                	ld	s1,80(s1)
    80204874:	02e48a63          	beq	s1,a4,802048a8 <bread+0x70>
        if (b->dev == dev && b->blockno == blockno) {
    80204878:	449c                	lw	a5,8(s1)
    8020487a:	ff279ce3          	bne	a5,s2,80204872 <bread+0x3a>
    8020487e:	44dc                	lw	a5,12(s1)
    80204880:	ff3799e3          	bne	a5,s3,80204872 <bread+0x3a>
            b->refcnt++;
    80204884:	40bc                	lw	a5,64(s1)
    80204886:	2785                	addiw	a5,a5,1
    80204888:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    8020488a:	0012c517          	auipc	a0,0x12c
    8020488e:	23650513          	addi	a0,a0,566 # 80330ac0 <bcache>
    80204892:	ffffd097          	auipc	ra,0xffffd
    80204896:	b56080e7          	jalr	-1194(ra) # 802013e8 <release>
            acquiresleep(&b->lock);
    8020489a:	01048513          	addi	a0,s1,16
    8020489e:	ffffd097          	auipc	ra,0xffffd
    802048a2:	bcc080e7          	jalr	-1076(ra) # 8020146a <acquiresleep>
            return b;
    802048a6:	a8b9                	j	80204904 <bread+0xcc>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    802048a8:	00134497          	auipc	s1,0x134
    802048ac:	4c84b483          	ld	s1,1224(s1) # 80338d70 <bcache+0x82b0>
    802048b0:	00134797          	auipc	a5,0x134
    802048b4:	47878793          	addi	a5,a5,1144 # 80338d28 <bcache+0x8268>
    802048b8:	00f48863          	beq	s1,a5,802048c8 <bread+0x90>
    802048bc:	873e                	mv	a4,a5
        if (b->refcnt == 0) {
    802048be:	40bc                	lw	a5,64(s1)
    802048c0:	cf81                	beqz	a5,802048d8 <bread+0xa0>
    for (struct buf *b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    802048c2:	64a4                	ld	s1,72(s1)
    802048c4:	fee49de3          	bne	s1,a4,802048be <bread+0x86>
    panic("bget: no buffers - raise NBUF or find the brelse you forgot");
    802048c8:	00003517          	auipc	a0,0x3
    802048cc:	0b050513          	addi	a0,a0,176 # 80207978 <etext+0x978>
    802048d0:	ffffc097          	auipc	ra,0xffffc
    802048d4:	d2e080e7          	jalr	-722(ra) # 802005fe <panic>
            b->dev = dev;
    802048d8:	0124a423          	sw	s2,8(s1)
            b->blockno = blockno;
    802048dc:	0134a623          	sw	s3,12(s1)
            b->valid = 0;
    802048e0:	0004a023          	sw	zero,0(s1)
            b->refcnt = 1;
    802048e4:	4785                	li	a5,1
    802048e6:	c0bc                	sw	a5,64(s1)
            release(&bcache.lock);
    802048e8:	0012c517          	auipc	a0,0x12c
    802048ec:	1d850513          	addi	a0,a0,472 # 80330ac0 <bcache>
    802048f0:	ffffd097          	auipc	ra,0xffffd
    802048f4:	af8080e7          	jalr	-1288(ra) # 802013e8 <release>
            acquiresleep(&b->lock);
    802048f8:	01048513          	addi	a0,s1,16
    802048fc:	ffffd097          	auipc	ra,0xffffd
    80204900:	b6e080e7          	jalr	-1170(ra) # 8020146a <acquiresleep>
    struct buf *b = bget(dev, blockno);
    if (!b->valid) {
    80204904:	409c                	lw	a5,0(s1)
    80204906:	cb89                	beqz	a5,80204918 <bread+0xe0>
        hal_block_rw(b, 0);
        b->valid = 1;
    }
    return b;
}
    80204908:	8526                	mv	a0,s1
    8020490a:	70a2                	ld	ra,40(sp)
    8020490c:	7402                	ld	s0,32(sp)
    8020490e:	64e2                	ld	s1,24(sp)
    80204910:	6942                	ld	s2,16(sp)
    80204912:	69a2                	ld	s3,8(sp)
    80204914:	6145                	addi	sp,sp,48
    80204916:	8082                	ret
        hal_block_rw(b, 0);
    80204918:	4581                	li	a1,0
    8020491a:	8526                	mv	a0,s1
    8020491c:	00002097          	auipc	ra,0x2
    80204920:	c46080e7          	jalr	-954(ra) # 80206562 <hal_block_rw>
        b->valid = 1;
    80204924:	4785                	li	a5,1
    80204926:	c09c                	sw	a5,0(s1)
    return b;
    80204928:	b7c5                	j	80204908 <bread+0xd0>

000000008020492a <bwrite>:

/* Caller must hold b->lock (i.e. this buf came from bread). */
void bwrite(struct buf *b)
{
    8020492a:	1101                	addi	sp,sp,-32
    8020492c:	ec06                	sd	ra,24(sp)
    8020492e:	e822                	sd	s0,16(sp)
    80204930:	e426                	sd	s1,8(sp)
    80204932:	1000                	addi	s0,sp,32
    80204934:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80204936:	0541                	addi	a0,a0,16
    80204938:	ffffd097          	auipc	ra,0xffffd
    8020493c:	bcc080e7          	jalr	-1076(ra) # 80201504 <holdingsleep>
    80204940:	cd01                	beqz	a0,80204958 <bwrite+0x2e>
    hal_block_rw(b, 1);
    80204942:	4585                	li	a1,1
    80204944:	8526                	mv	a0,s1
    80204946:	00002097          	auipc	ra,0x2
    8020494a:	c1c080e7          	jalr	-996(ra) # 80206562 <hal_block_rw>
}
    8020494e:	60e2                	ld	ra,24(sp)
    80204950:	6442                	ld	s0,16(sp)
    80204952:	64a2                	ld	s1,8(sp)
    80204954:	6105                	addi	sp,sp,32
    80204956:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("bwrite: buf not locked");
    80204958:	00003517          	auipc	a0,0x3
    8020495c:	06050513          	addi	a0,a0,96 # 802079b8 <etext+0x9b8>
    80204960:	ffffc097          	auipc	ra,0xffffc
    80204964:	c9e080e7          	jalr	-866(ra) # 802005fe <panic>

0000000080204968 <brelse>:

void brelse(struct buf *b)
{
    80204968:	1101                	addi	sp,sp,-32
    8020496a:	ec06                	sd	ra,24(sp)
    8020496c:	e822                	sd	s0,16(sp)
    8020496e:	e426                	sd	s1,8(sp)
    80204970:	e04a                	sd	s2,0(sp)
    80204972:	1000                	addi	s0,sp,32
    80204974:	84aa                	mv	s1,a0
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    80204976:	01050913          	addi	s2,a0,16
    8020497a:	854a                	mv	a0,s2
    8020497c:	ffffd097          	auipc	ra,0xffffd
    80204980:	b88080e7          	jalr	-1144(ra) # 80201504 <holdingsleep>
    80204984:	c925                	beqz	a0,802049f4 <brelse+0x8c>
    releasesleep(&b->lock);
    80204986:	854a                	mv	a0,s2
    80204988:	ffffd097          	auipc	ra,0xffffd
    8020498c:	b38080e7          	jalr	-1224(ra) # 802014c0 <releasesleep>

    acquire(&bcache.lock);
    80204990:	0012c517          	auipc	a0,0x12c
    80204994:	13050513          	addi	a0,a0,304 # 80330ac0 <bcache>
    80204998:	ffffd097          	auipc	ra,0xffffd
    8020499c:	99c080e7          	jalr	-1636(ra) # 80201334 <acquire>
    b->refcnt--;
    802049a0:	40bc                	lw	a5,64(s1)
    802049a2:	37fd                	addiw	a5,a5,-1
    802049a4:	0007871b          	sext.w	a4,a5
    802049a8:	c0bc                	sw	a5,64(s1)
    if (b->refcnt == 0) {
    802049aa:	e71d                	bnez	a4,802049d8 <brelse+0x70>
        /* Move to the front: most recently used. */
        b->next->prev = b->prev;
    802049ac:	68b8                	ld	a4,80(s1)
    802049ae:	64bc                	ld	a5,72(s1)
    802049b0:	e73c                	sd	a5,72(a4)
        b->prev->next = b->next;
    802049b2:	68b8                	ld	a4,80(s1)
    802049b4:	ebb8                	sd	a4,80(a5)
        b->next = bcache.head.next;
    802049b6:	00134797          	auipc	a5,0x134
    802049ba:	10a78793          	addi	a5,a5,266 # 80338ac0 <bcache+0x8000>
    802049be:	2b87b703          	ld	a4,696(a5)
    802049c2:	e8b8                	sd	a4,80(s1)
        b->prev = &bcache.head;
    802049c4:	00134717          	auipc	a4,0x134
    802049c8:	36470713          	addi	a4,a4,868 # 80338d28 <bcache+0x8268>
    802049cc:	e4b8                	sd	a4,72(s1)
        bcache.head.next->prev = b;
    802049ce:	2b87b703          	ld	a4,696(a5)
    802049d2:	e724                	sd	s1,72(a4)
        bcache.head.next = b;
    802049d4:	2a97bc23          	sd	s1,696(a5)
    }
    release(&bcache.lock);
    802049d8:	0012c517          	auipc	a0,0x12c
    802049dc:	0e850513          	addi	a0,a0,232 # 80330ac0 <bcache>
    802049e0:	ffffd097          	auipc	ra,0xffffd
    802049e4:	a08080e7          	jalr	-1528(ra) # 802013e8 <release>
}
    802049e8:	60e2                	ld	ra,24(sp)
    802049ea:	6442                	ld	s0,16(sp)
    802049ec:	64a2                	ld	s1,8(sp)
    802049ee:	6902                	ld	s2,0(sp)
    802049f0:	6105                	addi	sp,sp,32
    802049f2:	8082                	ret
    if (!holdingsleep(&b->lock)) panic("brelse: buf not locked");
    802049f4:	00003517          	auipc	a0,0x3
    802049f8:	fdc50513          	addi	a0,a0,-36 # 802079d0 <etext+0x9d0>
    802049fc:	ffffc097          	auipc	ra,0xffffc
    80204a00:	c02080e7          	jalr	-1022(ra) # 802005fe <panic>

0000000080204a04 <bfree>:
    printf("luitfs: out of data blocks\n");
    return 0;
}

static void bfree(int dev, uint32 b)
{
    80204a04:	1101                	addi	sp,sp,-32
    80204a06:	ec06                	sd	ra,24(sp)
    80204a08:	e822                	sd	s0,16(sp)
    80204a0a:	e426                	sd	s1,8(sp)
    80204a0c:	e04a                	sd	s2,0(sp)
    80204a0e:	1000                	addi	s0,sp,32
    80204a10:	84ae                	mv	s1,a1
    struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204a12:	00d5d59b          	srliw	a1,a1,0xd
    80204a16:	00134797          	auipc	a5,0x134
    80204a1a:	7827a783          	lw	a5,1922(a5) # 80339198 <sb+0x18>
    80204a1e:	9dbd                	addw	a1,a1,a5
    80204a20:	00000097          	auipc	ra,0x0
    80204a24:	e18080e7          	jalr	-488(ra) # 80204838 <bread>
    uint32 bi = b % BPB;
    int m = 1 << (bi % 8);
    80204a28:	0074f713          	andi	a4,s1,7
    80204a2c:	4785                	li	a5,1
    80204a2e:	00e797bb          	sllw	a5,a5,a4
    uint32 bi = b % BPB;
    80204a32:	14ce                	slli	s1,s1,0x33
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80204a34:	0364d713          	srli	a4,s1,0x36
    80204a38:	00e504b3          	add	s1,a0,a4
    80204a3c:	0584c683          	lbu	a3,88(s1)
    80204a40:	00d7f633          	and	a2,a5,a3
    80204a44:	ca0d                	beqz	a2,80204a76 <bfree+0x72>
    80204a46:	892a                	mv	s2,a0
    bp->data[bi / 8] &= ~m;
    80204a48:	1702                	slli	a4,a4,0x20
    80204a4a:	9301                	srli	a4,a4,0x20
    80204a4c:	972a                	add	a4,a4,a0
    80204a4e:	fff7c793          	not	a5,a5
    80204a52:	8efd                	and	a3,a3,a5
    80204a54:	04d70c23          	sb	a3,88(a4)
    bwrite(bp);
    80204a58:	00000097          	auipc	ra,0x0
    80204a5c:	ed2080e7          	jalr	-302(ra) # 8020492a <bwrite>
    brelse(bp);
    80204a60:	854a                	mv	a0,s2
    80204a62:	00000097          	auipc	ra,0x0
    80204a66:	f06080e7          	jalr	-250(ra) # 80204968 <brelse>
}
    80204a6a:	60e2                	ld	ra,24(sp)
    80204a6c:	6442                	ld	s0,16(sp)
    80204a6e:	64a2                	ld	s1,8(sp)
    80204a70:	6902                	ld	s2,0(sp)
    80204a72:	6105                	addi	sp,sp,32
    80204a74:	8082                	ret
    if ((bp->data[bi / 8] & m) == 0) panic("bfree: freeing a free block");
    80204a76:	00003517          	auipc	a0,0x3
    80204a7a:	f7250513          	addi	a0,a0,-142 # 802079e8 <etext+0x9e8>
    80204a7e:	ffffc097          	auipc	ra,0xffffc
    80204a82:	b80080e7          	jalr	-1152(ra) # 802005fe <panic>

0000000080204a86 <balloc>:
{
    80204a86:	711d                	addi	sp,sp,-96
    80204a88:	ec86                	sd	ra,88(sp)
    80204a8a:	e8a2                	sd	s0,80(sp)
    80204a8c:	e4a6                	sd	s1,72(sp)
    80204a8e:	1080                	addi	s0,sp,96
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80204a90:	00134797          	auipc	a5,0x134
    80204a94:	6f87a783          	lw	a5,1784(a5) # 80339188 <sb+0x8>
    80204a98:	10078463          	beqz	a5,80204ba0 <balloc+0x11a>
    80204a9c:	e0ca                	sd	s2,64(sp)
    80204a9e:	fc4e                	sd	s3,56(sp)
    80204aa0:	f852                	sd	s4,48(sp)
    80204aa2:	f456                	sd	s5,40(sp)
    80204aa4:	f05a                	sd	s6,32(sp)
    80204aa6:	ec5e                	sd	s7,24(sp)
    80204aa8:	e862                	sd	s8,16(sp)
    80204aaa:	e466                	sd	s9,8(sp)
    80204aac:	8baa                	mv	s7,a0
    80204aae:	4a81                	li	s5,0
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204ab0:	00134b17          	auipc	s6,0x134
    80204ab4:	6d0b0b13          	addi	s6,s6,1744 # 80339180 <sb>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204ab8:	4c01                	li	s8,0
            int m = 1 << (bi % 8);
    80204aba:	4985                	li	s3,1
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204abc:	6a09                	lui	s4,0x2
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80204abe:	6c89                	lui	s9,0x2
    80204ac0:	a061                	j	80204b48 <balloc+0xc2>
                bp->data[bi / 8] |= m;              /* claim it... */
    80204ac2:	1582                	slli	a1,a1,0x20
    80204ac4:	9181                	srli	a1,a1,0x20
    80204ac6:	95ca                	add	a1,a1,s2
    80204ac8:	8ed9                	or	a3,a3,a4
    80204aca:	04d58c23          	sb	a3,88(a1)
                bwrite(bp);                         /* ...ON DISK, before use */
    80204ace:	854a                	mv	a0,s2
    80204ad0:	00000097          	auipc	ra,0x0
    80204ad4:	e5a080e7          	jalr	-422(ra) # 8020492a <bwrite>
                brelse(bp);
    80204ad8:	854a                	mv	a0,s2
    80204ada:	00000097          	auipc	ra,0x0
    80204ade:	e8e080e7          	jalr	-370(ra) # 80204968 <brelse>
    struct buf *bp = bread(dev, bno);
    80204ae2:	85a6                	mv	a1,s1
    80204ae4:	855e                	mv	a0,s7
    80204ae6:	00000097          	auipc	ra,0x0
    80204aea:	d52080e7          	jalr	-686(ra) # 80204838 <bread>
    80204aee:	892a                	mv	s2,a0
    memset(bp->data, 0, BSIZE);
    80204af0:	40000613          	li	a2,1024
    80204af4:	4581                	li	a1,0
    80204af6:	05850513          	addi	a0,a0,88
    80204afa:	ffffc097          	auipc	ra,0xffffc
    80204afe:	baa080e7          	jalr	-1110(ra) # 802006a4 <memset>
    bwrite(bp);
    80204b02:	854a                	mv	a0,s2
    80204b04:	00000097          	auipc	ra,0x0
    80204b08:	e26080e7          	jalr	-474(ra) # 8020492a <bwrite>
    brelse(bp);
    80204b0c:	854a                	mv	a0,s2
    80204b0e:	00000097          	auipc	ra,0x0
    80204b12:	e5a080e7          	jalr	-422(ra) # 80204968 <brelse>
}
    80204b16:	6906                	ld	s2,64(sp)
    80204b18:	79e2                	ld	s3,56(sp)
    80204b1a:	7a42                	ld	s4,48(sp)
    80204b1c:	7aa2                	ld	s5,40(sp)
    80204b1e:	7b02                	ld	s6,32(sp)
    80204b20:	6be2                	ld	s7,24(sp)
    80204b22:	6c42                	ld	s8,16(sp)
    80204b24:	6ca2                	ld	s9,8(sp)
}
    80204b26:	8526                	mv	a0,s1
    80204b28:	60e6                	ld	ra,88(sp)
    80204b2a:	6446                	ld	s0,80(sp)
    80204b2c:	64a6                	ld	s1,72(sp)
    80204b2e:	6125                	addi	sp,sp,96
    80204b30:	8082                	ret
        brelse(bp);
    80204b32:	854a                	mv	a0,s2
    80204b34:	00000097          	auipc	ra,0x0
    80204b38:	e34080e7          	jalr	-460(ra) # 80204968 <brelse>
    for (uint32 b = 0; b < sb.size; b += BPB) {
    80204b3c:	015c8abb          	addw	s5,s9,s5
    80204b40:	008b2783          	lw	a5,8(s6)
    80204b44:	04faf663          	bgeu	s5,a5,80204b90 <balloc+0x10a>
        struct buf *bp = bread(dev, DBBLOCK(b, sb));
    80204b48:	00dad59b          	srliw	a1,s5,0xd
    80204b4c:	018b2783          	lw	a5,24(s6)
    80204b50:	9dbd                	addw	a1,a1,a5
    80204b52:	855e                	mv	a0,s7
    80204b54:	00000097          	auipc	ra,0x0
    80204b58:	ce4080e7          	jalr	-796(ra) # 80204838 <bread>
    80204b5c:	892a                	mv	s2,a0
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204b5e:	008b2503          	lw	a0,8(s6)
    80204b62:	84d6                	mv	s1,s5
    80204b64:	87e2                	mv	a5,s8
    80204b66:	fca4f6e3          	bgeu	s1,a0,80204b32 <balloc+0xac>
            int m = 1 << (bi % 8);
    80204b6a:	0077f713          	andi	a4,a5,7
    80204b6e:	00e9973b          	sllw	a4,s3,a4
            if ((bp->data[bi / 8] & m) == 0) {
    80204b72:	0037d59b          	srliw	a1,a5,0x3
    80204b76:	0037d69b          	srliw	a3,a5,0x3
    80204b7a:	96ca                	add	a3,a3,s2
    80204b7c:	0586c683          	lbu	a3,88(a3)
    80204b80:	00d77633          	and	a2,a4,a3
    80204b84:	de1d                	beqz	a2,80204ac2 <balloc+0x3c>
        for (uint32 bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80204b86:	2785                	addiw	a5,a5,1
    80204b88:	2485                	addiw	s1,s1,1
    80204b8a:	fd479ee3          	bne	a5,s4,80204b66 <balloc+0xe0>
    80204b8e:	b755                	j	80204b32 <balloc+0xac>
    80204b90:	6906                	ld	s2,64(sp)
    80204b92:	79e2                	ld	s3,56(sp)
    80204b94:	7a42                	ld	s4,48(sp)
    80204b96:	7aa2                	ld	s5,40(sp)
    80204b98:	7b02                	ld	s6,32(sp)
    80204b9a:	6be2                	ld	s7,24(sp)
    80204b9c:	6c42                	ld	s8,16(sp)
    80204b9e:	6ca2                	ld	s9,8(sp)
    printf("luitfs: out of data blocks\n");
    80204ba0:	00003517          	auipc	a0,0x3
    80204ba4:	e6850513          	addi	a0,a0,-408 # 80207a08 <etext+0xa08>
    80204ba8:	ffffb097          	auipc	ra,0xffffb
    80204bac:	7e4080e7          	jalr	2020(ra) # 8020038c <printf>
    return 0;
    80204bb0:	4481                	li	s1,0
    80204bb2:	bf95                	j	80204b26 <balloc+0xa0>

0000000080204bb4 <bmap>:
/* ---------- block mapping ---------- */

/* Return the disk block holding byte-offset block `bn` of ip, allocating it
 * (and the indirect block) on demand. 0 = out of space. Caller holds ip->lock. */
static uint32 bmap(struct inode *ip, uint32 bn)
{
    80204bb4:	7179                	addi	sp,sp,-48
    80204bb6:	f406                	sd	ra,40(sp)
    80204bb8:	f022                	sd	s0,32(sp)
    80204bba:	ec26                	sd	s1,24(sp)
    80204bbc:	e84a                	sd	s2,16(sp)
    80204bbe:	e44e                	sd	s3,8(sp)
    80204bc0:	1800                	addi	s0,sp,48
    80204bc2:	89aa                	mv	s3,a0
    if (bn < NDIRECT) {
    80204bc4:	47ad                	li	a5,11
    80204bc6:	02b7e863          	bltu	a5,a1,80204bf6 <bmap+0x42>
        uint32 addr = ip->addrs[bn];
    80204bca:	02059793          	slli	a5,a1,0x20
    80204bce:	01e7d593          	srli	a1,a5,0x1e
    80204bd2:	00b504b3          	add	s1,a0,a1
    80204bd6:	0504a903          	lw	s2,80(s1)
        if (addr == 0) {
    80204bda:	08091263          	bnez	s2,80204c5e <bmap+0xaa>
            addr = balloc(ip->dev);
    80204bde:	4108                	lw	a0,0(a0)
    80204be0:	00000097          	auipc	ra,0x0
    80204be4:	ea6080e7          	jalr	-346(ra) # 80204a86 <balloc>
    80204be8:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80204bec:	06090963          	beqz	s2,80204c5e <bmap+0xaa>
            ip->addrs[bn] = addr;
    80204bf0:	0524a823          	sw	s2,80(s1)
    80204bf4:	a0ad                	j	80204c5e <bmap+0xaa>
        }
        return addr;
    }
    bn -= NDIRECT;
    80204bf6:	ff45849b          	addiw	s1,a1,-12
    80204bfa:	0004871b          	sext.w	a4,s1
    if (bn < NINDIRECT) {
    80204bfe:	0ff00793          	li	a5,255
    80204c02:	08e7e863          	bltu	a5,a4,80204c92 <bmap+0xde>
        /* Lab 9 extends this function with a DOUBLE-indirect level. */
        uint32 addr = ip->addrs[NDIRECT];
    80204c06:	08052903          	lw	s2,128(a0)
        if (addr == 0) {
    80204c0a:	00091f63          	bnez	s2,80204c28 <bmap+0x74>
            addr = balloc(ip->dev);
    80204c0e:	4108                	lw	a0,0(a0)
    80204c10:	00000097          	auipc	ra,0x0
    80204c14:	e76080e7          	jalr	-394(ra) # 80204a86 <balloc>
    80204c18:	0005091b          	sext.w	s2,a0
            if (addr == 0) return 0;
    80204c1c:	04090163          	beqz	s2,80204c5e <bmap+0xaa>
    80204c20:	e052                	sd	s4,0(sp)
            ip->addrs[NDIRECT] = addr;
    80204c22:	0929a023          	sw	s2,128(s3)
    80204c26:	a011                	j	80204c2a <bmap+0x76>
    80204c28:	e052                	sd	s4,0(sp)
        }
        struct buf *bp = bread(ip->dev, addr);
    80204c2a:	85ca                	mv	a1,s2
    80204c2c:	0009a503          	lw	a0,0(s3)
    80204c30:	00000097          	auipc	ra,0x0
    80204c34:	c08080e7          	jalr	-1016(ra) # 80204838 <bread>
    80204c38:	8a2a                	mv	s4,a0
        uint32 *a = (uint32 *)bp->data;
    80204c3a:	05850793          	addi	a5,a0,88
        if ((addr = a[bn]) == 0) {
    80204c3e:	02049713          	slli	a4,s1,0x20
    80204c42:	01e75593          	srli	a1,a4,0x1e
    80204c46:	00b784b3          	add	s1,a5,a1
    80204c4a:	0004a903          	lw	s2,0(s1)
    80204c4e:	02090063          	beqz	s2,80204c6e <bmap+0xba>
            addr = balloc(ip->dev);
            if (addr) { a[bn] = addr; bwrite(bp); }
        }
        brelse(bp);
    80204c52:	8552                	mv	a0,s4
    80204c54:	00000097          	auipc	ra,0x0
    80204c58:	d14080e7          	jalr	-748(ra) # 80204968 <brelse>
        return addr;
    80204c5c:	6a02                	ld	s4,0(sp)
    }
    panic("bmap: block number beyond MAXFILE");
}
    80204c5e:	854a                	mv	a0,s2
    80204c60:	70a2                	ld	ra,40(sp)
    80204c62:	7402                	ld	s0,32(sp)
    80204c64:	64e2                	ld	s1,24(sp)
    80204c66:	6942                	ld	s2,16(sp)
    80204c68:	69a2                	ld	s3,8(sp)
    80204c6a:	6145                	addi	sp,sp,48
    80204c6c:	8082                	ret
            addr = balloc(ip->dev);
    80204c6e:	0009a503          	lw	a0,0(s3)
    80204c72:	00000097          	auipc	ra,0x0
    80204c76:	e14080e7          	jalr	-492(ra) # 80204a86 <balloc>
    80204c7a:	0005091b          	sext.w	s2,a0
            if (addr) { a[bn] = addr; bwrite(bp); }
    80204c7e:	fc090ae3          	beqz	s2,80204c52 <bmap+0x9e>
    80204c82:	0124a023          	sw	s2,0(s1)
    80204c86:	8552                	mv	a0,s4
    80204c88:	00000097          	auipc	ra,0x0
    80204c8c:	ca2080e7          	jalr	-862(ra) # 8020492a <bwrite>
    80204c90:	b7c9                	j	80204c52 <bmap+0x9e>
    80204c92:	e052                	sd	s4,0(sp)
    panic("bmap: block number beyond MAXFILE");
    80204c94:	00003517          	auipc	a0,0x3
    80204c98:	d9450513          	addi	a0,a0,-620 # 80207a28 <etext+0xa28>
    80204c9c:	ffffc097          	auipc	ra,0xffffc
    80204ca0:	962080e7          	jalr	-1694(ra) # 802005fe <panic>

0000000080204ca4 <iget>:
{
    80204ca4:	7179                	addi	sp,sp,-48
    80204ca6:	f406                	sd	ra,40(sp)
    80204ca8:	f022                	sd	s0,32(sp)
    80204caa:	ec26                	sd	s1,24(sp)
    80204cac:	e84a                	sd	s2,16(sp)
    80204cae:	e44e                	sd	s3,8(sp)
    80204cb0:	e052                	sd	s4,0(sp)
    80204cb2:	1800                	addi	s0,sp,48
    80204cb4:	89aa                	mv	s3,a0
    80204cb6:	8a2e                	mv	s4,a1
    acquire(&icache.lock);
    80204cb8:	00134517          	auipc	a0,0x134
    80204cbc:	4f050513          	addi	a0,a0,1264 # 803391a8 <icache>
    80204cc0:	ffffc097          	auipc	ra,0xffffc
    80204cc4:	674080e7          	jalr	1652(ra) # 80201334 <acquire>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204cc8:	00134497          	auipc	s1,0x134
    80204ccc:	4f848493          	addi	s1,s1,1272 # 803391c0 <icache+0x18>
    struct inode *empty = 0;
    80204cd0:	4901                	li	s2,0
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204cd2:	00136697          	auipc	a3,0x136
    80204cd6:	f7e68693          	addi	a3,a3,-130 # 8033ac50 <devsw>
    80204cda:	a039                	j	80204ce8 <iget+0x44>
        if (empty == 0 && ip->ref == 0)
    80204cdc:	02090b63          	beqz	s2,80204d12 <iget+0x6e>
    for (struct inode *ip = icache.inode; ip < icache.inode + NINODE; ip++) {
    80204ce0:	08848493          	addi	s1,s1,136
    80204ce4:	02d48a63          	beq	s1,a3,80204d18 <iget+0x74>
        if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80204ce8:	449c                	lw	a5,8(s1)
    80204cea:	fef059e3          	blez	a5,80204cdc <iget+0x38>
    80204cee:	4098                	lw	a4,0(s1)
    80204cf0:	ff3716e3          	bne	a4,s3,80204cdc <iget+0x38>
    80204cf4:	40d8                	lw	a4,4(s1)
    80204cf6:	ff4713e3          	bne	a4,s4,80204cdc <iget+0x38>
            ip->ref++;
    80204cfa:	2785                	addiw	a5,a5,1
    80204cfc:	c49c                	sw	a5,8(s1)
            release(&icache.lock);
    80204cfe:	00134517          	auipc	a0,0x134
    80204d02:	4aa50513          	addi	a0,a0,1194 # 803391a8 <icache>
    80204d06:	ffffc097          	auipc	ra,0xffffc
    80204d0a:	6e2080e7          	jalr	1762(ra) # 802013e8 <release>
            return ip;
    80204d0e:	8926                	mv	s2,s1
    80204d10:	a03d                	j	80204d3e <iget+0x9a>
        if (empty == 0 && ip->ref == 0)
    80204d12:	f7f9                	bnez	a5,80204ce0 <iget+0x3c>
            empty = ip;
    80204d14:	8926                	mv	s2,s1
    80204d16:	b7e9                	j	80204ce0 <iget+0x3c>
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80204d18:	02090c63          	beqz	s2,80204d50 <iget+0xac>
    ip->dev = dev; ip->inum = inum; ip->ref = 1; ip->valid = 0;
    80204d1c:	01392023          	sw	s3,0(s2)
    80204d20:	01492223          	sw	s4,4(s2)
    80204d24:	4785                	li	a5,1
    80204d26:	00f92423          	sw	a5,8(s2)
    80204d2a:	04092023          	sw	zero,64(s2)
    release(&icache.lock);
    80204d2e:	00134517          	auipc	a0,0x134
    80204d32:	47a50513          	addi	a0,a0,1146 # 803391a8 <icache>
    80204d36:	ffffc097          	auipc	ra,0xffffc
    80204d3a:	6b2080e7          	jalr	1714(ra) # 802013e8 <release>
}
    80204d3e:	854a                	mv	a0,s2
    80204d40:	70a2                	ld	ra,40(sp)
    80204d42:	7402                	ld	s0,32(sp)
    80204d44:	64e2                	ld	s1,24(sp)
    80204d46:	6942                	ld	s2,16(sp)
    80204d48:	69a2                	ld	s3,8(sp)
    80204d4a:	6a02                	ld	s4,0(sp)
    80204d4c:	6145                	addi	sp,sp,48
    80204d4e:	8082                	ret
    if (empty == 0) panic("iget: inode cache full - raise NINODE");
    80204d50:	00003517          	auipc	a0,0x3
    80204d54:	d0050513          	addi	a0,a0,-768 # 80207a50 <etext+0xa50>
    80204d58:	ffffc097          	auipc	ra,0xffffc
    80204d5c:	8a6080e7          	jalr	-1882(ra) # 802005fe <panic>

0000000080204d60 <fsinit>:
{
    80204d60:	1101                	addi	sp,sp,-32
    80204d62:	ec06                	sd	ra,24(sp)
    80204d64:	e822                	sd	s0,16(sp)
    80204d66:	e426                	sd	s1,8(sp)
    80204d68:	e04a                	sd	s2,0(sp)
    80204d6a:	1000                	addi	s0,sp,32
    struct buf *bp = bread(dev, 1);
    80204d6c:	4585                	li	a1,1
    80204d6e:	00000097          	auipc	ra,0x0
    80204d72:	aca080e7          	jalr	-1334(ra) # 80204838 <bread>
    80204d76:	84aa                	mv	s1,a0
    memmove(&sb, bp->data, sizeof(sb));
    80204d78:	00134917          	auipc	s2,0x134
    80204d7c:	40890913          	addi	s2,s2,1032 # 80339180 <sb>
    80204d80:	02800613          	li	a2,40
    80204d84:	05850593          	addi	a1,a0,88
    80204d88:	854a                	mv	a0,s2
    80204d8a:	ffffc097          	auipc	ra,0xffffc
    80204d8e:	936080e7          	jalr	-1738(ra) # 802006c0 <memmove>
    brelse(bp);
    80204d92:	8526                	mv	a0,s1
    80204d94:	00000097          	auipc	ra,0x0
    80204d98:	bd4080e7          	jalr	-1068(ra) # 80204968 <brelse>
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80204d9c:	00092703          	lw	a4,0(s2)
    80204da0:	4c5557b7          	lui	a5,0x4c555
    80204da4:	95478793          	addi	a5,a5,-1708 # 4c554954 <_entry-0x33cab6ac>
    80204da8:	02f71e63          	bne	a4,a5,80204de4 <fsinit+0x84>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80204dac:	00134717          	auipc	a4,0x134
    80204db0:	3d872703          	lw	a4,984(a4) # 80339184 <sb+0x4>
    80204db4:	4785                	li	a5,1
    80204db6:	02f71f63          	bne	a4,a5,80204df4 <fsinit+0x94>
    printf("luitfs: %d blocks, %d inodes, data at block %d\n",
    80204dba:	00134797          	auipc	a5,0x134
    80204dbe:	3c678793          	addi	a5,a5,966 # 80339180 <sb>
    80204dc2:	5394                	lw	a3,32(a5)
    80204dc4:	47d0                	lw	a2,12(a5)
    80204dc6:	478c                	lw	a1,8(a5)
    80204dc8:	00003517          	auipc	a0,0x3
    80204dcc:	cf850513          	addi	a0,a0,-776 # 80207ac0 <etext+0xac0>
    80204dd0:	ffffb097          	auipc	ra,0xffffb
    80204dd4:	5bc080e7          	jalr	1468(ra) # 8020038c <printf>
}
    80204dd8:	60e2                	ld	ra,24(sp)
    80204dda:	6442                	ld	s0,16(sp)
    80204ddc:	64a2                	ld	s1,8(sp)
    80204dde:	6902                	ld	s2,0(sp)
    80204de0:	6105                	addi	sp,sp,32
    80204de2:	8082                	ret
    if (sb.magic != LUITFS_MAGIC) panic("fsinit: not a LuitFS disk (bad magic)");
    80204de4:	00003517          	auipc	a0,0x3
    80204de8:	c9450513          	addi	a0,a0,-876 # 80207a78 <etext+0xa78>
    80204dec:	ffffc097          	auipc	ra,0xffffc
    80204df0:	812080e7          	jalr	-2030(ra) # 802005fe <panic>
    if (sb.version != LUITFS_VERSION) panic("fsinit: LuitFS version mismatch");
    80204df4:	00003517          	auipc	a0,0x3
    80204df8:	cac50513          	addi	a0,a0,-852 # 80207aa0 <etext+0xaa0>
    80204dfc:	ffffc097          	auipc	ra,0xffffc
    80204e00:	802080e7          	jalr	-2046(ra) # 802005fe <panic>

0000000080204e04 <iinit>:
{
    80204e04:	7179                	addi	sp,sp,-48
    80204e06:	f406                	sd	ra,40(sp)
    80204e08:	f022                	sd	s0,32(sp)
    80204e0a:	ec26                	sd	s1,24(sp)
    80204e0c:	e84a                	sd	s2,16(sp)
    80204e0e:	e44e                	sd	s3,8(sp)
    80204e10:	1800                	addi	s0,sp,48
    initlock(&icache.lock, "icache");
    80204e12:	00003597          	auipc	a1,0x3
    80204e16:	cde58593          	addi	a1,a1,-802 # 80207af0 <etext+0xaf0>
    80204e1a:	00134517          	auipc	a0,0x134
    80204e1e:	38e50513          	addi	a0,a0,910 # 803391a8 <icache>
    80204e22:	ffffc097          	auipc	ra,0xffffc
    80204e26:	496080e7          	jalr	1174(ra) # 802012b8 <initlock>
    for (int i = 0; i < NINODE; i++)
    80204e2a:	00134497          	auipc	s1,0x134
    80204e2e:	3a648493          	addi	s1,s1,934 # 803391d0 <icache+0x28>
    80204e32:	00136997          	auipc	s3,0x136
    80204e36:	e2e98993          	addi	s3,s3,-466 # 8033ac60 <devsw+0x10>
        initsleeplock(&icache.inode[i].lock, "inode");
    80204e3a:	00003917          	auipc	s2,0x3
    80204e3e:	cbe90913          	addi	s2,s2,-834 # 80207af8 <etext+0xaf8>
    80204e42:	85ca                	mv	a1,s2
    80204e44:	8526                	mv	a0,s1
    80204e46:	ffffc097          	auipc	ra,0xffffc
    80204e4a:	5ea080e7          	jalr	1514(ra) # 80201430 <initsleeplock>
    for (int i = 0; i < NINODE; i++)
    80204e4e:	08848493          	addi	s1,s1,136
    80204e52:	ff3498e3          	bne	s1,s3,80204e42 <iinit+0x3e>
}
    80204e56:	70a2                	ld	ra,40(sp)
    80204e58:	7402                	ld	s0,32(sp)
    80204e5a:	64e2                	ld	s1,24(sp)
    80204e5c:	6942                	ld	s2,16(sp)
    80204e5e:	69a2                	ld	s3,8(sp)
    80204e60:	6145                	addi	sp,sp,48
    80204e62:	8082                	ret

0000000080204e64 <ialloc>:
{
    80204e64:	715d                	addi	sp,sp,-80
    80204e66:	e486                	sd	ra,72(sp)
    80204e68:	e0a2                	sd	s0,64(sp)
    80204e6a:	0880                	addi	s0,sp,80
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80204e6c:	00134717          	auipc	a4,0x134
    80204e70:	32072703          	lw	a4,800(a4) # 8033918c <sb+0xc>
    80204e74:	4785                	li	a5,1
    80204e76:	06e7fe63          	bgeu	a5,a4,80204ef2 <ialloc+0x8e>
    80204e7a:	fc26                	sd	s1,56(sp)
    80204e7c:	f84a                	sd	s2,48(sp)
    80204e7e:	f44e                	sd	s3,40(sp)
    80204e80:	f052                	sd	s4,32(sp)
    80204e82:	ec56                	sd	s5,24(sp)
    80204e84:	e85a                	sd	s6,16(sp)
    80204e86:	e45e                	sd	s7,8(sp)
    80204e88:	8a2a                	mv	s4,a0
    80204e8a:	8bae                	mv	s7,a1
    80204e8c:	4485                	li	s1,1
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80204e8e:	00134997          	auipc	s3,0x134
    80204e92:	2f298993          	addi	s3,s3,754 # 80339180 <sb>
        int m = 1 << (bi % 8);
    80204e96:	4b05                	li	s6,1
        uint32 bi = i % BPB;
    80204e98:	6a89                	lui	s5,0x2
    80204e9a:	1afd                	addi	s5,s5,-1 # 1fff <_entry-0x801fe001>
        struct buf *bp = bread(dev, IBBLOCK(i, sb));
    80204e9c:	00d4d59b          	srliw	a1,s1,0xd
    80204ea0:	0149a783          	lw	a5,20(s3)
    80204ea4:	9dbd                	addw	a1,a1,a5
    80204ea6:	8552                	mv	a0,s4
    80204ea8:	00000097          	auipc	ra,0x0
    80204eac:	990080e7          	jalr	-1648(ra) # 80204838 <bread>
    80204eb0:	892a                	mv	s2,a0
        int m = 1 << (bi % 8);
    80204eb2:	0074f713          	andi	a4,s1,7
    80204eb6:	00eb173b          	sllw	a4,s6,a4
        uint32 bi = i % BPB;
    80204eba:	0154f7b3          	and	a5,s1,s5
        if ((bp->data[bi / 8] & m) == 0) {
    80204ebe:	0037d61b          	srliw	a2,a5,0x3
    80204ec2:	0037d79b          	srliw	a5,a5,0x3
    80204ec6:	97aa                	add	a5,a5,a0
    80204ec8:	0587c783          	lbu	a5,88(a5)
    80204ecc:	00f776b3          	and	a3,a4,a5
    80204ed0:	ce95                	beqz	a3,80204f0c <ialloc+0xa8>
        brelse(bp);
    80204ed2:	00000097          	auipc	ra,0x0
    80204ed6:	a96080e7          	jalr	-1386(ra) # 80204968 <brelse>
    for (uint32 i = ROOTINO; i < sb.ninodes; i += 1) {
    80204eda:	2485                	addiw	s1,s1,1
    80204edc:	00c9a783          	lw	a5,12(s3)
    80204ee0:	faf4eee3          	bltu	s1,a5,80204e9c <ialloc+0x38>
    80204ee4:	74e2                	ld	s1,56(sp)
    80204ee6:	7942                	ld	s2,48(sp)
    80204ee8:	79a2                	ld	s3,40(sp)
    80204eea:	7a02                	ld	s4,32(sp)
    80204eec:	6ae2                	ld	s5,24(sp)
    80204eee:	6b42                	ld	s6,16(sp)
    80204ef0:	6ba2                	ld	s7,8(sp)
    printf("luitfs: out of inodes\n");
    80204ef2:	00003517          	auipc	a0,0x3
    80204ef6:	c0e50513          	addi	a0,a0,-1010 # 80207b00 <etext+0xb00>
    80204efa:	ffffb097          	auipc	ra,0xffffb
    80204efe:	492080e7          	jalr	1170(ra) # 8020038c <printf>
    return 0;
    80204f02:	4501                	li	a0,0
}
    80204f04:	60a6                	ld	ra,72(sp)
    80204f06:	6406                	ld	s0,64(sp)
    80204f08:	6161                	addi	sp,sp,80
    80204f0a:	8082                	ret
            bp->data[bi / 8] |= m;
    80204f0c:	1602                	slli	a2,a2,0x20
    80204f0e:	9201                	srli	a2,a2,0x20
    80204f10:	962a                	add	a2,a2,a0
    80204f12:	8fd9                	or	a5,a5,a4
    80204f14:	04f60c23          	sb	a5,88(a2) # 1058 <_entry-0x801fefa8>
            bwrite(bp);
    80204f18:	00000097          	auipc	ra,0x0
    80204f1c:	a12080e7          	jalr	-1518(ra) # 8020492a <bwrite>
            brelse(bp);
    80204f20:	854a                	mv	a0,s2
    80204f22:	00000097          	auipc	ra,0x0
    80204f26:	a46080e7          	jalr	-1466(ra) # 80204968 <brelse>
            bp = bread(dev, IBLOCK(i, sb));
    80204f2a:	0044d59b          	srliw	a1,s1,0x4
    80204f2e:	00134797          	auipc	a5,0x134
    80204f32:	26e7a783          	lw	a5,622(a5) # 8033919c <sb+0x1c>
    80204f36:	9dbd                	addw	a1,a1,a5
    80204f38:	8552                	mv	a0,s4
    80204f3a:	00000097          	auipc	ra,0x0
    80204f3e:	8fe080e7          	jalr	-1794(ra) # 80204838 <bread>
    80204f42:	892a                	mv	s2,a0
            struct dinode *dip = (struct dinode *)bp->data + i % IPB;
    80204f44:	05850993          	addi	s3,a0,88
    80204f48:	00f4f793          	andi	a5,s1,15
    80204f4c:	079a                	slli	a5,a5,0x6
    80204f4e:	99be                	add	s3,s3,a5
            memset(dip, 0, sizeof(*dip));
    80204f50:	04000613          	li	a2,64
    80204f54:	4581                	li	a1,0
    80204f56:	854e                	mv	a0,s3
    80204f58:	ffffb097          	auipc	ra,0xffffb
    80204f5c:	74c080e7          	jalr	1868(ra) # 802006a4 <memset>
            dip->type = type;
    80204f60:	01799023          	sh	s7,0(s3)
            bwrite(bp);
    80204f64:	854a                	mv	a0,s2
    80204f66:	00000097          	auipc	ra,0x0
    80204f6a:	9c4080e7          	jalr	-1596(ra) # 8020492a <bwrite>
            brelse(bp);
    80204f6e:	854a                	mv	a0,s2
    80204f70:	00000097          	auipc	ra,0x0
    80204f74:	9f8080e7          	jalr	-1544(ra) # 80204968 <brelse>
            return iget(dev, i);
    80204f78:	85a6                	mv	a1,s1
    80204f7a:	8552                	mv	a0,s4
    80204f7c:	00000097          	auipc	ra,0x0
    80204f80:	d28080e7          	jalr	-728(ra) # 80204ca4 <iget>
    80204f84:	74e2                	ld	s1,56(sp)
    80204f86:	7942                	ld	s2,48(sp)
    80204f88:	79a2                	ld	s3,40(sp)
    80204f8a:	7a02                	ld	s4,32(sp)
    80204f8c:	6ae2                	ld	s5,24(sp)
    80204f8e:	6b42                	ld	s6,16(sp)
    80204f90:	6ba2                	ld	s7,8(sp)
    80204f92:	bf8d                	j	80204f04 <ialloc+0xa0>

0000000080204f94 <iupdate>:
{
    80204f94:	1101                	addi	sp,sp,-32
    80204f96:	ec06                	sd	ra,24(sp)
    80204f98:	e822                	sd	s0,16(sp)
    80204f9a:	e426                	sd	s1,8(sp)
    80204f9c:	e04a                	sd	s2,0(sp)
    80204f9e:	1000                	addi	s0,sp,32
    80204fa0:	84aa                	mv	s1,a0
    struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80204fa2:	415c                	lw	a5,4(a0)
    80204fa4:	0047d79b          	srliw	a5,a5,0x4
    80204fa8:	00134597          	auipc	a1,0x134
    80204fac:	1f45a583          	lw	a1,500(a1) # 8033919c <sb+0x1c>
    80204fb0:	9dbd                	addw	a1,a1,a5
    80204fb2:	4108                	lw	a0,0(a0)
    80204fb4:	00000097          	auipc	ra,0x0
    80204fb8:	884080e7          	jalr	-1916(ra) # 80204838 <bread>
    80204fbc:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    80204fbe:	05850793          	addi	a5,a0,88
    80204fc2:	40d8                	lw	a4,4(s1)
    80204fc4:	8b3d                	andi	a4,a4,15
    80204fc6:	071a                	slli	a4,a4,0x6
    80204fc8:	97ba                	add	a5,a5,a4
    dip->type  = ip->type;
    80204fca:	0444d703          	lhu	a4,68(s1)
    80204fce:	00e79023          	sh	a4,0(a5)
    dip->major = ip->major;
    80204fd2:	0464d703          	lhu	a4,70(s1)
    80204fd6:	00e79123          	sh	a4,2(a5)
    dip->minor = ip->minor;
    80204fda:	0484d703          	lhu	a4,72(s1)
    80204fde:	00e79223          	sh	a4,4(a5)
    dip->nlink = ip->nlink;
    80204fe2:	04a4d703          	lhu	a4,74(s1)
    80204fe6:	00e79323          	sh	a4,6(a5)
    dip->size  = ip->size;
    80204fea:	44f8                	lw	a4,76(s1)
    80204fec:	c798                	sw	a4,8(a5)
    memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80204fee:	03400613          	li	a2,52
    80204ff2:	05048593          	addi	a1,s1,80
    80204ff6:	00c78513          	addi	a0,a5,12
    80204ffa:	ffffb097          	auipc	ra,0xffffb
    80204ffe:	6c6080e7          	jalr	1734(ra) # 802006c0 <memmove>
    bwrite(bp);
    80205002:	854a                	mv	a0,s2
    80205004:	00000097          	auipc	ra,0x0
    80205008:	926080e7          	jalr	-1754(ra) # 8020492a <bwrite>
    brelse(bp);
    8020500c:	854a                	mv	a0,s2
    8020500e:	00000097          	auipc	ra,0x0
    80205012:	95a080e7          	jalr	-1702(ra) # 80204968 <brelse>
}
    80205016:	60e2                	ld	ra,24(sp)
    80205018:	6442                	ld	s0,16(sp)
    8020501a:	64a2                	ld	s1,8(sp)
    8020501c:	6902                	ld	s2,0(sp)
    8020501e:	6105                	addi	sp,sp,32
    80205020:	8082                	ret

0000000080205022 <idup>:
{
    80205022:	1101                	addi	sp,sp,-32
    80205024:	ec06                	sd	ra,24(sp)
    80205026:	e822                	sd	s0,16(sp)
    80205028:	e426                	sd	s1,8(sp)
    8020502a:	1000                	addi	s0,sp,32
    8020502c:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    8020502e:	00134517          	auipc	a0,0x134
    80205032:	17a50513          	addi	a0,a0,378 # 803391a8 <icache>
    80205036:	ffffc097          	auipc	ra,0xffffc
    8020503a:	2fe080e7          	jalr	766(ra) # 80201334 <acquire>
    ip->ref++;
    8020503e:	449c                	lw	a5,8(s1)
    80205040:	2785                	addiw	a5,a5,1
    80205042:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    80205044:	00134517          	auipc	a0,0x134
    80205048:	16450513          	addi	a0,a0,356 # 803391a8 <icache>
    8020504c:	ffffc097          	auipc	ra,0xffffc
    80205050:	39c080e7          	jalr	924(ra) # 802013e8 <release>
}
    80205054:	8526                	mv	a0,s1
    80205056:	60e2                	ld	ra,24(sp)
    80205058:	6442                	ld	s0,16(sp)
    8020505a:	64a2                	ld	s1,8(sp)
    8020505c:	6105                	addi	sp,sp,32
    8020505e:	8082                	ret

0000000080205060 <ilock>:
{
    80205060:	1101                	addi	sp,sp,-32
    80205062:	ec06                	sd	ra,24(sp)
    80205064:	e822                	sd	s0,16(sp)
    80205066:	e426                	sd	s1,8(sp)
    80205068:	1000                	addi	s0,sp,32
    if (ip == 0 || ip->ref < 1) panic("ilock");
    8020506a:	c10d                	beqz	a0,8020508c <ilock+0x2c>
    8020506c:	84aa                	mv	s1,a0
    8020506e:	451c                	lw	a5,8(a0)
    80205070:	00f05e63          	blez	a5,8020508c <ilock+0x2c>
    acquiresleep(&ip->lock);
    80205074:	0541                	addi	a0,a0,16
    80205076:	ffffc097          	auipc	ra,0xffffc
    8020507a:	3f4080e7          	jalr	1012(ra) # 8020146a <acquiresleep>
    if (!ip->valid) {
    8020507e:	40bc                	lw	a5,64(s1)
    80205080:	cf99                	beqz	a5,8020509e <ilock+0x3e>
}
    80205082:	60e2                	ld	ra,24(sp)
    80205084:	6442                	ld	s0,16(sp)
    80205086:	64a2                	ld	s1,8(sp)
    80205088:	6105                	addi	sp,sp,32
    8020508a:	8082                	ret
    8020508c:	e04a                	sd	s2,0(sp)
    if (ip == 0 || ip->ref < 1) panic("ilock");
    8020508e:	00003517          	auipc	a0,0x3
    80205092:	a8a50513          	addi	a0,a0,-1398 # 80207b18 <etext+0xb18>
    80205096:	ffffb097          	auipc	ra,0xffffb
    8020509a:	568080e7          	jalr	1384(ra) # 802005fe <panic>
    8020509e:	e04a                	sd	s2,0(sp)
        struct buf *bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    802050a0:	40dc                	lw	a5,4(s1)
    802050a2:	0047d79b          	srliw	a5,a5,0x4
    802050a6:	00134597          	auipc	a1,0x134
    802050aa:	0f65a583          	lw	a1,246(a1) # 8033919c <sb+0x1c>
    802050ae:	9dbd                	addw	a1,a1,a5
    802050b0:	4088                	lw	a0,0(s1)
    802050b2:	fffff097          	auipc	ra,0xfffff
    802050b6:	786080e7          	jalr	1926(ra) # 80204838 <bread>
    802050ba:	892a                	mv	s2,a0
        struct dinode *dip = (struct dinode *)bp->data + ip->inum % IPB;
    802050bc:	05850593          	addi	a1,a0,88
    802050c0:	40dc                	lw	a5,4(s1)
    802050c2:	8bbd                	andi	a5,a5,15
    802050c4:	079a                	slli	a5,a5,0x6
    802050c6:	95be                	add	a1,a1,a5
        ip->type  = dip->type;
    802050c8:	0005d783          	lhu	a5,0(a1)
    802050cc:	04f49223          	sh	a5,68(s1)
        ip->major = dip->major;
    802050d0:	0025d783          	lhu	a5,2(a1)
    802050d4:	04f49323          	sh	a5,70(s1)
        ip->minor = dip->minor;
    802050d8:	0045d783          	lhu	a5,4(a1)
    802050dc:	04f49423          	sh	a5,72(s1)
        ip->nlink = dip->nlink;
    802050e0:	0065d783          	lhu	a5,6(a1)
    802050e4:	04f49523          	sh	a5,74(s1)
        ip->size  = dip->size;
    802050e8:	459c                	lw	a5,8(a1)
    802050ea:	c4fc                	sw	a5,76(s1)
        memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    802050ec:	03400613          	li	a2,52
    802050f0:	05b1                	addi	a1,a1,12
    802050f2:	05048513          	addi	a0,s1,80
    802050f6:	ffffb097          	auipc	ra,0xffffb
    802050fa:	5ca080e7          	jalr	1482(ra) # 802006c0 <memmove>
        brelse(bp);
    802050fe:	854a                	mv	a0,s2
    80205100:	00000097          	auipc	ra,0x0
    80205104:	868080e7          	jalr	-1944(ra) # 80204968 <brelse>
        ip->valid = 1;
    80205108:	4785                	li	a5,1
    8020510a:	c0bc                	sw	a5,64(s1)
        if (ip->type == 0) panic("ilock: inode has no type (bitmap out of sync)");
    8020510c:	0444d783          	lhu	a5,68(s1)
    80205110:	c399                	beqz	a5,80205116 <ilock+0xb6>
    80205112:	6902                	ld	s2,0(sp)
    80205114:	b7bd                	j	80205082 <ilock+0x22>
    80205116:	00003517          	auipc	a0,0x3
    8020511a:	a0a50513          	addi	a0,a0,-1526 # 80207b20 <etext+0xb20>
    8020511e:	ffffb097          	auipc	ra,0xffffb
    80205122:	4e0080e7          	jalr	1248(ra) # 802005fe <panic>

0000000080205126 <iunlock>:
{
    80205126:	1101                	addi	sp,sp,-32
    80205128:	ec06                	sd	ra,24(sp)
    8020512a:	e822                	sd	s0,16(sp)
    8020512c:	e426                	sd	s1,8(sp)
    8020512e:	e04a                	sd	s2,0(sp)
    80205130:	1000                	addi	s0,sp,32
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    80205132:	c905                	beqz	a0,80205162 <iunlock+0x3c>
    80205134:	84aa                	mv	s1,a0
    80205136:	01050913          	addi	s2,a0,16
    8020513a:	854a                	mv	a0,s2
    8020513c:	ffffc097          	auipc	ra,0xffffc
    80205140:	3c8080e7          	jalr	968(ra) # 80201504 <holdingsleep>
    80205144:	cd19                	beqz	a0,80205162 <iunlock+0x3c>
    80205146:	449c                	lw	a5,8(s1)
    80205148:	00f05d63          	blez	a5,80205162 <iunlock+0x3c>
    releasesleep(&ip->lock);
    8020514c:	854a                	mv	a0,s2
    8020514e:	ffffc097          	auipc	ra,0xffffc
    80205152:	372080e7          	jalr	882(ra) # 802014c0 <releasesleep>
}
    80205156:	60e2                	ld	ra,24(sp)
    80205158:	6442                	ld	s0,16(sp)
    8020515a:	64a2                	ld	s1,8(sp)
    8020515c:	6902                	ld	s2,0(sp)
    8020515e:	6105                	addi	sp,sp,32
    80205160:	8082                	ret
    if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1) panic("iunlock");
    80205162:	00003517          	auipc	a0,0x3
    80205166:	9ee50513          	addi	a0,a0,-1554 # 80207b50 <etext+0xb50>
    8020516a:	ffffb097          	auipc	ra,0xffffb
    8020516e:	494080e7          	jalr	1172(ra) # 802005fe <panic>

0000000080205172 <itrunc>:

/* Free all data blocks of ip and set size 0. Caller holds ip->lock. */
void itrunc(struct inode *ip)
{
    80205172:	7179                	addi	sp,sp,-48
    80205174:	f406                	sd	ra,40(sp)
    80205176:	f022                	sd	s0,32(sp)
    80205178:	ec26                	sd	s1,24(sp)
    8020517a:	e84a                	sd	s2,16(sp)
    8020517c:	e44e                	sd	s3,8(sp)
    8020517e:	1800                	addi	s0,sp,48
    80205180:	89aa                	mv	s3,a0
    for (int i = 0; i < NDIRECT; i++) {
    80205182:	05050493          	addi	s1,a0,80
    80205186:	08050913          	addi	s2,a0,128
    8020518a:	a021                	j	80205192 <itrunc+0x20>
    8020518c:	0491                	addi	s1,s1,4
    8020518e:	01248d63          	beq	s1,s2,802051a8 <itrunc+0x36>
        if (ip->addrs[i]) { bfree(ip->dev, ip->addrs[i]); ip->addrs[i] = 0; }
    80205192:	408c                	lw	a1,0(s1)
    80205194:	dde5                	beqz	a1,8020518c <itrunc+0x1a>
    80205196:	0009a503          	lw	a0,0(s3)
    8020519a:	00000097          	auipc	ra,0x0
    8020519e:	86a080e7          	jalr	-1942(ra) # 80204a04 <bfree>
    802051a2:	0004a023          	sw	zero,0(s1)
    802051a6:	b7dd                	j	8020518c <itrunc+0x1a>
    }
    if (ip->addrs[NDIRECT]) {
    802051a8:	0809a583          	lw	a1,128(s3)
    802051ac:	ed99                	bnez	a1,802051ca <itrunc+0x58>
            if (a[j]) bfree(ip->dev, a[j]);
        brelse(bp);
        bfree(ip->dev, ip->addrs[NDIRECT]);
        ip->addrs[NDIRECT] = 0;
    }
    ip->size = 0;
    802051ae:	0409a623          	sw	zero,76(s3)
    iupdate(ip);
    802051b2:	854e                	mv	a0,s3
    802051b4:	00000097          	auipc	ra,0x0
    802051b8:	de0080e7          	jalr	-544(ra) # 80204f94 <iupdate>
}
    802051bc:	70a2                	ld	ra,40(sp)
    802051be:	7402                	ld	s0,32(sp)
    802051c0:	64e2                	ld	s1,24(sp)
    802051c2:	6942                	ld	s2,16(sp)
    802051c4:	69a2                	ld	s3,8(sp)
    802051c6:	6145                	addi	sp,sp,48
    802051c8:	8082                	ret
    802051ca:	e052                	sd	s4,0(sp)
        struct buf *bp = bread(ip->dev, ip->addrs[NDIRECT]);
    802051cc:	0009a503          	lw	a0,0(s3)
    802051d0:	fffff097          	auipc	ra,0xfffff
    802051d4:	668080e7          	jalr	1640(ra) # 80204838 <bread>
    802051d8:	8a2a                	mv	s4,a0
        for (uint32 j = 0; j < NINDIRECT; j++)
    802051da:	05850493          	addi	s1,a0,88
    802051de:	45850913          	addi	s2,a0,1112
    802051e2:	a021                	j	802051ea <itrunc+0x78>
    802051e4:	0491                	addi	s1,s1,4
    802051e6:	01248b63          	beq	s1,s2,802051fc <itrunc+0x8a>
            if (a[j]) bfree(ip->dev, a[j]);
    802051ea:	408c                	lw	a1,0(s1)
    802051ec:	dde5                	beqz	a1,802051e4 <itrunc+0x72>
    802051ee:	0009a503          	lw	a0,0(s3)
    802051f2:	00000097          	auipc	ra,0x0
    802051f6:	812080e7          	jalr	-2030(ra) # 80204a04 <bfree>
    802051fa:	b7ed                	j	802051e4 <itrunc+0x72>
        brelse(bp);
    802051fc:	8552                	mv	a0,s4
    802051fe:	fffff097          	auipc	ra,0xfffff
    80205202:	76a080e7          	jalr	1898(ra) # 80204968 <brelse>
        bfree(ip->dev, ip->addrs[NDIRECT]);
    80205206:	0809a583          	lw	a1,128(s3)
    8020520a:	0009a503          	lw	a0,0(s3)
    8020520e:	fffff097          	auipc	ra,0xfffff
    80205212:	7f6080e7          	jalr	2038(ra) # 80204a04 <bfree>
        ip->addrs[NDIRECT] = 0;
    80205216:	0809a023          	sw	zero,128(s3)
    8020521a:	6a02                	ld	s4,0(sp)
    8020521c:	bf49                	j	802051ae <itrunc+0x3c>

000000008020521e <iput>:
{
    8020521e:	7179                	addi	sp,sp,-48
    80205220:	f406                	sd	ra,40(sp)
    80205222:	f022                	sd	s0,32(sp)
    80205224:	ec26                	sd	s1,24(sp)
    80205226:	1800                	addi	s0,sp,48
    80205228:	84aa                	mv	s1,a0
    acquire(&icache.lock);
    8020522a:	00134517          	auipc	a0,0x134
    8020522e:	f7e50513          	addi	a0,a0,-130 # 803391a8 <icache>
    80205232:	ffffc097          	auipc	ra,0xffffc
    80205236:	102080e7          	jalr	258(ra) # 80201334 <acquire>
    if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    8020523a:	4498                	lw	a4,8(s1)
    8020523c:	4785                	li	a5,1
    8020523e:	00f71763          	bne	a4,a5,8020524c <iput+0x2e>
    80205242:	40bc                	lw	a5,64(s1)
    80205244:	c781                	beqz	a5,8020524c <iput+0x2e>
    80205246:	04a4d783          	lhu	a5,74(s1)
    8020524a:	c38d                	beqz	a5,8020526c <iput+0x4e>
    ip->ref--;
    8020524c:	449c                	lw	a5,8(s1)
    8020524e:	37fd                	addiw	a5,a5,-1
    80205250:	c49c                	sw	a5,8(s1)
    release(&icache.lock);
    80205252:	00134517          	auipc	a0,0x134
    80205256:	f5650513          	addi	a0,a0,-170 # 803391a8 <icache>
    8020525a:	ffffc097          	auipc	ra,0xffffc
    8020525e:	18e080e7          	jalr	398(ra) # 802013e8 <release>
}
    80205262:	70a2                	ld	ra,40(sp)
    80205264:	7402                	ld	s0,32(sp)
    80205266:	64e2                	ld	s1,24(sp)
    80205268:	6145                	addi	sp,sp,48
    8020526a:	8082                	ret
    8020526c:	e84a                	sd	s2,16(sp)
    8020526e:	e44e                	sd	s3,8(sp)
        acquiresleep(&ip->lock);
    80205270:	01048993          	addi	s3,s1,16
    80205274:	854e                	mv	a0,s3
    80205276:	ffffc097          	auipc	ra,0xffffc
    8020527a:	1f4080e7          	jalr	500(ra) # 8020146a <acquiresleep>
        release(&icache.lock);
    8020527e:	00134517          	auipc	a0,0x134
    80205282:	f2a50513          	addi	a0,a0,-214 # 803391a8 <icache>
    80205286:	ffffc097          	auipc	ra,0xffffc
    8020528a:	162080e7          	jalr	354(ra) # 802013e8 <release>
        itrunc(ip);
    8020528e:	8526                	mv	a0,s1
    80205290:	00000097          	auipc	ra,0x0
    80205294:	ee2080e7          	jalr	-286(ra) # 80205172 <itrunc>
        ip->type = 0;
    80205298:	04049223          	sh	zero,68(s1)
        iupdate(ip);
    8020529c:	8526                	mv	a0,s1
    8020529e:	00000097          	auipc	ra,0x0
    802052a2:	cf6080e7          	jalr	-778(ra) # 80204f94 <iupdate>
        struct buf *bp = bread(ip->dev, IBBLOCK(ip->inum, sb));
    802052a6:	40dc                	lw	a5,4(s1)
    802052a8:	00d7d79b          	srliw	a5,a5,0xd
    802052ac:	00134597          	auipc	a1,0x134
    802052b0:	ee85a583          	lw	a1,-280(a1) # 80339194 <sb+0x14>
    802052b4:	9dbd                	addw	a1,a1,a5
    802052b6:	4088                	lw	a0,0(s1)
    802052b8:	fffff097          	auipc	ra,0xfffff
    802052bc:	580080e7          	jalr	1408(ra) # 80204838 <bread>
    802052c0:	892a                	mv	s2,a0
        uint32 bi = ip->inum % BPB;
    802052c2:	40d4                	lw	a3,4(s1)
    802052c4:	03369793          	slli	a5,a3,0x33
        if ((bp->data[bi / 8] & (1 << (bi % 8))) == 0)
    802052c8:	0367d713          	srli	a4,a5,0x36
    802052cc:	00e507b3          	add	a5,a0,a4
    802052d0:	0587c603          	lbu	a2,88(a5)
    802052d4:	8a9d                	andi	a3,a3,7
    802052d6:	40d657bb          	sraw	a5,a2,a3
    802052da:	8b85                	andi	a5,a5,1
    802052dc:	cba1                	beqz	a5,8020532c <iput+0x10e>
        bp->data[bi / 8] &= ~(1 << (bi % 8));
    802052de:	02071793          	slli	a5,a4,0x20
    802052e2:	9381                	srli	a5,a5,0x20
    802052e4:	97aa                	add	a5,a5,a0
    802052e6:	4705                	li	a4,1
    802052e8:	00d7173b          	sllw	a4,a4,a3
    802052ec:	fff74713          	not	a4,a4
    802052f0:	8e79                	and	a2,a2,a4
    802052f2:	04c78c23          	sb	a2,88(a5)
        bwrite(bp);
    802052f6:	fffff097          	auipc	ra,0xfffff
    802052fa:	634080e7          	jalr	1588(ra) # 8020492a <bwrite>
        brelse(bp);
    802052fe:	854a                	mv	a0,s2
    80205300:	fffff097          	auipc	ra,0xfffff
    80205304:	668080e7          	jalr	1640(ra) # 80204968 <brelse>
        ip->valid = 0;
    80205308:	0404a023          	sw	zero,64(s1)
        releasesleep(&ip->lock);
    8020530c:	854e                	mv	a0,s3
    8020530e:	ffffc097          	auipc	ra,0xffffc
    80205312:	1b2080e7          	jalr	434(ra) # 802014c0 <releasesleep>
        acquire(&icache.lock);
    80205316:	00134517          	auipc	a0,0x134
    8020531a:	e9250513          	addi	a0,a0,-366 # 803391a8 <icache>
    8020531e:	ffffc097          	auipc	ra,0xffffc
    80205322:	016080e7          	jalr	22(ra) # 80201334 <acquire>
    80205326:	6942                	ld	s2,16(sp)
    80205328:	69a2                	ld	s3,8(sp)
    8020532a:	b70d                	j	8020524c <iput+0x2e>
            panic("iput: inode bitmap already clear");
    8020532c:	00003517          	auipc	a0,0x3
    80205330:	82c50513          	addi	a0,a0,-2004 # 80207b58 <etext+0xb58>
    80205334:	ffffb097          	auipc	ra,0xffffb
    80205338:	2ca080e7          	jalr	714(ra) # 802005fe <panic>

000000008020533c <iunlockput>:
void iunlockput(struct inode *ip) { iunlock(ip); iput(ip); }
    8020533c:	1101                	addi	sp,sp,-32
    8020533e:	ec06                	sd	ra,24(sp)
    80205340:	e822                	sd	s0,16(sp)
    80205342:	e426                	sd	s1,8(sp)
    80205344:	1000                	addi	s0,sp,32
    80205346:	84aa                	mv	s1,a0
    80205348:	00000097          	auipc	ra,0x0
    8020534c:	dde080e7          	jalr	-546(ra) # 80205126 <iunlock>
    80205350:	8526                	mv	a0,s1
    80205352:	00000097          	auipc	ra,0x0
    80205356:	ecc080e7          	jalr	-308(ra) # 8020521e <iput>
    8020535a:	60e2                	ld	ra,24(sp)
    8020535c:	6442                	ld	s0,16(sp)
    8020535e:	64a2                	ld	s1,8(sp)
    80205360:	6105                	addi	sp,sp,32
    80205362:	8082                	ret

0000000080205364 <stati>:

void stati(struct inode *ip, struct stat *st)
{
    80205364:	1141                	addi	sp,sp,-16
    80205366:	e422                	sd	s0,8(sp)
    80205368:	0800                	addi	s0,sp,16
    st->dev   = ip->dev;
    8020536a:	411c                	lw	a5,0(a0)
    8020536c:	c19c                	sw	a5,0(a1)
    st->ino   = ip->inum;
    8020536e:	415c                	lw	a5,4(a0)
    80205370:	c1dc                	sw	a5,4(a1)
    st->type  = ip->type;
    80205372:	04455783          	lhu	a5,68(a0)
    80205376:	00f59423          	sh	a5,8(a1)
    st->nlink = ip->nlink;
    8020537a:	04a55783          	lhu	a5,74(a0)
    8020537e:	00f59523          	sh	a5,10(a1)
    st->size  = ip->size;
    80205382:	04c56783          	lwu	a5,76(a0)
    80205386:	e99c                	sd	a5,16(a1)
}
    80205388:	6422                	ld	s0,8(sp)
    8020538a:	0141                	addi	sp,sp,16
    8020538c:	8082                	ret

000000008020538e <readi>:

/* Read n bytes at offset off into dst (user va if user_dst, else kernel).
 * Returns bytes read, or -1. Caller holds ip->lock. */
int readi(struct inode *ip, int user_dst, uint64 dst, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return 0;
    8020538e:	457c                	lw	a5,76(a0)
    80205390:	12d7e763          	bltu	a5,a3,802054be <readi+0x130>
{
    80205394:	7159                	addi	sp,sp,-112
    80205396:	f486                	sd	ra,104(sp)
    80205398:	f0a2                	sd	s0,96(sp)
    8020539a:	eca6                	sd	s1,88(sp)
    8020539c:	e0d2                	sd	s4,64(sp)
    8020539e:	f45e                	sd	s7,40(sp)
    802053a0:	f062                	sd	s8,32(sp)
    802053a2:	ec66                	sd	s9,24(sp)
    802053a4:	1880                	addi	s0,sp,112
    802053a6:	8c2a                	mv	s8,a0
    802053a8:	8cae                	mv	s9,a1
    802053aa:	8a32                	mv	s4,a2
    802053ac:	84b6                	mv	s1,a3
    802053ae:	8bba                	mv	s7,a4
    if (off > ip->size || off + n < off) return 0;
    802053b0:	9f35                	addw	a4,a4,a3
    802053b2:	4501                	li	a0,0
    802053b4:	0ed76c63          	bltu	a4,a3,802054ac <readi+0x11e>
    802053b8:	e4ce                	sd	s3,72(sp)
    if (off + n > ip->size) n = ip->size - off;
    802053ba:	00e7f463          	bgeu	a5,a4,802053c2 <readi+0x34>
    802053be:	40d78bbb          	subw	s7,a5,a3

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    802053c2:	0c0b8b63          	beqz	s7,80205498 <readi+0x10a>
    802053c6:	e8ca                	sd	s2,80(sp)
    802053c8:	fc56                	sd	s5,56(sp)
    802053ca:	f85a                	sd	s6,48(sp)
    802053cc:	e86a                	sd	s10,16(sp)
    802053ce:	e46e                	sd	s11,8(sp)
    802053d0:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    802053d2:	40000d13          	li	s10,1024
    802053d6:	a81d                	j	8020540c <readi+0x7e>
                brelse(bp);
                tot = -1;
                break;
            }
        } else {
            memmove((void *)dst, bp->data + off % BSIZE, m);
    802053d8:	05890593          	addi	a1,s2,88
    802053dc:	020a9613          	slli	a2,s5,0x20
    802053e0:	9201                	srli	a2,a2,0x20
    802053e2:	95da                	add	a1,a1,s6
    802053e4:	8552                	mv	a0,s4
    802053e6:	ffffb097          	auipc	ra,0xffffb
    802053ea:	2da080e7          	jalr	730(ra) # 802006c0 <memmove>
        }
        brelse(bp);
    802053ee:	854a                	mv	a0,s2
    802053f0:	fffff097          	auipc	ra,0xfffff
    802053f4:	578080e7          	jalr	1400(ra) # 80204968 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    802053f8:	013d89bb          	addw	s3,s11,s3
    802053fc:	009d84bb          	addw	s1,s11,s1
    80205400:	1d82                	slli	s11,s11,0x20
    80205402:	020ddd93          	srli	s11,s11,0x20
    80205406:	9a6e                	add	s4,s4,s11
    80205408:	0979f263          	bgeu	s3,s7,8020548c <readi+0xfe>
        uint32 addr = bmap(ip, off / BSIZE);
    8020540c:	00a4d59b          	srliw	a1,s1,0xa
    80205410:	8562                	mv	a0,s8
    80205412:	fffff097          	auipc	ra,0xfffff
    80205416:	7a2080e7          	jalr	1954(ra) # 80204bb4 <bmap>
    8020541a:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;
    8020541e:	cdbd                	beqz	a1,8020549c <readi+0x10e>
        struct buf *bp = bread(ip->dev, addr);
    80205420:	000c2503          	lw	a0,0(s8)
    80205424:	fffff097          	auipc	ra,0xfffff
    80205428:	414080e7          	jalr	1044(ra) # 80204838 <bread>
    8020542c:	892a                	mv	s2,a0
        m = BSIZE - off % BSIZE;
    8020542e:	3ff4fb13          	andi	s6,s1,1023
        if (m > n - tot) m = n - tot;
    80205432:	413b87bb          	subw	a5,s7,s3
        m = BSIZE - off % BSIZE;
    80205436:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    8020543a:	8abe                	mv	s5,a5
    8020543c:	2781                	sext.w	a5,a5
    8020543e:	0007069b          	sext.w	a3,a4
    80205442:	00f6f363          	bgeu	a3,a5,80205448 <readi+0xba>
    80205446:	8aba                	mv	s5,a4
    80205448:	000a8d9b          	sext.w	s11,s5
        if (user_dst) {
    8020544c:	f80c86e3          	beqz	s9,802053d8 <readi+0x4a>
            if (copyout(myproc()->pagetable, dst,
    80205450:	ffffc097          	auipc	ra,0xffffc
    80205454:	2ce080e7          	jalr	718(ra) # 8020171e <myproc>
                        (char *)bp->data + off % BSIZE, m) < 0) {
    80205458:	05890613          	addi	a2,s2,88
            if (copyout(myproc()->pagetable, dst,
    8020545c:	020a9693          	slli	a3,s5,0x20
    80205460:	9281                	srli	a3,a3,0x20
    80205462:	965a                	add	a2,a2,s6
    80205464:	85d2                	mv	a1,s4
    80205466:	6928                	ld	a0,80(a0)
    80205468:	ffffe097          	auipc	ra,0xffffe
    8020546c:	ae6080e7          	jalr	-1306(ra) # 80202f4e <copyout>
    80205470:	f6055fe3          	bgez	a0,802053ee <readi+0x60>
                brelse(bp);
    80205474:	854a                	mv	a0,s2
    80205476:	fffff097          	auipc	ra,0xfffff
    8020547a:	4f2080e7          	jalr	1266(ra) # 80204968 <brelse>
                tot = -1;
    8020547e:	59fd                	li	s3,-1
                break;
    80205480:	6946                	ld	s2,80(sp)
    80205482:	7ae2                	ld	s5,56(sp)
    80205484:	7b42                	ld	s6,48(sp)
    80205486:	6d42                	ld	s10,16(sp)
    80205488:	6da2                	ld	s11,8(sp)
    8020548a:	a831                	j	802054a6 <readi+0x118>
    8020548c:	6946                	ld	s2,80(sp)
    8020548e:	7ae2                	ld	s5,56(sp)
    80205490:	7b42                	ld	s6,48(sp)
    80205492:	6d42                	ld	s10,16(sp)
    80205494:	6da2                	ld	s11,8(sp)
    80205496:	a801                	j	802054a6 <readi+0x118>
    for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80205498:	89de                	mv	s3,s7
    8020549a:	a031                	j	802054a6 <readi+0x118>
    8020549c:	6946                	ld	s2,80(sp)
    8020549e:	7ae2                	ld	s5,56(sp)
    802054a0:	7b42                	ld	s6,48(sp)
    802054a2:	6d42                	ld	s10,16(sp)
    802054a4:	6da2                	ld	s11,8(sp)
    }
    return tot;
    802054a6:	0009851b          	sext.w	a0,s3
    802054aa:	69a6                	ld	s3,72(sp)
}
    802054ac:	70a6                	ld	ra,104(sp)
    802054ae:	7406                	ld	s0,96(sp)
    802054b0:	64e6                	ld	s1,88(sp)
    802054b2:	6a06                	ld	s4,64(sp)
    802054b4:	7ba2                	ld	s7,40(sp)
    802054b6:	7c02                	ld	s8,32(sp)
    802054b8:	6ce2                	ld	s9,24(sp)
    802054ba:	6165                	addi	sp,sp,112
    802054bc:	8082                	ret
    if (off > ip->size || off + n < off) return 0;
    802054be:	4501                	li	a0,0
}
    802054c0:	8082                	ret

00000000802054c2 <writei>:

/* Write n bytes at off from src. Grows the file if needed. Caller holds lock. */
int writei(struct inode *ip, int user_src, uint64 src, uint32 off, uint32 n)
{
    if (off > ip->size || off + n < off) return -1;
    802054c2:	457c                	lw	a5,76(a0)
    802054c4:	14d7e063          	bltu	a5,a3,80205604 <writei+0x142>
{
    802054c8:	7159                	addi	sp,sp,-112
    802054ca:	f486                	sd	ra,104(sp)
    802054cc:	f0a2                	sd	s0,96(sp)
    802054ce:	e8ca                	sd	s2,80(sp)
    802054d0:	fc56                	sd	s5,56(sp)
    802054d2:	f45e                	sd	s7,40(sp)
    802054d4:	f062                	sd	s8,32(sp)
    802054d6:	ec66                	sd	s9,24(sp)
    802054d8:	1880                	addi	s0,sp,112
    802054da:	8baa                	mv	s7,a0
    802054dc:	8cae                	mv	s9,a1
    802054de:	8ab2                	mv	s5,a2
    802054e0:	8936                	mv	s2,a3
    802054e2:	8c3a                	mv	s8,a4
    if (off > ip->size || off + n < off) return -1;
    802054e4:	00e687bb          	addw	a5,a3,a4
    802054e8:	12d7e063          	bltu	a5,a3,80205608 <writei+0x146>
    if (off + n > MAXFILE * BSIZE) return -1;
    802054ec:	00043737          	lui	a4,0x43
    802054f0:	10f76e63          	bltu	a4,a5,8020560c <writei+0x14a>
    802054f4:	e4ce                	sd	s3,72(sp)

    uint32 tot, m;
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    802054f6:	0e0c0f63          	beqz	s8,802055f4 <writei+0x132>
    802054fa:	eca6                	sd	s1,88(sp)
    802054fc:	e0d2                	sd	s4,64(sp)
    802054fe:	f85a                	sd	s6,48(sp)
    80205500:	e86a                	sd	s10,16(sp)
    80205502:	e46e                	sd	s11,8(sp)
    80205504:	4981                	li	s3,0
        uint32 addr = bmap(ip, off / BSIZE);
        if (addr == 0) break;                     /* disk full: partial write */
        struct buf *bp = bread(ip->dev, addr);
        m = BSIZE - off % BSIZE;
    80205506:	40000d13          	li	s10,1024
    8020550a:	a081                	j	8020554a <writei+0x88>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
                brelse(bp);
                break;
            }
        } else {
            memmove(bp->data + off % BSIZE, (void *)src, m);
    8020550c:	05848513          	addi	a0,s1,88
    80205510:	020a1613          	slli	a2,s4,0x20
    80205514:	9201                	srli	a2,a2,0x20
    80205516:	85d6                	mv	a1,s5
    80205518:	955a                	add	a0,a0,s6
    8020551a:	ffffb097          	auipc	ra,0xffffb
    8020551e:	1a6080e7          	jalr	422(ra) # 802006c0 <memmove>
        }
        bwrite(bp);
    80205522:	8526                	mv	a0,s1
    80205524:	fffff097          	auipc	ra,0xfffff
    80205528:	406080e7          	jalr	1030(ra) # 8020492a <bwrite>
        brelse(bp);
    8020552c:	8526                	mv	a0,s1
    8020552e:	fffff097          	auipc	ra,0xfffff
    80205532:	43a080e7          	jalr	1082(ra) # 80204968 <brelse>
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80205536:	013d89bb          	addw	s3,s11,s3
    8020553a:	012d893b          	addw	s2,s11,s2
    8020553e:	1d82                	slli	s11,s11,0x20
    80205540:	020ddd93          	srli	s11,s11,0x20
    80205544:	9aee                	add	s5,s5,s11
    80205546:	0789fb63          	bgeu	s3,s8,802055bc <writei+0xfa>
        uint32 addr = bmap(ip, off / BSIZE);
    8020554a:	00a9559b          	srliw	a1,s2,0xa
    8020554e:	855e                	mv	a0,s7
    80205550:	fffff097          	auipc	ra,0xfffff
    80205554:	664080e7          	jalr	1636(ra) # 80204bb4 <bmap>
    80205558:	0005059b          	sext.w	a1,a0
        if (addr == 0) break;                     /* disk full: partial write */
    8020555c:	c1a5                	beqz	a1,802055bc <writei+0xfa>
        struct buf *bp = bread(ip->dev, addr);
    8020555e:	000ba503          	lw	a0,0(s7)
    80205562:	fffff097          	auipc	ra,0xfffff
    80205566:	2d6080e7          	jalr	726(ra) # 80204838 <bread>
    8020556a:	84aa                	mv	s1,a0
        m = BSIZE - off % BSIZE;
    8020556c:	3ff97b13          	andi	s6,s2,1023
        if (m > n - tot) m = n - tot;
    80205570:	413c07bb          	subw	a5,s8,s3
        m = BSIZE - off % BSIZE;
    80205574:	416d073b          	subw	a4,s10,s6
        if (m > n - tot) m = n - tot;
    80205578:	8a3e                	mv	s4,a5
    8020557a:	2781                	sext.w	a5,a5
    8020557c:	0007069b          	sext.w	a3,a4
    80205580:	00f6f363          	bgeu	a3,a5,80205586 <writei+0xc4>
    80205584:	8a3a                	mv	s4,a4
    80205586:	000a0d9b          	sext.w	s11,s4
        if (user_src) {
    8020558a:	f80c81e3          	beqz	s9,8020550c <writei+0x4a>
            if (copyin(myproc()->pagetable,
    8020558e:	ffffc097          	auipc	ra,0xffffc
    80205592:	190080e7          	jalr	400(ra) # 8020171e <myproc>
                       (char *)bp->data + off % BSIZE, src, m) < 0) {
    80205596:	05848593          	addi	a1,s1,88
            if (copyin(myproc()->pagetable,
    8020559a:	020a1693          	slli	a3,s4,0x20
    8020559e:	9281                	srli	a3,a3,0x20
    802055a0:	8656                	mv	a2,s5
    802055a2:	95da                	add	a1,a1,s6
    802055a4:	6928                	ld	a0,80(a0)
    802055a6:	ffffe097          	auipc	ra,0xffffe
    802055aa:	a9c080e7          	jalr	-1380(ra) # 80203042 <copyin>
    802055ae:	f6055ae3          	bgez	a0,80205522 <writei+0x60>
                brelse(bp);
    802055b2:	8526                	mv	a0,s1
    802055b4:	fffff097          	auipc	ra,0xfffff
    802055b8:	3b4080e7          	jalr	948(ra) # 80204968 <brelse>
    }
    if (off > ip->size) ip->size = off;
    802055bc:	04cba783          	lw	a5,76(s7)
    802055c0:	0327fc63          	bgeu	a5,s2,802055f8 <writei+0x136>
    802055c4:	052ba623          	sw	s2,76(s7)
    802055c8:	64e6                	ld	s1,88(sp)
    802055ca:	6a06                	ld	s4,64(sp)
    802055cc:	7b42                	ld	s6,48(sp)
    802055ce:	6d42                	ld	s10,16(sp)
    802055d0:	6da2                	ld	s11,8(sp)
    iupdate(ip);                    /* size and any new addrs[] hit the disk */
    802055d2:	855e                	mv	a0,s7
    802055d4:	00000097          	auipc	ra,0x0
    802055d8:	9c0080e7          	jalr	-1600(ra) # 80204f94 <iupdate>
    return tot;
    802055dc:	0009851b          	sext.w	a0,s3
    802055e0:	69a6                	ld	s3,72(sp)
}
    802055e2:	70a6                	ld	ra,104(sp)
    802055e4:	7406                	ld	s0,96(sp)
    802055e6:	6946                	ld	s2,80(sp)
    802055e8:	7ae2                	ld	s5,56(sp)
    802055ea:	7ba2                	ld	s7,40(sp)
    802055ec:	7c02                	ld	s8,32(sp)
    802055ee:	6ce2                	ld	s9,24(sp)
    802055f0:	6165                	addi	sp,sp,112
    802055f2:	8082                	ret
    for (tot = 0; tot < n; tot += m, off += m, src += m) {
    802055f4:	89e2                	mv	s3,s8
    802055f6:	bff1                	j	802055d2 <writei+0x110>
    802055f8:	64e6                	ld	s1,88(sp)
    802055fa:	6a06                	ld	s4,64(sp)
    802055fc:	7b42                	ld	s6,48(sp)
    802055fe:	6d42                	ld	s10,16(sp)
    80205600:	6da2                	ld	s11,8(sp)
    80205602:	bfc1                	j	802055d2 <writei+0x110>
    if (off > ip->size || off + n < off) return -1;
    80205604:	557d                	li	a0,-1
}
    80205606:	8082                	ret
    if (off > ip->size || off + n < off) return -1;
    80205608:	557d                	li	a0,-1
    8020560a:	bfe1                	j	802055e2 <writei+0x120>
    if (off + n > MAXFILE * BSIZE) return -1;
    8020560c:	557d                	li	a0,-1
    8020560e:	bfd1                	j	802055e2 <writei+0x120>

0000000080205610 <namecmp>:

/* ---------- directories ---------- */

int namecmp(const char *s, const char *t) { return strncmp(s, t, DIRSIZ); }
    80205610:	1141                	addi	sp,sp,-16
    80205612:	e406                	sd	ra,8(sp)
    80205614:	e022                	sd	s0,0(sp)
    80205616:	0800                	addi	s0,sp,16
    80205618:	4671                	li	a2,28
    8020561a:	ffffb097          	auipc	ra,0xffffb
    8020561e:	116080e7          	jalr	278(ra) # 80200730 <strncmp>
    80205622:	60a2                	ld	ra,8(sp)
    80205624:	6402                	ld	s0,0(sp)
    80205626:	0141                	addi	sp,sp,16
    80205628:	8082                	ret

000000008020562a <dirlookup>:

/* Look up name in directory dp. Returns unlocked inode; *poff = entry offset. */
struct inode *dirlookup(struct inode *dp, char *name, uint32 *poff)
{
    8020562a:	715d                	addi	sp,sp,-80
    8020562c:	e486                	sd	ra,72(sp)
    8020562e:	e0a2                	sd	s0,64(sp)
    80205630:	fc26                	sd	s1,56(sp)
    80205632:	f84a                	sd	s2,48(sp)
    80205634:	f44e                	sd	s3,40(sp)
    80205636:	f052                	sd	s4,32(sp)
    80205638:	0880                	addi	s0,sp,80
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    8020563a:	04455703          	lhu	a4,68(a0)
    8020563e:	4785                	li	a5,1
    80205640:	00f71a63          	bne	a4,a5,80205654 <dirlookup+0x2a>
    80205644:	892a                	mv	s2,a0
    80205646:	89ae                	mv	s3,a1
    80205648:	8a32                	mv	s4,a2

    struct dirent de;
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    8020564a:	457c                	lw	a5,76(a0)
    8020564c:	4481                	li	s1,0
        if (namecmp(name, de.name) == 0) {
            if (poff) *poff = off;
            return iget(dp->dev, de.inum);
        }
    }
    return 0;
    8020564e:	4501                	li	a0,0
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80205650:	eb85                	bnez	a5,80205680 <dirlookup+0x56>
    80205652:	a8bd                	j	802056d0 <dirlookup+0xa6>
    if (dp->type != T_DIR) panic("dirlookup: not a directory");
    80205654:	00002517          	auipc	a0,0x2
    80205658:	52c50513          	addi	a0,a0,1324 # 80207b80 <etext+0xb80>
    8020565c:	ffffb097          	auipc	ra,0xffffb
    80205660:	fa2080e7          	jalr	-94(ra) # 802005fe <panic>
            panic("dirlookup: short directory read");
    80205664:	00002517          	auipc	a0,0x2
    80205668:	53c50513          	addi	a0,a0,1340 # 80207ba0 <etext+0xba0>
    8020566c:	ffffb097          	auipc	ra,0xffffb
    80205670:	f92080e7          	jalr	-110(ra) # 802005fe <panic>
    for (uint32 off = 0; off < dp->size; off += sizeof(de)) {
    80205674:	0204849b          	addiw	s1,s1,32
    80205678:	04c92783          	lw	a5,76(s2)
    8020567c:	04f4f963          	bgeu	s1,a5,802056ce <dirlookup+0xa4>
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205680:	02000713          	li	a4,32
    80205684:	86a6                	mv	a3,s1
    80205686:	fb040613          	addi	a2,s0,-80
    8020568a:	4581                	li	a1,0
    8020568c:	854a                	mv	a0,s2
    8020568e:	00000097          	auipc	ra,0x0
    80205692:	d00080e7          	jalr	-768(ra) # 8020538e <readi>
    80205696:	02000793          	li	a5,32
    8020569a:	fcf515e3          	bne	a0,a5,80205664 <dirlookup+0x3a>
        if (de.inum == 0) continue;
    8020569e:	fb042783          	lw	a5,-80(s0)
    802056a2:	dbe9                	beqz	a5,80205674 <dirlookup+0x4a>
        if (namecmp(name, de.name) == 0) {
    802056a4:	fb440593          	addi	a1,s0,-76
    802056a8:	854e                	mv	a0,s3
    802056aa:	00000097          	auipc	ra,0x0
    802056ae:	f66080e7          	jalr	-154(ra) # 80205610 <namecmp>
    802056b2:	f169                	bnez	a0,80205674 <dirlookup+0x4a>
            if (poff) *poff = off;
    802056b4:	000a0463          	beqz	s4,802056bc <dirlookup+0x92>
    802056b8:	009a2023          	sw	s1,0(s4) # 2000 <_entry-0x801fe000>
            return iget(dp->dev, de.inum);
    802056bc:	fb042583          	lw	a1,-80(s0)
    802056c0:	00092503          	lw	a0,0(s2)
    802056c4:	fffff097          	auipc	ra,0xfffff
    802056c8:	5e0080e7          	jalr	1504(ra) # 80204ca4 <iget>
    802056cc:	a011                	j	802056d0 <dirlookup+0xa6>
    return 0;
    802056ce:	4501                	li	a0,0
}
    802056d0:	60a6                	ld	ra,72(sp)
    802056d2:	6406                	ld	s0,64(sp)
    802056d4:	74e2                	ld	s1,56(sp)
    802056d6:	7942                	ld	s2,48(sp)
    802056d8:	79a2                	ld	s3,40(sp)
    802056da:	7a02                	ld	s4,32(sp)
    802056dc:	6161                	addi	sp,sp,80
    802056de:	8082                	ret

00000000802056e0 <namex>:
}

/* Walk path from / (or the cwd). If parent, stop one level early and copy the
 * final element into name. The RETURNED inode is unlocked and referenced. */
static struct inode *namex(char *path, int nameiparent_, char *name)
{
    802056e0:	711d                	addi	sp,sp,-96
    802056e2:	ec86                	sd	ra,88(sp)
    802056e4:	e8a2                	sd	s0,80(sp)
    802056e6:	e4a6                	sd	s1,72(sp)
    802056e8:	e0ca                	sd	s2,64(sp)
    802056ea:	fc4e                	sd	s3,56(sp)
    802056ec:	f852                	sd	s4,48(sp)
    802056ee:	f456                	sd	s5,40(sp)
    802056f0:	f05a                	sd	s6,32(sp)
    802056f2:	ec5e                	sd	s7,24(sp)
    802056f4:	e862                	sd	s8,16(sp)
    802056f6:	e466                	sd	s9,8(sp)
    802056f8:	1080                	addi	s0,sp,96
    802056fa:	84aa                	mv	s1,a0
    802056fc:	8b2e                	mv	s6,a1
    802056fe:	8ab2                	mv	s5,a2
    struct inode *ip;
    if (*path == '/')
    80205700:	00054703          	lbu	a4,0(a0)
    80205704:	02f00793          	li	a5,47
    80205708:	02f70263          	beq	a4,a5,8020572c <namex+0x4c>
        ip = iget(ROOTDEV, ROOTINO);
    else
        ip = idup(myproc()->cwd);
    8020570c:	ffffc097          	auipc	ra,0xffffc
    80205710:	012080e7          	jalr	18(ra) # 8020171e <myproc>
    80205714:	15053503          	ld	a0,336(a0)
    80205718:	00000097          	auipc	ra,0x0
    8020571c:	90a080e7          	jalr	-1782(ra) # 80205022 <idup>
    80205720:	8a2a                	mv	s4,a0
    while (*path == '/') path++;
    80205722:	02f00913          	li	s2,47
    if (len >= DIRSIZ) {
    80205726:	4c6d                	li	s8,27

    while ((path = skipelem(path, name)) != 0) {
        ilock(ip);
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    80205728:	4b85                	li	s7,1
    8020572a:	a865                	j	802057e2 <namex+0x102>
        ip = iget(ROOTDEV, ROOTINO);
    8020572c:	4585                	li	a1,1
    8020572e:	4501                	li	a0,0
    80205730:	fffff097          	auipc	ra,0xfffff
    80205734:	574080e7          	jalr	1396(ra) # 80204ca4 <iget>
    80205738:	8a2a                	mv	s4,a0
    8020573a:	b7e5                	j	80205722 <namex+0x42>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    8020573c:	8552                	mv	a0,s4
    8020573e:	00000097          	auipc	ra,0x0
    80205742:	bfe080e7          	jalr	-1026(ra) # 8020533c <iunlockput>
    80205746:	4a01                	li	s4,0
        iunlockput(ip);
        ip = next;
    }
    if (nameiparent_) { iput(ip); return 0; }
    return ip;
}
    80205748:	8552                	mv	a0,s4
    8020574a:	60e6                	ld	ra,88(sp)
    8020574c:	6446                	ld	s0,80(sp)
    8020574e:	64a6                	ld	s1,72(sp)
    80205750:	6906                	ld	s2,64(sp)
    80205752:	79e2                	ld	s3,56(sp)
    80205754:	7a42                	ld	s4,48(sp)
    80205756:	7aa2                	ld	s5,40(sp)
    80205758:	7b02                	ld	s6,32(sp)
    8020575a:	6be2                	ld	s7,24(sp)
    8020575c:	6c42                	ld	s8,16(sp)
    8020575e:	6ca2                	ld	s9,8(sp)
    80205760:	6125                	addi	sp,sp,96
    80205762:	8082                	ret
            iunlock(ip);                          /* stop at the parent */
    80205764:	8552                	mv	a0,s4
    80205766:	00000097          	auipc	ra,0x0
    8020576a:	9c0080e7          	jalr	-1600(ra) # 80205126 <iunlock>
            return ip;
    8020576e:	bfe9                	j	80205748 <namex+0x68>
        if (next == 0) { iunlockput(ip); return 0; }
    80205770:	8552                	mv	a0,s4
    80205772:	00000097          	auipc	ra,0x0
    80205776:	bca080e7          	jalr	-1078(ra) # 8020533c <iunlockput>
    8020577a:	8a4e                	mv	s4,s3
    8020577c:	b7f1                	j	80205748 <namex+0x68>
    int len = path - s;
    8020577e:	40998cbb          	subw	s9,s3,s1
    if (len >= DIRSIZ) {
    80205782:	099c5763          	bge	s8,s9,80205810 <namex+0x130>
        memmove(name, s, DIRSIZ);                 /* truncate long names */
    80205786:	4671                	li	a2,28
    80205788:	85a6                	mv	a1,s1
    8020578a:	8556                	mv	a0,s5
    8020578c:	ffffb097          	auipc	ra,0xffffb
    80205790:	f34080e7          	jalr	-204(ra) # 802006c0 <memmove>
    80205794:	84ce                	mv	s1,s3
    while (*path == '/') path++;
    80205796:	0004c783          	lbu	a5,0(s1)
    8020579a:	01279763          	bne	a5,s2,802057a8 <namex+0xc8>
    8020579e:	0485                	addi	s1,s1,1
    802057a0:	0004c783          	lbu	a5,0(s1)
    802057a4:	ff278de3          	beq	a5,s2,8020579e <namex+0xbe>
        ilock(ip);
    802057a8:	8552                	mv	a0,s4
    802057aa:	00000097          	auipc	ra,0x0
    802057ae:	8b6080e7          	jalr	-1866(ra) # 80205060 <ilock>
        if (ip->type != T_DIR) { iunlockput(ip); return 0; }
    802057b2:	044a5783          	lhu	a5,68(s4)
    802057b6:	f97793e3          	bne	a5,s7,8020573c <namex+0x5c>
        if (nameiparent_ && *path == '\0') {
    802057ba:	000b0563          	beqz	s6,802057c4 <namex+0xe4>
    802057be:	0004c783          	lbu	a5,0(s1)
    802057c2:	d3cd                	beqz	a5,80205764 <namex+0x84>
        struct inode *next = dirlookup(ip, name, 0);
    802057c4:	4601                	li	a2,0
    802057c6:	85d6                	mv	a1,s5
    802057c8:	8552                	mv	a0,s4
    802057ca:	00000097          	auipc	ra,0x0
    802057ce:	e60080e7          	jalr	-416(ra) # 8020562a <dirlookup>
    802057d2:	89aa                	mv	s3,a0
        if (next == 0) { iunlockput(ip); return 0; }
    802057d4:	dd51                	beqz	a0,80205770 <namex+0x90>
        iunlockput(ip);
    802057d6:	8552                	mv	a0,s4
    802057d8:	00000097          	auipc	ra,0x0
    802057dc:	b64080e7          	jalr	-1180(ra) # 8020533c <iunlockput>
        ip = next;
    802057e0:	8a4e                	mv	s4,s3
    while (*path == '/') path++;
    802057e2:	0004c783          	lbu	a5,0(s1)
    802057e6:	01279763          	bne	a5,s2,802057f4 <namex+0x114>
    802057ea:	0485                	addi	s1,s1,1
    802057ec:	0004c783          	lbu	a5,0(s1)
    802057f0:	ff278de3          	beq	a5,s2,802057ea <namex+0x10a>
    if (*path == 0) return 0;
    802057f4:	cb95                	beqz	a5,80205828 <namex+0x148>
    while (*path != '/' && *path != 0) path++;
    802057f6:	0004c783          	lbu	a5,0(s1)
    802057fa:	89a6                	mv	s3,s1
    int len = path - s;
    802057fc:	4c81                	li	s9,0
    while (*path != '/' && *path != 0) path++;
    802057fe:	01278963          	beq	a5,s2,80205810 <namex+0x130>
    80205802:	dfb5                	beqz	a5,8020577e <namex+0x9e>
    80205804:	0985                	addi	s3,s3,1
    80205806:	0009c783          	lbu	a5,0(s3)
    8020580a:	ff279ce3          	bne	a5,s2,80205802 <namex+0x122>
    8020580e:	bf85                	j	8020577e <namex+0x9e>
        memmove(name, s, len);
    80205810:	8666                	mv	a2,s9
    80205812:	85a6                	mv	a1,s1
    80205814:	8556                	mv	a0,s5
    80205816:	ffffb097          	auipc	ra,0xffffb
    8020581a:	eaa080e7          	jalr	-342(ra) # 802006c0 <memmove>
        name[len] = 0;
    8020581e:	9cd6                	add	s9,s9,s5
    80205820:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x801fe000>
    80205824:	84ce                	mv	s1,s3
    80205826:	bf85                	j	80205796 <namex+0xb6>
    if (nameiparent_) { iput(ip); return 0; }
    80205828:	f20b00e3          	beqz	s6,80205748 <namex+0x68>
    8020582c:	8552                	mv	a0,s4
    8020582e:	00000097          	auipc	ra,0x0
    80205832:	9f0080e7          	jalr	-1552(ra) # 8020521e <iput>
    80205836:	4a01                	li	s4,0
    80205838:	bf01                	j	80205748 <namex+0x68>

000000008020583a <dirlink>:
{
    8020583a:	715d                	addi	sp,sp,-80
    8020583c:	e486                	sd	ra,72(sp)
    8020583e:	e0a2                	sd	s0,64(sp)
    80205840:	f84a                	sd	s2,48(sp)
    80205842:	f44e                	sd	s3,40(sp)
    80205844:	f052                	sd	s4,32(sp)
    80205846:	0880                	addi	s0,sp,80
    80205848:	892a                	mv	s2,a0
    8020584a:	8a2e                	mv	s4,a1
    8020584c:	89b2                	mv	s3,a2
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    8020584e:	4601                	li	a2,0
    80205850:	00000097          	auipc	ra,0x0
    80205854:	dda080e7          	jalr	-550(ra) # 8020562a <dirlookup>
    80205858:	e141                	bnez	a0,802058d8 <dirlink+0x9e>
    8020585a:	fc26                	sd	s1,56(sp)
    for (off = 0; off < dp->size; off += sizeof(de)) {
    8020585c:	04c92483          	lw	s1,76(s2)
    80205860:	c895                	beqz	s1,80205894 <dirlink+0x5a>
    80205862:	4481                	li	s1,0
        if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80205864:	02000713          	li	a4,32
    80205868:	86a6                	mv	a3,s1
    8020586a:	fb040613          	addi	a2,s0,-80
    8020586e:	4581                	li	a1,0
    80205870:	854a                	mv	a0,s2
    80205872:	00000097          	auipc	ra,0x0
    80205876:	b1c080e7          	jalr	-1252(ra) # 8020538e <readi>
    8020587a:	02000793          	li	a5,32
    8020587e:	06f51363          	bne	a0,a5,802058e4 <dirlink+0xaa>
        if (de.inum == 0) break;                  /* reuse a freed slot */
    80205882:	fb042783          	lw	a5,-80(s0)
    80205886:	c799                	beqz	a5,80205894 <dirlink+0x5a>
    for (off = 0; off < dp->size; off += sizeof(de)) {
    80205888:	0204849b          	addiw	s1,s1,32
    8020588c:	04c92783          	lw	a5,76(s2)
    80205890:	fcf4eae3          	bltu	s1,a5,80205864 <dirlink+0x2a>
    strncpy(de.name, name, DIRSIZ);
    80205894:	4671                	li	a2,28
    80205896:	85d2                	mv	a1,s4
    80205898:	fb440513          	addi	a0,s0,-76
    8020589c:	ffffb097          	auipc	ra,0xffffb
    802058a0:	eca080e7          	jalr	-310(ra) # 80200766 <strncpy>
    de.inum = inum;
    802058a4:	fb342823          	sw	s3,-80(s0)
    if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    802058a8:	02000713          	li	a4,32
    802058ac:	86a6                	mv	a3,s1
    802058ae:	fb040613          	addi	a2,s0,-80
    802058b2:	4581                	li	a1,0
    802058b4:	854a                	mv	a0,s2
    802058b6:	00000097          	auipc	ra,0x0
    802058ba:	c0c080e7          	jalr	-1012(ra) # 802054c2 <writei>
    802058be:	1501                	addi	a0,a0,-32
    802058c0:	00a03533          	snez	a0,a0
    802058c4:	40a00533          	neg	a0,a0
    802058c8:	74e2                	ld	s1,56(sp)
}
    802058ca:	60a6                	ld	ra,72(sp)
    802058cc:	6406                	ld	s0,64(sp)
    802058ce:	7942                	ld	s2,48(sp)
    802058d0:	79a2                	ld	s3,40(sp)
    802058d2:	7a02                	ld	s4,32(sp)
    802058d4:	6161                	addi	sp,sp,80
    802058d6:	8082                	ret
    if ((ip = dirlookup(dp, name, 0)) != 0) { iput(ip); return -1; }
    802058d8:	00000097          	auipc	ra,0x0
    802058dc:	946080e7          	jalr	-1722(ra) # 8020521e <iput>
    802058e0:	557d                	li	a0,-1
    802058e2:	b7e5                	j	802058ca <dirlink+0x90>
            panic("dirlink: short directory read");
    802058e4:	00002517          	auipc	a0,0x2
    802058e8:	2dc50513          	addi	a0,a0,732 # 80207bc0 <etext+0xbc0>
    802058ec:	ffffb097          	auipc	ra,0xffffb
    802058f0:	d12080e7          	jalr	-750(ra) # 802005fe <panic>

00000000802058f4 <namei>:

struct inode *namei(char *path)
{
    802058f4:	7179                	addi	sp,sp,-48
    802058f6:	f406                	sd	ra,40(sp)
    802058f8:	f022                	sd	s0,32(sp)
    802058fa:	1800                	addi	s0,sp,48
    char name[DIRSIZ];
    return namex(path, 0, name);
    802058fc:	fd040613          	addi	a2,s0,-48
    80205900:	4581                	li	a1,0
    80205902:	00000097          	auipc	ra,0x0
    80205906:	dde080e7          	jalr	-546(ra) # 802056e0 <namex>
}
    8020590a:	70a2                	ld	ra,40(sp)
    8020590c:	7402                	ld	s0,32(sp)
    8020590e:	6145                	addi	sp,sp,48
    80205910:	8082                	ret

0000000080205912 <nameiparent>:

struct inode *nameiparent(char *path, char *name)
{
    80205912:	1141                	addi	sp,sp,-16
    80205914:	e406                	sd	ra,8(sp)
    80205916:	e022                	sd	s0,0(sp)
    80205918:	0800                	addi	s0,sp,16
    8020591a:	862e                	mv	a2,a1
    return namex(path, 1, name);
    8020591c:	4585                	li	a1,1
    8020591e:	00000097          	auipc	ra,0x0
    80205922:	dc2080e7          	jalr	-574(ra) # 802056e0 <namex>
}
    80205926:	60a2                	ld	ra,8(sp)
    80205928:	6402                	ld	s0,0(sp)
    8020592a:	0141                	addi	sp,sp,16
    8020592c:	8082                	ret

000000008020592e <fileinit>:
static struct {
    struct spinlock lock;
    struct file file[NFILE];
} ftable;

void fileinit(void) { initlock(&ftable.lock, "ftable"); }
    8020592e:	1141                	addi	sp,sp,-16
    80205930:	e406                	sd	ra,8(sp)
    80205932:	e022                	sd	s0,0(sp)
    80205934:	0800                	addi	s0,sp,16
    80205936:	00002597          	auipc	a1,0x2
    8020593a:	2aa58593          	addi	a1,a1,682 # 80207be0 <etext+0xbe0>
    8020593e:	00135517          	auipc	a0,0x135
    80205942:	3b250513          	addi	a0,a0,946 # 8033acf0 <ftable>
    80205946:	ffffc097          	auipc	ra,0xffffc
    8020594a:	972080e7          	jalr	-1678(ra) # 802012b8 <initlock>
    8020594e:	60a2                	ld	ra,8(sp)
    80205950:	6402                	ld	s0,0(sp)
    80205952:	0141                	addi	sp,sp,16
    80205954:	8082                	ret

0000000080205956 <filealloc>:

struct file *filealloc(void)
{
    80205956:	1101                	addi	sp,sp,-32
    80205958:	ec06                	sd	ra,24(sp)
    8020595a:	e822                	sd	s0,16(sp)
    8020595c:	e426                	sd	s1,8(sp)
    8020595e:	1000                	addi	s0,sp,32
    acquire(&ftable.lock);
    80205960:	00135517          	auipc	a0,0x135
    80205964:	39050513          	addi	a0,a0,912 # 8033acf0 <ftable>
    80205968:	ffffc097          	auipc	ra,0xffffc
    8020596c:	9cc080e7          	jalr	-1588(ra) # 80201334 <acquire>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    80205970:	00135497          	auipc	s1,0x135
    80205974:	39848493          	addi	s1,s1,920 # 8033ad08 <ftable+0x18>
    80205978:	00136717          	auipc	a4,0x136
    8020597c:	33070713          	addi	a4,a4,816 # 8033bca8 <ftable+0xfb8>
        if (f->ref == 0) {
    80205980:	40dc                	lw	a5,4(s1)
    80205982:	cf99                	beqz	a5,802059a0 <filealloc+0x4a>
    for (struct file *f = ftable.file; f < ftable.file + NFILE; f++) {
    80205984:	02848493          	addi	s1,s1,40
    80205988:	fee49ce3          	bne	s1,a4,80205980 <filealloc+0x2a>
            f->ref = 1;
            release(&ftable.lock);
            return f;
        }
    }
    release(&ftable.lock);
    8020598c:	00135517          	auipc	a0,0x135
    80205990:	36450513          	addi	a0,a0,868 # 8033acf0 <ftable>
    80205994:	ffffc097          	auipc	ra,0xffffc
    80205998:	a54080e7          	jalr	-1452(ra) # 802013e8 <release>
    return 0;
    8020599c:	4481                	li	s1,0
    8020599e:	a819                	j	802059b4 <filealloc+0x5e>
            f->ref = 1;
    802059a0:	4785                	li	a5,1
    802059a2:	c0dc                	sw	a5,4(s1)
            release(&ftable.lock);
    802059a4:	00135517          	auipc	a0,0x135
    802059a8:	34c50513          	addi	a0,a0,844 # 8033acf0 <ftable>
    802059ac:	ffffc097          	auipc	ra,0xffffc
    802059b0:	a3c080e7          	jalr	-1476(ra) # 802013e8 <release>
}
    802059b4:	8526                	mv	a0,s1
    802059b6:	60e2                	ld	ra,24(sp)
    802059b8:	6442                	ld	s0,16(sp)
    802059ba:	64a2                	ld	s1,8(sp)
    802059bc:	6105                	addi	sp,sp,32
    802059be:	8082                	ret

00000000802059c0 <filedup>:

struct file *filedup(struct file *f)
{
    802059c0:	1101                	addi	sp,sp,-32
    802059c2:	ec06                	sd	ra,24(sp)
    802059c4:	e822                	sd	s0,16(sp)
    802059c6:	e426                	sd	s1,8(sp)
    802059c8:	1000                	addi	s0,sp,32
    802059ca:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    802059cc:	00135517          	auipc	a0,0x135
    802059d0:	32450513          	addi	a0,a0,804 # 8033acf0 <ftable>
    802059d4:	ffffc097          	auipc	ra,0xffffc
    802059d8:	960080e7          	jalr	-1696(ra) # 80201334 <acquire>
    if (f->ref < 1) panic("filedup");
    802059dc:	40dc                	lw	a5,4(s1)
    802059de:	02f05263          	blez	a5,80205a02 <filedup+0x42>
    f->ref++;
    802059e2:	2785                	addiw	a5,a5,1
    802059e4:	c0dc                	sw	a5,4(s1)
    release(&ftable.lock);
    802059e6:	00135517          	auipc	a0,0x135
    802059ea:	30a50513          	addi	a0,a0,778 # 8033acf0 <ftable>
    802059ee:	ffffc097          	auipc	ra,0xffffc
    802059f2:	9fa080e7          	jalr	-1542(ra) # 802013e8 <release>
    return f;
}
    802059f6:	8526                	mv	a0,s1
    802059f8:	60e2                	ld	ra,24(sp)
    802059fa:	6442                	ld	s0,16(sp)
    802059fc:	64a2                	ld	s1,8(sp)
    802059fe:	6105                	addi	sp,sp,32
    80205a00:	8082                	ret
    if (f->ref < 1) panic("filedup");
    80205a02:	00002517          	auipc	a0,0x2
    80205a06:	1e650513          	addi	a0,a0,486 # 80207be8 <etext+0xbe8>
    80205a0a:	ffffb097          	auipc	ra,0xffffb
    80205a0e:	bf4080e7          	jalr	-1036(ra) # 802005fe <panic>

0000000080205a12 <fileclose>:

void fileclose(struct file *f)
{
    80205a12:	7139                	addi	sp,sp,-64
    80205a14:	fc06                	sd	ra,56(sp)
    80205a16:	f822                	sd	s0,48(sp)
    80205a18:	f426                	sd	s1,40(sp)
    80205a1a:	0080                	addi	s0,sp,64
    80205a1c:	84aa                	mv	s1,a0
    acquire(&ftable.lock);
    80205a1e:	00135517          	auipc	a0,0x135
    80205a22:	2d250513          	addi	a0,a0,722 # 8033acf0 <ftable>
    80205a26:	ffffc097          	auipc	ra,0xffffc
    80205a2a:	90e080e7          	jalr	-1778(ra) # 80201334 <acquire>
    if (f->ref < 1) panic("fileclose");
    80205a2e:	40dc                	lw	a5,4(s1)
    80205a30:	04f05c63          	blez	a5,80205a88 <fileclose+0x76>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80205a34:	37fd                	addiw	a5,a5,-1
    80205a36:	0007871b          	sext.w	a4,a5
    80205a3a:	c0dc                	sw	a5,4(s1)
    80205a3c:	06e04263          	bgtz	a4,80205aa0 <fileclose+0x8e>
    80205a40:	f04a                	sd	s2,32(sp)
    80205a42:	ec4e                	sd	s3,24(sp)
    80205a44:	e852                	sd	s4,16(sp)
    80205a46:	e456                	sd	s5,8(sp)

    struct file ff = *f;                 /* copy, then free the slot */
    80205a48:	0004a903          	lw	s2,0(s1)
    80205a4c:	0094ca83          	lbu	s5,9(s1)
    80205a50:	0104ba03          	ld	s4,16(s1)
    80205a54:	0184b983          	ld	s3,24(s1)
    f->ref = 0;
    80205a58:	0004a223          	sw	zero,4(s1)
    f->type = FD_NONE;
    80205a5c:	0004a023          	sw	zero,0(s1)
    release(&ftable.lock);
    80205a60:	00135517          	auipc	a0,0x135
    80205a64:	29050513          	addi	a0,a0,656 # 8033acf0 <ftable>
    80205a68:	ffffc097          	auipc	ra,0xffffc
    80205a6c:	980080e7          	jalr	-1664(ra) # 802013e8 <release>

    if (ff.type == FD_PIPE)
    80205a70:	4785                	li	a5,1
    80205a72:	04f90463          	beq	s2,a5,80205aba <fileclose+0xa8>
        pipeclose(ff.pipe, ff.writable);
    else if (ff.type == FD_INODE || ff.type == FD_DEVICE)
    80205a76:	3979                	addiw	s2,s2,-2
    80205a78:	4785                	li	a5,1
    80205a7a:	0527fb63          	bgeu	a5,s2,80205ad0 <fileclose+0xbe>
    80205a7e:	7902                	ld	s2,32(sp)
    80205a80:	69e2                	ld	s3,24(sp)
    80205a82:	6a42                	ld	s4,16(sp)
    80205a84:	6aa2                	ld	s5,8(sp)
    80205a86:	a02d                	j	80205ab0 <fileclose+0x9e>
    80205a88:	f04a                	sd	s2,32(sp)
    80205a8a:	ec4e                	sd	s3,24(sp)
    80205a8c:	e852                	sd	s4,16(sp)
    80205a8e:	e456                	sd	s5,8(sp)
    if (f->ref < 1) panic("fileclose");
    80205a90:	00002517          	auipc	a0,0x2
    80205a94:	16050513          	addi	a0,a0,352 # 80207bf0 <etext+0xbf0>
    80205a98:	ffffb097          	auipc	ra,0xffffb
    80205a9c:	b66080e7          	jalr	-1178(ra) # 802005fe <panic>
    if (--f->ref > 0) { release(&ftable.lock); return; }
    80205aa0:	00135517          	auipc	a0,0x135
    80205aa4:	25050513          	addi	a0,a0,592 # 8033acf0 <ftable>
    80205aa8:	ffffc097          	auipc	ra,0xffffc
    80205aac:	940080e7          	jalr	-1728(ra) # 802013e8 <release>
        iput(ff.ip);
}
    80205ab0:	70e2                	ld	ra,56(sp)
    80205ab2:	7442                	ld	s0,48(sp)
    80205ab4:	74a2                	ld	s1,40(sp)
    80205ab6:	6121                	addi	sp,sp,64
    80205ab8:	8082                	ret
        pipeclose(ff.pipe, ff.writable);
    80205aba:	85d6                	mv	a1,s5
    80205abc:	8552                	mv	a0,s4
    80205abe:	00000097          	auipc	ra,0x0
    80205ac2:	324080e7          	jalr	804(ra) # 80205de2 <pipeclose>
    80205ac6:	7902                	ld	s2,32(sp)
    80205ac8:	69e2                	ld	s3,24(sp)
    80205aca:	6a42                	ld	s4,16(sp)
    80205acc:	6aa2                	ld	s5,8(sp)
    80205ace:	b7cd                	j	80205ab0 <fileclose+0x9e>
        iput(ff.ip);
    80205ad0:	854e                	mv	a0,s3
    80205ad2:	fffff097          	auipc	ra,0xfffff
    80205ad6:	74c080e7          	jalr	1868(ra) # 8020521e <iput>
    80205ada:	7902                	ld	s2,32(sp)
    80205adc:	69e2                	ld	s3,24(sp)
    80205ade:	6a42                	ld	s4,16(sp)
    80205ae0:	6aa2                	ld	s5,8(sp)
    80205ae2:	b7f9                	j	80205ab0 <fileclose+0x9e>

0000000080205ae4 <filestat>:

int filestat(struct file *f, uint64 uaddr)
{
    if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80205ae4:	411c                	lw	a5,0(a0)
    80205ae6:	37f9                	addiw	a5,a5,-2
    80205ae8:	4705                	li	a4,1
    80205aea:	06f76063          	bltu	a4,a5,80205b4a <filestat+0x66>
{
    80205aee:	7139                	addi	sp,sp,-64
    80205af0:	fc06                	sd	ra,56(sp)
    80205af2:	f822                	sd	s0,48(sp)
    80205af4:	f426                	sd	s1,40(sp)
    80205af6:	f04a                	sd	s2,32(sp)
    80205af8:	0080                	addi	s0,sp,64
    80205afa:	84aa                	mv	s1,a0
    80205afc:	892e                	mv	s2,a1
        struct stat st;
        ilock(f->ip);
    80205afe:	6d08                	ld	a0,24(a0)
    80205b00:	fffff097          	auipc	ra,0xfffff
    80205b04:	560080e7          	jalr	1376(ra) # 80205060 <ilock>
        stati(f->ip, &st);
    80205b08:	fc840593          	addi	a1,s0,-56
    80205b0c:	6c88                	ld	a0,24(s1)
    80205b0e:	00000097          	auipc	ra,0x0
    80205b12:	856080e7          	jalr	-1962(ra) # 80205364 <stati>
        iunlock(f->ip);
    80205b16:	6c88                	ld	a0,24(s1)
    80205b18:	fffff097          	auipc	ra,0xfffff
    80205b1c:	60e080e7          	jalr	1550(ra) # 80205126 <iunlock>
        if (copyout(myproc()->pagetable, uaddr, (char *)&st, sizeof(st)) < 0)
    80205b20:	ffffc097          	auipc	ra,0xffffc
    80205b24:	bfe080e7          	jalr	-1026(ra) # 8020171e <myproc>
    80205b28:	46e1                	li	a3,24
    80205b2a:	fc840613          	addi	a2,s0,-56
    80205b2e:	85ca                	mv	a1,s2
    80205b30:	6928                	ld	a0,80(a0)
    80205b32:	ffffd097          	auipc	ra,0xffffd
    80205b36:	41c080e7          	jalr	1052(ra) # 80202f4e <copyout>
    80205b3a:	41f5551b          	sraiw	a0,a0,0x1f
            return -1;
        return 0;
    }
    return -1;
}
    80205b3e:	70e2                	ld	ra,56(sp)
    80205b40:	7442                	ld	s0,48(sp)
    80205b42:	74a2                	ld	s1,40(sp)
    80205b44:	7902                	ld	s2,32(sp)
    80205b46:	6121                	addi	sp,sp,64
    80205b48:	8082                	ret
    return -1;
    80205b4a:	557d                	li	a0,-1
}
    80205b4c:	8082                	ret

0000000080205b4e <fileread>:

int fileread(struct file *f, uint64 uaddr, int n)
{
    80205b4e:	7179                	addi	sp,sp,-48
    80205b50:	f406                	sd	ra,40(sp)
    80205b52:	f022                	sd	s0,32(sp)
    80205b54:	e84a                	sd	s2,16(sp)
    80205b56:	1800                	addi	s0,sp,48
    if (f->readable == 0) return -1;
    80205b58:	00854783          	lbu	a5,8(a0)
    80205b5c:	cbcd                	beqz	a5,80205c0e <fileread+0xc0>
    80205b5e:	ec26                	sd	s1,24(sp)
    80205b60:	e44e                	sd	s3,8(sp)
    80205b62:	84aa                	mv	s1,a0
    80205b64:	89ae                	mv	s3,a1
    80205b66:	8932                	mv	s2,a2

    if (f->type == FD_PIPE)
    80205b68:	411c                	lw	a5,0(a0)
    80205b6a:	4705                	li	a4,1
    80205b6c:	04e78963          	beq	a5,a4,80205bbe <fileread+0x70>
        return piperead(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80205b70:	470d                	li	a4,3
    80205b72:	04e78f63          	beq	a5,a4,80205bd0 <fileread+0x82>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
        return devsw[f->major].read(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80205b76:	4709                	li	a4,2
    80205b78:	08e79363          	bne	a5,a4,80205bfe <fileread+0xb0>
        ilock(f->ip);
    80205b7c:	6d08                	ld	a0,24(a0)
    80205b7e:	fffff097          	auipc	ra,0xfffff
    80205b82:	4e2080e7          	jalr	1250(ra) # 80205060 <ilock>
        int r = readi(f->ip, 1, uaddr, f->off, n);
    80205b86:	874a                	mv	a4,s2
    80205b88:	5094                	lw	a3,32(s1)
    80205b8a:	864e                	mv	a2,s3
    80205b8c:	4585                	li	a1,1
    80205b8e:	6c88                	ld	a0,24(s1)
    80205b90:	fffff097          	auipc	ra,0xfffff
    80205b94:	7fe080e7          	jalr	2046(ra) # 8020538e <readi>
    80205b98:	892a                	mv	s2,a0
        if (r > 0) f->off += r;          /* offset update under the inode lock */
    80205b9a:	00a05563          	blez	a0,80205ba4 <fileread+0x56>
    80205b9e:	509c                	lw	a5,32(s1)
    80205ba0:	9fa9                	addw	a5,a5,a0
    80205ba2:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80205ba4:	6c88                	ld	a0,24(s1)
    80205ba6:	fffff097          	auipc	ra,0xfffff
    80205baa:	580080e7          	jalr	1408(ra) # 80205126 <iunlock>
        return r;
    80205bae:	64e2                	ld	s1,24(sp)
    80205bb0:	69a2                	ld	s3,8(sp)
    }
    panic("fileread");
}
    80205bb2:	854a                	mv	a0,s2
    80205bb4:	70a2                	ld	ra,40(sp)
    80205bb6:	7402                	ld	s0,32(sp)
    80205bb8:	6942                	ld	s2,16(sp)
    80205bba:	6145                	addi	sp,sp,48
    80205bbc:	8082                	ret
        return piperead(f->pipe, uaddr, n);
    80205bbe:	6908                	ld	a0,16(a0)
    80205bc0:	00000097          	auipc	ra,0x0
    80205bc4:	38a080e7          	jalr	906(ra) # 80205f4a <piperead>
    80205bc8:	892a                	mv	s2,a0
    80205bca:	64e2                	ld	s1,24(sp)
    80205bcc:	69a2                	ld	s3,8(sp)
    80205bce:	b7d5                	j	80205bb2 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80205bd0:	02451783          	lh	a5,36(a0)
    80205bd4:	03079693          	slli	a3,a5,0x30
    80205bd8:	92c1                	srli	a3,a3,0x30
    80205bda:	4725                	li	a4,9
    80205bdc:	02d76b63          	bltu	a4,a3,80205c12 <fileread+0xc4>
    80205be0:	0792                	slli	a5,a5,0x4
    80205be2:	00135717          	auipc	a4,0x135
    80205be6:	06e70713          	addi	a4,a4,110 # 8033ac50 <devsw>
    80205bea:	97ba                	add	a5,a5,a4
    80205bec:	639c                	ld	a5,0(a5)
    80205bee:	c795                	beqz	a5,80205c1a <fileread+0xcc>
        return devsw[f->major].read(uaddr, n);
    80205bf0:	85b2                	mv	a1,a2
    80205bf2:	854e                	mv	a0,s3
    80205bf4:	9782                	jalr	a5
    80205bf6:	892a                	mv	s2,a0
    80205bf8:	64e2                	ld	s1,24(sp)
    80205bfa:	69a2                	ld	s3,8(sp)
    80205bfc:	bf5d                	j	80205bb2 <fileread+0x64>
    panic("fileread");
    80205bfe:	00002517          	auipc	a0,0x2
    80205c02:	00250513          	addi	a0,a0,2 # 80207c00 <etext+0xc00>
    80205c06:	ffffb097          	auipc	ra,0xffffb
    80205c0a:	9f8080e7          	jalr	-1544(ra) # 802005fe <panic>
    if (f->readable == 0) return -1;
    80205c0e:	597d                	li	s2,-1
    80205c10:	b74d                	j	80205bb2 <fileread+0x64>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read) return -1;
    80205c12:	597d                	li	s2,-1
    80205c14:	64e2                	ld	s1,24(sp)
    80205c16:	69a2                	ld	s3,8(sp)
    80205c18:	bf69                	j	80205bb2 <fileread+0x64>
    80205c1a:	597d                	li	s2,-1
    80205c1c:	64e2                	ld	s1,24(sp)
    80205c1e:	69a2                	ld	s3,8(sp)
    80205c20:	bf49                	j	80205bb2 <fileread+0x64>

0000000080205c22 <filewrite>:

int filewrite(struct file *f, uint64 uaddr, int n)
{
    80205c22:	7179                	addi	sp,sp,-48
    80205c24:	f406                	sd	ra,40(sp)
    80205c26:	f022                	sd	s0,32(sp)
    80205c28:	e84a                	sd	s2,16(sp)
    80205c2a:	1800                	addi	s0,sp,48
    if (f->writable == 0) return -1;
    80205c2c:	00954783          	lbu	a5,9(a0)
    80205c30:	cfdd                	beqz	a5,80205cee <filewrite+0xcc>
    80205c32:	ec26                	sd	s1,24(sp)
    80205c34:	e44e                	sd	s3,8(sp)
    80205c36:	84aa                	mv	s1,a0
    80205c38:	892e                	mv	s2,a1
    80205c3a:	89b2                	mv	s3,a2

    if (f->type == FD_PIPE)
    80205c3c:	411c                	lw	a5,0(a0)
    80205c3e:	4705                	li	a4,1
    80205c40:	04e78c63          	beq	a5,a4,80205c98 <filewrite+0x76>
        return pipewrite(f->pipe, uaddr, n);

    if (f->type == FD_DEVICE) {
    80205c44:	470d                	li	a4,3
    80205c46:	06e78263          	beq	a5,a4,80205caa <filewrite+0x88>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
        return devsw[f->major].write(uaddr, n);
    }
    if (f->type == FD_INODE) {
    80205c4a:	4709                	li	a4,2
    80205c4c:	08e79963          	bne	a5,a4,80205cde <filewrite+0xbc>
        ilock(f->ip);
    80205c50:	6d08                	ld	a0,24(a0)
    80205c52:	fffff097          	auipc	ra,0xfffff
    80205c56:	40e080e7          	jalr	1038(ra) # 80205060 <ilock>
        int r = writei(f->ip, 1, uaddr, f->off, n);
    80205c5a:	874e                	mv	a4,s3
    80205c5c:	5094                	lw	a3,32(s1)
    80205c5e:	864a                	mv	a2,s2
    80205c60:	4585                	li	a1,1
    80205c62:	6c88                	ld	a0,24(s1)
    80205c64:	00000097          	auipc	ra,0x0
    80205c68:	85e080e7          	jalr	-1954(ra) # 802054c2 <writei>
    80205c6c:	892a                	mv	s2,a0
        if (r > 0) f->off += r;
    80205c6e:	00a05563          	blez	a0,80205c78 <filewrite+0x56>
    80205c72:	509c                	lw	a5,32(s1)
    80205c74:	9fa9                	addw	a5,a5,a0
    80205c76:	d09c                	sw	a5,32(s1)
        iunlock(f->ip);
    80205c78:	6c88                	ld	a0,24(s1)
    80205c7a:	fffff097          	auipc	ra,0xfffff
    80205c7e:	4ac080e7          	jalr	1196(ra) # 80205126 <iunlock>
        return (r == n) ? n : -1;        /* short write = disk full = error */
    80205c82:	05298b63          	beq	s3,s2,80205cd8 <filewrite+0xb6>
    80205c86:	597d                	li	s2,-1
    80205c88:	64e2                	ld	s1,24(sp)
    80205c8a:	69a2                	ld	s3,8(sp)
    }
    panic("filewrite");
}
    80205c8c:	854a                	mv	a0,s2
    80205c8e:	70a2                	ld	ra,40(sp)
    80205c90:	7402                	ld	s0,32(sp)
    80205c92:	6942                	ld	s2,16(sp)
    80205c94:	6145                	addi	sp,sp,48
    80205c96:	8082                	ret
        return pipewrite(f->pipe, uaddr, n);
    80205c98:	6908                	ld	a0,16(a0)
    80205c9a:	00000097          	auipc	ra,0x0
    80205c9e:	1b8080e7          	jalr	440(ra) # 80205e52 <pipewrite>
    80205ca2:	892a                	mv	s2,a0
    80205ca4:	64e2                	ld	s1,24(sp)
    80205ca6:	69a2                	ld	s3,8(sp)
    80205ca8:	b7d5                	j	80205c8c <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80205caa:	02451783          	lh	a5,36(a0)
    80205cae:	03079693          	slli	a3,a5,0x30
    80205cb2:	92c1                	srli	a3,a3,0x30
    80205cb4:	4725                	li	a4,9
    80205cb6:	02d76e63          	bltu	a4,a3,80205cf2 <filewrite+0xd0>
    80205cba:	0792                	slli	a5,a5,0x4
    80205cbc:	00135717          	auipc	a4,0x135
    80205cc0:	f9470713          	addi	a4,a4,-108 # 8033ac50 <devsw>
    80205cc4:	97ba                	add	a5,a5,a4
    80205cc6:	679c                	ld	a5,8(a5)
    80205cc8:	cb8d                	beqz	a5,80205cfa <filewrite+0xd8>
        return devsw[f->major].write(uaddr, n);
    80205cca:	85b2                	mv	a1,a2
    80205ccc:	854a                	mv	a0,s2
    80205cce:	9782                	jalr	a5
    80205cd0:	892a                	mv	s2,a0
    80205cd2:	64e2                	ld	s1,24(sp)
    80205cd4:	69a2                	ld	s3,8(sp)
    80205cd6:	bf5d                	j	80205c8c <filewrite+0x6a>
    80205cd8:	64e2                	ld	s1,24(sp)
    80205cda:	69a2                	ld	s3,8(sp)
    80205cdc:	bf45                	j	80205c8c <filewrite+0x6a>
    panic("filewrite");
    80205cde:	00002517          	auipc	a0,0x2
    80205ce2:	f3250513          	addi	a0,a0,-206 # 80207c10 <etext+0xc10>
    80205ce6:	ffffb097          	auipc	ra,0xffffb
    80205cea:	918080e7          	jalr	-1768(ra) # 802005fe <panic>
    if (f->writable == 0) return -1;
    80205cee:	597d                	li	s2,-1
    80205cf0:	bf71                	j	80205c8c <filewrite+0x6a>
        if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write) return -1;
    80205cf2:	597d                	li	s2,-1
    80205cf4:	64e2                	ld	s1,24(sp)
    80205cf6:	69a2                	ld	s3,8(sp)
    80205cf8:	bf51                	j	80205c8c <filewrite+0x6a>
    80205cfa:	597d                	li	s2,-1
    80205cfc:	64e2                	ld	s1,24(sp)
    80205cfe:	69a2                	ld	s3,8(sp)
    80205d00:	b771                	j	80205c8c <filewrite+0x6a>

0000000080205d02 <pipealloc>:
    int    readopen;
    int    writeopen;
};

int pipealloc(struct file **f0, struct file **f1)
{
    80205d02:	7179                	addi	sp,sp,-48
    80205d04:	f406                	sd	ra,40(sp)
    80205d06:	f022                	sd	s0,32(sp)
    80205d08:	ec26                	sd	s1,24(sp)
    80205d0a:	e052                	sd	s4,0(sp)
    80205d0c:	1800                	addi	s0,sp,48
    80205d0e:	84aa                	mv	s1,a0
    80205d10:	8a2e                	mv	s4,a1
    struct pipe *pi = 0;
    *f0 = *f1 = 0;
    80205d12:	0005b023          	sd	zero,0(a1)
    80205d16:	00053023          	sd	zero,0(a0)

    if ((*f0 = filealloc()) == 0) goto bad;
    80205d1a:	00000097          	auipc	ra,0x0
    80205d1e:	c3c080e7          	jalr	-964(ra) # 80205956 <filealloc>
    80205d22:	e088                	sd	a0,0(s1)
    80205d24:	cd49                	beqz	a0,80205dbe <pipealloc+0xbc>
    if ((*f1 = filealloc()) == 0) goto bad;
    80205d26:	00000097          	auipc	ra,0x0
    80205d2a:	c30080e7          	jalr	-976(ra) # 80205956 <filealloc>
    80205d2e:	00aa3023          	sd	a0,0(s4)
    80205d32:	c141                	beqz	a0,80205db2 <pipealloc+0xb0>
    80205d34:	e84a                	sd	s2,16(sp)
    if ((pi = (struct pipe *)palloc()) == 0) goto bad;
    80205d36:	ffffb097          	auipc	ra,0xffffb
    80205d3a:	370080e7          	jalr	880(ra) # 802010a6 <palloc>
    80205d3e:	892a                	mv	s2,a0
    80205d40:	c13d                	beqz	a0,80205da6 <pipealloc+0xa4>
    80205d42:	e44e                	sd	s3,8(sp)

    pi->readopen  = 1;
    80205d44:	4985                	li	s3,1
    80205d46:	23352023          	sw	s3,544(a0)
    pi->writeopen = 1;
    80205d4a:	23352223          	sw	s3,548(a0)
    pi->nread  = 0;
    80205d4e:	20052c23          	sw	zero,536(a0)
    pi->nwrite = 0;
    80205d52:	20052e23          	sw	zero,540(a0)
    initlock(&pi->lock, "pipe");
    80205d56:	00002597          	auipc	a1,0x2
    80205d5a:	eca58593          	addi	a1,a1,-310 # 80207c20 <etext+0xc20>
    80205d5e:	ffffb097          	auipc	ra,0xffffb
    80205d62:	55a080e7          	jalr	1370(ra) # 802012b8 <initlock>

    (*f0)->type = FD_PIPE; (*f0)->readable = 1; (*f0)->writable = 0; (*f0)->pipe = pi;
    80205d66:	609c                	ld	a5,0(s1)
    80205d68:	0137a023          	sw	s3,0(a5)
    80205d6c:	609c                	ld	a5,0(s1)
    80205d6e:	01378423          	sb	s3,8(a5)
    80205d72:	609c                	ld	a5,0(s1)
    80205d74:	000784a3          	sb	zero,9(a5)
    80205d78:	609c                	ld	a5,0(s1)
    80205d7a:	0127b823          	sd	s2,16(a5)
    (*f1)->type = FD_PIPE; (*f1)->readable = 0; (*f1)->writable = 1; (*f1)->pipe = pi;
    80205d7e:	000a3783          	ld	a5,0(s4)
    80205d82:	0137a023          	sw	s3,0(a5)
    80205d86:	000a3783          	ld	a5,0(s4)
    80205d8a:	00078423          	sb	zero,8(a5)
    80205d8e:	000a3783          	ld	a5,0(s4)
    80205d92:	013784a3          	sb	s3,9(a5)
    80205d96:	000a3783          	ld	a5,0(s4)
    80205d9a:	0127b823          	sd	s2,16(a5)
    return 0;
    80205d9e:	4501                	li	a0,0
    80205da0:	6942                	ld	s2,16(sp)
    80205da2:	69a2                	ld	s3,8(sp)
    80205da4:	a03d                	j	80205dd2 <pipealloc+0xd0>

bad:
    if (*f0) fileclose(*f0);
    80205da6:	6088                	ld	a0,0(s1)
    80205da8:	c119                	beqz	a0,80205dae <pipealloc+0xac>
    80205daa:	6942                	ld	s2,16(sp)
    80205dac:	a029                	j	80205db6 <pipealloc+0xb4>
    80205dae:	6942                	ld	s2,16(sp)
    80205db0:	a039                	j	80205dbe <pipealloc+0xbc>
    80205db2:	6088                	ld	a0,0(s1)
    80205db4:	c50d                	beqz	a0,80205dde <pipealloc+0xdc>
    80205db6:	00000097          	auipc	ra,0x0
    80205dba:	c5c080e7          	jalr	-932(ra) # 80205a12 <fileclose>
    if (*f1) fileclose(*f1);
    80205dbe:	000a3783          	ld	a5,0(s4)
    return -1;
    80205dc2:	557d                	li	a0,-1
    if (*f1) fileclose(*f1);
    80205dc4:	c799                	beqz	a5,80205dd2 <pipealloc+0xd0>
    80205dc6:	853e                	mv	a0,a5
    80205dc8:	00000097          	auipc	ra,0x0
    80205dcc:	c4a080e7          	jalr	-950(ra) # 80205a12 <fileclose>
    return -1;
    80205dd0:	557d                	li	a0,-1
}
    80205dd2:	70a2                	ld	ra,40(sp)
    80205dd4:	7402                	ld	s0,32(sp)
    80205dd6:	64e2                	ld	s1,24(sp)
    80205dd8:	6a02                	ld	s4,0(sp)
    80205dda:	6145                	addi	sp,sp,48
    80205ddc:	8082                	ret
    return -1;
    80205dde:	557d                	li	a0,-1
    80205de0:	bfcd                	j	80205dd2 <pipealloc+0xd0>

0000000080205de2 <pipeclose>:

void pipeclose(struct pipe *pi, int writable)
{
    80205de2:	1101                	addi	sp,sp,-32
    80205de4:	ec06                	sd	ra,24(sp)
    80205de6:	e822                	sd	s0,16(sp)
    80205de8:	e426                	sd	s1,8(sp)
    80205dea:	e04a                	sd	s2,0(sp)
    80205dec:	1000                	addi	s0,sp,32
    80205dee:	84aa                	mv	s1,a0
    80205df0:	892e                	mv	s2,a1
    acquire(&pi->lock);
    80205df2:	ffffb097          	auipc	ra,0xffffb
    80205df6:	542080e7          	jalr	1346(ra) # 80201334 <acquire>
    if (writable) {
    80205dfa:	02090d63          	beqz	s2,80205e34 <pipeclose+0x52>
        pi->writeopen = 0;
    80205dfe:	2204a223          	sw	zero,548(s1)
        wakeup(&pi->nread);          /* blocked readers must see EOF */
    80205e02:	21848513          	addi	a0,s1,536
    80205e06:	ffffc097          	auipc	ra,0xffffc
    80205e0a:	102080e7          	jalr	258(ra) # 80201f08 <wakeup>
    } else {
        pi->readopen = 0;
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    }
    if (pi->readopen == 0 && pi->writeopen == 0) {
    80205e0e:	2204b783          	ld	a5,544(s1)
    80205e12:	eb95                	bnez	a5,80205e46 <pipeclose+0x64>
        release(&pi->lock);
    80205e14:	8526                	mv	a0,s1
    80205e16:	ffffb097          	auipc	ra,0xffffb
    80205e1a:	5d2080e7          	jalr	1490(ra) # 802013e8 <release>
        pfree(pi);
    80205e1e:	8526                	mv	a0,s1
    80205e20:	ffffb097          	auipc	ra,0xffffb
    80205e24:	396080e7          	jalr	918(ra) # 802011b6 <pfree>
    } else {
        release(&pi->lock);
    }
}
    80205e28:	60e2                	ld	ra,24(sp)
    80205e2a:	6442                	ld	s0,16(sp)
    80205e2c:	64a2                	ld	s1,8(sp)
    80205e2e:	6902                	ld	s2,0(sp)
    80205e30:	6105                	addi	sp,sp,32
    80205e32:	8082                	ret
        pi->readopen = 0;
    80205e34:	2204a023          	sw	zero,544(s1)
        wakeup(&pi->nwrite);         /* blocked writers must see the error */
    80205e38:	21c48513          	addi	a0,s1,540
    80205e3c:	ffffc097          	auipc	ra,0xffffc
    80205e40:	0cc080e7          	jalr	204(ra) # 80201f08 <wakeup>
    80205e44:	b7e9                	j	80205e0e <pipeclose+0x2c>
        release(&pi->lock);
    80205e46:	8526                	mv	a0,s1
    80205e48:	ffffb097          	auipc	ra,0xffffb
    80205e4c:	5a0080e7          	jalr	1440(ra) # 802013e8 <release>
}
    80205e50:	bfe1                	j	80205e28 <pipeclose+0x46>

0000000080205e52 <pipewrite>:

int pipewrite(struct pipe *pi, uint64 uaddr, int n)
{
    80205e52:	711d                	addi	sp,sp,-96
    80205e54:	ec86                	sd	ra,88(sp)
    80205e56:	e8a2                	sd	s0,80(sp)
    80205e58:	e4a6                	sd	s1,72(sp)
    80205e5a:	e0ca                	sd	s2,64(sp)
    80205e5c:	fc4e                	sd	s3,56(sp)
    80205e5e:	f852                	sd	s4,48(sp)
    80205e60:	f456                	sd	s5,40(sp)
    80205e62:	1080                	addi	s0,sp,96
    80205e64:	84aa                	mv	s1,a0
    80205e66:	8aae                	mv	s5,a1
    80205e68:	8a32                	mv	s4,a2
    struct proc *pr = myproc();
    80205e6a:	ffffc097          	auipc	ra,0xffffc
    80205e6e:	8b4080e7          	jalr	-1868(ra) # 8020171e <myproc>
    80205e72:	89aa                	mv	s3,a0
    int i = 0;

    acquire(&pi->lock);
    80205e74:	8526                	mv	a0,s1
    80205e76:	ffffb097          	auipc	ra,0xffffb
    80205e7a:	4be080e7          	jalr	1214(ra) # 80201334 <acquire>
    while (i < n) {
    80205e7e:	0d405163          	blez	s4,80205f40 <pipewrite+0xee>
    80205e82:	f05a                	sd	s6,32(sp)
    80205e84:	ec5e                	sd	s7,24(sp)
    int i = 0;
    80205e86:	4901                	li	s2,0
        if (pi->readopen == 0 || pr->killed) {
            release(&pi->lock);
            return -1;
        }
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
            wakeup(&pi->nread);
    80205e88:	21848b93          	addi	s7,s1,536
            sleep(&pi->nwrite, &pi->lock);
    80205e8c:	21c48b13          	addi	s6,s1,540
    80205e90:	a081                	j	80205ed0 <pipewrite+0x7e>
            release(&pi->lock);
    80205e92:	8526                	mv	a0,s1
    80205e94:	ffffb097          	auipc	ra,0xffffb
    80205e98:	554080e7          	jalr	1364(ra) # 802013e8 <release>
            return -1;
    80205e9c:	597d                	li	s2,-1
    80205e9e:	7b02                	ld	s6,32(sp)
    80205ea0:	6be2                	ld	s7,24(sp)
        }
    }
    wakeup(&pi->nread);
    release(&pi->lock);
    return i;
}
    80205ea2:	854a                	mv	a0,s2
    80205ea4:	60e6                	ld	ra,88(sp)
    80205ea6:	6446                	ld	s0,80(sp)
    80205ea8:	64a6                	ld	s1,72(sp)
    80205eaa:	6906                	ld	s2,64(sp)
    80205eac:	79e2                	ld	s3,56(sp)
    80205eae:	7a42                	ld	s4,48(sp)
    80205eb0:	7aa2                	ld	s5,40(sp)
    80205eb2:	6125                	addi	sp,sp,96
    80205eb4:	8082                	ret
            wakeup(&pi->nread);
    80205eb6:	855e                	mv	a0,s7
    80205eb8:	ffffc097          	auipc	ra,0xffffc
    80205ebc:	050080e7          	jalr	80(ra) # 80201f08 <wakeup>
            sleep(&pi->nwrite, &pi->lock);
    80205ec0:	85a6                	mv	a1,s1
    80205ec2:	855a                	mv	a0,s6
    80205ec4:	ffffc097          	auipc	ra,0xffffc
    80205ec8:	ebe080e7          	jalr	-322(ra) # 80201d82 <sleep>
    while (i < n) {
    80205ecc:	05495c63          	bge	s2,s4,80205f24 <pipewrite+0xd2>
        if (pi->readopen == 0 || pr->killed) {
    80205ed0:	2204a783          	lw	a5,544(s1)
    80205ed4:	dfdd                	beqz	a5,80205e92 <pipewrite+0x40>
    80205ed6:	0289a783          	lw	a5,40(s3)
    80205eda:	ffc5                	bnez	a5,80205e92 <pipewrite+0x40>
        if (pi->nwrite == pi->nread + PIPESIZE) {   /* full */
    80205edc:	2184a783          	lw	a5,536(s1)
    80205ee0:	21c4a703          	lw	a4,540(s1)
    80205ee4:	2007879b          	addiw	a5,a5,512
    80205ee8:	fcf707e3          	beq	a4,a5,80205eb6 <pipewrite+0x64>
            if (copyin(pr->pagetable, &ch, uaddr + i, 1) < 0) break;
    80205eec:	4685                	li	a3,1
    80205eee:	01590633          	add	a2,s2,s5
    80205ef2:	faf40593          	addi	a1,s0,-81
    80205ef6:	0509b503          	ld	a0,80(s3)
    80205efa:	ffffd097          	auipc	ra,0xffffd
    80205efe:	148080e7          	jalr	328(ra) # 80203042 <copyin>
    80205f02:	04054163          	bltz	a0,80205f44 <pipewrite+0xf2>
            pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80205f06:	21c4a783          	lw	a5,540(s1)
    80205f0a:	0017871b          	addiw	a4,a5,1
    80205f0e:	20e4ae23          	sw	a4,540(s1)
    80205f12:	1ff7f793          	andi	a5,a5,511
    80205f16:	97a6                	add	a5,a5,s1
    80205f18:	faf44703          	lbu	a4,-81(s0)
    80205f1c:	00e78c23          	sb	a4,24(a5)
            i++;
    80205f20:	2905                	addiw	s2,s2,1
    80205f22:	b76d                	j	80205ecc <pipewrite+0x7a>
    80205f24:	7b02                	ld	s6,32(sp)
    80205f26:	6be2                	ld	s7,24(sp)
    wakeup(&pi->nread);
    80205f28:	21848513          	addi	a0,s1,536
    80205f2c:	ffffc097          	auipc	ra,0xffffc
    80205f30:	fdc080e7          	jalr	-36(ra) # 80201f08 <wakeup>
    release(&pi->lock);
    80205f34:	8526                	mv	a0,s1
    80205f36:	ffffb097          	auipc	ra,0xffffb
    80205f3a:	4b2080e7          	jalr	1202(ra) # 802013e8 <release>
    return i;
    80205f3e:	b795                	j	80205ea2 <pipewrite+0x50>
    int i = 0;
    80205f40:	4901                	li	s2,0
    80205f42:	b7dd                	j	80205f28 <pipewrite+0xd6>
    80205f44:	7b02                	ld	s6,32(sp)
    80205f46:	6be2                	ld	s7,24(sp)
    80205f48:	b7c5                	j	80205f28 <pipewrite+0xd6>

0000000080205f4a <piperead>:

int piperead(struct pipe *pi, uint64 uaddr, int n)
{
    80205f4a:	715d                	addi	sp,sp,-80
    80205f4c:	e486                	sd	ra,72(sp)
    80205f4e:	e0a2                	sd	s0,64(sp)
    80205f50:	fc26                	sd	s1,56(sp)
    80205f52:	f84a                	sd	s2,48(sp)
    80205f54:	f44e                	sd	s3,40(sp)
    80205f56:	f052                	sd	s4,32(sp)
    80205f58:	ec56                	sd	s5,24(sp)
    80205f5a:	0880                	addi	s0,sp,80
    80205f5c:	84aa                	mv	s1,a0
    80205f5e:	892e                	mv	s2,a1
    80205f60:	8ab2                	mv	s5,a2
    struct proc *pr = myproc();
    80205f62:	ffffb097          	auipc	ra,0xffffb
    80205f66:	7bc080e7          	jalr	1980(ra) # 8020171e <myproc>
    80205f6a:	8a2a                	mv	s4,a0

    acquire(&pi->lock);
    80205f6c:	8526                	mv	a0,s1
    80205f6e:	ffffb097          	auipc	ra,0xffffb
    80205f72:	3c6080e7          	jalr	966(ra) # 80201334 <acquire>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205f76:	2184a703          	lw	a4,536(s1)
    80205f7a:	21c4a783          	lw	a5,540(s1)
        if (pr->killed) { release(&pi->lock); return -1; }
        sleep(&pi->nread, &pi->lock);
    80205f7e:	21848993          	addi	s3,s1,536
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205f82:	02f71463          	bne	a4,a5,80205faa <piperead+0x60>
    80205f86:	2244a783          	lw	a5,548(s1)
    80205f8a:	c385                	beqz	a5,80205faa <piperead+0x60>
        if (pr->killed) { release(&pi->lock); return -1; }
    80205f8c:	028a2783          	lw	a5,40(s4)
    80205f90:	e7d9                	bnez	a5,8020601e <piperead+0xd4>
        sleep(&pi->nread, &pi->lock);
    80205f92:	85a6                	mv	a1,s1
    80205f94:	854e                	mv	a0,s3
    80205f96:	ffffc097          	auipc	ra,0xffffc
    80205f9a:	dec080e7          	jalr	-532(ra) # 80201d82 <sleep>
    while (pi->nread == pi->nwrite && pi->writeopen) {  /* empty, not EOF */
    80205f9e:	2184a703          	lw	a4,536(s1)
    80205fa2:	21c4a783          	lw	a5,540(s1)
    80205fa6:	fef700e3          	beq	a4,a5,80205f86 <piperead+0x3c>
    }
    int i;
    for (i = 0; i < n; i++) {
    80205faa:	4981                	li	s3,0
    80205fac:	05505463          	blez	s5,80205ff4 <piperead+0xaa>
        if (pi->nread == pi->nwrite) break;             /* drained */
    80205fb0:	2184a783          	lw	a5,536(s1)
    80205fb4:	21c4a703          	lw	a4,540(s1)
    80205fb8:	02f70e63          	beq	a4,a5,80205ff4 <piperead+0xaa>
        char ch = pi->data[pi->nread++ % PIPESIZE];
    80205fbc:	0017871b          	addiw	a4,a5,1
    80205fc0:	20e4ac23          	sw	a4,536(s1)
    80205fc4:	1ff7f793          	andi	a5,a5,511
    80205fc8:	97a6                	add	a5,a5,s1
    80205fca:	0187c783          	lbu	a5,24(a5)
    80205fce:	faf40fa3          	sb	a5,-65(s0)
        if (copyout(pr->pagetable, uaddr + i, &ch, 1) < 0) break;
    80205fd2:	4685                	li	a3,1
    80205fd4:	fbf40613          	addi	a2,s0,-65
    80205fd8:	85ca                	mv	a1,s2
    80205fda:	050a3503          	ld	a0,80(s4)
    80205fde:	ffffd097          	auipc	ra,0xffffd
    80205fe2:	f70080e7          	jalr	-144(ra) # 80202f4e <copyout>
    80205fe6:	00054763          	bltz	a0,80205ff4 <piperead+0xaa>
    for (i = 0; i < n; i++) {
    80205fea:	2985                	addiw	s3,s3,1
    80205fec:	0905                	addi	s2,s2,1
    80205fee:	fd3a91e3          	bne	s5,s3,80205fb0 <piperead+0x66>
    80205ff2:	89d6                	mv	s3,s5
    }
    wakeup(&pi->nwrite);
    80205ff4:	21c48513          	addi	a0,s1,540
    80205ff8:	ffffc097          	auipc	ra,0xffffc
    80205ffc:	f10080e7          	jalr	-240(ra) # 80201f08 <wakeup>
    release(&pi->lock);
    80206000:	8526                	mv	a0,s1
    80206002:	ffffb097          	auipc	ra,0xffffb
    80206006:	3e6080e7          	jalr	998(ra) # 802013e8 <release>
    return i;                                           /* 0 here = EOF */
}
    8020600a:	854e                	mv	a0,s3
    8020600c:	60a6                	ld	ra,72(sp)
    8020600e:	6406                	ld	s0,64(sp)
    80206010:	74e2                	ld	s1,56(sp)
    80206012:	7942                	ld	s2,48(sp)
    80206014:	79a2                	ld	s3,40(sp)
    80206016:	7a02                	ld	s4,32(sp)
    80206018:	6ae2                	ld	s5,24(sp)
    8020601a:	6161                	addi	sp,sp,80
    8020601c:	8082                	ret
        if (pr->killed) { release(&pi->lock); return -1; }
    8020601e:	8526                	mv	a0,s1
    80206020:	ffffb097          	auipc	ra,0xffffb
    80206024:	3c8080e7          	jalr	968(ra) # 802013e8 <release>
    80206028:	59fd                	li	s3,-1
    8020602a:	b7c5                	j	8020600a <piperead+0xc0>

000000008020602c <hal_intc_init>:
#define PLIC_PRIORITY(irq)   (plic + (irq) * 4)
#define PLIC_SENABLE(h)      (plic + 0x2080 + (h) * 0x100)
#define PLIC_STHRESHOLD(h)   (plic + 0x201000 + (h) * 0x2000)
#define PLIC_SCLAIM(h)       (plic + 0x201004 + (h) * 0x2000)

void hal_intc_init(uint64 plic_base) { plic = plic_base; }
    8020602c:	1141                	addi	sp,sp,-16
    8020602e:	e422                	sd	s0,8(sp)
    80206030:	0800                	addi	s0,sp,16
    80206032:	00139797          	auipc	a5,0x139
    80206036:	fea7bb23          	sd	a0,-10(a5) # 8033f028 <plic>
    8020603a:	6422                	ld	s0,8(sp)
    8020603c:	0141                	addi	sp,sp,16
    8020603e:	8082                	ret

0000000080206040 <hal_intc_enable>:

void hal_intc_enable(int irq)
{
    80206040:	1141                	addi	sp,sp,-16
    80206042:	e422                	sd	s0,8(sp)
    80206044:	0800                	addi	s0,sp,16
    if (!plic) return;
    80206046:	00139797          	auipc	a5,0x139
    8020604a:	fe27b783          	ld	a5,-30(a5) # 8033f028 <plic>
    8020604e:	c791                	beqz	a5,8020605a <hal_intc_enable+0x1a>
    *(volatile uint32 *)PLIC_PRIORITY(irq) = 1;   /* priority 0 = never fire */
    80206050:	0025151b          	slliw	a0,a0,0x2
    80206054:	953e                	add	a0,a0,a5
    80206056:	4785                	li	a5,1
    80206058:	c11c                	sw	a5,0(a0)
}
    8020605a:	6422                	ld	s0,8(sp)
    8020605c:	0141                	addi	sp,sp,16
    8020605e:	8082                	ret

0000000080206060 <hal_intc_hart_init>:

void hal_intc_hart_init(int hart)
{
    80206060:	1141                	addi	sp,sp,-16
    80206062:	e422                	sd	s0,8(sp)
    80206064:	0800                	addi	s0,sp,16
    if (!plic) return;
    80206066:	00139797          	auipc	a5,0x139
    8020606a:	fc27b783          	ld	a5,-62(a5) # 8033f028 <plic>
    8020606e:	cb89                	beqz	a5,80206080 <hal_intc_hart_init+0x20>
    *(volatile uint32 *)PLIC_STHRESHOLD(hart) = 0; /* accept any priority > 0 */
    80206070:	00d5151b          	slliw	a0,a0,0xd
    80206074:	00201737          	lui	a4,0x201
    80206078:	97ba                	add	a5,a5,a4
    8020607a:	953e                	add	a0,a0,a5
    8020607c:	00052023          	sw	zero,0(a0)
}
    80206080:	6422                	ld	s0,8(sp)
    80206082:	0141                	addi	sp,sp,16
    80206084:	8082                	ret

0000000080206086 <hal_intc_enable_hart>:

/* Enable irq for this hart (must be called after hal_intc_enable). */
void hal_intc_enable_hart(int hart, int irq)
{
    80206086:	1141                	addi	sp,sp,-16
    80206088:	e422                	sd	s0,8(sp)
    8020608a:	0800                	addi	s0,sp,16
    if (!plic) return;
    8020608c:	00139797          	auipc	a5,0x139
    80206090:	f9c7b783          	ld	a5,-100(a5) # 8033f028 <plic>
    80206094:	cb85                	beqz	a5,802060c4 <hal_intc_enable_hart+0x3e>
    volatile uint32 *en = (volatile uint32 *)PLIC_SENABLE(hart);
    80206096:	0085151b          	slliw	a0,a0,0x8
    8020609a:	6709                	lui	a4,0x2
    8020609c:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    802060a0:	97ba                	add	a5,a5,a4
    802060a2:	953e                	add	a0,a0,a5
    en[irq / 32] |= (1u << (irq % 32));
    802060a4:	41f5d79b          	sraiw	a5,a1,0x1f
    802060a8:	01b7d79b          	srliw	a5,a5,0x1b
    802060ac:	9fad                	addw	a5,a5,a1
    802060ae:	4057d79b          	sraiw	a5,a5,0x5
    802060b2:	078a                	slli	a5,a5,0x2
    802060b4:	953e                	add	a0,a0,a5
    802060b6:	411c                	lw	a5,0(a0)
    802060b8:	4705                	li	a4,1
    802060ba:	00b7173b          	sllw	a4,a4,a1
    802060be:	8fd9                	or	a5,a5,a4
    802060c0:	2781                	sext.w	a5,a5
    802060c2:	c11c                	sw	a5,0(a0)
}
    802060c4:	6422                	ld	s0,8(sp)
    802060c6:	0141                	addi	sp,sp,16
    802060c8:	8082                	ret

00000000802060ca <hal_intc_claim>:

int hal_intc_claim(void)
{
    802060ca:	1141                	addi	sp,sp,-16
    802060cc:	e422                	sd	s0,8(sp)
    802060ce:	0800                	addi	s0,sp,16
    if (!plic) return 0;
    802060d0:	00139797          	auipc	a5,0x139
    802060d4:	f587b783          	ld	a5,-168(a5) # 8033f028 <plic>
    802060d8:	4501                	li	a0,0
    802060da:	e781                	bnez	a5,802060e2 <hal_intc_claim+0x18>
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
}
    802060dc:	6422                	ld	s0,8(sp)
    802060de:	0141                	addi	sp,sp,16
    802060e0:	8082                	ret
static inline uint64 r_tp(void){ uint64 x; asm volatile("mv %0, tp":"=r"(x)); return x; }
    802060e2:	8712                	mv	a4,tp
    return *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id());
    802060e4:	00d7171b          	slliw	a4,a4,0xd
    802060e8:	002016b7          	lui	a3,0x201
    802060ec:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    802060ee:	97b6                	add	a5,a5,a3
    802060f0:	97ba                	add	a5,a5,a4
    802060f2:	4388                	lw	a0,0(a5)
    802060f4:	b7e5                	j	802060dc <hal_intc_claim+0x12>

00000000802060f6 <hal_intc_complete>:

void hal_intc_complete(int irq)
{
    802060f6:	1141                	addi	sp,sp,-16
    802060f8:	e422                	sd	s0,8(sp)
    802060fa:	0800                	addi	s0,sp,16
    if (!plic) return;
    802060fc:	00139797          	auipc	a5,0x139
    80206100:	f2c7b783          	ld	a5,-212(a5) # 8033f028 <plic>
    80206104:	e781                	bnez	a5,8020610c <hal_intc_complete+0x16>
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
}
    80206106:	6422                	ld	s0,8(sp)
    80206108:	0141                	addi	sp,sp,16
    8020610a:	8082                	ret
    8020610c:	8712                	mv	a4,tp
    *(volatile uint32 *)PLIC_SCLAIM(hal_hart_id()) = irq;
    8020610e:	00d7171b          	slliw	a4,a4,0xd
    80206112:	002016b7          	lui	a3,0x201
    80206116:	0691                	addi	a3,a3,4 # 201004 <_entry-0x7fffeffc>
    80206118:	97b6                	add	a5,a5,a3
    8020611a:	97ba                	add	a5,a5,a4
    8020611c:	2501                	sext.w	a0,a0
    8020611e:	c388                	sw	a0,0(a5)
    80206120:	b7dd                	j	80206106 <hal_intc_complete+0x10>

0000000080206122 <hal_hart_id>:

int hal_hart_id(void) { return (int)r_tp(); }
    80206122:	1141                	addi	sp,sp,-16
    80206124:	e422                	sd	s0,8(sp)
    80206126:	0800                	addi	s0,sp,16
    80206128:	8512                	mv	a0,tp
    8020612a:	2501                	sext.w	a0,a0
    8020612c:	6422                	ld	s0,8(sp)
    8020612e:	0141                	addi	sp,sp,16
    80206130:	8082                	ret

0000000080206132 <plic_dbg>:

int plic_dbg(int which)
{
    80206132:	1141                	addi	sp,sp,-16
    80206134:	e422                	sd	s0,8(sp)
    80206136:	0800                	addi	s0,sp,16
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    80206138:	cd09                	beqz	a0,80206152 <plic_dbg+0x20>
    return *(volatile uint32 *)PLIC_SENABLE(0);
    8020613a:	6709                	lui	a4,0x2
    8020613c:	08070713          	addi	a4,a4,128 # 2080 <_entry-0x801fdf80>
    80206140:	00139797          	auipc	a5,0x139
    80206144:	ee87b783          	ld	a5,-280(a5) # 8033f028 <plic>
    80206148:	97ba                	add	a5,a5,a4
    8020614a:	4388                	lw	a0,0(a5)
}
    8020614c:	6422                	ld	s0,8(sp)
    8020614e:	0141                	addi	sp,sp,16
    80206150:	8082                	ret
    if (which == 0) return *(volatile uint32 *)PLIC_PRIORITY(10);
    80206152:	00139797          	auipc	a5,0x139
    80206156:	ed67b783          	ld	a5,-298(a5) # 8033f028 <plic>
    8020615a:	5788                	lw	a0,40(a5)
    8020615c:	bfc5                	j	8020614c <plic_dbg+0x1a>

000000008020615e <hal_time_read>:
#include "hal.h"
#include "riscv.h"
#include "defs.h"

void    hal_timer_init(void)          { hal_timer_next(1000000); }
uint64  hal_time_read(void)           { return r_time(); }
    8020615e:	1141                	addi	sp,sp,-16
    80206160:	e422                	sd	s0,8(sp)
    80206162:	0800                	addi	s0,sp,16
static inline uint64 r_time(void){ uint64 x; asm volatile("rdtime %0":"=r"(x)); return x; }
    80206164:	c0102573          	rdtime	a0
    80206168:	6422                	ld	s0,8(sp)
    8020616a:	0141                	addi	sp,sp,16
    8020616c:	8082                	ret

000000008020616e <hal_timer_set>:
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    8020616e:	1141                	addi	sp,sp,-16
    80206170:	e406                	sd	ra,8(sp)
    80206172:	e022                	sd	s0,0(sp)
    80206174:	0800                	addi	s0,sp,16
    80206176:	ffffa097          	auipc	ra,0xffffa
    8020617a:	68a080e7          	jalr	1674(ra) # 80200800 <sbi_set_timer>
    8020617e:	60a2                	ld	ra,8(sp)
    80206180:	6402                	ld	s0,0(sp)
    80206182:	0141                	addi	sp,sp,16
    80206184:	8082                	ret

0000000080206186 <hal_timer_ack>:
void    hal_timer_ack(void)           { /* SBI: next set_timer clears STIP */ }
    80206186:	1141                	addi	sp,sp,-16
    80206188:	e422                	sd	s0,8(sp)
    8020618a:	0800                	addi	s0,sp,16
    8020618c:	6422                	ld	s0,8(sp)
    8020618e:	0141                	addi	sp,sp,16
    80206190:	8082                	ret

0000000080206192 <hal_timer_next>:
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    80206192:	1141                	addi	sp,sp,-16
    80206194:	e406                	sd	ra,8(sp)
    80206196:	e022                	sd	s0,0(sp)
    80206198:	0800                	addi	s0,sp,16
    8020619a:	c01027f3          	rdtime	a5
void    hal_timer_set(uint64 dl)      { sbi_set_timer(dl); }
    8020619e:	953e                	add	a0,a0,a5
    802061a0:	ffffa097          	auipc	ra,0xffffa
    802061a4:	660080e7          	jalr	1632(ra) # 80200800 <sbi_set_timer>
void    hal_timer_next(uint64 iv)     { hal_timer_set(hal_time_read() + iv); }
    802061a8:	60a2                	ld	ra,8(sp)
    802061aa:	6402                	ld	s0,0(sp)
    802061ac:	0141                	addi	sp,sp,16
    802061ae:	8082                	ret

00000000802061b0 <hal_timer_init>:
void    hal_timer_init(void)          { hal_timer_next(1000000); }
    802061b0:	1141                	addi	sp,sp,-16
    802061b2:	e406                	sd	ra,8(sp)
    802061b4:	e022                	sd	s0,0(sp)
    802061b6:	0800                	addi	s0,sp,16
    802061b8:	000f4537          	lui	a0,0xf4
    802061bc:	24050513          	addi	a0,a0,576 # f4240 <_entry-0x8010bdc0>
    802061c0:	00000097          	auipc	ra,0x0
    802061c4:	fd2080e7          	jalr	-46(ra) # 80206192 <hal_timer_next>
    802061c8:	60a2                	ld	ra,8(sp)
    802061ca:	6402                	ld	s0,0(sp)
    802061cc:	0141                	addi	sp,sp,16
    802061ce:	8082                	ret

00000000802061d0 <hal_console_init>:
#define LSR 5   /* line status              */
#define LSR_RX_READY  (1 << 0)
#define LSR_TX_IDLE   (1 << 5)

void hal_console_init(uint64 uart_base)
{
    802061d0:	1141                	addi	sp,sp,-16
    802061d2:	e422                	sd	s0,8(sp)
    802061d4:	0800                	addi	s0,sp,16
    uart = (volatile uint8 *)uart_base;
    802061d6:	00139797          	auipc	a5,0x139
    802061da:	e4a7bd23          	sd	a0,-422(a5) # 8033f030 <uart>
    uart[IER] = 0x00;              /* interrupts off while we configure */
    802061de:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x80;              /* DLAB=1: divisor latch visible     */
    802061e2:	f8000793          	li	a5,-128
    802061e6:	00f501a3          	sb	a5,3(a0)
    uart[0]   = 0x03;              /* divisor low: 38.4K                */
    802061ea:	478d                	li	a5,3
    802061ec:	00f50023          	sb	a5,0(a0)
    uart[1]   = 0x00;              /* divisor high                      */
    802061f0:	000500a3          	sb	zero,1(a0)
    uart[LCR] = 0x03;              /* DLAB=0, 8 bits, no parity, 1 stop */
    802061f4:	00f501a3          	sb	a5,3(a0)
    uart[FCR] = 0x07;              /* enable + clear FIFOs              */
    802061f8:	479d                	li	a5,7
    802061fa:	00f50123          	sb	a5,2(a0)
    uart[IER] = 0x01;              /* receive interrupts on             */
    802061fe:	4785                	li	a5,1
    80206200:	00f500a3          	sb	a5,1(a0)
}
    80206204:	6422                	ld	s0,8(sp)
    80206206:	0141                	addi	sp,sp,16
    80206208:	8082                	ret

000000008020620a <hal_console_putc>:

void hal_console_putc(char c)
{
    8020620a:	1141                	addi	sp,sp,-16
    8020620c:	e422                	sd	s0,8(sp)
    8020620e:	0800                	addi	s0,sp,16
    if (!uart) { return; }
    80206210:	00139717          	auipc	a4,0x139
    80206214:	e2073703          	ld	a4,-480(a4) # 8033f030 <uart>
    80206218:	cb01                	beqz	a4,80206228 <hal_console_putc+0x1e>
    while ((uart[LSR] & LSR_TX_IDLE) == 0)   /* wait for the holding reg */
    8020621a:	00574783          	lbu	a5,5(a4)
    8020621e:	0207f793          	andi	a5,a5,32
    80206222:	dfe5                	beqz	a5,8020621a <hal_console_putc+0x10>
        ;
    uart[THR] = c;
    80206224:	00a70023          	sb	a0,0(a4)
}
    80206228:	6422                	ld	s0,8(sp)
    8020622a:	0141                	addi	sp,sp,16
    8020622c:	8082                	ret

000000008020622e <hal_console_getc>:

int hal_console_getc(void)
{
    8020622e:	1141                	addi	sp,sp,-16
    80206230:	e422                	sd	s0,8(sp)
    80206232:	0800                	addi	s0,sp,16
    if (!uart) return -1;
    80206234:	00139717          	auipc	a4,0x139
    80206238:	dfc73703          	ld	a4,-516(a4) # 8033f030 <uart>
    8020623c:	cb11                	beqz	a4,80206250 <hal_console_getc+0x22>
    if (uart[LSR] & LSR_RX_READY)
    8020623e:	00574783          	lbu	a5,5(a4)
    80206242:	8b85                	andi	a5,a5,1
    80206244:	cb81                	beqz	a5,80206254 <hal_console_getc+0x26>
        return uart[RHR];
    80206246:	00074503          	lbu	a0,0(a4)
    return -1;
}
    8020624a:	6422                	ld	s0,8(sp)
    8020624c:	0141                	addi	sp,sp,16
    8020624e:	8082                	ret
    if (!uart) return -1;
    80206250:	557d                	li	a0,-1
    80206252:	bfe5                	j	8020624a <hal_console_getc+0x1c>
    return -1;
    80206254:	557d                	li	a0,-1
    80206256:	bfd5                	j	8020624a <hal_console_getc+0x1c>

0000000080206258 <free_desc>:
    for (int i = 0; i < VNUM; i++)
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    return -1;
}
static void free_desc(int i)
{
    80206258:	1141                	addi	sp,sp,-16
    8020625a:	e406                	sd	ra,8(sp)
    8020625c:	e022                	sd	s0,0(sp)
    8020625e:	0800                	addi	s0,sp,16
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    80206260:	479d                	li	a5,7
    80206262:	04a7c663          	blt	a5,a0,802062ae <free_desc+0x56>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    80206266:	00136797          	auipc	a5,0x136
    8020626a:	d9a78793          	addi	a5,a5,-614 # 8033c000 <vdisk>
    8020626e:	97aa                	add	a5,a5,a0
    80206270:	0287c783          	lbu	a5,40(a5)
    80206274:	e7a9                	bnez	a5,802062be <free_desc+0x66>
    vdisk.desc[i] = (struct virtq_desc){0};
    80206276:	00136797          	auipc	a5,0x136
    8020627a:	d8a78793          	addi	a5,a5,-630 # 8033c000 <vdisk>
    8020627e:	6b98                	ld	a4,16(a5)
    80206280:	00451693          	slli	a3,a0,0x4
    80206284:	9736                	add	a4,a4,a3
    80206286:	00073023          	sd	zero,0(a4)
    8020628a:	00073423          	sd	zero,8(a4)
    vdisk.free[i] = 1;
    8020628e:	97aa                	add	a5,a5,a0
    80206290:	4705                	li	a4,1
    80206292:	02e78423          	sb	a4,40(a5)
    wakeup(&vdisk.free[0]);
    80206296:	00136517          	auipc	a0,0x136
    8020629a:	d9250513          	addi	a0,a0,-622 # 8033c028 <vdisk+0x28>
    8020629e:	ffffc097          	auipc	ra,0xffffc
    802062a2:	c6a080e7          	jalr	-918(ra) # 80201f08 <wakeup>
}
    802062a6:	60a2                	ld	ra,8(sp)
    802062a8:	6402                	ld	s0,0(sp)
    802062aa:	0141                	addi	sp,sp,16
    802062ac:	8082                	ret
    if (i >= VNUM)      panic("virtio_blk: free_desc index");
    802062ae:	00002517          	auipc	a0,0x2
    802062b2:	97a50513          	addi	a0,a0,-1670 # 80207c28 <etext+0xc28>
    802062b6:	ffffa097          	auipc	ra,0xffffa
    802062ba:	348080e7          	jalr	840(ra) # 802005fe <panic>
    if (vdisk.free[i])  panic("virtio_blk: double free_desc");   /* I1 */
    802062be:	00002517          	auipc	a0,0x2
    802062c2:	98a50513          	addi	a0,a0,-1654 # 80207c48 <etext+0xc48>
    802062c6:	ffffa097          	auipc	ra,0xffffa
    802062ca:	338080e7          	jalr	824(ra) # 802005fe <panic>

00000000802062ce <hal_block_irq>:
int hal_block_irq(void) { return vdisk.base ? vdisk.irq : 0; }
    802062ce:	1141                	addi	sp,sp,-16
    802062d0:	e422                	sd	s0,8(sp)
    802062d2:	0800                	addi	s0,sp,16
    802062d4:	00136797          	auipc	a5,0x136
    802062d8:	d2c7b783          	ld	a5,-724(a5) # 8033c000 <vdisk>
    802062dc:	4501                	li	a0,0
    802062de:	c789                	beqz	a5,802062e8 <hal_block_irq+0x1a>
    802062e0:	00136517          	auipc	a0,0x136
    802062e4:	d2852503          	lw	a0,-728(a0) # 8033c008 <vdisk+0x8>
    802062e8:	6422                	ld	s0,8(sp)
    802062ea:	0141                	addi	sp,sp,16
    802062ec:	8082                	ret

00000000802062ee <hal_block_init>:
{
    802062ee:	7139                	addi	sp,sp,-64
    802062f0:	fc06                	sd	ra,56(sp)
    802062f2:	f822                	sd	s0,48(sp)
    802062f4:	f426                	sd	s1,40(sp)
    802062f6:	0080                	addi	s0,sp,64
    initlock(&vdisk.lock, "virtio_blk");
    802062f8:	00002597          	auipc	a1,0x2
    802062fc:	97058593          	addi	a1,a1,-1680 # 80207c68 <etext+0xc68>
    80206300:	00136517          	auipc	a0,0x136
    80206304:	e3850513          	addi	a0,a0,-456 # 8033c138 <vdisk+0x138>
    80206308:	ffffb097          	auipc	ra,0xffffb
    8020630c:	fb0080e7          	jalr	-80(ra) # 802012b8 <initlock>
    for (int i = 0; i < fdt.nvirtio; i++) {
    80206310:	00023797          	auipc	a5,0x23
    80206314:	d907a783          	lw	a5,-624(a5) # 802290a0 <fdt+0x88>
    80206318:	08f05c63          	blez	a5,802063b0 <hal_block_init+0xc2>
    8020631c:	f04a                	sd	s2,32(sp)
    8020631e:	ec4e                	sd	s3,24(sp)
    80206320:	e852                	sd	s4,16(sp)
    80206322:	e456                	sd	s5,8(sp)
    80206324:	e05a                	sd	s6,0(sp)
    80206326:	00023917          	auipc	s2,0x23
    8020632a:	cf290913          	addi	s2,s2,-782 # 80229018 <fdt>
    8020632e:	4481                	li	s1,0
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    80206330:	747279b7          	lui	s3,0x74727
    80206334:	97698993          	addi	s3,s3,-1674 # 74726976 <_entry-0xbad968a>
    80206338:	4a89                	li	s5,2
    8020633a:	4b05                	li	s6,1
    for (int i = 0; i < fdt.nvirtio; i++) {
    8020633c:	8a4a                	mv	s4,s2
    8020633e:	a039                	j	8020634c <hal_block_init+0x5e>
    80206340:	2485                	addiw	s1,s1,1
    80206342:	0921                	addi	s2,s2,8
    80206344:	088a2783          	lw	a5,136(s4)
    80206348:	04f4df63          	bge	s1,a5,802063a6 <hal_block_init+0xb8>
        uint64 va = mmio_alias(fdt.virtio_base[i]);
    8020634c:	02893503          	ld	a0,40(s2)
    80206350:	ffffc097          	auipc	ra,0xffffc
    80206354:	72c080e7          	jalr	1836(ra) # 80202a7c <mmio_alias>
        if (*magic == 0x74726976 && *devid == 2 && (*vers == 1 || *vers == 2)) {
    80206358:	411c                	lw	a5,0(a0)
    8020635a:	2781                	sext.w	a5,a5
    8020635c:	ff3792e3          	bne	a5,s3,80206340 <hal_block_init+0x52>
    80206360:	451c                	lw	a5,8(a0)
    80206362:	2781                	sext.w	a5,a5
    80206364:	fd579ee3          	bne	a5,s5,80206340 <hal_block_init+0x52>
    80206368:	415c                	lw	a5,4(a0)
    8020636a:	2781                	sext.w	a5,a5
    8020636c:	01678663          	beq	a5,s6,80206378 <hal_block_init+0x8a>
    80206370:	415c                	lw	a5,4(a0)
    80206372:	2781                	sext.w	a5,a5
    80206374:	fd5796e3          	bne	a5,s5,80206340 <hal_block_init+0x52>
            vdisk.base    = va;
    80206378:	00136717          	auipc	a4,0x136
    8020637c:	c8870713          	addi	a4,a4,-888 # 8033c000 <vdisk>
    80206380:	e308                	sd	a0,0(a4)
            vdisk.irq     = fdt.virtio_irq[i];
    80206382:	01848793          	addi	a5,s1,24
    80206386:	078a                	slli	a5,a5,0x2
    80206388:	00023697          	auipc	a3,0x23
    8020638c:	c9068693          	addi	a3,a3,-880 # 80229018 <fdt>
    80206390:	97b6                	add	a5,a5,a3
    80206392:	479c                	lw	a5,8(a5)
    80206394:	c71c                	sw	a5,8(a4)
            vdisk.version = *vers;
    80206396:	415c                	lw	a5,4(a0)
    80206398:	c75c                	sw	a5,12(a4)
            break;
    8020639a:	7902                	ld	s2,32(sp)
    8020639c:	69e2                	ld	s3,24(sp)
    8020639e:	6a42                	ld	s4,16(sp)
    802063a0:	6aa2                	ld	s5,8(sp)
    802063a2:	6b02                	ld	s6,0(sp)
    802063a4:	a031                	j	802063b0 <hal_block_init+0xc2>
    802063a6:	7902                	ld	s2,32(sp)
    802063a8:	69e2                	ld	s3,24(sp)
    802063aa:	6a42                	ld	s4,16(sp)
    802063ac:	6aa2                	ld	s5,8(sp)
    802063ae:	6b02                	ld	s6,0(sp)
    if (!vdisk.base) return -1;                   /* no disk on this board */
    802063b0:	00136797          	auipc	a5,0x136
    802063b4:	c507b783          	ld	a5,-944(a5) # 8033c000 <vdisk>
    802063b8:	1a078363          	beqz	a5,8020655e <hal_block_init+0x270>
    *R(VIRTIO_MMIO_STATUS) = 0;
    802063bc:	0607a823          	sw	zero,112(a5)
    *R(VIRTIO_MMIO_STATUS) = status;
    802063c0:	00136797          	auipc	a5,0x136
    802063c4:	c4078793          	addi	a5,a5,-960 # 8033c000 <vdisk>
    802063c8:	6398                	ld	a4,0(a5)
    802063ca:	4685                	li	a3,1
    802063cc:	db34                	sw	a3,112(a4)
    *R(VIRTIO_MMIO_STATUS) = status;
    802063ce:	6398                	ld	a4,0(a5)
    802063d0:	468d                	li	a3,3
    802063d2:	db34                	sw	a3,112(a4)
    uint32 feats = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    802063d4:	6390                	ld	a2,0(a5)
    802063d6:	4a18                	lw	a4,16(a2)
    feats &= ~(1u << VIRTIO_RING_F_EVENT_IDX);
    802063d8:	c7ffe6b7          	lui	a3,0xc7ffe
    802063dc:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <uart+0xffffffff47cbf72f>
    802063e0:	8f75                	and	a4,a4,a3
    *R(VIRTIO_MMIO_DRIVER_FEATURES) = feats;
    802063e2:	d218                	sw	a4,32(a2)
    if (vdisk.version == 2) {
    802063e4:	47d8                	lw	a4,12(a5)
    802063e6:	4789                	li	a5,2
    status |= VIRTIO_CONFIG_S_DRIVER;
    802063e8:	448d                	li	s1,3
    if (vdisk.version == 2) {
    802063ea:	0ef70563          	beq	a4,a5,802064d4 <hal_block_init+0x1e6>
    *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    802063ee:	00136797          	auipc	a5,0x136
    802063f2:	c1278793          	addi	a5,a5,-1006 # 8033c000 <vdisk>
    802063f6:	6398                	ld	a4,0(a5)
    802063f8:	02072823          	sw	zero,48(a4)
    uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    802063fc:	6398                	ld	a4,0(a5)
    802063fe:	5b5c                	lw	a5,52(a4)
    80206400:	2781                	sext.w	a5,a5
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206402:	10078263          	beqz	a5,80206506 <hal_block_init+0x218>
    if (max < VNUM) panic("virtio_blk: queue too short");
    80206406:	469d                	li	a3,7
    80206408:	10f6fc63          	bgeu	a3,a5,80206520 <hal_block_init+0x232>
    *R(VIRTIO_MMIO_QUEUE_NUM) = VNUM;
    8020640c:	47a1                	li	a5,8
    8020640e:	df1c                	sw	a5,56(a4)
    memset(pages, 0, sizeof(pages));
    80206410:	6609                	lui	a2,0x2
    80206412:	4581                	li	a1,0
    80206414:	00137517          	auipc	a0,0x137
    80206418:	bec50513          	addi	a0,a0,-1044 # 8033d000 <pages.0>
    8020641c:	ffffa097          	auipc	ra,0xffffa
    80206420:	288080e7          	jalr	648(ra) # 802006a4 <memset>
    vdisk.desc  = (struct virtq_desc *)pages;
    80206424:	00136797          	auipc	a5,0x136
    80206428:	bdc78793          	addi	a5,a5,-1060 # 8033c000 <vdisk>
    8020642c:	00137717          	auipc	a4,0x137
    80206430:	bd470713          	addi	a4,a4,-1068 # 8033d000 <pages.0>
    80206434:	eb98                	sd	a4,16(a5)
    vdisk.avail = (struct virtq_avail *)(pages + VNUM * sizeof(struct virtq_desc));
    80206436:	00137717          	auipc	a4,0x137
    8020643a:	c4a70713          	addi	a4,a4,-950 # 8033d080 <pages.0+0x80>
    8020643e:	ef98                	sd	a4,24(a5)
    vdisk.used  = (struct virtq_used *)(pages + PGSIZE);
    80206440:	00138717          	auipc	a4,0x138
    80206444:	bc070713          	addi	a4,a4,-1088 # 8033e000 <pages.0+0x1000>
    80206448:	f398                	sd	a4,32(a5)
    if (vdisk.version == 1) {
    8020644a:	47d8                	lw	a4,12(a5)
    8020644c:	4785                	li	a5,1
    8020644e:	0ef70663          	beq	a4,a5,8020653a <hal_block_init+0x24c>
        *R(VIRTIO_MMIO_QUEUE_DESC_LOW)   = (uint64)vdisk.desc;
    80206452:	00136797          	auipc	a5,0x136
    80206456:	bae78793          	addi	a5,a5,-1106 # 8033c000 <vdisk>
    8020645a:	6398                	ld	a4,0(a5)
    8020645c:	00137697          	auipc	a3,0x137
    80206460:	ba468693          	addi	a3,a3,-1116 # 8033d000 <pages.0>
    80206464:	08d72023          	sw	a3,128(a4)
        *R(VIRTIO_MMIO_QUEUE_DESC_HIGH)  = (uint64)vdisk.desc >> 32;
    80206468:	6398                	ld	a4,0(a5)
    8020646a:	4bd4                	lw	a3,20(a5)
    8020646c:	08d72223          	sw	a3,132(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_LOW)  = (uint64)vdisk.avail;
    80206470:	6398                	ld	a4,0(a5)
    80206472:	4f94                	lw	a3,24(a5)
    80206474:	08d72823          	sw	a3,144(a4)
        *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)vdisk.avail >> 32;
    80206478:	6398                	ld	a4,0(a5)
    8020647a:	4fd4                	lw	a3,28(a5)
    8020647c:	08d72a23          	sw	a3,148(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_LOW)  = (uint64)vdisk.used;
    80206480:	6398                	ld	a4,0(a5)
    80206482:	5394                	lw	a3,32(a5)
    80206484:	0ad72023          	sw	a3,160(a4)
        *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)vdisk.used >> 32;
    80206488:	6398                	ld	a4,0(a5)
    8020648a:	53d4                	lw	a3,36(a5)
    8020648c:	0ad72223          	sw	a3,164(a4)
        *R(VIRTIO_MMIO_QUEUE_READY) = 1;
    80206490:	639c                	ld	a5,0(a5)
    80206492:	4705                	li	a4,1
    80206494:	c3f8                	sw	a4,68(a5)
    for (int i = 0; i < VNUM; i++) vdisk.free[i] = 1;
    80206496:	00136797          	auipc	a5,0x136
    8020649a:	b6a78793          	addi	a5,a5,-1174 # 8033c000 <vdisk>
    8020649e:	4705                	li	a4,1
    802064a0:	02e78423          	sb	a4,40(a5)
    802064a4:	02e784a3          	sb	a4,41(a5)
    802064a8:	02e78523          	sb	a4,42(a5)
    802064ac:	02e785a3          	sb	a4,43(a5)
    802064b0:	02e78623          	sb	a4,44(a5)
    802064b4:	02e786a3          	sb	a4,45(a5)
    802064b8:	02e78723          	sb	a4,46(a5)
    802064bc:	02e787a3          	sb	a4,47(a5)
    status |= VIRTIO_CONFIG_S_DRIVER_OK;
    802064c0:	0044e493          	ori	s1,s1,4
    *R(VIRTIO_MMIO_STATUS) = status;
    802064c4:	639c                	ld	a5,0(a5)
    802064c6:	dba4                	sw	s1,112(a5)
    return 0;
    802064c8:	4501                	li	a0,0
}
    802064ca:	70e2                	ld	ra,56(sp)
    802064cc:	7442                	ld	s0,48(sp)
    802064ce:	74a2                	ld	s1,40(sp)
    802064d0:	6121                	addi	sp,sp,64
    802064d2:	8082                	ret
        *R(VIRTIO_MMIO_STATUS) = status;
    802064d4:	00136797          	auipc	a5,0x136
    802064d8:	b2c78793          	addi	a5,a5,-1236 # 8033c000 <vdisk>
    802064dc:	6398                	ld	a4,0(a5)
    802064de:	46ad                	li	a3,11
    802064e0:	db34                	sw	a3,112(a4)
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    802064e2:	639c                	ld	a5,0(a5)
    802064e4:	5bbc                	lw	a5,112(a5)
    802064e6:	8ba1                	andi	a5,a5,8
        status |= VIRTIO_CONFIG_S_FEATURES_OK;
    802064e8:	44ad                	li	s1,11
        if (!(*R(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    802064ea:	f391                	bnez	a5,802063ee <hal_block_init+0x100>
    802064ec:	f04a                	sd	s2,32(sp)
    802064ee:	ec4e                	sd	s3,24(sp)
    802064f0:	e852                	sd	s4,16(sp)
    802064f2:	e456                	sd	s5,8(sp)
    802064f4:	e05a                	sd	s6,0(sp)
            panic("virtio_blk: device rejected our feature set");
    802064f6:	00001517          	auipc	a0,0x1
    802064fa:	78250513          	addi	a0,a0,1922 # 80207c78 <etext+0xc78>
    802064fe:	ffffa097          	auipc	ra,0xffffa
    80206502:	100080e7          	jalr	256(ra) # 802005fe <panic>
    80206506:	f04a                	sd	s2,32(sp)
    80206508:	ec4e                	sd	s3,24(sp)
    8020650a:	e852                	sd	s4,16(sp)
    8020650c:	e456                	sd	s5,8(sp)
    8020650e:	e05a                	sd	s6,0(sp)
    if (max == 0)  panic("virtio_blk: queue 0 does not exist");
    80206510:	00001517          	auipc	a0,0x1
    80206514:	79850513          	addi	a0,a0,1944 # 80207ca8 <etext+0xca8>
    80206518:	ffffa097          	auipc	ra,0xffffa
    8020651c:	0e6080e7          	jalr	230(ra) # 802005fe <panic>
    80206520:	f04a                	sd	s2,32(sp)
    80206522:	ec4e                	sd	s3,24(sp)
    80206524:	e852                	sd	s4,16(sp)
    80206526:	e456                	sd	s5,8(sp)
    80206528:	e05a                	sd	s6,0(sp)
    if (max < VNUM) panic("virtio_blk: queue too short");
    8020652a:	00001517          	auipc	a0,0x1
    8020652e:	7a650513          	addi	a0,a0,1958 # 80207cd0 <etext+0xcd0>
    80206532:	ffffa097          	auipc	ra,0xffffa
    80206536:	0cc080e7          	jalr	204(ra) # 802005fe <panic>
        *R(VIRTIO_MMIO_GUEST_PAGE_SIZE) = PGSIZE;
    8020653a:	00136797          	auipc	a5,0x136
    8020653e:	ac678793          	addi	a5,a5,-1338 # 8033c000 <vdisk>
    80206542:	6394                	ld	a3,0(a5)
    80206544:	6705                	lui	a4,0x1
    80206546:	d698                	sw	a4,40(a3)
        *R(VIRTIO_MMIO_QUEUE_ALIGN)     = PGSIZE;
    80206548:	6394                	ld	a3,0(a5)
    8020654a:	ded8                	sw	a4,60(a3)
        *R(VIRTIO_MMIO_QUEUE_PFN)       = ((uint64)pages) >> 12;
    8020654c:	6398                	ld	a4,0(a5)
    8020654e:	00137797          	auipc	a5,0x137
    80206552:	ab278793          	addi	a5,a5,-1358 # 8033d000 <pages.0>
    80206556:	83b1                	srli	a5,a5,0xc
    80206558:	2781                	sext.w	a5,a5
    8020655a:	c33c                	sw	a5,64(a4)
    8020655c:	bf2d                	j	80206496 <hal_block_init+0x1a8>
    if (!vdisk.base) return -1;                   /* no disk on this board */
    8020655e:	557d                	li	a0,-1
    80206560:	b7ad                	j	802064ca <hal_block_init+0x1dc>

0000000080206562 <hal_block_rw>:
    }
    return 0;
}

void hal_block_rw(struct buf *b, int write)
{
    80206562:	7159                	addi	sp,sp,-112
    80206564:	f486                	sd	ra,104(sp)
    80206566:	f0a2                	sd	s0,96(sp)
    80206568:	eca6                	sd	s1,88(sp)
    8020656a:	e8ca                	sd	s2,80(sp)
    8020656c:	e4ce                	sd	s3,72(sp)
    8020656e:	e0d2                	sd	s4,64(sp)
    80206570:	fc56                	sd	s5,56(sp)
    80206572:	f85a                	sd	s6,48(sp)
    80206574:	f45e                	sd	s7,40(sp)
    80206576:	f062                	sd	s8,32(sp)
    80206578:	ec66                	sd	s9,24(sp)
    8020657a:	1880                	addi	s0,sp,112
    8020657c:	8a2a                	mv	s4,a0
    8020657e:	8cae                	mv	s9,a1
    /* LuitFS blocks are 1024 bytes = two 512-byte disk sectors. */
    uint64 sector = b->blockno * (BSIZE / 512);
    80206580:	00c52c03          	lw	s8,12(a0)
    80206584:	001c1c1b          	slliw	s8,s8,0x1
    80206588:	1c02                	slli	s8,s8,0x20
    8020658a:	020c5c13          	srli	s8,s8,0x20

    acquire(&vdisk.lock);
    8020658e:	00136517          	auipc	a0,0x136
    80206592:	baa50513          	addi	a0,a0,-1110 # 8033c138 <vdisk+0x138>
    80206596:	ffffb097          	auipc	ra,0xffffb
    8020659a:	d9e080e7          	jalr	-610(ra) # 80201334 <acquire>
    for (int i = 0; i < 3; i++) {
    8020659e:	4981                	li	s3,0
    for (int i = 0; i < VNUM; i++)
    802065a0:	44a1                	li	s1,8
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    802065a2:	00136b17          	auipc	s6,0x136
    802065a6:	a5eb0b13          	addi	s6,s6,-1442 # 8033c000 <vdisk>
    for (int i = 0; i < 3; i++) {
    802065aa:	4a8d                	li	s5,3

    int idx[3];
    while (alloc3_desc(idx) != 0)
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    802065ac:	00136b97          	auipc	s7,0x136
    802065b0:	b8cb8b93          	addi	s7,s7,-1140 # 8033c138 <vdisk+0x138>
    while (alloc3_desc(idx) != 0)
    802065b4:	a0ad                	j	8020661e <hal_block_rw+0xbc>
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    802065b6:	00fb0733          	add	a4,s6,a5
    802065ba:	02070423          	sb	zero,40(a4) # 1028 <_entry-0x801fefd8>
        idx[i] = alloc_desc();
    802065be:	c19c                	sw	a5,0(a1)
        if (idx[i] < 0) {
    802065c0:	0207c563          	bltz	a5,802065ea <hal_block_rw+0x88>
    for (int i = 0; i < 3; i++) {
    802065c4:	2905                	addiw	s2,s2,1
    802065c6:	0611                	addi	a2,a2,4 # 2004 <_entry-0x801fdffc>
    802065c8:	05590f63          	beq	s2,s5,80206626 <hal_block_rw+0xc4>
        idx[i] = alloc_desc();
    802065cc:	85b2                	mv	a1,a2
    for (int i = 0; i < VNUM; i++)
    802065ce:	00136717          	auipc	a4,0x136
    802065d2:	a3270713          	addi	a4,a4,-1486 # 8033c000 <vdisk>
    802065d6:	87ce                	mv	a5,s3
        if (vdisk.free[i]) { vdisk.free[i] = 0; return i; }
    802065d8:	02874683          	lbu	a3,40(a4)
    802065dc:	fee9                	bnez	a3,802065b6 <hal_block_rw+0x54>
    for (int i = 0; i < VNUM; i++)
    802065de:	2785                	addiw	a5,a5,1
    802065e0:	0705                	addi	a4,a4,1
    802065e2:	fe979be3          	bne	a5,s1,802065d8 <hal_block_rw+0x76>
        idx[i] = alloc_desc();
    802065e6:	57fd                	li	a5,-1
    802065e8:	c19c                	sw	a5,0(a1)
            for (int j = 0; j < i; j++) free_desc(idx[j]);
    802065ea:	03205163          	blez	s2,8020660c <hal_block_rw+0xaa>
    802065ee:	f9042503          	lw	a0,-112(s0)
    802065f2:	00000097          	auipc	ra,0x0
    802065f6:	c66080e7          	jalr	-922(ra) # 80206258 <free_desc>
    802065fa:	4785                	li	a5,1
    802065fc:	0127d863          	bge	a5,s2,8020660c <hal_block_rw+0xaa>
    80206600:	f9442503          	lw	a0,-108(s0)
    80206604:	00000097          	auipc	ra,0x0
    80206608:	c54080e7          	jalr	-940(ra) # 80206258 <free_desc>
        sleep(&vdisk.free[0], &vdisk.lock);       /* ring full: wait */
    8020660c:	85de                	mv	a1,s7
    8020660e:	00136517          	auipc	a0,0x136
    80206612:	a1a50513          	addi	a0,a0,-1510 # 8033c028 <vdisk+0x28>
    80206616:	ffffb097          	auipc	ra,0xffffb
    8020661a:	76c080e7          	jalr	1900(ra) # 80201d82 <sleep>
    for (int i = 0; i < 3; i++) {
    8020661e:	f9040613          	addi	a2,s0,-112
    80206622:	894e                	mv	s2,s3
    80206624:	b765                	j	802065cc <hal_block_rw+0x6a>

    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80206626:	f9042683          	lw	a3,-112(s0)
    8020662a:	00268793          	addi	a5,a3,2
    8020662e:	0796                	slli	a5,a5,0x5
    req->type     = write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN;
    80206630:	00136597          	auipc	a1,0x136
    80206634:	9d058593          	addi	a1,a1,-1584 # 8033c000 <vdisk>
    80206638:	00569713          	slli	a4,a3,0x5
    8020663c:	972e                	add	a4,a4,a1
    8020663e:	01903633          	snez	a2,s9
    80206642:	c330                	sw	a2,64(a4)
    req->reserved = 0;
    80206644:	04072223          	sw	zero,68(a4)
    req->sector   = sector;
    80206648:	05873423          	sd	s8,72(a4)

    vdisk.desc[idx[0]] = (struct virtq_desc){
    8020664c:	00469613          	slli	a2,a3,0x4
    80206650:	6998                	ld	a4,16(a1)
    80206652:	9732                	add	a4,a4,a2
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80206654:	f9442603          	lw	a2,-108(s0)
    struct virtio_blk_req *req = &vdisk.info[idx[0]].req;
    80206658:	00f58533          	add	a0,a1,a5
    vdisk.desc[idx[0]] = (struct virtq_desc){
    8020665c:	e308                	sd	a0,0(a4)
    8020665e:	4541                	li	a0,16
    80206660:	c708                	sw	a0,8(a4)
    80206662:	4505                	li	a0,1
    80206664:	00a71623          	sh	a0,12(a4)
        (uint64)req, sizeof(*req), VRING_DESC_F_NEXT, (uint16)idx[1] };
    80206668:	00c71723          	sh	a2,14(a4)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    8020666c:	0612                	slli	a2,a2,0x4
    8020666e:	6998                	ld	a4,16(a1)
    80206670:	9732                	add	a4,a4,a2
        (uint64)b->data, BSIZE,
    80206672:	058a0513          	addi	a0,s4,88
        (uint16)((write ? 0 : VRING_DESC_F_WRITE) | VRING_DESC_F_NEXT),
    80206676:	460d                	li	a2,3
    80206678:	000c8363          	beqz	s9,8020667e <hal_block_rw+0x11c>
    8020667c:	4605                	li	a2,1
        (uint16)idx[2] };
    8020667e:	f9842583          	lw	a1,-104(s0)
    vdisk.desc[idx[1]] = (struct virtq_desc){
    80206682:	e308                	sd	a0,0(a4)
    80206684:	40000513          	li	a0,1024
    80206688:	c708                	sw	a0,8(a4)
    8020668a:	00c71623          	sh	a2,12(a4)
        (uint16)idx[2] };
    8020668e:	00b71723          	sh	a1,14(a4)
    vdisk.info[idx[0]].status = 0xff;             /* device overwrites on success */
    80206692:	00136717          	auipc	a4,0x136
    80206696:	96e70713          	addi	a4,a4,-1682 # 8033c000 <vdisk>
    8020669a:	00268613          	addi	a2,a3,2
    8020669e:	0616                	slli	a2,a2,0x5
    802066a0:	963a                	add	a2,a2,a4
    802066a2:	557d                	li	a0,-1
    802066a4:	00a60823          	sb	a0,16(a2)
    vdisk.desc[idx[2]] = (struct virtq_desc){
    802066a8:	0592                	slli	a1,a1,0x4
    802066aa:	6b10                	ld	a2,16(a4)
    802066ac:	962e                	add	a2,a2,a1
        (uint64)&vdisk.info[idx[0]].status, 1, VRING_DESC_F_WRITE, 0 };
    802066ae:	07c1                	addi	a5,a5,16
    802066b0:	97ba                	add	a5,a5,a4
    vdisk.desc[idx[2]] = (struct virtq_desc){
    802066b2:	e21c                	sd	a5,0(a2)
    802066b4:	4585                	li	a1,1
    802066b6:	c60c                	sw	a1,8(a2)
    802066b8:	4789                	li	a5,2
    802066ba:	00f61623          	sh	a5,12(a2)
    802066be:	00061723          	sh	zero,14(a2)

    b->disk = 1;                                  /* I2: device owns b->data */
    802066c2:	00ba2223          	sw	a1,4(s4)
    vdisk.info[idx[0]].b = b;                     /* I3 */
    802066c6:	00569793          	slli	a5,a3,0x5
    802066ca:	97ba                	add	a5,a5,a4
    802066cc:	0347bc23          	sd	s4,56(a5)

    vdisk.avail->ring[vdisk.avail->idx % VNUM] = idx[0];
    802066d0:	6f10                	ld	a2,24(a4)
    802066d2:	00265783          	lhu	a5,2(a2)
    802066d6:	8b9d                	andi	a5,a5,7
    802066d8:	0786                	slli	a5,a5,0x1
    802066da:	963e                	add	a2,a2,a5
    802066dc:	00d61223          	sh	a3,4(a2)
    __sync_synchronize();          /* ring entry visible BEFORE idx bump */
    802066e0:	0ff0000f          	fence
    vdisk.avail->idx += 1;
    802066e4:	6f14                	ld	a3,24(a4)
    802066e6:	0026d783          	lhu	a5,2(a3)
    802066ea:	2785                	addiw	a5,a5,1
    802066ec:	00f69123          	sh	a5,2(a3)
    __sync_synchronize();          /* idx visible BEFORE the doorbell    */
    802066f0:	0ff0000f          	fence
    *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0;
    802066f4:	631c                	ld	a5,0(a4)
    802066f6:	0407a823          	sw	zero,80(a5)

    while (b->disk == 1)
    802066fa:	004a2783          	lw	a5,4(s4)
    802066fe:	02b79163          	bne	a5,a1,80206720 <hal_block_rw+0x1be>
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    80206702:	00136917          	auipc	s2,0x136
    80206706:	a3690913          	addi	s2,s2,-1482 # 8033c138 <vdisk+0x138>
    while (b->disk == 1)
    8020670a:	4485                	li	s1,1
        sleep(b, &vdisk.lock);                    /* intr handler wakes us */
    8020670c:	85ca                	mv	a1,s2
    8020670e:	8552                	mv	a0,s4
    80206710:	ffffb097          	auipc	ra,0xffffb
    80206714:	672080e7          	jalr	1650(ra) # 80201d82 <sleep>
    while (b->disk == 1)
    80206718:	004a2783          	lw	a5,4(s4)
    8020671c:	fe9788e3          	beq	a5,s1,8020670c <hal_block_rw+0x1aa>

    vdisk.info[idx[0]].b = 0;
    80206720:	f9042503          	lw	a0,-112(s0)
    80206724:	00551713          	slli	a4,a0,0x5
    80206728:	00136797          	auipc	a5,0x136
    8020672c:	8d878793          	addi	a5,a5,-1832 # 8033c000 <vdisk>
    80206730:	97ba                	add	a5,a5,a4
    80206732:	0207bc23          	sd	zero,56(a5)
    free_desc(idx[0]); free_desc(idx[1]); free_desc(idx[2]);
    80206736:	00000097          	auipc	ra,0x0
    8020673a:	b22080e7          	jalr	-1246(ra) # 80206258 <free_desc>
    8020673e:	f9442503          	lw	a0,-108(s0)
    80206742:	00000097          	auipc	ra,0x0
    80206746:	b16080e7          	jalr	-1258(ra) # 80206258 <free_desc>
    8020674a:	f9842503          	lw	a0,-104(s0)
    8020674e:	00000097          	auipc	ra,0x0
    80206752:	b0a080e7          	jalr	-1270(ra) # 80206258 <free_desc>

    release(&vdisk.lock);
    80206756:	00136517          	auipc	a0,0x136
    8020675a:	9e250513          	addi	a0,a0,-1566 # 8033c138 <vdisk+0x138>
    8020675e:	ffffb097          	auipc	ra,0xffffb
    80206762:	c8a080e7          	jalr	-886(ra) # 802013e8 <release>
}
    80206766:	70a6                	ld	ra,104(sp)
    80206768:	7406                	ld	s0,96(sp)
    8020676a:	64e6                	ld	s1,88(sp)
    8020676c:	6946                	ld	s2,80(sp)
    8020676e:	69a6                	ld	s3,72(sp)
    80206770:	6a06                	ld	s4,64(sp)
    80206772:	7ae2                	ld	s5,56(sp)
    80206774:	7b42                	ld	s6,48(sp)
    80206776:	7ba2                	ld	s7,40(sp)
    80206778:	7c02                	ld	s8,32(sp)
    8020677a:	6ce2                	ld	s9,24(sp)
    8020677c:	6165                	addi	sp,sp,112
    8020677e:	8082                	ret

0000000080206780 <hal_block_intr>:

void hal_block_intr(void)
{
    80206780:	1101                	addi	sp,sp,-32
    80206782:	ec06                	sd	ra,24(sp)
    80206784:	e822                	sd	s0,16(sp)
    80206786:	e426                	sd	s1,8(sp)
    80206788:	1000                	addi	s0,sp,32
    acquire(&vdisk.lock);
    8020678a:	00136497          	auipc	s1,0x136
    8020678e:	87648493          	addi	s1,s1,-1930 # 8033c000 <vdisk>
    80206792:	00136517          	auipc	a0,0x136
    80206796:	9a650513          	addi	a0,a0,-1626 # 8033c138 <vdisk+0x138>
    8020679a:	ffffb097          	auipc	ra,0xffffb
    8020679e:	b9a080e7          	jalr	-1126(ra) # 80201334 <acquire>

    /* Ack FIRST: a completion that lands after this read re-raises the
     * interrupt instead of being lost. */
    *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    802067a2:	6098                	ld	a4,0(s1)
    802067a4:	533c                	lw	a5,96(a4)
    802067a6:	8b8d                	andi	a5,a5,3
    802067a8:	d37c                	sw	a5,100(a4)
    __sync_synchronize();
    802067aa:	0ff0000f          	fence

    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    802067ae:	709c                	ld	a5,32(s1)
    802067b0:	0304d703          	lhu	a4,48(s1)
    802067b4:	0027d783          	lhu	a5,2(a5)
    802067b8:	04f70e63          	beq	a4,a5,80206814 <hal_block_intr+0x94>
    802067bc:	e04a                	sd	s2,0(sp)

        if (vdisk.info[id].status != 0)
            panic("virtio_blk: request failed (status byte nonzero)");

        struct buf *b = vdisk.info[id].b;
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    802067be:	4905                	li	s2,1
        __sync_synchronize();
    802067c0:	0ff0000f          	fence
        int id = vdisk.used->ring[vdisk.used_idx % VNUM].id;
    802067c4:	7098                	ld	a4,32(s1)
    802067c6:	0304d783          	lhu	a5,48(s1)
    802067ca:	8b9d                	andi	a5,a5,7
    802067cc:	078e                	slli	a5,a5,0x3
    802067ce:	97ba                	add	a5,a5,a4
    802067d0:	43dc                	lw	a5,4(a5)
        if (vdisk.info[id].status != 0)
    802067d2:	00278713          	addi	a4,a5,2
    802067d6:	0716                	slli	a4,a4,0x5
    802067d8:	9726                	add	a4,a4,s1
    802067da:	01074703          	lbu	a4,16(a4)
    802067de:	eb21                	bnez	a4,8020682e <hal_block_intr+0xae>
        struct buf *b = vdisk.info[id].b;
    802067e0:	0796                	slli	a5,a5,0x5
    802067e2:	97a6                	add	a5,a5,s1
    802067e4:	7f88                	ld	a0,56(a5)
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    802067e6:	cd21                	beqz	a0,8020683e <hal_block_intr+0xbe>
    802067e8:	415c                	lw	a5,4(a0)
    802067ea:	05279a63          	bne	a5,s2,8020683e <hal_block_intr+0xbe>
        b->disk = 0;                              /* I2: hart owns data again */
    802067ee:	00052223          	sw	zero,4(a0)
        wakeup(b);
    802067f2:	ffffb097          	auipc	ra,0xffffb
    802067f6:	716080e7          	jalr	1814(ra) # 80201f08 <wakeup>

        vdisk.used_idx += 1;
    802067fa:	0304d783          	lhu	a5,48(s1)
    802067fe:	2785                	addiw	a5,a5,1
    80206800:	17c2                	slli	a5,a5,0x30
    80206802:	93c1                	srli	a5,a5,0x30
    80206804:	02f49823          	sh	a5,48(s1)
    while (vdisk.used_idx != vdisk.used->idx) {   /* may batch completions */
    80206808:	7098                	ld	a4,32(s1)
    8020680a:	00275703          	lhu	a4,2(a4)
    8020680e:	faf719e3          	bne	a4,a5,802067c0 <hal_block_intr+0x40>
    80206812:	6902                	ld	s2,0(sp)
    }
    release(&vdisk.lock);
    80206814:	00136517          	auipc	a0,0x136
    80206818:	92450513          	addi	a0,a0,-1756 # 8033c138 <vdisk+0x138>
    8020681c:	ffffb097          	auipc	ra,0xffffb
    80206820:	bcc080e7          	jalr	-1076(ra) # 802013e8 <release>
}
    80206824:	60e2                	ld	ra,24(sp)
    80206826:	6442                	ld	s0,16(sp)
    80206828:	64a2                	ld	s1,8(sp)
    8020682a:	6105                	addi	sp,sp,32
    8020682c:	8082                	ret
            panic("virtio_blk: request failed (status byte nonzero)");
    8020682e:	00001517          	auipc	a0,0x1
    80206832:	4c250513          	addi	a0,a0,1218 # 80207cf0 <etext+0xcf0>
    80206836:	ffffa097          	auipc	ra,0xffffa
    8020683a:	dc8080e7          	jalr	-568(ra) # 802005fe <panic>
        if (!b || b->disk != 1) panic("virtio_blk: completion for idle buf");
    8020683e:	00001517          	auipc	a0,0x1
    80206842:	4ea50513          	addi	a0,a0,1258 # 80207d28 <etext+0xd28>
    80206846:	ffffa097          	auipc	ra,0xffffa
    8020684a:	db8080e7          	jalr	-584(ra) # 802005fe <panic>
