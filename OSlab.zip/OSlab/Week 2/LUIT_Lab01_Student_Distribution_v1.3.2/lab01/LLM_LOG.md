# Lab 1 AI/LLM Use Log

Name: Karyampudi Komal
Roll number: 240101041

## Entry 1
- Tool/model: Antigravity AI Assistant (Gemini)
- Question asked: Can you review my code in pingpong.c to ensure I am closing all unused pipe ends correctly?
- Advice used: The AI confirmed my understanding of pipe ownership and reminded me to always verify the return values of read and write system calls.
- Files/sections affected: user/pingpong.c
- How I independently verified it: I tested the pingpong program manually in QEMU and ran `make grade` to ensure there were no hangs or deadlocks.

## Entry 2
- Tool/model: Antigravity AI Assistant (Gemini)
- Question asked: Can you explain how the RISC-V `ecall` instruction interacts with the `sepc` register when tracing the system call path in GDB?
- Advice used: The AI explained that `ecall` saves the current PC into `sepc` and jumps to the trap handler, and that the kernel must advance `sepc` by 4 to skip the instruction before returning. I used this conceptual explanation to write the final GDB trace explanation.
- Files/sections affected: lab01/gdb-trace.txt, lab01/report.tex (Q8)
- How I independently verified it: I observed the value of `sepc` in GDB during my trace (`0x17e2`) and confirmed that the saved `epc` in the trapframe was incremented by 4 bytes (`0x17e6`).
