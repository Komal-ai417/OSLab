LUIT LAB 1 SUBMISSION

Name              : Karyampudi Komal
Roll number       : 240101041
Laboratory section: Lab 1
IITG email        : k.karyampudi@iitg.ac.in

Declaration:
I confirm that this submission is my own work. I have listed all permitted
AI/LLM use in LLM_LOG.md and have not included code copied from another
student or a public xv6/Luit solution.
