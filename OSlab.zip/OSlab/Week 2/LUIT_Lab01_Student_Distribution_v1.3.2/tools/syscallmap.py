#!/usr/bin/env python3
"""Lab 1 starter: verify Luit's generated syscall ABI.

Complete the marked TODO sections. Use only the Python 3 standard library.
Run this program from anywhere; paths are resolved from the repository root.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SYSCALL_TABLE = ROOT / "kernel" / "syscall.tbl"
SYSCALL_NUMBERS = ROOT / "kernel" / "syscallnums.h"
SYSCALL_DISPATCH = ROOT / "kernel" / "syscalltab.h"
USER_STUBS = ROOT / "user" / "usys.S"


class InputError(ValueError):
    """Expected malformed/missing ABI input; display without a traceback."""


def parse_syscall_table(path: Path) -> list[tuple[int, str, str]]:
    """Return (number, user_name, kernel_handler) rows."""
    # TODO-BEGIN A1: parse comments/blank lines and validate every row.
    table = []
    content = path.read_text()
    for line in content.splitlines():
        # Remove comments and strip whitespace
        clean_line = line.split('#', 1)[0].strip()
        if not clean_line:
            continue
            
        parts = clean_line.split()
        if len(parts) != 3:
            raise InputError(f"malformed row (expected 3 columns): {line}")
            
        try:
            num = int(parts[0])
        except ValueError:
            raise InputError(f"malformed row (invalid number): {line}")
            
        table.append((num, parts[1], parts[2]))
        
    return table
    # TODO-END A1


def parse_syscall_numbers(path: Path) -> tuple[dict[str, int], int]:
    """Return SYS_name definitions and NSYSCALL."""
    # TODO-BEGIN A2: parse generated #define lines.
    numbers = {}
    nsyscall = 0
    content = path.read_text()
    for line in content.splitlines():
        # Match #define SYS_name number
        m_sys = re.search(r'#define\s+SYS_([a-zA-Z0-9_]+)\s+(\d+)', line)
        if m_sys:
            numbers[m_sys.group(1)] = int(m_sys.group(2))
        else:
            # Match #define NSYSCALL number
            m_nsys = re.search(r'#define\s+NSYSCALL\s+(\d+)', line)
            if m_nsys:
                nsyscall = int(m_nsys.group(1))
                
    return numbers, nsyscall
    # TODO-END A2


def parse_syscalltab(path: Path) -> tuple[dict[int, str], dict[int, str]]:
    """Return dispatch handlers and syscall_names entries indexed by number."""
    # TODO-BEGIN A3: parse both generated arrays in syscalltab.h.
    handlers = {}
    names = {}
    
    # Helper to resolve SYS_ macros to integers if they are used as array indices
    sys_to_num = {}
    nums_path = path.parent / "syscallnums.h"
    if nums_path.exists():
        for line in nums_path.read_text().splitlines():
            m = re.search(r'#define\s+(SYS_[a-zA-Z0-9_]+)\s+(\d+)', line)
            if m:
                sys_to_num[m.group(1)] = int(m.group(2))

    content = path.read_text()
    for line in content.splitlines():
        # Parse handlers: [1] = sys_fork or [SYS_fork] = sys_fork
        m_hand = re.search(r'\[\s*(SYS_[a-zA-Z0-9_]+|\d+)\s*\]\s*=?\s*(sys_[a-zA-Z0-9_]+)', line)
        if m_hand:
            idx_str = m_hand.group(1)
            idx = int(idx_str) if idx_str.isdigit() else sys_to_num.get(idx_str, -1)
            handlers[idx] = m_hand.group(2)
            
        # Parse names: [1] = "fork" or [SYS_fork] = "fork"
        m_name = re.search(r'\[\s*(SYS_[a-zA-Z0-9_]+|\d+)\s*\]\s*=?\s*"([^"]+)"', line)
        if m_name:
            idx_str = m_name.group(1)
            idx = int(idx_str) if idx_str.isdigit() else sys_to_num.get(idx_str, -1)
            names[idx] = m_name.group(2)
            
    return handlers, names
    # TODO-END A3


def parse_user_stubs(path: Path) -> dict[str, int]:
    """Return generated SYSCALL name, number stubs."""
    # TODO-BEGIN A4: parse every generated SYSCALL invocation.
    stubs = {}
    
    # Helper to resolve SYS_ macros to integers if they are used in the stubs
    sys_to_num = {}
    nums_path = path.parent.parent / "kernel" / "syscallnums.h"
    if nums_path.exists():
        for line in nums_path.read_text().splitlines():
            m = re.search(r'#define\s+(SYS_[a-zA-Z0-9_]+)\s+(\d+)', line)
            if m:
                sys_to_num[m.group(1)] = int(m.group(2))

    content = path.read_text()
    for line in content.splitlines():
        clean_line = line.strip()
        
        # Skip macro definitions, preprocessor directives, and comments
        if clean_line.startswith(('#', '.macro', '//', '/*')):
            continue

        # Match two-argument macro/invocation: SYSCALL(name, number) or SYSCALL name, number
        m2 = re.search(r'SYSCALL\s*\(\s*([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)\s*\)', clean_line)
        if not m2:
            m2 = re.search(r'SYSCALL\s+([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)', clean_line)
            
        if m2:
            name = m2.group(1)
            val = m2.group(2)
            if val.isdigit():
                stubs[name] = int(val)
            else:
                stubs[name] = sys_to_num.get(val, -1)
        else:
            # Fallback for single-argument macro/invocation: SYSCALL(name) or SYSCALL name
            m1 = re.search(r'SYSCALL\s*\(\s*([a-zA-Z0-9_]+)\s*\)', clean_line)
            if not m1:
                m1 = re.search(r'SYSCALL\s+([a-zA-Z0-9_]+)', clean_line)
            if m1:
                name = m1.group(1)
                stubs[name] = sys_to_num.get(f"SYS_{name}", -1)
                
    return stubs
    # TODO-END A4


def validate(
    table: list[tuple[int, str, str]],
    numbers: dict[str, int],
    nsyscall: int,
    handlers: dict[int, str],
    names: dict[int, str],
    stubs: dict[str, int],
) -> list[str]:
    """Return every detected consistency error; do not stop at the first."""
    errors: list[str] = []

    # TODO-BEGIN A5:
    # Check duplicate/non-positive table entries, NSYSCALL, missing/mismatched
    # generated values, and every extra generated value not present in the
    # source table. Append clear messages to errors.
    seen_nums = set()
    seen_names = set()
    highest_num = 0

    for num, name, handler in table:
        # Check non-positive syscall numbers
        if num <= 0:
            errors.append(f"non-positive syscall number in table: {num}")
            
        # Check duplicate syscall numbers
        if num in seen_nums:
            errors.append(f"duplicate syscall number in table: {num}")
        seen_nums.add(num)
        
        # Check duplicate syscall names
        if name in seen_names:
            errors.append(f"duplicate syscall name in table: {name}")
        seen_names.add(name)
        
        if num > highest_num:
            highest_num = num

        # Missing or incorrect #define SYS_name number in syscallnums.h
        if numbers.get(name) != num:
            errors.append(f"missing or incorrect SYS_{name} in syscallnums.h")

        # Missing or mismatched kernel handler entry in syscalltab.h
        if handlers.get(num) != handler:
            errors.append(f"missing or mismatched handler for '{name}' ({num}) in syscalltab.h")

        # Missing or mismatched syscall-name entry in syscalltab.h
        if names.get(num) != name:
            errors.append(f"missing or mismatched name entry for '{name}' ({num}) in syscalltab.h")
            
        # Missing or mismatched SYSCALL name, number stub in usys.S
        if stubs.get(name) != num:
            errors.append(f"missing or mismatched stub for '{name}' ({num}) in usys.S")

    # Check incorrect NSYSCALL (must be one greater than highest assigned number)
    expected_nsyscall = highest_num + 1 if highest_num > 0 else 1
    if nsyscall != expected_nsyscall:
        errors.append(f"incorrect NSYSCALL: got {nsyscall}, expected {expected_nsyscall}")

    # Check for extra generated values not present in the source table
    for name in numbers:
        if name not in seen_names:
            errors.append(f"extra SYS_{name} macro in syscallnums.h not in source table")
    for num in handlers:
        if num not in seen_nums:
            errors.append(f"extra handler for number {num} in syscalltab.h not in source table")
    for num in names:
        if num not in seen_nums:
            errors.append(f"extra name entry for number {num} in syscalltab.h not in source table")
    for name in stubs:
        if name not in seen_names:
            errors.append(f"extra stub for '{name}' in usys.S not in source table")
    # TODO-END A5

    return errors


def print_map(
    table: list[tuple[int, str, str]], nsyscall: int, stubs: dict[str, int]
) -> None:
    """Print every number from 1 through NSYSCALL-1, including gaps."""
    # TODO-BEGIN A6: derive and print the table; do not hardcode ABI values.
    print(f"{'NUM':<6} {'NAME':<10} {'HANDLER':<14} USER-STUB")
    
    table_dict = {num: (name, handler) for num, name, handler in table}
    
    # Limit handles both correct nsyscall and gracefully continues if nsyscall is broken
    highest_in_table = max((num for num, _, _ in table), default=0)
    limit = max(nsyscall, highest_in_table + 1)
    
    for i in range(1, limit):
        if i in table_dict:
            name, handler = table_dict[i]
            has_stub = "yes" if stubs.get(name) == i else "no"
            print(f"{i:<6} {name:<10} {handler:<14} {has_stub}")
        else:
            print(f"{i:<6} <unused>")
    # TODO-END A6


def main() -> int:
    try:
        table = parse_syscall_table(SYSCALL_TABLE)
        numbers, nsyscall = parse_syscall_numbers(SYSCALL_NUMBERS)
        handlers, names = parse_syscalltab(SYSCALL_DISPATCH)
        stubs = parse_user_stubs(USER_STUBS)
        errors = validate(table, numbers, nsyscall, handlers, names, stubs)
    except FileNotFoundError as error:
        print(
            f"syscallmap: missing {error.filename}; run `make` first",
            file=sys.stderr,
        )
        return 2
    except (InputError, OSError) as error:
        print(f"syscallmap: {error}", file=sys.stderr)
        return 2
    except NotImplementedError as error:
        print(f"syscallmap: starter incomplete: {error}", file=sys.stderr)
        return 2

    print_map(table, nsyscall, stubs)

    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        print(f"syscallmap: ABI invalid ({len(errors)} error(s))", file=sys.stderr)
        return 1

    highest = max(number for number, _, _ in table)
    gaps = (nsyscall - 1) - len(table)
    gap_str = f"{gaps} gap" if gaps == 1 else f"{gaps} gaps"
    print(
        f"syscallmap: ABI valid ({len(table)} calls, "
        f"highest number {highest}, {gap_str})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
