// F1 minimal reproducer: fast_realloc large in-place-shrink early-return skips
// the FASTALLOC_DEBUG registry/red-zone update -> false-positive "BUFFER
// OVERFLOW" fatal on a fully legitimate workload.
// Sequence: big alloc -> free -> smaller alloc reuses the span (class-fit) ->
// realloc to a size that requests a >=1page shrink of a POOL-BACKED span ->
// early return (span kept, registry NOT updated) -> user writes new_size
// bytes (legal: the span holds it) -> free -> FATAL false positive.
#include "fast_alloc.h"
#include "fast_alloc_config.h"
#include <cstdio>
#include <cstring>

using namespace FastAlloc;

int main() {
    std::printf("step1: alloc 4194304 (pooled span, ~1.95MB)\n");
    void* p = fast_malloc(4194304);
    if (!p) { std::printf("alloc failed\n"); return 1; }
    std::memset(p, 1, 4194304);
    std::printf("step2: free -> TLS large cache\n");
    fast_free(p);

    std::printf("step3: alloc 2621440 (served from large cache, same span, class-fit)\n");
    p = fast_malloc(2621440);
    if (!p) { std::printf("alloc failed\n"); return 1; }
    if (p == nullptr) return 1;
    std::memset(p, 2, 2621440);

    std::printf("step4: realloc -> 2500000 (<= span usable, diff >= page: shrink path)\n");
    void* q = fast_realloc(p, 2500000);
    if (!q) { std::printf("realloc failed\n"); return 1; }
    std::printf("step5: user writes all 2500000 bytes (legal - span holds it)\n");
    std::memset(q, 3, 2500000);
    std::printf("step6: free -> if F1 fires, this aborts with a false-positive overflow\n");
    fast_free(q);
    std::printf("NO FATAL: F1 did not reproduce on this path\n");
    return 0;
}
