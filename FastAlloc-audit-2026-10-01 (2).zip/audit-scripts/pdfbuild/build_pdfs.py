#!/usr/bin/env python3
"""Build the two FastAlloc audit PDFs (body via ReportLab + cover merge).

Numbering map (Step 3.5, mandatory):
  | Outline | Type    | Chapter # | Title                              |
  |---------|---------|-----------|------------------------------------|
  | 1       | cover   | -         | Cover (HTML/Playwright, page 0)    |
  | 2       | toc     | -         | Table of Contents                  |
  | 3+      | content | 1..N      | AUDIT.md sections 1..14 / Phases   |
Body chapters always start at 1 (source sections already numbered from 1).
Page breaks: ONLY cover->TOC (inherent via merge) and TOC->body (one PageBreak).
Body flows continuously; CondPageBreak only for anti-orphan heading protection.
"""
import hashlib
import os
import re
import sys

SKILL = '/home/z/my-project/skills/pdf'
sys.path.insert(0, os.path.join(SKILL, 'scripts'))

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (CondPageBreak, HRFlowable, KeepTogether,
                                PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle, XPreformatted)
from reportlab.platypus.tableofcontents import TableOfContents

# ---------------------------------------------------------------- fonts ----
FF = '/usr/share/fonts/truetype/freefont'
DJ = '/usr/share/fonts/truetype/dejavu'
pdfmetrics.registerFont(TTFont('FreeSerif', f'{FF}/FreeSerif.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Bold', f'{FF}/FreeSerifBold.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Italic', f'{FF}/FreeSerifItalic.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-BoldItalic', f'{FF}/FreeSerifBoldItalic.ttf'))
registerFontFamily('FreeSerif', normal='FreeSerif', bold='FreeSerif-Bold',
                   italic='FreeSerif-Italic', boldItalic='FreeSerif-BoldItalic')
pdfmetrics.registerFont(TTFont('DejaVuSansMono', f'{DJ}/DejaVuSansMono.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', f'{DJ}/DejaVuSans.ttf'))
registerFontFamily('DejaVuSansMono', normal='DejaVuSansMono', bold='DejaVuSansMono')

from pdf import install_font_fallback  # noqa: E402  (skill helper)
install_font_fallback()

# ------------------------------------------------------------- palettes ----
# cascade seed 7 (audit) and seed 11 (explanation) - pasted verbatim from
# `pdf.py palette.cascade --format reportlab`
PAL_AUDIT = dict(
    PAGE_BG='#ffffff', SECTION_BG='#f2f1f0', CARD_BG='#e8e7e4', TABLE_STRIPE='#eeedeb',
    HEADER_FILL='#504933', COVER_BLOCK='#867b5a', BORDER='#cfcab8', ICON='#8c7e52',
    ACCENT='#87702a', TEXT_PRIMARY='#1c1c1a', TEXT_MUTED='#78766f')
PAL_EXPL = dict(
    PAGE_BG='#ffffff', SECTION_BG='#edeeef', CARD_BG='#e8eaeb', TABLE_STRIPE='#eff0f0',
    HEADER_FILL='#405f6f', COVER_BLOCK='#49616d', BORDER='#c0ccd2', ICON='#467f9c',
    ACCENT='#227fad', TEXT_PRIMARY='#1b1c1d', TEXT_MUTED='#838a8d')
for _p in (PAL_AUDIT, PAL_EXPL):
    for _k, _v in _p.items():
        _p[_k] = colors.HexColor(_v)

PAGE_W, PAGE_H = A4
LM = RM = 0.9 * inch
TM, BM = 0.85 * inch, 0.85 * inch
AVAIL_W = PAGE_W - LM - RM  # ~466pt


# -------------------------------------------------------------- styles ----
def make_styles(pal):
    base = dict(fontName='FreeSerif', textColor=pal['TEXT_PRIMARY'],
                leading=14.5, alignment=0, spaceAfter=7)
    s = {}
    s['body'] = ParagraphStyle('body', fontSize=10.5, **base)
    s['bullet'] = ParagraphStyle('bullet', parent=s['body'], leftIndent=16,
                                 bulletIndent=4, spaceAfter=4)
    s['bullet2'] = ParagraphStyle('bullet2', parent=s['body'], leftIndent=32,
                                  bulletIndent=20, spaceAfter=3)
    s['quote'] = ParagraphStyle('quote', parent=s['body'], fontSize=10,
                                leftIndent=14, textColor=pal['TEXT_MUTED'],
                                fontName='FreeSerif-Italic', spaceBefore=4)
    s['h1'] = ParagraphStyle('h1', fontName='FreeSerif-Bold', fontSize=17,
                             textColor=pal['HEADER_FILL'], leading=21,
                             spaceBefore=16, spaceAfter=9)
    s['h2'] = ParagraphStyle('h2', fontName='FreeSerif-Bold', fontSize=13.5,
                             textColor=pal['HEADER_FILL'], leading=17,
                             spaceBefore=13, spaceAfter=6)
    s['h3'] = ParagraphStyle('h3', fontName='FreeSerif-Bold', fontSize=11.5,
                             textColor=pal['TEXT_PRIMARY'], leading=15,
                             spaceBefore=10, spaceAfter=5)
    s['code'] = ParagraphStyle('code', fontName='DejaVuSansMono', fontSize=7,
                               leading=9.2, textColor=pal['TEXT_PRIMARY'],
                               backColor=pal['CARD_BG'], leftIndent=6,
                               rightIndent=6, topPadding=5, bottomPadding=5,
                               spaceBefore=6, spaceAfter=8, alignment=0)
    s['cell'] = ParagraphStyle('cell', parent=s['body'], fontSize=9,
                               leading=11.5, spaceAfter=0)
    s['cellh'] = ParagraphStyle('cellh', parent=s['cell'],
                                fontName='FreeSerif-Bold',
                                textColor=colors.white)
    s['toc0'] = ParagraphStyle('toc0', fontName='FreeSerif-Bold', fontSize=11,
                               textColor=pal['TEXT_PRIMARY'], leftIndent=2,
                               leading=15, spaceBefore=6)
    s['toc1'] = ParagraphStyle('toc1', fontName='FreeSerif', fontSize=9.5,
                               textColor=pal['TEXT_MUTED'], leftIndent=18,
                               leading=13, spaceBefore=2)
    return s


# ----------------------------------------------------- inline conversion ----
_AMP, _LT, _GT = chr(38), chr(60), chr(62)


def esc(t):
    if not isinstance(t, str):
        t = str(t)
    return (t.replace(_AMP, _AMP + 'amp;')
             .replace(_LT, _AMP + 'lt;')
             .replace(_GT, _AMP + 'gt;'))


def inline(t):
    """markdown inline -> reportlab tags. Backtick spans are stashed FIRST so
    their contents (which may contain * or _) never feed the emphasis regexes."""
    t = esc(t)
    codes = []

    def _stash(m):
        codes.append(m.group(1))
        return '\x00%d\x00' % (len(codes) - 1)

    t = re.sub(r'`([^`\n]+?)`', _stash, t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<!\*)\*([^*\n]+?)\*(?!\*)', r'<i>\1</i>', t)
    # em-dash must never start a line (pdf_qa punctuation rule): bind it to
    # the preceding word with a no-break space.
    t = t.replace(' \u2014 ', '\u00a0\u2014 ')
    for idx, c in enumerate(codes):
        t = t.replace('\x00%d\x00' % idx,
                      '<font face="DejaVuSansMono" size="8.5">%s</font>' % c)
    return t


# --------------------------------------------------------- md -> story ----
def md_to_story(md_path, pal, styles):
    raw = open(md_path, encoding='utf-8').read()
    lines = raw.split('\n')
    story = []
    first_h1_done = False
    i = 0
    n = len(lines)

    def add_heading(text, style, level):
        key = 'h_' + hashlib.md5(text.encode()).hexdigest()[:8]
        p = Paragraph(f'<a name="{key}"/>{inline(text)}', style)
        p.bookmark_name = key
        p.bookmark_level = level
        p.bookmark_text = re.sub(r'[`*]', '', text)
        p.bookmark_key = key
        return p

    while i < n:
        ln = lines[i]
        s = ln.strip()
        # ---- fenced code block
        if s.startswith('```'):
            buf = []
            i += 1
            while i < n and not lines[i].strip().startswith('```'):
                buf.append(lines[i])
                i += 1
            i += 1
            story.append(XPreformatted(esc('\n'.join(buf)), styles['code']))
            continue
        # ---- table
        if s.startswith('|') and i + 1 < n and re.match(r'^\|[\s:|-]+\|?\s*$', lines[i + 1].strip()):
            hdr = [c.strip() for c in s.strip('|').split('|')]
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith('|'):
                rows.append([c.strip() for c in lines[i].strip().strip('|').split('|')])
                i += 1
            story.append(build_table(hdr, rows, pal, styles))
            story.append(Spacer(1, 4))
            continue
        # ---- horizontal rule
        if re.match(r'^-{3,}$', s):
            story.append(HRFlowable(width='100%', thickness=0.6,
                                    color=pal['BORDER'], spaceBefore=6, spaceAfter=6))
            i += 1
            continue
        # ---- headings
        m = re.match(r'^(#{1,3})\s+(.*)', s)
        if m:
            lvl, txt = len(m.group(1)), m.group(2).strip()
            if lvl == 1 and not first_h1_done:
                first_h1_done = True   # doc title line: on the cover already
                i += 1
                continue
            if lvl == 1:
                story.append(CondPageBreak(0.25 * (PAGE_H - TM - BM)))
                story.append(add_heading(txt, styles['h1'], 0))
            elif lvl == 2:
                story.append(CondPageBreak(0.18 * (PAGE_H - TM - BM)))
                story.append(add_heading(txt, styles['h2'], 1))
            else:
                story.append(CondPageBreak(0.12 * (PAGE_H - TM - BM)))
                story.append(Paragraph(inline(txt), styles['h3']))
            i += 1
            continue
        # ---- blockquote
        if s.startswith('>'):
            buf = []
            while i < n and lines[i].strip().startswith('>'):
                buf.append(lines[i].strip().lstrip('>').strip())
                i += 1
            story.append(Paragraph(inline(' '.join(b for b in buf if b)),
                                   styles['quote']))
            continue
        # ---- lists
        m2 = re.match(r'^(\s*)[-*]\s+(.*)', ln)
        if m2 and s.startswith(('- ', '* ')):
            depth, txt = len(m2.group(1)), m2.group(2)
            st = styles['bullet'] if depth < 2 else styles['bullet2']
            story.append(Paragraph(inline(txt), st, bulletText='\u2022'))
            i += 1
            continue
        mn = re.match(r'^(\s*)\d+\.\s+(.*)', ln)
        if mn and re.match(r'^\d+\.', s):
            txt = mn.group(2)
            story.append(Paragraph(inline(txt), styles['bullet'], bulletText='-'))
            i += 1
            continue
        # ---- blank
        if not s:
            i += 1
            continue
        # ---- paragraph (merge soft-wrapped lines)
        buf = [ln]
        i += 1
        while i < n:
            nx = lines[i].strip()
            if (not nx or nx.startswith(('#', '|', '>', '```')) or
                    re.match(r'^-{3,}$', nx) or re.match(r'^\s*[-*]\s', nx) or
                    re.match(r'^\s*\d+\.\s', nx)):
                break
            buf.append(lines[i])
            i += 1
        para = ' '.join(b.strip() for b in buf)
        story.append(Paragraph(inline(para), styles['body']))
    return story


def build_table(hdr, rows, pal, styles):
    """Proportional column widths: sum == AVAIL_W (verified)."""
    ncols = len(hdr)
    # weight by max content length per column (capped)
    weights = []
    for c in range(ncols):
        w = len(hdr[c])
        for r in rows:
            if c < len(r):
                w = max(w, min(len(r[c]), 60))
        weights.append(max(w, 4))
    total = float(sum(weights))
    col_w = [max(0.10 * AVAIL_W, w / total * AVAIL_W) for w in weights]
    # renormalize to exactly AVAIL_W
    over = sum(col_w) / AVAIL_W
    col_w = [w / over for w in col_w]
    assert sum(col_w) <= AVAIL_W + 0.5, 'table overflow'
    data = [[Paragraph(inline(h), styles['cellh']) for h in hdr]]
    for r in rows:
        data.append([Paragraph(inline(c if c < len(r) else ''),
                               styles['cell']) for c in range(ncols)])
    t = Table(data, colWidths=col_w, hAlign='CENTER', repeatRows=1)
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), pal['HEADER_FILL']),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.4, pal['BORDER']),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]
    for ri in range(1, len(data)):
        if ri % 2 == 0:
            style.append(('BACKGROUND', (0, ri), (-1, ri), pal['TABLE_STRIPE']))
    t.setStyle(TableStyle(style))
    return t


# ---------------------------------------------------------- doc template ----
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark_name'):
            level = getattr(flowable, 'bookmark_level', 0)
            text = getattr(flowable, 'bookmark_text', '')
            key = getattr(flowable, 'bookmark_key', '')
            self.notify('TOCEntry', (level, text, self.page, key))


def footer_canvas(pal, title):
    def draw(canvas, doc):
        canvas.saveState()
        canvas.setFont('FreeSerif', 8)
        canvas.setFillColor(pal['TEXT_MUTED'])
        canvas.drawString(LM, 0.55 * inch, title)
        canvas.drawRightString(PAGE_W - RM, 0.55 * inch, f'Page {doc.page}')
        canvas.setStrokeColor(pal['BORDER'])
        canvas.setLineWidth(0.4)
        canvas.line(LM, 0.68 * inch, PAGE_W - RM, 0.68 * inch)
        canvas.restoreState()
    return draw


def build_doc(md_path, pal, cover_pdf, out_pdf, doc_title):
    styles = make_styles(pal)
    doc = TocDocTemplate(out_pdf + '.body.pdf', pagesize=A4,
                         leftMargin=LM, rightMargin=RM, topMargin=TM,
                         bottomMargin=BM,
                         title=doc_title, author='Z.ai')
    toc = TableOfContents()
    toc.levelStyles = [styles['toc0'], styles['toc1']]
    story = [toc, PageBreak()]          # the ONLY body page break: TOC -> content
    story += md_to_story(md_path, pal, styles)
    doc.multiBuild(story, onFirstPage=footer_canvas(pal, doc_title),
                   onLaterPages=footer_canvas(pal, doc_title))
    # merge cover
    from pypdf import PdfReader, PdfWriter
    w = PdfWriter()
    r = PdfReader(cover_pdf)
    cp = r.pages[0]
    # normalize cover to the body's exact A4 (html2poster px->pt rounding)
    cp.scale_to(width=595.276, height=841.89)
    w.add_page(cp)
    r2 = PdfReader(out_pdf + '.body.pdf')
    for p in r2.pages:
        w.add_page(p)
    with open(out_pdf, 'wb') as fh:
        w.write(fh)
    os.remove(out_pdf + '.body.pdf')
    print(f'BUILT {out_pdf}')


BASE = '/home/z/my-project'
build_doc(f'{BASE}/FastAlloc/AUDIT.md', PAL_AUDIT,
          f'{BASE}/scripts/pdfbuild/cover_audit.pdf',
          f'{BASE}/download/FastAlloc-Audit-Report.pdf',
          'FastAlloc - Evidence-Backed Audit Report')
build_doc(f'{BASE}/FastAlloc/AUDIT-EXPLANATION.md', PAL_EXPL,
          f'{BASE}/scripts/pdfbuild/cover_explanation.pdf',
          f'{BASE}/download/FastAlloc-Audit-Explanation.pdf',
          'FastAlloc Audit - Detailed Explanation Report')
