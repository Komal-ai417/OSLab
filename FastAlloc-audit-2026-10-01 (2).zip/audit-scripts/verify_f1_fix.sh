#!/bin/bash
# Rebuild + rerun the F1 deterministic repro against the FIXED allocator.
# Before-fix evidence: audit-evidence/f1-optrace.log + tests/lbc-isolated-{1,2,3}.log (SIGABRT).
# After-fix expectation: exit 0, no FATAL, prints PASS lines.
set -u
cd /home/z/my-project/FastAlloc
EV=/home/z/my-project/audit-evidence
mkdir -p "$EV/postfix"
FLAGS_DBG="-g -O2 -std=gnu++17 -DFASTALLOC_DEBUG -I include -I src -pthread"

for variant in repro_f1 repro_f1_nonpooled; do
  g++ $FLAGS_DBG /home/z/my-project/scripts/$variant.cpp src/fast_alloc.cpp src/slab.cpp src/global_heap.cpp src/tls_cache.cpp src/os_memory.cpp src/debug_aid.cpp -o /tmp/$variant-fixed 2>/tmp/$variant-build.log \
    || { echo "$variant BUILD FAILED"; cat /tmp/$variant-build.log; continue; }
  timeout 60 /tmp/$variant-fixed > "$EV/postfix/$variant.log" 2>&1
  echo "$variant: exit=$? :: $(grep -c FATAL $EV/postfix/$variant.log) fatals :: $(tail -1 $EV/postfix/$variant.log)"
done
