// F1 minimal reproducer: fast_realloc large in-place-shrink early-return skips
// the FASTALLOC_DEBUG registry/red-zone update -> false-positive "BUFFER
// OVERFLOW" fatal on a fully legitimate workload.
// Sequence: big alloc -> free -> smaller alloc reuses the span (class-fit) ->
// realloc to a size that requests a >=1page shrink of a POOL-BACKED span ->
// early return (span kept, registry NOT updated) -> user writes new_size
// bytes (legal: the span holds it) -> free -> FATAL false positive.
#include "fast_alloc.h"
#include "fast_alloc_config.h"
#include <cstdio>
#include <cstring>

using namespace FastAlloc;

int main() {
    std::printf("step1: alloc 1986242 (pooled span, ~1.95MB)\n");
    void* p = fast_malloc(1986242);
    if (!p) { std::printf("alloc failed\n"); return 1; }
    std::memset(p, 1, 1986242);
    std::printf("step2: free -> TLS large cache\n");
    fast_free(p);

    std::printf("step3: alloc 1333115 (served from large cache, same span, class-fit)\n");
    p = fast_malloc(1333115);
    if (!p) { std::printf("alloc failed\n"); return 1; }
    if (p == nullptr) return 1;
    std::memset(p, 2, 1333115);

    std::printf("step4: realloc -> 1863587 (<= span usable, diff >= page: shrink path)\n");
    void* q = fast_realloc(p, 1863587);
    if (!q) { std::printf("realloc failed\n"); return 1; }
    std::printf("step5: user writes all 1863587 bytes (legal - span holds it)\n");
    std::memset(q, 3, 1863587);
    std::printf("step6: free -> if F1 fires, this aborts with a false-positive overflow\n");
    fast_free(q);
    std::printf("NO FATAL: F1 did not reproduce on this path\n");
    return 0;
}
