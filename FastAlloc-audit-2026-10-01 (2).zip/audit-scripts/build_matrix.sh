#!/usr/bin/env bash
# FastAlloc audit — build matrix + environment record (Task 3)
# Usage: build_matrix.sh <config-name> <cmake-args...>
set -u
export PATH="$HOME/.local/bin:$PATH"
REPO=/home/z/my-project/FastAlloc
EV=/home/z/my-project/audit-evidence
CFG="$1"; shift
BD="$REPO/build-$CFG"

cd "$REPO"
echo "=== BUILD $CFG: $* ===" | tee -a "$EV/build.log"
cmake -GNinja -B "$BD" -DCMAKE_BUILD_TYPE=Release "$@" > "$EV/build-$CFG-cmake.log" 2>&1
cmake --build "$BD" -j2 > "$EV/build-$CFG.log" 2>&1
rc=$?
echo "config=$CFG rc=$rc" | tee -a "$EV/build.log"
# capture any warnings
grep -E "warning|error" "$EV/build-$CFG.log" | head -40 > "$EV/build-$CFG-warnings.txt" 2>/dev/null
exit $rc
