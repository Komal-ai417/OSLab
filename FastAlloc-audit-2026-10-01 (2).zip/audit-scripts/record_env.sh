#!/usr/bin/env bash
# Record full benchmark/test environment (audit checklist #28/#40)
EV=/home/z/my-project/audit-evidence
{
echo "=== FastAlloc audit environment ==="
date -u
echo "--- git ---"
cd /home/z/my-project/FastAlloc && git rev-parse HEAD && git log -1 --format='%ad %s' --date=iso
echo "--- cpu ---"
grep -m1 "model name" /proc/cpuinfo
echo "cores: $(nproc)"
lscpu 2>/dev/null | grep -E "^(Architecture|CPU\(s\)|Thread|Core|Socket|NUMA|L1d|L2|L3)" || true
echo "--- memory ---"
free -m | head -2
echo "--- kernel/os ---"
uname -a
cat /etc/os-release | head -2
echo "--- compilers ---"
g++ --version | head -1
gcc --version | head -1
ldd --version | head -1
echo "--- flags per config: see build-*.log ---"
echo "--- page size / THP ---"
getconf PAGESIZE
cat /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null || echo "THP sysfs unavailable"
echo "--- governor / affinity ---"
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo "governor sysfs unavailable (container)"
echo "--- allocator env ---"
env | grep -i fastalloc || echo "none"
} > "$EV/environment.txt" 2>&1
cat "$EV/environment.txt"
