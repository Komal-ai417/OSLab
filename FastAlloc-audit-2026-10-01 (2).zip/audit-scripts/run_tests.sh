#!/usr/bin/env bash
# Run existing test suite on a given build dir; capture full log + timing.
# Usage: run_tests.sh <build-dir> <label>
set -u
BD="$1"; LABEL="$2"
EV=/home/z/my-project/audit-evidence
mkdir -p "$EV/tests"
cd "$BD" || exit 2
START=$(date +%s.%N)
./fast_alloc_tests --gtest_shuffle > "$EV/tests/$LABEL.log" 2>&1
rc=$?
END=$(date +%s.%N)
grep -E "^\[.*(PASSED|FAILED)" "$EV/tests/$LABEL.log" | tail -3
python3 -c "print(f'WALL={float('$END')-float('$START'):.2f}s EXIT=$rc')" >> "$EV/tests/$LABEL.log"
grep -E "^\[.*(PASSED|FAILED|RUN)" "$EV/tests/$LABEL.log" | tail -3
echo "[$LABEL] exit=$rc :: $(grep -c '^\[ *OK' $EV/tests/$LABEL.log) passed :: $(grep -c '^\[ *FAILED' $EV/tests/$LABEL.log) failed"
exit $rc
