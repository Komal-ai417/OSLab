#!/usr/bin/env python3
"""Direct gcov-based coverage for FastAlloc. Usage: gcov_direct.py <build-dir>"""
import os, re, subprocess, sys, collections

build = sys.argv[1]
gcda_dirs = []
for root, dirs, files in os.walk(build):
    if any(f.endswith('.gcda') for f in files):
        gcda_dirs.append(root)

per_file = collections.OrderedDict()
total = [0, 0, 0, 0]

for d in gcda_dirs:
    gcs = [os.path.join(d, f) for f in os.listdir(d) if f.endswith('.gcda')]
    if not gcs:
        continue
    r = subprocess.run(['gcov', '-b', '-c'] + gcs, cwd=d, capture_output=True, text=True)
    out = r.stdout
    blocks = out.split("File '")[1:]
    for blk in blocks:
        path = blk.split("'")[0]
        if '/src/' not in path and not path.startswith('src'):
            continue
        if 'googletest' in path or '_deps' in path or '/tests/' in path or '/benchmarks/' in path:
            continue
        name = os.path.basename(path)
        if name in per_file:
            continue
        ml = re.search(r"Lines executed:(\d+\.\d+)% of (\d+)", blk)
        mb = re.search(r"Branches executed:(\d+\.\d+)% of (\d+)", blk)
        if not ml:
            continue
        lt = int(ml.group(2)); lh = round(float(ml.group(1)) / 100 * lt)
        bt = int(mb.group(2)) if mb else 0
        bh = round(float(mb.group(1)) / 100 * bt) if mb else 0
        per_file[name] = [lh, lt, bh, bt]
        total[0] += lh; total[1] += lt; total[2] += bh; total[3] += bt

print("per-file (lines hit/total, branch hit/total):")
for name, (h, t, bh, bt) in sorted(per_file.items()):
    print("  %-24s %5d/%-5d %5.1f%% | %4d/%-4d %5.1f%%" % (name, h, t, 100*h/t if t else 0, bh, bt, 100*bh/bt if bt else 0))
if total[1]:
    print("AGGREGATE src/: line=%.4f (%d/%d) branch=%.4f (%d/%d)" % (total[0]/total[1], total[0], total[1], total[2]/total[3], total[2], total[3]))
