#!/bin/bash
# Static analysis: GCC -fanalyzer (all checkers) + clang-tidy 19 (perf+bugprone+misc).
set -u
SRC=/home/z/my-project/FastAlloc
EV=/home/z/my-project/audit-evidence/static
mkdir -p "$EV"; cd "$SRC"
CB=/home/z/my-project/tools/clangroot/usr/bin
LIBS="src/fast_alloc.cpp src/slab.cpp src/global_heap.cpp src/tls_cache.cpp src/os_memory.cpp src/debug_aid.cpp"
INCS="-I include -I src"

echo "== GCC -fanalyzer (release semantics) =="
for f in $LIBS; do
  g++ -fanalyzer -fanalyzer-verbosity=1 -O2 -std=gnu++17 $INCS -c "$f" -o /dev/null \
    >> "$EV/fanalyzer.log" 2>&1
done
echo "fanalyzer diagnostics: $(grep -c "warning:" "$EV/fanalyzer.log" || true)"
grep "warning:" "$EV/fanalyzer.log" | head -12 || true

echo "== GCC -fanalyzer (FASTALLOC_DEBUG semantics) =="
: > "$EV/fanalyzer-debug.log"
for f in $LIBS; do
  g++ -fanalyzer -O2 -std=gnu++17 -DFASTALLOC_DEBUG $INCS -c "$f" -o /dev/null \
    >> "$EV/fanalyzer-debug.log" 2>&1
done
echo "fanalyzer(debug) diagnostics: $(grep -c "warning:" "$EV/fanalyzer-debug.log" || true)"
grep "warning:" "$EV/fanalyzer-debug.log" | head -12 || true

echo "== clang-tidy 19 =="
export LD_LIBRARY_PATH=/home/z/my-project/tools/clangroot/usr/lib/x86_64-linux-gnu:/home/z/my-project/tools/clangroot/usr/lib
CHECKS="bugprone-*,performance-*,misc-*,modernize-*,readability-*,-modernize-use-trailing-return-type,-readability-identifier-length,-bugprone-easily-swappable-parameters"
{
  for f in $LIBS; do
    $CB/clang-tidy-19 "$f" --checks="$CHECKS" -- $INCS -std=gnu++17 -O1 -DFASTALLOC_DEBUG=1
  done
} > "$EV/clang-tidy.log" 2>&1
echo "clang-tidy diagnostics: $(grep -c "warning:" "$EV/clang-tidy.log" || true)"
grep "warning:" "$EV/clang-tidy.log" | sed 's/.*warning:/warning:/' | sort | uniq -c | sort -rn | head -15
