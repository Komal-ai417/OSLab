// Op-trace reproducer for StressTest.LargeBlockChurn (FINDING F1)
// Replicates tests/test_stress.cpp StressRound(0xFEED2, 3000, 64, 2MB, 10)
// with per-op logging so the FATAL's last op identifies the trigger.
#include "fast_alloc.h"
#include "fast_alloc_config.h"
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>

using namespace FastAlloc;

static unsigned char PatternByte(std::size_t seed, std::size_t i) {
    return static_cast<unsigned char>((seed * 2654435761u + i * 40503u) >> 8);
}
struct LiveBlock { void* ptr; std::size_t size; std::size_t seed; };

int main() {
    std::mt19937 rng(0xFEED2);
    std::vector<LiveBlock> live;
    live.reserve(64);
    const std::size_t max_size = 2 * 1024 * 1024;
    const int realloc_prob = 10;
    for (int op = 0; op < 3000; ++op) {
        int action = static_cast<int>(rng() % 100);
        if (live.size() >= 64) action = 90;
        if (live.empty()) action = 0;
        if (action < 60) {
            std::size_t s = 1 + rng() % max_size;
            std::fprintf(stderr, "op#%d ALLOC s=%zu (live=%zu)\n", op, s, live.size());
            void* p = fast_malloc(s);
            if (!p) { std::fprintf(stderr, "op#%d ALLOC returned NULL\n", op); return 1; }
            std::size_t seed = rng();
            unsigned char* c = static_cast<unsigned char*>(p);
            for (std::size_t i = 0; i < s; ++i) c[i] = PatternByte(seed, i);
            live.push_back({p, s, seed});
        } else if (action < 60 + realloc_prob) {
            std::size_t idx = rng() % live.size();
            LiveBlock& b = live[idx];
            std::size_t ns = 1 + rng() % max_size;
            std::fprintf(stderr, "op#%d REALLOC idx=%zu old=%zu new=%zu ptr=%p\n", op, idx, b.size, ns, b.ptr);
            void* np = fast_realloc(b.ptr, ns);
            if (!np) { std::fprintf(stderr, "op#%d REALLOC returned NULL\n", op); return 1; }
            unsigned char* c = static_cast<unsigned char*>(np);
            std::size_t check = b.size < ns ? b.size : ns;
            bool broke = false;
            for (std::size_t i = 0; i < check; ++i) {
                if (c[i] != PatternByte(b.seed, i)) { std::fprintf(stderr, "op#%d REALLOC pattern broken at %zu (old=%zu new=%zu)\n", op, i, b.size, ns); broke = true; break; }
            }
            if (broke) return 2;
            std::size_t nseed = rng();
            for (std::size_t i = 0; i < ns; ++i) c[i] = PatternByte(nseed, i);
            b.ptr = np; b.size = ns; b.seed = nseed;
        } else {
            std::size_t idx = rng() % live.size();
            LiveBlock b = live[idx];
            live[idx] = live.back();
            live.pop_back();
            std::fprintf(stderr, "op#%d FREE idx=%zu size=%zu ptr=%p\n", op, idx, b.size, b.ptr);
            unsigned char* c = static_cast<unsigned char*>(b.ptr);
            for (std::size_t i = 0; i < b.size; ++i) {
                if (c[i] != PatternByte(b.seed, i)) { std::fprintf(stderr, "op#%d FREE pattern broken at %zu (size=%zu)\n", op, i, b.size); return 3; }
            }
            fast_free(b.ptr);
        }
    }
    std::fprintf(stderr, "completed all ops\n");
    return 0;
}
