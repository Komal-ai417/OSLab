#!/bin/bash
# Sanitizer matrix: ASan(+LSan), UBSan, TSan across existing + audit suites.
# GCC 14.2. Output: /home/z/my-project/audit-evidence/sanitizers/
set -u
SRC=/home/z/my-project/FastAlloc
EV=/home/z/my-project/audit-evidence/sanitizers
export PATH=/home/z/.local/bin:$PATH
mkdir -p "$EV"

run_matrix () {  # $1=name $2=flags $3=env
  local name="$1" flags="$2" env="$3"
  local bd="$SRC/build-$name"
  rm -rf "$bd"; mkdir -p "$bd"
  (cd "$bd" && cmake -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DFASTALLOC_BUILD_TESTS=ON \
      -DFASTALLOC_BUILD_BENCHMARKS=OFF -DCMAKE_CXX_FLAGS="$flags" "$SRC" \
      > "$EV/$name-cmake.log" 2>&1) || { echo "$name: CMAKE FAILED"; return 1; }
  (cd "$bd" && ninja fast_alloc_tests fast_alloc_audit_tests > "$EV/$name-build.log" 2>&1) \
      || { echo "$name: BUILD FAILED"; tail -5 "$EV/$name-build.log"; return 1; }
  echo "== $name: existing suite =="
  (cd "$bd" && eval "$env" timeout 900 ./fast_alloc_tests \
      > "$EV/$name-existing.log" 2>&1; echo "exit=$?" >> "$EV/$name-existing.log")
  grep -E "PASSED|FAILED|exit=" "$EV/$name-existing.log" | tail -3
  echo "== $name: audit suite =="
  (cd "$bd/tests/audit" && eval "$env" timeout 900 ./fast_alloc_audit_tests \
      > "$EV/$name-audit.log" 2>&1; echo "exit=$?" >> "$EV/$name-audit.log")
  grep -E "PASSED|FAILED|exit=" "$EV/$name-audit.log" | tail -3
  echo "== $name: ERROR SUMMARY =="
  {
    grep -cE "ERROR: (AddressSanitizer|LeakSanitizer)" "$EV/$name-existing.log" || true
    grep -c "runtime error" "$EV/$name-existing.log" || true
    grep -cE "WARNING: ThreadSanitizer" "$EV/$name-existing.log" || true
  } | paste -sd/ - | sed "s/^/$name-existing (asan/ubsan/tsan counts): /"
}

run_matrix asan  "-fsanitize=address -fsanitize-address-use-after-scope -fno-omit-frame-pointer -g" \
  "ASAN_OPTIONS=detect_leaks=1:abort_on_error=0:detect_stack_use_after_return=1:allocator_may_return_null=1"
run_matrix ubsan "-fsanitize=undefined -fno-omit-frame-pointer -g" \
  "UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=0"
run_matrix tsan  "-fsanitize=thread -fno-omit-frame-pointer -g -O1" \
  "TSAN_OPTIONS=second_deadlock_stack=1:history_size=7:allocator_may_return_null=1"
echo "ALL DONE. Summary:"; ls "$EV"
