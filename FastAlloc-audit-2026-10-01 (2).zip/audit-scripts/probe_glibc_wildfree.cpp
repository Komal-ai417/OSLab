// Evidence probe: does glibc free() also crash on a wild low pointer (0x10000)?
// Parity check for the audit report: the FastAlloc plausibility guard admits
// [0x10000, 2^47) 16-aligned pointers; the header read at p-16 faults on the
// unmapped low page. If glibc does the same, FastAlloc is at industry parity
// for this UB class (documented trade-off, not a defect).
#include <cstdlib>
#include <cstdio>
int main() {
    std::printf("calling free(0x10000) under glibc...\n");
    std::fflush(stdout);
    std::free(reinterpret_cast<void*>(0x10000));
    std::printf("survived (unexpected)\n");
    return 0;
}
