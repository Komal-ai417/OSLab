#!/bin/bash
# Build the audit fuzz harnesses: standalone (g++) + libFuzzer (clang 19 + ASan/UBSan).
set -u
SRC=/home/z/my-project/FastAlloc
OUT=/home/z/my-project/audit-evidence/fuzz
CB=/home/z/my-project/tools/clangroot/usr/bin
export LD_LIBRARY_PATH=/home/z/my-project/tools/clangroot/usr/lib/x86_64-linux-gnu:/home/z/my-project/tools/clangroot/usr/lib
mkdir -p "$OUT"

LIBS="$SRC/src/fast_alloc.cpp $SRC/src/slab.cpp $SRC/src/global_heap.cpp $SRC/src/tls_cache.cpp $SRC/src/os_memory.cpp $SRC/src/debug_aid.cpp"

echo "== standalone (g++ release semantics) =="
g++ -O2 -g -std=gnu++17 -I"$SRC/include" -I"$SRC/src" -pthread \
    "$SRC/fuzz/fuzz_standalone.cpp" $LIBS -o "$OUT/fuzz_standalone" \
    > "$OUT/build-standalone.log" 2>&1 && echo OK || tail -5 "$OUT/build-standalone.log"

echo "== standalone DEBUG semantics (canaries/registry active) =="
g++ -O2 -g -std=gnu++17 -DFASTALLOC_DEBUG -I"$SRC/include" -I"$SRC/src" -pthread \
    "$SRC/fuzz/fuzz_standalone.cpp" $LIBS -o "$OUT/fuzz_standalone_dbg" \
    > "$OUT/build-standalone-dbg.log" 2>&1 && echo OK || tail -5 "$OUT/build-standalone-dbg.log"

echo "== libFuzzer (clang 19, fuzzer+address+undefined) =="
$CB/clang++-19 -g -O1 -std=gnu++17 -fsanitize=fuzzer,address,undefined \
    -fno-omit-frame-pointer -I"$SRC/include" -I"$SRC/src" -pthread \
    "$SRC/fuzz/fuzz_ops_libfuzzer.cpp" $LIBS -o "$OUT/fuzz_ops_libfuzzer" \
    > "$OUT/build-libfuzzer.log" 2>&1 && echo OK || tail -8 "$OUT/build-libfuzzer.log"
ls -la "$OUT"
