/* waitdemo - exit() -> ZOMBIE -> wait() reaps it and copies the status.
 *   break exit ; break wait   then run   waitdemo   in the LUIT shell. */
#include "ulib.h"

int
main(void)
{
    int pid = fork();
    if (pid == 0) {
        printf("  child %d: exiting with status 7\n", getpid());
        exit(7);
    }
    int st;
    int got = wait(&st);
    printf("waitdemo: wait() returned pid %d, status %d\n", got, st);
    exit(0);
}
