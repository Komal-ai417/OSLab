/* ufault - deliberately store to an unmapped address to raise a page fault.
 *   break usertrap   then run   ufault   in the LUIT shell.
 * Expect: scause = 15 (store/AMO page fault), stval = 0xdead0000,
 * sepc = the faulting instruction. The kernel prints a message and kills
 * this process; the kernel itself keeps running. */
#include "ulib.h"

int
main(void)
{
    printf("ufault: storing to 0xdead0000 (unmapped) - expect a page fault\n");
    volatile int *bad = (volatile int *)0xdead0000UL;
    *bad = 42;                   /* store page fault here */
    printf("ufault: this line must never print\n");
    exit(0);
}
