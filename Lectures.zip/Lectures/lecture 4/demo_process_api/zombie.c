/* zombie - hold a child in the ZOMBIE state so 'ps' / gdb 'procs' can show it.
 * The parent sleeps BEFORE calling wait(), so during the sleep the exited
 * child has no reaper yet and stays ZOMBIE. */
#include "ulib.h"

int
main(void)
{
    int pid = fork();
    if (pid == 0) {
        exit(0);                 /* becomes ZOMBIE until the parent wait()s */
    }
    printf("zombie: child %d created; parent sleeping WITHOUT wait()\n", pid);
    printf("zombie: run 'ps' (shell) or 'procs' (gdb) now to see it ZOMBIE\n");
    sleep(50);
    int st;
    wait(&st);                   /* now reap it */
    printf("zombie: parent reaped child, status %d\n", st);
    exit(0);
}
