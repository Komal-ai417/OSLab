/* forkdemo - one fork(), two return values. For the GDB classroom demo:
 *   break sys_fork   (or: break fork)   then run   forkdemo   in the LUIT shell.
 * Exactly one fork happens, so the breakpoint fires once. */
#include "ulib.h"

int
main(void)
{
    printf("forkdemo: parent pid = %d, calling fork()\n", getpid());

    int pid = fork();
    if (pid < 0) {
        printf("forkdemo: fork failed\n");
        exit(1);
    }

    if (pid == 0) {
        /* child: fork() returned 0 here */
        printf("  child : fork() returned %d, my pid = %d\n", pid, getpid());
        exit(0);
    } else {
        /* parent: fork() returned the child's pid */
        int st;
        wait(&st);
        printf("  parent: fork() returned %d (child pid), child exit status %d\n",
               pid, st);
        exit(0);
    }
}
