# LUIT GDB demo pack — install & guide corrections

The classroom GDB guide references demonstration programs (`forkdemo`,
`waitdemo`, `zombie`, `ufault`) that are **not** in the student release. These
four files supply them. All were built and run on the release kernel, and the
GDB breakpoints/inspection commands in the guide were checked against them.

## Which program for which demo

| Guide demo | Program | Runs |
|---|---|---|
| Demo  — `fork()` and two return values | `forkdemo` | verified |
| Demo  — `exit()` / zombie / `wait()` | `waitdemo`, `zombie` | verified |
| Demo  — page fault | `ufault` | verified |
| Demo  — one syscall / trap entry | any program (`echo hello`) | uses shipped `echo` |
| Demo  — timer preemption / `swtch` | any long run + `CPUS=1` | uses shipped progs |

> **On the guide's "forkdemo": there is no forkdemo in the release — use this one.**
> If you want zero new code for a single class, note that the shell forks for
> every command, so `break fork` + running any command hits `fork()`. But that
> breakpoint also fires for `init` forking `sh` and for the shell forking each
> command, so you must continue past those. `forkdemo` forks exactly once, which
> is why it makes the cleaner demo.

## Install

1. Copy the four `.c` files into `user/`.
2. Add them to `UPROGS` in the `Makefile` (keep the continuation style):

   ```make
   UPROGS = user/init user/sh user/echo user/cat user/ls user/mkdir user/rm \
            user/wc user/grep user/kill user/ln user/ps user/meminfo user/vdemo \
            user/usertests user/forktest \
            user/forkdemo user/waitdemo user/zombie user/ufault
   ```

3. `make clean && make`, then `make qemu-gdb CPUS=1`.

## Verified behaviour (on the release kernel)

```
luit$ forkdemo
forkdemo: parent pid = 3, calling fork()
  child : fork() returned 0, my pid = 4
  parent: fork() returned 4 (child pid), child exit status 0

luit$ waitdemo
  child 6: exiting with status 7
waitdemo: wait() returned pid 6, status 7

luit$ ufault
ufault: storing to 0xdead0000 (unmapped) - expect a page fault
usertrap: pid 7 store page fault at va 0x00000000dead0000 (sepc 0x...1034) - killing
```