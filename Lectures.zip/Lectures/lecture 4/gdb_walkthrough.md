# LUIT under GDB: `fork()`'s two returns and the user ↔ kernel boundary

A step-by-step walkthrough using `forkdemo` and `waitdemo`. Every command
and every "you should see" block below was run against the LUIT release kernel. Process IDs and a few addresses
are run-dependent and may differ by a small amount; the *relationships* are stable.

---

## 0. Before our next class, practice

You need the **demo pack** installed (`forkdemo`, `waitdemo` in `UPROGS`) — see
`DEMO_PACK_INSTALL.md`. You also need GDB able to load the repo `.gdbinit`
(the auto-load safe-path line) if you rely on it; the steps below connect
explicitly so they work either way.

**Why we use conditional breakpoints.** `fork`, `exit`, `wait`, and `syscall` all
run constantly — `init` forks `sh` at boot, and the shell forks for *every* command
you type. If you just `break fork`, your first stop is boot noise, not your demo. So
each breakpoint below carries an `if` condition that fires only for the demo process
(`$_streq(p->name,"forkdemo")`). A no-conditions fallback is in §4.

### Reference numbers (LUIT)

| Thing | Values |
|---|---|
| Syscall numbers (`a7`) | `fork`=1, `exit`=2, `wait`=3, `write`=16 |
| `scause` (trap cause) | 8 = ecall from U-mode; 13 = load page fault; 15 = store page fault |
| `enum procstate` | 0 UNUSED, 1 USED, 2 SLEEPING, 3 RUNNABLE, 4 RUNNING, 5 ZOMBIE |

---

## 1. Start the session (two terminals)

**Terminal A — the machine.** One hart keeps the trace simple:

```bash
make clean && make          # or: make DEBUG=1   for -Og (less jumpy stepping)
make qemu-gdb CPUS=1
```

QEMU loads but does not run: it is waiting for GDB on TCP 1234.

**Terminal B — the debugger.**

```bash
gdb-multiarch kernel.elf
```

If your `.gdbinit` connects automatically you will see the `[Luit] connected`
banner. If not, connect by hand:

```gdb
set architecture riscv:rv64
target remote localhost:1234
symbol-file kernel.elf
```

---

## 2. Demo 1 — `forkdemo`: one syscall across the boundary, two return values

The whole point in one program: a user process executes `ecall`, the CPU switches to
supervisor mode, the kernel runs `fork()`, and **the same instruction returns two
different values** — 0 in the child, the child's PID in the parent.

### Step 1 — Stop the instant the fork syscall enters the kernel

```gdb
break trap.c:121 if $_streq(p->name,"forkdemo") && scause==8 && p->tf->a7==1
continue
```

Now, in **Terminal A**, run the program:

```text
luit$ forkdemo
```

GDB stops in `usertrap()`. Inspect the crossing:

```gdb
p p->name
p scause
p p->tf->a7
p/x p->tf->epc
```

You should see:

```
$1 = "forkdemo"
$2 = 8            # ecall from U-mode: we just came from user space
$3 = 1            # a7 = 1 = fork
$4 = 0x16be       # saved user PC = the ecall instruction itself
```

**Say this:** `scause == 8` means the CPU trapped because user code executed `ecall`.
The kernel does not "call" a syscall — the *user* raises a trap, and `a7` carries the
number the user put there. `epc` is the user address to come back to.

### Step 2 — Watch the kernel decide where the user resumes

The saved `epc` still points *at* the `ecall`. If we returned there we'd loop forever,
so the kernel advances it by 4 (one instruction):

```gdb
tbreak trap.c:124
continue
p/x p->tf->epc
```

```
$5 = 0x16c2       # 0x16be + 4 : resume AFTER the ecall
```

### Step 3 — See the dispatch

```gdb
tbreak syscall.c:128 if $_streq(p->name,"forkdemo")
continue
p num
```

```
$6 = 1            # syscall() will call syscalls[1]() == sys_fork
```

`syscall.c:128` is literally `p->tf->a0 = syscalls[num]();` — the return value of the
handler is about to be written into the saved user `a0`.

### Step 4 — Inside `fork()`: the child's return value is set to 0

```gdb
tbreak proc.c:212 if $_streq(parent->name,"forkdemo")
continue
p parent->pid
p np->pid
p np->state
p np->tf->a0
```

```
$7  = 3           # parent (the forkdemo process)
$8  = 4           # np = the new child
$9  = 1           # child state = USED (being built)
$10 = 0           # child's saved a0 == 0  <-- the CHILD will see fork() return 0
```

**Say this:** the kernel builds the child by *copying the parent's trapframe*
(`proc.c:200`, `*(np->tf) = *(parent->tf)`), then overwrites one field:
`np->tf->a0 = 0` (`proc.c:201`). That single line is why the child sees `0`.

### Step 5 — Back in the kernel: the parent's return value is the child's PID

```gdb
tbreak syscall.c:133 if $_streq(p->name,"forkdemo")
continue
p p->tf->a0
```

```
$11 = 4           # parent's saved a0 == child's pid  <-- the PARENT sees fork()==4
```

`fork()` returned `pid` (the child's PID) to `sys_fork`, and `syscall()` wrote it into
the parent's `a0`. When each process later executes `sret` and resumes in user mode,
each reads its own `a0`.

### Step 6 — Let it run and confirm at the user level

```gdb
continue
```

In **Terminal A**:

```text
forkdemo: parent pid = 3, calling fork()
  child : fork() returned 0, my pid = 4
  parent: fork() returned 4 (child pid), child exit status 0
```

**The payoff:** one `ecall`, one kernel path, but two user-visible results — `0` for
the child (from `np->tf->a0 = 0`) and `4` for the parent (from the `pid` return). That
is the "fork returns twice" idea, made concrete.

---

## 3. Demo 2 — `waitdemo`: `exit()` → ZOMBIE → `wait()` reaps it

A process does not vanish on `exit()`. It becomes a **ZOMBIE**, holding just its exit
status, until its parent calls `wait()`.

### Step 1 — Stop the child as it becomes a zombie

```gdb
delete
break proc.c:256 if $_streq(p->name,"waitdemo")
continue
```

In **Terminal A**:

```text
luit$ waitdemo
```

GDB stops just before `proc.c:256` (`p->state = ZOMBIE;`). Inspect:

```gdb
p p->pid
p status
p p->xstate
p p->state
```

```
$1 = 4            # the child
$2 = 7            # the status it passed to exit(7)
$3 = 7            # xstate already holds the status (set one line earlier)
$4 = 4            # state == 4 == RUNNING, for one more line
```

Now execute the ZOMBIE assignment and re-check:

```gdb
next
p p->state
```

```
$5 = 5            # state == 5 == ZOMBIE
```

**Say this:** `exit()` closes the child's files, records `xstate = status`, marks it
`ZOMBIE`, and calls `sched()` — it never returns. The process is dead but its slot and
exit code survive so the parent can collect them.

### Step 2 — The parent finds and reaps the zombie

```gdb
tbreak proc.c:275 if $_streq(p->name,"waitdemo")
continue
p p->pid
p pp->pid
p pp->xstate
```

```
$6 = 3            # the parent, now inside wait()
$7 = 4            # pp = the zombie child it found
$8 = 7            # the status wait() will hand back to the parent
```

`wait()` scans the process table for a child in state ZOMBIE, copies its `xstate` out
to the parent's buffer, frees the slot, and returns the child's PID.

### Step 3 — Finish

```gdb
continue
```

**Terminal A:**

```text
  child 6: exiting with status 7
waitdemo: wait() returned pid 6, status 7
```

(The PIDs here are from a separate run — hence 6, not 4. Relationships hold.)

---

## 4. Alternatives without conditional breakpoints

If you would rather not type `if` conditions, break plainly and step past the
boot/shell forks:

```gdb
break sys_fork
continue                 # (type: luit$ forkdemo)  -- FIRST hit = the SHELL forking forkdemo
p myproc()->name         # -> "sh"   : not us yet
continue                 # SECOND hit = forkdemo forking its own child
p myproc()->name         # -> "forkdemo"  : this is the one
```

Same idea for `exit`/`wait`: the first hits belong to other processes; check
`p myproc()->name` and `continue` until it is your demo program. The conditional form
in §2–3 just does this filtering for you.

---

## 5. Teaching points to land

- A system call is a **trap the user raises**, not a function the kernel calls.
  `scause=8`, `a7`=number, `a0–a5`=arguments, return value goes back in `a0`.
- The kernel advances `epc` by 4 so the user resumes *after* the `ecall`.
- `fork()` returns twice because the kernel writes **two different `a0` values** into
  two different trapframes: `0` into the child's, the child's PID into the parent's.
- `exit()` does not free the process; it makes a **ZOMBIE**. `wait()` is what frees it
  and delivers the status. This is why an un-`wait()`ed child lingers.

## 6. Cleanup / gotchas

- Quit GDB with `quit`; stop QEMU with `Ctrl-A` then `x`.
- Use `CPUS=1`. With 4 harts, several CPUs hit breakpoints at once and the trace is
  hard to narrate.
- If stepping jumps around, rebuild with `make DEBUG=1` (`-Og`) for the demo.
- If a breakpoint never fires, your condition string probably has the wrong process
  name, or you forgot to actually run the program in Terminal A.
