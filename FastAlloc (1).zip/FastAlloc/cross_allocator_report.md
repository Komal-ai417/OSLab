# FastAlloc benchmark matrix (cross_allocator_results.jsonl)


## Throughput (T=1)

| workload (ns/op, T=1) |      glibc |   jemalloc |   mimalloc |  FastAlloc |
|---|---|---|---|---|
| tiny                       |      55.05 |      23.25 |          - |      25.67 |
| small-mixed                |      39.37 |      28.10 |          - |      34.41 |
| random-1-4096              |      76.68 |      23.87 |          - |      20.75 |
| ramp                       |     142.32 |     161.56 |          - |     103.17 |
| churn                      |     399.56 |     185.57 |          - |     163.89 |
| cache-thrash               |     307.69 |      92.09 |          - |     120.89 |
| cross-thread               |      55.95 |      37.04 |          - |      46.25 |
| thread-churn               |     229.29 |     947.51 |          - |     444.80 |
| large                      |      49.51 |     667.89 |          - |      39.74 |
| realloc-grow               |      21.93 |      87.52 |          - |      60.54 |
| overhead                   |     402.73 |     430.04 |          - |     450.20 |

### FastAlloc speedup (T=1) — >1.00x = FastAlloc faster

| workload (T=1) | vs glibc | vs jemalloc | vs mimalloc | verdict |
|---|---|---|---|---|
| tiny                       |   2.14x |   0.91x |    -   | PARTIAL |
| small-mixed                |   1.14x |   0.82x |    -   | PARTIAL |
| random-1-4096              |   3.70x |   1.15x |    -   | WIN |
| ramp                       |   1.38x |   1.57x |    -   | WIN |
| churn                      |   2.44x |   1.13x |    -   | WIN |
| cache-thrash               |   2.55x |   0.76x |    -   | PARTIAL |
| cross-thread               |   1.21x |   0.80x |    -   | PARTIAL |
| thread-churn               |   0.52x |   2.13x |    -   | PARTIAL |
| large                      |   1.25x |  16.81x |    -   | WIN |
| realloc-grow               |   0.36x |   1.45x |    -   | PARTIAL |
| overhead                   |   0.89x |   0.96x |    -   | LOSS |

## Throughput (T=2)

| workload (ns/op, T=2) |      glibc |   jemalloc |   mimalloc |  FastAlloc |
|---|---|---|---|---|
| tiny                       |      37.60 |      24.17 |          - |      31.22 |
| small-mixed                |      46.88 |      41.97 |          - |      35.65 |
| random-1-4096              |      82.11 |      23.35 |          - |      26.87 |
| ramp                       |     159.21 |     147.47 |          - |      82.12 |
| churn                      |     382.56 |     262.96 |          - |     193.89 |
| cache-thrash               |     313.21 |     146.45 |          - |     293.65 |
| cross-thread               |     493.12 |      89.22 |          - |     386.10 |
| thread-churn               |     165.35 |     741.78 |          - |     272.17 |
| large                      |     125.22 |     914.76 |          - |     103.63 |
| realloc-grow               |      20.29 |     170.10 |          - |      95.97 |
| overhead                   |     319.58 |     365.50 |          - |     456.81 |

### FastAlloc speedup (T=2) — >1.00x = FastAlloc faster

| workload (T=2) | vs glibc | vs jemalloc | vs mimalloc | verdict |
|---|---|---|---|---|
| tiny                       |   1.20x |   0.77x |    -   | PARTIAL |
| small-mixed                |   1.32x |   1.18x |    -   | WIN |
| random-1-4096              |   3.06x |   0.87x |    -   | PARTIAL |
| ramp                       |   1.94x |   1.80x |    -   | WIN |
| churn                      |   1.97x |   1.36x |    -   | WIN |
| cache-thrash               |   1.07x |   0.50x |    -   | PARTIAL |
| cross-thread               |   1.28x |   0.23x |    -   | PARTIAL |
| thread-churn               |   0.61x |   2.73x |    -   | PARTIAL |
| large                      |   1.21x |   8.83x |    -   | WIN |
| realloc-grow               |   0.21x |   1.77x |    -   | PARTIAL |
| overhead                   |   0.70x |   0.80x |    -   | LOSS |

## Throughput (T=4)

| workload (ns/op, T=4) |      glibc |   jemalloc |   mimalloc |  FastAlloc |
|---|---|---|---|---|
| tiny                       |      61.37 |      21.43 |          - |      31.98 |
| small-mixed                |      63.97 |      37.58 |          - |      57.24 |
| random-1-4096              |      78.84 |      21.63 |          - |      28.15 |
| ramp                       |     130.60 |     101.75 |          - |      93.99 |
| churn                      |     284.56 |     158.88 |          - |     188.65 |
| cache-thrash               |     190.35 |     174.92 |          - |     115.95 |
| cross-thread               |     823.18 |     130.95 |          - |     446.60 |
| thread-churn               |     247.63 |     746.91 |          - |     245.51 |
| large                      |     170.71 |     923.23 |          - |     114.73 |
| realloc-grow               |      20.23 |      89.63 |          - |      59.53 |
| overhead                   |     359.74 |     334.51 |          - |     478.71 |

### FastAlloc speedup (T=4) — >1.00x = FastAlloc faster

| workload (T=4) | vs glibc | vs jemalloc | vs mimalloc | verdict |
|---|---|---|---|---|
| tiny                       |   1.92x |   0.67x |    -   | PARTIAL |
| small-mixed                |   1.12x |   0.66x |    -   | PARTIAL |
| random-1-4096              |   2.80x |   0.77x |    -   | PARTIAL |
| ramp                       |   1.39x |   1.08x |    -   | WIN |
| churn                      |   1.51x |   0.84x |    -   | PARTIAL |
| cache-thrash               |   1.64x |   1.51x |    -   | WIN |
| cross-thread               |   1.84x |   0.29x |    -   | PARTIAL |
| thread-churn               |   1.01x |   3.04x |    -   | WIN |
| large                      |   1.49x |   8.05x |    -   | WIN |
| realloc-grow               |   0.34x |   1.51x |    -   | PARTIAL |
| overhead                   |   0.75x |   0.70x |    -   | LOSS |

## Latency percentiles (1 thread)

| workload | allocator | p50 | p99 | p99.9 |
|---|---|---|---|---|
| tiny | glibc | 52.4 | 60.9 | 360.3 |
| tiny | jemalloc | 21.4 | 34.5 | 148.5 |
| tiny | FastAlloc | 24.0 | 40.0 | 161.2 |
| small-mixed | glibc | 37.3 | 61.5 | 202.2 |
| small-mixed | jemalloc | 26.1 | 42.4 | 168.1 |
| small-mixed | FastAlloc | 31.6 | 54.0 | 228.3 |
| random-1-4096 | glibc | 73.2 | 151.1 | 314.9 |
| random-1-4096 | jemalloc | 21.9 | 34.7 | 152.5 |
| random-1-4096 | FastAlloc | 19.0 | 35.7 | 160.8 |

## Memory (overhead workload, 1M objects)

| metric | glibc | jemalloc | mimalloc | FastAlloc |
|---|---|---|---|---|
| RSS/live ratio | 0.78 | 0.82 | - | 0.91 |
| retained after free (MB) | 369.61 | 116.47 | - | 89.19 |
| retained after purge (MB) | 46.60 | 116.47 | - | 15.98 |
| alloc phase (ms) | 335.90 | 268.96 | - | 274.28 |
| free phase (ms) | 66.83 | 161.08 | - | 175.92 |

## Thread scaling (churn)

| threads | glibc M ops/s | jemalloc M ops/s | mimalloc M ops/s | FastAlloc M ops/s |
|---|---|---|---|---|
| T=1 |       2.50 |       5.39 |          - |       6.10 |
| T=2 |       2.61 |       3.80 |          - |       5.16 |
| T=4 |       3.51 |       6.29 |          - |       5.30 |
